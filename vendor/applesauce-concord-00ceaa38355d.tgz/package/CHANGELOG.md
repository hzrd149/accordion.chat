# @applesauce/concord

## Unreleased

### Added (minor)

- `ConcordClient.createNewCommunity`, `joinByLink`, `joinByBundle` and `leave` reject with
  `ConcordClientNotStartedError` and change nothing before `start()` or after `stop()`, so start the client before
  changing memberships.
- A disposed `ConcordClient` cannot be restarted: `start()`, membership changes and `unlockCommunityListFragments()`
  reject with `ConcordClientDisposedError` (a subclass of `ConcordClientNotStartedError`) and
  `startDirectInviteWatcher()` throws it, so create a new client instead.
- A `ConcordClient.start()` that rejects, for example when the signer's `getPublicKey` fails, leaves the client stopped
  so the next `start()` runs normally, and a `start()` cut short by `stop()` or `dispose()` reads and publishes nothing
  afterwards.
- `joinByBundle()`, `joinByLink()` and `leave()` calls for one community take effect in the order you make them, and
  calls still queued when `stop()` or `dispose()` runs reject at once and never prompt the signer in a later lifecycle.
- A join or create that rejects after recording the membership, for example because the signer declines your Join, keeps
  the membership and still saves your Community List, and joining a community you already joined re-publishes your Join,
  so retrying finishes a failed join.
- `ConcordClient.diagnostics$` and `ConcordCommunity.diagnostics$` report background failures as typed
  `ConcordDiagnostic` values with a `stage` label, such as `community-list-save` or `duty-exhausted`, instead of
  printing to the console, while text logs stay available through the `applesauce:concord` logger.
- Messages and other background publishes (channel rekeys and grants, invite bundles and the Invite List) that no relay
  accepts are reported on `diagnostics$` as `plane-publish` or their own publish stage with a `RequiredPublishError`
  holding each relay's response, not only when the relay pool throws.
- A later `ConcordInviteManager.save()` republishes an Invite List that no relay accepted, tombstones included, and
  `dirty$` turns back to `true` after such a publish so you know to call `save()` again.
- `ConcordClient` syncs your Community List as kind 33302 fragments with scoped writes, size-based splitting and
  complete-list repacks, reads legacy kind 13302 lists without ever writing them, and `/helpers` exposes the wire codecs
  `encodeCommunityListFragment`, `decodeCommunityListFragment`, `encodeCommunityListSnapshot` and
  `decodeLegacyCommunityList`.
- `ConcordClient.memberships$` and `memberships()` report your live memberships, tombstones, how complete the relay copy
  is, whether a fragment is locked and whether a save is held, replacing the deprecated read-only `communityList$` and
  `CommunityListFactory`.
- `ConcordClient.communityListStatus$` and `ConcordCommunityListSync.status$` report whether the Community List is
  unknown, confirmed empty, partial or complete and whether a save is pending.
- Joins and leaves made while no relay has completed the Community List read, or while the newest fragment is locked,
  apply locally and are published once a read completes, through a bounded background retry or the next `start()`, so an
  offline device never overwrites another device's list.
- An exhausted Community List read retry is reported once as `duty-exhausted` and restarts on the next membership call,
  unlock, save, `start()`, relay-set change or another device's fragment, and a save interrupted by another device or a
  newer local change runs again on its own.
- Standalone `ConcordCommunityListSync` users get the same protection with `requireCompletedRead`, `beginRead()`,
  `markReadComplete(token)`, `clearReadEvidence()`, `unreceived` and `clearPending()`, and writes before a completed
  read reject with `CommunityListUnknownError`.
- `client.communityListSync.write()`, `repack()` and `receive()` run in turn with the client's other Community List
  work, and `write()` and `repack()` reject with `ConcordClientNotStartedError` or `ConcordClientDisposedError` when the
  client is not started or stops before they run.
- `ConcordClient` stores verified Community List fragments in `storage` under `concord:list-fragments:<pubkey>` and
  restores them, still locked, after a restart (reporting `fragment-restore` and `fragment-persist`), and
  `ConcordCommunityListSync` gains `restore()`, `locked`, `locked$` and the `persist` and `onDiagnostic` options.
- Community List repacks keep a complete list at every step and an interrupted repack is repaired later (reported as
  `community-list-repair` and `community-list-residue`), with `CommunityListFragments.residue`, `dormantResidue`,
  `duplicateResidue`, `documentAll` and `ConcordCommunityListSync.abandon()` for standalone use.
- List-level fields written by another client are kept on the first fragment and never copied onto others (reported as
  `fragment-extension-retained` while they cannot move yet), through `CommunityListFragments.strandedExtensionKeys` and
  an optional `scoped` parameter.
- `communityListDirty$` returns to `false` once a held save is published or the relay copy already matches, and with
  `autoSaveCommunityList` off a held join or leave is still published once the read completes or
  `unlockCommunityListFragments()` decrypts the fragments it waited for.
- Encrypted Community Lists carry complete key history and staff signing keys across devices, `mergeCommunities` picks
  between equal-epoch snapshots deterministically while keeping held staff keys, and standalone communities can persist
  new key material through `onMaterialChange` before it is used.
- Importing only `/operations` sets up Community List and Invite List encryption, so `modifyCommunityList` and
  `modifyInviteList` work without importing another barrel.
- Community Chat sends and timelines enforce disappearing-message timers with `setMessageExpiration` notices, judging
  each message by its own signed expiry, so a relay-facing expiration tag that was tampered with can neither hide nor
  keep a message.
- `wrapForTarget` and every community send keep the send time recorded when a message, membership event or snapshot is
  built, and rotations keep the time their rekey chunks were built, so quick successive sends keep their order, and a
  timed message whose timer ran out before its wrap was finished, even while a slow signer was answering, is refused
  with `MessageAlreadyExpiredError`.
- `MessageAlreadyExpiredError` is exported from the root and `/client` as well as `/helpers`, so apps can catch it from
  every send method with one `instanceof` check.
- `purgeExpiredMessages()` removes expired messages from every channel the community still lists, including persistent
  stores not opened this session, private channels you hold or left and older key epochs, and reports a store it could
  not sweep as `expiration-purge` while the rest still runs.
- `ConcordCommunity.schedulePurge()` and `ConcordClient.schedulePurge()` (with `ConcordPurgeScheduleOptions`) opt in to
  a periodic purge, every five minutes unless you pass `intervalMs`, that stops with `dispose()`, dissolution or its
  disposer, while the client schedule pauses on `stop()` and covers communities joined later.
- Opening a channel's rumor store deletes the expired messages your persistent store already held, while keeping
  deletion requests so deleted messages cannot come back.
- Pin proof helpers and the community `pinList()`, `pins()` and `setPins()` APIs verify pinned messages, enforce
  `PIN_MESSAGES` curator authority and keep public and private Pin Lists through control compaction.
- `ConcordCommunity.pins$(channelId, options)`, `pins()` and `ConcordPinsModel` list verified pins with the newest edit
  their author has not deleted, drop self-deleted pins, hide expired pins unless you pass `showExpired: true` and pins
  by banned authors unless you pass `showBanned: true`, show a message listed twice once, and return fresh objects on
  every read.
- `newestValidEdit`, `projectPins`, `verifiedPins` and `describePinList` in `/helpers` and the `VerifiedPin` fields
  `edited`, `behind`, `text` (required, so custom `verify` functions must set them) and `expiresAt` let custom renderers
  apply the same rules as `pins$`; republish `VerifiedPin.entry`, never the display-only `edit`.
- `setPins` publishes a channel's first Pin List once the community is live and no list can still verify, publishes each
  message once with its newest bundled edit, and otherwise rejects with `PinListNotReadyError` and a
  `PinListNotReadyReason` (`not-synced`, `suspended`, `unreadable`, `changed` or `unverified-edition`) instead of
  overwriting a list it cannot trust.
- With the `pinUpkeep` option (on by default) of `ConcordClient` and `ConcordCommunity`, `PIN_MESSAGES` holders
  automatically remove self-deleted pins, refresh pins to the newest author edit and re-seal a rekeyed private channel's
  Pin List, reporting skipped work as `pin-upkeep-skipped` on `diagnostics$`.
- Purging expired messages also removes expired pinned messages and their expired edits locally without publishing
  anything, so the pin stays hidden, though a pin whose list entry bundles only older text can show that text again.
- A dissolved community still accepts an author's deletion of their own pinned message, even one not stored locally,
  which hides the pin without publishing a Pin List or any other Control edition.
- `sendMessage()` takes a `subject` option (also inside an options object as the third argument) to send a titled forum
  post, `/helpers` adds `getSubject` (which also reads older kind 11 thread titles), `displaySubject`, `assertSubject`
  and `SUBJECT_MAX_BYTES`, and `/operations` adds `includeSubject`.
- `sendThread()` is deprecated and sends a titled chat message instead of a kind 11 thread so other CORD clients show
  your forum posts, keeps existing threads readable and rejects a title over 256 UTF-8 bytes with a `RangeError`.
- Channels from `channels$` have a `view` of `chat` or `forum` (`ChannelViewMode`, with `channelViewMode` in
  `/helpers`), `createChannel()` accepts `{ view }`, and `channels$` updates when a channel is renamed or changes view.
- `editMessage()` accepts the message itself as well as its id and marks the edit with the edited message's kind, as
  other CORD clients expect.
- `banMembers()` on a community and its `admin` bans several members in one Banlist edition, checks every target first
  and throws `BanMembersError` listing each refusal without publishing anything, and can also remove their access with a
  single Refounding.
- `ban()` and `unban()` run one at a time in call order and wait until a relay accepts the change, rejecting with
  `RequiredPublishError`, `BanlistRateLimitError`, `BanlistWriteBlockedError` or `BanlistHeadChangedError` when they
  cannot publish safely, and `unban()` refuses a member you do not outrank and throws a `TypeError` for an invalid key.
- A ban your client made that another admin's simultaneous edit wiped out is put back automatically, and `diagnostics$`
  reports a `BanlistReHealError` (stage `banlist-reheal`) when that cannot succeed.
- Staff admin actions are rejected unless the actor's current verified role, permissions and rank allow them, `ban()`
  rejects before publishing when the caller lacks `MANAGE_ROLES`, and `createInvite()` does when the caller lacks
  `CREATE_INVITE`.
- `ConcordCommunityAdmin.publishEdition` accepts an optional `EditionGuard` (`expectedHead`, `check`, `headChanged`,
  `chainOver`) so a publication can refuse to build on a head that moved.
- `classifyEditionLineage` (which walks up to `DEFAULT_EDITION_LINEAGE_DEPTH` versions) and `editionAdditions` in
  `/helpers` tell you whether your own control edition still leads to the current head or was displaced, and what an
  edition added, while `walkEditionChain()` returns a setting's checked version history.
- `RequiredPublishError` is the exported base class for publications that need at least one relay to accept them,
  carrying the failing `stage` and relay `responses`, and `InviteRevocationPublishError` extends it and is exported from
  `/client` and the root.
- New communities give members a read-only control key and reserve control signing for staff (`controlKeyFor`,
  `controlSignerGroupKey`), so `ConcordKeys.control` and `CommunityKeys.control` are read descriptors: read with
  `control.convKey` and check `control.signing` before signing control documents.
- Base rotations can upgrade older communities to separate member and staff keys while keeping history readable
  (`assertBaseRotationSupported`, `currentBaseRekeys`), and staff Grants deliver the control signing key through
  `encodeControlRootDelivery`, `decodeControlRootDelivery`, `isCurrentStaff`, `isStaffPermissionMask` and the new
  `PERM.PIN_MESSAGES` bit.
- `buildRefounding` requires the current verified community `state` and held control signing capability and its plan
  must be published and adopted in order, while `community.admin.refound()` resumes an interrupted Refounding when
  durable pending and membership storage is configured.
- `ConcordCommunity.discardPendingRefounding()` (also on `community.admin`) removes a stored Refounding that `refound()`
  refuses to finish, reports it as `refounding-discarded`, and is the way out when `banMembers({ refound: true })`
  refuses with `refounding-blocked`.
- `DissolutionFactory.create`, `.dissolution` and `setDissolution` require a community ID, and a validated dissolution
  stops subscriptions and writes and survives restarts while still allowing verified deletions of your own old messages,
  so owners must republish dissolutions made without a community ID.
- `decodeReceivedWrap` and `verifyReceiveEnvelope` let apps verify incoming events before storing them, invalid events
  are rejected before reaching any store, including custom stores, and sync accepts `controlVerification`,
  `controlHistory` and `SyncContext.onCancel`.
- `ConcordPrivateChannelOptions.onChannelInput` is an optional callback that receives every authenticated, unexpired
  channel input just before it is stored, and a callback that throws never stops the input from being stored.
- Envelope builders and readers enforce the CORD 65,535-byte plaintext limit at every layer, including rewraps, invites
  and self-encrypted list writes, and community sends and receives enforce the seal type each plane requires.
- `ConcordChatTimelineModel`, `community.channelTimeline` and a private channel's `timeline` give message timelines that
  update when bans or authority change, and channel stores keep deletion requests beside the original events, so render
  through these timelines rather than raw stores.
- Historical sync includes previously cached events, handles relays that cap results, time out or require
  authentication, reports an error when every relay fails (call `start()` again to retry) or a public channel cannot
  catch up, and opens live subscriptions only once it completes.
- Malformed or unauthorized control documents never crash community state or hide valid settings, circular role
  delegation grants nothing, revoked, banned or suspended staff cannot act through stale permissions, and removed roles,
  grants and bans stay removed.
- Key changes are saved before use and survive failed saves, disposal and concurrent updates, and one bad rotation
  message never blocks valid key updates.
- `sendMessage()` to an unknown channel fails before uploading any attachments.
- Receiving, syncing, key derivation and member-state updates reuse verified work and update incrementally, reducing
  signature checks, decryption and CPU use in busy communities.
- The library depends on stable Applesauce `^7` releases, so use stable Applesauce v7 packages alongside it.

### Fixed (patch)

- Concord now depends on applesauce 7.1 packages, and its models (`metadata$`, `channels$`, `roles$`, `members$`, chat
  timelines and pins) still update as soon as a rumor arrives instead of adopting 7.1's batched timeline updates.
- `decodeWrap`, `getWrapRumor` and `getSealRumor` now return `null` for a malformed rumor, so one bad guestbook entry
  can no longer stop a community from syncing its member list.
- `createChannel({ private: true })` and `leaveChannel()` now wait for `onMaterialChange` to save the key change and
  reject when it fails, and a failed save of keys received through a Direct Invite or dropped after a channel Rekey is
  reported on `diagnostics$` as `material-persist` instead of surfacing as an unhandled rejection.
- `admin.registerInviteLink()` and `admin.unregisterInviteLink()` now reject when your existing invite registry cannot
  be read, instead of publishing a registry that drops your earlier invite links.
- `ConcordClient` now applies channel keys from a Direct Invite that arrives before you join its community once you join
  it, instead of ignoring that invite.
- Overlapping `ConcordInviteManager.save()` calls, including those made by quick successive invite creations and
  revocations, now publish in order so relays keep your newest Invite List.

See the [admin](docs/guide/admin.md), [audio and video](docs/guide/audio-video.md), [client](docs/guide/client.md),
[messaging](docs/guide/messaging.md) and [storage](docs/guide/storage.md) guides for migration and durability
requirements.

## 0.1.0 (never published)

Prepared as the first JSR release of `@applesauce/concord`, a hard fork of the unreleased npm package
`applesauce-concord`, but never published, so the first published version is the baseline and includes these notes
together with the Unreleased entries above. The package version resets from the monorepo's `6.2.0` to `0.1.0`; the npm
name is retired. The earlier history below is retained for provenance, not a published npm upgrade path.

### Distribution

- Deno-native TypeScript published directly to JSR, with no build step or separate declaration output.
- Seven supported entrypoints: `@applesauce/concord` and `/helpers`, `/operations`, `/factories`, `/casts`, `/models`
  and `/client`. Replace wildcard/deep imports with these barrels.

### API changes

- Removed runtime exports `RotationCoordinator`, `shouldAdoptRotation` and `requireInviteRevocationAck`
  (`InviteRevocationPublishError` was restored before any publish and is exported from `/client` and the root; see
  Unreleased). Rotation types remain available; use `StreamSigners` for supported auth integration.
  `createUserAuthHandler`, `lookupRelayStatus` and `connectedRelays$` remain internal.
- Replaced ambient `User` getter augmentation with `ConcordCommunityListUser` and `ConcordInviteListUser` from
  `@applesauce/concord/casts`. Import that barrel at runtime to register the getters, then cast to the relevant
  interface or declare a local augmentation. Getter behavior is unchanged.
- Added named type exports for `ConcordRumorStore`, `ConcordStorage`, `ConcordStoreFactory`, `ConcordUploader`,
  `ConcordUploadProgress` and `ConcordUploadOptions` in `/client`, and `RuleKind`, `RuleForPresent`, `AssertNever` and
  `RuleTableKeysExactly` in `/helpers`. These add no runtime exports.

## 6.2.0

Initial release as a standalone package.
