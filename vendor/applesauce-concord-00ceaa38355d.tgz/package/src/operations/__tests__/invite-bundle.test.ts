import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { setInviteBundle, setRevocation } from "../invite-bundle.ts";
import { decryptBundle, INVITE_BUNDLE_KIND, newInviteToken } from "../../helpers/invite-bundle.ts";
import type { InviteBundle } from "../../types.ts";

const blank = (kind: number) => ({ kind, content: "", tags: [] as string[][], created_at: 0 });

describe("invite operations", () => {
  const bundle: InviteBundle = {
    community_id: "cid",
    owner: "owner",
    owner_salt: "salt",
    community_root: "root",
    root_epoch: 0,
    channels: [],
    relays: [],
    name: "N",
  };

  it("setInviteBundle encrypts the bundle and forces a single d='' tag", async () => {
    const token = newInviteToken();
    const draft = await setInviteBundle(bundle, token)({ ...blank(INVITE_BUNDLE_KIND), tags: [["d", "stale"]] });
    expect(draft.tags.filter((t) => t[0] === "d")).toEqual([["d", ""]]);
    expect(draft.tags).toContainEqual(["vsk", "6"]);
    expect(decryptBundle(draft.content, token).community_id).toBe("cid");
  });

  it("setRevocation writes an empty vsk 9 edition", async () => {
    const draft = await setRevocation()(blank(INVITE_BUNDLE_KIND));
    expect(draft.content).toBe("");
    expect(draft.tags).toContainEqual(["d", ""]);
    expect(draft.tags).toContainEqual(["vsk", "9"]);
  });
});
