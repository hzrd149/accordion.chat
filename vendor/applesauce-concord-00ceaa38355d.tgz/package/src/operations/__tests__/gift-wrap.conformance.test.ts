import { expect } from "@std/expect";
import { it } from "@std/testing/bdd";
import { spy } from "@std/testing/mock";
import { finalizeEvent, getEventHash, type NostrEvent } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { nip44 } from "applesauce-core/helpers/encryption";
import { setHiddenContentCache } from "applesauce-core/helpers";
import { PrivateKeySigner } from "applesauce-signers";
import { createCommunity } from "../../helpers/community.ts";
import { ENCRYPTED_SEAL_KIND, getSealRumor, getWrapSeal, PLAINTEXT_SEAL_KIND } from "../../helpers/gift-wrap.ts";
import { decryptBundle, encryptBundle } from "../../helpers/invite-bundle.ts";
import type { Rumor } from "../../types.ts";
import { rewrapSeal, sealRumor, wrapSeal } from "../gift-wrap.ts";
import { wrapDirectInvite } from "../direct-invite.ts";
import { modifyCommunityList } from "../community-list.ts";
import { modifyInviteList } from "../invite-list.ts";

const bytes = (value: string) => new TextEncoder().encode(value).length;
// Use astral Unicode so a UTF-16 length check would admit the invalid boundary.
const padding = (size: number) => "🦆".repeat(Math.floor(size / 4)) + "x".repeat(size % 4);
function sizedRumor(pubkey: string, size: number): Rumor {
  const rumor: Rumor = { kind: 9, created_at: 1, content: "", tags: [], pubkey, id: "0".repeat(64) };
  rumor.content = padding(size - bytes(JSON.stringify(rumor)));
  rumor.id = getEventHash(rumor);
  expect(bytes(JSON.stringify(rumor))).toBe(size);
  return rumor;
}
function sizedSeal(secret: Uint8Array, rumor: Rumor, size: number): NostrEvent {
  const template = {
    kind: PLAINTEXT_SEAL_KIND,
    created_at: 1,
    content: JSON.stringify(rumor),
    tags: [["padding", ""]],
  };
  const empty = finalizeEvent(template, secret);
  template.tags[0][1] = padding(size - bytes(JSON.stringify(empty)));
  const seal = finalizeEvent(template, secret);
  expect(bytes(JSON.stringify(seal))).toBe(size);
  return seal;
}

it("enforces 65535/65536 UTF-8 bytes on plaintext and encrypted rumor layers before signing", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const key = generateSecretKey();
  const signing = spy(signer, "signEvent");
  try {
    for (const plaintext of [true, false]) {
      const valid = sizedRumor(pubkey, 65535);
      const seal = await sealRumor(key, signer, { plaintext })(valid);
      expect(getSealRumor(seal, key)).toEqual(valid);
      const invalid = sizedRumor(pubkey, 65536);
      const before = signing.calls.length;
      await expect(sealRumor(key, signer, { plaintext })(invalid)).rejects.toThrow("65535-byte cap");
      expect(signing.calls.length).toBe(before);
      // Simulate a lenient dependency at the sender; the strict reader still refuses.
      const forged = await signer.signEvent({
        kind: plaintext ? PLAINTEXT_SEAL_KIND : ENCRYPTED_SEAL_KIND,
        created_at: 1,
        tags: [],
        content: plaintext ? JSON.stringify(invalid) : nip44.encrypt(JSON.stringify(invalid), key),
      });
      expect(getSealRumor(forged, key)).toBeNull();
    }
  } finally {
    signing.restore();
  }
});

it("enforces the serialized seal boundary for wraps, rewraps and strict readers", async () => {
  const secret = generateSecretKey();
  const signer = new PrivateKeySigner(secret);
  const pubkey = await signer.getPublicKey();
  const key = generateSecretKey();
  const stream = generateSecretKey();
  const rumor = sizedRumor(pubkey, 500);
  const valid = sizedSeal(secret, rumor, 65535);
  const invalid = sizedSeal(secret, rumor, 65536);
  const wrap = await wrapSeal(stream, key)(valid);
  expect(JSON.stringify(getWrapSeal(wrap, key))).toBe(JSON.stringify(valid));
  const rewrapped = rewrapSeal(valid, stream, key);
  expect(JSON.stringify(getWrapSeal(rewrapped, key))).toBe(JSON.stringify(valid));
  await expect(Promise.resolve().then(() => wrapSeal(stream, key)(invalid))).rejects.toThrow("65535-byte cap");
  expect(() => rewrapSeal(invalid, stream, key)).toThrow("65535-byte cap");
  const malicious = finalizeEvent({
    kind: 1059,
    created_at: 1,
    tags: [],
    content: nip44.encrypt(JSON.stringify(invalid), key),
  }, stream);
  expect(getWrapSeal(malicious, key)).toBeNull();
  const recipient = await new PrivateKeySigner(generateSecretKey()).getPublicKey();
  expect(await wrapDirectInvite(recipient)(valid)).toBeDefined();
  await expect(Promise.resolve().then(() => wrapDirectInvite(recipient)(invalid))).rejects.toThrow("65535-byte cap");
});

it("caps both self-encrypted list operation boundaries without shedding unknown fields", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  for (const kind of [13302, 13303]) {
    for (const size of [65535, 65536]) {
      const document = { entries: [], tombstones: [], padding: "" };
      document.padding = padding(size - bytes(JSON.stringify(document)));
      const draft = { kind, created_at: 1, content: "", tags: [] };
      setHiddenContentCache(draft, JSON.stringify(document));
      const operation = kind === 13302
        ? modifyCommunityList((communities, tombstones) => ({ communities, tombstones }), signer)
        : modifyInviteList((invites, tombstones) => ({ invites, tombstones }), signer);
      if (size === 65536) await expect(operation(draft)).rejects.toThrow("65535-byte cap");
      else {
        const event = await operation(draft);
        const plaintext = await signer.nip44.decrypt(pubkey, event.content);
        expect(plaintext).toBe(JSON.stringify(document));
        expect(bytes(plaintext)).toBe(65535);
      }
    }
  }
});

it("caps encrypted invite bundle plaintext on write and read", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const { material } = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "test", relays: [] });
  const token = generateSecretKey().slice(0, 16);
  const { buildInviteBundle } = await import("../../helpers/invite-bundle.ts");
  const { inviteBundleKey } = await import("../../helpers/crypto.ts");
  const base = buildInviteBundle(material);
  for (const size of [65535, 65536]) {
    const bundle = { ...base, relays: [""] };
    bundle.relays[0] = padding(size - bytes(JSON.stringify(bundle)));
    expect(bytes(JSON.stringify(bundle))).toBe(size);
    if (size === 65535) expect(decryptBundle(encryptBundle(bundle, token), token)).toEqual(bundle);
    else {
      expect(() => encryptBundle(bundle, token)).toThrow("65535-byte cap");
      const malicious = nip44.encrypt(JSON.stringify(bundle), inviteBundleKey(token));
      expect(() => decryptBundle(malicious, token)).toThrow("65535-byte cap");
    }
  }
});
