// CORD-03 §3 titled posts: `includeSubject` writes exactly one verbatim subject tag.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { includeSubject } from "../channel.ts";
import { includeEditTarget } from "../edit.ts";

describe("forum operations (CORD-03 §3)", () => {
  it("includeSubject sets exactly one subject tag and keeps the title verbatim", async () => {
    const draft = { kind: 9, content: "body", created_at: 1, tags: [["subject", "Old"], ["t", "keep"]] };
    const out = await includeSubject("  Title  ")(draft);
    const subjects = out.tags.filter((tag) => tag[0] === "subject");
    expect(subjects).toEqual([["subject", "  Title  "]]);
    expect(out.tags.some((tag) => tag[0] === "t" && tag[1] === "keep")).toBe(true);
    expect(out.kind).toBe(9);
    expect(out.content).toBe("body");
  });

  it("includeEditTarget adds a k tag only when the target kind is known (D-07)", async () => {
    const draft = { kind: 3302, content: "x", created_at: 1, tags: [] as string[][] };
    const bare = await includeEditTarget("target")(draft);
    expect(bare.tags).toContainEqual(["e", "target"]);
    expect(bare.tags.some((tag) => tag[0] === "k")).toBe(false);

    const typed = await includeEditTarget("target", 9)(draft);
    expect(typed.tags).toContainEqual(["e", "target"]);
    expect(typed.tags.filter((tag) => tag[0] === "k")).toEqual([["k", "9"]]);

    const reply = await includeEditTarget("target", 1111)(draft);
    expect(reply.tags.filter((tag) => tag[0] === "k")).toEqual([["k", "1111"]]);

    // A kind that is not a non-negative safe integer adds no k tag.
    for (const kind of [-1, 1.5, Number.NaN, Number.POSITIVE_INFINITY, 2 ** 53]) {
      const out = await includeEditTarget("target", kind)(draft);
      expect(out.tags.some((tag) => tag[0] === "k")).toBe(false);
    }
  });
});
