import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { buildRekeyRumors, REKEY_BLOBS_PER_EVENT, REKEY_KIND } from "../../helpers/rekey.ts";
import { includeRekeyChunk } from "../rekey.ts";

const blank = (kind: number) => ({ kind, content: "", tags: [] as string[][], created_at: 0 });

describe("rekey operations", () => {
  it("includeRekeyChunk writes blobs + rotation tags", async () => {
    const draft = await includeRekeyChunk(
      { scope: { kind: "root" }, newEpoch: 3n, prevEpoch: 2n, prevCommit: "cc" },
      [{ locator: "l", wrapped: "w" }],
      1,
      1,
    )(blank(REKEY_KIND));
    expect(JSON.parse(draft.content)).toEqual([{ locator: "l", wrapped: "w" }]);
    expect(draft.tags).toContainEqual(["newepoch", "3"]);
    expect(draft.tags).toContainEqual(["prevepoch", "2"]);
    expect(draft.tags).toContainEqual(["chunk", "1", "1"]);
  });

  it("includeRekeyChunk stamps created_at and ms from one clock read (CORD-06 §1, D-13)", async () => {
    const rotation = { scope: { kind: "root" as const }, newEpoch: 3n, prevEpoch: 2n, prevCommit: "cc" };
    const at = 1_700_000_000_788;
    const draft = await includeRekeyChunk(rotation, [], 1, 2, at)({ ...blank(REKEY_KIND), created_at: 5 });
    expect(draft.created_at).toBe(1_700_000_000);
    expect(draft.tags).toContainEqual(["ms", "788"]);

    const blobs = Array.from({ length: REKEY_BLOBS_PER_EVENT + 1 }, (_, i) => ({ locator: `l${i}`, wrapped: "w" }));
    const chunks = await Promise.all(buildRekeyRumors(rotation, blobs, at));
    expect(chunks).toHaveLength(2);
    for (const chunk of chunks) {
      expect(chunk.created_at).toBe(1_700_000_000);
      expect(chunk.tags).toContainEqual(["ms", "788"]);
    }
  });
});
