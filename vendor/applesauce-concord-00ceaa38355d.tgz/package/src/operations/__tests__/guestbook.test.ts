import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { JOIN_LEAVE_KIND, KICK_KIND, SNAPSHOT_KIND } from "../../helpers/guestbook.ts";
import { includeInviteAttribution, includeKickTarget, includeSnapshotChunk, setJoinLeave } from "../guestbook.ts";

const blank = (kind: number) => ({ kind, content: "", tags: [] as string[][], created_at: 0 });

describe("guestbook operations", () => {
  it("setJoinLeave sets the verb as content", async () => {
    expect((await setJoinLeave("join")(blank(JOIN_LEAVE_KIND))).content).toBe("join");
    expect((await setJoinLeave("leave")(blank(JOIN_LEAVE_KIND))).content).toBe("leave");
  });

  it("includeInviteAttribution and includeKickTarget add their tags", async () => {
    const join = await includeInviteAttribution("creator", "label")(blank(JOIN_LEAVE_KIND));
    expect(join.tags).toContainEqual(["invite", "creator", "label"]);
    const kick = await includeKickTarget("member", ["eid", "1", "hash"])(blank(KICK_KIND));
    expect(kick.tags).toContainEqual(["p", "member"]);
    expect(kick.tags).toContainEqual(["vac", "eid", "1", "hash"]);
  });

  it("includeSnapshotChunk sets members + snap tag", async () => {
    const snap = await includeSnapshotChunk(["a", "b"], "snapid", 1, 2, { created_at: 12, ms: 500 })(
      blank(SNAPSHOT_KIND),
    );
    expect(JSON.parse(snap.content)).toEqual(["a", "b"]);
    expect(snap.tags).toContainEqual(["snap", "snapid", "1", "2"]);
  });
});
