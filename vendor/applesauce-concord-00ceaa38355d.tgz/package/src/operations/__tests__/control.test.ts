import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { CONTROL_KIND } from "../../helpers/control.ts";
import { includeEdition, setDissolution } from "../control.ts";

const blank = (kind: number) => ({ kind, content: "", tags: [] as string[][], created_at: 0 });

describe("control operations", () => {
  it("includeEdition writes the edition machinery + content", async () => {
    const draft = await includeEdition({
      vsk: 0,
      eid: "eid",
      version: 2,
      prevHash: "prev",
      content: "{}",
      vac: ["e", "1", "h"],
    })(blank(CONTROL_KIND));
    expect(draft.content).toBe("{}");
    expect(draft.tags).toContainEqual(["vsk", "0"]);
    expect(draft.tags).toContainEqual(["eid", "eid"]);
    expect(draft.tags).toContainEqual(["ev", "2"]);
    expect(draft.tags).toContainEqual(["ep", "prev"]);
    expect(draft.tags).toContainEqual(["vac", "e", "1", "h"]);
  });

  it("setDissolution writes the vsk 10 tombstone", async () => {
    const draft = await setDissolution("ab".repeat(32))(blank(CONTROL_KIND));
    expect(draft.tags).toContainEqual(["vsk", "10"]);
    expect(draft.tags).toContainEqual(["eid", "ab".repeat(32)]);
  });
});
