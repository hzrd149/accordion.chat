// Chat Plane edit rumor operation (CORD-03 §3). A kind 3302 edit replaces a
// message's content and points at the message it replaces with an `e` tag, plus a
// `k` tag naming the target's kind when it is known. Receivers never require `k`.
//
// This is a composable EventOperation that mutates a draft's public tags via
// applesauce's tag operations; the EditFactory in ../factories/edit.ts chains it
// onto a blank rumor template.

import type { EventOperation } from "applesauce-core/factories";
import { modifyPublicTags } from "applesauce-core/operations";
import { addEventPointerTag, setSingletonTag } from "applesauce-core/operations/tag/common";

/**
 * Add the `e` tag pointing an edit at the message it replaces and, when `kind` is a non-negative safe integer, the
 * `["k", kind]` tag naming that message's kind (CORD-03 §3: 9, 1111, or 11 for a legacy thread root). Without a known
 * kind no `k` tag is added; receivers never require it.
 */
export function includeEditTarget(id: string, kind?: number): EventOperation {
  const target = addEventPointerTag(id, undefined, false);
  return Number.isSafeInteger(kind) && kind! >= 0
    ? modifyPublicTags(target, setSingletonTag(["k", String(kind)]))
    : modifyPublicTags(target);
}
