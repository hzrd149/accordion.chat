// CORD-02 §8 Community List mutations: decrypt current content, merge by
// community_id, and re-encrypt to self while preserving unknown fields (§6).

import { assertEnvelopeCap } from "../helpers/caps.ts";
import type { EventOperation, EventSigner } from "applesauce-core/factories";
import { getHiddenContent, getHiddenContentEncryptionMethods } from "applesauce-core/helpers";
import { setHiddenContent } from "applesauce-core/operations/hidden-content";
// Side effect: registers kinds 13302/13303 as NIP-44 hidden content so these operations
// work when `/operations` is the only barrel imported.
import "../helpers/register.ts";
import { mergeCommunities, mergeCommunityTombstones, parseCommunityList } from "../helpers/community-list.ts";
import type { CommunityListCommunity, CommunityTombstone, JoinMaterial } from "../types.ts";

/** A community_id-keyed merge over the current communities and tombstones. */
export type CommunityListOperation = (
  communities: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
) => { communities: CommunityListCommunity[]; tombstones: CommunityTombstone[] };

/**
 * Join or refresh a membership by merging it into the communities (community_id-keyed,
 * resurrects a re-joined tombstoned id — CORD-02 §8).
 */
export function joinCommunity(community: CommunityListCommunity): CommunityListOperation {
  return (communities, tombstones) => ({ communities: mergeCommunities(communities, [community]), tombstones });
}

/**
 * Leave a community by unioning in a tombstone (keeping the newest removal). The
 * entry stays in the document and a later join can still resurrect it (CORD-02 §8).
 */
export function leaveCommunity(communityId: string, removedAt: number = Date.now()): CommunityListOperation {
  return (communities, tombstones) => ({
    communities,
    tombstones: mergeCommunityTombstones(tombstones, [{ community_id: communityId, removed_at: removedAt }]),
  });
}

/**
 * Replace a membership's `current` snapshot in place (an authoritative local
 * refresh — a caught-up rename or a channel-key addition). Bypasses the
 * epoch-keyed `freshest` so a same-epoch update can't lose the canonical-bytes
 * tiebreak. Absent memberships are left untouched.
 */
export function refreshCommunity(current: JoinMaterial): CommunityListOperation {
  return (communities, tombstones) => {
    const idx = (communities ?? []).findIndex((e) => e.community_id === current.community_id);
    if (idx === -1) return { communities, tombstones };
    return { communities: communities.map((e, i) => (i === idx ? { ...e, current } : e)), tombstones };
  };
}

/**
 * Decrypt the current self-encrypted community list, apply a community list
 * operation, and re-encrypt it to self. On an empty draft (a fresh list) the
 * operation receives empty arrays; on an existing event the prior contents are
 * read from the plaintext cached on the draft, falling back to a decrypt with the
 * author's own pubkey.
 */
export function modifyCommunityList(apply: CommunityListOperation, signer?: EventSigner): EventOperation {
  return async (draft) => {
    if (!signer) throw new Error("Signer required to encrypt the community list");

    // Prefer the plaintext cached on the draft (carried across chained
    // mutations), otherwise decrypt the existing content with our own pubkey (the
    // draft template carries no pubkey, so we derive it from the signer).
    let json = getHiddenContent(draft);
    if (json === undefined && draft.content) {
      const { decrypt } = getHiddenContentEncryptionMethods(draft.kind, signer);
      json = await decrypt(await signer.getPublicKey(), draft.content);
    }

    const parsed = parseCommunityList(json);
    const next = apply(parsed.entries, parsed.tombstones);
    // Spread first to preserve unknown fields; updated arrays must override the snapshot.
    const document = JSON.stringify({ ...parsed, entries: next.communities, tombstones: next.tombstones });
    assertEnvelopeCap(document);
    return setHiddenContent(document, signer)(draft);
  };
}
