// CORD-08 §§1–4: signed Chat expiration is authoritative; outer tags are relay hints.
import type { RumorTemplate } from "../types.ts";

/** Informational Chat timer notice kind (CORD-08 §4). */
export const TIMER_NOTICE_KIND = 1740;

/** Read the community timer; malformed, absent and zero values disable expiration. */
export function messageExpiration(value: unknown): number {
  return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : 0;
}

/** Expiration in Unix seconds, ignoring malformed tags and permanent Chat tombstones/notices. */
export function rumorExpiration(rumor: { kind: number; tags: string[][] }): number | undefined {
  if (rumor.kind === 5 || rumor.kind === TIMER_NOTICE_KIND || (rumor.kind >= 20000 && rumor.kind < 30000)) {
    return undefined;
  }
  const tag = rumor.tags.find((tag) => tag[0] === "expiration");
  if (!tag || tag.length !== 2 || !/^(0|[1-9][0-9]*)$/.test(tag[1])) return undefined;
  const seconds = Number(tag[1]);
  return Number.isSafeInteger(seconds) ? seconds : undefined;
}

/** Whether a signed rumor has expired at this Unix-second clock reading. */
export function isRumorExpired(rumor: { kind: number; tags: string[][] }, now: number = Date.now() / 1000): boolean {
  const expiration = rumorExpiration(rumor);
  return expiration !== undefined && expiration <= now;
}

/** Stamp a durable Chat draft using its final timestamp, removing caller-supplied expiration. */
export function stampMessageExpiration(
  rumor: RumorTemplate,
  timer: unknown,
  ephemeral = false,
): RumorTemplate & { created_at: number } {
  const tags = rumor.tags.filter((tag) => tag[0] !== "expiration");
  const seconds = messageExpiration(timer);
  const createdAt = rumor.created_at;
  if (createdAt === undefined) throw new Error("Expiration stamping requires the final created_at");
  if (
    !ephemeral && seconds && rumor.kind !== 5 && rumor.kind !== TIMER_NOTICE_KIND &&
    !(rumor.kind >= 20000 && rumor.kind < 30000)
  ) {
    const expiration = createdAt + seconds;
    if (!Number.isSafeInteger(expiration)) throw new Error("Message expiration exceeds safe integer range");
    tags.push(["expiration", String(expiration)]);
  }
  return { ...rumor, tags, created_at: createdAt };
}

/**
 * Thrown by `wrapForTarget` instead of publishing a durable Chat message whose
 * signed expiration (kept send time plus the community timer, CORD-08 §2) has
 * already passed before signing or by the time the envelope is finished. Nothing was sent.
 */
export class MessageAlreadyExpiredError extends Error {
  /** The Unix-second expiration the message would have carried. */
  readonly expiration: number;

  /**
   * Builds the error for a message whose timer ran out before its wrap was finished.
   *
   * @param expiration the Unix-second expiration the message would have carried
   */
  constructor(expiration: number) {
    super("message already expired before it could be published");
    this.name = "MessageAlreadyExpiredError";
    this.expiration = expiration;
  }
}
