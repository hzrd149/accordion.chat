// CORD-04 §7: per-message disclosure proves ciphertext without revealing a channel key.
import { equalBytes } from "@noble/ciphers/utils.js";
import { chacha20 } from "@noble/ciphers/chacha.js";
import { expand } from "@noble/hashes/hkdf.js";
import { hmac } from "@noble/hashes/hmac.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, concatBytes, hexToBytes } from "@noble/hashes/utils.js";
import { base64 } from "@scure/base";
import { nip44 } from "applesauce-core/helpers/encryption";
import { getEventHash, type NostrEvent, type Rumor, verifyWrappedEvent } from "applesauce-core/helpers/event";
import { rumorExpiration } from "./expiration.ts";

/** Maximum number of entries in an opened Pin List (CORD-04 §7). */
export const PIN_LIST_MAX_ENTRIES = 25;
/** Maximum bytes of the exact carried edition content, including a sealed envelope. */
export const PIN_LIST_MAX_BYTES = 32_768;

/** Original signed encrypted seal and its per-message NIP-44 expansion. */
export interface PinProof {
  /** Original kind-20013 event; its ciphertext string is never reserialized. */
  seal: NostrEvent;
  /** 76 disclosed bytes as lowercase hex, revealing this message alone. */
  keys: string;
}
/** A message proof with optional context hint and independently proven edit. */
export interface PinEntry extends PinProof {
  /** Untrusted outer wrap locator hint. */
  wrap?: string;
  /** Optional newest proven Edit. */
  edit?: PinProof;
}
/** Verified original and optional author-matched edit, identified by recomputed rumor ids. */
export interface VerifiedPin {
  /** Proven original message. */
  rumor: Rumor;
  /**
   * The newest applicable Edit, for display only: the proven bundled Edit, or a newer locally known author-valid Edit
   * from the channel; never an Edit its author deleted (D-31). It is never proof bytes; only `entry` is republished.
   */
  edit?: Rumor;
  /** Original proof bytes, exactly as carried by the list, for safe list republication. */
  entry: PinEntry;
  /** Whether `text` comes from an Edit rather than the original message. */
  edited: boolean;
  /**
   * Whether the shown Edit differs from the one bundled in `entry`: a newer local Edit is shown, or the bundled Edit
   * was deleted by its author (a refresh candidate).
   */
  behind: boolean;
  /** The text to show: the content of `edit` when edited, otherwise of `rumor`. */
  text: string;
  /** Unix-second expiration: the earliest of the original's and of the shown Edit's expiration tags (CORD-08). */
  expiresAt?: number;
}
/** Readable lists distinguish an unavailable key/head from an empty list. */
export type PinListRead = { available: true; entries: PinEntry[] } | { available: false };

/** Produce a disclosure from an original seal using a held epoch conversation key. */
export function createPinProof(seal: NostrEvent, conversationKey: Uint8Array): PinProof {
  if (seal.kind !== 20013 || !verifyWrappedEvent(structuredClone(seal))) throw new Error("Invalid pin seal");
  const payload = base64.decode(seal.content);
  if (payload.length < 99 || payload[0] !== 2) throw new Error("Invalid pin payload");
  // Verify possession before disclosing; wrong keys must never produce publishable garbage.
  nip44.decrypt(seal.content, conversationKey);
  return {
    seal: structuredClone(seal),
    keys: bytesToHex(expand(sha256, conversationKey, payload.subarray(1, 33), 76)),
  };
}

function openProof(proof: PinProof, channelId: string, kinds: number[]): Rumor | undefined {
  try {
    if (!proof || !/^[0-9a-f]{152}$/.test(proof.keys)) return undefined;
    const seal = structuredClone(proof.seal);
    if (seal.kind !== 20013 || !verifyWrappedEvent(seal)) return undefined;
    const payload = base64.decode(seal.content);
    if (payload[0] !== 2 || payload.length < 99) return undefined;
    const keys = hexToBytes(proof.keys);
    const nonce = payload.subarray(1, 33), ciphertext = payload.subarray(33, -32), mac = payload.subarray(-32);
    if (!equalBytes(hmac(sha256, keys.subarray(44), concatBytes(nonce, ciphertext)), mac)) return undefined;
    const padded = chacha20(keys.subarray(0, 32), keys.subarray(32, 44), ciphertext);
    const rumor = JSON.parse(nip44.v2.utils.unpad(padded)) as Rumor;
    if (
      rumor.pubkey !== seal.pubkey || !kinds.includes(rumor.kind) ||
      !Array.isArray(rumor.tags) || !rumor.tags.every((t) =>
        Array.isArray(t) && t.every((v) => typeof v === "string")
      ) ||
      rumor.tags.find((t) => t[0] === "channel")?.[1] !== channelId
    ) return undefined;
    return { ...rumor, id: getEventHash(rumor) };
  } catch {
    return undefined;
  }
}

/** Verify an entry independently of channel secrets; invalid proofs never abort a list. */
export function verifyPinEntry(entry: PinEntry, channelId: string): VerifiedPin | undefined {
  const rumor = openProof(entry, channelId, [9, 1111]);
  if (!rumor) return undefined;
  const opened = entry.edit && openProof(entry.edit, channelId, [3302]);
  const edit = opened && opened.pubkey === rumor.pubkey && opened.tags.find((t) => t[0] === "e")?.[1] === rumor.id
    ? opened
    : undefined;
  const expirations = [rumorExpiration(rumor), edit && rumorExpiration(edit)].filter((v) => v !== undefined);
  return {
    rumor,
    entry: structuredClone(entry),
    ...(edit ? { edit } : {}),
    edited: edit !== undefined,
    behind: false,
    text: (edit ?? rumor).content,
    ...(expirations.length ? { expiresAt: Math.min(...expirations) } : {}),
  };
}

/** Open either Pin List form, regardless of the current channel type; caps mean empty, never a rejected edition. */
export function readPinList(
  content: string | undefined,
  keyForEpoch?: (epoch: string) => Uint8Array | undefined,
): PinListRead {
  if (content === undefined) return { available: false };
  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };
  try {
    let body = JSON.parse(content);
    if (typeof body?.sealed === "string") {
      if (
        typeof body.epoch !== "string" || !/^(0|[1-9][0-9]*)$/.test(body.epoch) ||
        BigInt(body.epoch) > 0xffffffffffffffffn
      ) return { available: true, entries: [] };
      const key = keyForEpoch?.(body.epoch);
      if (!key) return { available: false };
      body = JSON.parse(nip44.decrypt(body.sealed, key));
    }
    if (!Array.isArray(body?.entries) || body.entries.length > PIN_LIST_MAX_ENTRIES) {
      return { available: true, entries: [] };
    }
    return { available: true, entries: body.entries };
  } catch {
    return { available: false };
  }
}

/** Which form a Pin List edition's content carries; `"invalid"` is anything {@link describePinList} cannot classify. */
export type PinListForm = { form: "public" } | { form: "sealed"; epoch: string } | { form: "invalid" };

/**
 * Classify a Pin List edition's content without opening it (CORD-04 §7: a list is either the plaintext entries
 * document of a public channel or a sealed envelope of a private era). Total: never throws.
 */
export function describePinList(content: string | undefined): PinListForm {
  if (content === undefined) return { form: "invalid" };
  try {
    const body = JSON.parse(content);
    if (typeof body?.sealed === "string") {
      return typeof body.epoch === "string" && /^(0|[1-9][0-9]*)$/.test(body.epoch) &&
          BigInt(body.epoch) <= 0xffffffffffffffffn
        ? { form: "sealed", epoch: body.epoch }
        : { form: "invalid" };
    }
    return Array.isArray(body?.entries) ? { form: "public" } : { form: "invalid" };
  } catch {
    return { form: "invalid" };
  }
}

/** Serialize a curator's readable list using its folded channel type, preserving the supplied proof bundles. */
export function encodePinList(entries: PinEntry[], privateKey?: { epoch: number; convKey: Uint8Array }): string {
  if (entries.length > PIN_LIST_MAX_ENTRIES) throw new Error("Pin List has too many entries");
  const plaintext = JSON.stringify({ entries });
  const content = privateKey
    ? JSON.stringify({ epoch: String(privateKey.epoch), sealed: nip44.encrypt(plaintext, privateKey.convKey) })
    : plaintext;
  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) {
    throw new Error("Pin List exceeds content ceiling");
  }
  return content;
}
