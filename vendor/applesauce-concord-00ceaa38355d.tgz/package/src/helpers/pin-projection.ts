// CORD-04 §7: pin display. A pin's proof bundle is the only republishable truth; what a reader sees is projected
// from it plus the channel's own Edits and deletions. CORD-08 §3: expiry is a reader-side display rule only.
import type { Rumor } from "applesauce-core/helpers/event";
import { EDIT_KIND, newestValidEdit } from "./edit.ts";
import { isRumorExpired, rumorExpiration } from "./expiration.ts";
import { collapsePinEntries, isSelfDeleted } from "./pin-upkeep.ts";
import { type PinEntry, type PinListRead, type VerifiedPin, verifyPinEntry } from "./pins.ts";

/** Inputs for {@link projectPins}; everything but the list is optional so a keyless reader can project too. */
export interface PinProjectionInputs {
  /** Channel rumors to read: kind 5 deletions (of messages and of Edits) and kind 3302 Edits. Other kinds are ignored. */
  rumors?: readonly Rumor[];
  /** Unix-second clock. When omitted nothing is treated as expired. */
  now?: number;
  /** Include expired pins instead of hiding them (DEC-01). */
  showExpired?: boolean;
  /**
   * Returns true for a banned author. Their local Edits are ignored (bundled proof Edits are independent of bans) and,
   * unless `showBanned` is set, a pin whose proven message author is banned is hidden (CORD-04 §7 moderation
   * suppression). Without it nothing is suppressed.
   */
  isBanned?: (pubkey: string) => boolean;
  /** Include pins whose proven author is banned instead of hiding them. Default false. */
  showBanned?: boolean;
  /** Entry verifier, for callers that cache verification; results are never mutated. Defaults to `verifyPinEntry`. */
  verify?: (entry: PinEntry, channelId: string) => VerifiedPin | undefined;
}

/**
 * Project a Pin List into the pins a reader should see. Entries are verified one at a time (invalid ones are dropped),
 * deduplicated by recomputed rumor id, keeping the first position and the copy whose bundled Edit is newest (D-32; an
 * Edit its own author deleted never counts as newest), hidden when the proven author deleted the message, show the
 * newest author-valid Edit (bundled or local) as `text`, never show an Edit its own author deleted (the pin falls back
 * to the newest undeleted Edit or the original, D-31), are hidden when their proven author is banned unless
 * `showBanned` is set (CORD-04 §7, a reader-side view that never changes the list), and are hidden when expired unless
 * `showExpired` is set. Expiry
 * never removes the newest known Edit from display: when it or the original is expired the whole pin is expired, so
 * older text is never presented as current. `entry` stays the original bundle verbatim. Total: malformed input never
 * throws.
 */
export function projectPins(list: PinListRead, channelId: string, inputs: PinProjectionInputs = {}): VerifiedPin[] {
  const pins: VerifiedPin[] = [];
  if (!list.available) return [];
  const rumors = inputs.rumors ?? [];
  const edits = rumors.filter((r) => r.kind === EDIT_KIND);
  const verify = inputs.verify ?? verifyPinEntry;
  const { now } = inputs;
  for (const { pin: verified } of collapsePinEntries(list.entries, channelId, { rumors, verify })) {
    if (isSelfDeleted(verified, rumors)) continue;
    if (inputs.isBanned?.(verified.rumor.pubkey) && !inputs.showBanned) continue;
    const bundled = verified.edit;
    // Expiry is deliberately not passed: the newest Edit is chosen even when expired (D-11).
    const local = newestValidEdit(verified.rumor, edits, { channelId, isBanned: inputs.isBanned, deletions: rumors });
    const applied = newestValidEdit(verified.rumor, [bundled, local].filter((e) => e !== undefined), {
      channelId,
      deletions: rumors,
    });
    const expired = now !== undefined &&
      (isRumorExpired(verified.rumor, now) || (applied && isRumorExpired(applied, now)));
    if (expired && !inputs.showExpired) continue;
    const expirations = [rumorExpiration(verified.rumor), applied && rumorExpiration(applied)].filter((v) =>
      v !== undefined
    );
    const { edit: _edit, expiresAt: _expiresAt, ...rest } = verified;
    pins.push({
      ...rest,
      ...(applied ? { edit: applied } : {}),
      text: applied?.content ?? verified.rumor.content,
      edited: applied !== undefined,
      behind: applied?.id !== bundled?.id,
      ...(expirations.length ? { expiresAt: Math.min(...expirations) } : {}),
    });
  }
  return pins;
}

/** Verify and deduplicate entries, honoring proven-author self-deletions locally. */
export function verifiedPins(list: PinListRead, channelId: string, deletions: Rumor[] = []): VerifiedPin[] {
  return projectPins(list, channelId, { rumors: deletions.filter((d) => d.kind === 5), showExpired: true });
}
