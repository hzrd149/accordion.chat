// Internal pure module for pin write decisions; deliberately not exported from the helpers barrel (like
// authority-support.ts). CORD-04 §7: a reader treats a Pin List it cannot open as unavailable, and a writer MUST NOT
// build a replacement from a list it could not read, so a first version is only written once the entity is proven
// absent. CORD-04 §1: an entity's head is the verified edition chain; an unresolved chain, pending evidence or a
// suspension is not absence, and a version only ever climbs. CORD-04 §5: an edition whose cited Grant resolved but
// whose author current standing rejects is dropped, so it blocks nothing and a new head chains over it. CORD-04 §7 (Interaction with deletion): a Pin List that still carries a message its author
// deleted is stale, so a curator republishes it without that entry; the planner below decides that rewrite purely from
// verified state and never from the clock. CORD-04 §7 (Edits): an entry whose message has a newer Edit is refreshed with
// that Edit's own proof bundle and in no other form; the only clock input is the expiry check that keeps expired text
// out of a bundle; library rule D-31 adds that an Edit its own author deleted is never bundled and a bundled one is
// replaced or removed. CORD-04 §7 (Private rekey): after a private rekey a holder MAY, and a Rotator SHOULD, republish the
// readable list under the current key, carrying every proof bundle unchanged.
import { hexToBytes } from "@noble/hashes/utils.js";

import type {
  CommunityState,
  ConcordSyncPhase,
  ControlVerification,
  DecodedEvent,
  Rumor,
  VerifiedControlHead,
} from "../types.ts";
import { PERM, VSK } from "../types.ts";
import { isAuthorDeleted } from "./author-deletion.ts";
import { grantLocator } from "./crypto.ts";
import { EDIT_KIND, newestValidEdit } from "./edit.ts";
import { computeEditionHash, resolveEditionPin } from "./editions.ts";
import { isRumorExpired } from "./expiration.ts";
import { vacVerifier } from "./permissions.ts";
import type { PinEntry, PinListForm, PinListRead, PinProof, VerifiedPin } from "./pins.ts";
import { verifyPinEntry } from "./pins.ts";

/** What {@link pinWriteReadiness} needs to decide whether a Pin List write may be planned now. */
export interface PinWriteReadinessInput {
  /** The community sync phase; only `"live"` proves the Control Plane reads completed. */
  phase: ConcordSyncPhase;
  /** The Pin List coordinate being written. */
  eid: string;
  /** The verified control projection, when the fold has produced one. */
  verification?: ControlVerification;
  /** Selected display heads, which may exist without verified support. */
  displayHeads?: Map<string, DecodedEvent>;
  /**
   * Whether a retained kind-3308 edition names the coordinate, verified or not. The caller leaves out editions that can
   * never verify ({@link canEditionEverVerify}, D-33) and editions current standing rejects
   * ({@link isEditionRejectedByStanding}, D-34).
   */
  retained: (eid: string) => boolean;
  /** Whether the verified head's list can be opened with the keys held. */
  listAvailable: boolean;
}

/**
 * The outcome of {@link pinWriteReadiness}. `ready` with a `head` means replace that head; `ready` without one means
 * no edition at the coordinate can still verify, so a first head may be written: version 1, or the version after the
 * edition {@link rejectedChainBase} names (D-34).
 */
export type PinWriteReadiness =
  | { ready: true; head?: VerifiedControlHead }
  | { ready: false; reason: "not-synced" | "suspended" | "unreadable" | "unverified-edition" };

/**
 * Decide whether a Pin List write may be planned: it needs a live community, no suspension, and either a readable
 * verified head to replace or a proven absence (no verified head, display head, pending chain evidence or retained
 * edition that could still verify). While live, a coordinate blocked only by such an unverified edition reports
 * `"unverified-edition"` rather than `"not-synced"`, because waiting for sync will not clear it (D-33). Total: never
 * throws.
 */
export function pinWriteReadiness(input: PinWriteReadinessInput): PinWriteReadiness {
  if (input.phase !== "live") return { ready: false, reason: "not-synced" };
  const verification = input.verification;
  if (verification?.suspended.has(input.eid)) return { ready: false, reason: "suspended" };
  const head = verification?.heads.get(input.eid);
  if (head) {
    return head.vsk === VSK.PINS && input.listAvailable
      ? { ready: true, head }
      : { ready: false, reason: "unreadable" };
  }
  if (!verification) return { ready: false, reason: "not-synced" };
  // CORD-04 §1: an unresolved chain is not absence. `missing-pin` and `pin-mismatch` evidence is filed under the cited
  // Grant coordinate, never the Pin List's own, so only chain evidence about this coordinate counts here.
  if (
    input.displayHeads?.has(input.eid) ||
    verification.pending.some((evidence) =>
      evidence.eid === input.eid && (evidence.reason === "chain-gap" || evidence.reason === "support-cycle")
    ) ||
    input.retained(input.eid)
  ) {
    return { ready: false, reason: "unverified-edition" };
  }
  return { ready: true };
}

/**
 * Whether a retained Control edition could ever verify, judged from the edition alone (D-33). CORD-04 §5: a non-owner
 * edition is authorized only through its first `vac` tag, an exact `[grant coordinate, version, edition_hash]` citation
 * of its author's own Grant edition; the owner needs none, and the fold ignores one it carries. A non-owner edition
 * with no `vac` tag, a malformed one, or one citing any coordinate other than the author's own Grant can never verify
 * whatever later syncs, so it is not evidence that the entity exists. Every other edition may still verify, for example
 * once its Grant syncs. Total: never throws; an edition it cannot judge counts as one that may verify.
 */
export function canEditionEverVerify(edition: DecodedEvent, owner: string, communityId: string): boolean {
  try {
    if (edition.author === owner) return true;
    const tag = edition.rumor.tags.find((t) => t[0] === "vac");
    if (tag?.length !== 4) return false;
    const [, eid, version, hash] = tag;
    if (resolveEditionPin([], [eid, version, hash]).kind === "malformed") return false;
    // The fold matches the citation byte for byte against the author's own lowercase Grant coordinate and hash.
    return /^[0-9a-f]{64}$/.test(hash) && eid === grantLocator(hexToBytes(communityId), edition.author);
  } catch {
    return true;
  }
}

/**
 * Whether current standing already rejects a retained non-owner Pin List edition (D-34). CORD-04 §5: a `vac` citation
 * is a sync floor, not the verdict; once the reader holds the cited Grant edition it judges the actor against its
 * current roster, and a banned or demoted actor's edition is dropped, never grandfathered by its old citation. So an
 * edition whose exact citation resolves in the fold's Grant history while its author is banned or lacks
 * `PIN_MESSAGES` cannot verify on this roster, and is no evidence that blocks a new head. Only a citation that has not
 * resolved (an unsynced or mismatched Grant), or an author whose Grant or Roles are suspended, may still verify.
 * Total: never throws; an edition it cannot judge is not rejected.
 */
export function isEditionRejectedByStanding(edition: DecodedEvent, state: CommunityState): boolean {
  try {
    const verification = state.controlVerification;
    const { owner, community_id: communityId } = state.material;
    if (!verification || verification.communityId !== communityId || edition.author === owner) return false;
    if (edition.rumor.tags.find((t) => t[0] === "vsk")?.[1] !== String(VSK.PINS)) return false;
    if (!canEditionEverVerify(edition, owner, communityId)) return false;
    const [, eid, version, hash] = edition.rumor.tags.find((t) => t[0] === "vac")!;
    if (!verification.grantHistory.get(eid)?.some((g) => String(g.version) === version && g.hash === hash)) {
      return false;
    }
    // Suspended support is unresolved, not a verdict: the author's standing may still change once it resolves.
    if (
      verification.suspended.has(eid) ||
      (state.grants.get(edition.author) ?? []).some((roleId) => verification.suspended.has(roleId))
    ) return false;
    return !vacVerifier(state, PERM.PIN_MESSAGES)(edition.author, [eid, version, hash]);
  } catch {
    return false;
  }
}

/** A rejected edition a first Pin List write chains over: its version and `edition_hash` (CORD-04 §1). */
export interface EditionChainBase {
  /** The rejected edition's `ev` version; the new edition takes the next one. */
  version: number;
  /** The rejected edition's `edition_hash`, cited as the new edition's `ep`. */
  hash: string;
}

/**
 * The retained Pin List edition at `eid` that a write with no verified head chains over (D-34): the highest-version
 * edition that current standing rejects ({@link isEditionRejectedByStanding}), ties broken by the lower rumor id as in
 * the fold. CORD-04 §1: an entity's version only ever climbs and `prev` names the edition superseded, so a new head
 * takes the next version and cites it rather than a fresh version 1 that would tie with it at version 1 and could
 * lose the rumor-id tiebreak wherever the author still stands (a client that has not seen the demotion, or after the
 * author's authority is restored). Editions that can never verify are never chained over, so an injector cannot choose
 * the version. Undefined when no edition is rejected. Total: never throws.
 */
export function rejectedChainBase(
  history: Iterable<DecodedEvent>,
  eid: string,
  state: CommunityState,
): EditionChainBase | undefined {
  let best: (EditionChainBase & { id: string }) | undefined;
  for (const edition of history) {
    try {
      const { rumor } = edition;
      if (rumor.kind !== 3308 || rumor.tags.find((t) => t[0] === "eid")?.[1] !== eid) continue;
      if (!isEditionRejectedByStanding(edition, state)) continue;
      const ev = rumor.tags.find((t) => t[0] === "ev");
      const ep = rumor.tags.find((t) => t[0] === "ep");
      // Read the chain fields exactly as the fold does; an edition it would not parse is no chain link.
      if (ev?.length === 1 || ep?.length === 1) continue;
      if (ev && !/^(0|[1-9][0-9]*)$/.test(ev[1])) continue;
      const version = ev ? Number(ev[1]) : 1;
      if (version < 1 || !Number.isSafeInteger(version + 1)) continue;
      if (ep && !/^[0-9a-f]{64}$/i.test(ep[1])) continue;
      if (best && (version < best.version || (version === best.version && rumor.id >= best.id))) continue;
      const hash = computeEditionHash({ vsk: VSK.PINS, eid, version, prevHash: ep?.[1], content: rumor.content });
      best = { version, hash, id: rumor.id };
    } catch {
      // A malformed retained edition is no chain link; the remaining editions are still judged.
    }
  }
  return best && { version: best.version, hash: best.hash };
}

/**
 * The single place a pin's own author deletion is recognised. It shares `isAuthorDeleted` with the Edit chooser, so an
 * Edit its author deleted is recognised by exactly the same rule (D-31). DEC-04 is decided (D-16): banning a pinner
 * never triggers a republish, readers fall back to the last valid Pin List and the next authorized writer chains over
 * it, and the ban is deliberately not an input here, so a banned author's own deletion of a pinned message is still
 * honored (self-erasure outranks curation, CORD-04 §7).
 */
export function isSelfDeleted(pin: VerifiedPin, rumors: readonly Rumor[]): boolean {
  return isAuthorDeleted(pin.rumor, rumors);
}

/** One message of a Pin List after duplicate entries were collapsed by {@link collapsePinEntries}. */
export interface CollapsedPinEntry {
  /** The list's own entry object for the kept copy, never a clone. */
  entry: PinEntry;
  /** The verification of `entry`. */
  pin: VerifiedPin;
  /** Whether any copy of this message in the list, kept or dropped, bundles an Edit its own author deleted (D-31). */
  retracted: boolean;
}

/** Options for {@link collapsePinEntries}. */
export interface CollapsePinEntriesOptions {
  /** Channel rumors; kind 5 rumors make the bundled-Edit comparison deletion-aware, other kinds are ignored. */
  rumors?: readonly Rumor[];
  /** Entry verifier, for callers that cache verification. Defaults to `verifyPinEntry`. */
  verify?: (entry: PinEntry, channelId: string) => VerifiedPin | undefined;
}

/**
 * Collapse the entries of a Pin List to one per message. CORD-04 §7 projects one pin per pinned message; which copy a
 * list that names a message more than once resolves to is library rule D-32: the first copy fixes the position, and a
 * later copy replaces the kept one only when its bundled Edit strictly wins `newestValidEdit` (latest time, then lower
 * id) against the kept copy's bundled Edit, an Edit its own author deleted never counting (D-31). Ties and missing
 * bundles keep the first copy. Entries that fail verification are dropped one at a time. Total: never throws, never
 * mutates its input, and returns the list's own entry objects.
 */
export function collapsePinEntries(
  entries: readonly PinEntry[],
  channelId: string,
  options: CollapsePinEntriesOptions = {},
): CollapsedPinEntry[] {
  const verify = options.verify ?? verifyPinEntry;
  const rumors = options.rumors ?? [];
  const collapsed = new Map<string, CollapsedPinEntry>();
  for (const entry of entries) {
    const pin = verify(entry, channelId);
    if (!pin) continue;
    const retracted = pin.edit !== undefined && isAuthorDeleted(pin.edit, rumors);
    const kept = collapsed.get(pin.rumor.id);
    if (!kept) {
      collapsed.set(pin.rumor.id, { entry, pin, retracted });
      continue;
    }
    const keptEdit = kept.pin.edit;
    const wins = pin.edit !== undefined && pin.edit.id !== keptEdit?.id &&
      newestValidEdit(kept.pin.rumor, [keptEdit, pin.edit].filter((edit) => edit !== undefined), {
          channelId,
          deletions: rumors,
        })?.id === pin.edit.id;
    collapsed.set(pin.rumor.id, {
      ...(wins ? { entry, pin } : { entry: kept.entry, pin: kept.pin }),
      retracted: kept.retracted || retracted,
    });
  }
  return [...collapsed.values()];
}

/** Why a Pin List is rewritten: an author deleted a pinned message, a pinned Edit changed, or the channel rekeyed. */
export type PinUpkeepStage = "pin-omission" | "pin-edit-refresh" | "pin-rekey-refresh";

/**
 * What {@link planPinUpkeep} reads. Expiry never creates, removes or reorders an entry (DEC-01); the optional `now`
 * only keeps expired Edit text out of a refresh bundle.
 */
export interface PinUpkeepInput {
  /** The channel whose Pin List is examined. */
  channelId: string;
  /** The opened selected head list. */
  list: PinListRead;
  /** The form the selected head is stored in, from `describePinList`. */
  headForm: PinListForm;
  /** Whether the folded channel is private. */
  channelPrivate: boolean;
  /** The epoch of the held current channel key, when one is held. */
  sealKeyEpoch?: number;
  /** Channel rumors to read: kind 5 deletions (of messages and of Edits) and kind 3302 Edits. Other kinds are ignored. */
  rumors: readonly Rumor[];
  /**
   * The Edit's own proof for a pin, or undefined when it cannot be proved. Without it nothing is refreshed. It must
   * return only proofs that open to exactly the given Edit.
   */
  editProof?: (pin: VerifiedPin, edit: Rumor) => PinProof | undefined;
  /**
   * Unix-second clock. An Edit expired at `now` is never bundled, and when the newest author-valid Edit of a message is
   * expired the entry is not refreshed at all, so neither the expired text nor older, superseded text is published
   * as current (D-11). It never creates, removes or reorders entries.
   */
  now?: number;
  /** Returns true for an author whose Edits are ignored, for example a banned member. */
  isBanned?: (pubkey: string) => boolean;
  /** Entry verifier, for callers that cache verification. Defaults to `verifyPinEntry`. */
  verify?: (entry: PinEntry, channelId: string) => VerifiedPin | undefined;
}

/** The outcome of {@link planPinUpkeep}. */
export type PinUpkeepPlan =
  | { kind: "none" }
  | {
    kind: "rewrite";
    stage: PinUpkeepStage;
    form: "public" | "sealed";
    entries: PinEntry[];
    omitted: string[];
    refreshed: string[];
    affected: string[];
  }
  | { kind: "blocked"; stage: PinUpkeepStage; reason: "private-era-list"; affected: string[] };

/** The entry without its `edit` bundle; every other property is carried as the same value. */
export function withoutEdit(entry: PinEntry): PinEntry {
  const { edit: _edit, ...rest } = entry;
  return rest;
}

/**
 * The entry carrying the newest provable Edit of its message, or undefined when no refresh applies. Candidates are the
 * author-valid, unexpired, undeleted Edits tried newest first; one is attached only when it is strictly newer than the
 * Edit the entry already bundles, and only through `editProof`, so the entry changes in no other way (CORD-04 §7:
 * corrected text MUST NOT be republished in any other form). When the newest author-valid Edit is itself expired the
 * message is expired (D-11) and nothing is bundled, not even an older Edit that is still valid. An Edit its own author
 * deleted is never a candidate (D-31); when the entry bundles one, it is replaced by the newest undeleted provable Edit
 * or, when none qualifies, the entry is returned without its `edit` bundle. That fallback may be older than the deleted
 * Edit; it is not a regression because a deleted Edit is not valid. For a bundled Edit that is not deleted the
 * strictly-newer rule is unchanged.
 */
function refreshedEntry(
  pin: VerifiedPin,
  entry: PinEntry,
  input: PinUpkeepInput,
  edits: readonly Rumor[],
): PinEntry | undefined {
  const retracted = pin.edit !== undefined && isAuthorDeleted(pin.edit, input.rumors);
  const fallback = retracted ? withoutEdit(entry) : undefined;
  if (!input.editProof || edits.length === 0) return fallback;
  const options = { channelId: input.channelId, isBanned: input.isBanned, deletions: input.rumors };
  const current = newestValidEdit(pin.rumor, edits, options);
  if (!current || (input.now !== undefined && isRumorExpired(current, input.now))) return fallback;
  let remaining = edits;
  for (;;) {
    const candidate = newestValidEdit(pin.rumor, remaining, { ...options, now: input.now });
    if (!candidate) return fallback;
    // Never regress or re-attach: the candidate must beat the bundled Edit in the total (time, lower id) order. A
    // bundled Edit its author deleted is skipped by the chooser, so it never blocks a candidate (D-31).
    if (
      pin.edit &&
      newestValidEdit(pin.rumor, [pin.edit, candidate], { channelId: input.channelId, deletions: input.rumors })?.id ===
        pin.edit.id
    ) {
      return undefined;
    }
    const proof = input.editProof(pin, candidate);
    if (proof) return { ...entry, edit: proof };
    remaining = remaining.filter((rumor) =>
      newestValidEdit(pin.rumor, [rumor], { ...options, now: input.now })?.id !== candidate.id
    );
  }
}

/**
 * Plan the rewrite of a Pin List: entries whose proven author deleted the message are dropped, an entry whose message
 * has a newer provable Edit is refreshed with that Edit's proof bundle, an entry whose bundled Edit its author deleted
 * is refreshed with the newest undeleted provable Edit or loses its edit bundle (D-31, so no rewrite carries a deleted
 * Edit's proof), and every other valid entry is carried as the original object, in head order, so its proof bytes stay
 * byte-identical. A message listed more than once is collapsed first, keeping its first position and the copy whose
 * bundled Edit is newest (D-32); duplicates alone never trigger a rewrite. A folded private channel is rewritten sealed
 * and only when a current key is held; a sealed head on a public channel is never re-formed as public (`blocked`). A
 * readable list sealed at an older epoch than the held current key is resealed under that key even when nothing else is
 * due (CORD-04 §7: after a rekey a holder MAY, and a Rotator SHOULD, republish under the current key). The stage is
 * `pin-rekey-refresh` for a reseal, else `pin-omission` whenever anything is omitted, else `pin-edit-refresh`. Entries
 * that fail verification are dropped from a rewrite but never trigger one. Total: never throws.
 */
export function planPinUpkeep(input: PinUpkeepInput): PinUpkeepPlan {
  if (!input.list.available || input.list.entries.length === 0) return { kind: "none" };
  const verify = input.verify ?? verifyPinEntry;
  const edits = input.rumors.filter((rumor) => rumor.kind === EDIT_KIND);
  // A repeated pin keeps its first position and its newest bundled copy (D-32), exactly as readers project it, so an
  // unrelated rewrite never regresses the proven Edit. Duplicates alone never trigger a rewrite, like invalid entries;
  // only a copy bundling an Edit its author deleted makes the list due (D-31).
  const kept = new Map<string, PinEntry>();
  const omitted = new Set<string>();
  const refreshed = new Set<string>();
  for (
    const { entry, pin, retracted } of collapsePinEntries(input.list.entries, input.channelId, {
      rumors: input.rumors,
      verify,
    })
  ) {
    const id = pin.rumor.id;
    if (isSelfDeleted(pin, input.rumors)) {
      omitted.add(id);
      continue;
    }
    const fresh = refreshedEntry(pin, entry, input, edits);
    if (fresh || retracted) refreshed.add(id);
    kept.set(id, fresh ?? entry);
  }
  // Only a sealed head older than the held current key is resealed; a public head on a private channel is a conversion
  // that nothing here performs, and a key older than the head can only be a stale snapshot.
  const reseal = input.channelPrivate && input.headForm.form === "sealed" && input.sealKeyEpoch !== undefined &&
    BigInt(input.headForm.epoch) < BigInt(input.sealKeyEpoch) && kept.size > 0;
  if (omitted.size === 0 && refreshed.size === 0 && !reseal) return { kind: "none" };
  const stage: PinUpkeepStage = reseal ? "pin-rekey-refresh" : omitted.size > 0 ? "pin-omission" : "pin-edit-refresh";
  const affected = reseal ? [...omitted, ...kept.keys()] : [...omitted, ...refreshed];
  if (input.channelPrivate && input.sealKeyEpoch === undefined) return { kind: "none" };
  if (!input.channelPrivate && input.headForm.form === "sealed") {
    return { kind: "blocked", stage, reason: "private-era-list", affected };
  }
  const entries = [...kept.values()].filter((entry) => verify(entry, input.channelId) !== undefined);
  return {
    kind: "rewrite",
    stage,
    form: input.channelPrivate ? "sealed" : "public",
    entries,
    omitted: [...omitted],
    refreshed: [...refreshed],
    affected,
  };
}
