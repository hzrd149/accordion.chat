// CORD-02 §5 Guestbook — coalescing membership motion into a member list.
//
// Self-signed Joins/Leaves and authorised Kicks coalesce flat: one final state
// per npub, latest-by-millisecond wins (ties by lower rumor id). That fold,
// merged with observed authors (anyone seen publishing is present) and minus
// the Banlist, yields the Complete Memberlist.

import { PERM } from "../types.ts";
import type { DecodedEvent } from "../types.ts";
import { canActOn } from "./permissions.ts";
import type { Standing } from "./permissions.ts";
import { hasMalformedMs } from "./stream.ts";

/** Concord self-signed join/leave kind (CORD-02 §5). */
export const JOIN_LEAVE_KIND = 3306;
/** Concord authorised kick kind (CORD-02 §5). */
export const KICK_KIND = 3309;
/** Concord memberlist snapshot kind (CORD-02 §5). */
export const SNAPSHOT_KIND = 3312;

/** Concord self-signed join verb (CORD-02 §5). */
export const JOIN_VERB = "join";
/** Concord self-signed leave verb (CORD-02 §5). */
export const LEAVE_VERB = "leave";
/** The two self-signed membership verbs a kind 3306 rumor's content may carry. */
export type JoinLeaveVerb = typeof JOIN_VERB | typeof LEAVE_VERB;

const ONE_HOUR_MS = 60 * 60 * 1000;

/** Snapshot chunk size: 400 present members per event (CORD-02 §5). */
export const SNAPSHOT_CHUNK = 400;

interface Coalesced {
  present: boolean;
  ms: number;
  rumorId: string;
  /** True when this state came from a secondhand snapshot (CORD-02 §5): any
   *  self-signed entry or authorized Kick at ≥ its time supersedes it. */
  snapshot: boolean;
}

/**
 * Fold the Guestbook into a member set.
 *
 * @param observed  author npub -> latest ms seen publishing anywhere in the community
 * @param resolveStanding  roster lookup used to authorise Kicks
 * @param refounder  the npub whose Refounding minted the current epoch; only its
 *   snapshots (kind 3312) are honored (CORD-02 §5). Omit to honor none.
 * @param verifyVac  vac verification against the folded Roster (CORD-04 D-08/
 *   D-12, AUTH-08): a non-owner Kick must cite the Grant it acts under,
 *   structurally resolving to `grantLocator` AND still holding `PERM.KICK` in
 *   the CURRENT folded Roster. Additive to (never a replacement for) the
 *   rank-vs-victim check below. When omitted, non-owner Kicks fail closed;
 *   owner Kicks remain intrinsically authorized (CORD-04 §§1, 5).
 *   The predicate receives the Kick target as its third argument; it must deny
 *   suspended target support. {@link vacVerifier} supplies this check.
 */
export function foldMembers(
  guestbook: DecodedEvent[],
  observed: Map<string, number>,
  banlist: Set<string>,
  resolveStanding: (member: string) => Standing,
  nowMs: number = Date.now(),
  refounder?: string,
  verifyVac?: (rotator: string, vac: [string, string, string] | undefined, target?: string) => boolean,
): Set<string> {
  const state = new Map<string, Coalesced>();

  const consider = (subject: string, present: boolean, d: DecodedEvent) => {
    // Drop malformed entries (an ms tag outside 0..999) and ones dated more than
    // an hour ahead of our clock (anti-squat), rather than interpreting them.
    if (hasMalformedMs(d.rumor)) return;
    if (d.ms > nowMs + ONE_HOUR_MS) return;
    const prev = state.get(subject);
    // A firsthand entry (self-signed join/leave, or authorized kick) supersedes a
    // secondhand snapshot at equal time; two firsthand entries tie on lower rumor id.
    const wins = !prev || d.ms > prev.ms || (d.ms === prev.ms && (prev.snapshot || d.rumor.id < prev.rumorId));
    if (wins) state.set(subject, { present, ms: d.ms, rumorId: d.rumor.id, snapshot: false });
  };

  for (const d of guestbook) {
    // CORD-04 §4: banned authors contribute no membership effects, including
    // secondhand snapshots. The owner's intrinsic exemption remains intact.
    if (banlist.has(d.author) && !resolveStanding(d.author).isOwner) continue;
    const r = d.rumor;
    if (r.kind === JOIN_LEAVE_KIND) {
      if (typeof r.content !== "string") continue;
      const verb = r.content.trim();
      if (verb === JOIN_VERB) consider(d.author, true, d);
      else if (verb === LEAVE_VERB) consider(d.author, false, d);
    } else if (r.kind === KICK_KIND) {
      // Kick: honoured only if signer holds KICK and outranks the target.
      const target = r.tags.find((t) => t[0] === "p")?.[1];
      if (!target) continue;
      const actor = resolveStanding(d.author);
      const victim = resolveStanding(target);
      if (!actor.isOwner && !verifyVac) continue;
      if (!victim.isOwner && canActOn(actor, victim, PERM.KICK)) {
        // AUTH-08: additive vac gate — a non-owner Kick must cite the Grant it
        // acts under, and the CURRENT folded Roster must still grant KICK.
        if (verifyVac) {
          const vacTag = r.tags.find((t) => t[0] === "vac");
          const vac: [string, string, string] | undefined = vacTag && vacTag[1] && vacTag[2] && vacTag[3]
            ? [vacTag[1], vacTag[2], vacTag[3]]
            : undefined;
          if (!verifyVac(d.author, vac, target)) continue;
        }
        consider(target, false, d);
      }
    } else if (r.kind === SNAPSHOT_KIND) {
      // Snapshot: secondhand seed, honored ONLY from the epoch's refounder and
      // only when well-formed, held to the same clock/ms guards as any entry.
      if (refounder === undefined || d.author !== refounder) continue;
      if (hasMalformedMs(r)) continue;
      if (d.ms > nowMs + ONE_HOUR_MS) continue;
      try {
        const members: unknown = JSON.parse(r.content);
        if (!Array.isArray(members) || !members.every((pk: unknown) => typeof pk === "string")) continue;
        for (const pk of members as string[]) {
          const prev = state.get(pk);
          // Seeds present-state; any firsthand entry at ≥ its time overrides it.
          if (!prev || d.ms > prev.ms) state.set(pk, { present: true, ms: d.ms, rumorId: r.id, snapshot: true });
        }
      } catch {
        /* skip malformed snapshot */
      }
    }
  }

  const members = new Set<string>();
  for (const [npub, c] of state) if (c.present) members.add(npub);

  // Observation counts forward only: an author re-enters on activity newer than
  // their latest departure.
  for (const [author, lastMs] of observed) {
    const c = state.get(author);
    if (!c || c.present || lastMs > c.ms) members.add(author);
  }

  // D-14 defense-in-depth: the owner is never removable via a banlist, even if
  // a forged/buggy banlist Set carries their pk this far (CORD-04 §2 — the
  // owner occupies position 0, supreme and unremovable). Complements 09-02's
  // read-path banlist rank gate.
  for (const banned of banlist) {
    if (resolveStanding(banned).isOwner) continue;
    members.delete(banned);
  }
  return members;
}
