// CORD-03 §2 channel view mode and §3 titled forum posts: a kind 9 chat message MAY carry a ["subject", <title>] tag. These readers are total
// over untrusted relay input: a malformed tag is skipped, and an over-long subject is shortened for display, never a
// reason to drop the message ("A receiver truncates an over-long subject for display and MUST NOT drop the message
// because of it").

import type { ChannelMetadata, ChannelViewMode } from "../types.ts";
import { SUBJECT_MAX_BYTES } from "./caps.ts";

/** The value of the first well-formed `name` tag, skipping malformed entries. */
function firstTag(tags: unknown, name: string): string | undefined {
  if (!Array.isArray(tags)) return undefined;
  for (const tag of tags) {
    if (Array.isArray(tag) && tag[0] === name && typeof tag[1] === "string") return tag[1];
  }
  return undefined;
}

/**
 * The title of a forum post: the value of the first `subject` tag (CORD-03 §3). A legacy kind 11 thread root written by
 * older clients carries its title in a NIP-7D `title` tag instead, so for kind 11 a missing `subject` falls back to the
 * first `title` tag and existing threads keep their titles. Malformed tags (not an array, or a non-string value) are
 * skipped and never thrown on; returns `undefined` when no usable tag exists. The value is returned verbatim, so pass
 * it through {@link displaySubject} before rendering a received title.
 */
export function getSubject(rumor: { kind?: unknown; tags?: unknown }): string | undefined {
  return firstTag(rumor.tags, "subject") ?? (rumor.kind === 11 ? firstTag(rumor.tags, "title") : undefined);
}

/**
 * A subject shortened for display (CORD-03 §3): the longest prefix of at most `maxBytes` UTF-8 bytes (default
 * {@link SUBJECT_MAX_BYTES}) that ends on a code-point boundary, with no ellipsis. A subject within the cap is
 * returned unchanged. A non-finite or negative `maxBytes` counts as 0.
 */
export function displaySubject(subject: string, maxBytes: number = SUBJECT_MAX_BYTES): string {
  const limit = Number.isFinite(maxBytes) && maxBytes > 0 ? Math.floor(maxBytes) : 0;
  const bytes = new TextEncoder().encode(subject);
  if (bytes.length <= limit) return subject;
  let end = limit;
  // Walk back over UTF-8 continuation bytes (10xxxxxx) so the cut never splits a character.
  while (end > 0 && (bytes[end] & 0xc0) === 0x80) end--;
  return new TextDecoder().decode(bytes.subarray(0, end));
}

/**
 * How a channel is presented (CORD-03 §2): `"forum"` only when its folded `view` is exactly `"forum"`, and `"chat"`
 * for an absent view, `"chat"` itself and every unknown or malformed value ("A client MUST render an unknown or
 * unimplemented view value as chat rather than reject the edition"). Pure presentation: the raw value stays in the
 * folded channel and is never rewritten.
 */
export function channelViewMode(channel: { readonly view?: unknown } | ChannelMetadata | undefined): ChannelViewMode {
  return channel?.view === "forum" ? "forum" : "chat";
}
