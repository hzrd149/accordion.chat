// Compare UTF-8 bytes rather than UTF-16 code units; preserve keys such as __proto__.
export function canonicalWire(value: unknown): string {
  const encoder = new TextEncoder();
  const compare = (a: string, b: string): number => {
    const x = encoder.encode(a), y = encoder.encode(b);
    for (let i = 0; i < Math.min(x.length, y.length); i++) {
      if (x[i] !== y[i]) return x[i] - y[i];
    }
    return x.length - y.length;
  };
  const serialize = (input: unknown): string | undefined => {
    if (Array.isArray(input)) return "[" + input.map((value) => serialize(value) ?? "null").join(",") + "]";
    if (input && typeof input === "object") {
      return "{" + Object.keys(input).sort(compare).flatMap((field) => {
        const value = serialize((input as Record<string, unknown>)[field]);
        return value === undefined ? [] : [JSON.stringify(field) + ":" + value];
      }).join(",") + "}";
    }
    return JSON.stringify(input);
  };
  return serialize(value)!;
}

/** Preserve opaque per-record extensions with an order-independent value tie-break. */
export function mergeOpaque(a: object, b: object): Record<string, unknown> {
  const result: Record<string, unknown> = Object.create(null);
  for (const source of [a, b]) {
    for (const [key, value] of Object.entries(source)) {
      if (!Object.hasOwn(result, key) || canonicalWire(value) < canonicalWire(result[key])) result[key] = value;
    }
  }
  return result;
}
