// AV-01 / D-11: the CORD-07 call key derivations (§1 room keypair and media root, §3 per-sender keys), proven against
// independent recomputation with the literal labels so a wrong label, argument order or epoch rule fails.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { bytesToHex, hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";
import { sha256 } from "@noble/hashes/sha2.js";

import { concordHkdf, groupKey, voiceGroupKey, voiceMediaKey, voiceSenderKey } from "../crypto.ts";
import { voiceKeysFor } from "../community.ts";
import type { ChannelKey, ChannelMetadata, JoinMaterial } from "../../types.ts";

const ROOT_HEX = bytesToHex(new Uint8Array(32).fill(7));
const PRIVATE_KEY_HEX = bytesToHex(new Uint8Array(32).fill(11));
const PUBLIC_CHANNEL_ID = bytesToHex(new Uint8Array(32).fill(9));
const PRIVATE_CHANNEL_ID = bytesToHex(new Uint8Array(32).fill(13));
const KEYLESS_CHANNEL_ID = bytesToHex(new Uint8Array(32).fill(15));
const SECRET = hexToBytes(ROOT_HEX);
const CID = hexToBytes(PUBLIC_CHANNEL_ID);

const publicChannel: ChannelMetadata = { channel_id: PUBLIC_CHANNEL_ID, name: "lobby", private: false };
const privateChannel: ChannelMetadata = { channel_id: PRIVATE_CHANNEL_ID, name: "staff", private: true };
const keylessChannel: ChannelMetadata = { channel_id: KEYLESS_CHANNEL_ID, name: "secret", private: true };

function materialWith(channels: ChannelKey[]): JoinMaterial {
  return {
    community_id: bytesToHex(new Uint8Array(32).fill(1)),
    owner: bytesToHex(new Uint8Array(32).fill(2)),
    owner_salt: bytesToHex(new Uint8Array(32).fill(3)),
    community_root: ROOT_HEX,
    root_epoch: 3,
    channels,
    relays: [],
    name: "test community",
  };
}

const heldKey = (epoch: number): ChannelKey => ({
  id: PRIVATE_CHANNEL_ID,
  key: PRIVATE_KEY_HEX,
  epoch,
  name: "staff",
});

describe("CORD-07 call key derivations (AV-01)", () => {
  it("voiceGroupKey derives the room keypair from concord/voice-signer and rolls with the epoch (CORD-07 §1)", () => {
    const room = voiceGroupKey(SECRET, CID, 4);
    const expected = groupKey("concord/voice-signer", SECRET, CID, 4);
    expect(room.pk).toBe(expected.pk);
    expect(bytesToHex(room.sk)).toBe(bytesToHex(expected.sk));
    expect(voiceGroupKey(SECRET, CID, 4).pk).toBe(room.pk);
    expect(voiceGroupKey(SECRET, CID, 5).pk).not.toBe(room.pk);
    // The room is its own address, never the channel's chat address.
    expect(room.pk).not.toBe(groupKey("concord/channel", SECRET, CID, 4).pk);
  });

  it("voiceMediaKey derives the media root from concord/voice-media and rolls with the epoch (CORD-07 §1)", () => {
    const media = voiceMediaKey(SECRET, CID, 4);
    expect(bytesToHex(media)).toBe(bytesToHex(concordHkdf(SECRET, "concord/voice-media", CID, 4)));
    expect(media.length).toBe(32);
    expect(bytesToHex(voiceMediaKey(SECRET, CID, 5))).not.toBe(bytesToHex(media));
    expect(bytesToHex(media)).not.toBe(bytesToHex(voiceGroupKey(SECRET, CID, 4).sk));
  });

  it("voiceSenderKey hashes the SFU identity and omits the epoch (CORD-07 §3)", () => {
    const media = voiceMediaKey(SECRET, CID, 4);
    const alice = voiceSenderKey(media, "alice");
    const expected = concordHkdf(media, "concord/voice-sender", sha256(utf8ToBytes("alice")));
    expect(bytesToHex(alice)).toBe(bytesToHex(expected));
    expect(alice.length).toBe(32);
    const withEpoch = concordHkdf(media, "concord/voice-sender", sha256(utf8ToBytes("alice")), 4);
    expect(bytesToHex(alice)).not.toBe(bytesToHex(withEpoch));
    expect(bytesToHex(voiceSenderKey(media, "bob"))).not.toBe(bytesToHex(alice));
  });

  it("voiceKeysFor uses the community root for a public channel and the held key for a private one (CORD-07 §1)", () => {
    const publicKeys = voiceKeysFor(materialWith([]), publicChannel)!;
    expect(publicKeys.room.pk).toBe(voiceGroupKey(SECRET, CID, 3).pk);
    expect(bytesToHex(publicKeys.mediaKey)).toBe(bytesToHex(voiceMediaKey(SECRET, CID, 3)));

    const privateId = hexToBytes(PRIVATE_CHANNEL_ID);
    const privateSecret = hexToBytes(PRIVATE_KEY_HEX);
    const privateKeys = voiceKeysFor(materialWith([heldKey(2)]), privateChannel)!;
    expect(privateKeys.room.pk).toBe(voiceGroupKey(privateSecret, privateId, 2).pk);
    expect(bytesToHex(privateKeys.mediaKey)).toBe(bytesToHex(voiceMediaKey(privateSecret, privateId, 2)));
    // The private pair is not the community root pair.
    expect(privateKeys.room.pk).not.toBe(voiceGroupKey(SECRET, privateId, 3).pk);

    const rolled = voiceKeysFor(materialWith([heldKey(3)]), privateChannel)!;
    expect(rolled.room.pk).not.toBe(privateKeys.room.pk);
    expect(bytesToHex(rolled.mediaKey)).not.toBe(bytesToHex(privateKeys.mediaKey));
  });

  it("voiceKeysFor derives nothing for a private channel whose key is not held (CORD-07 §1)", () => {
    expect(voiceKeysFor(materialWith([heldKey(2)]), keylessChannel)).toBeNull();
    expect(voiceKeysFor(materialWith([]), keylessChannel)).toBeNull();
  });
});
