import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import type { Rumor } from "../../types.ts";
import { getEventHash } from "applesauce-core/helpers/event";
import { EDIT_KIND, getEditTarget, getEditText, isValidEdit, newestValidEdit } from "../edit.ts";

const ID = "a".repeat(64);

const rumor = (over: Partial<Rumor> = {}): Rumor =>
  ({
    id: "e".repeat(64),
    pubkey: "b".repeat(64),
    kind: EDIT_KIND,
    content: "",
    tags: [] as string[][],
    created_at: 0,
    ...over,
  }) as Rumor;

describe("edit helpers", () => {
  it("isValidEdit requires the edit kind and an `e` target", () => {
    expect(isValidEdit(rumor({ tags: [["e", ID]] }))).toBe(true);
    expect(isValidEdit(rumor())).toBe(false);
    expect(isValidEdit(rumor({ kind: 9, tags: [["e", ID]] }))).toBe(false);
    expect(isValidEdit(undefined)).toBe(false);
  });

  it("getEditTarget returns an EventPointer for the replaced message", () => {
    expect(getEditTarget(rumor({ tags: [["e", ID]] }))).toEqual({ id: ID });
    expect(getEditTarget(rumor())).toBeUndefined();
  });

  it("getEditText returns the replacement content", () => {
    expect(getEditText(rumor({ content: "fixed typo" }))).toBe("fixed typo");
  });

  describe("newestValidEdit", () => {
    const CHANNEL = "c".repeat(64);
    const original = rumor({ id: ID, kind: 9, pubkey: "b".repeat(64), tags: [["channel", CHANNEL]] });
    const edit = (over: Partial<Rumor> = {}): Rumor => {
      const base = rumor({
        id: "",
        content: "edit",
        created_at: 100,
        tags: [["e", ID], ["channel", CHANNEL], ["epoch", "0"]],
        ...over,
      });
      return { ...base, id: getEventHash(base) };
    };
    const options = { channelId: CHANNEL };

    it("newestValidEdit picks the newest author-valid Edit for the channel", () => {
      const older = edit({ content: "older", created_at: 100 });
      const newer = edit({ content: "newer", created_at: 101 });
      const sameSecondLaterMs = edit({ content: "ms", created_at: 100, tags: [...older.tags, ["ms", "5"]] });
      expect(newestValidEdit(original, [older, newer], options)?.content).toBe("newer");
      expect(newestValidEdit(original, [newer, older], options)?.content).toBe("newer");
      expect(newestValidEdit(original, [older, sameSecondLaterMs], options)?.content).toBe("ms");
      expect(newestValidEdit(original, [], options)).toBeUndefined();
    });

    it("newestValidEdit breaks equal-ms ties by the lower recomputed rumor id (A2)", () => {
      const a = edit({ content: "a" });
      const b = edit({ content: "b" });
      const lower = a.id < b.id ? a : b;
      expect(newestValidEdit(original, [a, b], options)?.id).toBe(lower.id);
      expect(newestValidEdit(original, [b, a], options)?.id).toBe(lower.id);
    });

    it("newestValidEdit ignores wrong author, wrong channel, edit of an edit, malformed ms, expired and banned edits", () => {
      const good = edit({ content: "good", created_at: 50 });
      const wrongAuthor = edit({ content: "author", pubkey: "d".repeat(64), created_at: 200 });
      const wrongChannel = edit({
        content: "channel",
        tags: [["e", ID], ["channel", "d".repeat(64)]],
        created_at: 200,
      });
      const ofEdit = edit({ content: "edit of edit", tags: [["e", good.id], ["channel", CHANNEL]], created_at: 200 });
      const malformed = edit({
        content: "ms",
        tags: [["e", ID], ["channel", CHANNEL], ["ms", "1000"]],
        created_at: 200,
      });
      const notEdit = edit({ content: "kind", kind: 9, created_at: 200 });
      const expired = edit({
        content: "expired",
        tags: [["e", ID], ["channel", CHANNEL], ["expiration", "150"]],
        created_at: 200,
      });
      const banned = edit({ content: "banned", created_at: 200 });
      const all = [good, wrongAuthor, wrongChannel, ofEdit, malformed, notEdit, expired];
      expect(newestValidEdit(original, all, { ...options, now: 1_000 })?.content).toBe("good");
      expect(newestValidEdit(original, [expired], options)?.content).toBe("expired");
      expect(newestValidEdit(original, [expired], { ...options, now: 1_000 })).toBeUndefined();
      expect(newestValidEdit(original, [good, banned], { ...options, isBanned: (pk) => pk === banned.pubkey }))
        .toBeUndefined();
    });

    it("newestValidEdit ignores the k tag", () => {
      const withK = edit({ content: "k", tags: [["e", ID], ["channel", CHANNEL], ["k", "1111"]] });
      expect(newestValidEdit(original, [withK], options)?.content).toBe("k");
    });

    it("newestValidEdit returns the recomputed id, never a forged embedded id", () => {
      const real = edit({ content: "forged" });
      const forged = { ...real, id: "f".repeat(64) };
      expect(newestValidEdit(original, [forged], options)?.id).toBe(real.id);
    });

    /** A kind 5 deletion of `target` by `pubkey`; `named` overrides the id the `e` tag carries. */
    const deletionOf = (target: Rumor, pubkey = target.pubkey, named = target.id): Rumor =>
      rumor({ kind: 5, pubkey, id: "d".repeat(64), tags: [["e", named]] });

    it("newestValidEdit skips an Edit its own author deleted and falls back to the next undeleted Edit (D-31)", () => {
      // Non-vacuity: drop the deletions check in newestValidEdit and the deleted newer Edit is chosen.
      const older = edit({ content: "older", created_at: 100 });
      const newer = edit({ content: "newer", created_at: 101 });
      const withDeletions = (deletions: Rumor[]) => ({ ...options, deletions });
      expect(newestValidEdit(original, [older, newer], options)?.content).toBe("newer");
      expect(newestValidEdit(original, [older, newer], withDeletions([deletionOf(newer)]))?.content).toBe("older");
      expect(newestValidEdit(original, [newer, older], withDeletions([deletionOf(newer)]))?.content).toBe("older");
      expect(newestValidEdit(original, [older, newer], withDeletions([deletionOf(newer), deletionOf(older)])))
        .toBeUndefined();
    });

    it("newestValidEdit honours only the Edit author's own deletion of the recomputed Edit id (D-31)", () => {
      // Non-vacuity: match the deleter against any pubkey, or the embedded id instead of the recomputed one.
      const real = edit({ content: "real" });
      const withDeletions = (deletions: Rumor[]) => ({ ...options, deletions });
      expect(newestValidEdit(original, [real], withDeletions([deletionOf(real, "d".repeat(64))]))?.content).toBe(
        "real",
      );
      expect(newestValidEdit(original, [real], withDeletions([deletionOf(real, real.pubkey, "f".repeat(64))]))?.content)
        .toBe("real");
      const forged = { ...real, id: "f".repeat(64) };
      expect(newestValidEdit(original, [forged], withDeletions([deletionOf(real)]))).toBeUndefined();
      expect(newestValidEdit(original, [forged], withDeletions([deletionOf(real, real.pubkey, forged.id)]))?.id)
        .toBe(real.id);
    });

    it("newestValidEdit skips malformed deletions without throwing (D-31)", () => {
      // Non-vacuity: the one valid deletion mixed in must still remove its Edit, so the test fails without the option.
      const older = edit({ content: "older", created_at: 100 });
      const newer = edit({ content: "newer", created_at: 101 });
      const malformed = [
        null,
        undefined,
        { ...rumor({ kind: 5 }), tags: "x" },
        rumor({ kind: 5, tags: [null, ["e"]] as unknown as string[][] }),
        rumor({ kind: 9, tags: [["e", newer.id]] }),
        rumor({ kind: 5, tags: [["e"]] }),
      ] as unknown as Rumor[];
      const withDeletions = (deletions: Rumor[]) => ({ ...options, deletions });
      const mixed = withDeletions([...malformed, deletionOf(newer)]);
      expect(newestValidEdit(original, [older, newer], mixed)?.content).toBe("older");
      expect(newestValidEdit(original, [older, newer], withDeletions(malformed))?.content).toBe("newer");
    });
  });
});
