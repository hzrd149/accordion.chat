// CORD-04 §4 re-heal decision rules (BAN-03, D-12..D-15, D-19, D-21): which of this client's bans did a concurrent
// sibling displace, and may they safely be put back on top of the winning head? Every case builds its editions with
// `computeEditionHash` and `decoded`, never with the code under test.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import type { DecodedEvent, VerifiedControlHead } from "../../types.ts";
import { VSK } from "../../types.ts";
import type { BanlistIntent } from "../banlist.ts";
import { type BanlistReHealInput, planBanlistReHeal } from "../banlist-reheal.ts";
import type { EditionRef } from "../edition-lineage.ts";
import { computeEditionHash } from "../editions.ts";
import { decoded } from "./test-utils.ts";

const EID = "11".repeat(32);
const SELF = "51".repeat(32);
const OWNER = "ab".repeat(32);
const OTHER = "52".repeat(32);
const A = "a1".repeat(32);
const B = "b1".repeat(32);
const C = "c1".repeat(32);
const MID = "d1".repeat(32);

interface Built {
  event: DecodedEvent;
  ref: EditionRef;
  members: string[];
}

/** One Banlist edition; its link hash comes from the hashing primitive, not from the planner. */
function edition(version: number, prev: Built | undefined, members: string[], author: string, ms = 1_000): Built {
  const content = JSON.stringify(members);
  const prevHash = prev?.ref.hash;
  const tags = [["vsk", String(VSK.BANLIST)], ["eid", EID], ["ev", String(version)]];
  if (prevHash) tags.push(["ep", prevHash]);
  const hash = computeEditionHash({ vsk: VSK.BANLIST, eid: EID, version, prevHash, content });
  return {
    event: decoded({ kind: 3308, content, tags }, author, ms),
    ref: { eid: EID, version, hash, ...(prevHash ? { prevHash } : {}) },
    members,
  };
}

/** The verified head the fold would report for a built edition. */
function head(built: Built): VerifiedControlHead {
  return { edition: built.event, vsk: VSK.BANLIST, ...built.ref };
}

const ban = (built: Built, seq = 1): BanlistIntent => ({ action: "ban", seq, edition: built.ref });

function plan(
  headEdition: Built | undefined,
  retained: Built[],
  over: Partial<BanlistReHealInput> = {},
): ReturnType<typeof planBanlistReHeal> {
  return planBanlistReHeal({
    self: SELF,
    owner: OWNER,
    head: headEdition && head(headEdition),
    suspended: false,
    effective: new Set(),
    retained: retained.map((b) => b.event),
    intents: new Map(),
    canBan: () => true,
    current: () => true,
    ...over,
  });
}

describe("planBanlistReHeal (CORD-04 §4, BAN-03, D-12..D-15, D-19, D-21)", () => {
  it("a ban lost to a same-version sibling heals on top of the winning head (D-13)", () => {
    // Non-vacuity: a planner that republished the own content instead of the head content would drop B.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    const result = plan(winner, [own, winner], {
      effective: new Set([B]),
      intents: new Map([[A, ban(own)]]),
    });
    expect(result).toEqual({ kind: "heal", members: [A], content: [B, A], source: "session" });
    // The same loss is found from retained history alone after a restart, with no session intent.
    expect(plan(winner, [own, winner], { effective: new Set([B]) })).toEqual({
      kind: "heal",
      members: [A],
      content: [B, A],
      source: "retained",
    });
  });

  it("a ban lost below the head heals when the head chain never carried it", () => {
    // Non-vacuity: treating only same-version losses as lost would skip this heal.
    const v1 = edition(1, undefined, [], OTHER);
    const own = edition(2, v1, [A], SELF);
    const w2 = edition(2, v1, [B], OTHER);
    const w3 = edition(3, w2, [B, C], OTHER);
    const w4 = edition(4, w3, [B, C, MID], OTHER);
    const result = plan(w4, [v1, own, w2, w3, w4], {
      effective: new Set([B, C, MID]),
      intents: new Map([[A, ban(own)]]),
    });
    expect(result).toEqual({ kind: "heal", members: [A], content: [B, C, MID, A], source: "session" });
  });

  it("an own edition that is still an ancestor of the head needs no heal", () => {
    // Non-vacuity: a planner that healed every own ban regardless of lineage and effectiveness would publish here.
    const v1 = edition(1, undefined, [], OTHER);
    const own = edition(2, v1, [A], SELF);
    const h = edition(3, own, [A, B], OTHER);
    const result = plan(h, [v1, own, h], { effective: new Set([A, B]), intents: new Map([[A, ban(own)]]) });
    expect(result).toEqual({ kind: "none" });
    expect(plan(h, [v1, own, h], { effective: new Set([A, B]) })).toEqual({ kind: "none" });
  });

  it("an unknown lineage plans nothing", () => {
    // Non-vacuity: guessing "lost" for a compacted predecessor would heal here.
    const v1 = edition(1, undefined, [], OTHER);
    const own = edition(2, v1, [A], SELF);
    const w2 = edition(2, v1, [B], OTHER);
    const w3 = edition(3, w2, [B, C], OTHER);
    const w4 = edition(4, w3, [B, C, MID], OTHER);
    const intents = new Map([[A, ban(own)]]);
    // w3 compacted away: the walk from the head cannot reach the own version.
    expect(plan(w4, [v1, own, w2, w4], { intents })).toEqual({ kind: "none" });
    // The depth cap also leaves the lineage undecided.
    expect(plan(w4, [v1, own, w2, w3, w4], { intents, maxDepth: 1 })).toEqual({ kind: "none" });
  });

  it("a ban that appeared on the head chain and was later removed is never revived (BAN-03)", () => {
    // Non-vacuity: a planner that only looked at the head content and the lineage would re-ban a deliberate unban.
    const v1 = edition(1, undefined, [], OTHER);
    const own = edition(2, v1, [A], SELF);
    const unbanned = edition(3, own, [], OTHER);
    expect(plan(unbanned, [v1, own, unbanned], { intents: new Map([[A, ban(own)]]) })).toEqual({ kind: "none" });
    expect(plan(unbanned, [v1, own, unbanned])).toEqual({ kind: "none" });

    // The same holds when the ban rode a winning sibling edition and was removed after it.
    const sibling = edition(2, v1, [A, B], OTHER);
    const removed = edition(3, sibling, [B], OTHER);
    expect(plan(removed, [v1, own, sibling, removed], { effective: new Set([B]), intents: new Map([[A, ban(own)]]) }))
      .toEqual({ kind: "none" });
  });

  it("a later session unban cancels a lost ban (D-12)", () => {
    // Non-vacuity: keeping the earlier ban intent (or seeding from retained history alone) would heal A.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    const unban: BanlistIntent = { action: "unban", seq: 2 };
    const retained = [own, winner];
    expect(plan(winner, retained, { effective: new Set([B]), intents: new Map([[A, unban]]) })).toEqual({
      kind: "none",
    });
  });

  it("only editions this client authored seed candidates (D-14)", () => {
    // Non-vacuity: seeding from any author's lost edition would act on a ban that is not ours. The foreign edition is the
    // newest of all (a later ms), so a planner that ignored the author would pick it as the newest own edition.
    const foreign = edition(1, undefined, [A], OTHER, 3_000);
    const winner = edition(1, undefined, [B], OTHER, 2_000);
    expect(plan(winner, [foreign, winner], { effective: new Set([B]) })).toEqual({ kind: "none" });
  });

  it("only the newest own Banlist edition seeds retained candidates (D-21)", () => {
    // Non-vacuity: scanning every own edition would seed A from the older v1 even though v2 adds nothing.
    const v1 = edition(1, undefined, [A], SELF);
    const v2 = edition(2, v1, [A], SELF, 2_000);
    const w1 = edition(1, undefined, [B], OTHER);
    const w2 = edition(2, w1, [B, C], OTHER);
    expect(plan(w2, [v1, v2, w1, w2], { effective: new Set([B, C]) })).toEqual({ kind: "none" });
  });

  it("an own edition no longer at the current epoch's Control address seeds nothing (D-15)", () => {
    // Non-vacuity: ignoring current() would re-apply a loss from before a Refounding.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    const result = plan(winner, [own, winner], { effective: new Set([B]), current: () => false });
    expect(result).toEqual({ kind: "none" });
  });

  it("a ban kept in the head content but dropped by rank heals with the content unchanged", () => {
    // Non-vacuity: treating "in the head content" as healthy would never repair a rank-dropped entry.
    const own = edition(1, undefined, [A], SELF);
    const h = edition(2, own, [A, B], OTHER);
    const result = plan(h, [own, h], { effective: new Set([B]), intents: new Map([[A, ban(own)]]) });
    expect(result).toEqual({ kind: "heal", members: [A], content: [A, B], source: "session" });
  });

  it("a member this client can no longer ban is never healed (D-15)", () => {
    // Non-vacuity: skipping the canBan check would re-sign a ban the fold would drop again.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    const intents = new Map([[A, ban(own)]]);
    const canBan = (member: string) => member !== A;
    expect(plan(winner, [own, winner], { effective: new Set([B]), intents, canBan })).toEqual({ kind: "none" });
    expect(plan(winner, [own, winner], { effective: new Set([B]), canBan })).toEqual({ kind: "none" });
  });

  it("a heal that would carry an entry this client cannot vouch for is blocked (D-19)", () => {
    // Non-vacuity: dropping the unvouched guard would re-sign a senior's ban under this client's lower rank.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [MID], OTHER);
    const result = plan(winner, [own, winner], {
      intents: new Map([[A, ban(own)]]),
      canBan: (member) => member !== MID,
    });
    expect(result).toEqual({ kind: "blocked", members: [MID] });
  });

  it("exhausted members are never planned again", () => {
    // Non-vacuity: ignoring the exhausted set would retry a member forever.
    const own = edition(1, undefined, [A, C], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    const result = plan(winner, [own, winner], {
      effective: new Set([B]),
      intents: new Map([[A, ban(own)], [C, ban(own)]]),
      exhausted: new Set([A]),
    });
    expect(result).toEqual({ kind: "heal", members: [C], content: [B, C], source: "session" });
    expect(plan(winner, [own, winner], { effective: new Set([B]), exhausted: new Set([A, C]) })).toEqual({
      kind: "none",
    });
  });

  it("session-sourced heals are marked session and retained-sourced heals retained", () => {
    // Non-vacuity: a constant source would mislabel one of the three outcomes.
    const own = edition(1, undefined, [A, C], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    const effective = new Set([B]);
    const sessionOnly = plan(winner, [own, winner], { effective, intents: new Map([[A, ban(own)], [C, ban(own)]]) });
    expect(sessionOnly).toMatchObject({ kind: "heal", members: [A, C], source: "session" });
    const retainedOnly = plan(winner, [own, winner], { effective });
    expect(retainedOnly).toMatchObject({ kind: "heal", members: [A, C], source: "retained" });
    const mixed = plan(winner, [own, winner], { effective, intents: new Map([[A, ban(own)]]) });
    expect(mixed).toMatchObject({ kind: "heal", members: [A, C], source: "session" });
  });

  it("a heal never removes a head-content entry other than the owner key (D-19)", () => {
    // Non-vacuity: planning from the effective set instead of the head content would drop MID and lift its ban.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [OWNER, B, MID, C], OTHER);
    const result = plan(winner, [own, winner], {
      effective: new Set([B, C]),
      intents: new Map([[A, ban(own)]]),
      canBan: () => true,
    });
    expect(result).toEqual({ kind: "heal", members: [A], content: [B, MID, C, A], source: "session" });
    if (result.kind !== "heal") throw new Error("expected a heal");
    for (const entry of winner.members.filter((m) => m !== OWNER)) expect(result.content).toContain(entry);
    expect(result.content).not.toContain(OWNER);
  });

  it("planBanlistReHeal is total on garbage input", () => {
    // Non-vacuity: an unguarded planner would throw on any of these.
    const own = edition(1, undefined, [A], SELF);
    const winner = edition(1, undefined, [B], OTHER);
    expect(plan(undefined, [own])).toEqual({ kind: "none" });
    expect(plan(winner, [own, winner], { suspended: true, intents: new Map([[A, ban(own)]]) })).toEqual({
      kind: "none",
    });
    // A head that is not a Banlist, or whose content is not a Banlist, plans nothing.
    const wrongVsk = { ...head(winner), vsk: VSK.PINS };
    expect(planBanlistReHeal({ ...baseInput(winner, [own, winner]), head: wrongVsk })).toEqual({ kind: "none" });
    const garbledHead = {
      ...head(winner),
      edition: { ...winner.event, rumor: { ...winner.event.rumor, content: "{" } },
    };
    expect(planBanlistReHeal({ ...baseInput(winner, [own, winner]), head: garbledHead })).toEqual({ kind: "none" });
    // Hostile retained entries and intents never throw.
    const junk = [null, undefined, 3, { rumor: null }, { rumor: { tags: "x" } }] as unknown as DecodedEvent[];
    expect(
      planBanlistReHeal({
        ...baseInput(winner, [own, winner]),
        retained: junk,
        intents: new Map([[A, { action: "ban", seq: 1, edition: { eid: "x", version: 0, hash: 1 } }]]) as never,
      }),
    ).toEqual({ kind: "none" });
    expect(planBanlistReHeal(null as never)).toEqual({ kind: "none" });
    expect(planBanlistReHeal({} as never)).toEqual({ kind: "none" });
  });
});

function baseInput(headEdition: Built, retained: Built[]): BanlistReHealInput {
  return {
    self: SELF,
    owner: OWNER,
    head: head(headEdition),
    suspended: false,
    effective: new Set(),
    retained: retained.map((b) => b.event),
    intents: new Map(),
    canBan: () => true,
    current: () => true,
  };
}
