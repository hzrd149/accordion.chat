/// <reference lib="esnext.disposable" />
import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import { createCommunity } from "../community.ts";
import { foldControl } from "../control.ts";
import { type ConcordKeys, deriveConcordKeys, wrapForTarget, type WrapTarget } from "../keys.ts";
import { decodeWrap } from "../gift-wrap.ts";
import { EDIT_KIND } from "../edit.ts";
import { WEBXDC_KIND } from "../webxdc.ts";
import { TYPING_KIND } from "../typing.ts";
import { VOICE_PRESENCE_KIND } from "../voice.ts";
import { decoded } from "./test-utils.ts";
import { createReceiveDecoder } from "../../client/receive.ts";
import { FakeTime } from "@std/testing/time";
import { RumorStore } from "applesauce-core";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";
import { BehaviorSubject } from "rxjs";
import {
  isRumorExpired,
  messageExpiration,
  rumorExpiration,
  stampMessageExpiration,
  TIMER_NOTICE_KIND,
} from "../expiration.ts";
import { ConcordChatTimelineModel } from "../../models/chat.ts";
import { retainChannelInput } from "../../client/channel-input.ts";
import type { ConcordRumorStore } from "../../client/storage.ts";

function rumor(kind = 9, expires = 2): Rumor {
  const event = {
    pubkey: "11".repeat(32),
    kind,
    created_at: 1,
    content: "text",
    tags: [["expiration", String(expires)]],
    id: "",
  };
  event.id = getEventHash(event);
  return event;
}

describe("disappearing Chat", () => {
  it("stamps final Unix-second time and strips tags from exempt kinds", () => {
    expect(stampMessageExpiration(rumor(), 30).tags).toEqual([["expiration", "31"]]);
    for (const kind of [5, 1740, 23311, 23313]) expect(stampMessageExpiration(rumor(kind), 30).tags).toEqual([]);
    expect(stampMessageExpiration(rumor(), 30, true).tags).toEqual([]);
    for (const value of [undefined, null, "30", -1, 1.5, NaN, Infinity]) expect(messageExpiration(value)).toBe(0);
    expect(isRumorExpired(rumor(), 1)).toBe(false);
    expect(isRumorExpired(rumor(), 2)).toBe(true);
    expect(isRumorExpired(rumor(5), 3)).toBe(false);
  });

  async function plane() {
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const genesis = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "timer", relays: [] });
    const state = foldControl(genesis.controlRumors.map((r) => decoded(r, genesis.material.owner)), genesis.material);
    const keys = deriveConcordKeys(genesis.material, state.channels);
    return { signer, keys, channelId: genesis.generalChannelId };
  }

  /** Wrap a caller draft (carrying a bogus expiration tag) for a target, then open it again. */
  async function sendAndOpen(keys: ConcordKeys, target: WrapTarget, signer: PrivateKeySigner, kind: number) {
    const draft = { kind, content: "x", tags: [["expiration", "1"], ["epoch", "0"]] };
    const { wrap } = await wrapForTarget(keys, target, signer, draft, { messageExpiration: 60 });
    const info = keys.planes.get(wrap.pubkey)!;
    const opened = decodeWrap(structuredClone(wrap), info.convKey)!;
    return { wrap, rumor: opened.rumor };
  }

  const expirationTags = (tags: string[][]) => tags.filter((tag) => tag[0] === "expiration");

  it("stamps every durable Chat kind on the rumor and its outer wrap (CORD-08 §2)", async () => {
    const { signer, keys, channelId } = await plane();
    // 19999 and 30000 are the range boundaries around the permanent 20000-29999 block.
    for (const kind of [9, 7, 11, 1111, EDIT_KIND, WEBXDC_KIND, 19999, 30000]) {
      const { wrap, rumor } = await sendAndOpen(keys, { plane: "channel", channelId }, signer, kind);
      // The caller's ["expiration", "1"] tag was replaced, not kept beside the stamp.
      expect(expirationTags(rumor.tags)).toEqual([["expiration", String(rumor.created_at + 60)]]);
      expect(expirationTags(wrap.tags)).toEqual(expirationTags(rumor.tags));
    }
  });

  it("never stamps exempt kinds or non-Chat planes (CORD-08 §2)", async () => {
    const { signer, keys, channelId } = await plane();
    for (const kind of [5, TIMER_NOTICE_KIND, TYPING_KIND, VOICE_PRESENCE_KIND, 20000, 29999]) {
      const { wrap, rumor } = await sendAndOpen(keys, { plane: "channel", channelId }, signer, kind);
      expect(expirationTags(rumor.tags)).toEqual([]);
      expect(expirationTags(wrap.tags)).toEqual([]);
    }
    // Control and guestbook documents are never Chat: a timer must not stamp them.
    for (const target of [{ plane: "control" }, { plane: "guestbook" }] as WrapTarget[]) {
      const { wrap, rumor } = await sendAndOpen(keys, target, signer, target.plane === "control" ? 3308 : 9);
      // Control and guestbook rumors keep the caller's own tag untouched and never gain a stamp or an outer tag.
      expect(expirationTags(rumor.tags)).toEqual([["expiration", "1"]]);
      expect(expirationTags(wrap.tags)).toEqual([]);
    }
  });

  it("a malformed or absent community timer stamps nothing on the rumor or its wrap (CORD-08 §1)", async () => {
    const { signer, keys, channelId } = await plane();
    const target = { plane: "channel", channelId } as WrapTarget;
    const send = async (timer: unknown) => {
      const draft = { kind: 9, content: "x", tags: [["epoch", "0"]] };
      const { wrap } = await wrapForTarget(keys, target, signer, draft, { messageExpiration: timer as number });
      const opened = decodeWrap(structuredClone(wrap), keys.planes.get(wrap.pubkey)!.convKey)!;
      return { wrap, rumor: opened.rumor };
    };
    // Non-vacuity: the same path stamps both copies for a valid timer, so the empty results below come from the rule.
    const valid = await send(60);
    expect(expirationTags(valid.rumor.tags)).toEqual([["expiration", String(valid.rumor.created_at + 60)]]);
    expect(expirationTags(valid.wrap.tags)).toEqual(expirationTags(valid.rumor.tags));
    // A reader must not coerce garbage into a default: strings, booleans, containers, fractions and non-finite numbers
    // read as off, exactly like an absent or zero timer.
    for (const garbage of [undefined, null, 0, "60", "0", true, {}, [60], -60, 1.5, NaN, Infinity]) {
      const { wrap, rumor } = await send(garbage);
      expect({ garbage, rumor: expirationTags(rumor.tags), wrap: expirationTags(wrap.tags) }).toEqual({
        garbage,
        rumor: [],
        wrap: [],
      });
    }
  });

  it("judges the expiration tag by the library's strict rule (D-21)", () => {
    // applesauce-core stores judge the tag with their own lenient rule (documented in docs/guide/storage.md by plan
    // 04-02), so this test pins only the library's rule.
    const tagged = (tag: string[], kind = 9) => ({ kind, tags: [tag] });
    for (const tag of [["expiration", "10abc"], ["expiration", "2", "x"], ["expiration", "01"], ["expiration", "-1"]]) {
      expect(rumorExpiration(tagged(tag))).toBeUndefined();
    }
    for (const kind of [TIMER_NOTICE_KIND, TYPING_KIND]) {
      expect(rumorExpiration(tagged(["expiration", "1"], kind))).toBeUndefined();
      expect(isRumorExpired(tagged(["expiration", "1"], kind), 100)).toBe(false);
    }
    expect(isRumorExpired(tagged(["expiration", "0"]), 100)).toBe(true);
    expect(isRumorExpired(tagged(["expiration", "100"]), 100)).toBe(true);
    expect(isRumorExpired(tagged(["expiration", "101"]), 100)).toBe(false);
    expect(isRumorExpired(tagged(["expiration", "1"], 5), 100)).toBe(false);
  });

  it("rejects expired rumors before retention", async () => {
    const store = new RumorStore();
    try {
      await retainChannelInput(store, rumor());
      expect(store.getTimeline([{}])).toEqual([]);
    } finally {
      store.dispose();
    }
    // The upstream store refuses an expired rumor by its own rule, so a store with no expiry rule of its own shows
    // whether the library's gate holds: it must never be offered the rumor, and nothing may be noted for it.
    const offered: string[] = [];
    let noted = 0;
    const open = {
      add: (added: Rumor) => {
        offered.push(added.id);
        return Promise.resolve(added);
      },
    } as unknown as ConcordRumorStore;
    await retainChannelInput(open, rumor(), () => noted++);
    expect({ offered, noted }).toEqual({ offered: [], noted: 0 });
    // Non-vacuity: the same store is offered a live rumor and the callback runs for it.
    const live = rumor(9, 4_000_000_000);
    await retainChannelInput(open, live, () => noted++);
    expect({ offered, noted }).toEqual({ offered: [live.id], noted: 1 });
  });

  it("hides messages without new traffic and gates notices on changing authority", () => {
    const time = new FakeTime(1000);
    const store = new RumorStore();
    const allowed = new BehaviorSubject<(author: string) => boolean>(() => false);
    const bans = new BehaviorSubject<ReadonlySet<string>>(new Set());
    const values: Rumor[][] = [];
    const sub = ConcordChatTimelineModel(bans, [{}], allowed)(store).subscribe((value) => values.push(value));
    try {
      store.add(rumor());
      store.add(rumor(1740));
      expect(values.at(-1)).toHaveLength(1);
      time.tick(1000);
      expect(values.at(-1)).toHaveLength(0);
      allowed.next(() => true);
      expect(values.at(-1)?.[0].kind).toBe(1740);
      bans.next(new Set([rumor().pubkey]));
      expect(values.at(-1)).toHaveLength(0);
    } finally {
      sub.unsubscribe();
      store.dispose();
      time.restore();
    }
  });
});

it("copies author expiration onto the durable wrap and rechecks cached receives as time advances", async () => {
  const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
  const genesis = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "timer", relays: [] });
  const state = foldControl(genesis.controlRumors.map((r) => decoded(r, genesis.material.owner)), genesis.material);
  const keys = deriveConcordKeys(genesis.material, state.channels);
  const target = { plane: "channel" as const, channelId: genesis.generalChannelId };
  const draft = { kind: 9, content: "expires", tags: [["channel", target.channelId], ["epoch", "0"]] };
  const { wrap } = await wrapForTarget(keys, target, signer, draft, { messageExpiration: 60 });
  const expiration = wrap.tags.find((tag) => tag[0] === "expiration")?.[1];
  expect(expiration).toBeDefined();
  const info = keys.planes.get(wrap.pubkey)!;
  const decode = createReceiveDecoder();
  const opened = decode(wrap, info)!;
  expect(opened.rumor.tags).toContainEqual(["expiration", expiration!]);
  const time = new FakeTime(Number(expiration) * 1000);
  try {
    expect(decode(wrap, info)).toBeNull();
  } finally {
    time.restore();
  }
});
