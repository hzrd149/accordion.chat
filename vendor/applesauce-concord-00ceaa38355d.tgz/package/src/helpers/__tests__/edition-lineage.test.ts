import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import type { DecodedEvent } from "../../types.ts";
import { VSK } from "../../types.ts";
import { computeEditionHash } from "../editions.ts";
import {
  classifyEditionLineage,
  DEFAULT_EDITION_LINEAGE_DEPTH,
  editionAdditions,
  type EditionRef,
  walkEditionChain,
} from "../edition-lineage.ts";
import { decoded } from "./test-utils.ts";

const EID = "11".repeat(32);
const AUTHOR = "55".repeat(32);

interface Built {
  event: DecodedEvent;
  ref: EditionRef;
}

/** Build one edition; its link hash is computed with the hashing primitive, not the helper under test. */
function edition(version: number, prev: Built | undefined, content: string, eid = EID): Built {
  const prevHash = prev?.ref.hash;
  const tags = [["vsk", String(VSK.BANLIST)], ["eid", eid], ["ev", String(version)]];
  if (prevHash) tags.push(["ep", prevHash]);
  const hash = computeEditionHash({ vsk: VSK.BANLIST, eid, version, prevHash, content });
  return {
    event: decoded({ kind: 3308, content, tags }, AUTHOR),
    ref: { eid, version, hash, ...(prevHash ? { prevHash } : {}) },
  };
}

/** A chain v1..vN with content `["v<n>"]` per version. */
function chain(length: number): Built[] {
  const out: Built[] = [];
  for (let v = 1; v <= length; v++) out.push(edition(v, out[v - 2], JSON.stringify([`v${v}`])));
  return out;
}

const events = (built: Built[]): DecodedEvent[] => built.map((b) => b.event);

describe("classifyEditionLineage (FND-03, CORD-04 §1)", () => {
  it("classifies the head itself as an ancestor", () => {
    const c = chain(3);
    expect(classifyEditionLineage(c[2].ref, c[2].ref, events(c))).toEqual({ kind: "ancestor", depth: 0 });
  });

  it("classifies a deep ancestor through retained editions", () => {
    const c = chain(6);
    expect(classifyEditionLineage(c[1].ref, c[5].ref, events(c))).toEqual({ kind: "ancestor", depth: 4 });
    // the own edition itself does not need to be retained: the child's ep is the evidence
    expect(classifyEditionLineage(c[1].ref, c[5].ref, events(c.slice(2)))).toEqual({ kind: "ancestor", depth: 4 });
  });

  it("classifies a same-version loser as a lost sibling", () => {
    const c = chain(3);
    const rival = edition(3, c[1], JSON.stringify(["rival"]));
    expect(classifyEditionLineage(rival.ref, c[2].ref, events(c))).toEqual({ kind: "lost-sibling", depth: 0 });
  });

  it("classifies an earlier-version divergence as a lost sibling", () => {
    const c = chain(5);
    const rival = edition(2, c[0], JSON.stringify(["rival"]));
    expect(classifyEditionLineage(rival.ref, c[4].ref, events(c))).toEqual({ kind: "lost-sibling", depth: 3 });
  });

  it("returns unknown when a compacted predecessor is missing", () => {
    const c = chain(5);
    const compacted = [c[0], c[1], c[3], c[4]];
    expect(classifyEditionLineage(c[1].ref, c[4].ref, events(compacted))).toEqual({
      kind: "unknown",
      reason: "predecessor-missing",
      depth: 1,
    });
    // a head whose own record is not retained and which carries no prevHash cannot be walked either
    const bareHead: EditionRef = { eid: EID, version: 5, hash: c[4].ref.hash };
    expect(classifyEditionLineage(c[1].ref, bareHead, [])).toEqual({
      kind: "unknown",
      reason: "predecessor-missing",
      depth: 0,
    });
  });

  it("returns unknown beyond the depth cap", () => {
    const c = chain(8);
    expect(classifyEditionLineage(c[0].ref, c[7].ref, events(c), { maxDepth: 3 })).toEqual({
      kind: "unknown",
      reason: "depth-cap",
      depth: 0,
    });
    expect(classifyEditionLineage(c[0].ref, c[7].ref, events(c), { maxDepth: 7 })).toEqual({
      kind: "ancestor",
      depth: 7,
    });
    expect(DEFAULT_EDITION_LINEAGE_DEPTH).toBe(256);
    const far: EditionRef = { eid: EID, version: 1 + DEFAULT_EDITION_LINEAGE_DEPTH + 1, hash: "aa".repeat(32) };
    expect(classifyEditionLineage(c[0].ref, far, [])).toMatchObject({ kind: "unknown", reason: "depth-cap" });
  });

  it("returns unknown when the own edition is newer than the head", () => {
    const c = chain(4);
    expect(classifyEditionLineage(c[3].ref, c[1].ref, events(c))).toEqual({
      kind: "unknown",
      reason: "head-behind",
      depth: 0,
    });
  });

  it("returns unknown for editions of different entities", () => {
    const c = chain(3);
    const other = edition(2, undefined, "[]", "22".repeat(32));
    expect(classifyEditionLineage(other.ref, c[2].ref, events(c))).toEqual({
      kind: "unknown",
      reason: "entity-mismatch",
      depth: 0,
    });
  });

  it("does not trust a retained edition whose content does not hash to the cited link", () => {
    const c = chain(4);
    // v3 claims ep -> v2 but its content was tampered, so it no longer hashes to the link v4 cites
    const forged = decoded({
      kind: 3308,
      content: JSON.stringify(["forged"]),
      tags: [["vsk", String(VSK.BANLIST)], ["eid", EID], ["ev", "3"], ["ep", c[1].ref.hash]],
    }, AUTHOR);
    const retained = [c[0].event, c[1].event, forged, c[3].event];
    expect(classifyEditionLineage(c[1].ref, c[3].ref, retained)).toEqual({
      kind: "unknown",
      reason: "predecessor-missing",
      depth: 0,
    });
  });

  it("ignores duplicate copies of the same edition", () => {
    const c = chain(4);
    const once = classifyEditionLineage(c[0].ref, c[3].ref, events(c));
    const dup = classifyEditionLineage(c[0].ref, c[3].ref, [...events(c), ...events(c), c[2].event]);
    expect(dup).toEqual(once);
    expect(dup).toEqual({ kind: "ancestor", depth: 3 });
  });

  it("never throws on malformed editions", () => {
    const c = chain(3);
    const bad = (partial: Record<string, unknown>) => ({ rumor: { ...c[1].event.rumor, ...partial } }) as DecodedEvent;
    const retained = [
      ...events(c),
      bad({ tags: "nope" }),
      bad({ tags: [["eid", EID], ["ev", "2"], ["ep", "zz"]] }),
      bad({ tags: [["eid", EID], ["ev", "two"]] }),
      bad({ tags: [["eid", EID], ["ev", "2"], [1, 2]] }),
      bad({ content: 42 }),
      bad({ kind: 1 }),
      { rumor: undefined } as unknown as DecodedEvent,
    ];
    expect(classifyEditionLineage(c[0].ref, c[2].ref, retained)).toEqual({ kind: "ancestor", depth: 2 });
    const garbage = { eid: "nope", version: 1.5, hash: "x" } as EditionRef;
    expect(classifyEditionLineage(garbage, c[2].ref, retained)).toMatchObject({ kind: "unknown", reason: "malformed" });
    expect(classifyEditionLineage(c[0].ref, { ...c[2].ref, version: 0 }, retained)).toMatchObject({
      kind: "unknown",
      reason: "malformed",
    });
    expect(classifyEditionLineage(c[0].ref, { ...c[2].ref, prevHash: "zz" }, retained)).toMatchObject({
      kind: "unknown",
      reason: "malformed",
    });
  });
});

describe("editionAdditions (CORD-04 §4)", () => {
  const parse = (content: string): readonly string[] | undefined => {
    try {
      const value = JSON.parse(content);
      return Array.isArray(value) ? value : undefined;
    } catch {
      return undefined;
    }
  };

  it("reports additions against the predecessor", () => {
    const v1 = edition(1, undefined, JSON.stringify(["a", "b"]));
    const v2 = edition(2, v1, JSON.stringify(["a", "b", "c"]));
    expect(editionAdditions(v2.event, [v1.event, v2.event], parse)).toEqual({ predecessor: "found", added: ["c"] });
  });

  it("treats a first edition as adding every item", () => {
    const v1 = edition(1, undefined, JSON.stringify(["a", "b"]));
    expect(editionAdditions(v1.event, [], parse)).toEqual({ predecessor: "first", added: ["a", "b"] });
  });

  it("refuses to guess when the predecessor is missing", () => {
    const v1 = edition(1, undefined, JSON.stringify(["a"]));
    const v2 = edition(2, v1, JSON.stringify(["a", "c"]));
    expect(editionAdditions(v2.event, [], parse)).toEqual({ predecessor: "missing", added: [] });
    expect(editionAdditions(edition(2, v1, "not json").event, [v1.event], parse)).toEqual({
      predecessor: "malformed",
      added: [],
    });
  });
});

describe("walkEditionChain", () => {
  it("walkEditionChain returns the verified chain from the minimum version to the head", () => {
    const c = chain(5);
    // Retained in a scrambled order with a duplicate: the walk must not depend on arrival order.
    const retained = [c[3], c[0], c[4], c[2], c[1], c[2]].map((b) => b.event);
    const walked = walkEditionChain(c[4].ref, retained, { minVersion: 3 });
    expect(walked.complete).toBe(true);
    expect(walked.links).toEqual([
      { version: 3, hash: c[2].ref.hash, prevHash: c[1].ref.hash, content: JSON.stringify(["v3"]) },
      { version: 4, hash: c[3].ref.hash, prevHash: c[2].ref.hash, content: JSON.stringify(["v4"]) },
      { version: 5, hash: c[4].ref.hash, prevHash: c[3].ref.hash, content: JSON.stringify(["v5"]) },
    ]);
    // The default minimum is the first edition, whose link carries no prevHash.
    const whole = walkEditionChain(c[4].ref, events(c));
    expect(whole.complete).toBe(true);
    expect(whole.links.map((l) => l.version)).toEqual([1, 2, 3, 4, 5]);
    expect(whole.links[0].prevHash).toBeUndefined();
    // A minimum above the head clamps to the head itself.
    expect(walkEditionChain(c[4].ref, events(c), { minVersion: 99 }).links.map((l) => l.version)).toEqual([5]);
  });

  it("walkEditionChain reports incomplete when a link is missing or its hash does not match", () => {
    const c = chain(5);
    // Non-vacuity: a walker that trusted a claimed ep without re-hashing would accept the forged v4.
    expect(walkEditionChain(c[4].ref, events([c[0], c[1], c[2], c[4]]), { minVersion: 2 }).complete).toBe(false);
    const forged = decoded({
      kind: 3308,
      content: JSON.stringify(["forged"]),
      tags: [["vsk", String(VSK.BANLIST)], ["eid", EID], ["ev", "4"], ["ep", c[2].ref.hash]],
    }, AUTHOR);
    const withForged = walkEditionChain(c[4].ref, [c[0].event, c[1].event, c[2].event, forged, c[4].event]);
    expect(withForged.complete).toBe(false);
    // A head whose own record is not retained cannot be verified.
    expect(walkEditionChain(c[4].ref, events(c.slice(0, 4))).complete).toBe(false);
    // Entity mismatch: records of another entity are ignored.
    const other = chain(5).map((b) => edition(b.ref.version, undefined, "[]", "22".repeat(32)));
    expect(walkEditionChain(c[4].ref, events(other)).complete).toBe(false);
  });

  it("walkEditionChain stops at the depth cap and is total on garbage input", () => {
    const c = chain(8);
    expect(walkEditionChain(c[7].ref, events(c), { minVersion: 1, maxDepth: 3 }).complete).toBe(false);
    expect(walkEditionChain(c[7].ref, events(c), { minVersion: 5, maxDepth: 3 }).complete).toBe(true);
    expect(walkEditionChain(c[7].ref, events(c), { maxDepth: 7 }).links).toHaveLength(8);

    const bad = (partial: Record<string, unknown>) => ({ rumor: { ...c[1].event.rumor, ...partial } }) as DecodedEvent;
    const retained = [
      ...events(c),
      bad({ tags: "nope" }),
      bad({ tags: [["eid", EID], ["ev", "2"], ["ep", "zz"]] }),
      bad({ content: 42 }),
      { rumor: undefined } as unknown as DecodedEvent,
    ];
    expect(walkEditionChain(c[7].ref, retained).complete).toBe(true);
    const garbage = { eid: "nope", version: 1.5, hash: "x" } as EditionRef;
    expect(walkEditionChain(garbage, retained)).toEqual({ links: [], complete: false });
    expect(walkEditionChain(null as unknown as EditionRef, retained)).toEqual({ links: [], complete: false });
    expect(walkEditionChain(c[7].ref, null as unknown as Iterable<DecodedEvent>)).toEqual({
      links: [],
      complete: false,
    });
  });
});
