// CORD-03 §3 titled forum posts: the 256-byte subject cap on writes (D-03), display truncation of inbound subjects on
// a code-point boundary (D-04), and first-tag reading (FORUM-01, FORUM-02).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { ForumThreadFactory } from "applesauce-common/factories";

import { MULTIBYTE_ASTRAL_CHAR } from "../../__tests__/cord-wire-fixtures.ts";
import { assertSubject, SUBJECT_MAX_BYTES } from "../caps.ts";
import { channelViewMode, displaySubject, getSubject } from "../forum.ts";

const bytesOf = (value: string): number => new TextEncoder().encode(value).length;

describe("forum subjects (CORD-03 §3, FORUM-01, FORUM-02)", () => {
  it("assertSubject accepts exactly 256 UTF-8 bytes and rejects 257 with a RangeError (D-03)", () => {
    expect(SUBJECT_MAX_BYTES).toBe(256);
    expect(() => assertSubject("a".repeat(256))).not.toThrow();
    expect(() => assertSubject("a".repeat(257))).toThrow(RangeError);
    expect(() => assertSubject("")).not.toThrow();
  });

  it("assertSubject counts multibyte and astral characters in UTF-8 bytes", () => {
    // Two-byte (U+00E9), three-byte (U+20AC) and four-byte characters each land exactly on the cap.
    expect(() => assertSubject("é".repeat(128))).not.toThrow();
    expect(() => assertSubject("é".repeat(129))).toThrow(RangeError);
    expect(() => assertSubject("€".repeat(85) + "a")).not.toThrow();
    expect(() => assertSubject("€".repeat(86))).toThrow(RangeError);
    // 64 astral characters are 256 bytes although their `.length` is 128; 65 are over.
    expect(MULTIBYTE_ASTRAL_CHAR.repeat(64).length).toBe(128);
    expect(() => assertSubject(MULTIBYTE_ASTRAL_CHAR.repeat(64))).not.toThrow();
    expect(() => assertSubject(MULTIBYTE_ASTRAL_CHAR.repeat(65))).toThrow(RangeError);
  });

  it("assertSubject never echoes the subject in its error message", () => {
    const secret = "private-title-" + "x".repeat(300);
    let message = "";
    try {
      assertSubject(secret);
    } catch (error) {
      message = (error as Error).message;
    }
    expect(message).not.toBe("");
    expect(message).not.toContain("private-title");
    expect(message).toContain(String(bytesOf(secret)));
    expect(message).toContain("256");
  });

  it("displaySubject returns a subject within the cap unchanged", () => {
    expect(displaySubject("")).toBe("");
    expect(displaySubject("Hello")).toBe("Hello");
    const exact = "a".repeat(256);
    expect(displaySubject(exact)).toBe(exact);
    const astral = MULTIBYTE_ASTRAL_CHAR.repeat(64);
    expect(displaySubject(astral)).toBe(astral);
  });

  it("displaySubject truncates an overlong subject to 256 bytes on a code-point boundary with no ellipsis (D-04)", () => {
    const long = "a".repeat(400);
    const shown = displaySubject(long);
    expect(shown).toBe("a".repeat(256));
    expect(shown.endsWith("...")).toBe(false);
    expect(shown.endsWith("…")).toBe(false);

    // 70 astral characters are 280 bytes: the cut keeps 64 whole characters (256 bytes).
    const astral = MULTIBYTE_ASTRAL_CHAR.repeat(70);
    const cut = displaySubject(astral);
    expect(cut).toBe(MULTIBYTE_ASTRAL_CHAR.repeat(64));
    expect(long.startsWith(shown)).toBe(true);
    expect(astral.startsWith(cut)).toBe(true);

    // One ASCII byte shifts the astral boundary: 255 ASCII bytes leave room for no whole 4-byte character.
    const shifted = "a".repeat(255) + MULTIBYTE_ASTRAL_CHAR;
    expect(displaySubject(shifted)).toBe("a".repeat(255));
  });

  it("displaySubject never splits a four-byte character at any cut position", () => {
    const subject = "ab" + MULTIBYTE_ASTRAL_CHAR.repeat(5) + "cd";
    const total = bytesOf(subject);
    for (let max = 0; max <= total + 2; max++) {
      const shown = displaySubject(subject, max);
      const encoded = new TextEncoder().encode(shown);
      expect(encoded.length).toBeLessThanOrEqual(max);
      expect(subject.startsWith(shown)).toBe(true);
      // Valid UTF-8: a strict decode round-trips and the string holds no replacement character.
      expect(new TextDecoder("utf-8", { fatal: true }).decode(encoded)).toBe(shown);
      expect(shown.includes("�")).toBe(false);
      // The cut is the largest prefix that fits: adding the next code point would exceed the cap.
      if (shown.length < subject.length) {
        const next = String.fromCodePoint(subject.codePointAt(shown.length)!);
        expect(bytesOf(shown + next)).toBeGreaterThan(max);
      }
    }
  });

  it("displaySubject is total for lone surrogates and custom caps", () => {
    const lone = "ab\ud800cd";
    expect(() => displaySubject(lone)).not.toThrow();
    expect(() => displaySubject(lone, 4)).not.toThrow();
    expect(typeof displaySubject(lone, 3)).toBe("string");
    expect(displaySubject("hello", 3)).toBe("hel");
    expect(displaySubject("hello", 0)).toBe("");
    expect(displaySubject("hello", -5)).toBe("");
    expect(displaySubject("hello", Number.NaN)).toBe("");
  });

  it("getSubject reads the first subject tag and ignores malformed tags", () => {
    expect(getSubject({ tags: [["subject", "First"], ["subject", "Second"]] })).toBe("First");
    expect(getSubject({ tags: [["t", "x"]] })).toBeUndefined();
    expect(getSubject({ tags: [] })).toBeUndefined();
    expect(getSubject({})).toBeUndefined();
    // Malformed entries are skipped, never thrown on; a later well-formed subject still reads.
    const malformed = ["nope", null, 7, [], ["subject"], ["subject", 5], ["subject", "Kept"]];
    expect(getSubject({ tags: malformed })).toBe("Kept");
    expect(getSubject({ tags: "not-an-array" })).toBeUndefined();
    expect(getSubject({ tags: [["subject", ""]] })).toBe("");
  });

  // Non-vacuity: a reader of `subject` alone renders every retained legacy thread untitled, because kind 11 roots carry
  // the NIP-7D `title` tag; the fallback is scoped to kind 11 so a kind 9 `title` tag never becomes a forum title.
  it("getSubject falls back to the title tag of a legacy kind 11 thread root (FORUM-05, D-08)", async () => {
    const root = await ForumThreadFactory.create("Legacy title", "legacy body");
    expect(root.kind).toBe(11);
    expect(getSubject(root)).toBe("Legacy title");
    expect(getSubject({ kind: 11, tags: [["title", "Old"], ["subject", "New"]] })).toBe("New");
    expect(getSubject({ kind: 11, tags: [["title", 5], ["title", "Kept"]] })).toBe("Kept");
    expect(getSubject({ kind: 9, tags: [["title", "Not a forum title"]] })).toBeUndefined();
    expect(getSubject({ kind: 11, tags: [] })).toBeUndefined();
  });
});

describe("channel view mode (CORD-03 §2, FORUM-03)", () => {
  it("channelViewMode presents forum only for the exact value and chat for anything else (D-05)", () => {
    expect(channelViewMode({ view: "forum" })).toBe("forum");
    expect(channelViewMode({ view: "chat" })).toBe("chat");
    expect(channelViewMode({})).toBe("chat");
    for (const view of ["Forum", "FORUM", " forum", "kanban", "", 7, null, {}, ["forum"], true]) {
      expect(channelViewMode({ view })).toBe("chat");
    }
    expect(channelViewMode(undefined)).toBe("chat");
  });
});
