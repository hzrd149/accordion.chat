import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { PrivateKeySigner } from "applesauce-signers";
import { getEventHash } from "applesauce-core/helpers/event";
import { hexToBytes } from "@noble/hashes/utils.js";

import { EditionFactory } from "../../factories/control.ts";
import { sealRumor } from "../../operations/gift-wrap.ts";
import { createCommunity } from "../community.ts";
import { foldControl } from "../control.ts";
import { banlistLocator, grantLocator, pinsLocator } from "../crypto.ts";
import { computeEditionHash } from "../editions.ts";
import {
  type CommunityState,
  type ControlVerification,
  type DecodedEvent,
  PERM,
  type Rumor,
  type VerifiedControlHead,
  VSK,
} from "../../types.ts";
import {
  canEditionEverVerify,
  isEditionRejectedByStanding,
  type PinUpkeepInput,
  pinWriteReadiness,
  type PinWriteReadinessInput,
  planPinUpkeep,
  rejectedChainBase,
} from "../pin-upkeep.ts";
import {
  createPinProof,
  encodePinList,
  type PinEntry,
  type PinListRead,
  type PinProof,
  verifyPinEntry,
} from "../pins.ts";
import { decoded } from "./test-utils.ts";

const EID = "ab".repeat(32);

function head(vsk: number = VSK.PINS): VerifiedControlHead {
  return { vsk, eid: EID, version: 3, hash: "cd".repeat(32), edition: {} as DecodedEvent };
}

function verification(patch: Partial<ControlVerification> = {}): ControlVerification {
  return {
    communityId: "ef".repeat(32),
    heads: new Map(),
    grantHistory: new Map(),
    suspended: new Set(),
    pending: [],
    removals: new Map(),
    ...patch,
  };
}

function input(patch: Partial<PinWriteReadinessInput> = {}): PinWriteReadinessInput {
  return {
    phase: "live",
    eid: EID,
    verification: verification(),
    retained: () => false,
    listAvailable: false,
    ...patch,
  };
}

describe("pinWriteReadiness", () => {
  it("pinWriteReadiness proves absence only when live with no head, suspension, pending evidence or retained edition", () => {
    expect(pinWriteReadiness(input())).toEqual({ ready: true });
    for (const phase of ["idle", "syncing", "removed", "error"] as const) {
      expect(pinWriteReadiness(input({ phase }))).toEqual({ ready: false, reason: "not-synced" });
    }
    // Each absence blocker alone must flip the answer; otherwise a branch could be dead.
    expect(pinWriteReadiness(input({ verification: undefined }))).toEqual({ ready: false, reason: "not-synced" });
    // While live, a known but unverified edition is not a sync gap: it is reported as such so apps stop retrying (D-33).
    expect(pinWriteReadiness(input({ displayHeads: new Map([[EID, {} as DecodedEvent]]) }))).toEqual({
      ready: false,
      reason: "unverified-edition",
    });
    expect(pinWriteReadiness(input({ displayHeads: new Map([["00".repeat(32), {} as DecodedEvent]]) }))).toEqual({
      ready: true,
    });
    for (const reason of ["chain-gap", "support-cycle"] as const) {
      expect(pinWriteReadiness(input({ verification: verification({ pending: [{ eid: EID, reason }] }) }))).toEqual({
        ready: false,
        reason: "unverified-edition",
      });
    }
    expect(
      pinWriteReadiness(
        input({ verification: verification({ pending: [{ eid: "00".repeat(32), reason: "chain-gap" }] }) }),
      ),
    ).toEqual({ ready: true });
    expect(pinWriteReadiness(input({ retained: (eid) => eid === EID }))).toEqual({
      ready: false,
      reason: "unverified-edition",
    });
    const verified = head();
    expect(
      pinWriteReadiness(
        input({ verification: verification({ heads: new Map([[EID, verified]]) }), listAvailable: true }),
      ),
    ).toEqual({ ready: true, head: verified });
  });

  it("pinWriteReadiness ignores Grant-citation evidence filed under the Pin List coordinate (D-33)", () => {
    // missing-pin and pin-mismatch evidence names the cited Grant coordinate. A forged `vac` citing the Pin List
    // coordinate itself files such evidence under it; that is never evidence the Pin List exists.
    for (const reason of ["missing-pin", "pin-mismatch"] as const) {
      expect(pinWriteReadiness(input({ verification: verification({ pending: [{ eid: EID, reason }] }) }))).toEqual({
        ready: true,
      });
    }
  });

  it("pinWriteReadiness refuses an unreadable head", () => {
    const heads = new Map([[EID, head()]]);
    expect(pinWriteReadiness(input({ verification: verification({ heads }), listAvailable: false }))).toEqual({
      ready: false,
      reason: "unreadable",
    });
    const wrongType = new Map([[EID, head(VSK.CHANNEL)]]);
    expect(pinWriteReadiness(input({ verification: verification({ heads: wrongType }), listAvailable: true }))).toEqual(
      {
        ready: false,
        reason: "unreadable",
      },
    );
  });

  it("pinWriteReadiness reports suspended entities", () => {
    const heads = new Map([[EID, head()]]);
    expect(
      pinWriteReadiness(
        input({ verification: verification({ heads, suspended: new Set([EID]) }), listAvailable: true }),
      ),
    ).toEqual({ ready: false, reason: "suspended" });
    // Not-live wins over suspended: nothing is decided before the community is live.
    expect(
      pinWriteReadiness(input({ phase: "syncing", verification: verification({ suspended: new Set([EID]) }) })),
    ).toEqual({ ready: false, reason: "not-synced" });
  });
});

describe("canEditionEverVerify", () => {
  const OWNER = "11".repeat(32);
  const STAFF = "22".repeat(32);
  const OTHER = "33".repeat(32);
  const COMMUNITY = "ef".repeat(32);
  const ownGrant = grantLocator(hexToBytes(COMMUNITY), STAFF);
  const HASH = "cd".repeat(32);

  /** A retained Pin List edition by `author`, with extra tags such as a `vac` citation. */
  function edition(author: string, tags: string[][] = []): DecodedEvent {
    const rumor = {
      pubkey: author,
      id: "",
      kind: 3308,
      content: "",
      tags: [["vsk", String(VSK.PINS)], ["eid", EID], ["ev", "1"], ...tags],
      created_at: 10,
    };
    rumor.id = getEventHash(rumor);
    return { rumor, author, wrapId: "00".repeat(32), sealKind: 20014, ms: 0 };
  }

  const verify = (decoded: DecodedEvent) => canEditionEverVerify(decoded, OWNER, COMMUNITY);

  it("canEditionEverVerify keeps owner editions and well-formed citations of the author's own Grant (D-33)", () => {
    // The owner needs no citation, and the fold ignores any it carries, so its edition may always verify.
    expect(verify(edition(OWNER))).toBe(true);
    expect(verify(edition(OWNER, [["vac", "nonsense"]]))).toBe(true);
    // A well-formed citation of the author's own Grant may verify once that Grant syncs.
    expect(verify(edition(STAFF, [["vac", ownGrant, "1", HASH]]))).toBe(true);
    expect(verify(edition(STAFF, [["vac", ownGrant, "12", HASH]]))).toBe(true);
  });

  it("canEditionEverVerify rejects non-owner editions with no vac tag or a malformed one (D-33)", () => {
    expect(verify(edition(STAFF))).toBe(false);
    expect(verify(edition(STAFF, [["vac"]]))).toBe(false);
    expect(verify(edition(STAFF, [["vac", ownGrant, "1"]]))).toBe(false);
    expect(verify(edition(STAFF, [["vac", ownGrant, "1", HASH, "extra"]]))).toBe(false);
    for (const version of ["0", "01", "-1", "1.0", "x", ""]) {
      expect(verify(edition(STAFF, [["vac", ownGrant, version, HASH]]))).toBe(false);
    }
    for (const hash of ["cd", "zz".repeat(32), HASH.toUpperCase(), ""]) {
      expect(verify(edition(STAFF, [["vac", ownGrant, "1", hash]]))).toBe(false);
    }
    // Only the first vac tag counts, as in the fold: a later well-formed one cannot rescue a malformed first one.
    expect(verify(edition(STAFF, [["vac", ownGrant, "1"], ["vac", ownGrant, "1", HASH]]))).toBe(false);
  });

  it("canEditionEverVerify rejects a citation of any coordinate other than the author's own Grant (D-33)", () => {
    expect(verify(edition(STAFF, [["vac", grantLocator(hexToBytes(COMMUNITY), OTHER), "1", HASH]]))).toBe(false);
    expect(verify(edition(STAFF, [["vac", EID, "1", HASH]]))).toBe(false);
    expect(verify(edition(STAFF, [["vac", ownGrant.toUpperCase(), "1", HASH]]))).toBe(false);
  });
});

const OWNER_PK = "12".repeat(32);
const CURATOR = "34".repeat(32);
const ROLE_ID = "56".repeat(32);

/**
 * A community whose general channel's only Pin List edition is version 1 by a curator holding `PIN_MESSAGES` through
 * an owner Grant, with a correct `vac`; the owner's seeded list is dropped, as for a channel the curator created.
 */
async function curatorChain() {
  const genesis = await createCommunity({ ownerPubkey: OWNER_PK, name: "T", relays: ["wss://r"] });
  const cidHex = genesis.material.community_id;
  const cid = hexToBytes(cidHex);
  const eid = pinsLocator(cid, genesis.generalChannelId);
  const grantEid = grantLocator(cid, CURATOR);
  const base = genesis.controlRumors.filter((r) => !r.tags.some((t) => t[0] === "eid" && t[1] === eid));
  const role = await EditionFactory.create({
    vsk: VSK.ROLE,
    eid: ROLE_ID,
    version: 1,
    content: JSON.stringify({
      name: "curator",
      position: 2,
      permissions: PERM.PIN_MESSAGES.toString(),
      scope: { kind: "server" },
      color: 0,
    }),
  });
  const grantContent = JSON.stringify({ member: CURATOR, role_ids: [ROLE_ID] });
  const grant = await EditionFactory.create({ vsk: VSK.GRANT, eid: grantEid, version: 1, content: grantContent });
  const grantHash = computeEditionHash({ vsk: VSK.GRANT, eid: grantEid, version: 1, content: grantContent });
  const events = [...base, role, grant].map((r) => decoded(r, OWNER_PK));
  const pinContent = encodePinList([]);
  const pin = decoded(
    await EditionFactory.create({
      vsk: VSK.PINS,
      eid,
      version: 1,
      content: pinContent,
      vac: [grantEid, "1", grantHash],
    }),
    CURATOR,
    2_000,
  );
  const pinHash = computeEditionHash({ vsk: VSK.PINS, eid, version: 1, content: pinContent });
  const ban = decoded(
    await EditionFactory.create({
      vsk: VSK.BANLIST,
      eid: banlistLocator(cid),
      version: 1,
      content: JSON.stringify([CURATOR]),
    }),
    OWNER_PK,
    3_000,
  );
  const demoteContent = JSON.stringify({ member: CURATOR, role_ids: [] });
  const demote = decoded(
    await EditionFactory.create({
      vsk: VSK.GRANT,
      eid: grantEid,
      version: 2,
      prevHash: grantHash,
      content: demoteContent,
    }),
    OWNER_PK,
    3_000,
  );
  const demoteHash = computeEditionHash({
    vsk: VSK.GRANT,
    eid: grantEid,
    version: 2,
    prevHash: grantHash,
    content: demoteContent,
  });
  const repromote = decoded(
    await EditionFactory.create({
      vsk: VSK.GRANT,
      eid: grantEid,
      version: 3,
      prevHash: demoteHash,
      content: grantContent,
    }),
    OWNER_PK,
    5_000,
  );
  return { genesis, cidHex, eid, grantEid, grantHash, events, pin, pinHash, ban, demote, repromote };
}

/** Whether a retained edition still blocks a first Pin List write, as the client judges it (D-33, D-34). */
function blocks(edition: DecodedEvent, state: CommunityState): boolean {
  return canEditionEverVerify(edition, state.material.owner, state.material.community_id) &&
    !isEditionRejectedByStanding(edition, state);
}

describe("standing-rejected Pin List editions (D-34)", () => {
  it("a banned or demoted curator's only Pin List edition no longer blocks a first write (D-34)", async () => {
    // Non-vacuity: without isEditionRejectedByStanding the curator's well-formed citation keeps blocking every writer,
    // the owner included, with unverified-edition (review iteration 3, WR-01).
    const { genesis, eid, events, pin, ban, demote } = await curatorChain();
    const staffed = foldControl([...events, pin], genesis.material);
    expect(staffed.controlVerification!.heads.get(eid)?.edition.author).toBe(CURATOR);
    expect(isEditionRejectedByStanding(pin, staffed)).toBe(false);
    for (const removal of [ban, demote]) {
      const all = [...events, pin, removal];
      const state = foldControl(all, genesis.material);
      const verification = state.controlVerification!;
      expect(verification.heads.has(eid)).toBe(false);
      expect(canEditionEverVerify(pin, OWNER_PK, genesis.material.community_id)).toBe(true);
      expect(isEditionRejectedByStanding(pin, state)).toBe(true);
      expect(pinWriteReadiness({
        phase: "live",
        eid,
        verification,
        displayHeads: state.heads,
        retained: (id) => all.some((e) => e.rumor.tags.some((t) => t[0] === "eid" && t[1] === id) && blocks(e, state)),
        listAvailable: false,
      })).toEqual({ ready: true });
    }
  });

  it("a citation of a Grant that has not synced still blocks a first write (D-34)", async () => {
    const { genesis, eid, events, grantEid } = await curatorChain();
    const withoutGrant = events.filter((e) => !e.rumor.tags.some((t) => t[0] === "eid" && t[1] === grantEid));
    const unsynced = decoded(
      await EditionFactory.create({
        vsk: VSK.PINS,
        eid,
        version: 1,
        content: encodePinList([]),
        vac: [grantEid, "1", "cd".repeat(32)],
      }),
      CURATOR,
      2_000,
    );
    const state = foldControl([...withoutGrant, unsynced], genesis.material);
    expect(state.controlVerification!.heads.has(eid)).toBe(false);
    expect(isEditionRejectedByStanding(unsynced, state)).toBe(false);
    expect(blocks(unsynced, state)).toBe(true);
    // A citation whose hash does not match the synced Grant parks like an unsynced one (CORD-04 §5).
    const mismatched = foldControl([...events, unsynced], genesis.material);
    expect(mismatched.controlVerification!.heads.has(eid)).toBe(false);
    expect(isEditionRejectedByStanding(unsynced, mismatched)).toBe(false);
  });

  it("rejectedChainBase names the highest standing-rejected edition and never an owner or unverifiable one (D-34)", async () => {
    const { genesis, eid, events, pin, pinHash, ban } = await curatorChain();
    const state = foldControl([...events, pin, ban], genesis.material);
    expect(rejectedChainBase([pin], eid, state)).toEqual({ version: 1, hash: pinHash });
    // A forged edition with no citation at a higher version is never chained over.
    const forged = decoded(
      await EditionFactory.create({ vsk: VSK.PINS, eid, version: 9, content: encodePinList([]) }),
      CURATOR,
      2_500,
    );
    expect(rejectedChainBase([pin, forged], eid, state)).toEqual({ version: 1, hash: pinHash });
    // An owner edition is never rejected by standing, so it is never a chain base either.
    const owned = decoded(
      await EditionFactory.create({ vsk: VSK.PINS, eid, version: 5, content: encodePinList([]) }),
      OWNER_PK,
      2_500,
    );
    expect(rejectedChainBase([owned, pin], eid, state)).toEqual({ version: 1, hash: pinHash });
    expect(rejectedChainBase([pin], "00".repeat(32), state)).toBeUndefined();
    // While the curator still stands nothing is rejected.
    expect(rejectedChainBase([pin], eid, foldControl([...events, pin], genesis.material))).toBeUndefined();
  });

  it("an owner Pin List chained over a rejected edition stays the head when the curator is restored (D-34)", async () => {
    // A fresh version 1 would tie with the curator's version 1 once the curator stands again and could lose the
    // rumor-id tiebreak; a chained version 2 climbs past it on every client (CORD-04 §1).
    const { genesis, eid, events, pin, pinHash, demote, repromote } = await curatorChain();
    const owner = decoded(
      await EditionFactory.create({ vsk: VSK.PINS, eid, version: 2, prevHash: pinHash, content: encodePinList([]) }),
      OWNER_PK,
      4_000,
    );
    const demoted = foldControl([...events, pin, demote, owner], genesis.material);
    expect(demoted.controlVerification!.heads.get(eid)?.edition.author).toBe(OWNER_PK);
    expect(demoted.controlVerification!.suspended.has(eid)).toBe(false);
    const restored = foldControl([...events, pin, demote, repromote, owner], genesis.material);
    expect(restored.controlVerification!.heads.get(eid)?.edition.author).toBe(OWNER_PK);
    expect(restored.controlVerification!.heads.get(eid)?.version).toBe(2);
    // A client that has not yet seen the demotion also lands on the owner's head.
    const unaware = foldControl([...events, pin, owner], genesis.material);
    expect(unaware.controlVerification!.heads.get(eid)?.edition.author).toBe(OWNER_PK);
  });
});

const CHANNEL = "ab".repeat(32);
const CONV_KEY = new Uint8Array(32).fill(2);
const author = new PrivateKeySigner(new Uint8Array(32).fill(1));
const authorPubkey = await author.getPublicKey();

/** A proven pinned message, optionally carrying extra rumor tags such as an expiration. */
async function pinnedMessage(content: string, tags: string[][] = []): Promise<{ rumor: Rumor; entry: PinEntry }> {
  const rumor = {
    pubkey: authorPubkey,
    id: "",
    kind: 9,
    content,
    tags: [["channel", CHANNEL], ["epoch", "0"], ...tags],
    created_at: 10,
  };
  rumor.id = getEventHash(rumor);
  const seal = await sealRumor(CONV_KEY, author)(rumor);
  return { rumor, entry: createPinProof(seal, CONV_KEY) as PinEntry };
}

/** A kind-5 deletion of `target` signed by `pubkey` (the author unless stated). */
function deletion(target: Rumor, pubkey: string = authorPubkey): Rumor {
  const base = { pubkey, id: "", kind: 5, content: "", tags: [["e", target.id]], created_at: 20 };
  return { ...base, id: getEventHash(base) };
}

function planInput(entries: PinEntry[], rumors: Rumor[], patch: Partial<PinUpkeepInput> = {}): PinUpkeepInput {
  return {
    channelId: CHANNEL,
    list: { available: true, entries },
    headForm: { form: "public" },
    channelPrivate: false,
    rumors,
    ...patch,
  };
}

describe("planPinUpkeep", () => {
  it("planPinUpkeep omits self-deleted entries and keeps the rest verbatim in head order", async () => {
    const a = await pinnedMessage("a");
    const b = await pinnedMessage("b");
    const c = await pinnedMessage("c");
    const plan = planPinUpkeep(planInput([a.entry, b.entry, c.entry], [deletion(b.rumor)]));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.stage).toBe("pin-omission");
    expect(plan.form).toBe("public");
    expect(plan.entries).toHaveLength(2);
    // Reference equality keeps the proof bytes byte-identical to what the head carried.
    expect(plan.entries[0]).toBe(a.entry);
    expect(plan.entries[1]).toBe(c.entry);
    expect(plan.omitted).toEqual([b.rumor.id]);
    expect(plan.affected).toEqual([b.rumor.id]);
    expect(plan.refreshed).toEqual([]);
    for (const entry of plan.entries) expect(verifyPinEntry(entry, CHANNEL)).toBeDefined();
    // Only the proven author's deletion counts.
    const stranger = planPinUpkeep(planInput([a.entry, b.entry], [deletion(b.rumor, "00".repeat(32))]));
    expect(stranger).toEqual({ kind: "none" });
  });

  // Non-vacuity: in planPinUpkeep, count a kept entry whose verified `expiresAt` is at or before
  // `Math.floor(Date.now() / 1000)` as omitted (expiry shaping an omission, the D-02 bug). The assertions that the
  // expired entry is in the rewrite (reference-equal) and absent from `omitted` then fail.
  it("an omission rewrite carries an expired pin verbatim (D-02)", async () => {
    const expired = await pinnedMessage("stale", [["expiration", "1000"]]);
    const doomed = await pinnedMessage("doomed");
    expect(verifyPinEntry(expired.entry, CHANNEL)?.expiresAt).toBe(1000);
    const plan = planPinUpkeep(planInput([expired.entry, doomed.entry], [deletion(doomed.rumor)]));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.entries).toHaveLength(1);
    expect(plan.entries[0]).toBe(expired.entry);
    expect(plan.omitted).toEqual([doomed.rumor.id]);
    expect(plan.omitted).not.toContain(expired.rumor.id);
    // Expiry alone never creates a duty: there is no time input to plan from.
    expect(planPinUpkeep(planInput([expired.entry], []))).toEqual({ kind: "none" });
  });

  it("planPinUpkeep never re-forms a sealed head as public on a public channel", async () => {
    const a = await pinnedMessage("a");
    const b = await pinnedMessage("b");
    const sealed = { headForm: { form: "sealed", epoch: "1" } as const };
    const due = planPinUpkeep(planInput([a.entry, b.entry], [deletion(b.rumor)], sealed));
    expect(due).toEqual({ kind: "blocked", stage: "pin-omission", reason: "private-era-list", affected: [b.rumor.id] });
    expect(planPinUpkeep(planInput([a.entry, b.entry], [], sealed))).toEqual({ kind: "none" });
  });

  it("planPinUpkeep seals rewrites for a private channel only with a held current key", async () => {
    const a = await pinnedMessage("a");
    const b = await pinnedMessage("b");
    const privateChannel = { channelPrivate: true };
    const withKey = planPinUpkeep(
      planInput([a.entry, b.entry], [deletion(b.rumor)], { ...privateChannel, sealKeyEpoch: 3 }),
    );
    if (withKey.kind !== "rewrite") throw new Error(`expected a rewrite, got ${withKey.kind}`);
    expect(withKey.form).toBe("sealed");
    expect(withKey.entries).toEqual([a.entry]);
    expect(planPinUpkeep(planInput([a.entry, b.entry], [deletion(b.rumor)], privateChannel))).toEqual({
      kind: "none",
    });
    expect(planPinUpkeep(planInput([a.entry, b.entry], [], { ...privateChannel, sealKeyEpoch: 3 }))).toEqual({
      kind: "none",
    });
  });

  it("planPinUpkeep plans nothing for an unavailable or empty list", async () => {
    const a = await pinnedMessage("a");
    const unavailable: PinListRead = { available: false };
    expect(planPinUpkeep({ ...planInput([], [deletion(a.rumor)]), list: unavailable })).toEqual({ kind: "none" });
    expect(planPinUpkeep(planInput([], [deletion(a.rumor)]))).toEqual({ kind: "none" });
    expect(planPinUpkeep(planInput([a.entry], []))).toEqual({ kind: "none" });
    // An entry that fails verification is dropped from a rewrite but never triggers one.
    const broken = { ...a.entry, keys: "00".repeat(76) };
    expect(planPinUpkeep(planInput([broken], []))).toEqual({ kind: "none" });
    const b = await pinnedMessage("b");
    const plan = planPinUpkeep(planInput([broken, b.entry], [deletion(b.rumor)]));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.entries).toEqual([]);
  });
});

interface ProvableEdit {
  rumor: Rumor;
  proof: PinProof;
}

/** A signed Edit of `target` at `ms` milliseconds after second 1000, with the proof a refresh would bundle. */
async function editOf(target: Rumor, text: string, ms: number, tags: string[][] = []): Promise<ProvableEdit> {
  const rumor = {
    pubkey: authorPubkey,
    id: "",
    kind: 3302,
    content: text,
    tags: [["e", target.id], ["channel", CHANNEL], ["epoch", "0"], ["ms", String(ms % 1000)], ...tags],
    created_at: 1000 + Math.floor(ms / 1000),
  };
  rumor.id = getEventHash(rumor);
  return { rumor, proof: createPinProof(await sealRumor(CONV_KEY, author)(rumor), CONV_KEY) };
}

/** An `editProof` callback that proves only the given Edits and records every Edit it was asked about. */
function provers(...provable: ProvableEdit[]) {
  const asked: string[] = [];
  const editProof: NonNullable<PinUpkeepInput["editProof"]> = (_pin, edit) => {
    asked.push(edit.content);
    return provable.find((candidate) => candidate.rumor.id === edit.id)?.proof;
  };
  return { editProof, asked };
}

describe("planPinUpkeep edit-proof refresh", () => {
  it("a refresh replaces only the entry's edit bundle with a verified proof", async () => {
    const a = await pinnedMessage("a");
    const entry = { ...a.entry, wrap: "ab".repeat(32), future: { kept: true } } as PinEntry;
    const e1 = await editOf(a.rumor, "a, corrected", 5_000);
    const { editProof } = provers(e1);
    const plan = planPinUpkeep(planInput([entry], [e1.rumor], { editProof }));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.stage).toBe("pin-edit-refresh");
    expect(plan.form).toBe("public");
    expect(plan.refreshed).toEqual([a.rumor.id]);
    expect(plan.affected).toEqual([a.rumor.id]);
    expect(plan.omitted).toEqual([]);
    expect(plan.entries).toEqual([{ ...entry, edit: e1.proof }]);
    // Seal, keys, wrap hint and unknown fields are the carried objects, not copies of changed bytes.
    expect(plan.entries[0].seal).toBe(entry.seal);
    expect((plan.entries[0] as PinEntry & { future: unknown }).future).toBe(
      (entry as PinEntry & { future: unknown }).future,
    );
    expect(verifyPinEntry(plan.entries[0], CHANNEL)?.edit?.id).toBe(e1.rumor.id);

    // Newest first: when the newest is unprovable the next newest provable Edit is used.
    const e2 = await editOf(a.rumor, "a, corrected twice", 6_000);
    const e3 = await editOf(a.rumor, "a, corrected thrice", 7_000);
    const fallback = provers(e2);
    const second = planPinUpkeep(planInput([entry], [e1.rumor, e2.rumor, e3.rumor], { editProof: fallback.editProof }));
    if (second.kind !== "rewrite") throw new Error(`expected a rewrite, got ${second.kind}`);
    expect(fallback.asked).toEqual(["a, corrected thrice", "a, corrected twice"]);
    expect(verifyPinEntry(second.entries[0], CHANNEL)?.edit?.id).toBe(e2.rumor.id);
  });

  // Non-vacuity: drop the "strictly newer than the bundled Edit" test so any provable candidate is attached. The entry
  // that already bundles e2 is then rewritten to e1 (a regression) and the none assertions fail.
  it("planPinUpkeep never attaches an Edit that is not strictly newer than the bundled one", async () => {
    const a = await pinnedMessage("a");
    const e1 = await editOf(a.rumor, "older", 5_000);
    const e2 = await editOf(a.rumor, "bundled", 6_000);
    const bundled = { ...a.entry, edit: e2.proof } as PinEntry;
    const spy = provers(e1, e2);
    // Older and equal candidates only: nothing to do, and the prover is never even asked.
    expect(planPinUpkeep(planInput([bundled], [e1.rumor, e2.rumor], { editProof: spy.editProof }))).toEqual({
      kind: "none",
    });
    expect(spy.asked).toEqual([]);
    // A strictly newer candidate is attached over the bundled one.
    const e3 = await editOf(a.rumor, "newest", 7_000);
    const newer = provers(e3);
    const plan = planPinUpkeep(planInput([bundled], [e1.rumor, e2.rumor, e3.rumor], { editProof: newer.editProof }));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(verifyPinEntry(plan.entries[0], CHANNEL)?.edit?.id).toBe(e3.rumor.id);
    // Equal time resolves to the lower recomputed id, as everywhere else: the higher id is not newer.
    const tieA = await editOf(a.rumor, "tie a", 8_000);
    const tieB = await editOf(a.rumor, "tie b", 8_000);
    const [lower, higher] = tieA.rumor.id < tieB.rumor.id ? [tieA, tieB] : [tieB, tieA];
    const tied = provers(lower, higher);
    expect(
      planPinUpkeep(planInput([{ ...a.entry, edit: lower.proof } as PinEntry], [higher.rumor], {
        editProof: tied.editProof,
      })),
    ).toEqual({ kind: "none" });
    expect(tied.asked).toEqual([]);
  });

  it("planPinUpkeep keeps the bundle when no newer Edit is provable", async () => {
    const a = await pinnedMessage("a");
    const e1 = await editOf(a.rumor, "unprovable", 5_000);
    const none = provers();
    expect(planPinUpkeep(planInput([a.entry], [e1.rumor], { editProof: none.editProof }))).toEqual({ kind: "none" });
    expect(none.asked).toEqual(["unprovable"]);
    // Without a prover at all there is nothing to refresh with.
    expect(planPinUpkeep(planInput([a.entry], [e1.rumor]))).toEqual({ kind: "none" });
  });

  it("planPinUpkeep never bundles an expired or banned author's Edit", async () => {
    const a = await pinnedMessage("a");
    const e1 = await editOf(a.rumor, "valid and older", 5_000);
    const e2 = await editOf(a.rumor, "expired in the middle", 6_000, [["expiration", "1500"]]);
    const e3 = await editOf(a.rumor, "newest but unprovable", 7_000);
    const spy = provers(e1, e2);
    const plan = planPinUpkeep(
      planInput([a.entry], [e1.rumor, e2.rumor, e3.rumor], { editProof: spy.editProof, now: 2_000 }),
    );
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    // The expired Edit is never even a candidate, so it is never asked about and never bundled.
    expect(spy.asked).toEqual(["newest but unprovable", "valid and older"]);
    expect(verifyPinEntry(plan.entries[0], CHANNEL)?.edit?.id).toBe(e1.rumor.id);

    const banned = provers(e1);
    expect(
      planPinUpkeep(planInput([a.entry], [e1.rumor], { editProof: banned.editProof, isBanned: () => true })),
    ).toEqual({ kind: "none" });
    expect(banned.asked).toEqual([]);
    // A ban of some other pubkey leaves the author's Edit usable.
    const other = planPinUpkeep(
      planInput([a.entry], [e1.rumor], { editProof: banned.editProof, isBanned: (pk) => pk === "00".repeat(32) }),
    );
    expect(other.kind).toBe("rewrite");
  });

  // Non-vacuity: remove the "newest Edit is expired" stop so the loop picks the newest unexpired Edit. e1 is then
  // bundled as if it were current and the none assertion fails (superseded text published, D-11).
  it("planPinUpkeep never refreshes to older text when the newest Edit is expired (D-11)", async () => {
    const a = await pinnedMessage("a");
    const e1 = await editOf(a.rumor, "older, still valid", 5_000);
    const e2 = await editOf(a.rumor, "newest, expired", 6_000, [["expiration", "1500"]]);
    const spy = provers(e1, e2);
    expect(planPinUpkeep(planInput([a.entry], [e1.rumor, e2.rumor], { editProof: spy.editProof, now: 2_000 }))).toEqual(
      {
        kind: "none",
      },
    );
    expect(spy.asked).toEqual([]);
    // Before the expiry the same Edit is the current one and is refreshed.
    const before = planPinUpkeep(planInput([a.entry], [e1.rumor, e2.rumor], { editProof: spy.editProof, now: 1_000 }));
    if (before.kind !== "rewrite") throw new Error(`expected a rewrite, got ${before.kind}`);
    expect(verifyPinEntry(before.entries[0], CHANNEL)?.edit?.id).toBe(e2.rumor.id);
  });

  it("an omission and a refresh in one evaluation publish one rewrite", async () => {
    const a = await pinnedMessage("a");
    const b = await pinnedMessage("b");
    const e1 = await editOf(a.rumor, "a, corrected", 5_000);
    const { editProof } = provers(e1);
    const plan = planPinUpkeep(planInput([a.entry, b.entry], [e1.rumor, deletion(b.rumor)], { editProof }));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.stage).toBe("pin-omission");
    expect(plan.omitted).toEqual([b.rumor.id]);
    expect(plan.refreshed).toEqual([a.rumor.id]);
    expect(plan.affected).toEqual([b.rumor.id, a.rumor.id]);
    expect(plan.entries).toHaveLength(1);
    expect(verifyPinEntry(plan.entries[0], CHANNEL)?.edit?.id).toBe(e1.rumor.id);
    // A self-deleted pin is never refreshed.
    const e2 = await editOf(b.rumor, "b, corrected", 5_000);
    const gone = provers(e2);
    const only = planPinUpkeep(planInput([b.entry], [e2.rumor, deletion(b.rumor)], { editProof: gone.editProof }));
    if (only.kind !== "rewrite") throw new Error(`expected a rewrite, got ${only.kind}`);
    expect(only.refreshed).toEqual([]);
    expect(gone.asked).toEqual([]);
  });

  it("planPinUpkeep never bundles an Edit its author deleted (D-31)", async () => {
    // Non-vacuity: drop `deletions` from the candidate chooser and e2's proof is asked for and bundled (CR-02).
    const a = await pinnedMessage("a");
    const e1 = await editOf(a.rumor, "kept", 5_000);
    const e2 = await editOf(a.rumor, "retracted", 6_000);
    const spy = provers(e1, e2);
    const plan = planPinUpkeep(planInput([a.entry], [e1.rumor, e2.rumor, deletion(e2.rumor)], {
      editProof: spy.editProof,
    }));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(spy.asked).toEqual(["kept"]);
    expect(verifyPinEntry(plan.entries[0], CHANNEL)?.edit?.id).toBe(e1.rumor.id);
    // Every Edit deleted: nothing to bundle and nothing to rewrite.
    const both = provers(e1, e2);
    expect(
      planPinUpkeep(
        planInput([a.entry], [e1.rumor, e2.rumor, deletion(e1.rumor), deletion(e2.rumor)], {
          editProof: both.editProof,
        }),
      ),
    ).toEqual({ kind: "none" });
    expect(both.asked).toEqual([]);
    // A deletion by another pubkey retracts nothing.
    const stranger = provers(e1, e2);
    const other = planPinUpkeep(
      planInput([a.entry], [e1.rumor, e2.rumor, deletion(e2.rumor, "00".repeat(32))], {
        editProof: stranger.editProof,
      }),
    );
    if (other.kind !== "rewrite") throw new Error(`expected a rewrite, got ${other.kind}`);
    expect(verifyPinEntry(other.entries[0], CHANNEL)?.edit?.id).toBe(e2.rumor.id);
  });

  it("planPinUpkeep replaces a bundled Edit its author deleted with the newest undeleted provable Edit or removes it (D-31)", async () => {
    // Non-vacuity: return undefined instead of the stripped entry, or compare against the deleted bundled Edit.
    const a = await pinnedMessage("a");
    const entry = { ...a.entry, wrap: "ab".repeat(32), future: { kept: true } } as PinEntry;
    const e1 = await editOf(a.rumor, "older", 5_000);
    const e2 = await editOf(a.rumor, "bundled, then retracted", 6_000);
    const bundled = { ...entry, edit: e2.proof } as PinEntry;
    const gone = deletion(e2.rumor);

    // Replaced by the older undeleted Edit: not a regression, a deleted Edit is not valid.
    const spy = provers(e1, e2);
    const replaced = planPinUpkeep(planInput([bundled], [e1.rumor, e2.rumor, gone], { editProof: spy.editProof }));
    if (replaced.kind !== "rewrite") throw new Error(`expected a rewrite, got ${replaced.kind}`);
    expect(replaced.stage).toBe("pin-edit-refresh");
    expect(replaced.refreshed).toEqual([a.rumor.id]);
    expect(replaced.affected).toEqual([a.rumor.id]);
    expect(spy.asked).toEqual(["older"]);
    expect(verifyPinEntry(replaced.entries[0], CHANNEL)?.edit?.id).toBe(e1.rumor.id);
    expect(replaced.entries[0].seal).toBe(entry.seal);

    // No provable undeleted Edit, or no prover at all: the edit bundle is removed, everything else is carried.
    for (const editProof of [provers().editProof, undefined]) {
      const stripped = planPinUpkeep(planInput([bundled], [e1.rumor, e2.rumor, gone], { editProof }));
      if (stripped.kind !== "rewrite") throw new Error(`expected a rewrite, got ${stripped.kind}`);
      expect(stripped.stage).toBe("pin-edit-refresh");
      expect(stripped.refreshed).toEqual([a.rumor.id]);
      const [out] = stripped.entries as Array<PinEntry & { future: unknown }>;
      expect("edit" in out).toBe(false);
      expect(out.seal).toBe(entry.seal);
      expect(out.keys).toBe(entry.keys);
      expect(out.wrap).toBe(entry.wrap);
      expect(out.future).toBe((entry as PinEntry & { future: unknown }).future);
      expect(verifyPinEntry(out, CHANNEL)?.edit).toBeUndefined();
    }
    // A bundled Edit deleted with no other Edit at all is removed too.
    const lone = planPinUpkeep(planInput([bundled], [gone]));
    if (lone.kind !== "rewrite") throw new Error(`expected a rewrite, got ${lone.kind}`);
    expect("edit" in lone.entries[0]).toBe(false);

    // The newest undeleted Edit is expired (D-11): nothing older is bundled, the edit bundle is removed.
    const e3 = await editOf(a.rumor, "newest, expired", 7_000, [["expiration", "1500"]]);
    const expiredSpy = provers(e1, e3);
    const expired = planPinUpkeep(
      planInput([bundled], [e1.rumor, e2.rumor, e3.rumor, gone], { editProof: expiredSpy.editProof, now: 2_000 }),
    );
    if (expired.kind !== "rewrite") throw new Error(`expected a rewrite, got ${expired.kind}`);
    expect("edit" in expired.entries[0]).toBe(false);
    expect(expiredSpy.asked).toEqual([]);

    // The same list also omits another entry: one rewrite, stage pin-omission, no deleted Edit survives.
    const b = await pinnedMessage("b");
    const mixed = planPinUpkeep(planInput([bundled, b.entry], [e1.rumor, e2.rumor, gone, deletion(b.rumor)]));
    if (mixed.kind !== "rewrite") throw new Error(`expected a rewrite, got ${mixed.kind}`);
    expect(mixed.stage).toBe("pin-omission");
    expect(mixed.omitted).toEqual([b.rumor.id]);
    expect(mixed.entries).toHaveLength(1);
    expect("edit" in mixed.entries[0]).toBe(false);

    // A bundled Edit that is not deleted keeps the never-regress rule.
    const kept = provers(e1, e2);
    expect(planPinUpkeep(planInput([bundled], [e1.rumor, e2.rumor], { editProof: kept.editProof }))).toEqual({
      kind: "none",
    });
  });
});

describe("planPinUpkeep duplicate entries", () => {
  /** One message pinned with two different bundled Edits, plus an unrelated message. */
  async function duplicated() {
    const a = await pinnedMessage("a");
    const other = await pinnedMessage("other");
    const e1 = await editOf(a.rumor, "older", 5_000);
    const e2 = await editOf(a.rumor, "newer", 6_000);
    const withE1: PinEntry = { ...a.entry, edit: e1.proof };
    const withE2: PinEntry = { ...a.entry, edit: e2.proof };
    return { a, other, e1, e2, withE1, withE2 };
  }

  it("an omission rewrite keeps the duplicate whose bundled Edit is newest (D-32)", async () => {
    // Non-vacuity: iterate the raw entries with last-wins dedupe and the rewrite publishes the older orig+edit1 bundle.
    const { a, other, withE1, withE2 } = await duplicated();
    const third = await pinnedMessage("third");
    const plan = planPinUpkeep(planInput([withE2, withE1, other.entry], [deletion(other.rumor)]));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.stage).toBe("pin-omission");
    expect(plan.entries).toHaveLength(1);
    // Reference equality keeps the proven Edit's bundle byte-identical.
    expect(plan.entries[0]).toBe(withE2);
    expect(plan.omitted).toEqual([other.rumor.id]);
    expect(plan.refreshed).toEqual([]);
    // The message keeps the position of its first copy and the content of the newest bundle.
    const moved = planPinUpkeep(planInput([withE1, other.entry, withE2, third.entry], [deletion(third.rumor)]));
    if (moved.kind !== "rewrite") throw new Error(`expected a rewrite, got ${moved.kind}`);
    expect(moved.entries).toHaveLength(2);
    expect(moved.entries[0]).toBe(withE2);
    expect(moved.entries[1]).toBe(other.entry);
    expect(moved.omitted).toEqual([third.rumor.id]);
    expect(verifyPinEntry(moved.entries[0], CHANNEL)?.rumor.id).toBe(a.rumor.id);
  });

  it("duplicate entries alone never trigger a rewrite (D-32)", async () => {
    // Non-vacuity: treat collapsed duplicates as a change and this list is rewritten, or let the last copy win and the
    // newer Edit is refreshed over the older bundle.
    const { e1, e2, withE1, withE2 } = await duplicated();
    expect(planPinUpkeep(planInput([withE2, withE1], []))).toEqual({ kind: "none" });
    expect(planPinUpkeep(planInput([withE1, withE2], []))).toEqual({ kind: "none" });
    const both = provers(e1, e2);
    expect(planPinUpkeep(planInput([withE2, withE1], [e1.rumor, e2.rumor], { editProof: both.editProof }))).toEqual({
      kind: "none",
    });
    expect(both.asked).toEqual([]);
  });

  it("a duplicate bundling an Edit its author deleted triggers a rewrite that keeps one undeleted copy (D-32)", async () => {
    // Non-vacuity: compare the bundles without deletions, or ignore the dropped copy's deleted Edit, and the retracted
    // bundle survives or no rewrite is planned.
    const { a, e1, e2, withE1, withE2 } = await duplicated();
    const gone = deletion(e2.rumor);
    for (const entries of [[withE2, withE1], [withE1, withE2]]) {
      const spy = provers(e1, e2);
      const plan = planPinUpkeep(planInput(entries, [e1.rumor, e2.rumor, gone], { editProof: spy.editProof }));
      if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
      expect(plan.stage).toBe("pin-edit-refresh");
      expect(plan.entries).toHaveLength(1);
      expect(plan.entries[0]).toBe(withE1);
      expect(plan.refreshed).toEqual([a.rumor.id]);
      expect(plan.affected).toEqual([a.rumor.id]);
      expect(plan.omitted).toEqual([]);
    }
  });
});

describe("planPinUpkeep rekey refresh", () => {
  const sealedAt = (epoch: string) => ({ headForm: { form: "sealed", epoch } as const, channelPrivate: true });

  it("planPinUpkeep reseals a readable older-epoch private Pin List under the current key with the original entries", async () => {
    const a = await pinnedMessage("a");
    const b = await pinnedMessage("b");
    const plan = planPinUpkeep(planInput([a.entry, b.entry], [], { ...sealedAt("1"), sealKeyEpoch: 2 }));
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.stage).toBe("pin-rekey-refresh");
    expect(plan.form).toBe("sealed");
    // Reference equality keeps every seal string and unknown field byte for byte.
    expect(plan.entries).toHaveLength(2);
    expect(plan.entries[0]).toBe(a.entry);
    expect(plan.entries[1]).toBe(b.entry);
    expect(plan.omitted).toEqual([]);
    expect(plan.refreshed).toEqual([]);
    expect(plan.affected).toEqual([a.rumor.id, b.rumor.id]);
  });

  it("planPinUpkeep does not reseal a list already at the current epoch or without the current key", async () => {
    const a = await pinnedMessage("a");
    expect(planPinUpkeep(planInput([a.entry], [], { ...sealedAt("2"), sealKeyEpoch: 2 }))).toEqual({ kind: "none" });
    // A key older than the head can only come from a stale snapshot; it is never a reseal.
    expect(planPinUpkeep(planInput([a.entry], [], { ...sealedAt("3"), sealKeyEpoch: 2 }))).toEqual({ kind: "none" });
    expect(planPinUpkeep(planInput([a.entry], [], sealedAt("1")))).toEqual({ kind: "none" });
    expect(
      planPinUpkeep({ ...planInput([a.entry], [], { ...sealedAt("1"), sealKeyEpoch: 2 }), list: { available: false } }),
    )
      .toEqual({ kind: "none" });
    expect(planPinUpkeep(planInput([], [], { ...sealedAt("1"), sealKeyEpoch: 2 }))).toEqual({ kind: "none" });
    // A public channel never reseals, and a public head on a private channel is not an older sealed epoch.
    expect(planPinUpkeep(planInput([a.entry], [], { headForm: { form: "sealed", epoch: "1" } }))).toEqual({
      kind: "none",
    });
    expect(planPinUpkeep(planInput([a.entry], [], { channelPrivate: true, sealKeyEpoch: 2 }))).toEqual({
      kind: "none",
    });
  });

  it("a reseal and an omission publish one rewrite", async () => {
    const a = await pinnedMessage("a");
    const b = await pinnedMessage("b");
    const plan = planPinUpkeep(
      planInput([a.entry, b.entry], [deletion(b.rumor)], { ...sealedAt("1"), sealKeyEpoch: 2 }),
    );
    if (plan.kind !== "rewrite") throw new Error(`expected a rewrite, got ${plan.kind}`);
    expect(plan.stage).toBe("pin-rekey-refresh");
    expect(plan.form).toBe("sealed");
    expect(plan.omitted).toEqual([b.rumor.id]);
    expect(plan.entries).toEqual([a.entry]);
    expect(plan.affected).toEqual([b.rumor.id, a.rumor.id]);
  });
});
