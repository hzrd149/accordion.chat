import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { hexToBytes } from "@noble/hashes/utils.js";
import { base64urlnopad } from "@scure/base";
import { controlSignerGroupKey } from "../crypto.ts";
import { mergeCommunities, mergeCommunityTombstones } from "../community-list.ts";
import type { CommunityListCommunity, JoinMaterial } from "../../types.ts";
import {
  decodeCommunityListFragment,
  decodeLegacyCommunityList,
  encodeCommunityListFragment,
  encodeCommunityListSnapshot,
} from "../community-list-wire.ts";

const material: JoinMaterial = {
  community_id: "00".repeat(32),
  owner: "11".repeat(32),
  owner_salt: "22".repeat(32),
  community_root: "33".repeat(32),
  control_pk: "44".repeat(32),
  control_root: "55".repeat(32),
  root_epoch: 0,
  name: "new",
  relays: ["wss://example.com"],
  channels: [{ id: "66".repeat(32), key: "77".repeat(32), epoch: 0, name: "renamed" }],
};
const entry = { community_id: material.community_id, current: material, seed: material, added_at: 2 };

describe("CORD-02 §8 fragment wire boundary", () => {
  it("uses base64url, inherits identity, elides equal seeds and preserves staff roots", () => {
    const json = encodeCommunityListFragment({ frags: 1, entries: [entry], tombstones: [] });
    const wire = JSON.parse(json);
    expect(wire.entries[0].community_id).toBe("A".repeat(43));
    expect(wire.entries[0].current.owner).toBe("ERERERERERERERERERERERERERERERERERERERERERE");
    expect(wire.entries[0].current.community_id).toBeUndefined();
    expect(wire.entries[0].seed).toBeUndefined();
    const decoded = decodeCommunityListFragment(json);
    expect(decoded.entries[0].current).toEqual(material);
    expect(decoded.entries[0].seed).toEqual(material);
    expect(encodeCommunityListFragment(decoded)).toBe(json);
    expect(encodeCommunityListSnapshot(material).community_id).toBe("A".repeat(43));
  });

  it("rewrites seed cosmetics and strips local history without modifying recovery state", () => {
    const seed = { ...material, name: "old", relays: [], channels: [{ ...material.channels[0], name: "old" }] };
    const current = {
      ...material,
      held_roots: [{ epoch: 0, key: material.community_root }],
      prev_root: material.community_root,
    };
    const json = encodeCommunityListFragment({ frags: 1, entries: [{ ...entry, current, seed }], tombstones: [] });
    expect(JSON.parse(json).entries[0].seed).toBeUndefined();
    expect(json).not.toContain("held_roots");
    expect(json).not.toContain("prev_root");
    expect(seed.name).toBe("old");
    expect(current.held_roots).toHaveLength(1);
  });

  it("retains an older seed anchor and rewrites matching channel names without serializing channel history", () => {
    const seed = {
      ...material,
      name: "old",
      channels: [{ ...material.channels[0], name: "old", held: [{ epoch: 0, key: material.owner }] }],
    };
    const current = { ...material, root_epoch: 1, community_root: material.owner };
    const wire = JSON.parse(
      encodeCommunityListFragment({ frags: 1, entries: [{ ...entry, current, seed }], tombstones: [] }),
    );
    expect(wire.entries[0].seed.root_epoch).toBe(0);
    expect(wire.entries[0].seed.name).toBe("new");
    expect(wire.entries[0].seed.channels[0].name).toBe("renamed");
    expect(wire.entries[0].seed.channels[0].held).toBeUndefined();
    const decoded = decodeCommunityListFragment(JSON.stringify(wire));
    expect(decoded.entries[0].seed.community_root).toBe(material.community_root);
    expect(decoded.entries[0].current.community_root).toBe(material.owner);
  });

  it("round-trips opaque fields at all levels without re-encoding nested lookalike keys", () => {
    const opaque = { key: "AbC_", owner: "ABCD", nested: ["😀", "é"] };
    const current = { ...material, future: opaque, channels: [{ ...material.channels[0], future: opaque }] };
    const fragment = {
      frags: 2,
      future: opaque,
      entries: [{ ...entry, current, seed: current, future: opaque }],
      tombstones: [{ community_id: "88".repeat(32), removed_at: 1, future: opaque }],
    };
    const decoded = decodeCommunityListFragment(encodeCommunityListFragment(fragment));
    expect(decoded.future).toEqual(opaque);
    expect(decoded.entries[0].future).toEqual(opaque);
    expect(decoded.entries[0].current).toEqual(current);
    expect(decoded.tombstones[0].future).toEqual(opaque);
  });

  it("omits covered entries but retains tombstones and local backfill material", () => {
    const fragment = {
      frags: 1,
      entries: [entry],
      tombstones: [{ community_id: material.community_id, removed_at: 2 }],
    };
    expect(decodeCommunityListFragment(encodeCommunityListFragment(fragment)).entries).toEqual([]);
    expect(fragment.entries[0].seed).toEqual(material);
    expect(decodeCommunityListFragment(encodeCommunityListFragment(fragment)).tombstones).toEqual(fragment.tombstones);
  });

  it("writes every named 32-byte value as unpadded base64url at any depth, including each channels entry (CORD-02 §8)", () => {
    const wire = JSON.parse(
      encodeCommunityListFragment({
        frags: 1,
        entries: [entry],
        tombstones: [{ community_id: "88".repeat(32), removed_at: 1 }],
      }),
    );
    const current = wire.entries[0].current;
    const named: Array<[unknown, string]> = [
      [wire.entries[0].community_id, material.community_id],
      [current.owner, material.owner],
      [current.owner_salt, material.owner_salt],
      [current.community_root, material.community_root],
      [current.control_pk, material.control_pk!],
      [current.control_root, material.control_root!],
      [current.channels[0].id, material.channels[0].id],
      [current.channels[0].key, material.channels[0].key],
      [wire.tombstones[0].community_id, "88".repeat(32)],
    ];
    for (const [written, hex] of named) {
      expect(written).toMatch(/^[A-Za-z0-9_-]{43}$/);
      expect(written).toBe(base64urlnopad.encode(hexToBytes(hex)));
    }
  });

  it("never writes the icon, invite-link fields or local history into a membership snapshot (CORD-02 §8)", () => {
    const current = {
      ...material,
      icon: "https://example.com/icon.png",
      expires_at: 9,
      creator_npub: "npub1example",
      label: "launch party",
      refounder: material.owner,
      held_roots: [{ epoch: 0, key: material.community_root }],
      prev_root: material.community_root,
    } as unknown as JoinMaterial;
    const wire = JSON.parse(
      encodeCommunityListFragment({ frags: 1, entries: [{ ...entry, current, seed: current }], tombstones: [] }),
    );
    for (
      const field of ["icon", "expires_at", "creator_npub", "label", "refounder", "held_roots", "prev_root"]
    ) {
      expect(wire.entries[0].current).not.toHaveProperty(field);
    }
    expect(wire.entries[0].current.control_root).toBe(base64urlnopad.encode(hexToBytes(material.control_root!)));
    expect(wire.entries[0].current.community_root).toBe(base64urlnopad.encode(hexToBytes(material.community_root)));
  });

  it("omits an entry whose added_at ties its tombstone's removed_at and keeps one added a millisecond later (CORD-02 §8)", () => {
    const tombstones = [{ community_id: material.community_id, removed_at: 2 }];
    const read = (added_at: number) =>
      decodeCommunityListFragment(
        encodeCommunityListFragment({ frags: 1, entries: [{ ...entry, added_at }], tombstones }),
      );
    for (const covered of [1, 2]) expect(read(covered).entries).toEqual([]);
    expect(read(3).entries.map((kept) => kept.added_at)).toEqual([3]);
    expect(read(3).tombstones).toEqual(tombstones);
  });

  it("round-trips unknown fields on a seed that differs from current, on its channels entries and on a tombstone (CORD-02 §8)", () => {
    const opaque = { key: "AbC_", nested: ["😀", { deep: null }] };
    const seed = {
      ...material,
      root_epoch: 0,
      seed_future: opaque,
      channels: [{ ...material.channels[0], channel_future: opaque }],
    };
    const current = {
      ...material,
      root_epoch: 1,
      community_root: material.owner,
      current_future: opaque,
      channels: [{ ...material.channels[0], channel_future: opaque }],
    };
    const tombstone = { community_id: "88".repeat(32), removed_at: 1, tombstone_future: opaque };
    const json = encodeCommunityListFragment({
      frags: 1,
      entries: [{ ...entry, seed, current, entry_future: opaque }],
      tombstones: [tombstone],
    });
    const wire = JSON.parse(json);
    expect(wire.entries[0].seed.seed_future).toEqual(opaque);
    expect(wire.entries[0].seed.channels[0].channel_future).toEqual(opaque);
    expect(wire.entries[0].current.current_future).toEqual(opaque);
    expect(wire.entries[0].current.channels[0].channel_future).toEqual(opaque);
    const decoded = decodeCommunityListFragment(json);
    expect((decoded.entries[0].seed as unknown as Record<string, unknown>).seed_future).toEqual(opaque);
    expect((decoded.entries[0] as unknown as Record<string, unknown>).entry_future).toEqual(opaque);
    expect((decoded.tombstones[0] as unknown as Record<string, unknown>).tombstone_future).toEqual(opaque);
    expect(encodeCommunityListFragment(decoded)).toBe(json);
  });

  it("preserves prototype-named extensions and orders Unicode keys by UTF-8 bytes", () => {
    const extras = JSON.parse('{"__proto__":{"key":"opaque"},"😀":1,"\\ue000":2}');
    const fragment = { ...extras, frags: 1, entries: [entry], tombstones: [] };
    const json = encodeCommunityListFragment(fragment);
    expect(JSON.parse(json).__proto__).toEqual({ key: "opaque" });
    expect(json.indexOf("\ue000")).toBeLessThan(json.indexOf("😀"));
    expect(encodeCommunityListFragment(decodeCommunityListFragment(json))).toBe(json);
  });

  it("keeps case-significant keys distinct and rejects mismatched embedded runtime identity", () => {
    const json = encodeCommunityListFragment({ frags: 1, entries: [entry], tombstones: [] });
    const wire = JSON.parse(json);
    wire.entries[0].current.owner = "a" + wire.entries[0].current.owner.slice(1);
    const decoded = decodeCommunityListFragment(JSON.stringify(wire));
    expect(decoded.entries[0].current.owner).not.toBe(material.owner);
    expect(JSON.parse(encodeCommunityListFragment(decoded)).entries[0].current.owner).toBe(
      wire.entries[0].current.owner,
    );
    expect(() =>
      encodeCommunityListFragment({
        frags: 1,
        entries: [{ ...entry, current: { ...material, community_id: material.owner } }],
        tombstones: [],
      })
    ).toThrow("identity mismatch");
  });

  it("keeps legacy hex decoding separate and rejects padded, malformed and noncanonical keys", () => {
    expect(decodeLegacyCommunityList(JSON.stringify({ entries: [entry] })).entries[0].current).toEqual(material);
    const wire = JSON.parse(encodeCommunityListFragment({ frags: 1, entries: [entry], tombstones: [] }));
    for (const bad of [material.community_id, "A".repeat(43) + "=", "A".repeat(42) + "B"]) {
      expect(() =>
        decodeCommunityListFragment(JSON.stringify({ ...wire, entries: [{ ...wire.entries[0], community_id: bad }] }))
      ).toThrow();
    }
  });
});

describe("snapshot merge convergence", () => {
  it("chooses base64url wire bytes rather than internal hex spelling", () => {
    const a = { ...material, community_root: "00".repeat(32) };
    const b = { ...material, community_root: "fb".repeat(32) };
    const entries = [a, b].map((current) => ({ ...entry, current, seed: current }));
    // '+'/'-' sorts before 'A', whereas hex 00 sorts before fb.
    for (const order of [entries, [...entries].reverse()]) {
      const result = mergeCommunities([], order);
      expect(result[0].current.community_root).toBe(b.community_root);
      expect(result[0].seed.community_root).toBe(b.community_root);
    }
  });

  it("keeps the lower-epoch seed and the higher-epoch current in either merge order (CORD-02 §8)", () => {
    const older = { ...material, root_epoch: 0 };
    const newer = { ...material, root_epoch: 3, community_root: material.owner };
    const a = { ...entry, seed: older, current: older };
    const b = { ...entry, seed: newer, current: newer };
    for (const [first, second] of [[a, b], [b, a]]) {
      const [merged] = mergeCommunities([first], [second]);
      expect(merged.seed.root_epoch).toBe(0);
      expect(merged.seed.community_root).toBe(material.community_root);
      expect(merged.current.root_epoch).toBe(3);
      expect(merged.current.community_root).toBe(material.owner);
    }
  });

  it("ignores local history when choosing equal-epoch wire snapshots", () => {
    const a = { ...material, name: "a", prev_root: "ff".repeat(32) };
    const b = { ...material, name: "b", prev_root: "00".repeat(32) };
    const inputs = [a, b].map((current) => ({ ...entry, current, seed: current }));
    expect(mergeCommunities([], inputs)[0].current.name).toBe("a");
    expect(mergeCommunities([], [...inputs].reverse())[0].current.name).toBe("a");
  });

  it("retains valid staff secrets through all input permutations and repeated merges", () => {
    const secret = "12".repeat(32);
    const read = {
      ...material,
      control_pk: controlSignerGroupKey(hexToBytes(secret), hexToBytes(material.community_id), 0).pk,
    };
    const { control_root: _root, ...without } = read;
    const inputs = [without, { ...without, control_root: secret }, { ...without, name: "other" }]
      .map((current) => ({ ...entry, current, seed: current }));
    const permutations = inputs.flatMap((a, i) =>
      inputs.flatMap((b, j) => i === j ? [] : [[a, b, inputs.find((_, k) => k !== i && k !== j)!]])
    );
    const expected = mergeCommunities([], permutations[0]);
    for (const order of permutations) {
      const merged = order.reduce((state, item) => mergeCommunities(state, [item]), [] as CommunityListCommunity[]);
      expect(merged).toEqual(expected);
      expect(merged[0].current.control_root).toBe(secret);
      expect(mergeCommunities(merged, order)).toEqual(expected);
    }
  });
});

it("unions opaque entry and tombstone extensions independently of input order", () => {
  const a = { ...entry, future: { name: "a" }, onlyA: 1 };
  const b = { ...entry, future: { name: "b" }, onlyB: 2 };
  expect(mergeCommunities([a], [b])).toEqual(mergeCommunities([b], [a]));
  expect(mergeCommunities([a], [b])[0].onlyB).toBe(2);
  const x = { community_id: entry.community_id, removed_at: 4, onlyA: 1 };
  const y = { community_id: entry.community_id, removed_at: 4, onlyB: 2 };
  expect(mergeCommunityTombstones([x], [y])).toEqual(mergeCommunityTombstones([y], [x]));
  expect(mergeCommunityTombstones([x], [y])[0]).toMatchObject({ onlyA: 1, onlyB: 2 });
});
