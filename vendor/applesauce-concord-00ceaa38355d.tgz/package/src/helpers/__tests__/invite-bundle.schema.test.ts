// Generate hostile probes from the rule tables so new fields are tested
// automatically. Type-derived tables reject missing rules at compile time.

/// <reference lib="deno.ns" />
// Test-only: `deno.json` sets `lib` to ES2022+DOM without `deno.ns`, so library
// source cannot reach for Deno APIs and stays browser-safe. This file is a test
// guard that must read the source tree, so it opts into the Deno namespace here
// rather than widening `lib` for all of `src/`.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { bytesToHex, randomBytes } from "@noble/hashes/utils.js";

import { communityId } from "../crypto.ts";
import { createCommunity } from "../community.ts";
import * as InviteBundleModule from "../invite-bundle.ts";
import {
  BLOB_POINTER_FIELD_RULES,
  buildInviteBundle,
  type BundleFieldRule,
  CHANNEL_KEY_FIELD_RULES,
  HELD_KEY_FIELD_RULES,
  INVITE_BUNDLE_FIELD_RULES,
  INVITE_BUNDLE_MAX_CHANNELS,
  INVITE_BUNDLE_MAX_HELD_CHANNEL_KEYS,
  INVITE_BUNDLE_MAX_HELD_ROOTS,
  INVITE_BUNDLE_MAX_RELAY_URL_LENGTH,
  INVITE_BUNDLE_MAX_TEXT_LENGTH,
  validateInviteBundle,
} from "../invite-bundle.ts";
import type { BlobPointer, ChannelKey, InviteBundle } from "../../types.ts";

// ── Layer 1: a baseline fixture whose owner proof genuinely passes, with
// EVERY optional field populated, so every probe below mutates a bundle that
// would otherwise validate cleanly (TEST-01: no expected value is ever read
// back from the function under test).
const OWNER = "ab".repeat(32);
const OWNER_SALT = randomBytes(32);
const COMMUNITY_ID = bytesToHex(communityId(OWNER, OWNER_SALT));

function baselineBundle(): InviteBundle {
  return {
    community_id: COMMUNITY_ID,
    owner: OWNER,
    owner_salt: bytesToHex(OWNER_SALT),
    community_root: "cd".repeat(32),
    control_pk: "12".repeat(32),
    root_epoch: 1,
    channels: [
      {
        id: "11".repeat(32),
        key: "22".repeat(32),
        epoch: 2,
        name: "mods",
        held: [{ epoch: 1, key: "33".repeat(32) }],
      },
    ],
    relays: ["wss://relay-a.example.com", "wss://relay-b.example.com"],
    name: "Baseline Community",
    held_roots: [{ epoch: 0, key: "44".repeat(32), refounder: "55".repeat(32) }],
    refounder: "66".repeat(32),
    icon: {
      url: "https://img.example.com/a.png",
      key: "77".repeat(32),
      nonce: "nonce-value",
      hash: "88".repeat(32),
    },
    creator_npub: "99".repeat(32),
    label: "Reddit",
    expires_at: 4_000_000_000,
  };
}

/**
 * Builds a hostile value for `rule` by dispatching on `rule.kind` — never a
 * single universal literal, since a raw string is not even type-compatible
 * with every kind's positive-validity check. The `default` branch below is
 * LOAD-BEARING (D-17): it must never be softened into a skip, and a new
 * `BundleFieldRule` kind with no case here fails `deno check` via the `never`
 * assignment before it could ever reach this throw at runtime.
 */
function hostileValueFor(rule: BundleFieldRule): unknown {
  switch (rule.kind) {
    case "hex-key":
    case "bounded-text":
      return "x".repeat(60_000);
    case "safe-integer":
      // Not a safe integer — same class of failure a 60,000-char string is
      // for the string-shaped kinds above.
      return Number.MAX_SAFE_INTEGER + 100;
    case "relay-list":
    case "channel-list":
    case "held-list":
      return "not-an-array";
    case "blob-pointer":
      return "not-an-object";
    default: {
      const exhaustive: never = rule;
      throw new Error(
        `invite-bundle.schema.test.ts has no oversize probe for rule kind '${
          (exhaustive as BundleFieldRule).kind
        }' — add one; this throw is load-bearing and must never be softened into a skip (D-17)`,
      );
    }
  }
}

// ── Layer 2: generated probes, one per field of every rule table — the
// parameterisation reads Object.entries(...FIELD_RULES) directly, so there is
// no hand-maintained list of field names anywhere in this file.

for (const [field, rule] of Object.entries(INVITE_BUNDLE_FIELD_RULES)) {
  describe(`bundle field ${field} (generated probe)`, () => {
    it(`a malformed ${field} is handled per its declared disposition ("${rule.onInvalid}")`, () => {
      const bundle = { ...baselineBundle(), [field]: hostileValueFor(rule) };
      const result = validateInviteBundle(bundle);
      if (rule.onInvalid === "reject") {
        // A reject-disposition bundle-level field failing rejects the WHOLE bundle.
        expect(result).toBeUndefined();
      } else {
        // A drop-disposition field failing omits just that key; every other
        // field (including the owner proof) still validates.
        expect(result).toBeDefined();
        expect(Object.prototype.hasOwnProperty.call(result, field)).toBe(false);
      }
    });
  });
}

for (const [field, rule] of Object.entries(CHANNEL_KEY_FIELD_RULES)) {
  describe(`channel-entry field ${field} (generated probe)`, () => {
    it(`a malformed channels[0].${field} is handled per its declared disposition — a sibling channel always survives`, () => {
      const bundle = baselineBundle();
      const poisoned = { ...(bundle.channels[0] as ChannelKey), [field]: hostileValueFor(rule) };
      const sibling: ChannelKey = { id: "99".repeat(32), key: "aa".repeat(32), epoch: 0, name: "sibling" };
      const injected = { ...bundle, channels: [poisoned, sibling] };
      const result = validateInviteBundle(injected);
      // Channel-level issues never reject the whole bundle (channel-list's
      // per-entry drop policy) — the bundle always validates here.
      expect(result).toBeDefined();
      expect(result?.channels.some((c) => c.name === "sibling")).toBe(true);
      if (rule.onInvalid === "reject") {
        // The whole poisoned ENTRY is dropped (channel-list's per-entry policy).
        expect(result?.channels.length).toBe(1);
      } else {
        // The field alone is dropped; the poisoned channel entry itself survives.
        const survivor = result?.channels.find((c) => c.id === poisoned.id);
        expect(survivor).toBeDefined();
        expect(Object.prototype.hasOwnProperty.call(survivor, field)).toBe(false);
      }
    });
  });
}

for (const [field, rule] of Object.entries(HELD_KEY_FIELD_RULES)) {
  describe(`held-root-entry field ${field} (generated probe)`, () => {
    it(`a malformed held_roots[0].${field} is handled per its declared disposition ("${rule.onInvalid}")`, () => {
      const bundle = baselineBundle();
      const heldRoots = bundle.held_roots!;
      const poisoned = { ...heldRoots[0], [field]: hostileValueFor(rule) };
      const injected = { ...bundle, held_roots: [poisoned] };
      const result = validateInviteBundle(injected);
      if (rule.onInvalid === "reject") {
        // held-list rejects the WHOLE containing object on any malformed entry.
        expect(result).toBeUndefined();
      } else {
        expect(result).toBeDefined();
        const entry = result?.held_roots?.[0];
        expect(entry).toBeDefined();
        expect(Object.prototype.hasOwnProperty.call(entry, field)).toBe(false);
      }
    });
  });
}

for (const [field] of Object.entries(BLOB_POINTER_FIELD_RULES)) {
  describe(`icon field ${field} (generated probe)`, () => {
    it(`a malformed icon.${field} drops the whole icon (every blob-table field is reject/reject)`, () => {
      const bundle = baselineBundle();
      const injected = {
        ...bundle,
        icon: {
          ...(bundle.icon as BlobPointer),
          [field]: hostileValueFor(BLOB_POINTER_FIELD_RULES[field as keyof BlobPointer]),
        },
      };
      const result = validateInviteBundle(injected);
      expect(result).toBeDefined();
      expect(result?.icon).toBeUndefined();
    });
  });
}

// ── Array-kind specifics: count-cap + raw-array ordering, and the relay
// kind's per-entry length filter (in-count, one over-length entry).

describe("array-kind count-cap and ordering probes (generated over the bundle table's array fields)", () => {
  // relay-list is deliberately excluded here: its count cap SLICES the raw
  // array rather than rejecting (unchanged pre-D-17 behavior — a bundle whose
  // relays are entirely junk still validates), so it gets its own dedicated
  // truncation probe below instead of this reject-on-over-count assertion.
  const arrayFields = Object.entries(INVITE_BUNDLE_FIELD_RULES).filter(
    (entry): entry is [string, Extract<(typeof entry)[1], { countCap: number }>] =>
      "countCap" in entry[1] && entry[1].kind !== "relay-list",
  );

  for (const [field, rule] of arrayFields) {
    it(`an over-count ${field} array of well-formed-looking entries is refused per its disposition`, () => {
      // "Well-formed-looking" placeholder entries — the count cap must fire on
      // the RAW array length, before any per-entry validation ever runs.
      const entries = Array.from({ length: rule.countCap + 1 }, () => ({}));
      const bundle = { ...baselineBundle(), [field]: entries };
      const result = validateInviteBundle(bundle);
      expect(result).toBeUndefined();
    });
  }

  for (const [field, rule] of arrayFields) {
    it(`the same over-count ${field} array with every entry malformed is refused identically (ordering guard)`, () => {
      const entries = Array.from({ length: rule.countCap + 1 }, () => ({ junk: true }));
      const bundle = { ...baselineBundle(), [field]: entries };
      const result = validateInviteBundle(bundle);
      // Non-vacuity: if the per-entry filter ran BEFORE the count check, every
      // entry here (all malformed) would be dropped/rejected individually,
      // potentially emptying the array below the cap — this pins the count
      // check running on the RAW array first.
      expect(result).toBeUndefined();
    });
  }
});

it("an over-count relays array is TRUNCATED to the cap, not rejected — the exception to the reject-on-over-count array kinds above", () => {
  const relayRule = INVITE_BUNDLE_FIELD_RULES.relays;
  if (relayRule.kind !== "relay-list") throw new Error("relays rule kind changed — update this probe");
  const relays = Array.from({ length: relayRule.countCap + 5 }, (_, i) => `wss://relay-${i}.example.com`);
  const result = validateInviteBundle({ ...baselineBundle(), relays });
  expect(result).toBeDefined();
  expect(result?.relays.length).toBe(relayRule.countCap);
  expect(result?.relays).toEqual(relays.slice(0, relayRule.countCap));
});

it("an in-count relays array holding one syntactically valid URL longer than the relay kind's urlMax is filtered out, not rejected", () => {
  const relayRule = INVITE_BUNDLE_FIELD_RULES.relays;
  if (relayRule.kind !== "relay-list") throw new Error("relays rule kind changed — update this probe");
  const longUrl = "wss://relay.example.com/" + "a".repeat(relayRule.urlMax);
  const bundle = { ...baselineBundle(), relays: [longUrl] };
  const result = validateInviteBundle(bundle);
  expect(result).toBeDefined();
  expect(result?.relays).toEqual([]);
});

// ── Layer 3: whole-structure invariants ──────────────────────────────────

it("no string value anywhere in a validated (maximal) bundle exceeds the largest declared cap", () => {
  const result = validateInviteBundle(baselineBundle())!;
  expect(result).toBeDefined();

  const allRules = [
    ...Object.values(INVITE_BUNDLE_FIELD_RULES),
    ...Object.values(CHANNEL_KEY_FIELD_RULES),
    ...Object.values(HELD_KEY_FIELD_RULES),
    ...Object.values(BLOB_POINTER_FIELD_RULES),
  ];
  const largestCap = Math.max(...allRules.map((r) => ("max" in r ? r.max : "urlMax" in r ? r.urlMax : 0)));

  const lengths: number[] = [];
  (function walk(value: unknown): void {
    if (typeof value === "string") lengths.push(value.length);
    else if (Array.isArray(value)) { for (const v of value) walk(v); }
    else if (value && typeof value === "object") { for (const v of Object.values(value)) walk(v); }
  })(result);

  expect(lengths.length).toBeGreaterThan(0);
  expect(Math.max(...lengths)).toBeLessThanOrEqual(largestCap);
});

it("every key a genuine buildInviteBundle output carries has a rule in the bundle table (builder coverage)", async () => {
  const genesis = await createCommunity({
    ownerPubkey: OWNER,
    name: "Builder Coverage",
    relays: ["wss://ok.example.com"],
  });
  const material = {
    ...genesis.material,
    channels: [{ id: "11".repeat(32), key: "22".repeat(32), epoch: 0, name: "general" }],
    refounder: "cc".repeat(32),
  };
  const built = buildInviteBundle(material, {
    channels: ["11".repeat(32)],
    icon: { url: "https://x", key: "k", nonce: "n", hash: "h" },
    creator_npub: "dd".repeat(32),
    label: "Reddit",
    expires_at: 4_000_000_000,
  });
  for (const key of Object.keys(built)) {
    expect(Object.prototype.hasOwnProperty.call(INVITE_BUNDLE_FIELD_RULES, key)).toBe(true);
  }
  // No false negative: the genuine bundle itself validates unchanged.
  expect(validateInviteBundle(built)).toBeDefined();
});

it("the removed aggregate-byte-cap symbol is permanently gone from the module's export surface (D-07/D-25), and every surviving bound is an independent literal (D-09)", () => {
  // Structural guard: this symbol must never reappear. A future re-add of
  // INVITE_BUNDLE_MAX_TOTAL_BYTES (or any replacement aggregate bound) fails
  // this assertion even if every other test in this file stays green.
  expect(Object.keys(InviteBundleModule)).not.toContain("INVITE_BUNDLE_MAX_TOTAL_BYTES");

  // D-09: these five bounds are independent literals with no arithmetic tie
  // to any byte figure or to each other — a future reader must not re-derive
  // one from another, the way the deleted cap-chain test used to.
  expect(INVITE_BUNDLE_MAX_CHANNELS).toBe(256);
  expect(INVITE_BUNDLE_MAX_HELD_ROOTS).toBe(64);
  expect(INVITE_BUNDLE_MAX_HELD_CHANNEL_KEYS).toBe(64);
  expect(INVITE_BUNDLE_MAX_TEXT_LENGTH).toBe(256);
  expect(INVITE_BUNDLE_MAX_RELAY_URL_LENGTH).toBe(512);
});

// Check nested channel history and type-derived annotations independently;
// top-level field probes alone cannot detect either coverage gap.

/**
 * The rule table governing the CHILD objects a rule of `kind` produces, or
 * `undefined` for a leaf kind. Mirrors `checkKind`'s own dispatch exactly.
 * The `default` branch is LOAD-BEARING (D-17/CR4-01): a new `BundleFieldRule`
 * kind with no case here fails `deno check` via the `never` assignment before it
 * could ever reach this throw at runtime — this must never be softened into
 * a skip.
 */
function childTableForKind(kind: BundleFieldRule["kind"]): Record<string, BundleFieldRule> | undefined {
  switch (kind) {
    case "channel-list":
      return CHANNEL_KEY_FIELD_RULES;
    case "held-list":
      return HELD_KEY_FIELD_RULES;
    case "blob-pointer":
      return BLOB_POINTER_FIELD_RULES;
    case "hex-key":
    case "bounded-text":
    case "safe-integer":
    case "relay-list":
      return undefined;
    default: {
      const exhaustive: never = kind;
      throw new Error(
        `invite-bundle.schema.test.ts's childTableForKind has no case for rule kind '${exhaustive}' — add one; this throw is load-bearing and must never be softened into a skip (CR4-01)`,
      );
    }
  }
}

/**
 * Recursively asserts every own key of `value` has an own property in
 * `rules` (the table governing `value`'s level), then descends into any key
 * whose rule kind has a child table — arrays element-by-element (index
 * appended to `path`), plain objects directly. Returns the number of key
 * checks performed, so callers can assert non-zero (indeed, deeper-than-top-
 * level) coverage — the guard against a walk that silently never descends.
 */
function assertRuleCoverage(value: unknown, rules: Record<string, BundleFieldRule>, path: string): number {
  if (typeof value !== "object" || value === null) return 0;
  let count = 0;
  for (const key of Object.keys(value as Record<string, unknown>)) {
    expect(
      Object.prototype.hasOwnProperty.call(rules, key),
      `${path}.${key} has no rule in the table governing ${path} (CR4-01: a nested field with no rule)`,
    ).toBe(true);
    count++;
    const rule = rules[key];
    if (!rule) continue;
    const childTable = childTableForKind(rule.kind);
    if (!childTable) continue;
    const raw = (value as Record<string, unknown>)[key];
    if (Array.isArray(raw)) {
      raw.forEach((item, i) => {
        count += assertRuleCoverage(item, childTable, `${path}.${key}[${i}]`);
      });
    } else if (raw && typeof raw === "object") {
      count += assertRuleCoverage(raw, childTable, `${path}.${key}`);
    }
  }
  return count;
}

it("every key at every level of a validated maximal bundle has a rule in the table governing that level (nested rule coverage)", () => {
  const result = validateInviteBundle(baselineBundle());
  expect(result).toBeDefined();
  const checkCount = assertRuleCoverage(result, INVITE_BUNDLE_FIELD_RULES, "bundle");
  // Non-vacuity: if the walk stopped at depth 0, checkCount would equal the
  // number of top-level keys exactly — it must be strictly greater, proving
  // the walk genuinely descended into channels[]/channels[].held[]/held_roots[]/icon.
  expect(checkCount).toBeGreaterThan(Object.keys(result as object).length);
});

it("every key a genuine buildInviteBundle output carries at every level has a rule in the table governing that level (nested builder coverage)", async () => {
  const genesis = await createCommunity({
    ownerPubkey: OWNER,
    name: "Nested Builder Coverage",
    relays: ["wss://ok.example.com"],
  });
  const material = {
    ...genesis.material,
    channels: [
      {
        id: "11".repeat(32),
        key: "22".repeat(32),
        epoch: 1,
        name: "general",
        // buildInviteBundle carries `held` through when present — this is the
        // ONLY way a built bundle ever carries a nested `channels[].held[]`
        // entry (buildInviteBundle never emits `held_roots` at all — see its
        // own doc comment — which is why this test and the one above it are
        // BOTH needed to reach every nested position: 2b (a validated
        // bundle) reaches `held_roots[]`, 2c (a built bundle) reaches
        // `channels[].held[]`).
        held: [{ epoch: 0, key: "33".repeat(32) }],
      },
    ],
  };
  const built = buildInviteBundle(material, {
    channels: ["11".repeat(32)],
    icon: { url: "https://x.example.com", key: "k", nonce: "n", hash: "h" },
    creator_npub: "dd".repeat(32),
    label: "Reddit",
    expires_at: 4_000_000_000,
  });
  const checkCount = assertRuleCoverage(built, INVITE_BUNDLE_FIELD_RULES, "built");
  expect(checkCount).toBeGreaterThan(Object.keys(built as object).length);
  // No false negative: the genuine built bundle itself validates unchanged.
  expect(validateInviteBundle(built)).toBeDefined();
});

it("an unknown attacker key injected at every nested position is absent from the validated output", () => {
  const ATTACKER_KEY = "__cr4_01_attacker_key__";
  const bundle = baselineBundle();
  const injected = {
    ...bundle,
    channels: [
      { ...bundle.channels[0], [ATTACKER_KEY]: "x", held: [{ ...bundle.channels[0]!.held![0], [ATTACKER_KEY]: "x" }] },
    ],
    held_roots: [{ ...bundle.held_roots![0], [ATTACKER_KEY]: "x" }],
    icon: { ...bundle.icon, [ATTACKER_KEY]: "x" },
  };
  const result = validateInviteBundle(injected as unknown as InviteBundle);
  expect(result).toBeDefined();
  // Derived from rebuildByRules's own doc comment (it builds a fresh object
  // and never spreads its input) — not by reading validateInviteBundle's
  // actual output.
  expect(Object.prototype.hasOwnProperty.call(result?.channels[0], ATTACKER_KEY)).toBe(false);
  expect(Object.prototype.hasOwnProperty.call(result?.channels[0]?.held?.[0], ATTACKER_KEY)).toBe(false);
  expect(Object.prototype.hasOwnProperty.call(result?.held_roots?.[0], ATTACKER_KEY)).toBe(false);
  expect(Object.prototype.hasOwnProperty.call(result?.icon, ATTACKER_KEY)).toBe(false);
  expect(JSON.stringify(result)).not.toContain(ATTACKER_KEY);
});

it("preserves an absent held-key optional while closing the nested projection", () => {
  const bundle = baselineBundle();
  const held = { epoch: 0, key: "44".repeat(32), injected: "must-not-survive" };
  const result = validateInviteBundle({ ...bundle, held_roots: [held] } as unknown as InviteBundle);

  expect(result?.held_roots).toHaveLength(1);
  expect(Object.prototype.hasOwnProperty.call(result?.held_roots?.[0], "refounder")).toBe(false);
  expect(Object.prototype.hasOwnProperty.call(result?.held_roots?.[0], "injected")).toBe(false);
});

it("binds the held-key refounder rule to its declared string value family", () => {
  const source = Deno.readTextFileSync(new URL("../invite-bundle.ts", import.meta.url)).replace(/\s+/g, " ");

  expect(source).toContain("type RuleFor<Value>");
  expect(source).toContain("[K in keyof Required<T>]: RuleFor<T[K]>");
  // The `(?:\s*:\s*[^=]+?)?` group tolerates the isolatedDeclarations type
  // annotation (05-02) between the name and `=`. It cannot start unless a `:`
  // directly follows the name, so every other mention of this table (comments,
  // `typeof` proof entries, call arguments) still fails to match, exactly as
  // before the annotation landed.
  expect(source).toMatch(/HELD_KEY_FIELD_RULES(?:\s*:\s*[^=]+?)?\s*=\s*\{.*?refounder:\s*\{\s*kind:\s*"hex-key"/);
});

it("pins negative compiler assertions for every rule value family and optional absence", () => {
  const source = Deno.readTextFileSync(new URL("../invite-bundle.ts", import.meta.url));

  expect(source).toContain("export type BundleRuleMismatchAssertions");
  expect(source.match(/AssertNever<Extract<RuleFor</g)).toHaveLength(5);
});

it("preserves omission for every omit-disposition field at every table depth", () => {
  const bundle = baselineBundle();
  let checked = 0;

  for (const [field, rule] of Object.entries(INVITE_BUNDLE_FIELD_RULES)) {
    if (rule.onAbsent !== "omit") continue;
    const result = validateInviteBundle({ ...bundle, [field]: undefined });
    expect(Object.prototype.hasOwnProperty.call(result, field)).toBe(false);
    checked++;
  }
  for (const [field, rule] of Object.entries(CHANNEL_KEY_FIELD_RULES)) {
    if (rule.onAbsent !== "omit") continue;
    const channel = { ...bundle.channels[0], [field]: undefined };
    const result = validateInviteBundle({ ...bundle, channels: [channel] } as unknown as InviteBundle);
    expect(Object.prototype.hasOwnProperty.call(result?.channels[0], field)).toBe(false);
    checked++;
  }
  for (const [field, rule] of Object.entries(HELD_KEY_FIELD_RULES)) {
    if (rule.onAbsent !== "omit") continue;
    const held = { ...bundle.held_roots![0], [field]: undefined };
    const result = validateInviteBundle({ ...bundle, held_roots: [held] } as unknown as InviteBundle);
    expect(Object.prototype.hasOwnProperty.call(result?.held_roots?.[0], field)).toBe(false);
    checked++;
  }
  expect(checked).toBeGreaterThan(0);
});

it("every exported *_FIELD_RULES table in invite-bundle.ts satisfies ExhaustiveBundleRules<> over a subject derived from InviteBundle", () => {
  const source = Deno.readTextFileSync(new URL("../invite-bundle.ts", import.meta.url));
  // Collapse all whitespace runs to single spaces so prettier's line-wrapping
  // cannot break the match.
  const collapsed = source.replace(/\s+/g, " ");

  // The `(?:\s*:\s*[^=]+?)?` group tolerates the isolatedDeclarations type
  // annotation (05-02) between the name and `=`. The subject this test checks is
  // still read from the trailing `satisfies` clause, never from the annotation.
  const tableRegex = /export const (\w+_FIELD_RULES)(?:\s*:\s*[^=]+?)?\s*=\s*\{.*?\}\s+satisfies\s+([^;]+);/g;
  const discovered: { name: string; subject: string }[] = [];
  let match: RegExpExecArray | null;
  while ((match = tableRegex.exec(collapsed))) {
    const name = match[1]!;
    const annotation = match[2]!.trim();
    expect(
      annotation.startsWith("ExhaustiveBundleRules<"),
      `${name} must satisfy ExhaustiveBundleRules<...> over a subject derived from InviteBundle (CR4-01) — found "${annotation}"`,
    ).toBe(true);
    const subject = annotation.slice(annotation.indexOf("<") + 1, annotation.lastIndexOf(">")).trim();
    discovered.push({ name, subject });
  }

  // Without this guard, a regex that silently stops matching would make the
  // whole test vacuous.
  expect(discovered.length).toBeGreaterThanOrEqual(4);

  for (const { name, subject } of discovered) {
    const directlyRootedInInviteBundle = subject.includes("InviteBundle");
    let aliasRootedInInviteBundle = false;
    if (!directlyRootedInInviteBundle && /^\w+$/.test(subject)) {
      const aliasMatch = new RegExp(`type ${subject} = ([^;]+);`).exec(collapsed);
      aliasRootedInInviteBundle = !!aliasMatch && aliasMatch[1]!.includes("InviteBundle");
    }
    expect(
      directlyRootedInInviteBundle || aliasRootedInInviteBundle,
      `${name}'s subject "${subject}" must be InviteBundle itself, or a derived alias whose right-hand side is an indexed-access path rooted at InviteBundle (CR4-01) — a rule table exhaustive over a hand-declared mirror of the real type is exhaustive over nothing`,
    ).toBe(true);
  }
});
