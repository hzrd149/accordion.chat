// CORD-03 §3: a receiver checks the channel and epoch tags of a decoded Chat rumor strict-equal against the Channel and
// epoch whose key opened its wrap (REL-01 spec sweep of CORD-03).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { checkChatBinding } from "../chat.ts";

describe("chat binding (CORD-03 §3)", () => {
  it("checkChatBinding accepts only the exact channel id and the exact epoch number (CORD-03 §3)", () => {
    const bound = [["channel", "chan"], ["epoch", "3"], ["ms", "12"]];
    expect(checkChatBinding(bound, "chan", 3)).toBe(true);

    // Non-vacuity: every one of these differs from the bound tags in exactly one respect and must be refused.
    expect(checkChatBinding(bound, "other", 3)).toBe(false);
    expect(checkChatBinding(bound, "CHAN", 3)).toBe(false);
    expect(checkChatBinding(bound, "chan", 2)).toBe(false);
    expect(checkChatBinding(bound, "chan", 4)).toBe(false);
    expect(checkChatBinding([["channel", "chan"], ["epoch", "03"]], "chan", 3)).toBe(false);
    expect(checkChatBinding([["channel", "chan"], ["epoch", " 3"]], "chan", 3)).toBe(false);
    expect(checkChatBinding([["channel", "chan"], ["epoch", "3.0"]], "chan", 3)).toBe(false);
    expect(checkChatBinding([["channel", "chan "], ["epoch", "3"]], "chan", 3)).toBe(false);
    expect(checkChatBinding([["epoch", "3"]], "chan", 3)).toBe(false);
    expect(checkChatBinding([["channel", "chan"]], "chan", 3)).toBe(false);
    expect(checkChatBinding([], "chan", 3)).toBe(false);
    expect(checkChatBinding([["channel"], ["epoch"]], "chan", 3)).toBe(false);
  });
});
