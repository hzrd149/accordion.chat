// CORD-04 §§4, 6 Banlist write planning: the pure checks and the content planner behind batch bans (BAN-01, D-09,
// D-19). The planner builds from the head content and never drops or carries an entry the writer cannot vouch for.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { hexToBytes } from "@noble/hashes/utils.js";

import { EditionFactory } from "../../factories/control.ts";
import { PERM, VSK } from "../../types.ts";
import type { CommunityState, DecodedEvent, JoinMaterial } from "../../types.ts";
import {
  banTargetFailures,
  newestOwnBanlistEdition,
  normalizeBanTargets,
  parseBanlist,
  planBanlistWrite,
  unvouchedEntries,
} from "../banlist.ts";
import { createCommunity } from "../community.ts";
import { foldControl } from "../control.ts";
import { banlistLocator, grantLocator } from "../crypto.ts";
import { computeEditionHash } from "../editions.ts";
import { foldMembers } from "../guestbook.ts";
import { resolveStanding } from "../permissions.ts";
import { decoded } from "./test-utils.ts";

const OWNER = "ab".repeat(32);
const SENIOR = "a1".repeat(32);
const JUNIOR = "b1".repeat(32);
const BAN_ONLY = "c1".repeat(32);
const MID = "d1".repeat(32);
const TARGET = "e1".repeat(32);
const OTHER = "f1".repeat(32);

const ROLE_SENIOR = "01".repeat(32);
const ROLE_MID = "02".repeat(32);
const ROLE_JUNIOR = "03".repeat(32);
const ROLE_BAN_ONLY = "04".repeat(32);

function role(roleId: string, position: number, permissions: bigint) {
  return {
    role_id: roleId,
    name: `role-${position}`,
    position,
    permissions: permissions.toString(),
    scope: { kind: "server" },
    color: 0,
  };
}

/** The staff roles and grants of the fixture as decoded Control editions, plus the citation each member acts under. */
interface StaffWorld {
  material: JoinMaterial;
  cid: Uint8Array;
  events: DecodedEvent[];
  /** The `vac` tag values (grant eid, version, edition hash) a non-owner member cites. */
  vacFor(member: string): [string, string, string];
}

/** A world with a senior (2), a mid (3, PIN_MESSAGES only), a junior (5) and a BAN-only staff member (5). */
async function staffWorld(): Promise<StaffWorld> {
  const { material } = await createCommunity({ ownerPubkey: OWNER, name: "Test", relays: [] });
  const cid = hexToBytes(material.community_id);
  const roles = [
    role(ROLE_SENIOR, 2, PERM.BAN | PERM.MANAGE_ROLES),
    role(ROLE_MID, 3, PERM.PIN_MESSAGES),
    role(ROLE_JUNIOR, 5, PERM.BAN | PERM.MANAGE_ROLES),
    role(ROLE_BAN_ONLY, 5, PERM.BAN),
  ];
  const grants: Array<[string, string]> = [
    [SENIOR, ROLE_SENIOR],
    [MID, ROLE_MID],
    [JUNIOR, ROLE_JUNIOR],
    [BAN_ONLY, ROLE_BAN_ONLY],
  ];
  const grantContent = (member: string, roleId: string) => JSON.stringify({ member, role_ids: [roleId] });
  const events = [
    ...await Promise.all(roles.map(async (body) =>
      decoded(
        await EditionFactory.create({ vsk: VSK.ROLE, eid: body.role_id, version: 1, content: JSON.stringify(body) }),
        OWNER,
      )
    )),
    ...await Promise.all(grants.map(async ([member, roleId]) =>
      decoded(
        await EditionFactory.create({
          vsk: VSK.GRANT,
          eid: grantLocator(cid, member),
          version: 1,
          content: grantContent(member, roleId),
        }),
        OWNER,
      )
    )),
  ];
  const vacFor = (member: string): [string, string, string] => {
    const roleId = grants.find(([m]) => m === member)![1];
    const eid = grantLocator(cid, member);
    return [eid, "1", computeEditionHash({ vsk: VSK.GRANT, eid, version: 1, content: grantContent(member, roleId) })];
  };
  return { material, cid, events, vacFor };
}

/** A state with a senior (2), a mid (3, PIN_MESSAGES only), a junior (5) and a BAN-only staff member (5). */
async function staffState(): Promise<CommunityState> {
  const world = await staffWorld();
  return foldControl(world.events, world.material);
}

/** One Banlist edition by `author` (citing its Grant unless it is the owner) and the hash the next edition cites. */
async function banEdition(
  world: StaffWorld,
  author: string,
  members: string[],
  options: { version?: number; prev?: string; id?: string; ms?: number } = {},
): Promise<{ event: DecodedEvent; hash: string }> {
  const eid = banlistLocator(world.cid);
  const version = options.version ?? 1;
  const content = JSON.stringify(members);
  const template = await EditionFactory.create({
    vsk: VSK.BANLIST,
    eid,
    version,
    content,
    prevHash: options.prev,
    vac: author === OWNER ? undefined : world.vacFor(author),
  });
  return {
    event: decoded(template, author, options.ms ?? 3_000, options.id),
    hash: computeEditionHash({ vsk: VSK.BANLIST, eid, version, prevHash: options.prev, content }),
  };
}

describe("Banlist write planning (CORD-04 §§4, 6, BAN-01, D-09, D-19)", () => {
  it("parseBanlist accepts only an array of 64-hex keys", () => {
    expect(parseBanlist("[]")).toEqual([]);
    expect(parseBanlist(JSON.stringify([TARGET, TARGET.toUpperCase()]))).toEqual([TARGET, TARGET.toUpperCase()]);
    expect(parseBanlist("not json")).toBeUndefined();
    expect(parseBanlist("{}")).toBeUndefined();
    expect(parseBanlist(JSON.stringify([TARGET, "short"]))).toBeUndefined();
    expect(parseBanlist(JSON.stringify([TARGET, 5]))).toBeUndefined();
  });

  it("normalizeBanTargets lowercases, dedupes and reports invalid keys", () => {
    const result = normalizeBanTargets([TARGET.toUpperCase(), TARGET, OTHER, "nope", 5, null]);
    expect(result.targets).toEqual([TARGET, OTHER]);
    expect(result.failures).toEqual([
      { member: "nope", reason: "invalid-key" },
      { member: "5", reason: "invalid-key" },
      { member: "null", reason: "invalid-key" },
    ]);
  });

  it("banTargetFailures lists every failing target with its reason (D-09)", async () => {
    const state = await staffState();
    const failures = banTargetFailures(state, JUNIOR, [OWNER, JUNIOR, SENIOR, MID, TARGET]);
    expect(failures).toEqual([
      { member: OWNER, reason: "owner" },
      { member: JUNIOR, reason: "self" },
      { member: SENIOR, reason: "not-outranked" },
      { member: MID, reason: "not-outranked" },
    ]);
    // A writer with BAN but not MANAGE_ROLES cannot strip the roles a ban is paired with.
    expect(banTargetFailures(state, BAN_ONLY, [TARGET])).toEqual([{ member: TARGET, reason: "cannot-strip-roles" }]);
    // A writer with neither is not outranking anyone.
    expect(banTargetFailures(state, TARGET, [OTHER])).toEqual([{ member: OTHER, reason: "not-outranked" }]);
  });

  it("banTargetFailures lets the owner ban any member except the owner and self", async () => {
    const state = await staffState();
    expect(banTargetFailures(state, OWNER, [SENIOR, MID, JUNIOR, TARGET])).toEqual([]);
    expect(banTargetFailures(state, OWNER, [OWNER])).toEqual([{ member: OWNER, reason: "owner" }]);
  });

  it("planBanlistWrite builds from the head content, not the effective set", () => {
    // MID is in the head content but is not effective in any state (its signer did not outrank it): the next
    // content still carries it, in its place, followed by the new members in input order.
    const plan = planBanlistWrite({
      base: [MID, TARGET],
      owner: OWNER,
      add: [OTHER, TARGET, SENIOR],
      canVouch: () => true,
    });
    expect(plan).toEqual({ kind: "write", content: [MID, TARGET, OTHER, SENIOR] });
    expect(
      planBanlistWrite({ base: [MID, TARGET], owner: OWNER, remove: [TARGET], canVouch: () => true }),
    ).toEqual({ kind: "write", content: [MID] });
  });

  it("planBanlistWrite blocks a write that would carry an entry the writer cannot vouch for (D-19)", () => {
    const canVouch = (member: string) => member !== MID;
    expect(unvouchedEntries([MID, TARGET, OWNER], OWNER, canVouch)).toEqual([MID]);
    expect(planBanlistWrite({ base: [MID], owner: OWNER, add: [TARGET], canVouch })).toEqual({
      kind: "blocked",
      members: [MID],
      reason: "unvouched-entries",
    });
    // Lifting a vouchable ban leaves the unvouchable one in the remaining list: the write is refused, not trimmed.
    expect(planBanlistWrite({ base: [MID, TARGET], owner: OWNER, remove: [TARGET], canVouch })).toEqual({
      kind: "blocked",
      members: [MID],
      reason: "unvouched-entries",
    });
  });

  it("planBanlistWrite refuses to remove an entry the writer cannot vouch for (D-19)", () => {
    const canVouch = (member: string) => member !== MID;
    expect(planBanlistWrite({ base: [MID, TARGET], owner: OWNER, remove: [MID], canVouch })).toEqual({
      kind: "blocked",
      members: [MID],
      reason: "not-outranked",
    });
    // Removing a member that is not in the head content needs no authority over it: there is nothing to remove.
    expect(planBanlistWrite({ base: [TARGET], owner: OWNER, remove: [MID], canVouch })).toEqual({ kind: "unchanged" });
  });

  it("planBanlistWrite drops the owner key and reports an unchanged list as unchanged", () => {
    expect(planBanlistWrite({ base: [OWNER, TARGET], owner: OWNER, canVouch: () => true })).toEqual({
      kind: "write",
      content: [TARGET],
    });
    expect(planBanlistWrite({ base: [TARGET], owner: OWNER, canVouch: () => true })).toEqual({ kind: "unchanged" });
    expect(planBanlistWrite({ base: [TARGET], owner: OWNER, add: [TARGET], canVouch: () => true })).toEqual({
      kind: "unchanged",
    });
    // A forced write republishes the head content unchanged (D-21).
    expect(planBanlistWrite({ base: [TARGET], owner: OWNER, canVouch: () => true, force: true })).toEqual({
      kind: "write",
      content: [TARGET],
    });
  });

  it("newestOwnBanlistEdition picks this client's highest-version Banlist edition (D-14, D-21)", async () => {
    const { material } = await createCommunity({ ownerPubkey: OWNER, name: "Test", relays: [] });
    const eid = banlistLocator(hexToBytes(material.community_id));
    const edition = async (version: number, author: string, ms: number, id: string, entity = eid) =>
      decoded(
        await EditionFactory.create({
          vsk: VSK.BANLIST,
          eid: entity,
          version,
          content: JSON.stringify([]),
          prevHash: version > 1 ? "00".repeat(32) : undefined,
        }),
        author,
        ms,
        id,
      );
    const records = [
      await edition(1, OWNER, 1_000, "a1"),
      await edition(2, OWNER, 2_000, "b2"),
      await edition(2, OWNER, 2_000, "a2"),
      await edition(2, OWNER, 1_500, "00"),
      await edition(9, SENIOR, 9_000, "c9"),
      await edition(7, OWNER, 7_000, "d7", "99".repeat(32)),
      { rumor: undefined } as unknown as ReturnType<typeof decoded>,
    ];
    const newest = newestOwnBanlistEdition(records, eid, OWNER);
    // Highest version, then the later ms, then the lower rumor id.
    expect(newest?.rumor.id).toBe("a2");
    expect(newestOwnBanlistEdition(records, eid, MID)).toBeUndefined();
    expect(newestOwnBanlistEdition([], eid, OWNER)).toBeUndefined();
  });
});

describe("Banlist fold (CORD-04 §§1, 3, 4, 5)", () => {
  // Non-vacuity: the BAN holder's identical list is honored, so the first assertion cannot pass on an empty fold.
  it("honors a Banlist only when its signer holds BAN (CORD-04 §4)", async () => {
    const world = await staffWorld();
    // MID (position 3) outranks the roleless target but holds only PIN_MESSAGES.
    const midList = await banEdition(world, MID, [TARGET]);
    expect(foldControl([...world.events, midList.event], world.material).banlist.size).toBe(0);
    const juniorList = await banEdition(world, JUNIOR, [TARGET]);
    expect([...foldControl([...world.events, juniorList.event], world.material).banlist]).toEqual([TARGET]);
  });

  // Non-vacuity: the senior's list bans all three, so the junior's refusal of a peer is not a fold that honors nothing.
  it("honors a Banlist entry only when its signer strictly outranks the target: a peer is not banned (CORD-04 §3)", async () => {
    const world = await staffWorld();
    // JUNIOR and BAN_ONLY share position 5: equal cannot act on equal.
    const peerList = await banEdition(world, JUNIOR, [BAN_ONLY, TARGET]);
    expect([...foldControl([...world.events, peerList.event], world.material).banlist]).toEqual([TARGET]);
    const seniorList = await banEdition(world, SENIOR, [JUNIOR, BAN_ONLY, MID]);
    expect([...foldControl([...world.events, seniorList.event], world.material).banlist].sort()).toEqual(
      [JUNIOR, BAN_ONLY, MID].sort(),
    );
  });

  // Non-vacuity: the same lists ban every other member, so only the owner key is exempt.
  it("never bans the owner, whoever signs the list (CORD-04 §2)", async () => {
    const world = await staffWorld();
    const ownerList = await banEdition(world, OWNER, [OWNER, TARGET]);
    expect([...foldControl([...world.events, ownerList.event], world.material).banlist]).toEqual([TARGET]);
    const seniorList = await banEdition(world, SENIOR, [OWNER, TARGET]);
    expect([...foldControl([...world.events, seniorList.event], world.material).banlist]).toEqual([TARGET]);
  });

  // Non-vacuity: before the ban the same Role edition is folded, and the ban removes only the banned signer's edition.
  it("drops the authority actions of a banned npub (CORD-04 §4)", async () => {
    const world = await staffWorld();
    const roleId = "05".repeat(32);
    const created = await EditionFactory.create({
      vsk: VSK.ROLE,
      eid: roleId,
      version: 1,
      content: JSON.stringify(role(roleId, 8, PERM.PIN_MESSAGES)),
      vac: world.vacFor(JUNIOR),
    });
    const roleEdition = decoded(created, JUNIOR, 2_000);
    const before = foldControl([...world.events, roleEdition], world.material);
    expect(before.roles.some((entry) => entry.role_id === roleId)).toBe(true);
    // SENIOR (position 2) bans JUNIOR (position 5): everything JUNIOR signed is dropped, nothing else.
    const ban = await banEdition(world, SENIOR, [JUNIOR]);
    const after = foldControl([...world.events, roleEdition, ban.event], world.material);
    expect([...after.banlist]).toEqual([JUNIOR]);
    expect(after.roles.some((entry) => entry.role_id === roleId)).toBe(false);
    expect(after.roles.map((entry) => entry.role_id).sort()).toEqual(
      before.roles.map((entry) => entry.role_id).filter((id) => id !== roleId).sort(),
    );
  });

  // Non-vacuity: a fold that kept the union of every version would still ban B after the second edition lifts it, and
  // one that took the lowest version would show the first list.
  it("replaces the whole list with the highest version and refuses to downgrade (CORD-04 §1, §4)", async () => {
    const world = await staffWorld();
    const first = await banEdition(world, OWNER, [TARGET, OTHER], { version: 1, id: "a1" });
    const second = await banEdition(world, OWNER, [TARGET], { version: 2, prev: first.hash, id: "a2" });
    const fold = (...events: DecodedEvent[]) => foldControl([...world.events, ...events], world.material).banlist;
    expect([...fold(first.event)].sort()).toEqual([TARGET, OTHER].sort());
    // A relay replaying the lifted version after the new one changes nothing, in either delivery order.
    expect([...fold(first.event, second.event)]).toEqual([TARGET]);
    expect([...fold(second.event, first.event)]).toEqual([TARGET]);
  });

  // Non-vacuity: the winner is the lower rumor id in both delivery orders, not the first or the last delivered.
  it("keeps one of two same-version Banlist editions, the lower rumor id, and drops the other's addition (CORD-04 §1, §4)", async () => {
    const world = await staffWorld();
    const low = await banEdition(world, JUNIOR, [TARGET], { id: "01".repeat(32) });
    const high = await banEdition(world, SENIOR, [OTHER], { id: "02".repeat(32) });
    const fold = (...events: DecodedEvent[]) => foldControl([...world.events, ...events], world.material).banlist;
    expect([...fold(low.event, high.event)]).toEqual([TARGET]);
    expect([...fold(high.event, low.event)]).toEqual([TARGET]);
  });
});

describe("a banned npub vanishes from membership (CORD-04 §4)", () => {
  const owner = "owner";
  const standing = (member: string) => resolveStanding(member, owner, new Map(), new Map<string, string[]>());
  const join = (pk: string, ms: number) =>
    decoded({ kind: 3306, content: "join", tags: [["ms", String(ms % 1000)]] }, pk, ms);

  // Non-vacuity: without the ban the same observed activity makes the authors members.
  it("removes a banned author from observed activity", () => {
    const entries = [join("alice", 1_000), join("dave", 1_000)];
    const observed = new Map([["dave", 5_000], ["erin", 5_000]]);
    const open = foldMembers(entries, observed, new Set(), standing, 10_000);
    expect([...open].sort()).toEqual(["alice", "dave", "erin"]);
    const banned = foldMembers(entries, observed, new Set(["dave", "erin"]), standing, 10_000);
    expect([...banned]).toEqual(["alice"]);
  });

  // Non-vacuity: the same Snapshot from an unbanned refounder seeds the member, so the banned one's is ignored on purpose.
  it("ignores the membership effects of a banned author, including a secondhand Snapshot", () => {
    const snapshot = (author: string, members: string[], ms: number) =>
      decoded(
        {
          kind: 3312,
          content: JSON.stringify(members),
          tags: [["snap", "s1", "1", "1"], ["ms", String(ms % 1000)]],
        },
        author,
        ms,
      );
    const entries = [snapshot("refounder", ["frank"], 1_000)];
    const open = foldMembers(entries, new Map(), new Set(), standing, 10_000, "refounder");
    expect([...open]).toEqual(["frank"]);
    const banned = foldMembers(entries, new Map(), new Set(["refounder"]), standing, 10_000, "refounder");
    expect([...banned]).toEqual([]);
  });
});
