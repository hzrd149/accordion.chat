import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import { getEventHash } from "applesauce-core/helpers/event";
import { sealRumor } from "../../operations/gift-wrap.ts";
import type { Rumor } from "../../types.ts";
import { EDIT_KIND } from "../edit.ts";
import { projectPins } from "../pin-projection.ts";
import { createPinProof, type PinEntry, type PinListRead } from "../pins.ts";

const channel = "ab".repeat(32);
const key = new Uint8Array(32).fill(2);
const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
const pubkey = await signer.getPublicKey();
const NOW = 1_000;

async function proven(
  kind: number,
  content: string,
  createdAt: number,
  tags: string[][] = [],
): Promise<{ rumor: Rumor; entry: PinEntry }> {
  const rumor = {
    pubkey,
    id: "",
    kind,
    content,
    tags: [["channel", channel], ["epoch", "0"], ...tags],
    created_at: createdAt,
  };
  rumor.id = getEventHash(rumor);
  const seal = await sealRumor(key, signer)(rumor);
  return { rumor, entry: createPinProof(seal, key) as PinEntry };
}

/** A pinned message with an optional bundled Edit. */
async function pinned(
  options: { expiration?: number; edit?: { content: string; at: number; expiration?: number } } = {},
) {
  const original = await proven(
    9,
    "original",
    10,
    options.expiration ? [["expiration", String(options.expiration)]] : [],
  );
  let bundled: Awaited<ReturnType<typeof proven>> | undefined;
  if (options.edit) {
    bundled = await proven(
      EDIT_KIND,
      options.edit.content,
      options.edit.at,
      [["e", original.rumor.id], ...(options.edit.expiration ? [["expiration", String(options.edit.expiration)]] : [])],
    );
  }
  const entry: PinEntry = bundled ? { ...original.entry, edit: bundled.entry } : original.entry;
  const list: PinListRead = { available: true, entries: [entry] };
  return { original: original.rumor, entry, list, bundled: bundled?.rumor };
}

function localEdit(
  original: Rumor,
  content: string,
  createdAt: number,
  over: { pubkey?: string; channel?: string; target?: string; expiration?: number } = {},
): Rumor {
  const base = {
    pubkey: over.pubkey ?? pubkey,
    id: "",
    kind: EDIT_KIND,
    content,
    tags: [
      ["e", over.target ?? original.id],
      ["channel", over.channel ?? channel],
      ["epoch", "0"],
      ...(over.expiration ? [["expiration", String(over.expiration)]] : []),
    ],
    created_at: createdAt,
  };
  return { ...base, id: getEventHash(base) };
}

describe("pin projection", () => {
  it("a newer local Edit replaces the bundled text and marks the pin edited and behind", async () => {
    const { original, list, bundled } = await pinned({ edit: { content: "bundled", at: 20 } });
    const newer = localEdit(original, "newer", 30);
    const [pin] = projectPins(list, channel, { rumors: [newer], now: NOW });
    expect(pin.text).toBe("newer");
    expect(pin.edit?.id).toBe(newer.id);
    expect(pin.edited).toBe(true);
    expect(pin.behind).toBe(true);
    const [bundledOnly] = projectPins(list, channel, { now: NOW });
    expect(bundledOnly.edit?.id).toBe(bundled!.id);
    expect(bundledOnly.text).toBe("bundled");
    expect(bundledOnly.behind).toBe(false);
    // A local Edit with no bundled one is a refresh candidate too.
    const bare = await pinned();
    const [fresh] = projectPins(bare.list, channel, { rumors: [localEdit(bare.original, "late", 30)], now: NOW });
    expect(fresh.edited).toBe(true);
    expect(fresh.behind).toBe(true);
    const [plain] = projectPins(bare.list, channel, { now: NOW });
    expect(plain.edited).toBe(false);
    expect(plain.text).toBe("original");
    expect(plain.edit).toBeUndefined();
  });

  it("a local Edit older than the bundled proof never replaces it", async () => {
    const { original, list, bundled } = await pinned({ edit: { content: "bundled", at: 20 } });
    const [pin] = projectPins(list, channel, { rumors: [localEdit(original, "older", 15)], now: NOW });
    expect(pin.text).toBe("bundled");
    expect(pin.edit?.id).toBe(bundled!.id);
    expect(pin.behind).toBe(false);
  });

  it("an Edit by another pubkey, for another channel, or of an edit is ignored", async () => {
    const { original, list, bundled } = await pinned({ edit: { content: "bundled", at: 20 } });
    const rumors = [
      localEdit(original, "author", 90, { pubkey: "cd".repeat(32) }),
      localEdit(original, "channel", 91, { channel: "cd".repeat(32) }),
      localEdit(original, "of edit", 92, { target: bundled!.id }),
    ];
    const [pin] = projectPins(list, channel, { rumors, now: NOW });
    expect(pin.text).toBe("bundled");
    expect(pin.behind).toBe(false);
  });

  it("a self-deletion by the proven author hides the pin; one by another pubkey does not", async () => {
    const { original, list } = await pinned();
    const deletion = { ...original, id: "00".repeat(32), kind: 5, tags: [["e", original.id]] };
    expect(projectPins(list, channel, { rumors: [deletion], now: NOW })).toEqual([]);
    expect(projectPins(list, channel, { rumors: [{ ...deletion, pubkey: "cd".repeat(32) }], now: NOW })).toHaveLength(
      1,
    );
    expect(projectPins({ available: false }, channel, { rumors: [], now: NOW })).toEqual([]);
  });

  /** A kind 5 by `by` (default: the Edit's author) naming the recomputed id of `target`. */
  const deletionOf = (target: Rumor, by: string = target.pubkey): Rumor => ({
    ...target,
    id: "00".repeat(32),
    kind: 5,
    pubkey: by,
    content: "",
    tags: [["e", target.id]],
  });

  it("a local Edit its author deleted is never shown and the pin falls back to the newest undeleted Edit or the original (D-31)", async () => {
    // Non-vacuity: drop `deletions: rumors` from the local chooser call and the deleted newer Edit is still shown.
    const { original, list } = await pinned();
    const e1 = localEdit(original, "first", 30);
    const e2 = localEdit(original, "second", 40);
    const [one] = projectPins(list, channel, { rumors: [e1, e2, deletionOf(e2)], now: NOW });
    expect(one.text).toBe("first");
    expect(one.edited).toBe(true);
    expect(one.behind).toBe(true);
    expect(one.edit?.id).toBe(e1.id);
    const [none] = projectPins(list, channel, { rumors: [e1, e2, deletionOf(e1), deletionOf(e2)], now: NOW });
    expect(none.text).toBe("original");
    expect(none.edited).toBe(false);
    expect(none.behind).toBe(false);
    expect(none.edit).toBeUndefined();
    // Only the author's own deletion counts.
    const [kept] = projectPins(list, channel, { rumors: [e1, e2, deletionOf(e2, "cd".repeat(32))], now: NOW });
    expect(kept.text).toBe("second");
  });

  it("a bundled Edit its author deleted is not shown and the pin is marked behind (D-31)", async () => {
    // Non-vacuity: drop `deletions: rumors` from the applied chooser call, or keep `behind` tied to a newer Edit.
    const { list, bundled, entry } = await pinned({ edit: { content: "bundled", at: 20 } });
    const [pin] = projectPins(list, channel, { rumors: [deletionOf(bundled!)], now: NOW });
    expect(pin.text).toBe("original");
    expect(pin.edited).toBe(false);
    expect(pin.behind).toBe(true);
    expect(pin.edit).toBeUndefined();
    expect(pin.entry).toEqual(entry);
    expect(pin.entry.edit).toEqual(entry.edit);
    const [other] = projectPins(list, channel, { rumors: [deletionOf(bundled!, "cd".repeat(32))], now: NOW });
    expect(other.text).toBe("bundled");
    expect(other.behind).toBe(false);
  });

  describe("a message listed more than once", () => {
    async function duplicated() {
      const original = await proven(9, "original", 10);
      const other = await proven(9, "other", 11);
      const edit1 = await proven(EDIT_KIND, "edit1", 20, [["e", original.rumor.id]]);
      const edit2 = await proven(EDIT_KIND, "edit2", 30, [["e", original.rumor.id]]);
      const withEdit1: PinEntry = { ...original.entry, edit: edit1.entry };
      const withEdit2: PinEntry = { ...original.entry, edit: edit2.entry };
      return { original, other, edit1, edit2, withEdit1, withEdit2 };
    }
    const listOf = (...entries: PinEntry[]): PinListRead => ({ available: true, entries });

    it("a message listed twice shows the copy whose bundled Edit is newest at its first position (D-32)", async () => {
      // Non-vacuity: let the last copy win, as the old Map did, and [orig+edit2, orig+edit1] shows "edit1" (CR-01).
      const { other, withEdit1, withEdit2 } = await duplicated();
      const pins = projectPins(listOf(withEdit2, withEdit1, other.entry), channel, { now: NOW });
      const [first, second] = pins;
      expect(pins.map((p) => p.text)).toEqual(["edit2", "other"]);
      expect(first.behind).toBe(false);
      expect(first.entry).toEqual(withEdit2);
      expect(second.text).toBe("other");
      // The message keeps the position of its first copy and the content of the newest bundle.
      expect(projectPins(listOf(withEdit1, other.entry, withEdit2), channel, { now: NOW }).map((p) => p.text))
        .toEqual(["edit2", "other"]);
      // Non-vacuity: replace on a tie and the second wrap hint would win.
      const hinted1: PinEntry = { ...withEdit1, wrap: "aa".repeat(32) };
      const hinted2: PinEntry = { ...withEdit1, wrap: "bb".repeat(32) };
      expect(projectPins(listOf(hinted1, hinted2), channel, {})[0].entry.wrap).toBe("aa".repeat(32));
      const bare = await duplicated();
      const plain1: PinEntry = { ...bare.original.entry, wrap: "aa".repeat(32) };
      const plain2: PinEntry = { ...bare.original.entry, wrap: "bb".repeat(32) };
      expect(projectPins(listOf(plain1, plain2), channel, {})[0].entry.wrap).toBe("aa".repeat(32));
    });

    it("a duplicate whose bundled Edit its author deleted never wins over an undeleted bundle (D-32)", async () => {
      // Non-vacuity: compare the bundles without deletions and the deleted edit2 bundle wins (or, with last-wins, stays).
      const { edit1, edit2, withEdit1, withEdit2 } = await duplicated();
      const deleted = deletionOf(edit2.rumor);
      for (const entries of [[withEdit1, withEdit2], [withEdit2, withEdit1]]) {
        const [pin] = projectPins(listOf(...entries), channel, { rumors: [deleted], now: NOW });
        expect(pin.text).toBe("edit1");
        expect(pin.behind).toBe(false);
        expect(pin.edit?.id).toBe(edit1.rumor.id);
        expect(pin.entry).toEqual(withEdit1);
      }
      // Only the author's own deletion counts.
      const foreign = deletionOf(edit2.rumor, "cd".repeat(32));
      expect(projectPins(listOf(withEdit1, withEdit2), channel, { rumors: [foreign], now: NOW })[0].text).toBe("edit2");
    });
  });

  it("an expired pin is hidden unless showExpired, which exposes expiresAt", async () => {
    const { list } = await pinned({ expiration: 500 });
    expect(projectPins(list, channel, { now: NOW })).toEqual([]);
    const [pin] = projectPins(list, channel, { now: NOW, showExpired: true });
    expect(pin.expiresAt).toBe(500);
    expect(pin.text).toBe("original");
    const live = projectPins(list, channel, { now: 400 });
    expect(live).toHaveLength(1);
    expect(live[0].expiresAt).toBe(500);
    // With no clock the projection performs no expiry hiding.
    expect(projectPins(list, channel, {})).toHaveLength(1);
  });

  it("an expired newest Edit hides the pin by default and showExpired shows only that Edit's text (D-11)", async () => {
    const { list } = await pinned({ edit: { content: "bundled edit", at: 20, expiration: 500 } });
    expect(projectPins(list, channel, { now: NOW })).toEqual([]);
    const [pin] = projectPins(list, channel, { now: NOW, showExpired: true });
    expect(pin.text).toBe("bundled edit");
    expect(pin.edited).toBe(true);
    expect(pin.expiresAt).toBe(500);
    expect(pin.text).not.toBe("original");
  });

  it("an expired newer local Edit never falls back to the bundled or original text (D-11)", async () => {
    const { original, list } = await pinned({ edit: { content: "bundled", at: 20 } });
    const expired = localEdit(original, "expired local", 30, { expiration: 500 });
    expect(projectPins(list, channel, { rumors: [expired], now: NOW })).toEqual([]);
    const [pin] = projectPins(list, channel, { rumors: [expired], now: NOW, showExpired: true });
    expect(pin.text).toBe("expired local");
    expect(pin.expiresAt).toBe(500);
    expect(pin.behind).toBe(true);
    // Before the boundary the same Edit is simply current.
    expect(projectPins(list, channel, { rumors: [expired], now: 400 })[0].text).toBe("expired local");
  });

  it("a keyless reader verifies a public pin and shows its bundled Edit as edited", async () => {
    const { list } = await pinned({ edit: { content: "bundled", at: 20 } });
    const [pin] = projectPins(list, channel, {});
    expect(pin.edited).toBe(true);
    expect(pin.text).toBe("bundled");
    expect(pin.behind).toBe(false);
  });

  it("entry stays the original bundle verbatim when a local Edit is applied", async () => {
    const { original, list, entry } = await pinned({ edit: { content: "bundled", at: 20 } });
    const [pin] = projectPins(list, channel, { rumors: [localEdit(original, "newer", 30)], now: NOW });
    expect(pin.entry).toEqual(entry);
    expect(pin.entry.edit).toEqual(entry.edit);
  });

  it("projectPins never mutates the verified pins it is given", async () => {
    const { original, list } = await pinned();
    const { verifyPinEntry } = await import("../pins.ts");
    const shared = verifyPinEntry((list as { entries: PinEntry[] }).entries[0], channel)!;
    const snapshot = structuredClone(shared);
    const [pin] = projectPins(list, channel, {
      rumors: [localEdit(original, "newer", 30)],
      now: NOW,
      verify: () => shared,
    });
    expect(pin).not.toBe(shared);
    expect(shared).toEqual(snapshot);
    expect(pin.text).toBe("newer");
  });

  it("drops invalid entries one at a time and dedupes by recomputed id", async () => {
    const { list } = await pinned();
    const entry = (list as { entries: PinEntry[] }).entries[0];
    const mixed: PinListRead = { available: true, entries: [entry, {} as PinEntry, entry] };
    expect(projectPins(mixed, channel, {})).toHaveLength(1);
  });

  // Non-vacuity: without the ban check a banned proven author's pin would still be projected, so the first assertion
  // fails; ignoring `showBanned` would hide the pin from the opt-in reader, so the second fails.
  it("a pin whose proven author is banned is hidden unless showBanned is set (CORD-04 §7 moderation suppression)", async () => {
    const { list } = await pinned();
    const banned = (who: string) => who === pubkey;
    expect(projectPins(list, channel, { now: NOW, isBanned: banned })).toEqual([]);
    expect(projectPins(list, channel, { now: NOW, isBanned: banned, showBanned: true })).toHaveLength(1);
    expect(projectPins(list, channel, { now: NOW, isBanned: (who) => who !== pubkey })).toHaveLength(1);
    // No ban predicate means nothing is suppressed, as for the keyless readers and pin upkeep.
    expect(projectPins(list, channel, { now: NOW })).toHaveLength(1);
  });
});
