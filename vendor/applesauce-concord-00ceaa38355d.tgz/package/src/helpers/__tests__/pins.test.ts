import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import { getEventHash } from "applesauce-core/helpers/event";
import { nip44 } from "applesauce-core/helpers/encryption";
import { sealRumor } from "../../operations/gift-wrap.ts";
import { createPinProof, describePinList, encodePinList, type PinEntry, readPinList, verifyPinEntry } from "../pins.ts";
import { verifiedPins } from "../pin-projection.ts";

const channel = "ab".repeat(32);
const key = new Uint8Array(32).fill(2);
async function fixture(kind = 9, tags: string[][] = []) {
  const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
  const rumor = {
    pubkey: await signer.getPublicKey(),
    id: "",
    kind,
    content: "proven words",
    tags: [["channel", channel], ["epoch", "0"], ...tags],
    created_at: 1,
  };
  rumor.id = getEventHash(rumor);
  const seal = await sealRumor(key, signer)(rumor);
  return { rumor, entry: createPinProof(seal, key) as PinEntry };
}

describe("provable pins", () => {
  it("verifies original ciphertext without any channel key and recomputes rumor identity", async () => {
    const { rumor, entry } = await fixture();
    expect(verifyPinEntry(entry, channel)?.rumor).toEqual(rumor);
    expect(verifyPinEntry(entry, "cd".repeat(32))).toBeUndefined();
    expect(verifyPinEntry({ ...entry, keys: "00".repeat(76) }, channel)).toBeUndefined();
    expect(verifyPinEntry({ ...entry, seal: { ...entry.seal, content: entry.seal.content + "A" } }, channel))
      .toBeUndefined();
    expect(() => createPinProof(entry.seal, new Uint8Array(32))).toThrow();
  });

  it("accepts only message kinds and author-matched edits targeting the proven original", async () => {
    const { rumor, entry } = await fixture();
    const edit = await fixture(3302, [["e", rumor.id]]);
    expect(verifyPinEntry({ ...entry, edit: edit.entry }, channel)?.edit?.kind).toBe(3302);
    const wrong = await fixture(3302, [["e", "00".repeat(32)]]);
    expect(verifyPinEntry({ ...entry, edit: wrong.entry }, channel)?.edit).toBeUndefined();
    expect(verifyPinEntry(edit.entry, channel)).toBeUndefined();
  });

  it("distinguishes unavailable private keys from readable empty and enforces both caps", async () => {
    const { entry } = await fixture();
    const sealed = encodePinList([entry], { epoch: 4, convKey: key });
    expect(readPinList(sealed)).toEqual({ available: false });
    expect(readPinList(sealed, (epoch) => epoch === "4" ? key : undefined)).toEqual({
      available: true,
      entries: [entry],
    });
    expect(readPinList(undefined)).toEqual({ available: false });
    expect(readPinList(JSON.stringify({ entries: Array(26).fill(entry) }))).toEqual({ available: true, entries: [] });
    expect(readPinList(" ".repeat(32769))).toEqual({ available: true, entries: [] });
    expect(() => encodePinList(Array(26).fill(entry))).toThrow();
  });

  it("drops malformed entries individually, deduplicates and honors only the original author's deletion", async () => {
    const { rumor, entry } = await fixture();
    const list = { available: true as const, entries: [entry, {} as PinEntry, entry] };
    expect(verifiedPins(list, channel)).toHaveLength(1);
    const deletion = { ...rumor, kind: 5, tags: [["e", rumor.id]] };
    expect(verifiedPins(list, channel, [{ ...deletion, pubkey: "00".repeat(32) }])).toHaveLength(1);
    expect(verifiedPins(list, channel, [deletion])).toEqual([]);
  });
});

/** Differences from a well-formed proof bundle, for the verifier steps of CORD-04 §7. */
interface BundleOverrides {
  /** Signer of the seal; the default is the fixture's own key. */
  signer?: PrivateKeySigner;
  kind?: number;
  /** Replaces the default `channel` and `epoch` tags. */
  tags?: string[][];
  /** Rumor author, when it differs from the seal's signer. */
  rumorPubkey?: string;
  /** Rumor text; the default is shared by all fixtures. */
  content?: string;
  /** An embedded id that is not the rumor's hash. */
  id?: string;
}

/** A proof bundle of a rumor built to the overrides, sealed under the shared key. */
async function bundle(over: BundleOverrides = {}) {
  const signer = over.signer ?? new PrivateKeySigner(new Uint8Array(32).fill(1));
  const rumor = {
    pubkey: over.rumorPubkey ?? await signer.getPublicKey(),
    id: "",
    kind: over.kind ?? 9,
    content: over.content ?? "proven words",
    tags: over.tags ?? [["channel", channel], ["epoch", "0"]],
    created_at: 1,
  };
  rumor.id = over.id ?? getEventHash(rumor);
  const seal = await sealRumor(key, signer)(rumor);
  return { rumor, seal, entry: createPinProof(seal, key) as PinEntry };
}

describe("pin verifier steps (CORD-04 §7 proof bundle)", () => {
  it("an entry failing any verifier step is invalid and dropped alone (CORD-04 §7 proof bundle)", async () => {
    const good = await bundle();
    expect(verifyPinEntry(good.entry, channel)?.rumor.id).toBe(good.rumor.id);
    // Step 1: the seal must be kind 20013 with a valid signature. This seal is validly signed but is kind 20014.
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const plaintextKind = await signer.signEvent({
      kind: 20014,
      content: good.seal.content,
      tags: [],
      created_at: good.seal.created_at,
    });
    expect(verifyPinEntry({ ...good.entry, seal: plaintextKind }, channel)).toBeUndefined();
    const other = await bundle({ rumorPubkey: undefined, tags: [["channel", channel], ["epoch", "1"]] });
    expect(verifyPinEntry({ ...good.entry, seal: { ...good.seal, sig: other.seal.sig } }, channel)).toBeUndefined();
    // Step 2: the MAC is checked with the disclosed hmac key; a bundle of another message fails it.
    expect(verifyPinEntry({ ...good.entry, keys: other.entry.keys }, channel)).toBeUndefined();
    // The chacha key and nonce are right and only the hmac key is wrong: the MAC alone must reject it.
    expect(verifyPinEntry({ ...good.entry, keys: good.entry.keys.slice(0, 88) + "00".repeat(32) }, channel))
      .toBeUndefined();
    expect(verifyPinEntry({ ...good.entry, keys: good.entry.keys.slice(2) }, channel)).toBeUndefined();
    expect(verifyPinEntry({ ...good.entry, keys: good.entry.keys.toUpperCase() }, channel)).toBeUndefined();
    // Step 4: the rumor author equals the seal's, the kind is 9 or 1111, and the channel tag equals the list's.
    const stranger = await new PrivateKeySigner(new Uint8Array(32).fill(7)).getPublicKey();
    expect(verifyPinEntry((await bundle({ rumorPubkey: stranger })).entry, channel)).toBeUndefined();
    expect(verifyPinEntry((await bundle({ kind: 7 })).entry, channel)).toBeUndefined();
    expect(verifyPinEntry((await bundle({ kind: 1111 })).entry, channel)?.rumor.kind).toBe(1111);
    expect(verifyPinEntry((await bundle({ tags: [["epoch", "0"]] })).entry, channel)).toBeUndefined();
    expect(verifyPinEntry((await bundle({ tags: [["channel", "cd".repeat(32)], ["epoch", "0"]] })).entry, channel))
      .toBeUndefined();
    // Step 5: the entry's identity is the recomputed rumor id, never an embedded one.
    const forged = await bundle({ id: "ff".repeat(32), content: "forged id words" });
    expect(verifyPinEntry(forged.entry, channel)?.rumor.id).toBe(getEventHash(forged.rumor));
    expect(verifyPinEntry(forged.entry, channel)?.rumor.id).not.toBe("ff".repeat(32));
    // An invalid entry is dropped alone: its neighbours survive in order.
    const list = {
      available: true as const,
      entries: [good.entry, { ...good.entry, keys: "00".repeat(76) }, forged.entry],
    };
    expect(verifiedPins(list, channel).map((pin) => pin.rumor.id)).toEqual([good.rumor.id, getEventHash(forged.rumor)]);
  });

  it("an edit bundle is accepted only as kind 3302 by the original's author, naming the original, in this channel (CORD-04 §7)", async () => {
    const { rumor, entry } = await bundle();
    const editTags = [["e", rumor.id], ["channel", channel], ["epoch", "0"]];
    const accepted = await bundle({ kind: 3302, tags: editTags });
    expect(verifyPinEntry({ ...entry, edit: accepted.entry }, channel)?.edit?.id).toBe(accepted.rumor.id);
    const verdict = (edit: PinEntry) => verifyPinEntry({ ...entry, edit }, channel);
    // The proven author of the Edit must equal the original's: nobody else may revise another member's words.
    const stranger = new PrivateKeySigner(new Uint8Array(32).fill(9));
    const byOther = await bundle({ kind: 3302, tags: editTags, signer: stranger });
    expect(verdict(byOther.entry)?.rumor.id).toBe(rumor.id);
    expect(verdict(byOther.entry)?.edit).toBeUndefined();
    expect(verdict(byOther.entry)?.edited).toBe(false);
    // The e tag must name the original's recomputed id, not an embedded or missing one.
    const missing = await bundle({ kind: 3302, tags: [["channel", channel], ["epoch", "0"]] });
    expect(verdict(missing.entry)?.edit).toBeUndefined();
    // The channel binding stands for the revision path: an Edit sealed in another Channel is refused.
    const foreign = await bundle({ kind: 3302, tags: [["e", rumor.id], ["channel", "cd".repeat(32)], ["epoch", "0"]] });
    expect(verdict(foreign.entry)?.edit).toBeUndefined();
    const unbound = await bundle({ kind: 3302, tags: [["e", rumor.id], ["epoch", "0"]] });
    expect(verdict(unbound.entry)?.edit).toBeUndefined();
    // Step 4's kind is substituted: a message kind is no Edit.
    const message = await bundle({ kind: 9, tags: editTags });
    expect(verdict(message.entry)?.edit).toBeUndefined();
  });

  it("a wrap hint is never trusted: verification, identity and deduplication ignore it (CORD-04 §7)", async () => {
    const { rumor, entry } = await bundle();
    const plain = verifyPinEntry(entry, channel)!;
    for (const wrap of ["zz", "00".repeat(32), "ab".repeat(32), "", 7 as unknown as string]) {
      // Optional chaining keeps a mutant that rejects the hint on an assertion failure rather than a TypeError.
      const hinted = verifyPinEntry({ ...entry, wrap }, channel);
      expect(hinted?.rumor).toEqual(plain.rumor);
      expect(hinted?.text).toBe(plain.text);
      expect(hinted?.edited).toBe(plain.edited);
      // The hint rides the entry verbatim and nothing else changes with it.
      expect(hinted?.entry.wrap).toEqual(wrap);
    }
    // The same message under two different hints is one pin: identity is the recomputed rumor id, not the locator.
    const twice = {
      available: true as const,
      entries: [{ ...entry, wrap: "aa".repeat(32) }, { ...entry, wrap: "bb".repeat(32) }],
    };
    expect(verifiedPins(twice, channel).map((pin) => pin.rumor.id)).toEqual([rumor.id]);
  });
});

describe("Pin List caps (CORD-04 §7 Limits)", () => {
  const PAD_BYTES = 32_768;
  /** A public list document `{"entries":[{}],"p":"..."}` whose carried content is exactly `bytes` long. */
  function padded(bytes: number, filler = "x"): string {
    const encode = (text: string) => new TextEncoder().encode(text).length;
    const base = encode(JSON.stringify({ entries: [{}], p: "" }));
    return JSON.stringify({ entries: [{}], p: filler.repeat(Math.ceil((bytes - base) / encode(filler))) });
  }

  it("a violating edition reads as an empty list in either form, judged on the exact carried bytes (CORD-04 §7 Limits)", () => {
    // The byte cap is inclusive: exactly 32,768 carried bytes opens, one more is an empty list.
    const atCap = padded(PAD_BYTES);
    expect(new TextEncoder().encode(atCap).length).toBe(PAD_BYTES);
    expect(readPinList(atCap)).toEqual({ available: true, entries: [{}] });
    const over = padded(PAD_BYTES + 1);
    expect(new TextEncoder().encode(over).length).toBe(PAD_BYTES + 1);
    expect(readPinList(over)).toEqual({ available: true, entries: [] });
    // Bytes, not characters: two-byte characters fit the character count but not the byte cap.
    const wide = padded(PAD_BYTES + 2, "é");
    expect(wide.length).toBeLessThan(PAD_BYTES);
    expect(readPinList(wide)).toEqual({ available: true, entries: [] });
    // The entry cap is inclusive too: 25 entries open, 26 are an empty list.
    expect(readPinList(JSON.stringify({ entries: Array(25).fill({}) }))).toEqual({
      available: true,
      entries: Array(25).fill({}),
    });
    expect(readPinList(JSON.stringify({ entries: Array(26).fill({}) }))).toEqual({ available: true, entries: [] });
    // Sealed form: the byte cap is judged on the envelope for every reader, with or without the key, never as
    // unavailable; the entry cap needs the key to open the form.
    const bloated = JSON.stringify({ epoch: "4", sealed: "A".repeat(PAD_BYTES) });
    expect(readPinList(bloated)).toEqual({ available: true, entries: [] });
    expect(readPinList(bloated, () => key)).toEqual({ available: true, entries: [] });
    const sealedWith = (count: number) =>
      JSON.stringify({ epoch: "4", sealed: nip44.encrypt(JSON.stringify({ entries: Array(count).fill({}) }), key) });
    expect(readPinList(sealedWith(25), () => key)).toEqual({ available: true, entries: Array(25).fill({}) });
    expect(readPinList(sealedWith(26), () => key)).toEqual({ available: true, entries: [] });
    expect(readPinList(sealedWith(26))).toEqual({ available: false });
  });
});

describe("describePinList", () => {
  it("describePinList reports the public, sealed and invalid forms without throwing", () => {
    expect(describePinList(JSON.stringify({ entries: [] }))).toEqual({ form: "public" });
    expect(describePinList(JSON.stringify({ sealed: "x", epoch: "0" }))).toEqual({ form: "sealed", epoch: "0" });
    expect(describePinList(JSON.stringify({ sealed: "x", epoch: "12" }))).toEqual({ form: "sealed", epoch: "12" });
    for (
      const content of [
        undefined,
        "not json",
        "null",
        "[]",
        JSON.stringify({}),
        JSON.stringify({ sealed: "x" }),
        JSON.stringify({ sealed: "x", epoch: "01" }),
        JSON.stringify({ sealed: "x", epoch: 3 }),
        JSON.stringify({ sealed: "x", epoch: "18446744073709551616" }),
        JSON.stringify({ entries: "nope" }),
      ]
    ) {
      expect(describePinList(content)).toEqual({ form: "invalid" });
    }
  });
});
