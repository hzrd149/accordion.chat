// CORD-04 edition lineage: where an edition sits relative to the current head.
//
// CORD-04 §1 gives every control entity a versioned edition chain: each edition
// carries its version and `ep`, the hash of the edition it replaced, and the
// highest version with an intact chain wins, with the same version a
// deterministic tiebreak. After a Refounding compaction a joiner accepts the
// head even though its `ep` dangles, so a missing predecessor is a normal state
// and not evidence of a fork. CORD-04 §4 adds that a concurrent Banlist edit
// keeps one edition and the other's addition drops until someone re-applies it.
//
// These helpers answer the two questions a re-apply or refresh duty must settle
// before it publishes: "is my own edition still an ancestor of the head, or was
// it displaced by a sibling?" and "what did this edition add over its
// predecessor?". Both are pure and total. Every retained link is re-hashed with
// `computeEditionHash` instead of trusting a claimed `ep`, a missing or
// unverifiable link yields "unknown" and never a guess, and the walk is
// depth-capped.
//
// `walkEditionChain` goes one step further for a duty that must read the head's
// history itself (for example to see that a member was removed after an edition
// added it): it returns the head's verified chain, every link re-hashed, or
// reports the chain incomplete and returns nothing to trust.

import { isHexKey } from "applesauce-core/helpers/string";
import type { DecodedEvent } from "../types.ts";
import { canonicalJson } from "./community-list.ts";
import { computeEditionHash } from "./editions.ts";

/** The default number of versions {@link classifyEditionLineage} will walk
 *  between the head and the own edition before answering `depth-cap`. */
export const DEFAULT_EDITION_LINEAGE_DEPTH = 256;

/** The identity of one edition: its entity, version, hash and the hash it
 *  replaced. A `VerifiedControlHead` satisfies this structurally. */
export interface EditionRef {
  /** The entity coordinate (32-byte hex). */
  eid: string;
  /** The edition version, counting from 1. */
  version: number;
  /** This edition's hash, hex. */
  hash: string;
  /** The previous edition's hash (the `ep` link), hex; absent on a first edition. */
  prevHash?: string;
}

/** A retained control edition. Only the rumor is read, and it is read
 *  defensively because retained history comes from relays. */
export type EditionRecord = Pick<DecodedEvent, "rumor">;

/** Why a lineage could not be decided. Callers must treat every reason as
 *  "do nothing". */
export type EditionLineageUnknownReason =
  | "malformed"
  | "entity-mismatch"
  | "head-behind"
  | "depth-cap"
  | "predecessor-missing";

/** The outcome of {@link classifyEditionLineage}. `depth` is the number of
 *  versions walked (for `ancestor` and `lost-sibling`, head minus own version). */
export type EditionLineage =
  | { kind: "ancestor"; depth: number }
  | { kind: "lost-sibling"; depth: number }
  | { kind: "unknown"; reason: EditionLineageUnknownReason; depth: number };

/** Options for {@link classifyEditionLineage}. */
export interface EditionLineageOptions {
  /** The most versions to walk below the head. Defaults to {@link DEFAULT_EDITION_LINEAGE_DEPTH}. */
  maxDepth?: number;
}

/** The outcome of {@link editionAdditions}. `found` and `first` carry the added
 *  items; `missing` (predecessor not retained) and `malformed` carry none. */
export interface EditionAdditions<T> {
  predecessor: "found" | "first" | "missing" | "malformed";
  added: T[];
}

/** One verified link of an edition chain: what the edition at `version` carried. */
export interface EditionChainLink {
  /** The edition version, counting from 1. */
  version: number;
  /** The edition hash, recomputed from the content and chain fields (lowercase hex). */
  hash: string;
  /** The `ep` link to the previous edition (lowercase hex); absent on a first edition. */
  prevHash?: string;
  /** The edition content exactly as retained. */
  content: string;
}

/** The outcome of {@link walkEditionChain}. When `complete` is false `links` is empty and nothing may be trusted. */
export interface EditionChain {
  /** The head's chain from the requested minimum version to the head, in ascending version order. */
  links: EditionChainLink[];
  /** Whether every link from the head down to the minimum version was retained and verified. */
  complete: boolean;
}

/** Options for {@link walkEditionChain}. */
export interface EditionChainOptions {
  /** The lowest version to return, clamped to `[1, head.version]`. Defaults to 1. */
  minVersion?: number;
  /** The most versions to walk below the head. Defaults to {@link DEFAULT_EDITION_LINEAGE_DEPTH}. */
  maxDepth?: number;
}

const VERSION_TEXT = /^[1-9][0-9]*$/;

interface ReadEdition {
  version: number;
  prevHash?: string;
  content: string;
  vsk: number;
}

/** Tolerant reader for one retained record of the entity `eid`; never throws. */
function readEdition(record: EditionRecord, eid: string): ReadEdition | undefined {
  const rumor = record?.rumor;
  if (!rumor || typeof rumor.content !== "string" || !Array.isArray(rumor.tags)) return undefined;
  if (!rumor.tags.every((t) => Array.isArray(t) && t.every((v) => typeof v === "string"))) return undefined;
  const tag = (name: string) => rumor.tags.find((t) => t[0] === name)?.[1];
  if (rumor.kind !== 3308 || tag("eid")?.toLowerCase() !== eid.toLowerCase()) return undefined;
  const versionText = tag("ev") ?? "1";
  if (!VERSION_TEXT.test(versionText)) return undefined;
  const version = Number(versionText);
  if (!Number.isSafeInteger(version)) return undefined;
  const prevHash = tag("ep");
  if (prevHash !== undefined && !isHexKey(prevHash)) return undefined;
  return { version, prevHash, content: rumor.content, vsk: Number(tag("vsk") ?? 0) };
}

/** Recompute an edition's hash from what it actually carries; undefined if it cannot be hashed. */
function hashOf(edition: ReadEdition, eid: string): string | undefined {
  try {
    return computeEditionHash({
      vsk: edition.vsk,
      eid,
      version: edition.version,
      prevHash: edition.prevHash,
      content: edition.content,
    }).toLowerCase();
  } catch {
    return undefined;
  }
}

function validRef(ref: EditionRef): boolean {
  return !!ref && typeof ref.eid === "string" && isHexKey(ref.eid) && typeof ref.hash === "string" &&
    isHexKey(ref.hash) &&
    (ref.prevHash === undefined || (typeof ref.prevHash === "string" && isHexKey(ref.prevHash))) &&
    Number.isSafeInteger(ref.version) && ref.version >= 1;
}

function unknown(reason: EditionLineageUnknownReason, depth = 0): EditionLineage {
  return { kind: "unknown", reason, depth };
}

/**
 * Classify one of your own editions against the current head of the same entity
 * (CORD-04 §1).
 *
 * - `ancestor`: the head's chain passes through `own`, so nothing was displaced.
 * - `lost-sibling`: the head's chain provably does not include `own` (same
 *   version with a different hash, or a divergence below the head), so a
 *   concurrent sibling won and `own`'s additions may need re-applying (CORD-04 §4).
 * - `unknown`: the chain cannot be decided (a compacted or unretained
 *   predecessor, a depth over the cap, an own edition newer than the head,
 *   mismatched entities, or malformed input). Do nothing on `unknown`.
 *
 * Every retained edition is re-hashed with `computeEditionHash`; its claimed
 * `ep` is only followed when its content hashes to the link that the child
 * cited. `own` itself need not be retained, because the child's `ep` is the
 * evidence for the hash one version down. Pure and total.
 *
 * @param own - The edition whose fate is being decided.
 * @param head - The current head of the same entity (a `VerifiedControlHead` works).
 * @param retained - The retained control editions, in any order, duplicates allowed.
 * @param options - Optional depth cap.
 */
export function classifyEditionLineage(
  own: EditionRef,
  head: EditionRef,
  retained: Iterable<EditionRecord>,
  options: EditionLineageOptions = {},
): EditionLineage {
  if (!validRef(own) || !validRef(head)) return unknown("malformed");
  if (own.eid.toLowerCase() !== head.eid.toLowerCase()) return unknown("entity-mismatch");
  const ownHash = own.hash.toLowerCase();
  const headHash = head.hash.toLowerCase();
  if (ownHash === headHash) return { kind: "ancestor", depth: 0 };
  if (own.version > head.version) return unknown("head-behind");
  if (own.version === head.version) return { kind: "lost-sibling", depth: 0 };
  const maxDepth = options.maxDepth ?? DEFAULT_EDITION_LINEAGE_DEPTH;
  if (head.version - own.version > maxDepth) return unknown("depth-cap");

  // Index retained editions by version, keyed by recomputed hash (duplicates collapse).
  const byVersion = new Map<number, Map<string, string | undefined>>();
  try {
    for (const record of retained) {
      const read = readEdition(record, head.eid);
      if (!read) continue;
      const hash = hashOf(read, head.eid);
      if (!hash) continue;
      let hashes = byVersion.get(read.version);
      if (!hashes) byVersion.set(read.version, hashes = new Map());
      hashes.set(hash, read.prevHash?.toLowerCase());
    }
  } catch {
    return unknown("malformed");
  }

  let link: string | undefined = head.prevHash?.toLowerCase();
  if (link === undefined) {
    const headEntry = byVersion.get(head.version);
    link = headEntry?.has(headHash) ? headEntry.get(headHash) : undefined;
  }
  if (link === undefined) return unknown("predecessor-missing");

  let depth = 0;
  for (let v = head.version - 1; v > own.version; v--) {
    const hashes = byVersion.get(v);
    if (!hashes?.has(link)) return unknown("predecessor-missing", depth);
    const next: string | undefined = hashes.get(link);
    if (next === undefined) return unknown("predecessor-missing", depth);
    link = next;
    depth++;
  }
  const total = head.version - own.version;
  return link === ownHash ? { kind: "ancestor", depth: total } : { kind: "lost-sibling", depth: total };
}

/**
 * Walk the head's own edition chain downwards (CORD-04 §1) and return it from `minVersion` to the head.
 *
 * Every retained edition is re-hashed with `computeEditionHash`; a link is followed only when a retained edition's
 * recomputed hash equals the hash the child cited in `ep` (or the head's own hash for the first step). A missing link,
 * a hash mismatch, an `ep` that dangles before `minVersion`, a chain deeper than `maxDepth` or malformed input yields
 * `{ links: [], complete: false }`: an incomplete chain must not be trusted or guessed at. Pure and total.
 *
 * @param head - The current head of the entity (a `VerifiedControlHead` works).
 * @param retained - The retained control editions, in any order, duplicates allowed.
 * @param options - Optional lowest version to return and depth cap.
 * @returns The verified links in ascending version order and whether the walk was complete.
 */
export function walkEditionChain(
  head: EditionRef,
  retained: Iterable<EditionRecord>,
  options: EditionChainOptions = {},
): EditionChain {
  const incomplete: EditionChain = { links: [], complete: false };
  try {
    if (!validRef(head)) return incomplete;
    const requested = options?.minVersion;
    const wanted = typeof requested === "number" && Number.isFinite(requested) ? Math.floor(requested) : 1;
    const minVersion = Math.min(head.version, Math.max(1, wanted));
    const maxDepth = options?.maxDepth ?? DEFAULT_EDITION_LINEAGE_DEPTH;
    if (!(head.version - minVersion <= maxDepth)) return incomplete;

    // Index retained editions of this entity by version and recomputed hash (duplicates collapse).
    const byVersion = new Map<number, Map<string, ReadEdition>>();
    for (const record of retained) {
      const read = readEdition(record, head.eid);
      if (!read) continue;
      const hash = hashOf(read, head.eid);
      if (!hash) continue;
      let hashes = byVersion.get(read.version);
      if (!hashes) byVersion.set(read.version, hashes = new Map());
      hashes.set(hash, read);
    }

    const links: EditionChainLink[] = [];
    let hash = head.hash.toLowerCase();
    for (let version = head.version; version >= minVersion; version--) {
      const read = byVersion.get(version)?.get(hash);
      if (!read) return incomplete;
      const prevHash = read.prevHash?.toLowerCase();
      links.push({ version, hash, ...(prevHash ? { prevHash } : {}), content: read.content });
      if (version === minVersion) break;
      if (prevHash === undefined) return incomplete;
      hash = prevHash;
    }
    return { links: links.reverse(), complete: true };
  } catch {
    return incomplete;
  }
}

/**
 * Report what an edition added over its own predecessor (CORD-04 §4, the
 * concurrent-addition delta): the items in `own`'s content that the predecessor
 * did not have. A first edition adds everything; a predecessor that is not
 * retained (compaction) reports `missing` and no items rather than guessing.
 * Pure and total.
 *
 * @param own - The edition whose additions are wanted.
 * @param retained - The retained control editions of the same entity.
 * @param parse - Parses an edition's content into items, or returns undefined if it is not that document.
 * @param key - Identity of an item; defaults to the string itself, or canonical JSON for other values.
 */
export function editionAdditions<T>(
  own: EditionRecord,
  retained: Iterable<EditionRecord>,
  parse: (content: string) => readonly T[] | undefined,
  key: (item: T) => string = defaultKey,
): EditionAdditions<T> {
  try {
    const eid = own?.rumor?.tags?.find?.((t) => t?.[0] === "eid")?.[1];
    if (typeof eid !== "string" || !isHexKey(eid)) return { predecessor: "malformed", added: [] };
    const read = readEdition(own, eid);
    const items = read ? parse(read.content) : undefined;
    if (!read || !items) return { predecessor: "malformed", added: [] };
    if (read.version === 1 && read.prevHash === undefined) return { predecessor: "first", added: [...items] };
    if (read.prevHash === undefined) return { predecessor: "missing", added: [] };

    for (const record of retained) {
      const candidate = readEdition(record, eid);
      if (!candidate || candidate.version !== read.version - 1) continue;
      if (hashOf(candidate, eid) !== read.prevHash.toLowerCase()) continue;
      const before = parse(candidate.content);
      if (!before) continue;
      const known = new Set(before.map(key));
      return { predecessor: "found", added: items.filter((item) => !known.has(key(item))) };
    }
    return { predecessor: "missing", added: [] };
  } catch {
    return { predecessor: "malformed", added: [] };
  }
}

function defaultKey(item: unknown): string {
  return typeof item === "string" ? item : canonicalJson(item);
}
