// CORD-04 §4 and §6 Banlist write planning. A Banlist edition replaces the whole list, so two admins banning different
// members at the same version collide and one addition is lost (§4); the remedies are bulk bans (every target in one
// edition), a local rate limit and re-heal. §6 orders a ban: the Banlist edition first, the Grant strip alongside, the
// Refounding last. This module is the pure part of the local writer: it validates targets and plans the next content
// from the head content, never from the effective set, so a write can neither drop nor silently re-sign a ban the writer
// does not outrank (a Banlist entry only takes effect when its signer strictly outranks the target, §2).
//
// Internal: not part of the helpers barrel. Everything here is total and never throws on input.

import { isHexKey } from "applesauce-core/helpers/string";

import { type CommunityState, type DecodedEvent, PERM, VSK } from "../types.ts";
import { CONTROL_KIND } from "./control.ts";
import type { EditionRef } from "./edition-lineage.ts";
import { refoundAuthority } from "./permissions.ts";

/**
 * Why a ban target was refused before anything was published. `refounding-pending`: `banMembers({ refound: true })`
 * would resume a stored, unfinished Refounding that delivers the new root to this target, so finish that Refounding
 * with `refound()` first. `refounding-blocked`: a stored Refounding that `refound()` refuses to finish (it is blocked,
 * belongs to another epoch, or the Control state it was prepared against has changed) prevents any new Refounding, so
 * every target is refused; remove it with `discardPendingRefounding()` and retry, or ban with `refound: false`.
 */
export type BanTargetFailureReason =
  | "invalid-key"
  | "owner"
  | "self"
  | "not-outranked"
  | "cannot-strip-roles"
  | "refounding-pending"
  | "refounding-blocked";

/** One refused ban target: the member as given (lowercased when it was a valid key) and why it was refused. */
export interface BanTargetFailure {
  /** The refused member. */
  member: string;
  /** Why the member was refused. */
  reason: BanTargetFailureReason;
}

/** What this client last intended for one member: a ban or an unban, in call order, with the edition that carried it. */
export interface BanlistIntent {
  /** The intent. A later call for the same member replaces an earlier one. */
  action: "ban" | "unban";
  /** The call's position in this session, increasing once per public writer call. */
  seq: number;
  /** The Banlist edition this client published for the intent, absent when nothing was published. */
  edition?: EditionRef;
}

/** The result of {@link planBanlistWrite}. */
export type BanlistWritePlan =
  | { kind: "unchanged" }
  | { kind: "blocked"; members: string[]; reason: "unvouched-entries" | "not-outranked" }
  | { kind: "write"; content: string[] };

/** Input to {@link planBanlistWrite}. */
export interface BanlistWriteInput {
  /** The head edition's content: the whole list as the last accepted writer left it. */
  base: readonly string[];
  /** The community owner's key. The owner can never be banned, so the key is always dropped from the content. */
  owner: string;
  /** Members to add, in order. Members already in `base` are not repeated. */
  add?: readonly string[];
  /** Members to remove. */
  remove?: readonly string[];
  /** Whether the writer may vouch for an entry: the strict-rank check that makes it effective (CORD-04 §2). */
  canVouch(member: string): boolean;
  /** Turn an unchanged list into a write, to republish the head content as a new edition. */
  force?: boolean;
}

/** Parse Banlist content the way the fold does: a JSON array whose every entry is a 64-hex key, else undefined. */
export function parseBanlist(content: string): string[] | undefined {
  try {
    const parsed: unknown = JSON.parse(content);
    if (!Array.isArray(parsed)) return undefined;
    return parsed.every((entry) => typeof entry === "string" && isHexKey(entry)) ? [...parsed as string[]] : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Split ban targets into valid keys and failures. Valid keys are lowercased and deduplicated in first-seen order;
 * anything that is not a 64-hex string is an `invalid-key` failure carrying its string form. One malformed key would
 * void the whole edition in every fold (CORD-04 §4), so it is refused before anything is published.
 */
export function normalizeBanTargets(members: readonly unknown[]): { targets: string[]; failures: BanTargetFailure[] } {
  const targets: string[] = [];
  const failures: BanTargetFailure[] = [];
  for (const member of members) {
    if (typeof member === "string" && isHexKey(member)) {
      const key = member.toLowerCase();
      if (!targets.includes(key)) targets.push(key);
    } else {
      failures.push({ member: String(member), reason: "invalid-key" });
    }
  }
  return { targets, failures };
}

/**
 * The targets a writer may not ban, one failure each in input order (CORD-04 §§2-4, 6). Per target the first
 * applicable reason: the owner, the writer itself, no strict rank or no `BAN` (`not-outranked`), and no
 * `MANAGE_ROLES` over the target to strip its roles (`cannot-strip-roles`; the Grant strip that pairs with a ban).
 */
export function banTargetFailures(state: CommunityState, self: string, targets: readonly string[]): BanTargetFailure[] {
  const failures: BanTargetFailure[] = [];
  const canBan = (target: string) => refoundAuthority(state, PERM.BAN, target)(self);
  const canStrip = (target: string) => refoundAuthority(state, PERM.MANAGE_ROLES, target)(self);
  for (const target of targets) {
    const reason: BanTargetFailureReason | undefined = target === state.material.owner
      ? "owner"
      : target === self
      ? "self"
      : !canBan(target)
      ? "not-outranked"
      : !canStrip(target)
      ? "cannot-strip-roles"
      : undefined;
    if (reason) failures.push({ member: target, reason });
  }
  return failures;
}

/** The entries other than the owner key that the writer cannot vouch for. */
export function unvouchedEntries(
  content: readonly string[],
  owner: string,
  canVouch: (member: string) => boolean,
): string[] {
  return content.filter((member) => member !== owner && !canVouch(member));
}

/**
 * Plan the next Banlist content (CORD-04 §§4, 6). The next content is the head content without the owner key and
 * without `remove`, followed by new `add` members in order, so an entry the head carries but the fold does not honor is
 * kept in place. A removal of a head entry the writer cannot vouch for is `blocked` as `not-outranked`: lifting a ban
 * needs the same strict rank as placing it. A write whose next content would carry an entry the writer cannot vouch
 * for is `blocked` as `unvouched-entries`, because re-signing it under the writer's rank would make the fold drop it.
 * Dropping the owner key is the only removal that needs no check, since no signer can make it effective. An unchanged
 * list is `unchanged` unless `force` asks for a republish.
 */
export function planBanlistWrite(input: BanlistWriteInput): BanlistWritePlan {
  const { base, owner, canVouch } = input;
  const remove = new Set((input.remove ?? []).map((member) => member.toLowerCase()));
  const present = (member: string) => base.some((entry) => entry.toLowerCase() === member.toLowerCase());
  const refused = [...remove].filter((member) => member !== owner && present(member) && !canVouch(member));
  if (refused.length) return { kind: "blocked", members: refused, reason: "not-outranked" };

  const content = base.filter((entry) => entry !== owner && !remove.has(entry.toLowerCase()));
  for (const member of input.add ?? []) {
    if (member === owner) continue;
    if (!content.some((entry) => entry.toLowerCase() === member.toLowerCase())) content.push(member);
  }
  const changed = content.length !== base.length || content.some((entry, index) => entry !== base[index]);
  if (!changed && !input.force) return { kind: "unchanged" };

  const unvouched = unvouchedEntries(content, owner, canVouch);
  if (unvouched.length) return { kind: "blocked", members: unvouched, reason: "unvouched-entries" };
  return { kind: "write", content };
}

/**
 * This client's newest retained Banlist edition for `eid`: among kind 3308 records of the Banlist type at that
 * coordinate sealed by `self` (the proven seal author, D-14), the highest version, ties broken by the later `ms`, then
 * by the lower rumor id. Malformed records are skipped. Total.
 */
export function newestOwnBanlistEdition(
  retained: Iterable<DecodedEvent>,
  eid: string,
  self: string,
): DecodedEvent | undefined {
  let best: { record: DecodedEvent; version: number } | undefined;
  try {
    for (const record of retained) {
      const rumor = record?.rumor;
      if (!rumor || rumor.kind !== CONTROL_KIND || record.author !== self || !Array.isArray(rumor.tags)) continue;
      const tag = (name: string) => rumor.tags.find((t) => Array.isArray(t) && t[0] === name)?.[1];
      if (tag("vsk") !== String(VSK.BANLIST) || tag("eid")?.toLowerCase() !== eid.toLowerCase()) continue;
      const text = tag("ev") ?? "1";
      if (!/^[1-9][0-9]*$/.test(text)) continue;
      const version = Number(text);
      if (!Number.isSafeInteger(version)) continue;
      const better = !best || version > best.version ||
        (version === best.version &&
          (record.ms > best.record.ms || (record.ms === best.record.ms && rumor.id < best.record.rumor.id)));
      if (better) best = { record, version };
    }
  } catch {
    return best?.record;
  }
  return best?.record;
}
