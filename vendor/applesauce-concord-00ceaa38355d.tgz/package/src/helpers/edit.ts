// CORD-03 Chat Plane — message edits.
//
// An edit is a kind 3302 rumor that supersedes the prior chat message it
// targets. Sealing/wrapping is handled by ../stream.ts.
//
// These helpers read the edit-specific fields straight off a decoded rumor;
// they never build a parsed object, so callers pull only the field they need
// (the channel/epoch binding and `ms` ordering are read with `checkChatBinding`
// and `rumorMs`).

import { getOrComputeCachedValue } from "applesauce-core/helpers/cache";
import { getEventHash } from "applesauce-core/helpers/event";
import { type EventPointer, getEventPointerFromETag } from "applesauce-core/helpers/pointers";
import { isETag } from "applesauce-core/helpers/tags";
import type { Rumor } from "../types.ts";
import { isAuthorDeleted } from "./author-deletion.ts";
import { isRumorExpired } from "./expiration.ts";
import { hasMalformedMs, rumorMs } from "./stream.ts";

/** Concord chat message edit kind (CORD-03). */
export const EDIT_KIND = 3302;

/** A rumor validated as a Concord chat edit (kind 3302). */
export type EditRumor = Omit<Rumor, "kind"> & { kind: typeof EDIT_KIND };

/** Symbol for caching an edit's resolved target pointer on the rumor. */
export const EditTargetPointerSymbol: unique symbol = Symbol.for("concord-edit-target-pointer");

/**
 * Returns true if the rumor is a valid Concord chat edit: kind 3302 with an `e`
 * tag naming the message it replaces (CORD-03 §3).
 */
export function isValidEdit(rumor?: Rumor): rumor is EditRumor {
  if (!rumor || rumor.kind !== EDIT_KIND) return false;
  return !!rumor.tags.find(isETag);
}

/** Returns the {@link EventPointer} for the message an edit replaces (its `e` tag). */
export function getEditTarget(rumor: EditRumor): EventPointer;
/** Returns `undefined` when the rumor is not a valid edit, or carries no
 *  resolvable `e` tag. */
export function getEditTarget(rumor?: Rumor): EventPointer | undefined;
export function getEditTarget(rumor?: Rumor): EventPointer | undefined {
  if (!isValidEdit(rumor)) return undefined;

  return getOrComputeCachedValue(rumor, EditTargetPointerSymbol, () => {
    const eTag = rumor.tags.find(isETag);
    return eTag ? (getEventPointerFromETag(eTag) ?? undefined) : undefined;
  });
}

/** Returns the replacement text an edit carries in its `content` (CORD-03 §3). */
export function getEditText(rumor: Pick<Rumor, "content">): string {
  return rumor.content;
}

/** Options for {@link newestValidEdit}. */
export interface NewestValidEditOptions {
  /** Channel the original belongs to; an Edit must carry the same `channel` tag. */
  channelId: string;
  /** Unix-second clock; when given, Edits expired at this time are ignored. */
  now?: number;
  /** Returns true for an author whose Edits must be ignored (for example a banned member). */
  isBanned?: (pubkey: string) => boolean;
  /**
   * Channel rumors that may delete an Edit. Only a kind 5 by the Edit's own author whose `e` tag names the Edit's
   * recomputed id counts; other kinds and other authors are ignored. An Edit deleted this way is never chosen, so the
   * next undeleted Edit (or none) wins (D-31). Pass authenticated channel inputs (for example `channelTimeline`
   * rumors), never unverified relay data.
   */
  deletions?: readonly Rumor[];
}

/**
 * Choose the Edit that currently supersedes `original`: the newest kind 3302 rumor by the original's author, whose
 * first `e` tag is the original's id and whose `channel` tag is `options.channelId` (CORD-04 §7 Edits). The order is
 * the full millisecond time (CORD-02 §4); equal times resolve to the lower recomputed rumor id so every reader of this
 * library agrees on one total order (the spec is silent on ties). A wrong author, a wrong channel, an Edit of an
 * Edit, a malformed `ms` tag, an expired Edit (only when `options.now` is given), a banned author, and an Edit its own
 * author deleted (only with `options.deletions`) are ignored; the `k` tag is ignored. Ids are recomputed, never
 * trusted, and the returned rumor carries the recomputed id.
 */
export function newestValidEdit(
  original: Rumor,
  candidates: Iterable<Rumor>,
  options: NewestValidEditOptions,
): Rumor | undefined {
  let best: Rumor | undefined;
  let bestMs = 0;
  for (const candidate of candidates) {
    if (
      !candidate || candidate.kind !== EDIT_KIND || candidate.pubkey !== original.pubkey ||
      !Array.isArray(candidate.tags) || candidate.tags.find((t) => t[0] === "e")?.[1] !== original.id ||
      candidate.tags.find((t) => t[0] === "channel")?.[1] !== options.channelId || hasMalformedMs(candidate) ||
      (options.now !== undefined && isRumorExpired(candidate, options.now)) ||
      options.isBanned?.(candidate.pubkey)
    ) continue;
    let id: string;
    try {
      id = getEventHash(candidate);
    } catch {
      continue; // Malformed relay input is skipped, never thrown.
    }
    if (options.deletions && isAuthorDeleted({ id, pubkey: candidate.pubkey }, options.deletions)) continue;
    const ms = rumorMs(candidate);
    if (best === undefined || ms > bestMs || (ms === bestMs && id < best.id)) {
      best = { ...candidate, id };
      bestMs = ms;
    }
  }
  return best;
}
