// CORD-02 §8 Community List (kind 13302): merge entries and tombstones across
// devices. Only an explicit, newer re-join can restore a removed membership.

import {
  getHiddenContent,
  getOrComputeCachedValue,
  type HiddenContentSigner,
  isHiddenContentUnlocked,
  type KnownEvent,
  type NostrEvent,
  notifyEventUpdate,
  unlockHiddenContent,
} from "applesauce-core/helpers";

import type { CommunityListCommunity, CommunityTombstone, HeldRootEntry, JoinMaterial } from "../types.ts";
import { canonicalWire, mergeOpaque } from "./community-list-canonical.ts";
import { encodeCommunityListSnapshot } from "./community-list-wire.ts";
import { controlKeyFor } from "./crypto.ts";

/** Concord community list kind (CORD-02 §8). */
export const COMMUNITY_LIST_KIND = 13302;

/** The newest `added_at` for a community across (possibly un-merged) communities, or undefined if absent. */
function newestAdd(communities: CommunityListCommunity[], communityId: string): number | undefined {
  let added: number | undefined;
  for (const e of communities ?? []) {
    if (e?.community_id !== communityId) continue;
    const at = typeof e.added_at === "number" ? e.added_at : 0;
    added = added === undefined ? at : Math.max(added, at);
  }
  return added;
}

/** The newest removal; a tombstone lacking a valid `removed_at` is treated as terminal (+∞). */
function newestRemoval(tombstones: CommunityTombstone[], communityId: string): number | undefined {
  let removed: number | undefined;
  for (const t of tombstones ?? []) {
    if (t?.community_id !== communityId) continue;
    const at = typeof t.removed_at === "number" ? t.removed_at : Infinity;
    removed = removed === undefined ? at : Math.max(removed, at);
  }
  return removed;
}

/**
 * Whether a membership is live: it has a community, and either no tombstone or
 * its newest add postdates the newest removal (CORD-02 §8). A re-join
 * resurrects; a pure leave stays dead.
 */
export function isCommunityLive(
  communities: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
  communityId: string,
): boolean {
  const added = newestAdd(communities, communityId);
  if (added === undefined) return false;
  const removed = newestRemoval(tombstones, communityId);
  return removed === undefined || added > removed;
}

/** The live memberships, derived (deduped by community_id, newest-add snapshot). */
export function liveCommunities(
  communities: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
): CommunityListCommunity[] {
  const live = new Map<string, CommunityListCommunity>();
  for (const e of communities ?? []) {
    if (!e?.community_id || !isCommunityLive(communities, tombstones, e.community_id)) continue;
    const prev = live.get(e.community_id);
    if (!prev || (e.added_at ?? 0) >= (prev.added_at ?? 0)) live.set(e.community_id, e);
  }
  return [...live.values()];
}

/**
 * "The List caps at 50 memberships... the cap is a protocol constant, not
 * client taste" (CORD-02 §8). Counts LIVE memberships only, exactly as
 * {@link liveCommunities} derives them — a tombstoned entry does not consume
 * this budget, because the spec's own word is "memberships", not "entries".
 * This is a transcribed spec literal, not a derived constant (unlike
 * {@link LIST_MAX_BYTES}'s survivors below), so the derived-constants-carry-
 * a-rationale convention elsewhere in this file does not apply here (D-21).
 * Legacy format count bound; the shared plaintext ceiling also applies to writes.
 */
export const COMMUNITY_LIST_MAX_MEMBERSHIPS = 50;

/** Legacy list plaintext ceiling, enforced on writes (CORD-02 Appendix B). */
export const LIST_MAX_BYTES = 65_535;

/** JSON with recursively-sorted keys — a total order for equal-epoch tiebreaks. */
export function canonicalJson(value: unknown): string {
  return canonicalWire(value);
}

/** Wire snapshot bytes alone choose coordinates; local recovery caches never vote. */
function snapshotBytes(material: JoinMaterial): string {
  try {
    const { community_id: _id, ...wire } = encodeCommunityListSnapshot(material);
    return canonicalWire(wire);
  } catch {
    // Legacy local mirrors may contain malformed material. Keep the fold total.
    return "\uffff" + canonicalWire(material);
  }
}

function compareSnapshot(a: JoinMaterial, b: JoinMaterial): number {
  const x = new TextEncoder().encode(snapshotBytes(a));
  const y = new TextEncoder().encode(snapshotBytes(b));
  for (let i = 0; i < Math.min(x.length, y.length); i++) {
    if (x[i] !== y[i]) return x[i] - y[i];
  }
  return x.length - y.length;
}

/** Higher root_epoch wins; tie → lexicographically-lowest canonical bytes. */
function freshest(a: JoinMaterial, b: JoinMaterial): JoinMaterial {
  if (a.root_epoch !== b.root_epoch) return a.root_epoch > b.root_epoch ? a : b;
  const selected = compareSnapshot(a, b) <= 0 ? a : b;
  return preserveHeldControl(selected, selected === a ? b : a);
}
/** Lower root_epoch wins; tie → lowest canonical bytes (the backfill anchor). */
function earliest(a: JoinMaterial, b: JoinMaterial): JoinMaterial {
  if (a.root_epoch !== b.root_epoch) return a.root_epoch < b.root_epoch ? a : b;
  const selected = compareSnapshot(a, b) <= 0 ? a : b;
  return preserveHeldControl(selected, selected === a ? b : a);
}

/** CORD-02 §5/§8: retain a held staff root only for the exact same split coordinate. */
function preserveHeldControl(selected: JoinMaterial, held: JoinMaterial): JoinMaterial {
  if (
    !Object.hasOwn(selected, "control_pk") || !Object.hasOwn(held, "control_pk") ||
    selected.community_id !== held.community_id || selected.owner !== held.owner ||
    selected.owner_salt !== held.owner_salt || selected.community_root !== held.community_root ||
    selected.root_epoch !== held.root_epoch || selected.control_pk !== held.control_pk
  ) return selected;
  for (const candidate of [selected, held]) {
    if (!Object.hasOwn(candidate, "control_root")) continue;
    try {
      if (controlKeyFor(candidate).signing) {
        return selected.control_root === candidate.control_root
          ? selected
          : { ...selected, control_root: candidate.control_root };
      }
    } catch {
      // A malformed capability cannot interrupt other memberships or contribute a secret.
    }
  }
  return selected;
}

function mergeCommunity(
  x: CommunityListCommunity,
  y: CommunityListCommunity,
  preserveCurrent = false,
): CommunityListCommunity {
  let current = freshest(x.current, y.current);
  let conflictingHeldPair = false;
  const sameIdentity = x.current.community_id === y.current.community_id && x.current.owner === y.current.owner &&
    x.current.owner_salt === y.current.owner_salt;
  // CORD-06 §3 / CORD-02 §8: a durable owning-device coordinate is an
  // established selection, never a new candidate chosen by document bytes.
  if (
    preserveCurrent && sameIdentity && x.current.root_epoch === y.current.root_epoch &&
    (x.current.community_root === y.current.community_root ||
      (x.current.prev_root !== undefined && x.current.prev_root === y.current.prev_root))
  ) {
    current = x.current.community_root === y.current.community_root && x.current.control_pk === y.current.control_pk
      ? preserveHeldControl(current, x.current)
      : x.current;
    const conflict = [x.current, y.current].some((source) =>
      (source.community_root === x.current.community_root && source.control_pk !== x.current.control_pk) ||
      source.held_roots?.some((entry) =>
        entry.epoch === x.current.root_epoch && entry.key === x.current.community_root &&
        entry.control_pk !== x.current.control_pk
      )
    );
    if (conflict) {
      conflictingHeldPair = true;
      const { control_root: _root, ...read } = current;
      current = { ...read, ...(x.current.control_root !== undefined ? { control_root: x.current.control_root } : {}) };
    }
  }
  const seed = earliest(x.seed, y.seed);
  const retainHistory = (selected: JoinMaterial, anchor = false): JoinMaterial => {
    const records = new Map<string, HeldRootEntry>();
    for (const source of [x.current, x.seed, y.current, y.seed]) {
      if (
        source.community_id !== selected.community_id || source.owner !== selected.owner ||
        source.owner_salt !== selected.owner_salt
      ) continue;
      const entries = [...(source.held_roots ?? [])];
      if (
        !anchor && source.prev_root !== undefined && (source.root_epoch !== selected.root_epoch ||
          source.community_root !== selected.community_root || source.control_pk !== selected.control_pk)
      ) {
        entries.push({
          epoch: source.root_epoch,
          key: source.community_root,
          prev_root: source.prev_root,
          ...(source.refounder !== undefined ? { refounder: source.refounder } : {}),
          ...(source.control_pk !== undefined ? { control_pk: source.control_pk } : {}),
          ...(source.control_root !== undefined ? { control_root: source.control_root } : {}),
        });
      }
      for (const entry of entries) {
        if (anchor && entry.epoch >= selected.root_epoch) continue;
        try {
          const { control_pk: _pk, control_root: _root, ...base } = selected;
          controlKeyFor({
            ...base,
            community_root: entry.key,
            root_epoch: entry.epoch,
            ...(entry.control_pk !== undefined ? { control_pk: entry.control_pk } : {}),
            ...(entry.control_root !== undefined ? { control_root: entry.control_root } : {}),
          });
          // CORD-06 §3: keep provisional evidence distinct from established
          // history; its identifier/provenance must never become a held anchor.
          const id = canonicalJson([
            entry.epoch,
            entry.key,
            entry.control_pk,
            entry.prev_root,
            entry.candidate_id,
            entry.vac,
            entry.refounder,
          ]);
          const old = records.get(id);
          const best = !old || canonicalJson(entry) < canonicalJson(old) ? entry : old;
          records.set(id, {
            ...best,
            ...(old?.control_root || entry.control_root
              ? { control_root: old?.control_root ?? entry.control_root }
              : {}),
          });
        } catch { /* Malformed saved capability cannot abort this total merge. */ }
      }
    }
    if (!records.size && !Object.hasOwn(selected, "held_roots")) return selected;
    const history = [...records.values()].sort((a, b) =>
      b.epoch - a.epoch || canonicalJson(a).localeCompare(canonicalJson(b))
    );
    // A seed without history remains the original backfill anchor.
    return { ...selected, held_roots: history };
  };
  return {
    ...mergeOpaque(x, y),
    community_id: x.community_id,
    current: retainHistory(conflictingHeldPair ? current : preserveHeldControl(current, seed)),
    seed: retainHistory(preserveHeldControl(seed, current), true),
    added_at: Math.max(x.added_at, y.added_at),
  };
}

/**
 * Deterministically merge two arrays of communities — commutative, idempotent,
 * nothing deleted. The community_id is the merge key: `current` keeps the
 * freshest snapshot, `seed` the earliest, and `added_at` the newest add
 * (CORD-02 §8). With `preserveCurrent`, the first array's established same-epoch
 * coordinate is retained at matching read roots or known predecessor continuity;
 * this directional owning-device mode never chooses protocol candidates.
 */
export function mergeCommunities(
  a: CommunityListCommunity[],
  b: CommunityListCommunity[],
  preserveCurrent: boolean = false,
): CommunityListCommunity[] {
  const communities = new Map<string, CommunityListCommunity>();
  for (const e of [...(a ?? []), ...(b ?? [])]) {
    if (!e || typeof e.community_id !== "string") continue;
    const prev = communities.get(e.community_id);
    communities.set(
      e.community_id,
      prev ? mergeCommunity(prev, e, preserveCurrent) : e.current && e.seed ? mergeCommunity(e, e) : e,
    );
  }
  return [...communities.values()].sort((x, y) => x.community_id.localeCompare(y.community_id));
}

/**
 * Deterministically union two arrays of tombstones by community_id, keeping the
 * newest removal (commutative, idempotent). A tombstone always stays in the
 * document — liveness is derived from the newest add vs newest removal
 * (CORD-02 §8).
 */
export function mergeCommunityTombstones(a: CommunityTombstone[], b: CommunityTombstone[]): CommunityTombstone[] {
  const tombstones = new Map<string, CommunityTombstone>();
  for (const t of [...(a ?? []), ...(b ?? [])]) {
    if (!t || typeof t.community_id !== "string") continue;
    const prev = tombstones.get(t.community_id);
    tombstones.set(
      t.community_id,
      prev
        ? {
          ...mergeOpaque(prev, t),
          community_id: t.community_id,
          removed_at: Math.max(prev.removed_at, t.removed_at),
        }
        : t,
    );
  }
  return [...tombstones.values()].sort((x, y) => x.community_id.localeCompare(y.community_id));
}

/**
 * The atomic membership mutations (join/leave/refresh) live as composable
 * `CommunityListOperation`s in ../operations/community-list.ts; they are built on
 * the `mergeCommunities`/`mergeCommunityTombstones` primitives above.
 */

/**
 * The serialized byte size of the wire document (`{entries, tombstones}`) —
 * the SINGLE measurement `client.ts`'s `saveCommunityList` diagnostic
 * consumes, so the publish path and any future reader of this figure can
 * never drift apart on how the document is measured (WR-04's original
 * dedup rationale; D-08's retained size trace is why this survives).
 */
export function communityListByteSize(communities: CommunityListCommunity[], tombstones: CommunityTombstone[]): number {
  // The wire document keys the array as `entries` (armada-compatible).
  return new TextEncoder().encode(JSON.stringify({ entries: communities, tombstones })).length;
}

/** The serialized byte size of a single {@link CommunityListCommunity} entry —
 *  its material appears TWICE (`seed` AND `current`), roughly doubling its
 *  footprint versus a naive single-copy estimate. Used by `saveCommunityList`'s
 *  diagnostic to name the largest entry in the size trace (D-08). */
export function communityListEntryByteSize(entry: CommunityListCommunity): number {
  return new TextEncoder().encode(JSON.stringify(entry)).length;
}

/** A validated Concord Community List event (kind 13302). */
export type CommunityListEvent = KnownEvent<typeof COMMUNITY_LIST_KIND>;

/** Validates that an event is a Concord community list (kind 13302). */
export function isValidCommunityList(event: NostrEvent): event is CommunityListEvent {
  return event.kind === COMMUNITY_LIST_KIND;
}

/** Symbol for caching the parsed (decrypted) community list on an event. */
export const CommunityListSymbol: unique symbol = Symbol.for("concord-community-list");

/**
 * Open wire document preserving unknown fields (CORD-02 §6).
 * Missing `entries` and `tombstones` default to empty arrays.
 */
export interface ParsedCommunityList {
  /** The member's joined communities. Defaulted to `[]` when the JSON omits it. */
  entries: CommunityListCommunity[];
  /** Leave tombstones. NOT terminal, unlike an invite revocation — a later
   *  re-join supersedes one (CORD-02 §8). */
  tombstones: CommunityTombstone[];
  /** Every other top-level key the wire document carried, preserved verbatim to
   *  satisfy CORD-02 §6's round-trip MUST. */
  [k: string]: unknown;
}

/**
 * Parse the self-encrypted community list JSON into the open wire document
 * (empty arrays on absent/blank). The returned value is the parsed document
 * spread as-is, with only `entries` and `tombstones` defaulted to `[]` when
 * absent — every other top-level key present in the JSON survives unmodified
 * (D-01/D-12).
 */
export function parseCommunityList(json: string | undefined): ParsedCommunityList {
  if (!json) return { entries: [], tombstones: [] };
  const doc = JSON.parse(json) as ParsedCommunityList;
  return { ...doc, entries: doc.entries ?? [], tombstones: doc.tombstones ?? [] };
}

/** Whether the self-encrypted community list plaintext is unlocked on the event. */
export function isCommunityListUnlocked(event: NostrEvent): boolean {
  return isHiddenContentUnlocked(event);
}

/** Returns the parsed community list if the event has been unlocked, otherwise undefined. */
export function getCommunityList(event: NostrEvent): ParsedCommunityList | undefined {
  const json = getHiddenContent(event);
  if (json === undefined) return undefined;
  return getOrComputeCachedValue(event, CommunityListSymbol, () => parseCommunityList(json));
}

/** The live community memberships derived from the unlocked list, or undefined if locked. */
export function getLiveCommunities(event: NostrEvent): CommunityListCommunity[] | undefined {
  const parsed = getCommunityList(event);
  return parsed && liveCommunities(parsed.entries, parsed.tombstones);
}

/** Unlocks and parses the self-encrypted community list using the owning user's signer. */
export async function unlockCommunityList(
  event: NostrEvent,
  signer: HiddenContentSigner,
): Promise<ParsedCommunityList> {
  if (!isCommunityListUnlocked(event)) {
    await unlockHiddenContent(event, signer);
    notifyEventUpdate(event);
  }
  return getCommunityList(event) ?? { entries: [], tombstones: [] };
}
