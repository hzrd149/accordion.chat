// Concord cryptographic derivations (CORD-02 Appendix A).

import { hkdf } from "@noble/hashes/hkdf.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, concatBytes, hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";
import { schnorr, secp256k1 } from "@noble/curves/secp256k1.js";
import { numberToBytesBE } from "@noble/curves/utils.js";
import { nip44 } from "applesauce-core/helpers/encryption";
import { base64 } from "@scure/base";

/** A 32-byte all-zero id, used where a derivation label has no meaningful id. */
const ZERO_32 = new Uint8Array(32);

const SECP_ORDER: bigint = secp256k1.Point.Fn.ORDER;

function bytesToBigInt(bytes: Uint8Array): bigint {
  let v = 0n;
  for (const b of bytes) v = (v << 8n) | BigInt(b);
  return v;
}

/** A 32-byte value is a valid secp256k1 scalar iff 0 < v < n. */
function isValidScalar(bytes: Uint8Array): boolean {
  const v = bytesToBigInt(bytes);
  return v > 0n && v < SECP_ORDER;
}

/**
 * A.1 HKDF — HKDF-SHA256 with empty salt and
 *   info = utf8(label) || 0x00 || id[32] || epoch_be[8]?  (|| counter?)
 * The epoch is the only omittable field. `extraInfo` carries the
 * scalar_normalize retry counter, appended after all other fields (A.3).
 */
export function concordHkdf(
  secret: Uint8Array,
  label: string,
  id: Uint8Array = ZERO_32,
  epoch?: number | bigint,
  extraInfo?: Uint8Array,
): Uint8Array {
  if (id.length !== 32) throw new Error("hkdf id must be 32 bytes");
  const parts: Uint8Array[] = [utf8ToBytes(label), new Uint8Array([0x00]), id];
  if (epoch !== undefined) parts.push(numberToBytesBE(epoch, 8));
  if (extraInfo) parts.push(extraInfo);
  const info = concatBytes(...parts);
  return hkdf(sha256, secret, new Uint8Array(0), info, 32);
}

/**
 * A.3 scalar_normalize — the hkdf output is a seed; if it is not a valid
 * secp256k1 scalar, append an incrementing counter byte to the hkdf info and
 * retry (counter from 0). The reject branch is ~2^-128 rare.
 */
function scalarNormalize(
  secret: Uint8Array,
  label: string,
  id: Uint8Array,
  epoch: number | bigint | undefined,
  firstSeed: Uint8Array,
): Uint8Array {
  if (isValidScalar(firstSeed)) return firstSeed;
  for (let counter = 0; counter < 256; counter++) {
    const seed = concordHkdf(secret, label, id, epoch, new Uint8Array([counter]));
    if (isValidScalar(seed)) return seed;
  }
  throw new Error("scalar_normalize exhausted (astronomically unlikely)");
}

/** A derived stream identity: the keypair that addresses one plane on the wire,
 *  plus the conversation key that encrypts its wraps. Produced by
 *  {@link groupKey} (A.2), and through it by every frozen label below. */
export interface GroupKey {
  /** secret key (32 bytes) that signs the plane's giftwraps */
  sk: Uint8Array;
  /** x-only pubkey — the on-wire Stream address (hex) */
  pk: string;
  /** NIP-44 self-ECDH conversation key that encrypts the wrap */
  convKey: Uint8Array;
}

/** Control read access and, only when held, its independent wrap signer (CORD-02 §5). */
export interface ControlKey {
  /** Held x-only control stream address, encoded as canonical hex. */
  pk: string;
  /** Member read conversation key derived from the community root. */
  convKey: Uint8Array;
  /** Optional held wrap signing capability; its convKey is not the read key. */
  signing?: GroupKey;
}

/** Epoch-bound material accepted by {@link controlKeyFor}; absence of split fields identifies legacy material. */
export interface ControlKeyMaterial {
  /** Canonical 32-byte community identity in hex. */
  community_id: string;
  /** Canonical 32-byte member read root in hex. */
  community_root: string;
  /** Nonnegative safe integer epoch. */
  root_epoch: number;
  /** Held split control address; required when control_root is supplied. */
  control_pk?: string;
  /** Staff-only canonical 32-byte control signing root in hex. */
  control_root?: string;
}

function canonicalKeyBytes(value: string, field: string): Uint8Array {
  if (typeof value !== "string" || !/^[0-9a-f]{64}$/.test(value)) {
    throw new Error(`${field} must be canonical 32-byte hex`);
  }
  return hexToBytes(value);
}

function validateControlEpoch(epoch: number): void {
  if (!Number.isSafeInteger(epoch) || epoch < 0) throw new Error("control epoch must be a nonnegative safe integer");
}

/** Encode exactly epoch_be[8] || control_root[32] as standard base64 for pairwise NIP-44 (CORD-04 §3; CORD-02 §5). */
export function encodeControlRootDelivery(root: Uint8Array, epoch: number): string {
  if (root.length !== 32) throw new Error("control root must be 32 bytes");
  validateControlEpoch(epoch);
  const bytes = new Uint8Array(40);
  new DataView(bytes.buffer).setBigUint64(0, BigInt(epoch), false);
  bytes.set(root, 8);
  return base64.encode(bytes);
}

/** Decode a canonical standard-base64 40-byte promotion; malformed encoding or unsafe epochs return null (CORD-04 §3). */
export function decodeControlRootDelivery(plaintext: string): { epoch: number; controlRoot: Uint8Array } | null {
  try {
    if (typeof plaintext !== "string" || !/^[A-Za-z0-9+/]{54}==$/.test(plaintext)) return null;
    const bytes = base64.decode(plaintext);
    if (bytes.length !== 40 || base64.encode(bytes) !== plaintext) return null;
    const epoch = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getBigUint64(0, false);
    if (epoch > BigInt(Number.MAX_SAFE_INTEGER)) return null;
    return { epoch: Number(epoch), controlRoot: bytes.slice(8) };
  } catch {
    return null;
  }
}

/** Derive the staff wrap signer from its independent root (CORD-02 §5 / Appendix A). */
export function controlSignerGroupKey(controlRoot: Uint8Array, communityId: Uint8Array, epoch: number): GroupKey {
  if (controlRoot.length !== 32 || communityId.length !== 32) {
    throw new Error("control root and identity must be 32 bytes");
  }
  validateControlEpoch(epoch);
  return groupKey("concord/control-signer", controlRoot, communityId, epoch);
}

/**
 * Resolve control read access and optional signing capability (CORD-02 §5 / Appendix A).
 * Only complete absence of split fields selects the historical control keypair.
 * Supplied staff roots must derive exactly to the held control address.
 */
export function controlKeyFor(material: ControlKeyMaterial): ControlKey {
  const cid = canonicalKeyBytes(material.community_id, "community_id");
  const root = canonicalKeyBytes(material.community_root, "community_root");
  validateControlEpoch(material.root_epoch);
  const read = controlGroupKey(root, cid, material.root_epoch);
  if (!("control_pk" in material) && !("control_root" in material)) {
    return { pk: read.pk, convKey: read.convKey, signing: read };
  }
  canonicalKeyBytes(material.control_pk!, "control_pk");
  if (!("control_root" in material)) return { pk: material.control_pk!, convKey: read.convKey };
  const signing = controlSignerGroupKey(
    canonicalKeyBytes(material.control_root!, "control_root"),
    cid,
    material.root_epoch,
  );
  if (signing.pk !== material.control_pk) throw new Error("control_root does not match control_pk");
  return { pk: material.control_pk, convKey: read.convKey, signing };
}

/**
 * A.2 group_key — a pseudonym label's hkdf output normalized into a
 * secp256k1 keypair whose x-only pubkey is the on-wire Stream address.
 */
export function groupKey(
  label: string,
  secret: Uint8Array,
  id: Uint8Array = ZERO_32,
  epoch?: number | bigint,
): GroupKey {
  const seed = concordHkdf(secret, label, id, epoch);
  const sk = scalarNormalize(secret, label, id, epoch, seed);
  const pk = bytesToHex(schnorr.getPublicKey(sk));
  const convKey = nip44.getConversationKey(sk, pk);
  return { sk, pk, convKey };
}

/**
 * A.4 community_id — a plain SHA-256 commitment to the owner:
 *   sha256( utf8("concord/community") || owner_xonly[32] || owner_salt[32] )
 */
export function communityId(ownerXonlyHex: string, ownerSalt: Uint8Array): Uint8Array {
  return sha256(concatBytes(utf8ToBytes("concord/community"), hexToBytes(ownerXonlyHex), ownerSalt));
}

/**
 * A.5 epoch-key commitment (CORD-06):
 *   sha256( utf8("concord/epoch-key-commitment") || prev_epoch_be[8] || prev_key[32] )
 */
export function epochKeyCommitment(prevEpoch: number | bigint, prevKey: Uint8Array): Uint8Array {
  return sha256(concatBytes(utf8ToBytes("concord/epoch-key-commitment"), numberToBytesBE(prevEpoch, 8), prevKey));
}

/** Public/Private Channel group key. secret = channel key or community_root. */
export function channelGroupKey(secret: Uint8Array, channelId: Uint8Array, epoch: number): GroupKey {
  return groupKey("concord/channel", secret, channelId, epoch);
}

/** Control Plane group key. secret = community_root, id = community_id. */
export function controlGroupKey(root: Uint8Array, communityId: Uint8Array, epoch: number): GroupKey {
  return groupKey("concord/control", root, communityId, epoch);
}

/** Guestbook Plane group key. secret = community_root, id = community_id. */
export function guestbookGroupKey(root: Uint8Array, communityId: Uint8Array, epoch: number): GroupKey {
  return groupKey("concord/guestbook", root, communityId, epoch);
}

/** Dissolution tombstone address. secret = community_id, id = 0..0, no epoch. */
export function dissolvedGroupKey(communityId: Uint8Array): GroupKey {
  return groupKey("concord/dissolved", communityId, ZERO_32);
}

/** Channel rekey address (CORD-06). secret = prior community_root. */
export function channelRekeyGroupKey(priorRoot: Uint8Array, channelId: Uint8Array, newEpoch: number): GroupKey {
  return groupKey("concord/rekey-pseudonym", priorRoot, channelId, newEpoch);
}

/** Base (community_root) rekey address (CORD-06). */
export function baseRekeyGroupKey(priorRoot: Uint8Array, communityId: Uint8Array, newEpoch: number): GroupKey {
  return groupKey("concord/base-rekey-pseudonym", priorRoot, communityId, newEpoch);
}

/**
 * A voice Channel's signing keypair (CORD-07 §1). Its x-only `pk` is the SFU
 * **room name** and its `sk` signs token grants (§2); the pk is never a stream
 * address, the `group_key` shape is reused only for its deterministic keypair.
 * `secret`/`epoch` are the same pair that addresses the Channel's Chat Plane —
 * community_root@root_epoch for a Public Channel, the Channel's own key/epoch
 * for a Private one — so the room rolls exactly when the Channel's key does.
 */
export function voiceGroupKey(secret: Uint8Array, channelId: Uint8Array, epoch: number): GroupKey {
  return groupKey("concord/voice-signer", secret, channelId, epoch);
}

/**
 * A voice Channel's raw 32-byte media-encryption root (CORD-07 §1). Never feeds
 * a cipher directly — every publisher's per-sender frame key derives from it
 * (see {@link voiceSenderKey}).
 */
export function voiceMediaKey(secret: Uint8Array, channelId: Uint8Array, epoch: number): Uint8Array {
  return concordHkdf(secret, "concord/voice-media", channelId, epoch);
}

/**
 * A publisher's per-sender frame-key material (CORD-07 §3):
 * `hkdf(voice_media_key, "concord/voice-sender", sha256(utf8(identity)))` — the
 * epoch field is omitted, `voice_media_key` already carries it. Distinct keys
 * per sender partition the AEAD nonce domains; every member computes every
 * sender's key from the identity the SFU presents, no in-band exchange.
 */
export function voiceSenderKey(mediaKey: Uint8Array, identity: string): Uint8Array {
  return concordHkdf(mediaKey, "concord/voice-sender", sha256(utf8ToBytes(identity)));
}

/** A member's Grant coordinate. secret = community_id, id = member_xonly. */
export function grantLocator(communityId: Uint8Array, memberXonlyHex: string): string {
  return bytesToHex(concordHkdf(communityId, "concord/grant", hexToBytes(memberXonlyHex)));
}

/** The Banlist coordinate. secret = community_id, id = 0..0. */
export function banlistLocator(communityId: Uint8Array): string {
  return bytesToHex(concordHkdf(communityId, "concord/banlist", ZERO_32));
}

/** A creator's invite Registry coordinate. secret = community_id, id = creator_xonly. */
export function inviteLinksLocator(communityId: Uint8Array, creatorXonlyHex: string): string {
  return bytesToHex(concordHkdf(communityId, "concord/invite-links", hexToBytes(creatorXonlyHex)));
}

/** A channel's Pin List coordinate, bound to its community (CORD-02 Appendix A). */
export function pinsLocator(communityId: Uint8Array, channelId: string): string {
  return bytesToHex(concordHkdf(communityId, "concord/pins", hexToBytes(channelId)));
}

/** Public-invite decrypt key. secret = token, id = 0..0. */
export function inviteBundleKey(token: Uint8Array): Uint8Array {
  return concordHkdf(token, "concord/invite-key", ZERO_32);
}

/** A rekey blob locator (CORD-06 §2). */
export function recipientLocator(
  rotatorXonlyHex: string,
  recipientXonlyHex: string,
  scopeId: Uint8Array,
  epoch: number,
): string {
  const secret = concatBytes(hexToBytes(rotatorXonlyHex), hexToBytes(recipientXonlyHex));
  return bytesToHex(concordHkdf(secret, "concord/recipient-pseudonym", scopeId, epoch));
}

const EDITION_LABEL = "vector-community/v1/edition";

/**
 * edition_hash = sha256(
 *   len64(label) || label || entity_id[32] || version_be[8]
 *   || (prev ? 0x01||prev[32] : 0x00||zero[32]) || len64(content) || content )
 */
export function editionHash(
  entityId: Uint8Array,
  version: number,
  prev: Uint8Array | undefined,
  contentBytes: Uint8Array,
): string {
  const labelBytes = utf8ToBytes(EDITION_LABEL);
  const prevPart = prev ? concatBytes(new Uint8Array([0x01]), prev) : concatBytes(new Uint8Array([0x00]), ZERO_32);
  const preimage = concatBytes(
    numberToBytesBE(labelBytes.length, 8),
    labelBytes,
    entityId,
    numberToBytesBE(version, 8),
    prevPart,
    numberToBytesBE(contentBytes.length, 8),
    contentBytes,
  );
  return bytesToHex(sha256(preimage));
}

/** SHA-256 of `bytes`, hex-encoded — a convenience over the hashing this module
 *  already performs, not itself a CORD-defined derivation. */
export function sha256Hex(bytes: Uint8Array): string {
  return bytesToHex(sha256(bytes));
}
