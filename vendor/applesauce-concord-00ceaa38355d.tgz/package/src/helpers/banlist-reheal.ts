// CORD-04 §4 Banlist re-heal decisions. A concurrent Banlist edit keeps one edition and the other's addition drops
// until someone re-applies it, and "Re-heal guarantees convergence to the union": after publishing, re-fold, and if the
// addition is not in the head, re-apply it atop the winner. This module is the pure planning half of that duty: which
// of this client's bans did a concurrent sibling displace, and may they safely be put back? Decisions D-12 (a later
// unban cancels), D-13 (heal on top of the verified head), D-14 (own editions only), D-15 (rank loss and Refounding
// scope), D-19 (never lift or re-sign a ban the healer cannot vouch for) and D-21 (newest own edition only).
//
// Internal: not part of the helpers barrel. Everything here is total and never throws on input.

import { isHexKey } from "applesauce-core/helpers/string";

import { type DecodedEvent, type VerifiedControlHead, VSK } from "../types.ts";
import { type BanlistIntent, newestOwnBanlistEdition, parseBanlist, unvouchedEntries } from "./banlist.ts";
import {
  classifyEditionLineage,
  DEFAULT_EDITION_LINEAGE_DEPTH,
  editionAdditions,
  type EditionRef,
  walkEditionChain,
} from "./edition-lineage.ts";
import { computeEditionHash } from "./editions.ts";

/** Input to {@link planBanlistReHeal}. */
export interface BanlistReHealInput {
  /** This client's key; only editions it sealed seed retained candidates (D-14). */
  self: string;
  /** The community owner's key. It is never healed and always dropped from healed content. */
  owner: string;
  /** The verified Banlist head, if the fold produced one. */
  head: VerifiedControlHead | undefined;
  /** Whether the Control Plane fold is suspended; nothing is planned while it is. */
  suspended: boolean;
  /** The members the fold currently honors as banned. */
  effective: ReadonlySet<string>;
  /** The retained Control editions (any entity; the planner reads only the Banlist coordinate). */
  retained: Iterable<DecodedEvent>;
  /** This session's last intent per member (D-12, D-13). */
  intents: ReadonlyMap<string, BanlistIntent>;
  /** Members a bounded retry budget has already given up on; never planned again. */
  exhausted?: ReadonlySet<string>;
  /** Whether this client holds the strict rank and the BAN bit over `member` right now (D-15). */
  canBan(member: string): boolean;
  /** Whether a retained record sits at the current epoch's Control address, so a loss from before a Refounding seeds nothing (D-15). */
  current(record: DecodedEvent): boolean;
  /** The most versions to walk below the head. Defaults to {@link DEFAULT_EDITION_LINEAGE_DEPTH}. */
  maxDepth?: number;
}

/**
 * What to do about displaced bans. `none`: nothing to publish. `blocked`: a heal would carry these entries this client
 * cannot vouch for (D-19), so it must not publish. `heal`: publish `content` on top of the head, which restores
 * `members`; `source` says whether a session intent or only retained history named them.
 */
export type BanlistReHealPlan =
  | { kind: "none" }
  | { kind: "blocked"; members: string[] }
  | { kind: "heal"; members: string[]; content: string[]; source: "session" | "retained" };

const NONE: BanlistReHealPlan = { kind: "none" };

interface Candidate {
  ref: EditionRef;
  session: boolean;
}

/** The own edition ref a retained record denotes, or undefined when it cannot be hashed. */
function refOf(record: DecodedEvent, eid: string): EditionRef | undefined {
  const tag = (name: string) => record.rumor.tags.find((t) => t[0] === name)?.[1];
  const version = Number(tag("ev") ?? "1");
  const prevHash = tag("ep");
  if (!Number.isSafeInteger(version) || version < 1) return undefined;
  if (prevHash !== undefined && !isHexKey(prevHash)) return undefined;
  const hash = computeEditionHash({ vsk: VSK.BANLIST, eid, version, prevHash, content: record.rumor.content });
  return { eid, version, hash, ...(prevHash ? { prevHash } : {}) };
}

/**
 * Plan the re-apply of this client's Banlist additions that a concurrent sibling displaced (CORD-04 §4).
 *
 * Candidates are this session's `ban` intents (D-13) and the additions of this client's newest own Banlist edition
 * when that edition is at the current epoch's Control address (D-14, D-15, D-21). A candidate is dropped when its last
 * session intent is `unban` (D-12), it is already effective, exhausted, or this client can no longer ban it (D-15), its
 * lineage against the head is undecidable, the head's verified chain is incomplete, or the member appeared on the head
 * chain at or after the edition below its own and was later removed by anyone (a deliberate removal is never revived).
 * A member still in the head content but not effective was dropped by rank, so it is healed with the content unchanged.
 *
 * The heal content is the verified head content without the owner key followed by the lost members; it never removes
 * any other entry, so a heal cannot lift a ban (D-19). When that content would carry an entry this client cannot vouch
 * for the plan is `blocked`. Pure and total: any failure yields `none`.
 */
export function planBanlistReHeal(input: BanlistReHealInput): BanlistReHealPlan {
  try {
    const { head, self, owner } = input;
    if (!head || input.suspended || head.vsk !== VSK.BANLIST) return NONE;
    const headContent = parseBanlist(head.edition.rumor.content);
    if (!headContent) return NONE;
    const retained: DecodedEvent[] = [head.edition, ...input.retained];
    const ownerKey = owner.toLowerCase();

    // Session candidates: the last intent per member, when it is a ban that published an edition (D-13).
    const candidates = new Map<string, Candidate>();
    for (const [member, intent] of input.intents) {
      if (typeof member !== "string" || intent?.action !== "ban" || !intent.edition) continue;
      candidates.set(member.toLowerCase(), { ref: intent.edition, session: true });
    }

    // Retained candidates: only this client's newest own edition, only at the current address (D-14, D-15, D-21).
    const newest = newestOwnBanlistEdition(retained, head.eid, self);
    const ownRef = newest && input.current(newest) ? refOf(newest, head.eid) : undefined;
    if (newest && ownRef) {
      const additions = editionAdditions(newest, retained, parseBanlist);
      if (additions.predecessor === "found" || additions.predecessor === "first") {
        for (const raw of additions.added) {
          const member = raw.toLowerCase();
          if (input.intents.get(member)?.action === "unban" || candidates.has(member)) continue; // D-12
          candidates.set(member, { ref: ownRef, session: false });
        }
      }
    }

    const maxDepth = input.maxDepth ?? DEFAULT_EDITION_LINEAGE_DEPTH;
    const headSet = new Set(headContent.map((entry) => entry.toLowerCase()));
    const chains = new Map<number, ReturnType<typeof walkEditionChain>>();
    const healed: string[] = [];
    let fromSession = false;
    for (const [member, candidate] of candidates) {
      if (!isHexKey(member) || member === ownerKey) continue;
      if (input.effective.has(member) || input.exhausted?.has(member) || !input.canBan(member)) continue;
      const lineage = classifyEditionLineage(candidate.ref, head, retained, { maxDepth });
      if (lineage.kind === "unknown") continue;

      const minVersion = Math.max(1, candidate.ref.version - 1);
      let chain = chains.get(minVersion);
      if (!chain) chains.set(minVersion, chain = walkEditionChain(head, retained, { minVersion, maxDepth }));
      if (!chain.complete) continue;
      // Present in one link and absent in a later one: someone removed it on purpose, so never revive it (BAN-03).
      let seen = false;
      let removed = false;
      for (const link of chain.links) {
        const entries = parseBanlist(link.content);
        if (!entries) {
          removed = true; // an unreadable link makes the history undecidable
          break;
        }
        const present = entries.some((entry) => entry.toLowerCase() === member);
        if (present) seen = true;
        else if (seen) removed = true;
      }
      if (removed) continue;

      healed.push(member);
      if (candidate.session) fromSession = true;
    }
    if (!healed.length) return NONE;

    // Head content without the owner key, then the lost members; no other head entry is ever removed (D-19).
    const content = headContent.filter((entry) => entry.toLowerCase() !== ownerKey);
    const members = [...new Set(healed)].sort();
    for (const member of members) if (!headSet.has(member)) content.push(member);
    const unvouched = unvouchedEntries(content, ownerKey, input.canBan);
    if (unvouched.length) return { kind: "blocked", members: unvouched };
    return { kind: "heal", members, content, source: fromSession ? "session" : "retained" };
  } catch {
    return NONE;
  }
}
