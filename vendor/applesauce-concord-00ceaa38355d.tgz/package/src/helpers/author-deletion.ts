// Internal pure module; deliberately not exported from the helpers barrel (like pin-upkeep.ts).
// CORD-04 §7 (Interaction with deletion): a pinned message deleted by its own author is no longer shown. The library
// applies the same author match to an author's Edits (library rule D-31): a kind 5 by the target's own author whose
// `e` tag names the target's recomputed id retracts it.
import type { Rumor } from "../types.ts";

/**
 * True when some rumor is a kind 5 by `target.pubkey` with an `e` tag naming `target.id`. Pass the target's recomputed
 * id, never an embedded one. Total: falsy rumors, non-array tags and non-array tag entries are skipped, never thrown.
 */
export function isAuthorDeleted(target: Pick<Rumor, "id" | "pubkey">, rumors: Iterable<Rumor>): boolean {
  for (const d of rumors) {
    if (!d || d.kind !== 5 || d.pubkey !== target.pubkey || !Array.isArray(d.tags)) continue;
    for (const t of d.tags) {
      if (Array.isArray(t) && t[0] === "e" && t[1] === target.id) return true;
    }
  }
  return false;
}
