// CORD-04 Control Plane — folding versioned editions into community state.
//
// Every authority action is a kind 3308 edition sealed by the actor's real
// npub. Clients fold the highest-version edition per entity, refuse downgrades,
// and drop editions whose signer isn't authorised. Authority is rooted at the
// owner (proven by community_id) and resolved outward, so the roster is folded
// owner-first to break the apparent circularity (CORD-04 §1).

import { getEventHash } from "applesauce-core/helpers/event";
import type { Rumor } from "../types.ts";
import { PERM, VSK } from "../types.ts";
import type {
  ChannelKey,
  ChannelMetadata,
  CommunityMetadata,
  CommunityState,
  ControlPendingEvidence,
  ControlVerification,
  DecodedEvent,
  Grant,
  JoinMaterial,
  Role,
  VerifiedControlHead,
  VerifiedGrantEdition,
} from "../types.ts";
import { hasPerm, resolveStanding } from "./permissions.ts";
import { targetSupportReady } from "./authority-support.ts";
import { isHexKey } from "applesauce-core/helpers/string";
import { hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";
import { banlistLocator, editionHash, grantLocator, inviteLinksLocator, pinsLocator } from "./crypto.ts";
import { type EditionPin, resolveEditionPin } from "./editions.ts";

/** Concord control-plane edition kind (CORD-04). */
export const CONTROL_KIND = 3308;

/** Validate the exact chainless community binding of an authenticated tombstone (CORD-02 §9).
 * Callers must authenticate the enclosing owner-signed plaintext seal first.
 */
export function isDissolution(rumor: Rumor, material: Pick<JoinMaterial, "community_id" | "owner">): boolean {
  try {
    return /^[0-9a-f]{64}$/.test(material.community_id) && material.community_id !== "00".repeat(32) &&
      rumor.kind === CONTROL_KIND && rumor.pubkey === material.owner && rumor.content === "" &&
      rumor.id === getEventHash(rumor) && rumor.tags.length === 2 &&
      rumor.tags.every((tag) => tag.length === 2) &&
      rumor.tags.some((tag) => tag[0] === "vsk" && tag[1] === "10") &&
      rumor.tags.some((tag) => tag[0] === "eid" && tag[1] === material.community_id);
  } catch {
    return false;
  }
}

/** A Community folds only the 100 lowest `role_id`s, ignoring the rest (CORD-04 §2). */
export const MAX_ROLES = 100;

interface Edition {
  vsk: number;
  eid: string;
  version: number;
  prev?: string;
  /** edition_hash of THIS edition — what the next edition's `ep` must cite. */
  selfHash: string;
  content: string;
  author: string;
  rumorId: string;
  ms: number;
  /** The decoded stream event this edition arrived in (carries the re-wrappable seal). */
  source: DecodedEvent;
}

function parseEdition(d: DecodedEvent): Edition | null {
  const r = d.rumor;
  // CORD-01 §Encoding: tag members are strings; preserve first-tag semantics.
  if (
    r.kind !== CONTROL_KIND || typeof r.id !== "string" || !isKey(d.author) ||
    typeof r.content !== "string" || !Array.isArray(r.tags) ||
    !r.tags.every((tag) => Array.isArray(tag) && tag.every((value) => typeof value === "string"))
  ) return null;
  const get = (name: string) => r.tags.find((t) => t[0] === name)?.[1];
  if (["vsk", "eid", "ev", "ep"].some((name) => r.tags.find((tag) => tag[0] === name)?.length === 1)) return null;
  const vsk = get("vsk");
  const eid = get("eid");
  if (
    vsk === undefined || !isCanonicalUnsigned(vsk) || !Number.isSafeInteger(Number(vsk)) ||
    eid === undefined || !isHexKey(eid)
  ) return null;
  const ev = get("ev");
  // CORD-04 §1: validate the number-based reader before fixed-width hashing.
  if (ev !== undefined && !isCanonicalUnsigned(ev)) return null;
  const version = ev === undefined ? 1 : Number(ev);
  if (!Number.isSafeInteger(version) || version < 1) return null;
  const prev = get("ep");
  if (prev !== undefined && !isHexKey(prev)) return null;
  return {
    vsk: Number(vsk),
    eid,
    version,
    prev,
    selfHash: editionHash(hexToBytes(eid), version, prev ? hexToBytes(prev) : undefined, utf8ToBytes(r.content)),
    content: r.content,
    author: d.author,
    rumorId: r.id,
    ms: d.ms,
    source: d,
  };
}

/**
 * Eligible per-version winners, highest first. CORD-04 §1 permits a fresh fold
 * to bootstrap the highest authority-verified head despite a dangling ep.
 * Only eligible editions reach this selector; tracking continuity is separate.
 */
function headCandidates(editions: Edition[]): Edition[] {
  if (editions.length === 0) return [];
  // Per-version winner: equal version → lower rumor id (deterministic tiebreak).
  const byVersion = new Map<number, Edition>();
  for (const e of editions) {
    const w = byVersion.get(e.version);
    if (!w || e.rumorId < w.rumorId) byVersion.set(e.version, e);
  }
  return [...byVersion.keys()].sort((a, b) => b - a).map((version) => byVersion.get(version)!);
}

// Type-derived channel rules require validation or stripping for every declared field.

/**
 * Keep declared members only. Removing index signatures lets mapped rule
 * tables enforce coverage instead of accepting arbitrary string keys.
 */
export type DeclaredKeysOf<T> = {
  [K in keyof T as string extends K ? never : number extends K ? never : symbol extends K ? never : K]: T[K];
};

/**
 * Declared metadata fields with optionality removed, so even optional fields
 * require a validation rule.
 */
export type ChannelMetadataDeclared = Required<DeclaredKeysOf<ChannelMetadata>>;

/** A runtime type predicate bound to a fold rule's declared field type. */
export type ChannelFieldGuard<V> = (value: unknown) => value is V;

/**
 * One field's fold rule. `guard` is typed {@link ChannelFieldGuard}`<V>`
 * rather than a loose `(v: unknown) => boolean` so a guard asserting the
 * WRONG type for its slot is a compile error — deliberately closing the
 * class Phase 12.3 backlogged as CR5-01 (a rule's `kind` not type-bound to
 * the field it names, found latent-only there) rather than reproducing it
 * here.
 * - `"derived"`: the value never comes from edition JSON (only `channel_id`,
 *   sourced from the fold's own coordinate).
 * - `"required"`: a guard miss rejects the WHOLE edition (`continue` to the
 *   next candidate) — matches the fold's pre-existing `name`/`private`
 *   behavior.
 * - `"optional"`: a guard miss OMITS just this field and keeps the channel —
 *   converting a type-validation miss into a channel-availability miss would
 *   trade CR-01 for a worse bug (D-04's read-side precedent).
 */
export type ChannelFieldRule<V> =
  | { disposition: "derived" }
  | { disposition: "required"; guard: ChannelFieldGuard<V> }
  | { disposition: "optional"; guard: ChannelFieldGuard<V> };

/** A rule table total over {@link ChannelMetadataDeclared}'s five members. */
export type ChannelMetadataFoldRules = {
  [K in keyof ChannelMetadataDeclared]: ChannelFieldRule<ChannelMetadataDeclared[K]>;
};

function isStringValue(value: unknown): value is string {
  return typeof value === "string";
}

function isBooleanValue(value: unknown): value is boolean {
  return typeof value === "boolean";
}

/**
 * `custom` is declared `Record<string, unknown>` — excluding arrays here is a
 * DELIBERATE strengthening beyond the pre-12-08 check (which only tested
 * `typeof === "object"`): an array passes that bare typeof test while
 * producing numeric indices under `Object.keys`/enumeration, the identical
 * type-lie CR-01 names for a string `custom`.
 */
function isCustomRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isCanonicalUnsigned(value: unknown): value is string {
  return typeof value === "string" && /^(0|[1-9][0-9]*)$/.test(value);
}

function isKey(value: unknown): value is string {
  return typeof value === "string" && isHexKey(value);
}

// CORD-04 §3: u64 decimal masks, plus safe legacy numeric editions.
function permissionMask(value: unknown): string | undefined {
  if (typeof value === "number") {
    return Number.isSafeInteger(value) && value >= 0 ? String(value) : undefined;
  }
  if (!isCanonicalUnsigned(value) || value.length > 20 || BigInt(value) > 0xffffffffffffffffn) return undefined;
  return value;
}

function roleDocument(parsed: Record<string, unknown>, eid: string): Role | undefined {
  // CORD-04 §2/§3: identity, rank and permissions must be valid before insertion.
  const permissions = permissionMask(parsed.permissions);
  if (
    permissions === undefined || typeof parsed.position !== "number" ||
    !Number.isInteger(parsed.position) || parsed.position <= 0 || parsed.position >= 0xffffffff
  ) return undefined;
  if (parsed.role_id !== undefined && (!isKey(parsed.role_id) || parsed.role_id !== eid)) return undefined;
  if (parsed.name !== undefined && typeof parsed.name !== "string") return undefined;
  if (
    parsed.color !== undefined && (typeof parsed.color !== "number" || !Number.isInteger(parsed.color) ||
      parsed.color < 0 || parsed.color > 0xffffffff)
  ) return undefined;
  if (parsed.deleted !== undefined && typeof parsed.deleted !== "boolean") return undefined;
  if (parsed.scope !== undefined) {
    const scope = parsed.scope;
    if (
      !isCustomRecord(scope) || (scope.kind !== "server" && scope.kind !== "channel") ||
      (scope.channel_id !== undefined && !isKey(scope.channel_id)) ||
      (scope.kind === "channel" && !isKey(scope.channel_id))
    ) return undefined;
  }
  // Unknown fields survive; optional legacy display fields stay optional on read.
  return { ...parsed, role_id: eid, permissions } as unknown as Role;
}

/** The per-field validation table (CR-01). */
export const CHANNEL_METADATA_FOLD_RULES: ChannelMetadataFoldRules = {
  channel_id: { disposition: "derived" },
  name: { disposition: "required", guard: isStringValue },
  private: { disposition: "required", guard: isBooleanValue },
  deleted: { disposition: "optional", guard: isBooleanValue },
  custom: { disposition: "optional", guard: isCustomRecord },
};

/**
 * A total classification over every `ChannelKey` field (WR-01). The
 * conditional is the point of the whole type: a `ChannelKey` field that
 * `ChannelMetadata` does not itself declare is not merely EXPECTED to be
 * stripped, it CANNOT be classified any other way — the non-strip escape
 * hatch (`"metadata-field"`) is only reachable for names present in
 * {@link ChannelMetadataDeclared}'s key set.
 */
export type ChannelKeyFoldDisposition = {
  [K in keyof Required<ChannelKey>]: K extends keyof ChannelMetadataDeclared ? "strip" | "metadata-field" : "strip";
};

/**
 * `name` is the one field `ChannelKey` and `ChannelMetadata` share — the
 * metadata rules above validate it, so it must not be stripped. Every other
 * `ChannelKey` field (`id`, `key`, `epoch`, `held`) is key material or a
 * key-material identifier and is stripped, closing WR-01's `held` omission
 * alongside the pre-existing `key`/`epoch` denylist.
 */
export const CHANNEL_KEY_FOLD_DISPOSITION: ChannelKeyFoldDisposition = {
  id: "strip",
  key: "strip",
  epoch: "strip",
  name: "metadata-field",
  held: "strip",
};

/**
 * The strip set, DERIVED at module load from {@link CHANNEL_KEY_FOLD_DISPOSITION}
 * rather than written out as a literal array — a literal would not grow when
 * the table grows, which is the entire defect being closed.
 */
export const CHANNEL_KEY_STRIPPED_FIELDS: readonly string[] = Object.entries(CHANNEL_KEY_FOLD_DISPOSITION)
  .filter(([, disposition]) => disposition === "strip")
  .map(([field]) => field);

/**
 * Build validated metadata, or return `undefined` to try the next candidate.
 * Unknown fields precede declared fields so the derived coordinate wins.
 * `Object.fromEntries` creates data properties without invoking prototype setters.
 */
function foldChannelEdition(parsed: Record<string, unknown>, eid: string): ChannelMetadata | undefined {
  const declaredKeys = Object.keys(CHANNEL_METADATA_FOLD_RULES);
  const passThrough = Object.entries(parsed).filter(
    ([key]) => !CHANNEL_KEY_STRIPPED_FIELDS.includes(key) && !declaredKeys.includes(key),
  );

  const declared: [string, unknown][] = [];
  for (const [key, entry] of Object.entries(CHANNEL_METADATA_FOLD_RULES)) {
    // The only erasure in this function, deliberately contained here:
    // reading a heterogeneous table generically requires one widening step,
    // with the real enforcement living in `ChannelMetadataFoldRules`'s
    // declared type.
    const rule: ChannelFieldRule<unknown> = entry;
    if (rule.disposition === "derived") {
      declared.push([key, eid]);
      continue;
    }
    const raw = parsed[key];
    if (rule.guard(raw)) {
      declared.push([key, raw]);
    } else if (rule.disposition === "required") {
      return undefined;
    }
    // "optional" + guard miss: contribute nothing, keep the channel (D-04's
    // read-side precedent — a validation miss must not become an
    // availability miss).
  }

  return Object.fromEntries([...passThrough, ...declared]) as ChannelMetadata;
}

/**
 * A validated retained candidate. History and current eligibility are separate:
 * a raw matching hash is never itself a provenance certificate.
 */
interface Candidate {
  edition: Edition;
  role?: Role;
  grant?: Grant;
  channel?: ChannelMetadata;
  metadata?: CommunityMetadata;
  values?: string[];
  pin?: EditionPin;
  pins: Candidate[];
}

interface ResolutionNode {
  candidates: Candidate[];
  historical: boolean;
}

function entityKey(e: Edition): string {
  return "entity:" + e.vsk + ":" + e.eid;
}

function historyKey(c: Candidate): string {
  const e = c.edition;
  return "history:" + e.eid + ":" + e.version + ":" + e.selfHash + ":" + e.rumorId;
}

function verified(c: Candidate): VerifiedControlHead {
  const e = c.edition;
  return { edition: e.source, vsk: e.vsk, eid: e.eid, version: e.version, hash: e.selfHash, prevHash: e.prev };
}

function candidateOrder(a: Candidate, b: Candidate): number {
  return a.edition.version - b.edition.version ||
    a.edition.rumorId.localeCompare(b.edition.rumorId) ||
    a.edition.selfHash.localeCompare(b.edition.selfHash) ||
    a.edition.author.localeCompare(b.edition.author);
}

/**
 * Iterative Kosaraju traversal. Each vertex is pushed once per traversal and
 * each edge cursor advances once. Components are returned dependencies first.
 * Explicit stacks keep delegation depth independent of the JS call stack.
 */
function dependencyComponents(graph: Map<string, Set<string>>): string[][] {
  const reverse = new Map([...graph.keys()].map((key) => [key, new Set<string>()]));
  for (const [key, deps] of graph) for (const dep of deps) reverse.get(dep)!.add(key);
  const seen = new Set<string>();
  const finished: string[] = [];
  for (const key of graph.keys()) {
    if (seen.has(key)) continue;
    seen.add(key);
    const stack = [{ key, deps: [...graph.get(key)!], index: 0 }];
    while (stack.length) {
      const frame = stack[stack.length - 1];
      if (frame.index < frame.deps.length) {
        const dep = frame.deps[frame.index++];
        if (seen.has(dep)) continue;
        seen.add(dep);
        stack.push({ key: dep, deps: [...graph.get(dep)!], index: 0 });
      } else {
        finished.push(frame.key);
        stack.pop();
      }
    }
  }
  const assigned = new Set<string>();
  const components: string[][] = [];
  for (const key of finished.reverse()) {
    if (assigned.has(key)) continue;
    assigned.add(key);
    const stack = [key];
    const component: string[] = [];
    while (stack.length) {
      const current = stack.pop()!;
      component.push(current);
      for (const next of reverse.get(current)!) {
        if (assigned.has(next)) continue;
        assigned.add(next);
        stack.push(next);
      }
    }
    components.push(component.sort());
  }
  return components.reverse();
}

/**
 * Fold CORD-04 §§1–5 into deterministic, currently owner-rooted authority.
 *
 * Finite resolution contract:
 * - Candidate states are retained -> validated -> settled or parked. They never
 *   move back. History certificates and current entity nodes are distinct.
 * - Owner candidates are intrinsic anchors. Staff candidates depend on the
 *   exact typed Grant certificate, current actor Grant, ALL possible supporting
 *   Roles (rank and bit can come from different Roles), target predecessors and
 *   relevant author-ban exclusion. Inputs/ties are canonical, not timestamped.
 * - The graph is frozen before evaluation. Process its SCC condensation in
 *   dependency order. A candidate with internal component dependencies is
 *   permanently parked for this generation; independent candidates and owner
 *   anchors still settle. No cycle is allowed to manufacture positive support.
 * - A cited, linked self-empty Grant depends on its verified predecessor and
 *   pre-removal Roles instead of its own post-removal Grant. Its selected
 *   removal floor therefore cannot oscillate back to the positive predecessor.
 * - Every selected staff candidate reads only already settled exterior nodes.
 *   Owner candidates read no authority nodes. Thus later processing cannot
 *   invalidate a witness; rebuilding each projection from these selections
 *   gives one coherent snapshot without prior-pass residue.
 *
 * Termination measure: lexicographic (unvisited graph edges/vertices,
 * unsettled components, unevaluated retained candidates). Graph construction
 * scans finite candidate/pin/Role lists. Kosaraju consumes each edge at most
 * twice and each vertex at most twice; evaluation consumes each component once
 * and each candidate twice at most (history/current). No snapshots, depth cap,
 * roster assignments, state toggles or repeated convergence rounds are used.
 * Graph processing is O(V+E). For N retained candidates and L retained Role
 * references, conservative indexing and predecessor sorting are bounded by
 * O((N+L)^3 + N^2 log N); no whole-roster assignments are enumerated.
 *
 * Cyclic alternatives are deliberately conservative: an independently anchored
 * fallback survives, but staff alternatives requiring that unresolved component
 * stay parked even if one hypothetical assignment would authorize them.
 * The next fold is a new generation and recomputes from retained raw inputs.
 *
 * @param events Retained decoded control editions, including historical pins.
 * @param material Community identity and key material.
 * @param previous Optional same-community verification; continuity consumers
 *   retains display floors and historical proof across store/model compaction.
 */
export function foldControl(
  events: DecodedEvent[],
  material: JoinMaterial,
  previous?: ControlVerification,
): CommunityState {
  const owner = material.owner;
  const cid = hexToBytes(material.community_id);
  const pending = new Map<string, ControlPendingEvidence>();
  const note = (value: ControlPendingEvidence): void => {
    pending.set(JSON.stringify(value), value);
  };
  const continuity = previous?.communityId === material.community_id ? previous : undefined;
  // CORD-04 §1: a tracked edition is a floor, even after raw cache truncation.
  // Historical certificates carry provenance, not a waiver of current standing.
  const restored = continuity
    ? [...continuity.heads.values(), ...continuity.removals.values(), ...[...continuity.grantHistory.values()].flat()]
      .map((head) => head.edition)
    : [];
  const parsed = [...events, ...restored].map(parseEdition).filter((e): e is Edition => e !== null);
  const roleIds = [...new Set(parsed.filter((e) => e.vsk === VSK.ROLE).map((e) => e.eid))]
    .sort().slice(0, MAX_ROLES);
  const retained = new Map<string, Candidate>();
  for (const edition of parsed) {
    let body: unknown;
    try {
      body = JSON.parse(edition.content);
    } catch {
      if (edition.vsk !== VSK.PINS) continue;
    }
    const c: Candidate = { edition, pins: [] };
    switch (edition.vsk) {
      case VSK.PINS:
        // CORD-04 §7: content-level failures never refuse the edition or split its chain.
        if (!parsed.some((channel) => channel.vsk === VSK.CHANNEL && pinsLocator(cid, channel.eid) === edition.eid)) {
          continue;
        }
        break;
      case VSK.ROLE:
        if (!roleIds.includes(edition.eid) || !isCustomRecord(body)) continue;
        c.role = roleDocument(body, edition.eid);
        if (!c.role) continue;
        break;
      case VSK.GRANT:
        if (
          !isCustomRecord(body) || !isKey(body.member) ||
          edition.eid !== grantLocator(cid, body.member) ||
          !Array.isArray(body.role_ids) || !body.role_ids.every(isKey)
        ) continue;
        c.grant = { member: body.member, role_ids: body.role_ids };
        break;
      case VSK.METADATA:
        if (edition.eid !== material.community_id || !isCustomRecord(body)) continue;
        c.metadata = body as unknown as CommunityMetadata;
        break;
      case VSK.CHANNEL:
        if (!isCustomRecord(body)) continue;
        // A deletion document is terminal even without display metadata.
        c.channel = body.deleted === true
          ? { channel_id: edition.eid, name: "", private: false, deleted: true }
          : foldChannelEdition(body, edition.eid);
        if (!c.channel) continue;
        break;
      case VSK.BANLIST:
        if (edition.eid !== banlistLocator(cid) || !Array.isArray(body) || !body.every(isKey)) continue;
        c.values = body;
        break;
      case VSK.INVITE_REGISTRY:
        if (
          edition.eid !== inviteLinksLocator(cid, edition.author) ||
          !Array.isArray(body) || !body.every(isStringValue)
        ) continue;
        c.values = body;
        break;
      default:
        continue;
    }
    const tag = edition.source.rumor.tags.find((t) => t[0] === "vac");
    if (tag?.length === 4) c.pin = [tag[1], tag[2], tag[3]];
    const identity = entityKey(edition) + ":" + historyKey(c) + ":" + edition.author;
    // A re-wrap changes neither authority nor identity. Pick its retained seal
    // canonically so delivery order cannot choose the compaction source.
    const duplicate = retained.get(identity);
    if (!duplicate || edition.source.wrapId < duplicate.edition.source.wrapId) retained.set(identity, c);
  }
  const candidates = [...retained.values()].sort((a, b) =>
    entityKey(a.edition).localeCompare(entityKey(b.edition)) || candidateOrder(a, b)
  );
  const grantCandidates = candidates.filter((c) => c.grant);
  for (const c of candidates) {
    if (c.edition.author === owner) continue;
    if (c.pin && resolveEditionPin(grantCandidates.map((g) => g.edition.source), c.pin).kind === "matched") {
      c.pins = grantCandidates.filter((g) =>
        g.grant!.member === c.edition.author &&
        g.edition.eid === grantLocator(cid, c.edition.author) &&
        g.edition.eid === c.pin![0] && g.edition.version === Number(c.pin![1]) &&
        g.edition.selfHash === c.pin![2]
      );
    }
    if (!c.pins.length) {
      note({
        eid: c.pin?.[0] ?? grantLocator(cid, c.edition.author),
        version: c.pin ? Number(c.pin[1]) || undefined : undefined,
        hash: c.pin?.[2],
        actor: c.edition.author,
        reason: c.pin && grantCandidates.some((g) =>
            g.edition.eid === c.pin![0] && g.edition.version === Number(c.pin![1])
          )
          ? "pin-mismatch"
          : "missing-pin",
      });
    }
  }

  const nodes = new Map<string, ResolutionNode>();
  for (const c of candidates) {
    const key = entityKey(c.edition);
    const node = nodes.get(key) ?? { candidates: [], historical: false };
    node.candidates.push(c);
    nodes.set(key, node);
    if (c.grant || c.role) nodes.set(historyKey(c), { candidates: [c], historical: true });
  }
  const graph = new Map([...nodes.keys()].sort().map((key) => [key, new Set<string>()]));
  const candidateDeps = new Map<string, Map<Candidate, Set<string>>>();
  const banKey = "entity:" + VSK.BANLIST + ":" + banlistLocator(cid);
  const ownerHeads = new Map<string, Edition>();
  for (const [key, node] of nodes) {
    if (node.historical) continue;
    const head = headCandidates(node.candidates.filter((c) => c.edition.author === owner).map((c) => c.edition))[0];
    if (head) ownerHeads.set(key, head);
  }
  const canCompete = (c: Candidate): boolean => {
    if (c.channel?.deleted) return true;
    const head = ownerHeads.get(entityKey(c.edition));
    return !head || c.edition.version > head.version ||
      (c.edition.version === head.version && c.edition.rumorId <= head.rumorId);
  };
  // A lower staff edition can be the required link to a higher owner edition.
  // Verify that link with its own dependencies instead of discarding it merely
  // because it cannot win the entity's current-head competition.
  const supportsChain = (c: Candidate): boolean => {
    const floor = continuity?.heads.get(c.edition.eid);
    return c.edition.version === 1 || floor?.hash === c.edition.selfHash ||
      candidates.some((next) =>
        next.edition.eid === c.edition.eid && next.edition.vsk === c.edition.vsk &&
        next.edition.version === c.edition.version + 1 && next.edition.prev === c.edition.selfHash
      );
  };
  const bans = candidates.filter((c) =>
    c.edition.vsk === VSK.BANLIST && canCompete(c) &&
    (c.edition.author === owner || c.pins.length > 0)
  );
  const memberGrants = new Map<string, Candidate[]>();
  for (const c of grantCandidates) {
    const list = memberGrants.get(c.grant!.member) ?? [];
    list.push(c);
    memberGrants.set(c.grant!.member, list);
  }
  const currentGrantKey = (member: string) => "entity:" + VSK.GRANT + ":" + grantLocator(cid, member);
  const roleKey = (role: string) => "entity:" + VSK.ROLE + ":" + role;
  // Conservative rank/bit bounds over possible current Role heads. A held Role
  // supplying neither the required bit nor the minimum rank is not a support
  // edge: editing that unrelated lower Role must not create a false self-cycle.
  const bounds = new Map<string, { min: number; max: number; bits: bigint }>();
  for (const [key, node] of nodes) {
    if (node.historical || !node.candidates[0].role) continue;
    const choices = node.candidates.filter(canCompete).map((c) => c.role!);
    const positions = choices.map((r) => r.deleted ? 0xffffffff : r.position);
    bounds.set(node.candidates[0].edition.eid, {
      min: positions.reduce((min, position) => Math.min(min, position), 0xffffffff),
      max: ownerHeads.has(key) ? positions.reduce((max, position) => Math.max(max, position), 0) : 0xffffffff,
      bits: choices.reduce((bits, r) => bits | (r.deleted ? 0n : BigInt(r.permissions)), 0n),
    });
  }
  const requiredBit = (c: Candidate): bigint => {
    switch (c.edition.vsk) {
      case VSK.ROLE:
      case VSK.GRANT:
        return PERM.MANAGE_ROLES;
      case VSK.PINS:
        return PERM.PIN_MESSAGES;
      case VSK.METADATA:
        return PERM.MANAGE_METADATA;
      case VSK.CHANNEL:
        return PERM.MANAGE_CHANNELS;
      case VSK.BANLIST:
        return PERM.BAN;
      case VSK.INVITE_REGISTRY:
        return PERM.CREATE_INVITE;
      default:
        return 0n;
    }
  };
  const isSelfRemoval = (c: Candidate): boolean =>
    !!c.grant &&
    c.grant.member === c.edition.author && c.grant.role_ids.length === 0 &&
    c.pins.some((p) => c.edition.version === p.edition.version + 1 && c.edition.prev === p.edition.selfHash);
  const isVerifiedRoleFloor = (c: Candidate): boolean => {
    const floor = continuity?.heads.get(c.edition.eid);
    return !!floor && floor.vsk === VSK.ROLE && floor.version === c.edition.version &&
      floor.hash === c.edition.selfHash && floor.edition.author === c.edition.author &&
      floor.edition.rumor.id === c.edition.rumorId;
  };
  for (const [key, node] of nodes) {
    const perCandidate = new Map<Candidate, Set<string>>();
    // Intrinsic latest owner anchors cannot be displaced by a lower edition.
    for (const c of node.candidates) {
      const deps = new Set<string>();
      const add = (dep: string): void => {
        if (nodes.has(dep)) deps.add(dep);
      };
      const addRoles = (grants: Candidate[], required?: bigint): void => {
        for (const g of grants) {
          for (const rid of g.grant!.role_ids) {
            const bound = bounds.get(rid);
            if (!bound) continue;
            const otherMaximum = g.grant!.role_ids.filter((r) => r !== rid)
              .reduce((position, r) => Math.min(position, bounds.get(r)?.max ?? 0xffffffff), 0xffffffff);
            if (required === undefined || bound.min <= otherMaximum || (bound.bits & required) !== 0n) {
              add(roleKey(rid));
            }
          }
        }
      };
      if (
        c.edition.author !== owner && c.pins.length &&
        (node.historical || canCompete(c) || supportsChain(c))
      ) {
        for (const pin of c.pins) add(historyKey(pin));
        addRoles(c.pins, node.historical ? PERM.MANAGE_ROLES : requiredBit(c));
        if (c.role) {
          // CORD-04 §§3, 5: an edit cannot supply its own target-rank witness.
          for (const prior of candidates) {
            if (
              prior.role && prior.edition.eid === c.edition.eid &&
              prior.edition.version === c.edition.version - 1 && prior.edition.selfHash === c.edition.prev
            ) {
              add(historyKey(prior));
            }
          }
          if (
            c.edition.version > 1 && !isVerifiedRoleFloor(c) &&
            !candidates.some((prior) =>
              prior.role && prior.edition.eid === c.edition.eid &&
              prior.edition.version === c.edition.version - 1 && prior.edition.selfHash === c.edition.prev
            )
          ) note({ eid: c.edition.eid, version: c.edition.version - 1, hash: c.edition.prev, reason: "chain-gap" });
        }
        if (c.grant) {
          addRoles([c]);
          // The target standing immediately before this transition, rather
          // than the self-referential post-grant rank.
          const earlier = (memberGrants.get(c.grant.member) ?? []).filter((g) =>
            g.edition.version < c.edition.version ||
            (g.edition.author === owner && g.edition.version === c.edition.version)
          );
          for (const g of earlier) add(historyKey(g));
          addRoles(earlier, 0n);
        }
        if (!node.historical && (c.grant || c.role)) add(historyKey(c));
        // Role certificates call currentEligible too, so they must wait for
        // exactly the same current actor support and ban exclusion as heads.
        // Historical Grant provenance continues to use its separate pin predicate.
        if (!node.historical || c.role) {
          if (!isSelfRemoval(c)) {
            add(currentGrantKey(c.edition.author));
            addRoles(memberGrants.get(c.edition.author) ?? [], requiredBit(c));
          }
          if (bans.some((ban) => ban.values!.includes(c.edition.author))) add(banKey);
          if (c.edition.vsk === VSK.BANLIST) {
            for (const target of c.values!) {
              if (target === owner) continue;
              add(currentGrantKey(target));
              addRoles(memberGrants.get(target) ?? [], 0n);
            }
          }
        }
      }
      perCandidate.set(c, deps);
      for (const dep of deps) graph.get(key)!.add(dep);
    }
    candidateDeps.set(key, perCandidate);
  }

  const roles = new Map<string, Role>();
  const grants = new Map<string, string[]>();
  const banlist = new Set<string>();
  const selected = new Map<string, Candidate>();
  const historical = new Set<Candidate>();
  const verifiedRoles = new Set<Candidate>();
  for (const c of grantCandidates) {
    if (
      continuity?.grantHistory.get(c.edition.eid)?.some((entry) =>
        entry.version === c.edition.version && entry.hash === c.edition.selfHash &&
        entry.edition.rumor.id === c.edition.rumorId && entry.edition.author === c.edition.author
      )
    ) historical.add(c);
  }
  const suspended = new Set<string>();
  const removals = new Map<string, VerifiedControlHead>();
  const standing = (member: string) => resolveStanding(member, owner, roles, grants);
  const pinnedStanding = (c: Candidate) => {
    const pin = c.pins.find((p) => historical.has(p));
    return pin
      ? resolveStanding(c.edition.author, owner, roles, new Map([[c.edition.author, pin.grant!.role_ids]]))
      : undefined;
  };
  const predecessor = (c: Candidate): Candidate | undefined => {
    const prior = (memberGrants.get(c.grant!.member) ?? []).filter((g) =>
      historical.has(g) && g.edition.version < c.edition.version
    );
    const head = headCandidates(prior.map((g) => g.edition))[0];
    return prior.find((g) => g.edition === head);
  };
  const targetChainReady = (prior: Candidate[]): boolean => {
    if (!prior.length) return true;
    const head = headCandidates(prior.map((g) => g.edition))[0];
    const floor = continuity?.heads.get(head.eid);
    if (
      continuity?.suspended.has(head.eid) &&
      continuity.pending.some((missing) =>
        missing.reason === "chain-gap" && missing.eid === head.eid &&
        !prior.some((g) => g.edition.version === missing.version && g.edition.selfHash === missing.hash)
      )
    ) return false;
    const anchor = floor && floor.version <= head.version
      ? prior.find((g) => g.edition.selfHash === floor.hash && g.edition.version === floor.version)
      : prior.filter((g) => g.edition.version === 1).sort(candidateOrder)[0];
    // Fresh compacted owner-rooted Grants may bootstrap; retained floors cannot.
    if (!anchor) return !floor || floor.version > head.version;
    const linked = new Set([anchor]);
    for (const g of [...prior].sort(candidateOrder)) {
      if (g.edition.version === anchor.edition.version && g.edition.prev === anchor.edition.prev) linked.add(g);
      if (
        [...linked].some((p) => g.edition.version === p.edition.version + 1 && g.edition.prev === p.edition.selfHash)
      ) {
        linked.add(g);
      }
    }
    return [...linked].some((g) => g.edition === head);
  };
  const grantRank = (c: Candidate, s: ReturnType<typeof standing>): boolean => {
    if (
      !c.grant!.role_ids.every((rid) => {
        const role = roles.get(rid);
        return !!role && !role.deleted && role.position > s.position;
      })
    ) return false;
    if (c.grant!.member === c.edition.author) return true;
    const targetCandidates = (memberGrants.get(c.grant!.member) ?? []).filter((g) =>
      historical.has(g) && (g.edition.version < c.edition.version ||
        (g.edition.author === owner && g.edition.version === c.edition.version))
    );
    const targetHead = headCandidates(targetCandidates.map((g) => g.edition))[0];
    const prior = targetCandidates.find((g) => g.edition === targetHead);
    if (
      !targetSupportReady(
        targetChainReady(targetCandidates) && (c.edition.version === 1 ||
          (!!prior && prior.edition.version === c.edition.version - 1 && prior.edition.selfHash === c.edition.prev)),
        prior?.grant?.role_ids,
        (rid) => roles.has(rid) && !suspended.has(rid),
      )
    ) return false;
    const target = prior
      ? resolveStanding(c.grant!.member, owner, roles, new Map([[c.grant!.member, prior.grant!.role_ids]]))
      : resolveStanding(c.grant!.member, owner, roles, new Map());
    return s.position < target.position;
  };
  const currentEligible = (c: Candidate): boolean => {
    if (c.edition.author === owner) return true;
    if (banlist.has(c.edition.author) || !c.pins.some((p) => historical.has(p))) return false;
    if (isSelfRemoval(c)) {
      const prior = predecessor(c);
      const s = pinnedStanding(c);
      return !!prior && c.pins.includes(prior) && c.edition.prev === prior.edition.selfHash &&
        historical.has(c) && !!s && hasPerm(s.permissions, PERM.MANAGE_ROLES);
    }
    const s = standing(c.edition.author);
    switch (c.edition.vsk) {
      case VSK.ROLE:
        return hasPerm(s.permissions, PERM.MANAGE_ROLES) && c.role!.position > s.position &&
          // A restored exact verified floor already carries the prior transition's
          // proof. Recheck current actor rank/bits; newly received edits need a predecessor.
          (c.edition.version === 1 || isVerifiedRoleFloor(c) ||
            candidates.some((prior) =>
              verifiedRoles.has(prior) && prior.edition.eid === c.edition.eid &&
              prior.edition.version === c.edition.version - 1 && prior.edition.selfHash === c.edition.prev &&
              prior.role!.position > s.position
            ));
      case VSK.GRANT:
        return historical.has(c) && hasPerm(s.permissions, PERM.MANAGE_ROLES) && grantRank(c, s);
      case VSK.PINS:
        return hasPerm(s.permissions, PERM.PIN_MESSAGES);
      case VSK.METADATA:
        return hasPerm(s.permissions, PERM.MANAGE_METADATA);
      case VSK.CHANNEL:
        return hasPerm(s.permissions, PERM.MANAGE_CHANNELS);
      case VSK.BANLIST:
        return hasPerm(s.permissions, PERM.BAN);
      case VSK.INVITE_REGISTRY:
        return hasPerm(s.permissions, PERM.CREATE_INVITE);
      default:
        return false;
    }
  };
  for (const component of dependencyComponents(graph)) {
    const internal = new Set(component);
    for (const key of component) {
      const node = nodes.get(key)!;
      const eligible: Candidate[] = [];
      for (const c of node.candidates) {
        if (!node.historical && c.edition.author !== owner && !canCompete(c) && !supportsChain(c)) continue;
        if ([...candidateDeps.get(key)!.get(c)!].some((dep) => internal.has(dep))) {
          note({
            eid: c.edition.eid,
            version: c.edition.version,
            hash: c.edition.selfHash,
            actor: c.edition.author,
            reason: "support-cycle",
          });
          continue;
        }
        if (node.historical) {
          if (c.role) {
            if (currentEligible(c)) verifiedRoles.add(c);
          } else {
            const s = pinnedStanding(c);
            if (c.edition.author === owner || (s && hasPerm(s.permissions, PERM.MANAGE_ROLES) && grantRank(c, s))) {
              historical.add(c);
            }
          }
        } else if (currentEligible(c)) eligible.push(c);
      }
      if (node.historical) continue;
      const deletions = eligible.filter((c) => c.channel?.deleted);
      const head = deletions.length
        ? deletions.sort((a, b) => a.edition.rumorId.localeCompare(b.edition.rumorId))[0].edition
        : headCandidates(eligible.map((c) => c.edition))[0];
      let winner = eligible.find((c) => c.edition === head);
      if (!winner) {
        if (
          node.candidates.some((c) =>
            pending.has(JSON.stringify({
              eid: c.edition.eid,
              version: c.edition.version,
              hash: c.edition.selfHash,
              actor: c.edition.author,
              reason: "support-cycle",
            }))
          )
        ) suspended.add(node.candidates[0].edition.eid);
        continue;
      }
      const floor = continuity?.heads.get(winner.edition.eid);
      // Reconstruct tracking from an eligible genesis when complete history is
      // retained. A genuinely compacted fresh entity may bootstrap its head.
      let anchor = floor
        ? eligible.find((c) => c.edition.selfHash === floor.hash && c.edition.version === floor.version)
        : eligible.filter((c) => c.edition.version === 1).sort(candidateOrder)[0];
      if (anchor && !winner.channel?.deleted) {
        const linked = new Set([anchor]);
        for (const c of [...eligible].sort(candidateOrder)) {
          if (c.edition.version === anchor.edition.version && c.edition.prev === anchor.edition.prev) linked.add(c);
          if (
            [...linked].some((p) =>
              c.edition.version === p.edition.version + 1 && c.edition.prev === p.edition.selfHash
            )
          ) {
            linked.add(c);
          }
        }
        const reachableHead = headCandidates([...linked].map((c) => c.edition))[0];
        anchor = [...linked].find((c) => c.edition === reachableHead)!;
        const anchorVersion = anchor.edition.version;
        const higher = eligible.filter((c) => c.edition.version > anchorVersion);
        if (higher.length) {
          suspended.add(anchor.edition.eid);
          // Request the exact first missing predecessor on each authorized
          // higher path. Invalid or unauthorized orphans never reach here.
          for (const c of higher) {
            let missing = c;
            while (missing.edition.version > anchor.edition.version + 1) {
              const predecessor = eligible.find((p) =>
                p.edition.version === missing.edition.version - 1 && p.edition.selfHash === missing.edition.prev
              );
              if (!predecessor) break;
              missing = predecessor;
            }
            note({
              eid: c.edition.eid,
              version: missing.edition.version - 1,
              hash: missing.edition.prev,
              reason: "chain-gap",
            });
          }
        } else if (continuity?.suspended.has(anchor.edition.eid)) {
          // A recreated/truncated cache cannot silently clear a known gap.
          // Clear it only once the exact requested chain evidence is retained.
          for (
            const missing of continuity.pending.filter((p) => p.reason === "chain-gap" && p.eid === anchor!.edition.eid)
          ) {
            if (!eligible.some((c) => c.edition.version === missing.version && c.edition.selfHash === missing.hash)) {
              suspended.add(anchor.edition.eid);
              note(missing);
            }
          }
        }
        winner = anchor;
      }
      selected.set(key, winner);
      if (winner.role && !suspended.has(winner.edition.eid)) roles.set(winner.edition.eid, winner.role);
      if (winner.grant && !suspended.has(winner.edition.eid)) {
        grants.set(winner.grant.member, [...winner.grant.role_ids]);
        if (!winner.grant.role_ids.length) removals.set(winner.edition.eid, verified(winner));
      }
      if (winner.edition.vsk === VSK.BANLIST && !suspended.has(winner.edition.eid)) {
        const s = standing(winner.edition.author);
        for (const target of winner.values!) {
          const eid = grantLocator(cid, target);
          const ready = targetSupportReady(
            // Only settled Grants and verified suspensions are rank evidence.
            // An unauthorized raw candidate cannot immunize an absent target.
            !suspended.has(eid),
            grants.get(target),
            (rid) => roles.has(rid) && !suspended.has(rid),
          );
          if (target !== owner && (s.isOwner || (ready && s.position < standing(target).position))) banlist.add(target);
        }
      }
      if (winner.channel?.deleted) removals.set(winner.edition.eid, verified(winner));
    }
  }

  const heads = new Map<string, DecodedEvent>();
  const verifiedHeads = new Map<string, VerifiedControlHead>();
  const channels: ChannelMetadata[] = [];
  const inviteLinks = new Set<string>();
  let metadata: CommunityMetadata | undefined;
  const displayRoles: Role[] = [];
  const displayGrants = new Map<string, string[]>();
  for (const [, c] of [...selected].sort(([a], [b]) => a.localeCompare(b))) {
    heads.set(c.edition.eid, c.edition.source);
    verifiedHeads.set(c.edition.eid, verified(c));
    if (c.role) displayRoles.push(c.role);
    if (c.grant) displayGrants.set(c.grant.member, [...c.grant.role_ids]);
    if (c.metadata) metadata = c.metadata;
    if (c.channel && !c.channel.deleted) channels.push(c.channel);
    if (c.edition.vsk === VSK.INVITE_REGISTRY) { for (const value of c.values!) inviteLinks.add(value); }
  }
  const grantHistory = new Map<string, VerifiedGrantEdition[]>();
  for (const c of [...historical].sort(candidateOrder)) {
    const history = grantHistory.get(c.edition.eid) ?? [];
    history.push({ ...verified(c), member: c.grant!.member, roleIds: [...c.grant!.role_ids] });
    grantHistory.set(c.edition.eid, history);
  }
  // Historical proof may survive a tracking caller's raw-store compaction.
  // It never reintroduces a current Grant or changes current enforcement here.
  if (previous?.communityId === material.community_id) {
    for (const [eid, history] of previous.grantHistory) {
      const current = grantHistory.get(eid) ?? [];
      for (const entry of history) {
        if (
          !current.some((e) =>
            e.hash === entry.hash && e.version === entry.version &&
            e.edition.rumor.id === entry.edition.rumor.id
          )
        ) current.push(entry);
      }
      grantHistory.set(
        eid,
        current.sort((a, b) =>
          a.version - b.version ||
          a.edition.rumor.id.localeCompare(b.edition.rumor.id)
        ),
      );
    }
  }
  return {
    material,
    metadata,
    channels,
    roles: displayRoles.sort((a, b) => a.position - b.position || a.role_id.localeCompare(b.role_id)),
    grants: new Map([...displayGrants].sort(([a], [b]) => a.localeCompare(b))),
    banlist,
    inviteLinks,
    members: new Set(),
    dissolved: false,
    heads,
    controlVerification: {
      communityId: material.community_id,
      heads: verifiedHeads,
      grantHistory: new Map([...grantHistory].sort(([a], [b]) => a.localeCompare(b))),
      suspended,
      pending: [...pending.values()].sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))),
      removals,
    },
  };
}
