// The single Concord key-state object and the functional operations over it.
//
// All of a community's cryptographic material for an epoch lives in one
// `ConcordKeys` value, derived purely from its `JoinMaterial` plus the folded
// channel set. Wrapping an event and rotating keys (Refounding) are pure
// functions over that value — the signer is always a *separate* argument
// (mirroring stream.ts's `author`), so the crypto never needs the client class.

import { MessageAlreadyExpiredError, rumorExpiration, stampMessageExpiration } from "./expiration.ts";
import { assertEnvelopeCap } from "./caps.ts";
import { parseMs } from "./stream.ts";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { getOrComputeCachedValue } from "applesauce-core/helpers/cache";
import { unixNow } from "applesauce-core/helpers/time";
import { type NostrEvent, verifyWrappedEvent } from "applesauce-core/helpers/event";
import type { ISigner } from "applesauce-signers";

import {
  baseRekeyGroupKey,
  channelGroupKey,
  channelRekeyGroupKey,
  controlGroupKey,
  controlKeyFor,
  controlSignerGroupKey,
  dissolvedGroupKey,
  epochKeyCommitment,
  guestbookGroupKey,
} from "./crypto.ts";
import type { ControlKey, GroupKey } from "./crypto.ts";
import { channelKeyFor } from "./community.ts";
import { type EditionPin, type EditionPinResult, resolveEditionPin } from "./editions.ts";
import {
  base64ToBytes,
  buildRekeyRumors,
  bytesToBase64,
  checkContinuity,
  decodeBaseWrappedKey,
  decodeWrappedKey,
  encodeBaseWrappedKey,
  encodeWrappedKey,
  findBlob,
  groupRotations,
  lowerKeyWins,
  parseRekeyResult,
  rekeyLocator,
  ROOT_SCOPE_HEX,
} from "./rekey.ts";
import type { BaseRekeyMaterial } from "./rekey.ts";
import { giftWrap, rewrapSeal, sealRumor, toRumor, wrapSeal } from "../operations/gift-wrap.ts";
import { buildSnapshotFactories } from "../factories/guestbook.ts";
import { PLAINTEXT_SEAL_KIND } from "./gift-wrap.ts";
import { isCurrentStaff, refoundAuthority, vacVerifier } from "./permissions.ts";
import { PERM } from "../types.ts";
import type {
  ChannelKey,
  ChannelMetadata,
  CommunityState,
  DecodedEvent,
  HeldRootEntry,
  JoinMaterial,
  RumorTemplate,
} from "../types.ts";

/** How {@link classifyRotationAuthority} rated a rotator's CORD-04 citation:
 *  eligible to rotate, `parked` pending a cited edition we have not synced yet,
 *  or a terminal refusal. Parking rather than rejecting is what keeps an
 *  unsynced citation from being mistaken for a forged one. */
export type RotationAuthorityOutcome =
  | { kind: "eligible" }
  | { kind: "parked"; citation: Extract<EditionPinResult, { kind: "missing" | "mismatch" }> }
  | { kind: "unauthorized" }
  | { kind: "rejected"; reason: "citation-mismatch" }
  | { kind: "malformed" };

/**
 * Classify a rotation's CORD-04 authority without performing network work.
 * Exact historical citation resolution is only a synchronization floor; the
 * caller-provided current-roster verdict remains authoritative afterwards.
 */
export function classifyRotationAuthority(
  rotator: string,
  vac: EditionPin | undefined,
  owner: string,
  controlEditions: Iterable<DecodedEvent>,
  isCurrentlyAuthorized: (rotator: string, vac: EditionPin) => boolean,
  opts: { mismatchExhausted?: boolean } = {},
): RotationAuthorityOutcome {
  if (rotator === owner) return vac === undefined ? { kind: "eligible" } : { kind: "malformed" };
  if (!vac) return { kind: "malformed" };
  const citation = resolveEditionPin(controlEditions, vac);
  if (citation.kind === "mismatch" && opts.mismatchExhausted) {
    return { kind: "rejected", reason: "citation-mismatch" };
  }
  if (citation.kind === "missing" || citation.kind === "mismatch") return { kind: "parked", citation };
  if (citation.kind === "malformed") return { kind: "malformed" };
  return isCurrentlyAuthorized(rotator, vac) ? { kind: "eligible" } : { kind: "unauthorized" };
}

/** A decrypt-side descriptor: which plane a stream pubkey addresses, and the
 *  NIP-44 conversation key that opens its wraps. */
export interface PlaneInfo {
  /** Expected identity for the publicly writable dissolved address (CORD-02 §9). */
  communityId?: string;
  /** Owner committed to by the community identity. */
  owner?: string;
  /** Which plane this stream pubkey addresses. */
  type: "control" | "guestbook" | "channel" | "dissolved" | "rekey";
  /** The NIP-44 conversation key that opens wraps at this address. */
  convKey: Uint8Array;
  /** The channel this address belongs to, for `channel` planes and
   *  channel-scoped `rekey` addresses. */
  channelId?: string;
  /** The epoch this address derives at, for the planes that ride one — the
   *  Guestbook (CORD-02 §5), channels, and rekey addresses. Control and
   *  dissolved carry none. */
  epoch?: number;
}

/**
 * Every cryptographic key a member holds for a community at its current epoch —
 * the single state object. Derived purely from {@link JoinMaterial} + the folded
 * channels via {@link deriveConcordKeys}; `material` is the persisted source of
 * truth the rest is a function of.
 */
export interface ConcordKeys {
  /** The persisted membership/key material this derives from. */
  material: JoinMaterial;
  /** Control read address/key with an optional held staff wrap signer (CORD-02 §5). */
  control: ControlKey;
  /** The Guestbook Plane stream address + key at this epoch (CORD-02 §5). */
  guestbook: GroupKey;
  /** The dissolution-tombstone address. Derived from the community_id alone, so
   *  it is stable across every Refounding. */
  dissolved: GroupKey;
  /** The NEXT epoch's base-rekey listen address (CORD-06 §2): a Refounding
   *  publishes the new community_root here, keyed by the PRIOR root. */
  nextBaseRekey: { key: GroupKey; epoch: number };
  /** channel_id -> group key (public derived from root; private from its key). */
  channels: Map<string, GroupKey>;
  /** channel_id -> the epoch its key derives at (for the CORD-03 receive binding). */
  channelEpochs: Map<string, number>;
  /** Decrypt-side lookup: stream pubkey -> plane info, spanning every plane and
   *  (after a Refounding) retained prior-epoch addresses so history still decodes. */
  planes: Map<string, PlaneInfo>;
}

/** The epoch a channel's chat key derives at: its own for a private channel, the
 *  community root epoch for a public one. */
export function channelEpochOf(keys: ConcordKeys, channelId: string): number {
  return keys.channelEpochs.get(channelId) ?? keys.material.root_epoch;
}

/** The base (channel-independent) group keys, a pure function of `material`.
 *  Memoized on the material object (see {@link baseKeysFor}). */
interface BaseKeys {
  control: ControlKey;
  guestbook: GroupKey;
  dissolved: GroupKey;
  nextBaseRekey: { key: GroupKey; epoch: number };
}

/**
 * Memoize derivations on the stable material object. Cache symbols must be
 * non-enumerable so `rollForward` spreads cannot carry old-epoch keys forward.
 * Symbol-keyed caches are also excluded from JSON persistence.
 */
const BaseKeysSymbol = Symbol.for("concord-base-keys");
const ChannelKeysSymbol = Symbol.for("concord-channel-keys");
const ArchivedMaterialsSymbol = Symbol.for("concord-archived-materials");
/** Memoizes a Private Channel's current + held message-plane keys on its
 *  {@link ChannelKey} object (see {@link deriveChannelKeys}). */
const ChannelPlaneKeysSymbol = Symbol.for("concord-channel-plane-keys");

function nextEpochFor(epoch: number): number {
  const next = epoch + 1;
  if (!Number.isSafeInteger(epoch) || epoch < 0 || !Number.isSafeInteger(next)) {
    throw new RangeError("next epoch is not representable");
  }
  return next;
}

/**
 * Require the held current Control Plane signing capability before base writes.
 * Legacy material derives its historical signer; split members remain read-only.
 * Call before secret generation, signer I/O or persistence (CORD-06 §3; CORD-02 §5).
 */
export function assertBaseRotationSupported(material: JoinMaterial): void {
  if (!controlKeyFor(material).signing) throw new Error("control signing capability unavailable");
}

/** Check a captured operation around every remote signer boundary, including operations' internal calls. */
function guardedSigner(signer: ISigner, actor: string, assertCurrent?: () => void): ISigner {
  const call = async <T>(operation: () => Promise<T>): Promise<T> => {
    assertCurrent?.();
    try {
      return await operation();
    } finally {
      assertCurrent?.();
    }
  };
  return {
    getPublicKey: async () => {
      const pubkey = await call(() => signer.getPublicKey());
      if (pubkey !== actor) throw new Error("refounding signer does not match actor");
      return pubkey;
    },
    signEvent: async (event) => {
      const signed = await call(() => signer.signEvent(event));
      if (signed.pubkey !== actor) throw new Error("refounding signer does not match actor");
      return signed;
    },
    ...(signer.nip44
      ? {
        nip44: {
          encrypt: (pk: string, content: string) => {
            assertEnvelopeCap(content);
            return call(() => signer.nip44!.encrypt(pk, content));
          },
          decrypt: (pk: string, content: string) => call(() => signer.nip44!.decrypt(pk, content)),
        },
      }
      : {}),
  };
}

/** The base keys for `material`, derived once and memoized on it. */
function baseKeysFor(material: JoinMaterial): BaseKeys {
  return getOrComputeCachedValue(material, BaseKeysSymbol, () => {
    const cid = hexToBytes(material.community_id);
    const root = hexToBytes(material.community_root);
    const nextEpoch = nextEpochFor(material.root_epoch);
    return {
      control: controlKeyFor(material),
      guestbook: guestbookGroupKey(root, cid, material.root_epoch),
      dissolved: dissolvedGroupKey(cid),
      nextBaseRekey: { key: baseRekeyGroupKey(root, cid, nextEpoch), epoch: nextEpoch },
    };
  });
}

/** A channel's Chat-Plane group key for `material`, memoized on `material` keyed
 *  by a per-channel signature (public keys derive from the material's root/epoch,
 *  so `channel_id` disambiguates within a material; the private key/epoch are
 *  sourced from `material.channels` — the single source of truth post-D-01 —
 *  and folded in for safety since a private channel derives from its own secret).
 *  Returns `null` when a private channel has no held key (CHAN-01: derives
 *  nothing); the `null` itself is memoized (`cache.has`, not truthiness) so a
 *  cached "no key" result isn't recomputed every call. */
function channelKeyMemo(material: JoinMaterial, channel: ChannelMetadata): GroupKey | null {
  const cache = getOrComputeCachedValue(material, ChannelKeysSymbol, () => new Map<string, GroupKey | null>());
  const held = channel.private ? material.channels.find((c) => c.id === channel.channel_id) : undefined;
  const sig = channel.private
    ? held ? `p|${channel.channel_id}|${held.key}|${held.epoch}` : `p0|${channel.channel_id}`
    : `c|${channel.channel_id}`;
  if (cache.has(sig)) return cache.get(sig)!;
  const gk = channelKeyFor(material, channel);
  cache.set(sig, gk);
  return gk;
}

/**
 * Derive the full key state for `material` at its current epoch. Pass `prior` to
 * retain its (prior-epoch) plane addresses in the returned `planes` map — a
 * Refounding rolls the current epoch forward but already-fetched history must
 * still decode at the addresses it was wrapped under.
 */
export function deriveConcordKeys(
  material: JoinMaterial,
  channels: ChannelMetadata[],
  prior?: ConcordKeys,
): ConcordKeys {
  const { control, guestbook, dissolved, nextBaseRekey } = baseKeysFor(material);
  const nextEpoch = nextBaseRekey.epoch;

  const channelKeys = new Map<string, GroupKey>();
  const channelEpochs = new Map<string, number>();
  for (const ch of channels) {
    const gk = channelKeyMemo(material, ch);
    if (!gk) continue; // CHAN-01: keyless private channel — no entry, no epoch, no plane
    const held = ch.private ? material.channels.find((c) => c.id === ch.channel_id) : undefined;
    channelKeys.set(ch.channel_id, gk);
    // CHAN-03: the epoch the held key actually derived at, never ch.epoch ?? 1
    // off the edition (that field no longer exists post-D-01).
    channelEpochs.set(ch.channel_id, ch.private ? held!.epoch : material.root_epoch);
  }

  const planes = new Map<string, PlaneInfo>(prior?.planes);
  // CORD-06 §3: losing forks retain read capabilities, never current authority.
  // Archive derivation is independent of the current pair and tolerates old records.
  for (const held of material.held_roots ?? []) {
    try {
      // Keep archive objects stable so their base/channel memoization survives live updates.
      // Scope secrets to the owning material; object spreads must not inherit this cache.
      const archives = getOrComputeCachedValue(
        material,
        ArchivedMaterialsSymbol,
        () => new Map<string, JoinMaterial>(),
      );
      const coordinate = JSON.stringify([held.key, held.epoch, held.control_pk, held.control_root]);
      let archived = archives.get(coordinate);
      if (!archived) {
        const { control_pk: _pk, control_root: _root, ...base } = material;
        archived = {
          ...base,
          community_root: held.key,
          root_epoch: held.epoch,
          ...(held.control_pk !== undefined ? { control_pk: held.control_pk } : {}),
          ...(held.control_root !== undefined ? { control_root: held.control_root } : {}),
        };
        archives.set(coordinate, archived);
      }
      const derived = baseKeysFor(archived);
      planes.set(derived.control.pk, { type: "control", convKey: derived.control.convKey });
      planes.set(derived.guestbook.pk, { type: "guestbook", convKey: derived.guestbook.convKey, epoch: held.epoch });
      for (const channel of channels.filter((channel) => !channel.private)) {
        const key = channelKeyMemo(archived, channel)!;
        planes.set(key.pk, { type: "channel", convKey: key.convKey, channelId: channel.channel_id, epoch: held.epoch });
      }
    } catch { /* A malformed saved descriptor cannot interrupt current reads. */ }
  }
  planes.set(control.pk, { type: "control", convKey: control.convKey });
  // The Guestbook rides the epoch (CORD-02 §5): stamp it so `planeStoreKey`
  // (client/sync.ts) can key its store per epoch, unlike control/dissolved.
  planes.set(guestbook.pk, { type: "guestbook", convKey: guestbook.convKey, epoch: material.root_epoch });
  planes.set(dissolved.pk, {
    type: "dissolved",
    convKey: dissolved.convKey,
    communityId: material.community_id,
    owner: material.owner,
  });
  planes.set(nextBaseRekey.key.pk, { type: "rekey", convKey: nextBaseRekey.key.convKey, epoch: nextEpoch });
  for (const [channelId, key] of channelKeys) {
    planes.set(key.pk, { type: "channel", convKey: key.convKey, channelId, epoch: channelEpochs.get(channelId) });
  }

  return { material, control, guestbook, dissolved, nextBaseRekey, channels: channelKeys, channelEpochs, planes };
}

/** Which plane to wrap an event for. */
export type WrapTarget = { plane: "control" | "guestbook" | "dissolved" } | { plane: "channel"; channelId: string };

/** Resolve a {@link WrapTarget} to its wrapping key. Read-only control rejects
 * with `control signing capability unavailable` before author signer I/O. */
export function planeKeyFor(keys: ConcordKeys, target: WrapTarget): GroupKey {
  switch (target.plane) {
    case "control":
      // CORD-02 §5: reading a stream never implies its independent signing capability.
      if (!keys.control.signing) throw new Error("control signing capability unavailable");
      return { ...keys.control.signing, convKey: keys.control.convKey };
    case "guestbook":
      return keys.guestbook;
    case "dissolved":
      return keys.dissolved;
    case "channel": {
      const key = keys.channels.get(target.channelId);
      if (!key) throw new Error("unknown channel");
      return key;
    }
  }
}

/**
 * Seal + gift-wrap a rumor for a plane, purely from the key state + a signer.
 * A rumor that carries a valid `ms` tag keeps the `created_at` stamped together
 * with it (the single bind-time clock read of `includeMs`/`bindToChannel`, the
 * guestbook factories and the snapshot chunk operation), so
 * `created_at * 1000 + ms` stays the true send time (CORD-02 §4); any other
 * rumor (Control editions, dissolution, genesis Control rumors) is stamped at
 * wrap time. A durable Chat message's signed expiration is recomputed from the
 * kept `created_at` plus the timer, and the wrap is refused with a
 * {@link MessageAlreadyExpiredError} when that moment has already passed: before
 * any signing, and again after the last signer call, so a slow signer never
 * yields an already-expired wrap; either way nothing is returned to send
 * (CORD-08 §2). Returns the kind-1059 wrap, the inner rumor id, and
 * `key` — the exact {@link GroupKey} that finalized `wrap` (`wrap.pubkey ===
 * key.pk`). A caller that must be able to NIP-42-authenticate the wrap's
 * author registers this returned value rather than re-resolving the target
 * through {@link planeKeyFor} a second time — a second resolution after an
 * `await` can race a concurrent key change (see `ConcordCommunity.publishToPlane`).
 */
export async function wrapForTarget(
  keys: ConcordKeys,
  target: WrapTarget,
  author: ISigner,
  rumor: RumorTemplate,
  opts: {
    plaintext?: boolean;
    ephemeral?: boolean;
    ephemeralSk?: Uint8Array;
    assertCurrent?: () => void;
    messageExpiration?: number;
  } = {},
): Promise<{ wrap: NostrEvent; rumorId: string; key: GroupKey }> {
  // CORD-02 §5/§9: plane policy is fixed; generic CORD-01 builders remain flexible.
  const plaintext = target.plane === "control" || target.plane === "dissolved";
  if (opts.plaintext !== undefined && opts.plaintext !== plaintext) {
    throw new Error(`invalid seal type for ${target.plane} plane`);
  }
  const key = planeKeyFor(keys, target);
  // CORD-02 §4: keep the bind-time created_at only when it was stamped together with a valid
  // `ms` tag (one clock read), so created_at * 1000 + ms is the true send time; any other
  // rumor is stamped at wrap time. Build the rumor first so we can return its id, then seal +
  // wrap it onto the plane.
  const { created_at: boundAt, ...template } = rumor;
  const msTag = template.tags.find((tag) => tag[0] === "ms")?.[1];
  const keepBound = boundAt !== undefined && Number.isSafeInteger(boundAt) && parseMs(msTag) !== null;
  const draft = { ...template, created_at: keepBound ? boundAt : unixNow() };
  const ready = target.plane === "channel"
    ? stampMessageExpiration(draft, opts.messageExpiration, opts.ephemeral)
    : draft;
  // CORD-08 §2: a kept created_at can leave the timer already run out; never sign or send that.
  const expiration = target.plane === "channel" ? rumorExpiration(ready) : undefined;
  if (expiration !== undefined && expiration <= Date.now() / 1000) throw new MessageAlreadyExpiredError(expiration);
  const stamped = await toRumor(author)(ready);
  opts.assertCurrent?.();
  const seal = await sealRumor(key.convKey, author, { plaintext })(stamped);
  opts.assertCurrent?.();
  const wrap = await wrapSeal(key.sk, key.convKey, {
    ephemeral: opts.ephemeral,
    ephemeralSk: opts.ephemeralSk,
    expiration: target.plane === "channel" ? rumorExpiration(stamped) : undefined,
  })(seal);
  opts.assertCurrent?.();
  // CORD-08 §2: signer I/O may have outlived the timer; never hand back an already-expired wrap to publish.
  if (expiration !== undefined && expiration <= Date.now() / 1000) throw new MessageAlreadyExpiredError(expiration);
  return { wrap, rumorId: stamped.id, key };
}

/**
 * Mint a fresh private-channel key and return a new key state with it appended
 * to `material.channels` (immutably — the input is unchanged). The channel's
 * stream key only surfaces once its CHANNEL edition folds, since the derived
 * addresses come from the folded channel set; this only records the secret so it
 * can be persisted and shared in invites.
 */
export function addChannelKey(keys: ConcordKeys, channelId: string, name: string): ConcordKeys {
  const key = bytesToHex(generateSecretKey());
  const material: JoinMaterial = {
    ...keys.material,
    channels: [...keys.material.channels, { id: channelId, key, epoch: 1, name }],
  };
  return { ...keys, material };
}

/**
 * Roll the key state forward to a new community_root/epoch: keep the prior root
 * in `held_roots` so past history stays decodable, then re-derive every address
 * while retaining the prior planes (so already-fetched wraps still decode).
 * An explicit target descriptor supplies split control capabilities; omission
 * selects a historical legacy target, never inherited split fields (CORD-06 §1–3).
 */
export function rollForward(
  keys: ConcordKeys,
  newRoot: Uint8Array,
  newEpoch: number,
  refounder: string,
  channels: ChannelMetadata[],
  control?: { control_pk: string; control_root?: string },
): ConcordKeys {
  const priorRoots = Array.isArray(keys.material.held_roots) ? keys.material.held_roots : [];
  const { control_pk: _priorPk, control_root: _priorRoot, ...priorMaterial } = keys.material;
  const material: JoinMaterial = {
    ...priorMaterial,
    ...(control
      ? {
        control_pk: control.control_pk,
        ...(control.control_root !== undefined ? { control_root: control.control_root } : {}),
      }
      : {}),
    community_root: bytesToHex(newRoot),
    root_epoch: newEpoch,
    prev_root: keys.material.community_root,
    refounder,
    held_roots: [
      // ROTATE-12: attribute the now-historical OLD epoch to the refounder that
      // actually minted it (keys.material.refounder), not the new tip — buildChain
      // reads this per-epoch field instead of inheriting the tip's refounder. The
      // key is omitted (not set to `undefined`) when there is none, mirroring how
      // every other optional JoinMaterial field behaves — an explicit `undefined`
      // property changes the object's shape (Object.keys) even though its JSON
      // form is identical, which defeats value-based model-cache keys downstream.
      {
        epoch: keys.material.root_epoch,
        key: keys.material.community_root,
        ...(keys.material.prev_root !== undefined ? { prev_root: keys.material.prev_root } : {}),
        ...(keys.material.refounder !== undefined ? { refounder: keys.material.refounder } : {}),
        ...(keys.material.control_pk !== undefined ? { control_pk: keys.material.control_pk } : {}),
        ...(keys.material.control_root !== undefined ? { control_root: keys.material.control_root } : {}),
      },
      ...priorRoots,
    ],
  };
  return deriveConcordKeys(material, channels, keys);
}

/** The wraps a Refounding must publish, plus the rolled-forward key state. */
export interface RefoundingPlan {
  /** Per-recipient rekey blobs at the base-rekey address — publish (await) first. */
  rekeyWraps: NostrEvent[];
  /** Channel-scoped rekey blobs for the bundled private channels (CORD-06 §3),
   *  sealed under the PRIOR root — publish (await) alongside `rekeyWraps`. Empty
   *  unless `channelRekeys` was passed. */
  channelRekeyWraps: NostrEvent[];
  /** Mandatory original signed control heads re-wrapped into the new epoch; publish only after root confirmation. */
  compactionWraps: NostrEvent[];
  /** New-guestbook snapshot rumors (best-effort, non-gating). */
  snapshotWraps: NostrEvent[];
  /** Complete paired key state to persist and adopt after common mandatory-artifact confirmation. */
  next: ConcordKeys;
  /** The epoch `next` is rolled forward to (the prior `root_epoch` plus one). */
  newEpoch: number;
  /** The base-rekey address every entry in `rekeyWraps` was finalized under
   *  (`baseRekeyGroupKey(oldRoot, cidBytes, newEpoch)`). A caller that must
   *  NIP-42-authenticate the root-roll wraps MUST register this value, not
   *  recompute the address from `this.material.community_root` after an await —
   *  a concurrent `adoptRefounding()` can roll `material` forward mid-flight and
   *  desync a recomputed address from what the wraps actually carry (WR-01). */
  rekeyKey: GroupKey;
  /** One `GroupKey` per bundled channel rekey in `opts.channelRekeys`, in the same
   *  order, each the address that channel's own `channelRekeyWraps` entries were
   *  finalized under. Same registration hazard as `rekeyKey`, per-channel. */
  channelRekeyKeys: GroupKey[];
}

/**
 * Build a Refounding (CORD-06 §3): mint a new community_root, deliver it to
 * `recipients` as per-recipient rekey blobs at the base-rekey address (under the
 * PRIOR root), compact the Control Plane by re-wrapping each head's plaintext
 * seal into the new epoch, and seed the new Guestbook with a snapshot. Pure over
 * `(keys, signer)`; the caller publishes the returned wraps and adopts `next`.
 * Requires held current control signing capability, verified current authority
 * and a NIP-44 signer. Every kept member receives the 104-byte split read form;
 * only {@link isCurrentStaff} recipients receive the 136-byte staff form.
 * This prepares signed artifacts without publishing or persisting them. A
 * standalone caller must maintain current authority through `assertCurrent`,
 * confirm root delivery before compaction, and persist complete material before
 * exposure. Historical 72-byte base operations are read/resume inputs only.
 */
export async function buildRefounding(
  keys: ConcordKeys,
  signer: ISigner,
  opts: {
    /** Verified current fold used for actor authority and recipient staff classification. */
    state: CommunityState;
    /** The npubs that keep access (must include `self`). */
    recipients: string[];
    /** The rotator (our) hex pubkey. */
    self: string;
    /** The Control-Plane winning heads, for compaction. */
    heads: Iterable<DecodedEvent>;
    /** The current folded channels, for re-deriving the rolled key state. */
    channels: ChannelMetadata[];
    /** Private channels to ALSO rekey (CORD-06 §3), each to its own recipients —
     *  sealed under the prior root so the blob is openable on either base fork. */
    channelRekeys?: Array<{ channel: ChannelKey; recipients: string[] }>;
    /** Injectable new root (tests); defaults to a fresh random key. */
    newRoot?: Uint8Array;
    /** Independent fresh control root, injectable for deterministic tests. */
    newControlRoot?: Uint8Array;
    /** Throws if captured actor, authority, material or recipient support changed; called around signer awaits. */
    assertCurrent?: () => void;
    /** The rotator's own Grant citation (CORD-04 `vac`, D-08) — omitted for the
     *  owner. Rides both the root-roll rumors and any bundled channel rekeys
     *  (same rotator, same citation). */
    vac?: [string, string, string];
  },
): Promise<RefoundingPlan> {
  assertBaseRotationSupported(keys.material);
  if (!signer.nip44) throw new Error("this signer can't rotate keys (NIP-44 unsupported)");
  const { material } = keys;
  const coordinate = (
    value: JoinMaterial,
  ) => [value.community_id, value.owner, value.community_root, value.root_epoch, value.control_pk, value.control_root];
  if (JSON.stringify(coordinate(opts.state.material)) !== JSON.stringify(coordinate(material))) {
    throw new Error("refounding state does not match current material");
  }
  if (!refoundAuthority(opts.state)(opts.self) || !vacVerifier(opts.state, PERM.BAN)(opts.self, opts.vac)) {
    throw new Error("missing current verified refounding authority");
  }
  if (
    opts.channelRekeys?.length && (!refoundAuthority(opts.state, PERM.MANAGE_CHANNELS)(opts.self) ||
      !vacVerifier(opts.state, PERM.MANAGE_CHANNELS)(opts.self, opts.vac))
  ) {
    throw new Error("missing current verified bundled channel authority");
  }
  const recipients = [...new Set(opts.recipients)];
  if (!recipients.includes(opts.self)) throw new Error("refounding recipients must include self");
  signer = guardedSigner(signer, opts.self, opts.assertCurrent);
  if (await signer.getPublicKey() !== opts.self) throw new Error("refounding signer does not match actor");
  const oldRoot = hexToBytes(material.community_root);
  const oldEpoch = material.root_epoch;
  const newEpoch = nextEpochFor(oldEpoch);
  const cidBytes = hexToBytes(material.community_id);
  const newRoot = opts.newRoot ?? generateSecretKey();
  const newControlRoot = opts.newControlRoot ?? generateSecretKey();
  if (bytesToHex(newRoot) === bytesToHex(newControlRoot)) throw new Error("refounding roots must be independent");
  const newSigner = controlSignerGroupKey(newControlRoot, cidBytes, newEpoch);
  const prevCommit = bytesToHex(epochKeyCommitment(oldEpoch, oldRoot));

  // 1. The root roll: per-recipient rekey blobs at the base-rekey address (keyed
  //    by the PRIOR root, so every current holder converges).
  const blobs = [];
  for (const pk of recipients) {
    // CORD-06 §1/§3; CORD-04 §3: keep membership never conveys staff capability.
    const plain = bytesToBase64(
      encodeBaseWrappedKey(
        BigInt(newEpoch),
        newRoot,
        hexToBytes(newSigner.pk),
        isCurrentStaff(opts.state, pk) ? newControlRoot : undefined,
      ),
    );
    const wrapped = await signer.nip44!.encrypt(pk, plain);
    blobs.push({ locator: rekeyLocator(opts.self, pk, ROOT_SCOPE_HEX, BigInt(newEpoch)), wrapped });
  }
  const rekeyAddr = baseRekeyGroupKey(oldRoot, cidBytes, newEpoch);
  const rekeyWraps: NostrEvent[] = [];
  for (
    const rumor of buildRekeyRumors(
      { scope: { kind: "root" }, newEpoch: BigInt(newEpoch), prevEpoch: BigInt(oldEpoch), prevCommit, vac: opts.vac },
      blobs,
    )
  ) {
    const wrap = await giftWrap(rekeyAddr.sk, rekeyAddr.convKey, signer)(await rumor);
    rekeyWraps.push(wrap);
  }

  // 1b. Channel rekeys (CORD-06 §3): rotate each named Private Channel, delivering
  //     its new key only to that channel's kept members. Sealed under the PRIOR
  //     root (buildChannelRekey's default) so the blob stays openable on either
  //     base fork under a racing Refounding. The rolled channel keys are NOT baked
  //     into `next` — each channel's sub-engine reads its own rekey and persists.
  const channelRekeyWraps: NostrEvent[] = [];
  const channelRekeyKeys: GroupKey[] = [];
  for (const { channel, recipients } of opts.channelRekeys ?? []) {
    const cr = await buildChannelRekey(material, channel, signer, {
      recipients,
      self: opts.self,
      vac: opts.vac,
      assertCurrent: opts.assertCurrent,
    });
    channelRekeyWraps.push(...cr.rekeyWraps);
    channelRekeyKeys.push(cr.rekeyKey);
  }

  // 2. Compaction: re-wrap each Control-Plane head's plaintext seal into the new
  //    epoch so members read current state without re-syncing from genesis.
  const next = rollForward(keys, newRoot, newEpoch, opts.self, opts.channels, {
    control_pk: newSigner.pk,
    control_root: bytesToHex(newControlRoot),
  });
  const newControl = next.control;
  const compactionWraps: NostrEvent[] = [];
  for (const head of opts.heads) {
    // CORD-06 §3: "If the Refounder cannot reliably fold all Control events, the
    // Refounding must be aborted." A non-plaintext or un-rewrappable head can't be
    // safely compacted into the new epoch — abort (throw) BEFORE any wraps are
    // returned, rather than silently skipping it and shipping a partial
    // compactionWraps set. buildRefounding is awaited before refound() publishes
    // anything, so this throw aborts the whole Refounding atomically.
    if (!head.seal || head.sealKind !== PLAINTEXT_SEAL_KIND || !verifyWrappedEvent(structuredClone(head.seal))) {
      throw new Error("refounding aborted: control head cannot be folded into the new epoch");
    }
    try {
      opts.assertCurrent?.();
      compactionWraps.push(rewrapSeal(head.seal, newSigner.sk, newControl.convKey));
    } catch {
      throw new Error("refounding aborted: control head cannot be folded into the new epoch");
    }
  }

  // 3. Guestbook snapshot (best-effort, non-gating — CORD-02 §5).
  const newGuestbook = guestbookGroupKey(newRoot, cidBytes, newEpoch);
  const snapshotWraps: NostrEvent[] = [];
  for (const factory of buildSnapshotFactories(recipients, bytesToHex(generateSecretKey()))) {
    const wrap = await giftWrap(newGuestbook.sk, newGuestbook.convKey, signer)(await factory);
    snapshotWraps.push(wrap);
  }

  opts.assertCurrent?.();
  return {
    rekeyWraps,
    channelRekeyWraps,
    compactionWraps,
    snapshotWraps,
    next,
    newEpoch,
    rekeyKey: rekeyAddr,
    channelRekeyKeys,
  };
}

/** The outcome of folding the rekey blobs at the next-epoch base-rekey address. */
export type RekeyOutcome =
  | { kind: "adopt"; next: ConcordKeys; rotator: string; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | { kind: "removed"; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | {
    kind: "none";
    diagnostics?: RekeyCandidateDiagnostic[];
    /** Prior material plus validated parked evidence; current capabilities are unchanged. */
    retainedMaterial?: JoinMaterial;
  };

/** Why one rekey candidate was parked or rejected. Bounded and value-free, so a
 *  client can surface or log it without leaking key material. */
export type RekeyDiagnosticReason =
  | "malformed"
  | "incomplete"
  | "inconsistent"
  | "continuity-gap"
  | "continuity-fork"
  | "citation-missing"
  | "citation-mismatch"
  | "unauthorized"
  | "owner-citation"
  | "paired-control-conflict"
  | "decrypt-failed";

/** One non-adopted rekey candidate, explained. Rotation reads are total — an
 *  unusable candidate is reported here rather than thrown. */
export interface RekeyCandidateDiagnostic {
  /** The candidate rotation's stable id, or the wrap id when the chunk never
   *  parsed into one. */
  candidateId: string;
  /** `parked` may still resolve once more events arrive; `rejected` is final. */
  status: "parked" | "rejected";
  /** Which check the candidate failed. */
  reason: RekeyDiagnosticReason;
  /** Compatibility field for caller-authored diagnostics. Readers omit thrown
   * values so decrypted material and signer error text cannot reach logs. */
  cause?: unknown;
}

/**
 * Select parsed root-scope candidates for the material's next epoch (CORD-06 §2).
 * Empty, malformed, channel-scoped and archived evidence cannot dispatch a base
 * transition. This checks scope/epoch only; {@link readRekey} still checks authority
 * and continuity before adopting a complete delivered capability record.
 */
export function currentBaseRekeys(material: JoinMaterial, events: Iterable<DecodedEvent>): DecodedEvent[] {
  const nextEpoch = BigInt(material.root_epoch) + 1n;
  return [...events].filter((event) => {
    const parsed = parseRekeyResult(event);
    return parsed.kind === "parsed" && parsed.value.scopeIdHex === ROOT_SCOPE_HEX &&
      parsed.value.newEpoch === nextEpoch;
  });
}

/**
 * Fold the rekey blobs at the next-epoch base-rekey address (CORD-06 §2/§3): a
 * complete, AUTHORIZED, continuity-checked root rotation carrying our blob means
 * adopt the complete root/control pair (races converge on the lowest read root); a complete
 * rotation with NO blob for us means we've been removed. Authority is the roster
 * (`isAuthorized`), never key possession. Pure over `(keys, signer)`; the caller
 * decides what to do with the outcome. Requires a NIP-44 signer. Optional
 * `heldNext` protects an already-held next-epoch pair at this predecessor.
 * Conflicting lowest-root control pairs park with retained evidence under the
 * defensive D-13 policy; a strictly lower unambiguous pair may still win. This
 * does not define a control-key comparator beyond CORD-06 §3's base ordering.
 */
export async function readRekey(
  keys: ConcordKeys,
  rekeyEvents: Iterable<DecodedEvent>,
  isAuthorized: (rotator: string) => boolean,
  self: string,
  signer: ISigner,
  channels: ChannelMetadata[],
  canRemoveSelf?: (rotator: string) => boolean,
  verifyVac?: (
    rotator: string,
    vac: [string, string, string] | undefined,
  ) => boolean | RotationAuthorityOutcome,
  /** Already-held next epoch, anchored to this community/owner proof and predecessor. */
  heldNext?: JoinMaterial,
): Promise<RekeyOutcome> {
  if (!signer.nip44) return { kind: "none" };
  const retained: ValidatedRekeyCandidate[] = [];
  const sameIdentity = (material: JoinMaterial): boolean =>
    material.community_id === keys.material.community_id && material.owner === keys.material.owner &&
    material.owner_salt === keys.material.owner_salt && material.root_epoch === keys.material.root_epoch + 1 &&
    (material.prev_root === undefined || material.prev_root === keys.material.community_root);
  const entries: HeldRootEntry[] = [
    ...(keys.material.held_roots ?? []),
    ...(heldNext && sameIdentity(heldNext)
      ? [{
        epoch: heldNext.root_epoch,
        key: heldNext.community_root,
        prev_root: keys.material.community_root,
        refounder: heldNext.refounder,
        ...(heldNext.control_pk !== undefined ? { control_pk: heldNext.control_pk } : {}),
        ...(heldNext.control_root !== undefined ? { control_root: heldNext.control_root } : {}),
      }]
      : []),
  ];
  for (const entry of entries) {
    if (entry.epoch !== keys.material.root_epoch + 1 || entry.prev_root !== keys.material.community_root) continue;
    try {
      // Saved read capability supplies no authority: recheck the exact citation
      // and current shared predicate before considering retained evidence.
      const root = hexToBytes(entry.key);
      if (root.length !== 32 || (entry.candidate_id !== undefined && !entry.refounder)) continue;
      // A held anchor protects its coordinate even on older saved records
      // without attribution; this comparison actor never creates authority.
      const actor = entry.refounder ?? keys.material.owner;
      const authority = verifyVac?.(actor, entry.vac);
      if (
        entry.candidate_id !== undefined && (!isAuthorized(actor) || authority === false ||
          (authority !== undefined && authority !== true && authority.kind !== "eligible"))
      ) continue;
      const bytes = new Uint8Array(entry.control_pk ? entry.control_root ? 136 : 104 : 72);
      new DataView(bytes.buffer).setBigUint64(32, BigInt(entry.epoch), false);
      bytes.set(root, 40);
      if (entry.control_pk) {
        const pk = hexToBytes(entry.control_pk);
        if (pk.length !== 32) continue;
        bytes.set(pk, 72);
      }
      if (entry.control_root) {
        const secret = hexToBytes(entry.control_root);
        if (secret.length !== 32 || !entry.control_pk) continue;
        bytes.set(secret, 104);
      }
      retained.push({
        key: root,
        base: decodeBaseWrappedKey(bytes, BigInt(entry.epoch), hexToBytes(keys.material.community_id)),
        rotator: actor,
        candidateId: entry.candidate_id ?? "held",
        ...(entry.vac ? { vac: entry.vac } : {}),
      });
    } catch { /* Invalid restored coordinates do not affect current material. */ }
  }
  const scoped = await readRekeyScoped(
    {
      scopeIdHex: ROOT_SCOPE_HEX,
      scopeId: new Uint8Array(32),
      heldEpoch: keys.material.root_epoch,
      heldKey: hexToBytes(keys.material.community_root),
      communityId: hexToBytes(keys.material.community_id),
      retained,
      canRemoveSelf,
      verifyVac,
    },
    rekeyEvents,
    isAuthorized,
    self,
    signer,
  );
  const complete = new Map<string, ValidatedRekeyCandidate>();
  for (const candidate of scoped.kind === "removed" ? [] : scoped.candidates ?? []) {
    const id = JSON.stringify([
      candidate.candidateId,
      bytesToHex(candidate.key),
      candidate.base?.control_pk ? bytesToHex(candidate.base.control_pk) : undefined,
    ]);
    const old = complete.get(id);
    complete.set(id, old?.base?.control_root ? old : candidate);
  }
  const evidence = [...complete.values()]
    .filter((candidate) => candidate.candidateId !== "held").map((candidate): HeldRootEntry => ({
      epoch: keys.material.root_epoch + 1,
      key: bytesToHex(candidate.key),
      refounder: candidate.rotator,
      prev_root: keys.material.community_root,
      candidate_id: candidate.candidateId,
      ...(candidate.vac ? { vac: candidate.vac } : {}),
      ...(candidate.base!.control_pk ? { control_pk: bytesToHex(candidate.base!.control_pk) } : {}),
      ...(candidate.base!.control_root ? { control_root: bytesToHex(candidate.base!.control_root) } : {}),
    }));
  const withEvidence = (records: HeldRootEntry[]): ConcordKeys => ({
    ...keys,
    material: {
      ...keys.material,
      held_roots: [
        ...(keys.material.held_roots ?? []).filter((old) =>
          !records.some((entry) =>
            entry.candidate_id === old.candidate_id && entry.control_pk === old.control_pk && entry.key === old.key
          )
        ),
        ...records,
      ],
    },
  });
  if (scoped.kind === "adopt") {
    const losing = evidence.filter((candidate) =>
      candidate.key !== bytesToHex(scoped.newKey) ||
      candidate.control_pk !== (scoped.base?.control_pk ? bytesToHex(scoped.base.control_pk) : undefined)
    );
    let next = rollForward(
      withEvidence(losing),
      scoped.newKey,
      scoped.epoch,
      scoped.rotator,
      channels,
      scoped.base?.control_pk
        ? {
          control_pk: bytesToHex(scoped.base.control_pk),
          ...(scoped.base.control_root ? { control_root: bytesToHex(scoped.base.control_root) } : {}),
        }
        : undefined,
    );
    if (
      heldNext && sameIdentity(heldNext) && heldNext.community_root === next.material.community_root &&
      heldNext.control_pk === next.material.control_pk
    ) {
      // Matching enrichment preserves the held epoch's original attribution,
      // including absence on pre-field history, rather than inventing a minter.
      const { refounder: _selectedActor, ...material } = next.material;
      next = deriveConcordKeys(
        { ...material, ...(heldNext.refounder !== undefined ? { refounder: heldNext.refounder } : {}) },
        channels,
        keys,
      );
    }
    return {
      kind: "adopt",
      next,
      rotator: scoped.rotator,
      epoch: scoped.epoch,
      ...(scoped.diagnostics ? { diagnostics: scoped.diagnostics } : {}),
    };
  }
  if (scoped.kind === "removed") {
    return { kind: "removed", epoch: scoped.epoch, ...(scoped.diagnostics ? { diagnostics: scoped.diagnostics } : {}) };
  }
  return {
    kind: "none",
    ...(evidence.length ? { retainedMaterial: withEvidence(evidence).material } : {}),
    ...(scoped.diagnostics ? { diagnostics: scoped.diagnostics } : {}),
  };
}

//
// A Private Channel is a sub-community: independently keyed (unrelated to the
// community_root, CORD-03) at its OWN epoch, so it can be rekeyed alone. The
// scope-generic wire codec + convergence machinery (rekey.ts) are shared with
// the root Refounding via `readRekeyScoped`; only the held key/epoch and the
// listen address differ.

/** The held key + scope a rekey read is evaluated against. */
interface ScopedHeld {
  /** Complete base candidates revalidated by the base reader. */
  retained?: ValidatedRekeyCandidate[];
  /** Lowercased 32-byte scope id hex: `ROOT_SCOPE_HEX` or the channel id. */
  scopeIdHex: string;
  /** The scope id bytes (zeros for root, channel id for a channel). */
  scopeId: Uint8Array;
  /** The epoch of the key we currently hold for this scope. */
  heldEpoch: number;
  /** The key we currently hold for this scope. */
  heldKey: Uint8Array;
  /** Present only for base-form validation (CORD-06 §1; CORD-02 §5). */
  communityId?: Uint8Array;
  /**
   * Whether `rotator` is authorized to remove US specifically (CORD-04: holds the
   * bit AND strictly outranks us). Gates ONLY the `removed` outcome, never
   * adoption — so a lower-ranked manager can't sever a higher-ranked member by
   * rotating them out, but legitimate convergence among peers is unaffected.
   * REQUIRED to honor a removal: CORD-06 §3 requires the outrank check "in both"
   * the root and channel paths, so an omitted predicate fails closed — a removal
   * is denied, not permitted, when this is absent.
   */
  canRemoveSelf?: (rotator: string) => boolean;
  /**
   * vac verification against the folded Roster (CORD-04 D-08/D-12) — the
   * receive-side sibling of `canRemoveSelf`, gating whether a rotator is
   * honored AT ALL (both adopt and removed), independent of the `isAuthorized`
   * roster-bit check already applied above. Built by {@link vacVerifier}. When
   * ABSENT, no vac gating happens (opt-in, unlike `canRemoveSelf`'s
   * fail-closed-on-absence) — every real call site supplies one; tests may omit
   * it.
   */
  verifyVac?: (
    rotator: string,
    vac: [string, string, string] | undefined,
  ) => boolean | RotationAuthorityOutcome;
}

type ScopedRekeyOutcome =
  | {
    kind: "adopt";
    newKey: Uint8Array;
    base?: BaseRekeyMaterial;
    rotator: string;
    epoch: number;
    diagnostics?: RekeyCandidateDiagnostic[];
    candidates?: ValidatedRekeyCandidate[];
  }
  | { kind: "removed"; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | { kind: "none"; diagnostics?: RekeyCandidateDiagnostic[]; candidates?: ValidatedRekeyCandidate[] };

interface ValidatedRekeyCandidate {
  key: Uint8Array;
  base?: BaseRekeyMaterial;
  rotator: string;
  candidateId: string;
  vac?: [string, string, string];
}

/**
 * Resolve authorized, complete, continuous next-epoch rotations (CORD-06 §2/§3).
 * The lowest decryptable key wins only when no opaque competitor prevents ranking.
 * A decrypt failure is keep-evidence: defer, never infer removal. With no
 * decryptable candidates, genuine no-blob exclusion requires `canRemoveSelf`.
 * Requires `signer.nip44`.
 */
async function readRekeyScoped(
  held: ScopedHeld,
  rekeyEvents: Iterable<DecodedEvent>,
  isAuthorized: (rotator: string) => boolean,
  self: string,
  signer: ISigner,
): Promise<ScopedRekeyOutcome> {
  const heldEpoch = BigInt(held.heldEpoch);
  const diagnostics: RekeyCandidateDiagnostic[] = [];
  const parsed = [...rekeyEvents].flatMap((event) => {
    const result = parseRekeyResult(event);
    if (result.kind === "parsed") {
      return result.value.scopeIdHex === held.scopeIdHex && result.value.newEpoch === heldEpoch + 1n
        ? [result.value]
        : [];
    }
    diagnostics.push({ candidateId: event.wrapId, status: "rejected", reason: "malformed" });
    return [];
  });
  const rotations = [];
  for (const set of groupRotations(parsed)) {
    if (!isAuthorized(set.rotator)) {
      diagnostics.push({ candidateId: set.candidateId, status: "rejected", reason: "unauthorized" });
      continue;
    }
    if (!set.consistent) {
      diagnostics.push({ candidateId: set.candidateId, status: "parked", reason: "inconsistent" });
      continue;
    }
    if (!set.complete) {
      diagnostics.push({ candidateId: set.candidateId, status: "parked", reason: "incomplete" });
      continue;
    }
    const continuity = checkContinuity(set, heldEpoch, held.heldKey);
    if (!continuity.ok) {
      diagnostics.push({
        candidateId: set.candidateId,
        status: continuity.reason === "gap" ? "parked" : "rejected",
        reason: continuity.reason === "gap" ? "continuity-gap" : "continuity-fork",
      });
      continue;
    }
    const authority = held.verifyVac?.(set.rotator, set.vac);
    if (authority === false) {
      diagnostics.push({ candidateId: set.candidateId, status: "rejected", reason: "unauthorized" });
      continue;
    }
    if (authority !== undefined && authority !== true && authority.kind !== "eligible") {
      let reason: RekeyDiagnosticReason;
      if (authority.kind === "unauthorized") reason = "unauthorized";
      else if (authority.kind === "malformed") reason = "owner-citation";
      else if (authority.kind === "rejected") reason = authority.reason;
      else reason = authority.citation.kind === "missing" ? "citation-missing" : "citation-mismatch";
      diagnostics.push({
        candidateId: set.candidateId,
        status: authority.kind === "parked" ? "parked" : "rejected",
        reason,
      });
      continue;
    }
    rotations.push(set);
  }
  const withDiagnostics = <T extends object>(outcome: T): T & { diagnostics?: RekeyCandidateDiagnostic[] } => {
    const unique = [
      ...new Map(
        diagnostics.map((
          diagnostic,
        ) => [JSON.stringify([diagnostic.candidateId, diagnostic.status, diagnostic.reason]), diagnostic]),
      ).values(),
    ].slice(0, 128);
    return unique.length ? { ...outcome, diagnostics: unique } : outcome;
  };
  if (rotations.length === 0 && !held.retained?.length) return withDiagnostics({ kind: "none" as const });

  const targetEpoch = held.heldEpoch + 1;
  const decryptable: ValidatedRekeyCandidate[] = [...(held.retained ?? [])];
  const noBlobRotators: string[] = []; // genuinely excluded from these sets — removal candidates
  let opaqueCompetitor = false; // no-blob OR decrypt-threw set: cannot be ranked
  let decryptThrew = false; // a blob at OUR locator decrypted-threw: positive keep-evidence, defer removal (D-06)

  for (const set of rotations) {
    if (!set.complete) continue;
    const blob = findBlob(set, rekeyLocator(set.rotator, self, held.scopeIdHex, set.newEpoch));
    if (!blob) {
      // No blob for us anywhere in this complete authorized+continuity set: a
      // competing fork we cannot rank, and — if it turns out to be the only
      // kind of set in play — the classic removal case.
      opaqueCompetitor = true;
      noBlobRotators.push(set.rotator);
      continue;
    }
    let plain: string;
    try {
      plain = await signer.nip44!.decrypt(set.rotator, blob.wrapped);
    } catch {
      // A signer rejection is opaque keep-evidence, never absence (CORD-06 §2).
      opaqueCompetitor = true;
      decryptThrew = true;
      diagnostics.push({ candidateId: set.candidateId, status: "parked", reason: "decrypt-failed" });
      continue;
    }
    try {
      const bytes = base64ToBytes(plain);
      if (bytesToBase64(bytes) !== plain) throw new Error("noncanonical wrapped key encoding");
      const base = held.communityId ? decodeBaseWrappedKey(bytes, set.newEpoch, held.communityId) : undefined;
      const newKey = base ? base.community_root : decodeWrappedKey(bytes, held.scopeId, set.newEpoch);
      decryptable.push({
        key: newKey,
        ...(base ? { base } : {}),
        rotator: set.rotator,
        candidateId: set.candidateId,
        ...(set.vac ? { vac: set.vac } : {}),
      });
    } catch {
      // Successfully opened but invalid plaintext is deterministic rejection
      // (CORD-06 §1). It supplies neither an opaque competitor nor removal.
      diagnostics.push({ candidateId: set.candidateId, status: "rejected", reason: "malformed" });
    }
  }

  if (decryptable.length > 0) {
    let winner = decryptable[0];
    for (const candidate of decryptable.slice(1)) {
      if (lowerKeyWins(winner.key, candidate.key) === candidate.key) winner = candidate;
    }
    if (held.communityId) {
      const lowest = decryptable.filter((candidate) => bytesToHex(candidate.key) === bytesToHex(winner.key));
      const controlPk = (candidate: ValidatedRekeyCandidate): string =>
        candidate.base!.control_pk
          ? bytesToHex(candidate.base!.control_pk)
          : controlGroupKey(candidate.key, held.communityId!, targetEpoch).pk;
      // CORD-06 §3 orders read roots; accepted 04-CONTEXT D-13 parks
      // an ambiguous lowest class. There is no control-key comparator.
      if (new Set(lowest.map(controlPk)).size > 1) {
        for (const candidate of lowest) {
          diagnostics.push({ candidateId: candidate.candidateId, status: "parked", reason: "paired-control-conflict" });
        }
        return withDiagnostics({ kind: "none" as const, candidates: decryptable });
      }
      // A validated full record enriches only its exact matching coordinate.
      winner = lowest.find((candidate) => candidate.base!.control_root !== undefined) ?? lowest[0];
    }
    // D-10: an opaque competing fork means we cannot prove our decryptable
    // winner is the true global-lowest — defer rather than adopt a candidate
    // that might not be the winner.
    if (opaqueCompetitor) return withDiagnostics({ kind: "none" as const, candidates: decryptable });
    return withDiagnostics({
      kind: "adopt" as const,
      newKey: winner.key,
      ...(winner.base ? { base: winner.base } : {}),
      rotator: winner.rotator,
      epoch: targetEpoch,
      candidates: decryptable,
    });
  }

  // No decryptable candidate at all. A decrypt-throw at our own locator is
  // positive evidence we WERE a recipient somewhere (D-06), undetermined but
  // never absence — so defer even when a competing no-blob removal set also
  // exists: transient keep-evidence outranks an unproven removal, and the
  // down-only re-read spine revisits this epoch once the signer recovers.
  if (decryptThrew) return withDiagnostics({ kind: "none" as const });
  // Only a genuine no-blob set can honor removal, and only from a rotator
  // authorized to remove US (CORD-04). An absent/false predicate denies the
  // removal (fail-closed): we keep our current key either way.
  for (const rotator of noBlobRotators) {
    if (held.canRemoveSelf?.(rotator) === true) {
      return withDiagnostics({ kind: "removed" as const, epoch: targetEpoch });
    }
  }
  return withDiagnostics({ kind: "none" as const });
}

/** The outcome of folding a channel's rekey blobs at its next-epoch address. */
export type ChannelRekeyOutcome =
  | { kind: "adopt"; next: ChannelKey; rotator: string; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | { kind: "removed"; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | { kind: "none"; diagnostics?: RekeyCandidateDiagnostic[] };

/**
 * Roll a single {@link ChannelKey} forward to a new key/epoch, retaining the
 * prior key in `held` (newest-first) so messages under prior channel epochs
 * still decode. Pure; the input is unchanged. Analog of {@link rollForward}.
 */
export function rollForwardChannel(channel: ChannelKey, newKey: string, newEpoch: number): ChannelKey {
  return {
    ...channel,
    key: newKey,
    epoch: newEpoch,
    held: [{ epoch: channel.epoch, key: channel.key }, ...(channel.held ?? [])],
  };
}

/** Every stream address a Private Channel holder listens on: its message plane at
 *  the current + held epochs, plus the next-epoch channel-rekey address(es). */
export interface ChannelKeys {
  /** The channel's 32-byte id, hex. */
  channelId: string;
  /** The channel's OWN current epoch, independent of the community root epoch —
   *  so a Refounding does not move it (CORD-03). */
  epoch: number;
  /** Current-epoch channel message-plane key. */
  current: GroupKey;
  /** Prior-epoch message-plane keys (held), so old messages still decode. */
  held: Array<{ epoch: number; key: GroupKey }>;
  /** The next channel-epoch's rekey listen address, derived once per community
   *  root we hold — the current root (a standalone Rekey) and each held root (a
   *  Refounding-bundled channel rekey is sealed under the PRIOR root, CORD-06 §3). */
  nextRekey: Array<{ key: GroupKey; epoch: number }>;
  /** Decrypt-side lookup: stream pubkey → plane info (message planes + rekey addresses). */
  planes: Map<string, PlaneInfo>;
}

/**
 * Derive every stream address a holder of `channel` listens on, given the
 * community `material` (for the root(s) the channel-rekey address keys on). The
 * message plane derives from the channel's OWN secret/epoch — independent of the
 * community root — so it is stable across Refoundings.
 */
export function deriveChannelKeys(material: JoinMaterial, channel: ChannelKey): ChannelKeys {
  const channelId = hexToBytes(channel.id);
  // Channel message keys depend only on `channel`; non-enumerable caches do not
  // survive rotation spreads. Root-dependent rekey addresses stay per-call.
  const { current, held } = getOrComputeCachedValue(channel, ChannelPlaneKeysSymbol, () => ({
    current: channelGroupKey(hexToBytes(channel.key), channelId, channel.epoch),
    held: (channel.held ?? []).map((h) => ({
      epoch: h.epoch,
      key: channelGroupKey(hexToBytes(h.key), channelId, h.epoch),
    })),
  }));

  const newEpoch = nextEpochFor(channel.epoch);
  const roots = [material.community_root, ...(material.held_roots ?? []).map((r) => r.key)];
  const seenRoot = new Set<string>();
  const nextRekey = roots
    .filter((r) => (seenRoot.has(r) ? false : (seenRoot.add(r), true)))
    .map((r) => ({ key: channelRekeyGroupKey(hexToBytes(r), channelId, newEpoch), epoch: newEpoch }));

  const planes = new Map<string, PlaneInfo>();
  planes.set(current.pk, { type: "channel", convKey: current.convKey, channelId: channel.id, epoch: channel.epoch });
  for (const h of held) {
    planes.set(h.key.pk, { type: "channel", convKey: h.key.convKey, channelId: channel.id, epoch: h.epoch });
  }
  for (const rk of nextRekey) {
    planes.set(rk.key.pk, { type: "rekey", convKey: rk.key.convKey, channelId: channel.id, epoch: newEpoch });
  }

  return { channelId: channel.id, epoch: channel.epoch, current, held, nextRekey, planes };
}

/**
 * Build a channel-scoped Rekey (CORD-06): mint a fresh channel key at the next
 * channel epoch and deliver it to `recipients` as per-recipient channel-scoped
 * blobs at the channel-rekey address. Sealed under `priorRoot` (default: the
 * current community_root — a standalone Rekey; a Refounding passes the prior root
 * so the blob is openable on either base fork, CORD-06 §3). No compaction: a
 * channel is just chat, so prior messages stay readable under the held key.
 * Returns the wraps + the rolled-forward channel key. Requires a NIP-44 signer.
 */
export async function buildChannelRekey(
  material: JoinMaterial,
  channel: ChannelKey,
  signer: ISigner,
  opts: {
    recipients: string[];
    self: string;
    newKey?: Uint8Array;
    priorRoot?: string;
    /** The rotator's own Grant citation (CORD-04 `vac`, D-08) — omitted for the owner. */
    vac?: [string, string, string];
    /** Throws when bundled or standalone preparation becomes stale. */
    assertCurrent?: () => void;
  },
): Promise<{ rekeyWraps: NostrEvent[]; next: ChannelKey; newEpoch: number; rekeyKey: GroupKey }> {
  if (!signer.nip44) throw new Error("this signer can't rotate keys (NIP-44 unsupported)");
  signer = guardedSigner(signer, opts.self, opts.assertCurrent);
  const channelId = hexToBytes(channel.id);
  const oldEpoch = channel.epoch;
  const newEpoch = nextEpochFor(oldEpoch);
  const newKey = opts.newKey ?? generateSecretKey();
  const prevCommit = bytesToHex(epochKeyCommitment(oldEpoch, hexToBytes(channel.key)));

  const plain = bytesToBase64(encodeWrappedKey(channelId, BigInt(newEpoch), newKey));
  const blobs = [];
  for (const pk of new Set(opts.recipients)) {
    const wrapped = await signer.nip44!.encrypt(pk, plain);
    blobs.push({ locator: rekeyLocator(opts.self, pk, channel.id, BigInt(newEpoch)), wrapped });
  }

  const rekeyAddr = channelRekeyGroupKey(hexToBytes(opts.priorRoot ?? material.community_root), channelId, newEpoch);
  const rekeyWraps: NostrEvent[] = [];
  for (
    const rumor of buildRekeyRumors(
      {
        scope: { kind: "channel", channelId },
        newEpoch: BigInt(newEpoch),
        prevEpoch: BigInt(oldEpoch),
        prevCommit,
        vac: opts.vac,
      },
      blobs,
    )
  ) {
    rekeyWraps.push(await giftWrap(rekeyAddr.sk, rekeyAddr.convKey, signer)(await rumor));
  }

  return {
    rekeyWraps,
    next: rollForwardChannel(channel, bytesToHex(newKey), newEpoch),
    newEpoch,
    // The exact address every wrap above was finalized under (`giftWrap(rekeyAddr.sk, ...)`).
    // A caller that must NIP-42-authenticate these wraps MUST register this value, not
    // recompute the address from `material` after this call — `material` (and therefore a
    // recomputed address) can roll forward mid-await if a concurrent Refounding is adopted,
    // desyncing the registration from what the wraps actually carry (WR-01).
    rekeyKey: rekeyAddr,
  };
}

/**
 * Fold a channel's rekey blobs (CORD-06): a complete, AUTHORIZED,
 * continuity-checked channel rotation carrying our blob means adopt the new
 * channel key; a complete rotation with no blob for us means we've been removed
 * from the channel. Authority is `MANAGE_CHANNELS` + outranking the targets (the
 * caller's predicate), never key possession. Requires a NIP-44 signer.
 */
export async function readChannelRekey(
  channel: ChannelKey,
  rekeyEvents: Iterable<DecodedEvent>,
  isAuthorized: (rotator: string) => boolean,
  self: string,
  signer: ISigner,
  canRemoveSelf?: (rotator: string) => boolean,
  verifyVac?: (
    rotator: string,
    vac: [string, string, string] | undefined,
  ) => boolean | RotationAuthorityOutcome,
): Promise<ChannelRekeyOutcome> {
  if (!signer.nip44) return { kind: "none" };
  const scoped = await readRekeyScoped(
    {
      scopeIdHex: channel.id.toLowerCase(),
      scopeId: hexToBytes(channel.id),
      heldEpoch: channel.epoch,
      heldKey: hexToBytes(channel.key),
      canRemoveSelf,
      verifyVac,
    },
    rekeyEvents,
    isAuthorized,
    self,
    signer,
  );
  if (scoped.kind === "adopt") {
    return {
      kind: "adopt",
      next: rollForwardChannel(channel, bytesToHex(scoped.newKey), scoped.epoch),
      rotator: scoped.rotator,
      epoch: scoped.epoch,
      ...(scoped.diagnostics ? { diagnostics: scoped.diagnostics } : {}),
    };
  }
  if (scoped.kind === "removed") {
    return { kind: "removed", epoch: scoped.epoch, ...(scoped.diagnostics ? { diagnostics: scoped.diagnostics } : {}) };
  }
  return { kind: "none", ...(scoped.diagnostics ? { diagnostics: scoped.diagnostics } : {}) };
}
