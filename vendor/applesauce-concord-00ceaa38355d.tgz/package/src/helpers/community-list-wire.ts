// CORD-02 §8: explicit wire boundary for addressable Community List fragments.
import { base64urlnopad } from "@scure/base";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import type { CommunityListCommunity, JoinMaterial } from "../types.ts";
import { isCommunityLive, parseCommunityList, type ParsedCommunityList } from "./community-list.ts";

/** Addressable Community List fragment kind (CORD-02 §8, Appendix B). */
export const COMMUNITY_LIST_FRAGMENT_KIND = 33302;
/** Retired Community List kind, accepted for migration reads only. */
export const LEGACY_COMMUNITY_LIST_KIND = 13302;

/** Membership snapshot on the wire; named keys use unpadded base64url. */
export interface CommunityListWireSnapshot {
  /** Present only for standalone snapshots. */
  community_id?: string;
  /** Owner public key. */
  owner: string;
  /** Owner identity salt. */
  owner_salt: string;
  /** Member read root. */
  community_root: string;
  /** Control stream address. */
  control_pk?: string;
  /** Held staff signing root. */
  control_root?: string;
  /** Root epoch. */
  root_epoch: number;
  /** Private channel key snapshots, including opaque extensions. */
  channels: Record<string, unknown>[];
  /** Relay URLs. */
  relays: string[];
  /** Display name. */
  name: string;
  /** Unknown fields retain their original JSON values. */
  [key: string]: unknown;
}
/** A decrypted wire fragment, before conversion to runtime hex keys. */
export interface CommunityListWireFragment {
  /** Total fragment count. */
  frags: number;
  /** Live memberships. */
  entries: {
    community_id: string;
    current: CommunityListWireSnapshot;
    seed?: CommunityListWireSnapshot;
    added_at: number;
    [key: string]: unknown;
  }[];
  /** Permanent leave records. */
  tombstones: { community_id: string; removed_at: number; [key: string]: unknown }[];
  /** Opaque list extensions. */
  [key: string]: unknown;
}
/** Runtime fragment with hex keys and materialized seed and identity. */
export interface CommunityListFragment extends ParsedCommunityList {
  /** Total fragment count; positive safe integer. */
  frags: number;
}

import { canonicalWire } from "./community-list-canonical.ts";

function key(value: unknown, encode: boolean): string {
  if (typeof value !== "string") throw new Error("Expected a 32-byte Community List key");
  if (encode) {
    if (!/^[\da-fA-F]{64}$/.test(value)) throw new Error("Expected a hex Community List key");
    return base64urlnopad.encode(hexToBytes(value));
  }
  if (!/^[\w-]{43}$/.test(value)) throw new Error("Expected an unpadded base64url Community List key");
  const bytes = base64urlnopad.decode(value);
  if (bytes.length !== 32 || base64urlnopad.encode(bytes) !== value) throw new Error("Noncanonical Community List key");
  return bytesToHex(bytes);
}

function snapshot(value: Record<string, unknown>, encode: boolean, embedded: boolean): Record<string, unknown> {
  const out = { ...value };
  for (const field of ["owner", "owner_salt", "community_root"]) key(out[field], encode);
  if (
    !Number.isSafeInteger(out.root_epoch) || (out.root_epoch as number) < 0 ||
    typeof out.name !== "string" || !Array.isArray(out.relays) || out.relays.some((r) => typeof r !== "string")
  ) {
    throw new Error("Invalid Community List snapshot");
  }
  // CORD-02 §8: local history and invite-only fields never enter membership snapshots.
  for (const field of ["held_roots", "prev_root", "refounder", "icon", "expires_at", "creator_npub", "label"]) {
    delete out[field];
  }
  for (const field of ["owner", "owner_salt", "community_root", "control_pk", "control_root"]) {
    if (out[field] !== undefined) out[field] = key(out[field], encode);
  }
  if (embedded) delete out.community_id;
  else out.community_id = key(out.community_id, encode);
  if (!Array.isArray(out.channels)) throw new Error("Invalid Community List channels");
  out.channels = out.channels.map((channel: Record<string, unknown>) => {
    const result: Record<string, unknown> = { ...channel, id: key(channel.id, encode), key: key(channel.key, encode) };
    delete result.held;
    return result;
  });
  return out;
}

/** Encode a standalone membership snapshot, retaining its identity (CORD-02 §8). */
export function encodeCommunityListSnapshot(material: JoinMaterial): CommunityListWireSnapshot {
  return snapshot(material as unknown as Record<string, unknown>, true, false) as unknown as CommunityListWireSnapshot;
}

/** Serialize a fragment canonically, pruning covered entries without mutating local recovery material. */
export function encodeCommunityListFragment(fragment: CommunityListFragment): string {
  if (!Number.isSafeInteger(fragment.frags) || fragment.frags < 1) throw new Error("Invalid fragment count");
  const entries = fragment.entries.filter((entry) => isCommunityLive([entry], fragment.tombstones, entry.community_id))
    .map((entry) => {
      if (!Number.isSafeInteger(entry.added_at) || entry.added_at < 0) throw new Error("Invalid membership timestamp");
      if (entry.current.community_id !== entry.community_id || entry.seed.community_id !== entry.community_id) {
        throw new Error("Community List snapshot identity mismatch");
      }
      const current = snapshot(entry.current as unknown as Record<string, unknown>, true, true);
      const seed = snapshot(entry.seed as unknown as Record<string, unknown>, true, true);
      seed.name = current.name;
      seed.relays = current.relays;
      seed.channels = (seed.channels as Record<string, unknown>[]).map((channel) => {
        const latest = (current.channels as Record<string, unknown>[]).find((c) => c.id === channel.id);
        return latest ? { ...channel, name: latest.name } : channel;
      });
      const { seed: _seed, current: _current, ...extras } = entry;
      return {
        ...extras,
        community_id: key(entry.community_id, true),
        current,
        ...(canonicalWire(seed) === canonicalWire(current) ? {} : { seed }),
      };
    });
  return canonicalWire({
    ...fragment,
    entries,
    tombstones: fragment.tombstones.map((t) => {
      if (!Number.isSafeInteger(t.removed_at) || t.removed_at < 0) throw new Error("Invalid tombstone timestamp");
      return { ...t, community_id: key(t.community_id, true) };
    }),
  });
}

/** Decode a strict §8 fragment; malformed documents throw without altering retained state. */
export function decodeCommunityListFragment(json: string): CommunityListFragment {
  const doc = JSON.parse(json) as CommunityListWireFragment;
  if (
    !Number.isSafeInteger(doc.frags) || doc.frags < 1 || !Array.isArray(doc.entries) || !Array.isArray(doc.tombstones)
  ) {
    throw new Error("Invalid Community List fragment");
  }
  const entries = doc.entries.map((entry): CommunityListCommunity => {
    if (!Number.isSafeInteger(entry.added_at) || entry.added_at < 0) throw new Error("Invalid membership timestamp");
    const id = key(entry.community_id, false);
    const read = (value: CommunityListWireSnapshot): JoinMaterial =>
      ({
        ...snapshot(value, false, true),
        community_id: id,
      }) as unknown as JoinMaterial;
    const current = read(entry.current);
    return { ...entry, community_id: id, current, seed: entry.seed ? read(entry.seed) : current };
  });
  return {
    ...doc,
    entries,
    tombstones: doc.tombstones.map((t) => {
      if (!Number.isSafeInteger(t.removed_at) || t.removed_at < 0) throw new Error("Invalid tombstone timestamp");
      return { ...t, community_id: key(t.community_id, false) };
    }),
  };
}

/** Read-only migration decoder for retired kind-13302 plaintext; never interprets legacy hex as base64url. */
export function decodeLegacyCommunityList(json: string | undefined): ParsedCommunityList {
  return parseCommunityList(json);
}
