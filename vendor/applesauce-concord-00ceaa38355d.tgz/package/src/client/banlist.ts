// CORD-04 §§4, 6 local Banlist writes: the serial queue, the 10-per-minute window, required acknowledgment and the
// session intent ledger behind `banMembers`, `ban` and `unban` (D-09..D-12, D-19, D-20). A Banlist edition replaces the
// whole list, so concurrent local writes must chain instead of overwriting each other, and bulk bans (§4) put every
// target in one edition. The writer creates no timer: time comes from the host clock and every wait is a rejection.

import { hexToBytes } from "@noble/hashes/utils.js";
import { isHexKey } from "applesauce-core/helpers/string";
import { BehaviorSubject, type Observable } from "rxjs";

import {
  type BanlistIntent,
  type BanlistWritePlan,
  type BanTargetFailure,
  type BanTargetFailureReason,
  banTargetFailures,
  newestOwnBanlistEdition,
  normalizeBanTargets,
  parseBanlist,
  planBanlistWrite,
  unvouchedEntries,
} from "../helpers/banlist.ts";
import { banlistLocator } from "../helpers/crypto.ts";
import { computeEditionHash } from "../helpers/editions.ts";
import { editionAdditions, type EditionRef } from "../helpers/edition-lineage.ts";
import { refoundAuthority } from "../helpers/permissions.ts";
import { type CommunityState, type DecodedEvent, PERM, VSK } from "../types.ts";
import type { EditionGuard, EditionHead } from "./admin.ts";
import { BanlistReHealError } from "./banlist-reheal.ts";
import type { ConcordDiagnostic } from "./diagnostics.ts";
import type { RefoundingResult } from "./refounding.ts";

/** The required-acknowledgment stage label of a Banlist publication (`RequiredPublishError.stage`). */
export const BANLIST_PUBLICATION_STAGE: string = "banlist publication";

/** At most `max` Banlist editions per `windowMs` per community, measured on the community clock (CORD-04 §4). */
export const BANLIST_RATE_LIMIT: { max: number; windowMs: number } = { max: 10, windowMs: 60_000 };

/**
 * The most members the intent ledger keeps. Past it, the oldest `ban` intent is evicted first, then the oldest `unban`
 * intent whose member this client's newest own Banlist edition does not add; an unban that still cancels a restart
 * candidate is never evicted, so the ledger can exceed the bound by at most that edition's additions.
 */
const MAX_BANLIST_INTENTS = 512;

/**
 * Thrown when a Banlist write is refused because the community already has `limit` Banlist editions in flight or sent
 * within `windowMs`. The call is rejected at once and never waits; retry after `retryAfterMs`.
 */
export class BanlistRateLimitError extends Error {
  /**
   * @param retryAfterMs Milliseconds until a slot frees up, at most `windowMs`.
   * @param limit The most Banlist editions allowed per window.
   * @param windowMs The window length in milliseconds.
   */
  constructor(
    public readonly retryAfterMs: number,
    public readonly limit: number,
    public readonly windowMs: number,
  ) {
    super(`banlist rate limit reached: at most ${limit} editions per ${windowMs} ms`);
    this.name = "BanlistRateLimitError";
  }
}

const FAILURE_TEXT: Record<BanTargetFailureReason, string> = {
  "invalid-key": "not a 64-character hex public key",
  owner: "the owner outranks every member",
  self: "you never outrank yourself",
  "not-outranked": "you do not outrank them or lack BAN",
  "cannot-strip-roles": "missing MANAGE_ROLES over them to strip their roles",
  "refounding-pending":
    "a stored unfinished Refounding would still deliver the new root to them; finish it with refound()",
  "refounding-blocked":
    "refound() refuses the stored Refounding; remove it with discardPendingRefounding() or use refound: false",
};

/**
 * Thrown by `banMembers` and `ban` when any target cannot be banned; `failures` lists every refused target with its
 * reason and nothing is published.
 */
export class BanMembersError extends Error {
  /** @param failures Every refused target, as `{ member, reason }`. */
  constructor(public readonly failures: BanTargetFailure[]) {
    super(`cannot ban ${failures.map((failure) => `${failure.member}: ${FAILURE_TEXT[failure.reason]}`).join("; ")}`);
    this.name = "BanMembersError";
  }
}

/**
 * Thrown when a Banlist write would carry or lift a ban the writer cannot vouch for, and nothing is published.
 * `unvouched-entries`: the next list would keep `members`, bans this account does not outrank, so the fold would drop
 * them under this account's rank. `not-outranked`: the write would lift a ban on `members`, which this account does not
 * outrank. A more senior member has to make either write; entries are never silently dropped (D-19).
 */
export class BanlistWriteBlockedError extends Error {
  /**
   * @param members The members the writer cannot vouch for.
   * @param reason Whether the write would carry them forward or lift their ban.
   */
  constructor(
    public readonly members: string[],
    public readonly reason: "unvouched-entries" | "not-outranked",
  ) {
    super(
      reason === "unvouched-entries"
        ? `this write would carry bans this account cannot vouch for (${
          members.join(", ")
        }); a more senior member must make it`
        : `this write would lift a ban on a member this account does not outrank (${
          members.join(", ")
        }); a more senior member must make it`,
    );
    this.name = "BanlistWriteBlockedError";
  }
}

/**
 * Thrown when the Banlist head changed while a `ban`, `banMembers` or `unban` write was being published, and changed
 * again after the write was planned once more against the new head. Nothing was published; read the community state
 * again and retry.
 */
export class BanlistHeadChangedError extends Error {
  constructor() {
    super("banlist head changed during the write; try again");
    this.name = "BanlistHeadChangedError";
  }
}

/** Options for `banMembers`. */
export interface BanMembersOptions {
  /**
   * Also run one Refounding that excludes every target and keeps every other current member, after the ban and the role
   * strips (CORD-04 §6). It does not rotate private channels. A stored, unfinished Refounding would resume its own
   * request instead, so when that request still delivers the new root to any target (or its recipients are unknown)
   * the call rejects with {@link BanMembersError} (`refounding-pending`) before publishing anything; finish it with
   * `refound()` first. A stored Refounding that `refound()` refuses to finish (it is blocked, belongs to another epoch,
   * or the Control state it was prepared against has changed) would make the Refounding fail, so every target is
   * refused with `refounding-blocked` and nothing is published; remove that record with `discardPendingRefounding()`
   * and retry, or ban with `refound: false`. A Refounding failure rejects the call but leaves the published ban in
   * place.
   */
  refound?: boolean;
}

/** What `banMembers` resolved with. */
export interface BanMembersResult {
  /** The banned members: valid keys, lowercased and deduplicated, in call order. */
  banned: string[];
  /** The shared Refounding's result when `refound` was requested. */
  refounding?: RefoundingResult;
}

/** What the writer needs from its community; wired by the internal Banlist facade. */
export interface BanlistWriterHost {
  /** The logged-in user's pubkey. */
  self: string;
  /** The community's current folded state, read fresh at each use. */
  state(): CommunityState;
  /** The current root epoch; a change means a Refounding was adopted. */
  epoch(): number;
  /** The community clock in milliseconds, which the rate window is measured on. */
  now(): number;
  /** The retained Control history. */
  retained(): Iterable<DecodedEvent>;
  /** Whether a retained record sits at the current epoch's Control address. */
  current(record: DecodedEvent): boolean;
  /** Typed background diagnostics sink. */
  diagnostics: { report(diagnostic: ConcordDiagnostic): void };
  /** The selected verified head of a Control entity. */
  latestEdition(eid: string): Promise<EditionHead | undefined>;
  /** Publish the next edition of an entity, waiting for a relay acknowledgment under the stage label `required`. */
  publishEdition(vsk: number, eid: string, content: string, required: string, guard: EditionGuard): Promise<void>;
  /** Strip all of a member's roles (a Grant write). */
  stripRoles(member: string): Promise<void>;
  /** Throw when this community cannot run a Refounding now. */
  assertRefoundReady(): void;
  /**
   * The recipients of the stored, unfinished Refounding a new `refound()` would resume instead of the caller's request:
   * undefined when none is stored, `"unknown"` when the stored record does not name them, `"blocked"` when `refound()`
   * would refuse to finish it (it is blocked, belongs to another epoch, or its preparation changed).
   */
  pendingRefoundRecipients(): Promise<readonly string[] | "unknown" | "blocked" | undefined>;
  /** Run a Refounding that keeps `keep` and excludes `exclude`. */
  refound(options: { keep: string[]; exclude: string[] }): Promise<RefoundingResult>;
}

/** Internal: the Banlist head moved while a write was being published. */
class HeadMoved extends Error {
  constructor() {
    super("banlist head changed during the write");
    this.name = "HeadMoved";
  }
}

/** Internal: a later ban or unban call of a member a heal was planned for superseded the heal before it was sent. */
class IntentMoved extends Error {
  constructor() {
    super("banlist re-heal superseded by a later intent");
    this.name = "IntentMoved";
  }
}

/** A queued task's handle: `release` frees its queue slot once, as soon as its stamp counts. */
interface QueueSlot {
  release(): void;
}

/**
 * The per-community Banlist writer (CORD-04 §§4, 6). Every local ban, unban and batch ban runs through one serial
 * queue in call order, builds on the head the previous write produced, and waits for a relay acknowledgment before the
 * change is shown locally. At most {@link BANLIST_RATE_LIMIT} editions per window; the rest reject at once. It records
 * the last intent per member for a later re-heal: a ban after its acknowledged write, an unban as soon as it is called.
 * Nothing is persisted.
 */
export class BanlistWriter {
  private readonly host: BanlistWriterHost;
  private tail: Promise<void> = Promise.resolve();
  private queued = 0;
  private stamps: number[] = [];
  private seq = 0;
  private readonly entries = new Map<string, BanlistIntent>();
  private ledgerEpoch: number | undefined;
  private readonly revision = new BehaviorSubject<number>(0);
  /**
   * The intent ledger's revision: emits the current value on subscription and a new one after every recorded intent,
   * so the re-healer re-plans when an intent lands after the head it lost to was already folded.
   */
  readonly intents$: Observable<number> = this.revision.asObservable();

  /** @param host What the writer reads and writes through. */
  constructor(host: BanlistWriterHost) {
    this.host = host;
  }

  /** The last local intent per member at the current epoch, newest last. A copy; later writes do not change it. */
  intents(): ReadonlyMap<string, BanlistIntent> {
    return new Map(this.ledger);
  }

  /**
   * Ban every member in one Banlist edition (CORD-04 §4), strip the roles of those holding any, and optionally run one
   * shared Refounding (§6). Every target is validated first; any failure rejects with {@link BanMembersError} and
   * publishes nothing.
   */
  async banMembers(members: readonly string[], options: BanMembersOptions = {}): Promise<BanMembersResult> {
    if (!Array.isArray(members) || members.length === 0) throw new RangeError("banMembers needs at least one member");
    const { targets, failures: invalid } = normalizeBanTargets(members);
    const seq = ++this.seq;
    return await this.enqueue(async (slot) => {
      const host = this.host;
      const epoch = this.epoch();
      if (host.state().dissolved) throw new Error("community dissolved");
      const failures = [...invalid, ...banTargetFailures(host.state(), host.self, targets)];
      if (failures.length) throw new BanMembersError(failures);
      if (options.refound) {
        host.assertRefoundReady();
        // A stored Refounding resumes its own signed request (CORD-06 §3), which may still deliver the root to a target.
        const resumed = await host.pendingRefoundRecipients();
        if (resumed === "blocked") {
          throw new BanMembersError(targets.map((member) => ({ member, reason: "refounding-blocked" as const })));
        }
        const exposed = resumed === undefined
          ? []
          : targets.filter((target) => resumed === "unknown" || resumed.includes(target));
        if (exposed.length) {
          throw new BanMembersError(exposed.map((member) => ({ member, reason: "refounding-pending" as const })));
        }
      }
      const edition = await this.commit(slot, (base) =>
        this.planned(planBanlistWrite({
          base,
          owner: host.state().material.owner,
          add: targets,
          canVouch: this.vouch(),
        })));
      // A later unban of a target, recorded at its call, outranks this ban by `seq` and is kept (D-12).
      for (const target of targets) this.record(target, "ban", seq, edition, epoch);
      for (const target of targets) {
        if (host.state().grants.get(target)?.length) await host.stripRoles(target);
      }
      if (!options.refound) return { banned: targets };
      const keep = [...host.state().members].filter((member) => !targets.includes(member));
      return { banned: targets, refounding: await host.refound({ keep, exclude: targets }) };
    });
  }

  /** Ban one member: {@link banMembers} for a single target. */
  async ban(member: string): Promise<void> {
    await this.banMembers([member]);
  }

  /**
   * Lift a ban (CORD-04 §4). Needs `BAN` and strict rank over the member (the owner can unban anyone); otherwise it
   * rejects with {@link BanlistWriteBlockedError} and publishes nothing. The unban intent is recorded when the call is
   * made, before anything can fail, so even a rejected, refused or rate-limited unban stops this session from re-healing
   * the member (D-12). A member absent from the head content needs no edition, unless this client's newest own Banlist
   * edition at the current epoch still adds the member, in which case the head content is republished unchanged so a
   * restart cannot revive the ban. When that republish would carry a ban this account cannot vouch for (D-19), nothing
   * is published, the call still resolves, and a `BanlistReHealError` (`unban-not-durable`) on `diagnostics$` reports
   * that a restart may re-apply the ban.
   */
  async unban(member: string): Promise<void> {
    if (typeof member !== "string" || !isHexKey(member)) {
      throw new TypeError("unban needs a 64-character hex public key");
    }
    const key = member.toLowerCase();
    const seq = ++this.seq;
    // An unban intent only ever suppresses heals, so recording it first is always safe (D-12).
    this.record(key, "unban", seq, undefined);
    await this.enqueue(async (slot) => {
      const host = this.host;
      const epoch = this.epoch();
      if (host.state().dissolved) throw new Error("community dissolved");
      if (!refoundAuthority(host.state(), PERM.BAN)(host.self)) {
        throw new Error("missing current permission or verified authority");
      }
      const edition = await this.commit(slot, (base, eid, headHash) => {
        const inHead = base.some((entry) => entry.toLowerCase() === key);
        const force = !inHead && this.stillListed(key, eid);
        if (!inHead && !force) return { kind: "unchanged" };
        const plan = planBanlistWrite({
          base,
          owner: host.state().material.owner,
          remove: [key],
          canVouch: this.vouch(),
          force,
        });
        if (force && plan.kind === "blocked") {
          // The member is not banned, so there is nothing to lift; the unban intent recorded at the call keeps this
          // session from re-healing it (D-12), and only a restart could still revive it (D-21).
          const error = new BanlistReHealError("unban-not-durable", [key]);
          host.diagnostics.report({ stage: "banlist-reheal", key: headHash ?? eid, error });
          return { kind: "unchanged" };
        }
        return this.planned(plan);
      });
      if (edition) this.record(key, "unban", seq, edition, epoch);
    });
  }

  /**
   * Milliseconds until a Banlist edition fits the rate window: 0 while the acknowledged editions in the window plus the
   * queued writes are below {@link BANLIST_RATE_LIMIT}, otherwise the wait until the next slot frees (at most the window
   * length). A pure read of the community clock; the re-healer defers its duty by this much instead of being rejected.
   */
  rateLimitDelay(): number {
    const { max, windowMs } = BANLIST_RATE_LIMIT;
    const now = this.host.now();
    const stamps = this.stamps.filter((at) => at > now - windowMs);
    const load = stamps.length + this.queued;
    if (load < max) return 0;
    const expiring = stamps[load - max];
    return expiring === undefined ? windowMs : Math.min(windowMs, Math.max(0, expiring + windowMs - now));
  }

  /**
   * Publish a re-heal (CORD-04 §4): `content`, the verified head content plus the lost `members`, as the next edition on
   * `expectedHead` through the same serial queue and acknowledgment as every Banlist write. It does not reject on a full
   * rate window (the re-healer defers instead, D-11). It refuses content that omits any current head entry other than
   * the owner key, so a heal never lifts a ban, and content that carries an entry this account cannot vouch for (D-19).
   * `check` runs after every asynchronous step and throws to abandon the publish. So does an intent check: a `ban` or
   * `unban` call of any planned member made after the heal was planned (while it waits in the queue or on the signer)
   * abandons it before it is sent, and the call resolves `false` with nothing published (D-12). Each member's recorded
   * intent then points at the healing edition and keeps its per-intent `seq`, so a heal never resets a retry budget.
   * Resolves `true` once the heal is acknowledged.
   */
  async publishHeal(
    content: readonly string[],
    members: readonly string[],
    expectedHead: string,
    check: () => void,
  ): Promise<boolean> {
    const seqs = new Map(members.map((member) => [member, this.ledger.get(member)?.seq ?? 0]));
    const guard = () => {
      check();
      for (const member of members) {
        const intent = this.ledger.get(member);
        if ((intent?.seq ?? 0) !== seqs.get(member) || intent?.action === "unban") throw new IntentMoved();
      }
    };
    try {
      await this.heal(content, members, expectedHead, guard, seqs);
      return true;
    } catch (error) {
      if (error instanceof IntentMoved) return false;
      throw error;
    }
  }

  /** The queued body of {@link publishHeal}; `guard` runs before and after every asynchronous step. */
  private async heal(
    content: readonly string[],
    members: readonly string[],
    expectedHead: string,
    guard: () => void,
    seqs: ReadonlyMap<string, number>,
  ): Promise<void> {
    await this.enqueue(async (slot) => {
      const host = this.host;
      const epoch = this.epoch();
      guard();
      if (host.state().dissolved) throw new Error("community dissolved");
      const eid = banlistLocator(hexToBytes(host.state().material.community_id));
      const head = await host.latestEdition(eid);
      guard();
      if (head?.hash !== expectedHead) throw new HeadMoved();
      const owner = host.state().material.owner.toLowerCase();
      const next = new Set(content.map((entry) => entry.toLowerCase()));
      const omitted = (parseBanlist(head.content) ?? []).filter((entry) =>
        entry.toLowerCase() !== owner && !next.has(entry.toLowerCase())
      );
      if (omitted.length) throw new BanlistWriteBlockedError(omitted, "not-outranked");
      const vouch = this.vouch();
      const unvouched = unvouchedEntries(content.map((entry) => entry.toLowerCase()), owner, vouch);
      if (unvouched.length) throw new BanlistWriteBlockedError(unvouched, "unvouched-entries");
      const text = JSON.stringify(content);
      await host.publishEdition(VSK.BANLIST, eid, text, BANLIST_PUBLICATION_STAGE, {
        expectedHead,
        check: guard,
        headChanged: () => new HeadMoved(),
      });
      this.stamps.push(host.now());
      slot.release();
      const version = head.version + 1;
      const edition: EditionRef = {
        eid,
        version,
        hash: computeEditionHash({ vsk: VSK.BANLIST, eid, version, prevHash: head.hash, content: text }),
        prevHash: head.hash,
      };
      for (const member of members) this.record(member, "ban", seqs.get(member) ?? 0, edition, epoch);
    }, false);
  }

  /**
   * Whether a restart could still re-apply an own ban of `key`: this client's newest own edition adds it and sits at the
   * current epoch's address, the same scope the re-heal planner seeds from (D-15, D-21).
   */
  private stillListed(key: string, eid: string): boolean {
    return this.ownAdditions(eid).has(key);
  }

  /** The lowercased members this client's newest own Banlist edition at the current epoch adds (D-15, D-21). */
  private ownAdditions(eid: string): Set<string> {
    const newest = newestOwnBanlistEdition(this.host.retained(), eid, this.host.self);
    if (!newest || !this.host.current(newest)) return new Set();
    return new Set(
      editionAdditions(newest, this.host.retained(), parseBanlist).added.map((entry) => entry.toLowerCase()),
    );
  }

  /**
   * The ledger entry to evict past the bound, never `keep`: the oldest `ban` intent, else the oldest `unban` intent a
   * restart could not revive (its member is not added by the newest own edition), else none.
   */
  private evictable(keep: string): string | undefined {
    for (const [member, intent] of this.ledger) if (member !== keep && intent.action === "ban") return member;
    const eid = banlistLocator(hexToBytes(this.host.state().material.community_id));
    const guarded = this.ownAdditions(eid);
    for (const member of this.ledger.keys()) if (member !== keep && !guarded.has(member)) return member;
    return undefined;
  }

  /**
   * The intent ledger of the current epoch. Once a Refounding is adopted, every intent recorded at an earlier epoch is
   * dropped the next time the ledger is read or written, so an old-epoch edition never seeds a heal across it, while
   * intents recorded at the new epoch (even before this client's own Refounding finished) are kept (D-15).
   */
  private get ledger(): Map<string, BanlistIntent> {
    const epoch = this.epoch();
    if (epoch !== this.ledgerEpoch) {
      this.ledgerEpoch = epoch;
      this.entries.clear();
    }
    return this.entries;
  }

  /** The community's current root epoch; a change means a Refounding was adopted. */
  private epoch(): number {
    return this.host.epoch();
  }

  /** The strict-rank check behind every entry: whether this account can make a ban of `member` effective. */
  private vouch(): (member: string) => boolean {
    const state = this.host.state();
    return (member) => refoundAuthority(state, PERM.BAN, member)(this.host.self);
  }

  /** Turn a blocked plan into its typed error; pass every other plan through. */
  private planned(plan: BanlistWritePlan): BanlistWritePlan {
    if (plan.kind === "blocked") throw new BanlistWriteBlockedError(plan.members, plan.reason);
    return plan;
  }

  /**
   * Read the head, plan against it and publish the planned content with a required acknowledgment. A head that moves
   * while publishing is re-read and re-planned once. Resolves the published edition, or undefined when nothing needed
   * publishing. The slot is released and the window stamped as soon as the edition is acknowledged.
   */
  private async commit(
    slot: QueueSlot,
    planFor: (base: string[], eid: string, headHash: string | undefined) => BanlistWritePlan,
  ): Promise<EditionRef | undefined> {
    const host = this.host;
    const eid = banlistLocator(hexToBytes(host.state().material.community_id));
    for (let attempt = 0; attempt < 2; attempt++) {
      const head = await host.latestEdition(eid);
      const plan = planFor(parseBanlist(head?.content ?? "[]") ?? [], eid, head?.hash);
      if (plan.kind !== "write") return undefined;
      const content = JSON.stringify(plan.content);
      try {
        await host.publishEdition(VSK.BANLIST, eid, content, BANLIST_PUBLICATION_STAGE, {
          expectedHead: head?.hash ?? null,
          headChanged: () => new HeadMoved(),
        });
      } catch (error) {
        if (error instanceof HeadMoved) continue;
        throw error;
      }
      this.stamps.push(host.now());
      slot.release();
      const version = (head?.version ?? 0) + 1;
      return {
        eid,
        version,
        hash: computeEditionHash({ vsk: VSK.BANLIST, eid, version, prevHash: head?.hash, content }),
        prevHash: head?.hash,
      };
    }
    throw new BanlistHeadChangedError();
  }

  /** Run `task` after every earlier task, rejecting at once when the window is full unless `limited` is false. */
  private enqueue<T>(task: (slot: QueueSlot) => Promise<T>, limited = true): Promise<T> {
    if (limited) this.checkWindow();
    this.queued++;
    let released = false;
    const slot: QueueSlot = {
      release: () => {
        if (released) return;
        released = true;
        this.queued--;
      },
    };
    const run = this.tail.then(async () => {
      try {
        return await task(slot);
      } finally {
        slot.release();
      }
    });
    this.tail = run.then(() => {}, () => {});
    return run;
  }

  /** Reject when the acknowledged editions in the window plus the writes already queued fill it. */
  private checkWindow(): void {
    const { max, windowMs } = BANLIST_RATE_LIMIT;
    const now = this.host.now();
    this.stamps = this.stamps.filter((at) => at > now - windowMs);
    const load = this.stamps.length + this.queued;
    if (load < max) return;
    const expiring = this.stamps[load - max];
    const retryAfterMs = expiring === undefined ? windowMs : Math.min(windowMs, Math.max(0, expiring + windowMs - now));
    throw new BanlistRateLimitError(retryAfterMs, max, windowMs);
  }

  /**
   * Record the last intent for a member, newest last, evicting past the bound (see {@link MAX_BANLIST_INTENTS}; a
   * D-12 unban that still matters is kept). An intent from an earlier
   * call (a smaller `seq`) never replaces one from a later call, so the last call wins even when an earlier queued
   * write completes after it (D-12). A write that started in `epoch` records nothing once a Refounding was adopted
   * meanwhile: the ledger now belongs to the new epoch, and an old-epoch edition must never seed a heal across the
   * Refounding (D-15).
   */
  private record(
    member: string,
    action: "ban" | "unban",
    seq: number,
    edition: EditionRef | undefined,
    epoch: number = this.epoch(),
  ): void {
    if (epoch !== this.epoch()) return;
    const prior = this.ledger.get(member);
    if (prior && prior.seq > seq) return;
    this.ledger.delete(member);
    this.ledger.set(member, edition ? { action, seq, edition } : { action, seq });
    while (this.ledger.size > MAX_BANLIST_INTENTS) {
      const victim = this.evictable(member);
      if (victim === undefined) break;
      this.ledger.delete(victim);
    }
    this.revision.next(this.revision.value + 1);
  }
}
