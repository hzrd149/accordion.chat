// CORD-04 §4 Banlist re-heal of this client's own lost bans: "after publishing, re-fold, and if your addition isn't in
// the head, re-apply it atop the winner" (decisions D-11..D-15, D-19). Phase 1 duty ownership: the community DutyScope
// owns every delay and retry, so this module creates no timer of its own and stores no duty. A heal is a duty keyed by
// the verified Banlist head hash (a replay of the same head publishes once) that is planned again when it fires, and it
// stops with demotion, rank loss over the target, dissolution, disposal and a Refounding. Internal except
// `BanlistReHealError`.

import { hexToBytes } from "@noble/hashes/utils.js";
import { combineLatest, distinctUntilChanged, map, type Observable, type Subscription } from "rxjs";

import { type BanlistReHealPlan, planBanlistReHeal } from "../helpers/banlist-reheal.ts";
import { banlistLocator } from "../helpers/crypto.ts";
import { refoundAuthority } from "../helpers/permissions.ts";
import {
  type CommunityState,
  type ConcordSyncPhase,
  type DecodedEvent,
  PERM,
  type VerifiedControlHead,
  VSK,
} from "../types.ts";
import type { BanlistWriter } from "./banlist.ts";
import type { ConcordDiagnostic } from "./diagnostics.ts";
import { DutyCancelledError, type DutyContext, type DutyScope } from "./lifecycle.ts";

/** How long a heal of a ban made in this session waits before it acts, in milliseconds (a jittered point in the window). */
export const BANLIST_REHEAL_SESSION_DELAY_MS: { min: number; max: number } = { min: 0, max: 2_000 };
/**
 * How long a heal of a ban found only in this client's own retained history waits, in milliseconds: another device of
 * this account usually heals first.
 */
export const BANLIST_REHEAL_RETAINED_DELAY_MS: { min: number; max: number } = { min: 5_000, max: 30_000 };
/** The most heal publications one ban intent gets before the member is given up on (D-15). */
export const BANLIST_REHEAL_MAX_PUBLICATIONS = 3;
/**
 * The most times in a row a full rate window defers the heal of one ban intent before the member is given up on (D-11).
 * The count restarts each time a heal of the member is published.
 */
export const BANLIST_REHEAL_MAX_DEFERRALS = 5;
/** Extra lifetime a heal duty gets beyond its delay: the duty scope measures lifetime from the first request. */
export const BANLIST_REHEAL_GRACE_MS = 30_000;
/** The most budget, give-up and report records remembered, so a long-lived community cannot grow them without bound. */
const MAX_RECORDS = 512;

const REHEAL_TEXT = {
  "non-convergence": "banlist re-heal gave up after 3 publications",
  blocked: "banlist re-heal blocked: it would carry bans this account cannot vouch for",
  "unban-not-durable":
    "unban held for this session only: the Banlist could not be republished, so a restart may re-apply the ban",
  "rate-limited": "banlist re-heal gave up: the Banlist rate-limit window stayed full",
} as const;

/**
 * Reported on `diagnostics$` under the `banlist-reheal` stage when a Banlist re-heal stops on purpose. `non-convergence`:
 * three heal publications for the same ban did not make it stick, so `members` were given up on until a new ban or a
 * Refounding. `blocked`: the heal would carry bans this account cannot vouch for, so `members` lists those entries and
 * nothing was published. `unban-not-durable`: `unban()` of `members`, who were not on the Banlist but whom this
 * client's newest own Banlist edition still adds, could not republish the list (it would carry a ban this account
 * cannot vouch for); this session never re-adds them, but a restart of this client may. `rate-limited`: local Banlist
 * writes kept the 10-per-minute window full through {@link BANLIST_REHEAL_MAX_DEFERRALS} deferrals of the heal in a
 * row (with no heal of them published in between), so `members` were given up on until a new ban or a Refounding.
 */
export class BanlistReHealError extends Error {
  /**
   * @param reason Why the heal stopped.
   * @param members The members the report is about, as lowercase hex public keys.
   */
  constructor(
    public readonly reason: "non-convergence" | "blocked" | "unban-not-durable" | "rate-limited",
    public readonly members: readonly string[],
  ) {
    super(REHEAL_TEXT[reason]);
    this.name = "BanlistReHealError";
  }
}

/** What the re-healer needs from its community; closures keep it free of engine state. */
export interface BanlistReHealerHost {
  /** The community's duty scope: the only owner of timers and retries. */
  duties(): DutyScope;
  /** Typed background diagnostics sink. */
  diagnostics: { report(diagnostic: ConcordDiagnostic): void };
  /** The local user's pubkey. */
  self: string;
  /** Current folded community state. */
  state(): CommunityState;
  /** Folded state changes. */
  state$: Observable<CommunityState>;
  /** The community sync phase. */
  phase(): ConcordSyncPhase;
  /** Sync phase changes. */
  phase$: Observable<ConcordSyncPhase>;
  /** The current root epoch; a change means a Refounding was adopted. */
  epoch(): number;
  /** Whether the local user may publish a Banlist edition now: not disposed or sealed, can sign Control, holds BAN. */
  canWrite(): boolean;
  /** Whether a Refounding started by this client is in flight. */
  refounding(): boolean;
  /** Changes of {@link refounding}. */
  refounding$: Observable<boolean>;
  /** The retained Control history. */
  retained(): Iterable<DecodedEvent>;
  /** Whether a retained record sits at the current epoch's Control address. */
  current(record: DecodedEvent): boolean;
  /** The Banlist writer: the intent ledger, the rate window and the guarded heal publication. */
  writer: Pick<BanlistWriter, "intents" | "intents$" | "rateLimitDelay" | "publishHeal">;
}

/** Keep `records` at most {@link MAX_RECORDS} entries, evicting the oldest first. */
function bound(records: Set<string> | Map<string, number>): void {
  while (records.size > MAX_RECORDS) {
    const oldest = records.keys().next().value;
    if (oldest === undefined) break;
    records.delete(oldest);
  }
}

/**
 * Re-applies this client's own Banlist additions that a concurrent sibling edition displaced (CORD-04 §4). It watches the
 * verified Banlist head and the local authority, plans with `planBanlistReHeal`, and runs each heal as a duty in the
 * `banlist-reheal` slot. It plans again when the duty fires and publishes through the serial, acknowledged writer.
 */
export class BanlistReHealer {
  private readonly subscription: Subscription;
  private epoch: number;
  private disposed = false;
  /** Counter that makes the key of a deferred or re-planned heal duty fresh. */
  private freshKeys = 0;
  /** Heal publications per ban intent, as `<member>:<seq>`. */
  private readonly published = new Map<string, number>();
  /** Rate-window deferrals per ban intent since its last published heal, as `<member>:<seq>`. */
  private readonly deferred = new Map<string, number>();
  /** Intents given up on, as `<member>:<seq>`. */
  private readonly given = new Set<string>();
  /** Reports already made, so each is made once. */
  private readonly reported = new Set<string>();

  /** @param host What the re-healer reads and publishes through. */
  constructor(private readonly host: BanlistReHealerHost) {
    this.epoch = host.epoch();
    // The intent ledger is an input too: an own ban acknowledged after the sibling that displaced it was folded leaves
    // the head and the effective set unchanged, so only the recorded intent can trigger the re-plan (CORD-04 §4).
    this.subscription = combineLatest([host.state$, host.phase$, host.refounding$, host.writer.intents$]).pipe(
      map(([, , , revision]) => this.signature(revision)),
      distinctUntilChanged(),
    ).subscribe(() => this.reconcile());
  }

  /** Stop watching. Armed duties belong to the scope; they stop being eligible here and the scope drops them at once. */
  dispose(): void {
    this.disposed = true;
    this.subscription.unsubscribe();
    this.host.duties().reevaluate();
  }

  /** Whether this client may heal now: live, allowed to write Banlist editions and not running a Refounding. */
  private live(): boolean {
    return !this.disposed && this.host.phase() === "live" && this.host.canWrite() && !this.host.refounding();
  }

  private read(): { eid: string; head: VerifiedControlHead | undefined; suspended: boolean } {
    const state = this.host.state();
    const eid = banlistLocator(hexToBytes(state.material.community_id));
    const verification = state.controlVerification;
    return { eid, head: verification?.heads.get(eid), suspended: verification?.suspended.has(eid) ?? false };
  }

  /**
   * Everything {@link reconcile} reads, cheaply: the epoch, the verified Banlist head, what the fold honors, the intent
   * ledger's revision and an authority fingerprint, so a rank change re-plans a dormant heal or cancels a waiting one.
   */
  private signature(revision: number): string {
    if (!this.live()) return "idle";
    const { head, suspended } = this.read();
    const banned = [...this.host.state().banlist].sort();
    return [this.host.epoch(), head?.hash ?? "", suspended ? "suspended" : "", revision, banned, this.authority()]
      .join("#");
  }

  /**
   * The verified Role and Grant heads and the suspended coordinates: every input of the strict-rank checks behind
   * {@link canBan}, so any change of rank or permission on either side changes the fingerprint.
   */
  private authority(): string {
    const verification = this.host.state().controlVerification;
    if (!verification) return "";
    const parts: string[] = [];
    for (const head of verification.heads.values()) {
      if (head.vsk === VSK.ROLE || head.vsk === VSK.GRANT) parts.push(head.hash);
    }
    parts.sort();
    return `${parts.join(",")}|${[...verification.suspended].sort().join(",")}`;
  }

  private reconcile(): void {
    if (this.disposed) return;
    const epoch = this.host.epoch();
    if (epoch !== this.epoch) {
      // A Refounding was adopted: this session's budgets belong to the old epoch's Banlist (D-15). The writer drops
      // old-epoch intents itself, at the adoption, so intents recorded at the new epoch before this point are kept.
      this.epoch = epoch;
      this.published.clear();
      this.deferred.clear();
      this.given.clear();
      this.reported.clear();
    }
    this.host.duties().reevaluate();
    if (this.live()) this.evaluate();
  }

  private canBan(member: string): boolean {
    return refoundAuthority(this.host.state(), PERM.BAN, member)(this.host.self);
  }

  /** The per-intent budget key of a member: its call position in this session, 0 when only history names it. */
  private budgetKey(member: string): string {
    return `${member}:${this.host.writer.intents().get(member)?.seq ?? 0}`;
  }

  /** The members whose current intent was given up on. */
  private exhausted(): Set<string> {
    const members = new Set<string>();
    for (const key of this.given) {
      const member = key.slice(0, key.lastIndexOf(":"));
      if (this.budgetKey(member) === key) members.add(member);
    }
    return members;
  }

  /** Plan from current state; used both to decide a request and to re-plan at fire time. */
  private plan(): { plan: BanlistReHealPlan; headHash: string | undefined } {
    const { head, suspended } = this.read();
    const state = this.host.state();
    const plan = planBanlistReHeal({
      self: this.host.self,
      owner: state.material.owner,
      head,
      suspended,
      effective: state.banlist,
      retained: this.host.retained(),
      intents: this.host.writer.intents(),
      exhausted: this.exhausted(),
      canBan: (member) => this.canBan(member),
      current: (record) => this.host.current(record),
    });
    return { plan, headHash: head?.hash };
  }

  private report(error: BanlistReHealError, headHash: string, once: string): void {
    if (this.reported.has(once)) return;
    this.reported.add(once);
    bound(this.reported);
    this.host.diagnostics.report({ stage: "banlist-reheal", key: headHash, error });
  }

  /** Plan and arm a heal; `suffix` makes the duty key fresh when the head's own key is still running. */
  private evaluate(suffix = ""): void {
    if (this.disposed) return;
    const { plan, headHash } = this.plan();
    if (headHash === undefined) return;
    if (plan.kind === "blocked") {
      return this.report(new BanlistReHealError("blocked", plan.members), headHash, `blocked:${headHash}`);
    }
    if (plan.kind !== "heal") return;
    const duties = this.host.duties();
    const { min, max } = plan.source === "session" ? BANLIST_REHEAL_SESSION_DELAY_MS : BANLIST_REHEAL_RETAINED_DELAY_MS;
    const spread = min + Math.floor(duties.clock.random() * (max - min));
    this.request(
      `banlist-reheal:${headHash}${suffix}`,
      headHash,
      Math.max(spread, this.host.writer.rateLimitDelay()),
      plan.members,
    );
  }

  /** Arm the heal duty for `headHash`; a new key in the slot supersedes whatever occupies it. */
  private request(key: string, headHash: string, delayMs: number, members: readonly string[]): void {
    const epoch = this.host.epoch();
    this.host.duties().request({
      key,
      slot: "banlist-reheal",
      stage: "banlist-reheal",
      delayMs,
      lifetimeMs: delayMs + BANLIST_REHEAL_GRACE_MS,
      maxAttempts: 3,
      retryDelayMs: 1_000,
      // Rank over every member to heal is part of eligibility. A rank or permission change alters the authority
      // fingerprint, so reconcile re-evaluates and a waiting heal that lost it is cancelled at once (D-15).
      eligible: () =>
        this.live() && this.host.epoch() === epoch && this.read().head?.hash === headHash &&
        members.every((member) => this.canBan(member)),
      run: (context) => this.run(context, headHash),
    });
  }

  /**
   * Give up on the planned members whose `counts` reached `limit` for their current intent, report it once as `reason`
   * and plan again without them. Returns `current` unchanged when no member is spent.
   */
  private giveUp(
    current: { plan: BanlistReHealPlan; headHash: string | undefined },
    headHash: string,
    reason: "non-convergence" | "rate-limited",
    counts: Map<string, number>,
    limit: number,
  ): { plan: BanlistReHealPlan; headHash: string | undefined } {
    if (current.plan.kind !== "heal") return current;
    const spent = current.plan.members.filter((member) => (counts.get(this.budgetKey(member)) ?? 0) >= limit);
    if (!spent.length) return current;
    const spentKeys = spent.map((member) => this.budgetKey(member));
    for (const key of spentKeys) this.given.add(key);
    bound(this.given);
    this.report(new BanlistReHealError(reason, spent), headHash, `${reason}:${spentKeys.join(",")}`);
    return this.plan();
  }

  private async run(context: DutyContext, headHash: string): Promise<void> {
    context.assertAlive();
    let current = this.giveUp(
      this.plan(),
      headHash,
      "non-convergence",
      this.published,
      BANLIST_REHEAL_MAX_PUBLICATIONS,
    );
    const wait = this.host.writer.rateLimitDelay();
    // A full rate window defers the heal to the next free slot instead of failing (D-11), at most a bounded number of
    // times in a row per ban intent, so a window that never frees cannot re-arm the heal forever.
    if (wait > 0) current = this.giveUp(current, headHash, "rate-limited", this.deferred, BANLIST_REHEAL_MAX_DEFERRALS);
    const { plan } = current;
    if (plan.kind !== "heal" || current.headHash !== headHash) {
      throw new DutyCancelledError("banlist re-heal no longer due");
    }
    if (wait > 0) {
      for (const member of plan.members) {
        const key = this.budgetKey(member);
        this.deferred.set(key, (this.deferred.get(key) ?? 0) + 1);
      }
      bound(this.deferred);
      this.request(`banlist-reheal:${headHash}:deferred:${++this.freshKeys}`, headHash, wait, plan.members);
      throw new DutyCancelledError("banlist re-heal deferred by the rate window");
    }
    const keys = plan.members.map((member) => this.budgetKey(member));
    context.assertAlive();
    if (!(await this.host.writer.publishHeal(plan.content, plan.members, headHash, () => context.assertAlive()))) {
      // A later ban or unban of a planned member superseded the heal before it was sent (D-12). The re-plan its intent
      // revision triggered coalesced into this running duty, so plan again under a fresh key for the other members.
      if (this.live()) this.evaluate(`:superseded:${++this.freshKeys}`);
      throw new DutyCancelledError("banlist re-heal superseded by a later intent");
    }
    for (const key of keys) {
      this.published.set(key, (this.published.get(key) ?? 0) + 1);
      // The deferral bound counts waits in a row: a heal that went out ends the spell (D-11).
      this.deferred.delete(key);
    }
    bound(this.published);
  }
}
