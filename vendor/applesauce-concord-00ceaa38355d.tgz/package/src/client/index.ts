/**
 * The Concord client engine: a single-community reactive wrapper
 * (`ConcordCommunity`), a thin multi-community manager (`ConcordClient`), and the
 * epoch-atomic sync primitives that connect them to relays.
 *
 * This is the only entrypoint that reaches for `applesauce-relay`,
 * `applesauce-signers` and `applesauce-loaders` at runtime, so the pure layers
 * stay usable without the network stack. Sync is a strict sequential epoch walk
 * with a per-epoch plane barrier; live subscriptions open only at the tip.
 *
 * @example
 * ```ts
 * import { ConcordClient } from "@applesauce/concord/client";
 * ```
 *
 * @module
 */

// Named (not `export *`) re-export: `createUserAuthHandler`, `lookupRelayStatus`,
// and `connectedRelays$` stay internal to the package; only `StreamSigners` and
// its options type are public.
export { StreamSigners, type StreamSignersOptions } from "./auth.ts";
/** Pluggable persistence, decoded-rumor caching and media upload — the seams the engine injects. */
export * as Storage from "./storage.ts";
// Export types referenced by public options explicitly for `deno doc`;
// namespace exports alone do not make them public. No runtime exports are added.
export type {
  ConcordRumorStore,
  ConcordStorage,
  ConcordStoreFactory,
  ConcordUploader,
  ConcordUploadOptions,
  ConcordUploadProgress,
} from "./storage.ts";
export * from "./sync.ts";
/** Verified receive boundaries for manual consumers before retaining wire events or decoded rumors. */
export { decodeReceivedWrap, verifyReceiveEnvelope } from "./receive.ts";
export * from "./channel-sync.ts";
export * from "./invite-watcher.ts";
export * from "./invite-manager.ts";
export * from "./private-channel.ts";
export * from "./admin.ts";
export * from "./community.ts";
export * from "./refounding.ts";
// Only rotation types are public; rotation and revocation runtime helpers stay internal.
export type { RotationDiagnostic, RotationDiagnosticReason } from "./rotation.ts";
/** Thrown when no relay accepts a required stage; `RequiredPublishError` is the base class for required-acknowledgment
 *  publication failures and `InviteRevocationPublishError` is its invite-revocation subclass; catch with `instanceof`. */
export { InviteRevocationPublishError, RequiredPublishError } from "./revocation.ts";

/**
 * Thrown when a Banlist write is refused: the rate limit, an unbannable target, a ban the writer cannot vouch for, or a
 * head that kept changing during the write.
 */
export {
  BanlistHeadChangedError,
  BanlistRateLimitError,
  BanlistWriteBlockedError,
  BanMembersError,
  type BanMembersOptions,
  type BanMembersResult,
} from "./banlist.ts";
/**
 * Reported on `diagnostics$` (stage `banlist-reheal`) when a Banlist re-heal gives up or is blocked, or an unban only
 * holds for this session; see `reason`.
 */
export { BanlistReHealError } from "./banlist-reheal.ts";
export type { BanTargetFailure, BanTargetFailureReason } from "../helpers/banlist.ts";
/** Thrown by `setPins` when a Pin List write cannot be planned safely; `reason` says why and whether to retry. */
export { PinListNotReadyError, type PinListNotReadyReason } from "./pins.ts";
/**
 * Thrown by a `ConcordCommunity` send (public or private channel) whose message timer ran out before its wrap was
 * finished; nothing is published. The same class `/helpers` exports, so one `instanceof` check covers both.
 */
export { MessageAlreadyExpiredError } from "../helpers/expiration.ts";
export * from "./client.ts";
/** The `pinUpkeep` option that `ConcordClient` and `ConcordCommunity` accept; type only, the maintainer stays internal. */
export type { ConcordPinUpkeepOptions } from "./pin-maintainer.ts";
/** The schedulePurge options that ConcordClient and ConcordCommunity accept; type only, the purge engine stays internal. */
export type { ConcordPurgeScheduleOptions } from "./expiration-purge.ts";
/** Typed background failures reported on `diagnostics$`; the sink that emits them stays internal. */
export type { ConcordDiagnostic, ConcordDiagnosticBase, ConcordDiagnosticStage } from "./diagnostics.ts";

export * from "./community-list-sync.ts";
/** The shape `ConcordClient.memberships$` and `memberships()` report; type only, the builders stay internal. */
export type { ConcordMemberships } from "./community-list-memberships.ts";

export * from "./community-list-fragments.ts";
