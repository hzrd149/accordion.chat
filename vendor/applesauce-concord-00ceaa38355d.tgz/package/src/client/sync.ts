// Sequential epoch sync (CORD-06): fetch, decrypt, and route every plane before
// reading rekeys and advancing. Live subscriptions open only at the tip.
// The sync loader uses NIP-77 when supported, otherwise paginated REQ.

import type { Debugger, EventStore } from "applesauce-core";
import type { SyncAuthHandler } from "applesauce-loaders/loaders";
import { hexToBytes } from "@noble/hashes/utils.js";
import type { RelayPool } from "applesauce-relay";
import type { ISigner } from "applesauce-signers";
import type { NostrEvent } from "applesauce-core/helpers/event";

import type { StreamSigners } from "./auth.ts";
import {
  type ConcordKeys,
  currentBaseRekeys,
  deriveConcordKeys,
  type PlaneInfo,
  readRekey,
  type RekeyCandidateDiagnostic,
} from "../helpers/keys.ts";
import { foldControl, isDissolution } from "../helpers/control.ts";
import { decodeReceivedWrap } from "./receive.ts";
import { syncAuthorBatch } from "./sync-batch.ts";
import { foldMembers } from "../helpers/guestbook.ts";
import { refoundAuthority, resolveStanding, vacVerifier } from "../helpers/permissions.ts";
import { shouldAdoptRotation } from "./rotation.ts";
import {
  type CommunityState,
  type ControlVerification,
  type DecodedEvent,
  type HeldRootEntry,
  type JoinMaterial,
  PERM,
  type Role,
} from "../types.ts";

/** How the walk continues past an epoch. */
export type EpochTransition = "known" | "adopt" | "removed" | "tip" | "cannot-follow" | "dissolved";

/** The outcome of fully syncing one epoch. */
export interface EpochResult {
  /** Authenticated selection inputs and complete pair for commit-time revalidation. */
  selectedTransition?: {
    /** Held predecessor keys, including the verified continuity coordinate. */
    keys: ConcordKeys;
    /** Signed candidate evidence, retaining seal actors and exact Grant citations. */
    events: DecodedEvent[];
    /** The selected real seal signer. */
    rotator: string;
    /** The complete selected pair, never an independently combined read/control root. */
    material: JoinMaterial;
    /** Already-held successor for down-only rereads and capability enrichment. */
    heldNext?: JoinMaterial;
  };
  /** Bounded value-free explanations for parked or rejected rotation candidates. */
  diagnostics?: RekeyCandidateDiagnostic[];
  /** Same-community verified floors for the next epoch or a recreated model. */
  controlVerification?: ControlVerification;
  /** Authenticated decoded control history, including exact historical pins. */
  controlHistory?: DecodedEvent[];
  /** The root epoch that was synced. */
  epoch: number;
  /** The derived keys for this epoch, reused as the `prior` chain link for the next one. */
  keys: ConcordKeys;
  /** How the walk continues past this epoch. */
  transition: EpochTransition;
  /** Present when `transition === "adopt"`: the material for the next epoch. */
  adoptedMaterial?: JoinMaterial;
  /** D-04 re-read (Pitfall 3): present when `transition === "known"` AND this
   *  epoch's already-fetched rekey plane folds to an "adopt" outcome — a sibling
   *  rotation the walk hadn't previously reconsidered. `syncEpochs` compares
   *  `key` against the already-built next-epoch root and cascades the rebuild
   *  only when it is STRICTLY lower (down-only, never re-fork a settled epoch). */
  reReadAdopted?: { key: Uint8Array; epoch: number; material: JoinMaterial };
  /** Number of rumors routed while syncing this epoch. */
  rumors: number;
}

/** The outcome of walking every epoch to the tip. */
export interface EpochWalkResult {
  /** Selected transitions that contributed to the tip, in continuity order. */
  selectedTransitions?: NonNullable<EpochResult["selectedTransition"]>[];
  /** Final same-community verified floors for the caller's next fold. */
  controlVerification?: ControlVerification;
  /** Accumulated authenticated control history across the visited epochs. */
  controlHistory?: DecodedEvent[];
  /** Every epoch visited, oldest first — the audit trail of how the tip was reached. */
  epochs: EpochResult[];
  /** The keys for the latest epoch we still belong to — open the live subscription
   *  here. Undefined when we were removed. */
  tipKeys?: ConcordKeys;
  /** True when a Refounding excluded us (CORD-06). */
  removed: boolean;
  /** A verified terminal tombstone stopped the walk. */
  dissolved?: boolean;
}

/** Everything the sync walk needs, injected by the {@link ConcordCommunity}. */
export interface SyncContext {
  /** Same-community verified continuity restored after cache truncation. */
  controlVerification?: ControlVerification;
  /** Already authenticated control history belonging to this community. */
  controlHistory?: DecodedEvent[];
  /** Relay pool every plane fetch and live subscription runs on. */
  pool: RelayPool;
  /** This scope's own pubkey→signer holder (D-02/D-06) — never shared across
   *  engines, so two scopes on the same relay never cross-authenticate. */
  signers: StreamSigners;
  /** Wrap-level store: dedups kind-1059 wraps and doubles as the NIP-77 local store. */
  eventStore: EventStore;
  /** The user's signer. NIP-44 support decides whether the walk can follow a rotation at
   *  all — without it the walk stops at `"cannot-follow"` rather than failing. */
  signer: ISigner;
  /** The logged-in user's hex pubkey. */
  self: string;
  /** The relays to walk, already merged with any transport-only extras by the caller. */
  relays: string[];
  /** Route one decoded plane event into its plane's RumorStore (the community applies
   *  the CORD-03 channel binding). */
  route: (info: PlaneInfo, decoded: DecodedEvent) => void | Promise<void>;
  /** The scope's own reactive auth handler — invoked by the relay when it
   *  refuses THIS operation, never called by the walk itself (D-01). Threaded
   *  into every loader request beside `waitForAuth` so the relay can answer its
   *  own challenge against exactly this scope's held keys.
   *
   *  Typed `SyncAuthHandler`, not `RelayAuthHandler`: the loader's own auth
   *  context carries `relay`/`url`/`challenge`/`requirement`/the still-needed
   *  pubkey list/`reason` and NOT `request`, so a handler assigned here must
   *  not read `request`. That is the whole point of the narrower type — it
   *  makes the constraint visible to an external consumer of the public
   *  `SyncContext` / `syncAuthors` API
   *  rather than leaving it as an in-package convention. */
  onAuthRequired: SyncAuthHandler;
  /** Cooperative cancellation: return false to abort the walk between epochs. */
  alive?: () => boolean;
  /** Registers immediate transport cancellation and returns listener cleanup.
   * Manual contexts without this callback retain cooperative `alive` polling. */
  onCancel?: (cancel: () => void) => () => void;
  /** The sync-scoped debug logger (always a real value — constructed internally by
   *  each instance's own `syncContext()`, never `undefined`; see Pitfall 2). */
  logger: Debugger;
  /** The `:sync:decode` child logger for per-dropped-wrap detail (D-07), derived
   *  ONCE by `syncContext()` alongside `logger` — never re-`.extend()`d inside a
   *  decode loop, since `Debugger.extend()` allocates and re-runs namespace
   *  enable-matching on every call. */
  decodeLogger: Debugger;
}

/**
 * Fully sync every gift wrap at `authors` across the context relays and RESOLVE
 * only when done (the atomic barrier). Uses `createSyncLoader`, which probes each
 * relay for NIP-77 and reconciles via negentropy when supported, otherwise pages
 * backward through REQ blocks. Authentication waits only for requested authors
 * whose signing keys this scope actually holds; read-only control addresses
 * remain in the filter. When a relay refuses the request it
 * invokes `ctx.onAuthRequired` with the relay-reported still-needed pubkeys
 * narrowed to this operation's own `waitForAuth`, and the shared retry operator
 * resends once the keys land. Verified local history is included even when
 * negentropy transfers no events. Rejects when every relay fails or is skipped.
 * @param ctx The canonical store, relay transport and instance-held signers.
 * @param authors Exact stream addresses to fetch and authenticate on receive.
 * @param planes Optional held read descriptors. When supplied, every requested
 * address must resolve and its signed seal/rumor must satisfy that plane's binding
 * before insertion. Calls without descriptors still verify wrap kind, current
 * signature bytes and exact requested author before retention.
 */
export async function syncAuthors(
  ctx: SyncContext,
  authors: string[],
  planes?: ReadonlyMap<string, PlaneInfo>,
): Promise<NostrEvent[]> {
  return (await syncAuthorBatch(ctx, authors, planes)).events;
}

interface SyncAttempt {
  history: Map<string, DecodedEvent>;
  verification?: ControlVerification;
  held: Map<string, PlaneInfo>;
  requested: Set<string>;
}

function newAttempt(ctx: SyncContext, material: JoinMaterial): SyncAttempt {
  const sameCommunity = !ctx.controlVerification || ctx.controlVerification.communityId === material.community_id;
  return {
    history: new Map(
      (sameCommunity ? ctx.controlHistory ?? [] : []).map((event) => [event.author + ":" + event.rumor.id, event]),
    ),
    verification: sameCommunity ? ctx.controlVerification : undefined,
    held: new Map(),
    requested: new Set(),
  };
}

function retainControl(attempt: SyncAttempt, event: DecodedEvent): void {
  const id = event.author + ":" + event.rumor.id;
  const prior = attempt.history.get(id);
  if (!prior || event.wrapId < prior.wrapId) attempt.history.set(id, event);
}

/**
 * Fully sync ONE epoch and decide how the walk continues. Drains every decoded
 * wrap into the caller's stores (via `ctx.route`) and awaits each plane's full
 * sync before reading the rekey plane.
 */
export async function syncEpoch(
  ctx: SyncContext,
  epochMaterial: JoinMaterial,
  prior: ConcordKeys | undefined,
  chainHasNext: boolean,
): Promise<EpochResult> {
  return syncEpochWithAttempt(ctx, epochMaterial, prior, chainHasNext, newAttempt(ctx, epochMaterial));
}

async function syncEpochWithAttempt(
  ctx: SyncContext,
  epochMaterial: JoinMaterial,
  prior: ConcordKeys | undefined,
  chainHasNext: boolean,
  attempt: SyncAttempt,
  heldNext?: JoinMaterial,
): Promise<EpochResult> {
  let rumors = 0;
  const emit = async (info: PlaneInfo, d: DecodedEvent) => {
    await ctx.route(info, d);
    rumors++;
  };

  // 1. Derive with no channels yet; register the core planes. Registration only
  //    makes the keys resolvable — it no longer triggers an AUTH itself; the
  //    handler fires only when a relay actually refuses the request (D-01).
  let keys = deriveConcordKeys(epochMaterial, [], prior);
  ctx.signers.register([
    ...(keys.control.signing ? [keys.control.signing] : []),
    keys.guestbook,
    keys.dissolved,
    keys.nextBaseRekey.key,
  ]);
  attempt.held.set(keys.control.pk, keys.planes.get(keys.control.pk)!);

  // 2. Full-sync control / guestbook / dissolved / next-rekey (ATOMIC), routing by plane.
  const coreAuthors = [keys.control.pk, keys.guestbook.pk, keys.dissolved.pk, keys.nextBaseRekey.key.pk];
  const control: DecodedEvent[] = [];
  const guestbook: DecodedEvent[] = [];
  const dissolved: DecodedEvent[] = [];
  const rekey: DecodedEvent[] = [];
  const coreBatch = await syncAuthorBatch(ctx, coreAuthors, keys.planes, epochMaterial.root_epoch);
  const coreFetched = coreBatch.events;
  // CORD-02 §9: death wins the whole fetched batch, before any epoch work is routed.
  for (const event of coreFetched) {
    const info = keys.planes.get(event.pubkey);
    if (info?.type !== "dissolved") continue;
    const decoded = decodeReceivedWrap(event, info);
    if (!decoded || !isDissolution(decoded.rumor, epochMaterial)) continue;
    await emit(info, decoded);
    return { epoch: epochMaterial.root_epoch, keys, transition: "dissolved", rumors };
  }

  let coreDecoded = 0;
  let coreDropped = coreBatch.dropped;
  // Wraps that never reached the decode boundary at all (no plane matches the
  // author). Counted so the aggregate always sums: fetched = decoded + dropped
  // + skipped — otherwise `fetched=10 decoded=0 dropped=0` reads as "all fine".
  let coreSkipped = coreBatch.skipped;
  for (const ev of coreFetched) {
    if (ctx.alive?.() === false) break;
    const info = keys.planes.get(ev.pubkey);
    if (!info) {
      coreSkipped++;
      continue;
    }
    const d = decodeReceivedWrap(ev, info);
    if (!d) {
      coreDropped++;
      ctx.decodeLogger("dropped wrap=%s plane=%s epoch=%d", ev.id.slice(0, 8), info.type, epochMaterial.root_epoch);
      continue;
    }
    coreDecoded++;
    if (info.type === "control") {
      control.push(d);
      retainControl(attempt, d);
    } else if (info.type === "guestbook") guestbook.push(d);
    else if (info.type === "dissolved") dissolved.push(d);
    else if (info.type === "rekey") rekey.push(d);
    else continue;
    await emit(info, d);
  }
  // D-05 litmus: this MUST fire even when coreFetched.length === 0 — a zero-event
  // sync must read `fetched=0`, distinct from an arrived-but-undecryptable sync.
  ctx.logger(
    "core planes epoch=%d fetched=%d decoded=%d dropped=%d skipped=%d",
    epochMaterial.root_epoch,
    coreFetched.length + coreBatch.dropped + coreBatch.skipped,
    coreDecoded,
    coreDropped,
    coreSkipped,
  );

  // 3. Fold control → channels, re-derive to reveal the channel addresses, then
  //    full-sync only the PUBLIC channel planes. Public channels derive from the
  //    community_root, so they rotate with the base and belong to this walk;
  //    PRIVATE channels are independently keyed and sync on their own lifecycle
  //    (ConcordPrivateChannel), lifted out of the community walk entirely.
  let state0 = foldControl([...attempt.history.values()], epochMaterial, attempt.verification);
  // CORD-04 §1/§5: exact pins and tracked chain gaps are synchronization
  // requests, never authority. Snapshot this finite batch; newly exposed
  // dependencies can retry at a later epoch/sync, without an unbounded loop.
  const requests = state0.controlVerification!.pending.filter((p) =>
    (p.reason === "chain-gap" || p.reason === "missing-pin" || p.reason === "pin-mismatch") &&
    (p.version !== undefined || p.hash !== undefined)
  );
  for (const pending of requests) {
    for (const [author, info] of attempt.held) {
      if (ctx.alive?.() === false) break;
      const requestKey = JSON.stringify([
        epochMaterial.community_id,
        pending.eid,
        pending.version,
        pending.hash,
        author,
      ]);
      if (attempt.requested.has(requestKey)) continue;
      attempt.requested.add(requestKey);
      // Outer wraps contain no eid/ev/hash tags. Author filters are hints;
      // verify every returned signature and bind it to this exact held plane.
      const fetched = await syncAuthors(ctx, [author], attempt.held);
      for (const event of fetched) {
        if (ctx.alive?.() === false) break;
        if (event.pubkey !== author) continue;
        const decoded = decodeReceivedWrap(event, info);
        if (!decoded) continue;
        const id = decoded.author + ":" + decoded.rumor.id;
        if (attempt.history.has(id)) continue;
        retainControl(attempt, decoded);
        control.push(decoded);
        await emit(info, decoded);
      }
    }
  }
  state0 = foldControl([...attempt.history.values()], epochMaterial, attempt.verification);
  attempt.verification = state0.controlVerification;
  keys = deriveConcordKeys(epochMaterial, state0.channels, prior);
  const publicIds = new Set(state0.channels.filter((c) => !c.private && !c.deleted).map((c) => c.channel_id));
  const publicKeys = [...keys.channels.entries()].filter(([id]) => publicIds.has(id)).map(([, k]) => k);
  ctx.signers.register(publicKeys);
  const channelDecoded: DecodedEvent[] = [];
  const channelBatch = await syncAuthorBatch(
    ctx,
    publicKeys.map((k) => k.pk),
    keys.planes,
    epochMaterial.root_epoch,
  );
  const channelFetched = channelBatch.events;
  let channelDecodedCount = 0;
  let channelDropped = channelBatch.dropped;
  let channelSkipped = channelBatch.skipped; // never reached the decode boundary (see coreSkipped)
  for (const ev of channelFetched) {
    if (ctx.alive?.() === false) break;
    const info = keys.planes.get(ev.pubkey);
    if (!info || info.type !== "channel") {
      channelSkipped++;
      continue;
    }
    const d = decodeReceivedWrap(ev, info);
    if (!d) {
      channelDropped++;
      // The channel plane carries its OWN epoch (RESEARCH Pitfall 3) — report it
      // rather than the root epoch, so this line correlates with the same wrap
      // dropped by the live subscription (`community.ts`'s `onWrap`).
      ctx.decodeLogger(
        "dropped wrap=%s plane=%s epoch=%d",
        ev.id.slice(0, 8),
        info.type,
        info.epoch ?? epochMaterial.root_epoch,
      );
      continue;
    }
    channelDecodedCount++;
    channelDecoded.push(d);
    await emit(info, d);
  }
  // D-05 litmus: always-on, even for zero fetched public-channel wraps.
  ctx.logger(
    "public channels epoch=%d fetched=%d decoded=%d dropped=%d skipped=%d",
    epochMaterial.root_epoch,
    channelFetched.length + channelBatch.dropped + channelBatch.skipped,
    channelDecodedCount,
    channelDropped,
    channelSkipped,
  );

  // 4. Decide the transition (fold members for standing/authority, exactly as the walk does).
  const observed = new Map<string, number>();
  for (const d of [...control, ...guestbook, ...channelDecoded, ...dissolved]) {
    if (d.ms > (observed.get(d.author) ?? 0)) observed.set(d.author, d.ms);
  }
  const rolesMap = new Map<string, Role>(state0.roles.map((r) => [r.role_id, r]));
  const members = foldMembers(
    guestbook,
    observed,
    state0.banlist,
    (m) => resolveStanding(m, epochMaterial.owner, rolesMap, state0.grants),
    Date.now(),
    epochMaterial.refounder,
    vacVerifier(state0, PERM.KICK),
  );
  const state: CommunityState = { ...state0, members };

  // A rotator may only remove US if they also strictly outrank us (CORD-04/
  // CORD-06 §3 "in both"); no admin instance exists in the sync walk, so build
  // the shared predicate from this same verified current snapshot.
  // Built unconditionally (not just for the tip) since the "known" branch's
  // re-read below needs it too.
  const canRemoveSelf = refoundAuthority(state, PERM.BAN, ctx.self);

  // D-08/D-12: a non-owner rotation must cite the Grant it acts under; the
  // receiver verifies it against this SAME folded state, independent of the
  // `refoundAuthority` roster-bit check below (readRekey's `isAuthorized` arg).
  const verifyVac = vacVerifier(state, PERM.BAN);

  let transition: EpochTransition = "tip";
  // CORD-06 §2: author filters are hints; archived epochs returned alongside
  // the requested plane must not dispatch an unsupported split base transition.
  const candidateRekeys = "control_pk" in epochMaterial || "control_root" in epochMaterial
    ? currentBaseRekeys(epochMaterial, rekey)
    : rekey;
  let adoptedMaterial: JoinMaterial | undefined;
  let reReadAdopted: EpochResult["reReadAdopted"];
  let diagnostics: RekeyCandidateDiagnostic[] | undefined;
  let selectedTransition: EpochResult["selectedTransition"];
  if (chainHasNext) {
    transition = "known";
    // D-04 re-read spine (Pitfall 3): this epoch's rekey plane was already
    // fully fetched above (step 2) — fold it via readRekey instead of
    // discarding it, so a strictly-lower authorized sibling that arrives late
    // is still discoverable on a later full walk. This does NOT change the
    // "known" classification for the normal case; `syncEpochs` decides
    // whether the winner beats the already-built next epoch and cascades.
    const outcome = await readRekey(
      keys,
      candidateRekeys,
      refoundAuthority(state),
      ctx.self,
      ctx.signer,
      state.channels,
      canRemoveSelf,
      verifyVac,
      heldNext,
    );
    diagnostics = outcome.diagnostics;
    if (outcome.kind === "none" && outcome.retainedMaterial) {
      keys = deriveConcordKeys(outcome.retainedMaterial, state.channels, prior);
    }
    if (outcome.kind === "adopt") {
      selectedTransition = {
        keys,
        events: currentBaseRekeys(epochMaterial, candidateRekeys),
        rotator: outcome.rotator,
        material: outcome.next.material,
        heldNext,
      };
      reReadAdopted = {
        key: hexToBytes(outcome.next.material.community_root),
        epoch: outcome.epoch,
        material: outcome.next.material,
      };
    }
  } else if (!ctx.signer.nip44) {
    transition = "cannot-follow";
  } else {
    const outcome = await readRekey(
      keys,
      candidateRekeys,
      refoundAuthority(state),
      ctx.self,
      ctx.signer,
      state.channels,
      canRemoveSelf,
      verifyVac,
    );
    diagnostics = outcome.diagnostics;
    if (outcome.kind === "none" && outcome.retainedMaterial) {
      keys = deriveConcordKeys(outcome.retainedMaterial, state.channels, prior);
    }
    if (outcome.kind === "adopt") {
      selectedTransition = {
        keys,
        events: currentBaseRekeys(epochMaterial, candidateRekeys),
        rotator: outcome.rotator,
        material: outcome.next.material,
      };
      transition = "adopt";
      adoptedMaterial = outcome.next.material;
    } else if (outcome.kind === "removed") {
      transition = "removed";
    }
  }

  return {
    epoch: epochMaterial.root_epoch,
    keys,
    transition,
    adoptedMaterial,
    reReadAdopted,
    ...(selectedTransition ? { selectedTransition } : {}),
    ...(diagnostics ? { diagnostics } : {}),
    rumors,
    controlVerification: attempt.verification,
    controlHistory: [...attempt.history.values()],
  };
}

/**
 * Walk every epoch from the seed forward — fully syncing each (auth → all planes →
 * fold → rekey) before advancing — until we reach the tip, are removed, or can no
 * longer follow. Returns the tip keys so the caller can open the live subscription
 * there (and nowhere else).
 */
export async function syncEpochs(ctx: SyncContext, material: JoinMaterial): Promise<EpochWalkResult> {
  const epochs: EpochResult[] = [];
  let prior: ConcordKeys | undefined;
  let chain = buildChain(material);
  let tipKeys: ConcordKeys | undefined;
  let removed = false;
  const selectedTransitions: NonNullable<EpochResult["selectedTransition"]>[] = [];
  const attempt = newAttempt(ctx, material);

  for (let i = 0; i < chain.length; i++) {
    if (ctx.alive && !ctx.alive()) break;
    const result = await syncEpochWithAttempt(ctx, chain[i], prior, i + 1 < chain.length, attempt, chain[i + 1]);
    if (ctx.alive?.() === false) break;
    if (result.transition === "dissolved") {
      epochs.push(result);
      return { epochs, removed: false, dissolved: true, controlHistory: [...attempt.history.values()] };
    }
    prior = result.keys;
    epochs.push(result);

    if (result.transition === "adopt" && result.adoptedMaterial) {
      if (result.selectedTransition) selectedTransitions.push(result.selectedTransition);
      chain = [...chain, result.adoptedMaterial];
      continue;
    }
    if (result.transition === "known") {
      chain = chain.map((entry, index) =>
        index <= i ? entry : ({
          ...entry,
          held_roots: mergeRootHistory(entry.held_roots ?? [], result.keys.material.held_roots ?? [])
            .filter((root) => !isCurrentRootRecord(root, entry)),
        })
      );
      // D-04 cascade (Open Question 2): a strictly-lower re-read winner for this
      // known epoch beats what `chain[i+1]` already recorded — discard
      // chain[i+1..] (it was built on the abandoned branch) and rebuild the
      // continuation from the corrected root; the forward walk regenerates
      // everything past it from there. An equal-or-higher re-read keeps the
      // existing chain untouched (down-only — never re-fork a settled epoch).
      const next = chain[i + 1];
      if (
        result.reReadAdopted &&
        next &&
        shouldAdoptRotation(hexToBytes(next.community_root), result.reReadAdopted.key)
      ) {
        if (result.selectedTransition) selectedTransitions.push(result.selectedTransition);
        chain = [...chain.slice(0, i + 1), result.reReadAdopted.material];
      } else if (result.reReadAdopted && next) {
        if (
          result.selectedTransition && result.reReadAdopted.material.community_root === next.community_root &&
          result.reReadAdopted.material.control_pk === next.control_pk && next.control_root === undefined &&
          result.reReadAdopted.material.control_root !== undefined
        ) selectedTransitions.push(result.selectedTransition);
        // Preserve newly discovered losing pairs even when down-only selection
        // keeps the already settled root. Never copy the losing control pair.
        chain = chain.map((entry, index) =>
          index <= i ? entry : ({
            ...entry,
            ...(index === i + 1 && result.reReadAdopted!.material.community_root === entry.community_root &&
                result.reReadAdopted!.material.control_pk === entry.control_pk && entry.control_root === undefined &&
                result.reReadAdopted!.material.control_root !== undefined
              ? { control_root: result.reReadAdopted!.material.control_root }
              : {}),
            held_roots: mergeRootHistory(entry.held_roots ?? [], result.reReadAdopted!.material.held_roots ?? [])
              .filter((root) => !isCurrentRootRecord(root, entry)),
          })
        );
      }
      continue;
    }
    // tip / cannot-follow: we still belong here → open live at these keys.
    // removed: a Refounding excluded us → no live subscription.
    if (result.transition === "removed") removed = true;
    else tipKeys = result.keys;
    break;
  }

  if (tipKeys && ctx.alive?.() !== false) {
    // CORD-06 §3: retained fork messages are reads only. Do not fold losing
    // control/Guestbook heads into authority or follow their rekey addresses.
    const visited = new Set(epochs.flatMap((epoch) => [...epoch.keys.channels.values()].map((key) => key.pk)));
    const historical = [...tipKeys.planes].filter(([pk, info]) => info.type === "channel" && !visited.has(pk));
    const batch = await syncAuthorBatch(ctx, historical.map(([pk]) => pk), tipKeys.planes, tipKeys.material.root_epoch);
    for (const event of batch.events) {
      if (ctx.alive?.() === false) break;
      const info = tipKeys.planes.get(event.pubkey)!;
      const decoded = decodeReceivedWrap(event, info);
      if (decoded) await ctx.route(info, decoded);
    }
  }

  return {
    epochs,
    tipKeys,
    removed,
    controlVerification: attempt.verification,
    controlHistory: [...attempt.history.values()],
    selectedTransitions,
  };
}

function rootEntry(material: JoinMaterial): HeldRootEntry {
  return {
    epoch: material.root_epoch,
    key: material.community_root,
    ...(material.refounder !== undefined ? { refounder: material.refounder } : {}),
    ...(material.prev_root !== undefined ? { prev_root: material.prev_root } : {}),
    ...(material.control_pk !== undefined ? { control_pk: material.control_pk } : {}),
    ...(material.control_root !== undefined ? { control_root: material.control_root } : {}),
  };
}

function mergeRootHistory(left: HeldRootEntry[], right: HeldRootEntry[]): HeldRootEntry[] {
  const entries = new Map<string, HeldRootEntry>();
  for (const entry of [...left, ...right]) {
    const id = JSON.stringify([
      entry.epoch,
      entry.key,
      entry.control_pk,
      entry.prev_root,
      entry.refounder,
      entry.candidate_id,
    ]);
    const old = entries.get(id);
    entries.set(id, old?.control_root ? old : entry);
  }
  return [...entries.values()];
}

function isCurrentRootRecord(root: HeldRootEntry, material: JoinMaterial): boolean {
  return root.candidate_id === undefined && root.epoch === material.root_epoch &&
    root.key === material.community_root &&
    root.control_pk === material.control_pk &&
    (root.control_root === undefined || root.control_root === material.control_root);
}

/**
 * The ordered chain of held roots an invite/material grants — epoch 0..current.
 * Each element is a per-epoch {@link JoinMaterial} carrying only the roots at or
 * before that epoch, so `deriveConcordKeys` addresses the right generation.
 */
export function buildChain(material: JoinMaterial): JoinMaterial[] {
  const tip = rootEntry(material);
  const roots = mergeRootHistory([tip], material.held_roots ?? []).sort((a, b) => a.epoch - b.epoch);
  const established = roots.filter((root) => root.candidate_id === undefined && root.epoch <= material.root_epoch);
  const uniq: HeldRootEntry[] = [];
  for (
    const epoch of [...new Set(established.map((root) => root.epoch))]
  ) {
    const previous = uniq.at(-1);
    const continuous = roots.filter((root) =>
      root.epoch === epoch && root.candidate_id === undefined &&
      (root.prev_root === undefined ||
        // CORD-06 §3: a fresh joiner already holds its authenticated tip and
        // fetches compaction there without possessing the predecessor secret.
        // This singleton read anchor never bypasses archived pair conflicts or
        // missing continuity between two held coordinates.
        (established.length === 1 && root === tip && previous === undefined) ||
        (previous?.epoch === epoch - 1 && root.prev_root === previous.key))
    );
    if (!continuous.length) break;
    // CORD-06 §3 orders read roots only. Unproven older saved history follows
    // its compatibility path; new branches must match the predecessor.
    const candidates = continuous.some((root) => root.prev_root !== undefined)
      ? continuous.filter((root) => root.prev_root !== undefined).sort((a, b) =>
        a.key < b.key ? -1 : a.key > b.key ? 1 : 0
      )
      : continuous;
    const selected = candidates[0];
    const lowest = candidates.filter((root) => root.key === selected.key);
    if (new Set(lowest.map((root) => root.control_pk)).size > 1) {
      // Accepted D-13: preserve a held pair; without an anchor, park the
      // lowest class rather than bypassing it for a higher read root.
      const held = continuous.find((root) => root === tip) ??
        continuous.find((root) => root.candidate_id === undefined);
      if (!held) break;
      uniq.push(held);
      continue;
    }
    const matching = candidates.filter((root) => root.key === selected.key && root.control_pk === selected.control_pk);
    uniq.push(
      matching.find((root) => root === tip) ?? matching.find((root) => root.control_root !== undefined) ?? selected,
    );
  }
  // Strip the tip's own `refounder` out of the spread base below — every
  // synthesized epoch attributes its OWN refounder instead (ROTATE-12/L01), so
  // the tip's must never leak onto a historical entry via `...base`.
  const { refounder: _tipRefounder, control_pk: _tipPk, control_root: _tipRoot, prev_root: _prev, ...base } = material;
  return uniq.map((r) => ({
    ...base,
    community_root: r.key,
    root_epoch: r.epoch,
    ...(r.prev_root !== undefined ? { prev_root: r.prev_root } : {}),
    ...("control_pk" in r ? { control_pk: r.control_pk } : {}),
    ...("control_root" in r ? { control_root: r.control_root } : {}),
    // ROTATE-12/L01: attribute EACH synthesized epoch's refounder from its OWN
    // held_roots entry — genesis (epoch 0) and pre-field entries fall back to
    // undefined (key omitted, not set to `undefined`, to keep the object shape
    // stable when there is none) — instead of stamping the TIP's refounder onto
    // every historical epoch (a forged-roster vector the moment any per-epoch
    // fold surfaces at foldMembers' snapshot-authorization gate).
    ...(r.refounder !== undefined ? { refounder: r.refounder } : {}),
    held_roots: roots.filter((o) => o !== r).sort((a, b) => b.epoch - a.epoch),
  }));
}

/** The logical plane a decoded wrap belongs to — the RumorStore key. Channels
 *  key by their stable id (shared across epochs); control/dissolved/rekey key by
 *  kind (not epoch-partitioned in this phase). The Guestbook rides the epoch
 *  (CORD-02 §5), so its key includes `info.epoch` — a Refounding's new epoch
 *  starts a fresh store, and `foldMembers` reads only the current epoch's Joins/
 *  Leaves/Kicks/Snapshots + observed authors, so a removed member's prior-epoch
 *  activity can't resurrect them. Old-epoch guestbook stores stay addressable for
 *  reading history until the retention trim (`adoptRefounding`, D-03) disposes
 *  them once their epoch leaves `held_roots`. */
export function planeStoreKey(info: PlaneInfo): string {
  if (info.type === "channel") return `channel:${info.channelId}`;
  if (info.type === "guestbook") return `guestbook@${info.epoch}`;
  return info.type;
}
