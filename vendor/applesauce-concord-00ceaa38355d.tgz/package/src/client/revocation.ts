import type { PublishResponse } from "applesauce-relay";

/** The default stage label for required Control Plane publications: the invite registry unregister step. */
export const INVITE_REGISTRY_UNREGISTER_STAGE = "invite registry unregister";

/** Stages whose required-acknowledgment failures surface as {@link InviteRevocationPublishError}. */
const INVITE_REVOCATION_STAGES: ReadonlySet<string> = new Set([
  INVITE_REGISTRY_UNREGISTER_STAGE,
  "member bundle publication",
  "membership-free bundle publication",
]);

/**
 * Thrown when a publication that requires at least one relay acknowledgment receives none.
 * `stage` names the step that failed and `responses` holds what each relay answered; a publish that
 * threw before any relay answered has no responses and carries the thrown error as `cause`.
 */
export class RequiredPublishError extends AggregateError {
  /**
   * Creates a failure containing the relay responses for a required publication stage.
   * @param stage The stage that received no successful acknowledgment.
   * @param responses Relay publication results, also exposed through inherited `errors`.
   * @param options Optional error cause.
   */
  constructor(
    public readonly stage: string,
    public readonly responses: PublishResponse[],
    options?: ErrorOptions,
  ) {
    super(responses, `${stage} failed: no relay accepted the publication`, options);
    this.name = "RequiredPublishError";
  }
}

/** Structured failure for a required invite-revocation publication stage. */
export class InviteRevocationPublishError extends RequiredPublishError {
  /**
   * Creates a failure containing the relay responses for a required publication stage.
   * @param stage The invite-revocation stage that received no successful acknowledgment.
   * @param responses Relay publication results, also exposed through inherited `errors`.
   * @param options Optional error cause.
   */
  constructor(stage: string, responses: PublishResponse[], options?: ErrorOptions) {
    super(stage, responses, options);
    this.message = `${stage} failed: no relay accepted the revocation`;
    this.name = "InviteRevocationPublishError";
  }
}

/** Builds the failure for a stage: the invite subclass for invite stages, the base class otherwise. */
export function requiredPublishError(
  stage: string,
  responses: PublishResponse[],
  options?: ErrorOptions,
): RequiredPublishError {
  return INVITE_REVOCATION_STAGES.has(stage)
    ? new InviteRevocationPublishError(stage, responses, options)
    : new RequiredPublishError(stage, responses, options);
}

/** A required publication is effective once any targeted relay accepts it. */
export function requirePublishAck(stage: string, responses: PublishResponse[]): void {
  if (responses.some((response) => response.ok)) return;
  throw requiredPublishError(stage, responses);
}

/**
 * Settles a fire-and-forget publication without rejecting: `report` receives the pool's rejection, or, when the
 * publication resolved with no accepting relay, the {@link requirePublishAck} failure for `stage`. A real `RelayPool`
 * resolves refusals, timeouts and closed sockets as `ok: false` responses, so checking the rejection alone misses them.
 */
export function reportUnacknowledgedPublish(
  stage: string,
  publication: Promise<PublishResponse[]>,
  report: (error: unknown) => void,
): Promise<void> {
  return publication.then((responses) => requirePublishAck(stage, responses)).catch(report);
}

/** A multi-relay revocation is effective once any targeted relay accepts it. */
export function requireInviteRevocationAck(stage: string, responses: PublishResponse[]): void {
  if (responses.some((response) => response.ok)) return;
  throw new InviteRevocationPublishError(stage, responses);
}
