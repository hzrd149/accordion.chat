// CORD-02 §8: per-coordinate state and safe fragment write planning.
import type { CommunityListCommunity, CommunityTombstone } from "../types.ts";
import { mergeCommunities, mergeCommunityTombstones, type ParsedCommunityList } from "../helpers/community-list.ts";
import { type CommunityListFragment, encodeCommunityListFragment } from "../helpers/community-list-wire.ts";

/** Authenticated, decrypted version retained at one fragment index. */
export interface CommunityListFragmentVersion {
  /** Canonical decimal index from the signed d tag. */
  index: number;
  /** Signed event identifier, used for NIP-01 ties. */
  id: string;
  /** Signed event timestamp in seconds. */
  created_at: number;
  /** Validated fragment plaintext. */
  document: CommunityListFragment;
}

/** Parse a canonical nonnegative decimal fragment index, or return undefined. */
export function communityListFragmentIndex(value: string | undefined): number | undefined {
  if (value === undefined || !/^(0|[1-9][0-9]*)$/.test(value)) return undefined;
  const index = Number(value);
  return Number.isSafeInteger(index) ? index : undefined;
}

/** Union membership state without interpreting opaque extensions (CORD-02 §8). */
export function unionCommunityList(a: ParsedCommunityList, b: ParsedCommunityList): ParsedCommunityList {
  return {
    ...b,
    ...a,
    entries: mergeCommunities(a.entries, b.entries),
    tombstones: mergeCommunityTombstones(a.tombstones, b.tombstones),
  };
}

/** Pure fragment collection; missing indexes never count as empty documents. */
export class CommunityListFragments {
  private readonly versions = new Map<number, CommunityListFragmentVersion>();

  /** Retain the newest NIP-01 winner at an index; stale editions cannot replace it. */
  receive(version: CommunityListFragmentVersion): boolean {
    if (!Number.isSafeInteger(version.index) || version.index < 0) throw new Error("Invalid fragment index");
    // Validate before retaining any state, even for manually constructed runtime documents.
    encodeCommunityListFragment(version.document);
    const prior = this.versions.get(version.index);
    if (
      prior && (prior.created_at > version.created_at ||
        (prior.created_at === version.created_at && prior.id <= version.id))
    ) return false;
    this.versions.set(version.index, structuredClone(version));
    return true;
  }

  /** Defensive copy of the current version at one index. */
  get(index: number): CommunityListFragmentVersion | undefined {
    const version = this.versions.get(index);
    return version && structuredClone(version);
  }

  /** Held indexes in ascending order, including dormant coordinates. */
  get indexes(): number[] {
    return [...this.versions.keys()].sort((a, b) => a - b);
  }

  /** Newest declaration governs; equal-age declarations choose the larger count. */
  get count(): number {
    let age = -Infinity, count = 1;
    for (const version of this.versions.values()) {
      if (version.created_at > age) {
        age = version.created_at;
        count = version.document.frags;
      } else if (version.created_at === age) count = Math.max(count, version.document.frags);
    }
    return count;
  }

  /** Whether every index below the governing declaration is held. */
  get complete(): boolean {
    if (this.versions.size < this.count) return false;
    for (let index = 0; index < this.count; index++) if (!this.versions.has(index)) return false;
    return true;
  }

  /** Merge only in-range fragments, resolving fragment extensions by lowest index. */
  get document(): ParsedCommunityList {
    let document: ParsedCommunityList = { entries: [], tombstones: [] };
    for (const index of [...this.versions.keys()].sort((a, b) => a - b)) {
      if (index >= this.count) continue;
      document = unionCommunityList(document, this.versions.get(index)!.document);
    }
    const { frags: _count, ...result } = document;
    return result;
  }

  /**
   * Every held fragment merged in ascending index order, dormant coordinates included, so the lowest index wins for
   * fragment-level fields and nothing an interrupted repack left behind is dropped (CORD-02 §8, D-20). Unlike
   * {@link document} this is a planning view: a dormant membership appears here until a repack empties its index.
   */
  get documentAll(): ParsedCommunityList {
    let document: ParsedCommunityList = { entries: [], tombstones: [] };
    for (const index of this.indexes) document = unionCommunityList(document, this.versions.get(index)!.document);
    const { frags: _count, ...result } = document;
    return result;
  }

  /**
   * Held indexes at or above the governing count whose document still carries a membership, a tombstone or any field
   * other than the count: residue an interrupted staging, final or cleanup stage leaves (CORD-02 §8, D-20).
   */
  get dormantResidue(): number[] {
    return this.indexes.filter((index) => {
      if (index < this.count) return false;
      const { frags: _count, entries, tombstones, ...extras } = this.versions.get(index)!.document;
      return entries.length > 0 || tombstones.length > 0 || Object.keys(extras).length > 0;
    });
  }

  /**
   * Sorted community ids whose membership, or whose tombstone, is held in more than one fragment below the governing
   * count: an interrupted repack leaves a record briefly in two fragments (CORD-02 §8). A membership and its tombstone
   * in different fragments are not a duplicate, because another client may place them that way on purpose (IN-04).
   */
  get duplicateResidue(): string[] {
    const entries = new Map<string, Set<number>>();
    const tombstones = new Map<string, Set<number>>();
    const add = (where: Map<string, Set<number>>, id: string, index: number) =>
      where.set(id, (where.get(id) ?? new Set()).add(index));
    for (const version of this.versions.values()) {
      if (version.index >= this.count) continue;
      for (const entry of version.document.entries) add(entries, entry.community_id, version.index);
      for (const tombstone of version.document.tombstones) add(tombstones, tombstone.community_id, version.index);
    }
    const duplicated = [...entries, ...tombstones].filter(([, indexes]) => indexes.size > 1).map(([id]) => id);
    return [...new Set(duplicated)].sort();
  }

  /** Whether an interrupted repack left dormant content or memberships held in two fragments. */
  get residue(): boolean {
    return this.dormantResidue.length > 0 || this.duplicateResidue.length > 0;
  }

  /** Indexes holding a membership or its permanent tombstone. */
  indexesFor(communityId: string): number[] {
    return [...this.versions.values()].filter((v) =>
      v.index < this.count && (v.document.entries.some((e) => e.community_id === communityId) ||
        v.document.tombstones.some((t) => t.community_id === communityId))
    ).map((v) => v.index).sort((a, b) => a - b);
  }

  /**
   * Sorted list-level field names (everything but the count, entries and tombstones) that a held fragment above zero
   * carries and fragment 0 lacks: fields a scoped write to that fragment would otherwise destroy (CORD-02 §8, D-18).
   * Empty for index 0 and for an index that is not held. When fragment 0 is not held, every such field is stranded.
   */
  strandedExtensionKeys(index: number): string[] {
    const version = this.versions.get(index);
    if (index === 0 || !version) return [];
    const { frags: _count, entries: _entries, tombstones: _tombstones, ...extras } = version.document;
    const zero = this.versions.get(0)?.document;
    return Object.keys(extras).filter((key) => !zero || !(key in zero)).sort();
  }

  /**
   * Read-modify-write one held fragment; local material cannot erase remote entries. Fragment-level unknown fields
   * belong to the List and serialize only on fragment 0, unioned lowest index first (CORD-02 §8, D-09, D-10), so a
   * fragment above zero emits only the count, entries and tombstones. `retainExtensions` keeps that fragment's own
   * fields (never the writer's extras) and exists only for the D-18 fallback when fragment 0 is not held.
   */
  scoped(index: number, changes: ParsedCommunityList, retainExtensions: boolean = false): CommunityListFragment {
    const previous = this.versions.get(index);
    if (!previous && (index !== 0 || this.versions.size !== 0)) throw new Error("Fragment is unread");
    const merged = unionCommunityList(previous?.document ?? { entries: [], tombstones: [] }, changes);
    const { entries, tombstones } = merged;
    if (index === 0) return { ...this.document, ...merged, frags: this.count, entries, tombstones };
    const own = retainExtensions ? previous!.document : {};
    return { ...own, frags: this.count, entries, tombstones };
  }

  /**
   * Plan a complete repack, preserving extensions on zero and emptying dropped indexes. Dormant content is merged
   * before it is emptied, because only a tombstone subtracts a membership (CORD-02 §8, D-20).
   * The size callback budgets encoded events, including encryption/signature overhead; publishers must check actual signed events.
   */
  async repack(
    local: ParsedCommunityList,
    size: (index: number, document: CommunityListFragment) => Promise<number>,
    target: number = 56 * 1024,
  ): Promise<Map<number, CommunityListFragment>> {
    if (!this.complete && this.versions.size) throw new Error("Cannot repack an incomplete Community List");
    const merged = unionCommunityList(this.documentAll, local);
    const { entries, tombstones, ...extras } = merged;
    type RecordItem = { entry: CommunityListCommunity } | { tombstone: CommunityTombstone };
    const records: RecordItem[] = [
      ...entries.map((entry) => ({ entry })),
      ...tombstones.map((tombstone) => ({ tombstone })),
    ];
    let count = this.count;
    for (;;) {
      const drafts: CommunityListFragment[] = [{ ...extras, frags: count, entries: [], tombstones: [] }];
      for (const record of records) {
        let index = drafts.length - 1;
        const append = (base: CommunityListFragment): CommunityListFragment => ({
          ...base,
          entries: "entry" in record ? [...base.entries, record.entry] : base.entries,
          tombstones: "tombstone" in record ? [...base.tombstones, record.tombstone] : base.tombstones,
        });
        let draft = append(drafts[index]);
        if (await size(index, draft) > target) {
          index++;
          drafts.push({ frags: count, entries: [], tombstones: [] });
          draft = append(drafts[index]);
          if (await size(index, draft) > 65_536) {
            throw new Error("One Community List record exceeds the event ceiling");
          }
        }
        drafts[index] = draft;
      }
      if (drafts.length !== count) {
        count = drafts.length;
        continue; // The final declaration changes signed-event size too.
      }
      const result = new Map(drafts.map((draft, index) => [index, draft]));
      for (let index = count; index < this.count; index++) {
        result.set(index, { frags: count, entries: [], tombstones: [] });
      }
      for (const index of this.dormantResidue) {
        if (!result.has(index)) result.set(index, { frags: count, entries: [], tombstones: [] });
      }
      return result;
    }
  }
}
