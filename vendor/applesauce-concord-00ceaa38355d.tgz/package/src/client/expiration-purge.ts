// CORD-08 §3 engine-side purge of expired Chat: from the store of every folded non-deleted channel and from the retained
// wraps the engine can still decrypt, plus the CORD-08 §4 timer change and its notice fan-out, both moved out of
// community.ts, and the opt-in periodic schedule (CORD-08 §3) that runs the purge as a chain of one-shot DutyScope duties.
// Expiry judgement stays in helpers/expiration.ts (the signed rumor decides, never the wrap's outer tag). Only the
// ConcordPurgeScheduleOptions type is exported from a barrel; the engine stays internal.
import type { EventStore } from "applesauce-core";
import { type EventTemplate, verifyWrappedEvent } from "applesauce-core/helpers/event";

import { isRumorExpired, messageExpiration, TIMER_NOTICE_KIND } from "../helpers/expiration.ts";
import { decodeWrap, GIFT_WRAP_KIND } from "../helpers/gift-wrap.ts";
import { type ConcordKeys, deriveChannelKeys, type PlaneInfo } from "../helpers/keys.ts";
import type { ChannelMetadata } from "../types.ts";
import type { DiagnosticsSink } from "./diagnostics.ts";
import type { DutyScope } from "./lifecycle.ts";
import type { ConcordRumorStore } from "./storage.ts";

/** What {@link CommunityExpiration} needs from its community: plain getters, so it is testable without an engine. */
export interface CommunityExpirationHost {
  /** True once the engine is disposed; a purge then touches nothing. */
  disposed(): boolean;
  /** The folded channel list, which already omits deleted channels. */
  channels(): ChannelMetadata[];
  /**
   * One entry per id in order, opening missing stores through the app's store factory (see {@link openEach}), so an id
   * whose store cannot be opened yields its error and the rest still open.
   */
  channelStores(ids: readonly string[]): OpenedStore[];
  /** The engine's current keys, with the material they were derived from. */
  keys(): ConcordKeys;
  /** The shared wrap cache. */
  readonly eventStore: EventStore;
  /** The engine's duty scope, whose clock is the time source. */
  duties(): DutyScope;
  /** Where a failed sweep is reported. */
  readonly diagnostics: DiagnosticsSink;
  /** Patches the community metadata through the admin surface. */
  editMetadata(patch: { message_expiration: number }): Promise<void>;
  /** Whether the actor currently holds MANAGE_METADATA. */
  canManageMetadata(): boolean;
  /** Sends one rumor into a channel. */
  sendEvent(channelId: string, template: EventTemplate): Promise<unknown>;
  /**
   * Drops what the engine keeps in memory for rumors expired at `now` (Unix seconds), such as an expired Edit's seal,
   * whether or not a store still holds them: a store's own expiry timer may have removed them before any sweep.
   */
  forgetExpired(now: number): void;
}

/** One channel store as a purge opened it: the store, or what the app's store factory threw for it. */
export type OpenedStore = { store: ConcordRumorStore } | { error: unknown };

/** Opens each id's store in order, catching a failure per id so one throwing store factory call stops nothing else. */
export function openEach(ids: readonly string[], open: (id: string) => ConcordRumorStore): OpenedStore[] {
  return ids.map((id) => {
    try {
      return { store: open(id) };
    } catch (error) {
      return { error };
    }
  });
}

/**
 * Removes every expired Chat rumor from one channel store (CORD-08 §3). Kinds 5, 1740 and 20000-29999 are never expired,
 * so deletion tombstones survive a sweep.
 *
 * @param store The channel's rumor store.
 * @param now The judging time in Unix seconds.
 * @param alive Returns false to stop the sweep early, such as once the engine is disposed.
 * @returns How many rumors were removed.
 */
export async function sweepExpired(
  store: ConcordRumorStore,
  now: number,
  alive: () => boolean = () => true,
): Promise<number> {
  let removed = 0;
  for (const rumor of await store.getTimeline([{}])) {
    if (!alive()) break;
    if (!isRumorExpired(rumor, now)) continue;
    await store.remove(rumor);
    removed++;
  }
  return removed;
}

/**
 * Every channel message plane the engine holds a key for, restricted to the folded non-deleted channels. A fresh derive
 * holds only a private channel's current epoch, so older epochs come from the `ChannelKey` itself (its held keys); the
 * result unites both, keyed by wrap author pubkey.
 */
export function heldChannelPlanes(keys: ConcordKeys, folded: ReadonlySet<string>): Map<string, PlaneInfo> {
  const planes = new Map<string, PlaneInfo>();
  for (const [pubkey, info] of keys.planes) {
    if (info.type === "channel" && info.channelId !== undefined && folded.has(info.channelId)) {
      planes.set(pubkey, info);
    }
  }
  for (const key of keys.material.channels) {
    if (!folded.has(key.id)) continue;
    for (const [pubkey, info] of deriveChannelKeys(keys.material, key).planes) {
      if (info.type === "channel") planes.set(pubkey, info);
    }
  }
  return planes;
}

/**
 * Options for `schedulePurge` on `ConcordCommunity` and `ConcordClient`: the opt-in periodic purge of expired Chat
 * (CORD-08 §3). One sweep runs at once, another when an engine reaches `live`, then one per interval, never two at
 * once.
 */
export interface ConcordPurgeScheduleOptions {
  /**
   * Milliseconds between sweeps, an integer from 60_000 to 2_147_483_647 (larger values would overflow the platform
   * timer). Defaults to 300_000, five minutes.
   */
  intervalMs?: number;
}

/** The default time between scheduled sweeps: five minutes. */
export const DEFAULT_PURGE_INTERVAL_MS = 300_000;
/** The shortest accepted interval, which keeps a schedule from becoming a busy loop. */
export const MIN_PURGE_INTERVAL_MS = 60_000;
/** The longest accepted interval: the largest delay a platform timer holds without overflowing. */
export const MAX_PURGE_INTERVAL_MS = 2_147_483_647;

/**
 * The validated sweep interval for `options` (CORD-08 §3, D-11, D-21).
 *
 * @throws TypeError when `intervalMs` is not a number.
 * @throws RangeError when `intervalMs` is not an integer within the accepted range.
 */
export function purgeIntervalMs(options?: ConcordPurgeScheduleOptions): number {
  const value: unknown = options?.intervalMs;
  if (value === undefined) return DEFAULT_PURGE_INTERVAL_MS;
  if (typeof value !== "number") throw new TypeError("purge interval must be a number");
  if (!Number.isInteger(value) || value < MIN_PURGE_INTERVAL_MS || value > MAX_PURGE_INTERVAL_MS) {
    throw new RangeError(
      `purge interval must be an integer from ${MIN_PURGE_INTERVAL_MS} to ${MAX_PURGE_INTERVAL_MS} milliseconds`,
    );
  }
  return value;
}

/** Something a client can schedule a purge on: one community engine. */
export interface PurgeScheduleTarget {
  /** Starts the target's own periodic purge and returns its disposer. */
  schedulePurge(options?: ConcordPurgeScheduleOptions): () => void;
}

/**
 * The client-wide purge schedule (D-20): remembers the active options so every engine added or rebuilt later gets the
 * same schedule, and keeps each target's disposer so the schedule can be stopped everywhere at once. Internal.
 */
export class PurgeSchedules {
  private latest: object | undefined;
  private options: ConcordPurgeScheduleOptions | undefined;
  private readonly stops = new Map<PurgeScheduleTarget, () => void>();

  /**
   * Makes `options` the client schedule on `targets` and every target attached later, replacing the previous one.
   * Validates first, so an invalid interval touches nothing.
   *
   * @returns A disposer that stops this schedule everywhere; it does nothing once a later call replaced it.
   */
  set(options: ConcordPurgeScheduleOptions | undefined, targets: Iterable<PurgeScheduleTarget>): () => void {
    purgeIntervalMs(options);
    this.clear();
    const mine = {};
    this.latest = mine;
    this.options = { ...options };
    for (const target of targets) this.attach(target);
    return () => {
      if (this.latest === mine) this.clear();
    };
  }

  /** Schedules on `target` when a client schedule is active. */
  attach(target: PurgeScheduleTarget): void {
    if (this.latest === undefined) return;
    this.stops.get(target)?.();
    this.stops.set(target, target.schedulePurge(this.options));
  }

  /** Stops and forgets one target, such as an engine that left its community. */
  detach(target: PurgeScheduleTarget): void {
    this.stops.get(target)?.();
    this.stops.delete(target);
  }

  /** Forgets every attached target, whose engines are being disposed, and keeps the active options. */
  detachAll(): void {
    this.stops.clear();
  }

  /** Stops every attached schedule and forgets the options. */
  clear(): void {
    for (const stop of this.stops.values()) stop();
    this.stops.clear();
    this.latest = undefined;
    this.options = undefined;
  }
}

/** The expired-Chat purge and the CORD-08 §4 timer change of one community. */
export class CommunityExpiration {
  private running?: Promise<number>;
  /** Open-time sweeps not yet settled, by store; each resolves to how many rumors it removed. */
  private readonly hydrations = new Map<ConcordRumorStore, Promise<number>>();
  private schedules = 0;
  private activeSchedule = 0;
  /** Arms a fresh sweep of the active schedule; set by {@link CommunityExpiration.schedule}. */
  private sweepNow?: () => void;

  constructor(private readonly host: CommunityExpirationHost) {}

  /**
   * Deletes the expired Chat a channel store already held when it opened (CORD-08 §3, D-05): rows persisted by an
   * earlier session never pass the receive boundary, so they would otherwise stay on disk and count as activity. One
   * sweep per call, judged on the duty clock; nothing starts once the engine is disposed. A failure is reported as
   * `expiration-purge` with the channel id and never thrown.
   */
  hydrate(channelId: string, store: ConcordRumorStore): void {
    const host = this.host;
    if (host.disposed()) return;
    const now = host.duties().clock.now() / 1000;
    host.forgetExpired(now);
    const sweep: Promise<number> = sweepExpired(store, now, () => !host.disposed())
      .catch((error: unknown) => {
        host.diagnostics.report({ stage: "expiration-purge", key: channelId, error });
        return 0;
      })
      .finally(() => {
        if (this.hydrations.get(store) === sweep) this.hydrations.delete(store);
      });
    this.hydrations.set(store, sweep);
  }

  /**
   * Removes expired Chat from every folded non-deleted channel's store and from the retained wraps readable with a held
   * key (CORD-08 §3), judging by the signed rumor at the duty clock. A failing store or wrap scan is reported on
   * `diagnostics$` and the rest still runs. A call while one runs shares it.
   *
   * @returns How many rumors were removed from channel stores.
   */
  purge(): Promise<number> {
    if (this.host.disposed()) return Promise.resolve(0);
    this.running ??= this.sweep().finally(() => {
      this.running = undefined;
    });
    return this.running;
  }

  /**
   * Opts in to a periodic purge (CORD-08 §3, D-09..D-12): one sweep at once, another when the engine reaches `live` (see
   * {@link CommunityExpiration.live}), then one per interval, as a chain of one-shot duties in the `expiration-purge`
   * slot of the community's duty scope. The next tick is armed only after a
   * sweep ends, so sweeps never overlap. A failed sweep is reported as `expiration-purge` and the next tick retries. A
   * second call replaces the active schedule, and the earlier disposer then does nothing. Once the engine is disposed or
   * dissolved the duty scope refuses the tick, so a call arms nothing and its disposer does nothing.
   *
   * @returns A disposer that stops this schedule.
   * @throws TypeError or RangeError for an invalid interval, before anything is armed.
   */
  schedule(options?: ConcordPurgeScheduleOptions): () => void {
    const interval = purgeIntervalMs(options);
    const host = this.host;
    const id = ++this.schedules;
    this.activeSchedule = id;
    let tick = 0;
    const arm = (delayMs: number, fresh = false): void => {
      host.duties().request({
        key: `expiration-purge:${id}:${tick++}`,
        slot: "expiration-purge",
        stage: "expiration-purge",
        // The default publication semantics stay on, so dissolution cancels and refuses the schedule (D-10).
        delayMs,
        maxAttempts: 1,
        eligible: () => this.activeSchedule === id && !host.disposed(),
        run: async (context) => {
          try {
            // A fresh sweep waits out one that began earlier, which may have seen fewer channels, then runs its own
            // only if no disposer, replacement or dissolution stopped the schedule during the wait.
            if (fresh) await this.running;
            if (!context.alive()) return;
            await this.purge();
          } catch (error) {
            host.diagnostics.report({ stage: "expiration-purge", error });
          }
          if (context.alive()) arm(interval);
        },
      });
    };
    this.sweepNow = () => {
      if (this.activeSchedule === id) arm(0, true);
    };
    arm(0);
    return () => {
      if (this.activeSchedule !== id) return;
      this.activeSchedule = 0;
      host.duties().reevaluate();
    };
  }

  /**
   * Tells an active schedule that the engine reached `live`: its first sweep may have run before sync folded any
   * channel, so a fresh sweep is armed at once in place of the pending tick, and the interval restarts after it.
   */
  live(): void {
    this.sweepNow?.();
  }

  /**
   * Sets the community Chat timer through the metadata edit, then announces it with a timer notice in each readable
   * channel while the actor holds MANAGE_METADATA (CORD-08 §4).
   */
  async announceTimer(seconds: number): Promise<void> {
    const host = this.host;
    if (seconds !== 0 && messageExpiration(seconds) !== seconds) throw new Error("Invalid message expiration");
    await host.editMetadata({ message_expiration: seconds });
    for (const channel of host.channels()) {
      if (channel.private && !host.keys().material.channels.some((key) => key.id === channel.channel_id)) continue;
      if (!host.canManageMetadata()) break;
      await host.sendEvent(channel.channel_id, {
        kind: TIMER_NOTICE_KIND,
        created_at: Math.floor(host.duties().clock.now() / 1000),
        content: "",
        tags: [["timer", String(seconds)]],
      });
    }
  }

  private async sweep(): Promise<number> {
    const host = this.host;
    // CORD-08 §3: judged at the engine's duty clock, in Unix seconds.
    const now = host.duties().clock.now() / 1000;
    // Judged by signed expiry alone, so a seal goes even when the stores' own timers already removed its rows.
    host.forgetExpired(now);
    const ids = host.channels().map((channel) => channel.channel_id);
    let removed = 0;
    let opened: OpenedStore[] = [];
    try {
      opened = host.channelStores(ids);
    } catch (error) {
      host.diagnostics.report({ stage: "expiration-purge", error });
    }
    // Snapshot before any await: a store opened just now has its open-time sweep pending, and one that finishes while an
    // earlier store is swept must still be joined and counted rather than missed and swept twice.
    const joined = opened.map((entry) => "store" in entry ? this.hydrations.get(entry.store) : undefined);
    for (let i = 0; i < opened.length; i++) {
      if (host.disposed()) return removed;
      const entry = opened[i];
      if (!("store" in entry)) {
        host.diagnostics.report({ stage: "expiration-purge", key: ids[i], error: entry.error });
        continue;
      }
      try {
        const pending = joined[i];
        removed += pending ? await pending : await sweepExpired(entry.store, now, () => !host.disposed());
      } catch (error) {
        host.diagnostics.report({ stage: "expiration-purge", key: ids[i], error });
      }
    }
    if (host.disposed()) return removed;
    try {
      await this.sweepWraps(now);
    } catch (error) {
      host.diagnostics.report({ stage: "expiration-purge", error });
    }
    return removed;
  }

  /** Removes retained wraps whose signed rumor is expired; the outer tag is never read (CORD-08 §2). */
  private async sweepWraps(now: number): Promise<void> {
    const host = this.host;
    const planes = heldChannelPlanes(host.keys(), new Set(host.channels().map((channel) => channel.channel_id)));
    if (planes.size === 0) return;
    // The authors filter keeps the scan to this community's channel planes, never other communities' wraps.
    for (const wrap of await host.eventStore.getTimeline([{ kinds: [GIFT_WRAP_KIND], authors: [...planes.keys()] }])) {
      if (host.disposed()) return;
      const info = planes.get(wrap.pubkey);
      if (!info) continue;
      try {
        // Authenticate a clone first: a copy can still carry the SDK's verified symbol, and only bytes count.
        if (!verifyWrappedEvent(structuredClone(wrap))) continue;
        const decoded = decodeWrap(structuredClone(wrap), info.convKey);
        if (!decoded || !isRumorExpired(decoded.rumor, now)) continue;
        await host.eventStore.remove(wrap);
      } catch { /* An unreadable wrap is not evidence of expiry. */ }
    }
  }
}
