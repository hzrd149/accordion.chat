// CORD-04 §7 Edits: a curator republishes a Pin List entry with the Edit's own proof bundle, and the bundle needs the
// Edit's original encrypted seal (createPinProof). The library does not retain seals beyond the wrap layer, so this
// index records them at the single route funnel, after the channel binding check and before the rumor is stored, and
// sync rebuilds it on every start() by re-routing retained and fetched wraps before the community is live. It holds
// ciphertext seals plus the references to plane conversation keys that `keys.planes` already holds: no secret is
// copied, nothing is logged, and nothing is persisted. Internal: not exported from any barrel.
import { getEventHash, type NostrEvent, type Rumor } from "applesauce-core/helpers/event";

import { isValidEdit } from "../helpers/edit.ts";
import { rumorExpiration } from "../helpers/expiration.ts";
import type { PlaneInfo } from "../helpers/keys.ts";
import { createPinProof, type PinProof, type VerifiedPin, verifyPinEntry } from "../helpers/pins.ts";
import { hasMalformedMs, rumorMs } from "../helpers/stream.ts";
import type { DecodedEvent } from "../types.ts";

/** The most Edit seals kept per channel. */
export const PIN_EDIT_SEALS_PER_CHANNEL = 512;

/** An encrypted seal (kind 20013), the only kind a pin proof can disclose. */
const ENCRYPTED_SEAL = 20013;

/** What is kept per Edit: its seal, the key that opens it and what eviction orders by. */
interface SealRecord {
  seal: NostrEvent;
  convKey: Uint8Array;
  wrapId: string;
  /** The recomputed Edit id. */
  id: string;
  /** The message the Edit targets (first `e` tag) and who signed it: the pair "newest of its original" is judged on. */
  target: string;
  author: string;
  ms: number;
  /** The Edit's signed expiry in Unix seconds, if any (CORD-08 §3): the record is judged by it, not by a store row. */
  expiresAt?: number;
}

/** Whether a record's signed Edit has expired at `now` (Unix seconds), by the library's rule `expiration <= now`. */
function isExpired(record: SealRecord, now: number): boolean {
  return record.expiresAt !== undefined && record.expiresAt <= now;
}

/** Whether `a` is older than `b` in the library's total Edit order: lower time, or equal time and the higher id. */
function isOlder(a: SealRecord, b: SealRecord): boolean {
  return a.ms < b.ms || (a.ms === b.ms && a.id > b.id);
}

/** Recovers the seal an Edit proof needs from wraps already routed, and builds self-checked proofs from it. */
export class PinEditSeals {
  private readonly channels = new Map<string, Map<string, SealRecord>>();
  /** Proofs already built (or refused, `null`) by channel and Edit id; dropped with the seal they came from. */
  private readonly proofs = new Map<string, Map<string, PinProof | null>>();

  /**
   * Record the seal of a decoded channel-plane Edit. Anything else is ignored: other planes, other kinds, an Edit with
   * no target, a malformed `ms`, a seal that is not an encrypted seal, a decoded event without its seal, or an Edit
   * already expired at `now`. The Edit is keyed by its recomputed id, never by the id the rumor claims. A duplicate
   * keeps the seal of the lowest wrap id. Each note also forgets the channel's seals that expired by `now`. Over
   * {@link PIN_EDIT_SEALS_PER_CHANNEL} the oldest Edit by rumor order goes, preferring one that a newer retained Edit of
   * the same message by the same author has superseded, so the newest provable Edit survives a busy channel.
   */
  note(info: PlaneInfo, decoded: DecodedEvent, now: number = Date.now() / 1000): void {
    const channelId = info.channelId;
    const seal = decoded.seal;
    const rumor = decoded.rumor;
    if (info.type !== "channel" || !channelId || !seal || seal.kind !== ENCRYPTED_SEAL) return;
    if (!isValidEdit(rumor) || hasMalformedMs(rumor)) return;
    const target = rumor.tags.find((tag) => tag[0] === "e")?.[1];
    if (typeof target !== "string") return;
    let id: string;
    try {
      id = getEventHash(rumor);
    } catch {
      return; // Malformed relay input is skipped, never thrown.
    }
    const record: SealRecord = {
      seal,
      convKey: info.convKey,
      wrapId: decoded.wrapId,
      id,
      target,
      author: rumor.pubkey,
      ms: rumorMs(rumor),
      expiresAt: rumorExpiration(rumor),
    };
    if (isExpired(record, now)) return;
    let records = this.channels.get(channelId);
    if (!records) this.channels.set(channelId, records = new Map());
    const known = records.get(id);
    if (known) {
      if (record.wrapId >= known.wrapId) return;
      this.proofs.get(channelId)?.delete(id);
    }
    records.set(id, record);
    for (const held of [...records.values()]) if (isExpired(held, now)) this.drop(channelId, held.id);
    if (records.size > PIN_EDIT_SEALS_PER_CHANNEL) this.evict(channelId, records);
  }

  /**
   * The proof of `edit` for a pinned message, or undefined when the Edit's seal is not held, createPinProof refuses it,
   * or the proof does not verify (CORD-04 §7: the entry with this bundle must open to this exact Edit). Memoized; an
   * unknown Edit is not remembered, because its seal may still arrive. A seal whose Edit expired by `now` is forgotten
   * here and yields no proof (CORD-08 §3).
   */
  proof(
    channelId: string,
    pin: Pick<VerifiedPin, "rumor" | "entry">,
    edit: Rumor,
    now: number = Date.now() / 1000,
  ): PinProof | undefined {
    let id: string;
    try {
      id = getEventHash(edit);
    } catch {
      return undefined;
    }
    const record = this.channels.get(channelId)?.get(id);
    if (!record) return undefined;
    if (isExpired(record, now)) {
      this.drop(channelId, id);
      return undefined;
    }
    const memo = this.proofs.get(channelId)?.get(id);
    if (memo !== undefined) return memo ?? undefined;
    let built: PinProof | null = null;
    try {
      const candidate = createPinProof(record.seal, record.convKey);
      // The self-check: the entry as it would be published must open to exactly this Edit (RESEARCH Pitfall 6).
      if (verifyPinEntry({ ...pin.entry, edit: candidate }, channelId)?.edit?.id === id) built = candidate;
    } catch {
      built = null; // A seal the key cannot open yields no proof, not an error.
    }
    let memos = this.proofs.get(channelId);
    if (!memos) this.proofs.set(channelId, memos = new Map());
    memos.set(id, built);
    return built ?? undefined;
  }

  /** How many Edit seals a channel holds. */
  size(channelId: string): number {
    return this.channels.get(channelId)?.size ?? 0;
  }

  /**
   * Forget every seal and proof whose signed Edit expired by `now` (Unix seconds; CORD-08 §3), whether or not a store
   * still holds the Edit: the stores' own expiry timers may have removed it before any purge ran.
   */
  forgetExpired(now: number): void {
    for (const [channelId, records] of [...this.channels]) {
      for (const record of [...records.values()]) if (isExpired(record, now)) this.drop(channelId, record.id);
    }
  }

  /** Forget every seal and proof of a channel. */
  dropChannel(channelId: string): void {
    this.channels.delete(channelId);
    this.proofs.delete(channelId);
  }

  /** The ids of the channels that hold seals. */
  channelIds(): string[] {
    return [...this.channels.keys()];
  }

  /** Forget everything. */
  clear(): void {
    this.channels.clear();
    this.proofs.clear();
  }

  /** Remove the oldest record by rumor order that is not the newest of its (message, author), else the oldest overall. */
  private evict(channelId: string, records: Map<string, SealRecord>): void {
    const newest = new Map<string, SealRecord>();
    for (const record of records.values()) {
      const key = `${record.target}:${record.author}`;
      const best = newest.get(key);
      if (!best || isOlder(best, record)) newest.set(key, record);
    }
    let victim: SealRecord | undefined;
    let victimIsNewest = true;
    for (const record of records.values()) {
      const isNewest = newest.get(`${record.target}:${record.author}`) === record;
      // A superseded record always goes before a newest one; among equals the older one goes first.
      if (!victim || (victimIsNewest && !isNewest) || (victimIsNewest === isNewest && isOlder(record, victim))) {
        victim = record;
        victimIsNewest = isNewest;
      }
    }
    if (victim) this.drop(channelId, victim.id);
  }

  /** Forget one Edit's seal and proof, and the channel once it holds none. */
  private drop(channelId: string, id: string): void {
    const records = this.channels.get(channelId);
    records?.delete(id);
    this.proofs.get(channelId)?.delete(id);
    if (records?.size === 0) this.dropChannel(channelId);
  }
}
