import { hexToBytes } from "@noble/hashes/utils.js";
import { getEventHash } from "applesauce-core/helpers/event";
import { grantLocator } from "../helpers/crypto.ts";
import { resolveEditionPin } from "../helpers/editions.ts";
import { isCurrentStaff } from "../helpers/permissions.ts";
import { type CommunityState, type JoinMaterial, VSK } from "../types.ts";

/** One selected authenticated own Grant that may promote this holder to hold the control signing key. */
export interface PromotionCandidate {
  /** Changes whenever the material or the selected Grant edition changes; used to attempt each candidate once. */
  identity: string;
  /** The staff author of the Grant edition, the sender of the pairwise control-root delivery. */
  author: string;
  /** The NIP-44 wrapped control-root delivery named by the Grant body. */
  wrap: string;
  /** The material the candidate was selected against. */
  material: JoinMaterial;
}

/**
 * CORD-04 §3: use only the selected authenticated own Grant, never retained alternatives or display-only heads.
 * Returns the candidate for the current state and material, or `undefined` when no Grant qualifies. Pure and total.
 */
export function selectPromotionCandidate(
  state: CommunityState,
  material: JoinMaterial,
  pubkey: string,
): PromotionCandidate | undefined {
  const coordinates = ["community_id", "owner", "owner_salt", "community_root", "root_epoch", "control_pk"] as const;
  if (
    !material.control_pk || coordinates.some((field) => state.material[field] !== material[field]) ||
    !isCurrentStaff(state, pubkey)
  ) return;
  const eid = grantLocator(hexToBytes(material.community_id), pubkey);
  const verification = state.controlVerification;
  const head = verification?.heads.get(eid);
  if (
    verification?.communityId !== material.community_id || !head || head.vsk !== VSK.GRANT ||
    verification.suspended.has(eid)
  ) return;
  try {
    const { edition } = head;
    if (resolveEditionPin([edition], [eid, String(head.version), head.hash]).kind !== "matched") return;
    const body: unknown = JSON.parse(edition.rumor.content);
    if (
      !body || typeof body !== "object" || !("member" in body) || body.member !== pubkey ||
      !("control_wrap" in body) || typeof body.control_wrap !== "string"
    ) return;
    if (
      !/^[0-9a-f]{64}$/.test(edition.author) || edition.author !== edition.rumor.pubkey ||
      edition.rumor.id !== getEventHash(edition.rumor)
    ) return;
    return {
      identity: JSON.stringify([
        material.community_id,
        material.owner,
        material.owner_salt,
        material.community_root,
        material.root_epoch,
        material.control_pk,
        material.channels,
        material.held_roots,
        head.version,
        head.hash,
        edition.rumor.id,
        edition.author,
      ]),
      author: edition.author,
      wrap: body.control_wrap,
      material,
    };
  } catch {
    return;
  }
}
