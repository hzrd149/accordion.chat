// CORD-02 §8: authenticated fragment ingest and serialized read-modify-write publication.
import type { NostrEvent } from "applesauce-core/helpers/event";
import { nip44 } from "applesauce-core/helpers/encryption";
import type { ISigner } from "applesauce-signers";
import { BehaviorSubject, type Observable } from "rxjs";
import { CommunityListFragments } from "./community-list-fragments.ts";
import { authenticCommunityListFragment, communityListFragmentShape } from "./community-list-read.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  type CommunityListFragment,
  decodeCommunityListFragment,
  encodeCommunityListFragment,
} from "../helpers/community-list-wire.ts";
import { canonicalJson, type ParsedCommunityList } from "../helpers/community-list.ts";
import type { ConcordDiagnostic } from "./diagnostics.ts";

/** Fully encoded fragment event ceiling, including encryption and signature. */
export const COMMUNITY_LIST_EVENT_MAX_BYTES = 65_536;

/**
 * What this device knows about the kind-33302 Community List: `unknown` (no relay completed
 * the read and nothing is held; with `requireCompletedRead`, no completed, fully ingested read
 * recorded since the last {@link ConcordCommunityListSync.beginRead}, whatever is held),
 * `confirmed-empty` (a relay completed the read and nothing is held), `partial` (some indexes
 * held, but the governing count is unsatisfied or its newest declaration is still locked) or
 * `complete`.
 */
export type CommunityListKnowledge = "unknown" | "confirmed-empty" | "partial" | "complete";

/** Minimal read-only status of the Community List; the shape may gain fields. */
export interface ConcordCommunityListStatus {
  /** What the device knows about the relay copy. */
  readonly knowledge: CommunityListKnowledge;
  /** Whether a write was refused and is waiting for a completed read. */
  readonly pending: boolean;
}

/** Options for {@link ConcordCommunityListSync}. */
export interface ConcordCommunityListSyncOptions {
  /** Refuse writes and repacks until a completed read is recorded ({@link ConcordCommunityListSync.markReadComplete})
   *  and the newest held declaration is decrypted; fragments held from before the last
   *  {@link ConcordCommunityListSync.beginRead} are not evidence on their own, and a write stops before its next
   *  fragment once the evidence it started with is withdrawn. */
  requireCompletedRead?: boolean;
  /**
   * Receives every authenticated winner, ciphertext exactly as received and including locked and dormant indexes, plus
   * the advisory governing count once a fragment is decrypted, every time a winner changes. It must store them
   * durably. A write or repack waits for it before its first signer call, before each fragment it publishes and after
   * the last (CORD-02 §8, D-01, D-08). A rejection stops a repack before its next fragment, or before any signer call
   * when it has published nothing yet; that includes a write whose fragment would overflow the event ceiling, which
   * needs a repack. A scoped write whose fragments fit still publishes, so a store that keeps failing (a full quota)
   * does not block those joins and leaves; report failures from the callback, as ConcordClient does with
   * `fragment-persist`.
   */
  persist?: (snapshot: { readonly events: readonly NostrEvent[]; readonly count?: number }) => Promise<void>;
  /** Receives background diagnostics such as dropped restored fragments; it never receives decrypted content. */
  onDiagnostic?: (diagnostic: ConcordDiagnostic) => void;
}

/**
 * Thrown only when `requireCompletedRead` is set and a write was attempted before a completed read was recorded, while
 * no held fragment is decrypted and the read did not confirm the list empty, or while the newest held declaration is
 * locked.
 */
export class CommunityListUnknownError extends Error {
  /** Names the unmet precondition: no completed read or decrypted fragment backs the write. */
  constructor() {
    super("The Community List has not been read and decrypted; the write is held");
    this.name = "CommunityListUnknownError";
  }
}

/**
 * Thrown by `ConcordClient` membership changes (joins, leaves and `createNewCommunity`) while the client is not
 * started, before anything is applied; start the client before changing memberships.
 */
export class ConcordClientNotStartedError extends Error {
  /** Names the unmet precondition: the client must be started. */
  constructor(message: string = "ConcordClient not started — call start() first") {
    super(message);
    this.name = "ConcordClientNotStartedError";
  }
}

/**
 * Thrown by `ConcordClient.start()`, membership changes and `unlockCommunityListFragments()` once the client was
 * disposed; `dispose()` is terminal, so create a new client. Extends {@link ConcordClientNotStartedError}, so existing
 * `instanceof` checks still match.
 */
export class ConcordClientDisposedError extends ConcordClientNotStartedError {
  /** Names the unmet precondition: a disposed client cannot be used again. */
  constructor() {
    super("ConcordClient was disposed — create a new client");
    this.name = "ConcordClientDisposedError";
  }
}

/** Self-encrypted fragment synchronization, usable independently of community engines. */
export class ConcordCommunityListSync {
  /** Per-index winners and completeness; ciphertext is tracked separately until unlocked. */
  readonly fragments: CommunityListFragments = new CommunityListFragments();
  private readonly seen = new Map<number, NostrEvent>();
  private tail: Promise<void> = Promise.resolve();
  private readonly requireCompletedRead: boolean;
  private readComplete = false;
  /** Bumped by every clear and every failed receive: only a read begun in the current epoch may record (D-29). */
  private readEpoch = 0;
  /** Fragments that failed to be received, by id; kept across clears until a receive of them succeeds (D-29). */
  private readonly failed = new Map<string, NostrEvent>();
  private pending = false;
  private readonly statusSubject: BehaviorSubject<ConcordCommunityListStatus>;
  /** Emits the status whenever knowledge or pending changes. */
  readonly status$: Observable<ConcordCommunityListStatus>;
  private readonly lockedSubject: BehaviorSubject<boolean> = new BehaviorSubject(false);
  /**
   * Emits whether a held copy is not decrypted yet, on every change. A locked copy blocks repacks, and any write that
   * targets it or whose newest declaration is locked, until it is unlocked (D-04, D-05).
   */
  readonly locked$: Observable<boolean> = this.lockedSubject.asObservable();
  private readonly persist: ConcordCommunityListSyncOptions["persist"];
  private readonly onDiagnostic: ConcordCommunityListSyncOptions["onDiagnostic"];
  /** The newest persist call, awaited before a fragment is published (D-08). */
  private persisted: Promise<void> = Promise.resolve();
  /** Identifies the last snapshot handed to persist, so an unchanged one is not handed over again. */
  private handed = "";
  private persistFailed = false;
  /** Indexes whose kept list-level fields were reported since fragment 0 was last readable: each is reported once. */
  private readonly retainedReported = new Set<number>();

  /** Use the owning user's signer and an awaited publication callback. */
  constructor(
    private readonly signer: ISigner,
    private readonly publish: (event: NostrEvent) => Promise<void>,
    options: ConcordCommunityListSyncOptions = {},
  ) {
    this.requireCompletedRead = options.requireCompletedRead ?? false;
    this.persist = options.persist;
    this.onDiagnostic = options.onDiagnostic;
    this.statusSubject = new BehaviorSubject(this.status);
    this.status$ = this.statusSubject.asObservable();
  }

  /** Current knowledge and pending state (minimal and extensible, D-16). */
  get status(): ConcordCommunityListStatus {
    const held = new Set([...this.seen.keys(), ...this.fragments.indexes]).size;
    // With the gate, fragments held from an earlier read (an earlier start) are not evidence: the relay may hold newer.
    const knowledge: CommunityListKnowledge = held === 0
      ? (this.readComplete ? "confirmed-empty" : "unknown")
      : this.requireCompletedRead && !this.readComplete
      ? "unknown"
      : (this.fragments.complete && !this.newestDeclarationUnread() ? "complete" : "partial");
    return { knowledge, pending: this.pending };
  }

  /**
   * Begin a kind-33302 read: forget earlier evidence and return the token only this read may record with. A clear, a
   * newer `beginRead` or a failed receive after this call makes the token stale (D-29).
   */
  beginRead(): number {
    this.clearReadEvidence();
    return this.readEpoch;
  }

  /**
   * Record that the read begun with `token` completed on a relay and every fragment it returned was received (kind
   * 13302 is import-only, D-22). Returns false, recording nothing, when the token is stale or any fragment that failed
   * to be received ({@link unreceived}) is still outstanding: it may carry a newer declaration.
   */
  markReadComplete(token: number): boolean {
    if (token !== this.readEpoch || this.failed.size > 0) return false;
    this.readComplete = true;
    this.refreshStatus();
    return true;
  }

  /** Forget read evidence without starting a read, so no read begun earlier can record. */
  clearReadEvidence(): void {
    this.readEpoch++;
    this.readComplete = false;
    this.refreshStatus();
  }

  /** Fragments that failed to be received; each read must receive them again before it can record. */
  get unreceived(): NostrEvent[] {
    return [...this.failed.values()];
  }

  /**
   * Whether a held copy is not decrypted yet. A locked copy blocks repacks, and any write that targets it or whose
   * newest declaration is locked, until it is unlocked (D-04, D-05).
   */
  get locked(): boolean {
    return [...this.seen].some(([index, event]) => this.fragments.get(index)?.id !== event.id);
  }

  private refreshStatus(): void {
    const next = this.status;
    const prior = this.statusSubject.value;
    if (next.knowledge !== prior.knowledge || next.pending !== prior.pending) this.statusSubject.next(next);
    const locked = this.locked;
    if (locked !== this.lockedSubject.value) this.lockedSubject.next(locked);
  }

  /**
   * CORD-02 §8: the newest seen declaration governs the count, so while any copy at that age is locked (or failed to
   * decrypt) the count the decrypted fragments declare may be stale, and a write would publish it as the newest.
   */
  private newestDeclarationUnread(): boolean {
    const newest = Math.max(...[...this.seen.values()].map((event) => event.created_at));
    return [...this.seen].some(([index, event]) =>
      event.created_at === newest && this.fragments.get(index)?.id !== event.id
    );
  }

  /**
   * CORD-02 §8 / D-15: a write over zero decrypted versions plans `scoped(0)` with the default count of 1, so it is
   * allowed only when a completed read confirmed the list empty. Held but unread ciphertext is not knowledge, and a
   * locked newest declaration leaves the governing count unknown.
   */
  private assertKnown(): void {
    if (!this.requireCompletedRead) return;
    const { knowledge } = this.status; // "unknown" until a completed read is recorded, whatever is held
    const known = knowledge !== "unknown" && !this.newestDeclarationUnread() &&
      (this.fragments.indexes.length > 0 || knowledge === "confirmed-empty");
    if (known) return;
    this.pending = true;
    this.refreshStatus();
    throw new CommunityListUnknownError();
  }

  /** Settle a held write without writing, once the caller has verified the relay copy already carries it. */
  clearPending(): void {
    this.pending = false;
    this.refreshStatus();
  }

  /** Authenticate an incoming event before retaining it, then decrypt on explicit request. */
  async receive(event: NostrEvent, unlock: boolean = true): Promise<boolean> {
    const shaped = this.shape(event);
    if (!shaped) return false;
    const accepted = this.accept(shaped.wire, await this.authenticatedPubkey(shaped.wire));
    if (!accepted) return false;
    const { wire, index } = accepted;
    const prior = this.seen.get(index);
    if (prior && this.outranks(prior, wire)) return false;
    this.seen.set(index, wire);
    this.refreshStatus();
    if (prior?.id !== wire.id) this.kickPersist();
    if (!unlock) return false;
    if (this.fragments.get(index)?.id === wire.id) return false;
    if (!this.signer.nip44) throw new Error("NIP-44 signer required");
    const document = decodeCommunityListFragment(await this.signer.nip44.decrypt(wire.pubkey, wire.content));
    if (this.seen.get(index)?.id !== wire.id) return false;
    const accepts = this.fragments.receive({ index, id: wire.id, created_at: wire.created_at, document });
    this.refreshStatus();
    // The advisory count can only be known once a fragment is decrypted; the store skips an unchanged record.
    if (accepts) this.kickPersist();
    return accepts;
  }

  /**
   * CORD-02 §8, D-03, D-04: put stored fragments back after a restart. Every event passes the same authentication as
   * {@link receive} (author, kind, canonical `d`, signature) and the NIP-01 winner per index is retained, still locked:
   * nothing is decrypted, and restored copies are never read evidence. With `requireCompletedRead` (as ConcordClient
   * uses it), knowledge stays `unknown` and writes stay refused until a relay read completes. Without it (the standalone
   * default) restored copies count like any held fragment: knowledge becomes `partial`, then `complete` once they are
   * decrypted, and writes are then allowed with no relay read. Returns the winners kept and how many events were
   * refused; it never throws. A signer that cannot name its key refuses every event without touching the read evidence.
   */
  async restore(events: readonly NostrEvent[]): Promise<{ restored: NostrEvent[]; dropped: number }> {
    let pubkey: string;
    try {
      pubkey = await this.signer.getPublicKey();
    } catch (error) {
      this.diagnose(error);
      return { restored: [], dropped: events.length };
    }
    let dropped = 0;
    const offered = new Set<string>();
    for (const event of events) {
      try {
        const accepted = this.accept(event, pubkey);
        if (!accepted) {
          dropped++;
          continue;
        }
        const { wire, index } = accepted;
        const prior = this.seen.get(index);
        if (prior?.id !== wire.id) {
          if (prior && this.outranks(prior, wire)) continue;
          this.seen.set(index, wire);
        }
        offered.add(wire.id);
      } catch {
        dropped++; // a record entry that cannot be read as an event is refused like a forged one
      }
    }
    this.refreshStatus();
    this.kickPersist();
    if (dropped > 0) this.diagnose(new Error(`${dropped} stored Community List fragment(s) were dropped`));
    const restored = [...this.seen].filter(([, event]) => offered.has(event.id)).sort(([a], [b]) => a - b);
    return { restored: restored.map(([, event]) => event), dropped };
  }

  /** Structural checks shared by every ingest path: a clone with string-only tags, kind 33302 and one canonical `d`. */
  private shape(event: NostrEvent): { wire: NostrEvent; index: number } | undefined {
    return communityListFragmentShape(event);
  }

  /** The one authentication path for relay, restored and app-supplied events: shape, author, then the signature. */
  private accept(event: NostrEvent, pubkey: string): { wire: NostrEvent; index: number } | undefined {
    return authenticCommunityListFragment(event, pubkey);
  }

  /** NIP-01 replaceable order: whether `prior` beats `wire` (newer `created_at`, then the lower id). */
  private outranks(prior: NostrEvent, wire: NostrEvent): boolean {
    return prior.created_at > wire.created_at || (prior.created_at === wire.created_at && prior.id < wire.id);
  }

  private diagnose(error: unknown): void {
    this.report({ stage: "fragment-restore", error });
  }

  private report(diagnostic: ConcordDiagnostic): void {
    try {
      this.onDiagnostic?.(diagnostic);
    } catch {
      // A consumer callback must never break restoring or a write.
    }
  }

  /**
   * Hand the current winners to `persist` unless that exact snapshot was already handed over and stored. Receive does
   * not wait on the store (D-08 holds the publication instead), and a failure is kept for the next
   * {@link durable} to await or retry, never left as an unhandled rejection.
   */
  private kickPersist(): void {
    const persist = this.persist;
    if (!persist) return;
    const events = [...this.seen].sort(([a], [b]) => a - b).map(([, event]) => event);
    const count = this.fragments.indexes.length > 0 ? this.fragments.count : undefined;
    const key = `${events.map((event) => event.id).join(",")}|${count ?? ""}`;
    if (key === this.handed && !this.persistFailed) return;
    this.handed = key;
    const promise = (async () => await persist({ events, count }))();
    this.persisted = promise;
    this.persistFailed = false;
    promise.catch(() => {
      if (this.persisted === promise) this.persistFailed = true;
    });
  }

  /** Resolves once the winners held now are stored; rejects with the store's error, which stops a write (D-08). */
  private durable(): Promise<void> {
    this.kickPersist();
    return this.persisted;
  }

  /** A fragment that cannot be authenticated was never seen and may be a newer declaration: it is kept until a later
   *  receive succeeds, and no read begun before the failure is evidence. */
  private async authenticatedPubkey(wire: NostrEvent): Promise<string> {
    let pubkey: string;
    try {
      pubkey = await this.signer.getPublicKey();
    } catch (error) {
      this.failed.set(wire.id, wire);
      this.clearReadEvidence();
      throw error;
    }
    this.failed.delete(wire.id);
    return pubkey;
  }

  /** Any locked or failed newest copy blocks overwriting that coordinate. */
  private assertReadable(index: number): void {
    if (this.seen.get(index)?.id !== this.fragments.get(index)?.id) throw new Error("Newest fragment is unread");
  }

  /** Write one membership's containing fragments, allocating only with complete state; with `requireCompletedRead`,
   *  withdrawn read evidence refuses every fragment not yet published ({@link CommunityListUnknownError}).
   *  `assertCurrent` runs when the write's turn comes, before any signer call, and again before every fragment; a throw
   *  stops the write (the default does nothing). With `persist`, the write first waits until every fragment accepted
   *  so far is stored before the signer is asked, and again before each fragment. A scoped write publishes even when
   *  `persist` rejects. A write that needs a repack (a fragment that would overflow the event ceiling) runs as one and
   *  stops like {@link repack}, before the signer is asked for anything when the record cannot be stored (WR-02). */
  write(local: ParsedCommunityList, communityIds: string[], assertCurrent: () => void = () => {}): Promise<void> {
    return this.serial(async () => {
      assertCurrent(); // a call refused while it waited on the serial tail never prompts the signer (D-30)
      // D-08: the record catches up with every accepted fragment before the signer is asked for anything, as in a
      // repack. Planning starts only after this wait, so an arrival during it is part of the plan or refuses it.
      await this.stored(false);
      assertCurrent();
      this.assertKnown();
      const epoch = this.readEpoch;
      // The newest declaration is locked or failed (including when only ciphertext is held): the planned count could
      // be stale, and publishing it as the newest declaration would hide the held fragments.
      if (this.newestDeclarationUnread()) throw new Error("Newest fragment is unread");
      const indexes = new Set<number>();
      const destination = this.fragments.indexes.find((index) => index < this.fragments.count) ?? 0;
      for (const id of communityIds) {
        const held = this.fragments.indexesFor(id);
        for (const index of held.length ? held : [destination]) indexes.add(index);
      }
      // CORD-02 §8 / D-18: list-level fields belong on fragment 0. A target above zero that holds fields fragment 0
      // lacks brings fragment 0 into the write, which publishes first (ascending order) with their union; when fragment 0
      // is not held and readable, those fields stay on their own fragment and the retention is reported once.
      const zeroReadable = this.fragments.get(0) !== undefined && this.seen.get(0)?.id === this.fragments.get(0)!.id;
      const retaining = new Set<number>();
      if (zeroReadable) this.retainedReported.clear();
      for (const index of [...indexes].filter((i) => i >= 1)) {
        if (!this.fragments.strandedExtensionKeys(index).length) continue;
        if (zeroReadable) indexes.add(0);
        else {
          retaining.add(index);
          if (this.retainedReported.has(index)) continue;
          this.retainedReported.add(index);
          // Field names and values are decrypted content: the report carries only the index and a fixed message.
          this.report({
            stage: "fragment-extension-retained",
            key: String(index),
            error: new Error(`list-level fields stay on Community List fragment ${index} until fragment 0 is held`),
          });
        }
      }
      const drafts = new Map<number, CommunityListFragment>();
      for (const index of [...indexes].sort((a, b) => a - b)) {
        this.assertReadable(index);
        const ids = new Set(communityIds.filter((id) => {
          const held = this.fragments.indexesFor(id);
          return held.includes(index) || (!held.length && index === destination);
        }));
        drafts.set(
          index,
          this.fragments.scoped(index, {
            ...local,
            entries: local.entries.filter((e) => ids.has(e.community_id)),
            tombstones: local.tombstones.filter((t) => ids.has(t.community_id)),
          }, retaining.has(index)),
        );
      }
      // WR-02: a draft that overflows its fragment needs a repack, which keeps the strict persist barrier (D-21). Its
      // size is known without the signer, so the repack checks the store before the signer is asked for anything.
      const now = Math.floor(Date.now() / 1000);
      const overflowing = [...drafts].some(([index, document]) =>
        !this.unchanged(index, document) &&
        this.overflows(
          index,
          fragmentEventSize(index, document, Math.max(now, (this.seen.get(index)?.created_at ?? 0) + 1)),
        )
      );
      const baseline = this.baseline();
      const prepared = overflowing ? new Map<number, NostrEvent>() : await this.prepare(drafts, assertCurrent);
      // The estimate is exact up to the timestamp digits; a signed event is checked again all the same.
      if (overflowing || [...prepared].some(([index, event]) => this.overflows(index, eventSize(event)))) {
        await this.repackNow(local, assertCurrent, epoch);
        this.clearPending();
        return;
      }
      await this.publishPrepared(prepared, baseline, assertCurrent, epoch, false);
      this.clearPending();
    });
  }

  /** Repack only complete, fully unlocked state; dropped coordinates are explicitly emptied. Withdrawn read evidence
   *  stops it before its next publication, as for {@link write}. */
  repack(local: ParsedCommunityList, assertCurrent: () => void = () => {}): Promise<void> {
    return this.serial(async () => {
      assertCurrent(); // as for write(): refused before any signer work
      this.assertKnown();
      await this.repackNow(local, assertCurrent, this.readEpoch);
      this.clearPending();
    });
  }

  private async repackNow(local: ParsedCommunityList, assertCurrent: () => void, epoch: number): Promise<void> {
    assertCurrent(); // an oversized write refused while it signed prompts nothing more (D-30)
    for (const index of this.seen.keys()) this.assertReadable(index);
    // D-08: a record that cannot be stored stops the repack before the signer is prompted for anything.
    await this.durable();
    assertCurrent();
    const baseline = this.baseline();
    // Residue an interrupted repack left at dormant indexes; the drafts below merge it before it is emptied (D-20).
    const dormant = this.fragments.dormantResidue;
    const timestamp =
      Math.max(Math.floor(Date.now() / 1000), ...[...this.seen.values()].map((event) => event.created_at)) + 4;
    // Pack without prompting a remote signer for every trial prefix; check every actual signed event below.
    const drafts = await this.fragments.repack(
      local,
      async (index, document) => fragmentEventSize(index, document, timestamp),
    );
    const count = drafts.get(0)!.frags;
    const final = new Map([...drafts].filter(([index]) => index < count));
    const base = this.fragments.count;
    const temporaryCount = base + count;
    const publishPhase = async (documents: Map<number, CommunityListFragment>, expected: Map<number, string>) => {
      // A new count must outrank declarations at every index, including future-dated ones.
      const floor =
        Math.max(Math.floor(Date.now() / 1000), ...[...this.seen.values()].map((event) => event.created_at)) + 1;
      const events = new Map<number, NostrEvent>();
      for (const [index, document] of documents) {
        const event = await this.sign(index, document, floor, assertCurrent);
        if (eventSize(event) > COMMUNITY_LIST_EVENT_MAX_BYTES) {
          throw new Error("Community List fragment exceeds event ceiling");
        }
        events.set(index, event);
      }
      await this.publishPrepared(events, expected, assertCurrent, epoch, true);
    };
    // CORD-02 §8, D-17: every prefix of these stages must leave a complete List, because a missing fragment means
    // unseen, never empty, and a tail gap cannot be repaired without a journal (D-01).
    // 1. Staging copies sit at base + index, at or above the old count, and declare the OLD count: they stay dormant
    //    and out of range, so each acknowledged staging prefix is the old complete List with extra dormant content.
    const staging = new Map<number, CommunityListFragment>();
    for (const [index, document] of final) {
      staging.set(base + index, { frags: base, entries: document.entries, tombstones: document.tombstones });
    }
    await publishPhase(staging, baseline);
    // 2. Copies declare the temporary count, the first raise of the count: every index below it is held (the old
    //    ones and all staging copies), and each copy already carries final content, so no prefix loses a record.
    const copies = new Map([...final].map(([index, document]) => [index, { ...document, frags: temporaryCount }]));
    await publishPhase(copies, baseline);
    // 3. Only after every final destination is acknowledged may the smaller count hide staging.
    await publishPhase(final, baseline);
    // 4. Empty every index above the new count that is held: the staging range and any dormant residue captured
    //    before the first publication. Never publish at an index that was never held (CORD-02 §8).
    const cleanup = new Map<number, CommunityListFragment>();
    for (let index = count; index < temporaryCount; index++) {
      cleanup.set(index, { frags: count, entries: [], tombstones: [] });
    }
    for (const index of dormant) {
      if (index >= temporaryCount) cleanup.set(index, { frags: count, entries: [], tombstones: [] });
    }
    await publishPhase(new Map([...cleanup].sort(([a], [b]) => a - b)), baseline);
  }

  private baseline(): Map<number, string> {
    return new Map([...this.seen].map(([index, event]) => [index, event.id]));
  }

  /** `assertCurrent` runs before every signer call, so a refused write stops prompting between fragments (D-30). */
  private async sign(
    index: number,
    document: CommunityListFragment,
    minimumTimestamp = 0,
    assertCurrent: () => void = () => {},
  ): Promise<NostrEvent> {
    if (!this.signer.nip44) throw new Error("NIP-44 signer required");
    this.assertReadable(index);
    assertCurrent();
    const pubkey = await this.signer.getPublicKey();
    assertCurrent();
    const content = await this.signer.nip44.encrypt(pubkey, encodeCommunityListFragment(document));
    assertCurrent();
    return await this.signer.signEvent({
      kind: COMMUNITY_LIST_FRAGMENT_KIND,
      tags: [["d", String(index)]],
      content,
      created_at: Math.max(
        minimumTimestamp,
        Math.floor(Date.now() / 1000),
        (this.seen.get(index)?.created_at ?? 0) + 1,
      ),
    });
  }

  private async prepare(
    drafts: Map<number, CommunityListFragment>,
    assertCurrent: () => void,
  ): Promise<Map<number, NostrEvent>> {
    const prepared = new Map<number, NostrEvent>();
    for (const [index, document] of drafts) {
      if (this.unchanged(index, document)) continue;
      prepared.set(index, await this.sign(index, document, 0, assertCurrent));
    }
    return prepared;
  }

  /** Whether `document` is what the held, decrypted fragment at `index` already says; it is never re-signed. */
  private unchanged(index: number, document: CommunityListFragment): boolean {
    const held = this.fragments.get(index);
    return held !== undefined && canonicalJson(held.document) === canonicalJson(document);
  }

  /** Whether a scoped fragment of `bytes` at `index` overflows the event ceiling and needs a repack. A fragment that
   *  already exceeds it may be replaced by one no larger. */
  private overflows(index: number, bytes: number): boolean {
    const previous = this.seen.get(index);
    return bytes > COMMUNITY_LIST_EVENT_MAX_BYTES && (!previous || bytes >= eventSize(previous));
  }

  /** `required` (a repack stage) makes a `persist` rejection stop the publication; see {@link stored}. */
  private async publishPrepared(
    prepared: Map<number, NostrEvent>,
    baseline: Map<number, string>,
    assertCurrent: () => void,
    epoch: number,
    required: boolean,
  ): Promise<void> {
    for (const [index, event] of prepared) {
      // D-08: no fragment goes out while the stored record lags what is held. The wait comes first and every gate
      // below runs after it with no await before the publication, so a stop, withdrawn evidence or an arrival during
      // a slow storage write refuses this fragment (CR-01).
      await this.stored(required);
      if (this.seen.size !== baseline.size) throw new Error("Community List changed during signing");
      for (const [coordinate] of this.seen) {
        if (this.seen.get(coordinate)?.id !== baseline.get(coordinate)) {
          throw new Error("Community List changed during signing");
        }
      }
      this.assertReadable(index);
      assertCurrent();
      // D-31: evidence withdrawn since the write began (a stop, a newer read, a failed ingest) refuses what is left.
      if (this.requireCompletedRead && (!this.readComplete || this.readEpoch !== epoch)) {
        this.pending = true;
        this.refreshStatus();
        throw new CommunityListUnknownError();
      }
      await this.publish(event);
      await this.receive(event);
      baseline.set(index, event.id);
    }
    await this.stored(required); // a resolved repack is durable; so is a scoped write unless the store failed
  }

  /**
   * Wait until the record holds every accepted fragment. With `required` (a repack stage, D-08) a store failure
   * rejects, because the restarted client must find every acknowledged stage to repair from. A scoped write never
   * changes the count and replaces whole indexes, so publishing it while the record lags only adds a newer relay copy
   * of what the record would hold. Refusing would keep a leave or join off other devices for as long as the store
   * fails (a full quota), so the failure is left to `persist`, which reports it (WR-03). A join or leave that overflows
   * its fragment is a repack and waits strictly (WR-02).
   */
  private async stored(required: boolean): Promise<void> {
    if (required) return await this.durable();
    try {
      await this.durable();
    } catch {
      // Reported by the persist callback (ConcordClient: `fragment-persist`); the relay copy is the newest one now.
    }
  }

  /**
   * Stop waiting for serial tasks queued so far, so the next {@link write} or {@link repack} starts at once instead of
   * behind a task that may never settle (a signer prompt nobody answers; LIST-05, D-07). Call it only once every
   * abandoned task's `assertCurrent` refuses, as ConcordClient's lane does when it closes: an abandoned task that
   * resumes then publishes nothing, and a fragment it had already published is caught by the next task's baseline check.
   */
  abandon(): void {
    this.tail = Promise.resolve();
  }

  private serial(task: () => Promise<void>): Promise<void> {
    const pending = this.tail.then(task);
    this.tail = pending.catch(() => {});
    return pending;
  }
}

function eventSize(event: NostrEvent): number {
  return new TextEncoder().encode(JSON.stringify(event)).length;
}

/**
 * The encoded size of the signed fragment event for `document`, without a signer: NIP-44 v2 ciphertext and NIP-01
 * ids, keys and signatures have fixed lengths, so only `created_at` is assumed.
 */
function fragmentEventSize(index: number, document: CommunityListFragment, created_at: number): number {
  const plaintextBytes = new TextEncoder().encode(encodeCommunityListFragment(document)).length;
  const payloadBytes = 67 + nip44.v2.utils.calcPaddedLen(plaintextBytes);
  return eventSize({
    kind: COMMUNITY_LIST_FRAGMENT_KIND,
    pubkey: "0".repeat(64), // every key is 64 hex characters
    id: "0".repeat(64),
    sig: "0".repeat(128),
    created_at,
    tags: [["d", String(index)]],
    content: "x".repeat(4 * Math.ceil(payloadBytes / 3)),
  });
}
