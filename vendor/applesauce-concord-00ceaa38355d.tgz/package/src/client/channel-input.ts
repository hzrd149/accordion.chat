import { isRumorExpired } from "../helpers/expiration.ts";
import { EventStore } from "applesauce-core";
import { EventStoreSymbol, type Rumor } from "applesauce-core/helpers/event";
import type { ConcordRumorStore } from "./storage.ts";

const pending = new WeakMap<ConcordRumorStore, Map<string, Promise<void>>>();

/** Retain authenticated channel inputs before current-ban/effect projection (CORD-03 §3).
 * The upstream kind-5 manager prunes history and intercepts requests, so bypass it
 * only for already decoded/binding-checked deletion rumors. Other kinds use add.
 * `accepted` runs before the write only when the rumor is unexpired by the library's strict rule (`expiration <= now`,
 * CORD-08 §3, D-21). The upstream store rounds its clock to the second and parses tags differently, so it may still
 * refuse the rumor, such as in the last half-second before expiry; what a caller keeps in memory for it, such as an
 * Edit's seal, must also be judged by the signed expiry.
 */
export async function retainChannelInput(store: ConcordRumorStore, rumor: Rumor, accepted?: () => void): Promise<void> {
  if (isRumorExpired(rumor)) return;
  accepted?.();
  if (rumor.kind !== 5) {
    await store.add(rumor);
    return;
  }
  let writes = pending.get(store);
  if (!writes) pending.set(store, writes = new Map());
  const existing = writes.get(rumor.id);
  if (existing) {
    await existing;
    await retainDeletion(store, rumor);
    return;
  }
  const write = retainDeletion(store, rumor);
  writes.set(rumor.id, write);
  try {
    await write;
  } finally {
    writes.delete(rumor.id);
  }
}

async function retainDeletion(store: ConcordRumorStore, rumor: Rumor): Promise<void> {
  if (store.verifyEvent && !store.verifyEvent(rumor)) return;
  const cached = await store.getEvent(rumor.id);
  if (cached) {
    if (EventStore.copySymbolsToDuplicateEvent(rumor, cached)) await store.update(cached);
    return;
  }
  // Publish canonical memory identity only after the durable write succeeds.
  // Otherwise a failed write leaves a cache hit that suppresses every retry.
  const persisted = await store.database.add(rumor);
  const canonical = store.memory.add(rumor);
  const inserted = store.memory.add(persisted);
  EventStore.copySymbolsToDuplicateEvent(persisted, inserted);
  if (inserted === canonical) {
    Object.defineProperty(inserted, EventStoreSymbol, { value: store, configurable: true, writable: true });
    store.insert$.next(inserted);
  } else if (EventStore.copySymbolsToDuplicateEvent(rumor, inserted)) {
    await store.update(inserted);
  }
}
