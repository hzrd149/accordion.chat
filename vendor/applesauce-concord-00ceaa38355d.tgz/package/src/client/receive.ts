import type { EventStore } from "applesauce-core";
import { type NostrEvent, verifyWrappedEvent } from "applesauce-core/helpers/event";
import { getExpirationTimestamp } from "applesauce-core/helpers/expiration";
import { unixNow } from "applesauce-core/helpers/time";
import { isRumorExpired } from "../helpers/expiration.ts";
import { CONTROL_KIND, isDissolution } from "../helpers/control.ts";
import {
  decodeWrap,
  ENCRYPTED_SEAL_KIND,
  EPHEMERAL_GIFT_WRAP_KIND,
  GIFT_WRAP_KIND,
  PLAINTEXT_SEAL_KIND,
} from "../helpers/gift-wrap.ts";
import type { PlaneInfo } from "../helpers/keys.ts";
import type { DecodedEvent } from "../types.ts";

/** CORD-01 author binding: verify current wire bytes independently of SDK/store caches. */
export function verifyReceiveEnvelope(event: NostrEvent): boolean {
  try {
    if (event.kind !== GIFT_WRAP_KIND && event.kind !== EPHEMERAL_GIFT_WRAP_KIND) return false;
    return verifyWrappedEvent(structuredClone(event));
  } catch {
    return false;
  }
}

/** Authenticate envelopes and enforce plane seal policy and dissolution binding (CORD-02 §5/§9). */
export function decodeReceivedWrap(event: NostrEvent, info: PlaneInfo): DecodedEvent | null {
  try {
    // structuredClone strips symbol caches; decoding must also use the verified bytes.
    const wire = structuredClone(event);
    if (!verifyWrappedEvent(wire)) return null;
    const decoded = decodeWrap(wire, info.convKey);
    const plaintext = info.type === "control" || info.type === "dissolved";
    if (!decoded || decoded.sealKind !== (plaintext ? PLAINTEXT_SEAL_KIND : ENCRYPTED_SEAL_KIND)) return null;
    if (
      info.type === "control" &&
      (decoded?.sealKind !== PLAINTEXT_SEAL_KIND || decoded.rumor.kind !== CONTROL_KIND)
    ) return null;
    if (
      info.type === "dissolved" &&
      (!decoded || decoded.sealKind !== PLAINTEXT_SEAL_KIND || !info.communityId || !info.owner ||
        !isDissolution(decoded.rumor, { community_id: info.communityId, owner: info.owner }))
    ) return null;
    if (info.type === "channel" && isRumorExpired(decoded.rumor)) return null;
    return decoded;
  } catch {
    return null;
  }
}

/**
 * Store an authenticated wrap in the shared EventStore and return the store's canonical copy (CORD-08 §2). The wrap's
 * `expiration` tag is a relay hint, and the store refuses a past one by its own outer-tag rule, so a doctored outer tag
 * must not decide whether a verified, live rumor is retained: when the store refuses only for that reason, the caller's
 * wire is returned unstored and the signed rumor stays the sole judge of expiry. Returns null for any other refusal.
 * The fallback verifies the wire itself; callers still authenticate first and keep their pubkey and re-decode checks.
 *
 * The fallback covers Chat only: a wrap on a known non-channel plane keeps the store's refusal, so a control edition
 * that folds into state always has its seal in the store for a Refounding to recover (CORD-06 §2). `info` is omitted
 * by a sync without plane descriptors, which the engine runs only for channel message addresses; channel rekey syncs
 * pass their plane map, so a rekey wrap is refused here as it is on live receive.
 */
export function addWrap(eventStore: Pick<EventStore, "add">, wire: NostrEvent, info?: PlaneInfo): NostrEvent | null {
  const stored = eventStore.add(structuredClone(wire));
  if (stored || (info !== undefined && info.type !== "channel")) return stored;
  // Mirror the store's own refusal rule (`expiration <= now`) on a fresh clone so no symbol cache lands on the wire.
  const outer = getExpirationTimestamp(structuredClone(wire));
  // The store refuses a past outer tag before verifying, so authenticate the bytes it never checked (CORD-01).
  return outer && outer <= unixNow() && verifyReceiveEnvelope(wire) ? wire : null;
}

/** Reuse authenticated bytes within one receive operation, independently of SDK symbols. */
export function createReceiveDecoder(): (event: NostrEvent, info: PlaneInfo) => DecodedEvent | null {
  const cache = new Map<string, DecodedEvent | null>();
  return (event, info) => {
    try {
      const wire = structuredClone(event);
      // Include all signed fields and the plane capability, never just an event ID.
      const key = JSON.stringify([
        wire.id,
        wire.pubkey,
        wire.created_at,
        wire.kind,
        wire.tags,
        wire.content,
        wire.sig,
        info.type,
        info.communityId,
        info.owner,
        info.channelId,
        info.epoch,
        Array.from(info.convKey),
      ]);
      if (cache.has(key)) {
        const decoded = cache.get(key)!;
        // Store consumers may attach metadata or mutate rumors; keep cached evidence private.
        return decoded && !(info.type === "channel" && isRumorExpired(decoded.rumor)) ? structuredClone(decoded) : null;
      }
      const decoded = decodeReceivedWrap(wire, info);
      if (cache.size >= 256) cache.delete(cache.keys().next().value!);
      cache.set(key, decoded && structuredClone(decoded));
      return decoded;
    } catch {
      return null;
    }
  };
}
