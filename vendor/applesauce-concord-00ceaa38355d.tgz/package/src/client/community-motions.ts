// CORD-02 §8 / D-34: each community's own Join and Leave calls, with their Community List mutation and save, run in call
// order on one chain per community, so the newest guestbook motion (CORD-02 §5) and the list agree. Internal: never
// exported from a barrel.
//
// Lifecycle rule (D-30, D-32): app work queued in one client lifecycle never takes effect in a later lifecycle. It
// rejects with ConcordClientNotStartedError, or ConcordClientDisposedError after dispose(), as soon as its lifecycle
// ends, even if it is still waiting behind a call that never settles (a signer prompt the user dismissed). Every chain
// belongs to one lifecycle: `end()` settles the queued calls at once and the next lifecycle starts fresh chains.

import { JOIN_LEAVE_KIND, JOIN_VERB } from "../helpers/guestbook.ts";
import { rumorMs } from "../helpers/stream.ts";
import type { ConcordRumorStore } from "./storage.ts";

/** Per-community Join/Leave chains, each bound to the client lifecycle it was called in. */
export class CommunityMotions {
  private chains = new Map<string, Promise<void>>();
  private ended!: () => void;
  private ending = this.nextEnding();
  private readonly assertLifecycle: (lifecycle: number) => void;

  /** `assertLifecycle(lifecycle)` throws the client's typed error unless that lifecycle is still the running one. */
  constructor(assertLifecycle: (lifecycle: number) => void) {
    this.assertLifecycle = assertLifecycle;
  }

  /**
   * Run `work` after every earlier call of `cid` in this lifecycle settled (01-REVIEW-GAPS-3 CR-02). A queued call
   * waits on the chain or the lifecycle's end, whichever comes first, then re-checks its lifecycle before it runs
   * (01-REVIEW-GAPS-4 CR-02). `work` gets the same check to repeat after each of its own awaits. A rejected call never
   * blocks later ones.
   */
  run<T>(cid: string, lifecycle: number, work: (assertLive: () => void) => Promise<T>): Promise<T> {
    const assertLive = () => this.assertLifecycle(lifecycle);
    const chains = this.chains;
    const run = Promise.race([chains.get(cid) ?? Promise.resolve(), this.ending]).then(() => {
      assertLive();
      return work(assertLive);
    });
    const tail = run.then(() => {}, () => {});
    chains.set(cid, tail);
    void tail.then(() => chains.get(cid) === tail && chains.delete(cid));
    return run;
  }

  /** The lifecycle ended (`stop()`, so also `dispose()`): every queued call rejects now, and later calls start fresh. */
  end(): void {
    this.ended();
    this.ending = this.nextEnding();
    this.chains = new Map();
  }

  private nextEnding(): Promise<void> {
    return new Promise<void>((resolve) => (this.ended = resolve));
  }
}

/**
 * The attribution to re-publish for a community already joined: the `invite` tag of this user's newest own guestbook
 * motion (CORD-02 §5 order: millisecond time, then the lower rumor id) when it is a Join, `undefined` when that Join
 * has none, and otherwise (nothing held, or a Leave) `fallback`, this call's acceptance (CORD-05 §1 echo).
 */
export async function heldJoinAttribution(
  guestbook: ConcordRumorStore,
  pubkey: string,
  fallback?: { creator: string; label?: string },
): Promise<{ creator: string; label?: string } | undefined> {
  const own = await guestbook.getTimeline([{ kinds: [JOIN_LEAVE_KIND], authors: [pubkey] }]);
  const newest = own.reduce<(typeof own)[number] | undefined>((best, rumor) => {
    if (!best) return rumor;
    const order = rumorMs(rumor) - rumorMs(best);
    return order > 0 || (order === 0 && rumor.id < best.id) ? rumor : best;
  }, undefined);
  if (newest?.content.trim() !== JOIN_VERB) return fallback;
  const tag = newest.tags.find((t) => t[0] === "invite");
  return tag?.[1] ? { creator: tag[1], label: tag[2] } : undefined;
}
