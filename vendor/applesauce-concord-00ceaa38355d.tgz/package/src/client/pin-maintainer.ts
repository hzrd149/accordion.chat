// CORD-04 §7 Pins (Interaction with deletion): when a pinned message's own author deletes it, a curator with
// PIN_MESSAGES republishes the Pin List without that entry so every reader, not only readers who saw the deletion,
// stops seeing it. Phase 1 duty ownership (D-09): the single owner of every timer and retry here is the community's
// DutyScope; this module creates no timer of its own and stores no duty. Duties are derived from verified state each
// time the head, the channel inputs or the authority change, keyed by channel and selected head hash, so a replay of
// the same head publishes once and a new head supersedes the armed one. Internal: not exported from any barrel.
import { combineLatest, distinctUntilChanged, map, type Observable, startWith, type Subscription } from "rxjs";
import type { Rumor } from "applesauce-core/helpers/event";

import type { PlaneInfo } from "../helpers/keys.ts";
import { describePinList, encodePinList, type PinEntry, type PinListRead, type VerifiedPin } from "../helpers/pins.ts";
import { type PinUpkeepPlan, type PinUpkeepStage, planPinUpkeep } from "../helpers/pin-upkeep.ts";
import type { CommunityState, ConcordSyncPhase, DecodedEvent } from "../types.ts";
import type { ConcordDiagnostic } from "./diagnostics.ts";
import { DutyCancelledError, type DutyScope } from "./lifecycle.ts";
import { PinEditSeals } from "./pin-edit-seals.ts";

/**
 * The default window a witness (a holder who did not pin the message) waits before acting, in milliseconds, so the
 * pinner usually publishes first and the witnesses' re-check finds a moved head.
 */
export const PIN_UPKEEP_WITNESS_DELAY_MS: { min: number; max: number } = { min: 5_000, max: 30_000 };
/** Extra lifetime a duty gets beyond its delay: the duty scope measures lifetime from the first request. */
export const PIN_UPKEEP_GRACE_MS = 30_000;
/**
 * The most upkeep publications one channel may make inside a sliding window, so a hostile holder replaying heads cannot
 * turn upkeep into a publication storm. Upkeep beyond it is deferred, never dropped.
 */
export const PIN_UPKEEP_RATE_LIMIT: { max: number; windowMs: number } = { max: 4, windowMs: 600_000 };
/** The most message ids {@link PinMaintainer.notePinned} keeps per channel (a Pin List holds at most 25 entries). */
const MAX_PINNED_IDS = 25;
/** The most channels {@link PinMaintainer.notePinned} keeps ids for; the oldest channel is dropped first. */
const MAX_PINNED_CHANNELS = 256;
/** The most channels {@link PinMaintainer.noteRotation} keeps a mark for; the oldest channel is dropped first. */
const MAX_ROTATED_CHANNELS = 256;
/** The most skip reports remembered, so a long-lived community cannot grow the set without bound. */
const MAX_REPORTED_SKIPS = 256;

/** Options an app passes to turn automatic Pin List upkeep off. */
export interface ConcordPinUpkeepOptions {
  /**
   * Automatic pin upkeep: omitting a self-deleted pin from the Pin List, refreshing a pinned message's edit proof and
   * refreshing a private channel's Pin List after a rekey. On by default; `false` disables it. `pins$` and `pins()` are
   * unaffected and keep hiding self-deleted pins locally.
   */
  pinUpkeep?: boolean;
}

/** The epoch and conversation key a private channel's Pin List is sealed with. */
type SealKey = { epoch: number; convKey: Uint8Array };

/** What {@link PinMaintainer} needs from its community; closures keep it free of engine state. */
export interface PinMaintainerHost {
  /** The community's duty scope: the only owner of timers and retries. */
  duties(): DutyScope;
  /** Typed background diagnostics sink. */
  diagnostics: { report(diagnostic: ConcordDiagnostic): void };
  /** The local user's pubkey. */
  self: string;
  /** Current folded community state. */
  state(): CommunityState;
  /** Folded state changes. */
  state$: Observable<CommunityState>;
  /** The community sync phase. */
  phase(): ConcordSyncPhase;
  /** Sync phase changes. */
  phase$: Observable<ConcordSyncPhase>;
  /** Emits when channel key material changes outside the folded state. */
  materialChanged$: Observable<void>;
  /** Whether the local user may publish a Pin List now: not disposed or sealed, can sign Control, holds PIN_MESSAGES. */
  canWrite(): boolean;
  /** The opened selected Pin List of a channel. */
  pinList(channelId: string): PinListRead;
  /** The hash of the selected verified, unsuspended Pin List head, when there is one. */
  headHash(channelId: string): string | undefined;
  /** The exact content of that head. */
  headContent(channelId: string): string | undefined;
  /** A channel's kind 5 deletions and Edits, as the store retains them. */
  channelInputs(channelId: string): Observable<Rumor[]>;
  /** Verify a Pin List entry for a channel (memoized by the host). */
  verify(entry: PinEntry, channelId: string): VerifiedPin | undefined;
  /** The held current key a private channel's Pin List is sealed with, or undefined when none is held. */
  privateChannelKey(channelId: string): SealKey | undefined;
  /** A fingerprint of every key epoch held for a channel, current and older, which decides whether its list opens. */
  channelKeyEpochs(channelId: string): string;
  /** Publish a Pin List edition through the guarded required-acknowledgment path. */
  publishPinList(
    channelId: string,
    content: string,
    expectedHead: string,
    stage: PinUpkeepStage,
    check: () => void,
  ): Promise<void>;
}

/** Tuning for {@link PinMaintainer}. */
export interface PinMaintainerOptions {
  /** Window a witness waits before acting, in milliseconds; defaults to {@link PIN_UPKEEP_WITNESS_DELAY_MS}. */
  witnessDelayMs?: { min: number; max: number };
  /** Most upkeep publications per channel in a sliding window; defaults to {@link PIN_UPKEEP_RATE_LIMIT}. */
  rateLimit?: { max: number; windowMs: number };
}

interface Watch {
  rumors: Rumor[];
  sub?: Subscription;
}

/**
 * Keeps a community's Pin Lists free of messages their authors deleted and carrying the newest provable Edit of each
 * pinned message (CORD-04 §7).
 */
export class PinMaintainer {
  private readonly watched = new Map<string, Watch>();
  private readonly subscription: Subscription;
  private readonly witnessDelayMs: { min: number; max: number };
  private readonly rateLimit: { max: number; windowMs: number };
  /** Message ids this client pinned itself, per channel, insertion ordered so the oldest channel drops first. */
  private readonly pinned = new Map<string, Set<string>>();
  /** Times of this client's successful upkeep publications, per channel, within the rate-limit window. */
  private readonly published = new Map<string, number[]>();
  /** Channels this client just rekeyed, insertion ordered; the mark makes the next reseal of the channel immediate. */
  private readonly rotated = new Set<string>();
  /** Skip reports already made, as `<reason>:<channel>:<head>`, so each head is reported once. */
  private readonly reported = new Set<string>();
  /** Edit seals recovered at the route funnel, the one input an Edit proof needs that the library did not retain. */
  private readonly seals = new PinEditSeals();
  private disposed = false;

  constructor(private readonly host: PinMaintainerHost, options: PinMaintainerOptions = {}) {
    this.witnessDelayMs = options.witnessDelayMs ?? PIN_UPKEEP_WITNESS_DELAY_MS;
    this.rateLimit = options.rateLimit ?? PIN_UPKEEP_RATE_LIMIT;
    // Re-derive the watched set only when something it depends on changed, not on every chat-driven state emission.
    this.subscription = combineLatest([
      this.host.state$,
      this.host.phase$,
      this.host.materialChanged$.pipe(startWith(undefined)),
    ]).pipe(
      map(() => this.signature()),
      distinctUntilChanged(),
    ).subscribe(() => this.reconcile());
  }

  /**
   * Stop watching and release every subscription. Armed duties belong to the scope; they stop being eligible here and
   * the scope drops them at once.
   */
  dispose(): void {
    this.disposed = true;
    this.subscription.unsubscribe();
    for (const watch of this.watched.values()) watch.sub?.unsubscribe();
    this.watched.clear();
    this.seals.clear();
    this.rotated.clear();
    this.host.duties().reevaluate();
  }

  /**
   * Record a binding-checked channel-plane input at the route funnel, before its rumor is stored, so an Edit's seal is
   * held by the time the Edit can be planned. Sync rebuilds this on every start() before the community is live.
   */
  noteChannelInput(info: PlaneInfo, decoded: DecodedEvent): void {
    if (!this.disposed) this.seals.note(info, decoded, this.host.duties().clock.now() / 1000);
  }

  /**
   * Forget the Edit seals whose signed expiry passed by `now` (Unix seconds), so expired Edit text is not kept in memory
   * either, even when a store's own expiry timer removed the Edit before any purge found it (CORD-08 §3).
   */
  forgetExpiredInputs(now: number): void {
    this.seals.forgetExpired(now);
  }

  /**
   * Record that this client just rekeyed a private channel, so the reseal of its Pin List is a rotation duty that acts
   * at once instead of after the witness delay (CORD-04 §7: a Rotator SHOULD republish under the new key). The mark is
   * consumed by the next reseal request for the channel, holds at most 256 channels and is lost on restart, which only
   * costs latency.
   */
  noteRotation(channelId: string): void {
    this.rotated.delete(channelId);
    this.rotated.add(channelId);
    while (this.rotated.size > MAX_ROTATED_CHANNELS) {
      const oldest = this.rotated.values().next().value;
      if (oldest === undefined) break;
      this.rotated.delete(oldest);
    }
  }

  /**
   * Record the messages this client just pinned through `setPins` (D-08), so their deletion is upkept at once like a
   * pin this client authored. The record merges with the channel's previous one, keeping earlier ids only while they
   * are still in `present` (the message ids of the list just published), so a later `setPins` that adds a pin does not
   * forget this client's earlier ones. It keeps at most the 25 newest ids and 256 channels and is lost on restart,
   * which only costs latency.
   */
  notePinned(channelId: string, ids: readonly string[], present: ReadonlySet<string>): void {
    const merged = [...(this.pinned.get(channelId) ?? [])].filter((id) => present.has(id) && !ids.includes(id));
    merged.push(...ids);
    this.pinned.delete(channelId);
    this.pinned.set(channelId, new Set(merged.slice(-MAX_PINNED_IDS)));
    while (this.pinned.size > MAX_PINNED_CHANNELS) {
      const oldest = this.pinned.keys().next().value;
      if (oldest === undefined) break;
      this.pinned.delete(oldest);
    }
  }

  /** How many ids {@link notePinned} holds for a channel; for the bounded-record tests. */
  pinnedCount(channelId: string): number {
    return this.pinned.get(channelId)?.size ?? 0;
  }

  /** How many channels {@link notePinned} holds ids for; for the bounded-record tests. */
  pinnedChannelCount(): number {
    return this.pinned.size;
  }

  /** Report a deliberate skip once per reason, channel and head. Diagnostics carry the channel id and reason only. */
  private reportSkip(reason: "rate-limited" | "over-cap" | "private-era-list", channelId: string, head: string): void {
    const id = `${reason}:${channelId}:${head}`;
    if (this.reported.has(id)) return;
    this.reported.add(id);
    while (this.reported.size > MAX_REPORTED_SKIPS) {
      const oldest = this.reported.values().next().value;
      if (oldest === undefined) break;
      this.reported.delete(oldest);
    }
    const message = reason === "rate-limited"
      ? "pin upkeep postponed: per-channel rate limit reached"
      : reason === "over-cap"
      ? "pin upkeep skipped: the rewritten Pin List exceeds the content ceiling"
      : "pin upkeep skipped: the Pin List is a private-era list on a public channel";
    this.host.diagnostics.report({ stage: "pin-upkeep-skipped", reason, key: channelId, error: new Error(message) });
  }

  /** When the next upkeep publication may run for a channel, as a delay from now: 0 while the window has room. */
  private rateLimitDelay(channelId: string): number {
    const now = this.host.duties().clock.now();
    const stamps = (this.published.get(channelId) ?? []).filter((at) => at > now - this.rateLimit.windowMs);
    this.published.set(channelId, stamps);
    if (stamps.length < this.rateLimit.max) return 0;
    return stamps[stamps.length - this.rateLimit.max] + this.rateLimit.windowMs - now;
  }

  /**
   * Everything {@link reconcile} and the plans read from the host, cheaply: phase, authority, per channel head, current
   * key and held key epochs (an older held key can make a sealed list readable), and the ban list (which decides the
   * local Edits a plan may bundle).
   */
  private signature(): string {
    const live = this.host.phase() === "live" && this.host.canWrite();
    if (!live) return "idle";
    const state = this.host.state();
    const channels = state.channels.map(({ channel_id: id, private: isPrivate }) => {
      const keys = isPrivate
        ? `${this.host.privateChannelKey(id)?.epoch ?? "none"}/${this.host.channelKeyEpochs(id)}`
        : "public";
      return [id, this.host.headHash(id) ?? "", keys].join(":");
    }).join("|");
    return `${channels}#${[...state.banlist].sort().join(",")}`;
  }

  private reconcile(): void {
    if (this.disposed) return;
    const wanted = new Set<string>();
    if (this.host.phase() === "live" && this.host.canWrite()) {
      for (const channel of this.host.state().channels) {
        if (this.host.headHash(channel.channel_id) === undefined) continue;
        const list = this.host.pinList(channel.channel_id);
        if (list.available && list.entries.length > 0) wanted.add(channel.channel_id);
      }
    }
    // Once live, a channel that left the folded state keeps no seals; before then the state may still be filling.
    if (this.host.phase() === "live") {
      const present = new Set(this.host.state().channels.map((channel) => channel.channel_id));
      for (const channelId of this.seals.channelIds()) if (!present.has(channelId)) this.seals.dropChannel(channelId);
    }
    for (const [channelId, watch] of [...this.watched]) {
      if (wanted.has(channelId)) continue;
      watch.sub?.unsubscribe();
      this.watched.delete(channelId);
    }
    for (const channelId of wanted) {
      if (this.watched.has(channelId)) continue;
      const watch: Watch = { rumors: [] };
      this.watched.set(channelId, watch);
      watch.sub = this.host.channelInputs(channelId).subscribe((rumors) => {
        watch.rumors = rumors;
        this.evaluate(channelId);
      });
    }
    for (const channelId of this.watched.keys()) this.evaluate(channelId);
  }

  /** Plan from current state; used both to decide a request and to re-plan at fire time. */
  private plan(channelId: string): { plan: PinUpkeepPlan; list: PinListRead; key: SealKey | undefined } {
    const channel = this.host.state().channels.find((value) => value.channel_id === channelId);
    const now = this.host.duties().clock.now() / 1000;
    const list = this.host.pinList(channelId);
    const key = channel?.private ? this.host.privateChannelKey(channelId) : undefined;
    const plan = channel
      ? planPinUpkeep({
        channelId,
        list,
        headForm: describePinList(this.host.headContent(channelId)),
        channelPrivate: channel.private,
        sealKeyEpoch: key?.epoch,
        rumors: this.watched.get(channelId)?.rumors ?? [],
        editProof: (pin, edit) => this.seals.proof(channelId, pin, edit, now),
        now,
        isBanned: (pubkey) => this.host.state().banlist.has(pubkey),
        verify: (entry, id) => this.host.verify(entry, id),
      })
      : { kind: "none" as const };
    return { plan, list, key };
  }

  private evaluate(channelId: string): void {
    if (this.disposed) return;
    const headHash = this.host.headHash(channelId);
    if (headHash === undefined) return;
    const { plan, list } = this.plan(channelId);
    // A blocked plan (a sealed head on a now-public channel) is never re-formed as public: no duty is requested.
    if (plan.kind === "blocked") return this.reportSkip(plan.reason, channelId, headHash);
    if (plan.kind !== "rewrite") return;
    // The pinner is an entry's proven author or the client that pinned it through setPins (D-08).
    const recorded = this.pinned.get(channelId);
    const own = list.available && list.entries.some((entry) => {
      const verified = this.host.verify(entry, channelId);
      return verified !== undefined && plan.affected.includes(verified.rumor.id) &&
        (verified.rumor.pubkey === this.host.self || recorded?.has(verified.rumor.id) === true);
    });
    const duties = this.host.duties();
    const { min, max } = this.witnessDelayMs;
    // The pinner and a reseal's rotator act at once; every other holder waits a bounded random delay and re-checks
    // the head first.
    const rotating = plan.stage === "pin-rekey-refresh" && this.rotated.has(channelId);
    const witnessDelayMs = own || rotating ? 0 : min + Math.floor(duties.clock.random() * (max - min));
    // A channel that already made its share of publications waits for the window to free; the duty is deferred, not lost.
    const limitDelayMs = this.rateLimitDelay(channelId);
    const delayMs = Math.max(witnessDelayMs, limitDelayMs);
    const eligible = () =>
      !this.disposed && this.host.phase() === "live" && this.host.canWrite() &&
      this.host.state().channels.some((value) => value.channel_id === channelId) &&
      this.host.headHash(channelId) === headHash;
    const result = duties.request({
      key: `pin-upkeep:${channelId}:${headHash}`,
      slot: `pin-upkeep:${channelId}`,
      stage: plan.stage,
      delayMs,
      lifetimeMs: delayMs + PIN_UPKEEP_GRACE_MS,
      eligible,
      run: async (context) => {
        // Nothing to publish at fire time (an Edit expired or lost its seal, a key went missing) is a cancellation,
        // not a success: settling would make every later request for this head answer quiet and drop new due work.
        const current = this.plan(channelId);
        if (current.plan.kind !== "rewrite") throw new DutyCancelledError("pin upkeep no longer due");
        const { plan: rewrite, key } = current;
        // One key snapshot seals the content; a missing key was already refused by the planner.
        const sealing = rewrite.form === "sealed" ? key : undefined;
        if (rewrite.form === "sealed" && !sealing) throw new DutyCancelledError("pin upkeep has no sealing key");
        let content: string;
        try {
          content = encodePinList(rewrite.entries, sealing);
        } catch {
          // The rewrite cannot be encoded within the ceiling, now or on any retry of this head: report it once and
          // settle the key instead of rethrowing into retries that could only fail the same way.
          return this.reportSkip("over-cap", channelId, headHash);
        }
        context.assertAlive();
        await this.host.publishPinList(channelId, content, headHash, rewrite.stage, () => context.assertAlive());
        const stamps = this.published.get(channelId) ?? [];
        stamps.push(duties.clock.now());
        this.published.set(channelId, stamps);
      },
    });
    // The mark covers one reseal request, whether it armed a duty or coalesced into an armed one.
    if (rotating) this.rotated.delete(channelId);
    if (result === "armed" && limitDelayMs > 0) this.reportSkip("rate-limited", channelId, headHash);
  }
}
