// CORD-02 §8: "a missing fragment means unseen, and a short read means incomplete". A
// self-encrypted list read therefore reports per-relay completion evidence, never just
// the events it saw: an all-error, liveness-skipped, timed-out or cancelled read is
// incomplete and must not be treated as an empty list (LIST-01, D-13, D-21).

import {
  distinctUntilChanged,
  filter,
  firstValueFrom,
  forkJoin,
  merge,
  NEVER,
  type Observable,
  switchMap,
  takeUntil,
  tap,
  timer,
  toArray,
} from "rxjs";
import { type EventStore, mapEventsToStore } from "applesauce-core";
import { onlyEvents } from "applesauce-relay/operators";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { verifyWrappedEvent } from "applesauce-core/helpers/event";
import {
  createSyncLoader,
  type SyncAuthHandler,
  type SyncLoaderStatus,
  type SyncRelayState,
} from "applesauce-loaders/loaders";
import type { PublishResponse, RelayAuthHandler, RelayPool } from "applesauce-relay";
import { COMMUNITY_LIST_FRAGMENT_KIND } from "../helpers/community-list-wire.ts";
import { communityListFragmentIndex } from "./community-list-fragments.ts";
import { FragmentPersistError, FragmentRecordUnreadableError } from "./community-list-store.ts";
import { systemClock } from "./lifecycle.ts";

/** Per-relay stall bound for a Community List read; a silent relay fails closed after this long. */
export const COMMUNITY_LIST_READ_TIMEOUT_MS: number = 8_000;

/**
 * Overall bound for one Community List read, auth phases included: the per-relay stall clock is suspended while a
 * relay waits for NIP-42 auth, so without this a remote signer that never answers could hold a read open for minutes.
 */
export const COMMUNITY_LIST_READ_DEADLINE_MS: number = 15_000;

/**
 * CORD-02 §8: the shape every kind-33302 ingest path requires before anything is retained: a clone with string-only
 * tags, the fragment kind and exactly one canonical `d` index.
 */
export function communityListFragmentShape(event: unknown): { wire: NostrEvent; index: number } | undefined {
  if (typeof event !== "object" || event === null) return undefined;
  const wire = structuredClone(event) as NostrEvent;
  if (
    !Array.isArray(wire.tags) ||
    !wire.tags.every((tag) => Array.isArray(tag) && tag.every((value) => typeof value === "string"))
  ) return undefined;
  const index = communityListFragmentIndex(wire.tags.find((t) => t[0] === "d")?.[1]);
  if (
    wire.kind !== COMMUNITY_LIST_FRAGMENT_KIND || index === undefined ||
    wire.tags.filter((t) => t[0] === "d").length !== 1
  ) return undefined;
  return { wire, index };
}

/**
 * The one authentication of a kind-33302 fragment, whether a relay served it, the stored record restored it or the app
 * supplied it: its {@link communityListFragmentShape}, `pubkey` as its author and a valid id and signature.
 */
export function authenticCommunityListFragment(
  event: unknown,
  pubkey: string,
): { wire: NostrEvent; index: number } | undefined {
  const shaped = communityListFragmentShape(event);
  return shaped && shaped.wire.pubkey === pubkey && verifyWrappedEvent(shaped.wire) ? shaped : undefined;
}

/** Inputs for {@link readUserList}. */
export interface UserListReadOptions {
  /** Pool used for the read; its liveness filter is honored. */
  pool: RelayPool;
  /** Canonical store that receives verified events. */
  eventStore: EventStore;
  /** Transport targets for this read (never written into signed content). */
  relays: string[];
  /** The only author whose events are accepted. */
  pubkey: string;
  /** The only kind whose events are accepted. */
  kind: number;
  /** NIP-42 handler for relays that demand authentication before serving the list. */
  onAuthRequired?: SyncAuthHandler;
  /** Per-relay stall timeout; defaults to {@link COMMUNITY_LIST_READ_TIMEOUT_MS}. */
  timeoutMs?: number;
  /** Overall deadline, auth phases included; defaults to {@link COMMUNITY_LIST_READ_DEADLINE_MS}. Relays that completed
   *  before it still count; only the unfinished ones are cut. */
  deadlineMs?: number;
  /** Cancels the read; an in-flight read then reports as incomplete. */
  cancelled$?: Observable<unknown>;
}

/** Result of {@link readUserList}. */
export interface UserListReadOutcome {
  /** At least one relay reached its own `"complete"` state; a skipped or empty cohort is incomplete. */
  complete: boolean;
  /** `cancelled$` ended the read: incomplete, but no evidence of a relay failure. */
  cancelled: boolean;
  /** Events that passed kind, author and signature checks, in arrival order. */
  events: NostrEvent[];
  /**
   * Per-relay final state, keyed by the loader's normalized relay URL (for example
   * `wss://relay.example/`). Kept (D-21, D-28) so a stricter completeness rule than "at least
   * one relay completed" is a small later change.
   */
  relays: Record<string, SyncRelayState>;
  /** Why the read failed locally (for example, the store refused an event); such a read is never complete. */
  error?: unknown;
}

/**
 * Read every version of one user-authored list kind and report completion evidence.
 * Completeness comes only from the sync loader's per-relay `"complete"` state, so errors,
 * liveness skips, stalls, the overall deadline and cancellation can never read as an empty list; a relay that
 * completed before the deadline still counts. Events are
 * retained in the store only after kind, author and signature verification. Total: a local failure resolves as an
 * incomplete read carrying `error`, never a rejection.
 */
export async function readUserList(options: UserListReadOptions): Promise<UserListReadOutcome> {
  try {
    return await readUserListOnce(options);
  } catch (error) {
    return { complete: false, cancelled: false, events: [], relays: {}, error };
  }
}

async function readUserListOnce(options: UserListReadOptions): Promise<UserListReadOutcome> {
  const { kind, pubkey } = options;
  // The loader drops an event whose store insert throws, so a relay could still report "complete" over it.
  let failure: { error: unknown } | undefined;
  let cancelled = false;
  const cancelled$ = (options.cancelled$ ?? NEVER).pipe(tap(() => (cancelled = true)));
  const accepts = (event: NostrEvent): boolean =>
    event?.kind === kind && event.pubkey === pubkey && verifyWrappedEvent(structuredClone(event));
  // Mirror of the sync.ts guarded store: the loader funnels its events through `add` before
  // emission, so a relay ignoring the filter can never place a foreign event in the store.
  const guarded:
    & Parameters<typeof createSyncLoader>[0]["eventStore"]
    & Pick<EventStore, "getByFilters" | "getTimeline" | "getEvent" | "hasEvent"> = {
      add: (event) => {
        if (!accepts(event)) return null;
        try {
          const canonical = options.eventStore.add(structuredClone(event));
          return canonical && accepts(canonical) ? canonical : null;
        } catch (error) {
          failure ??= { error };
          return null;
        }
      },
      update: (event) => {
        if (accepts(event)) options.eventStore.update(event);
      },
      remove: (event) => options.eventStore.remove(event),
      getByFilters: (filters) => options.eventStore.getByFilters(filters),
      getTimeline: (filters) => options.eventStore.getTimeline(filters),
      getEvent: (id) => options.eventStore.getEvent(id),
      hasEvent: (id) => options.eventStore.hasEvent(id),
    };
  const loader = createSyncLoader({ eventStore: guarded, pool: options.pool });
  const { events$, status$ } = loader({
    relays: options.relays,
    filter: { kinds: [kind], authors: [pubkey] },
    waitForAuth: [pubkey],
    onAuthRequired: options.onAuthRequired,
    timeout: options.timeoutMs ?? COMMUNITY_LIST_READ_TIMEOUT_MS,
  });
  // Collected as they arrive, so the overall deadline keeps the relays that already completed and their events
  // (D-13, D-21): one relay stalled in auth must not make every read incomplete.
  const events: NostrEvent[] = [];
  let snapshot: SyncLoaderStatus | undefined;
  await firstValueFrom(
    forkJoin([
      events$.pipe(filter(accepts), tap((event) => events.push(event)), toArray()),
      status$.pipe(tap((status) => (snapshot = status))),
    ]).pipe(takeUntil(merge(cancelled$, timer(options.deadlineMs ?? COMMUNITY_LIST_READ_DEADLINE_MS)))),
    { defaultValue: undefined },
  );
  if (cancelled) return { complete: false, cancelled, events: [], relays: {}, ...failure };
  const relays: Record<string, SyncRelayState> = {};
  for (const [url, relay] of Object.entries(snapshot?.relays ?? {})) relays[url] = relay.state;
  return {
    // Unlike sync.ts, an empty relay map is incomplete: a liveness-skipped cohort is not evidence.
    complete: !failure && Object.values(relays).some((state) => state === "complete"),
    cancelled: false,
    events,
    relays,
    ...failure,
  };
}

/** Inputs for {@link watchUserList}. */
export interface UserListWatchOptions {
  /** Transport targets; a repeated identical set does not resubscribe. */
  relays$: Observable<string[]>;
  /** Pool used for the live subscription. */
  pool: RelayPool;
  /** Canonical store that receives verified events. */
  eventStore: EventStore;
  /** The only author whose events are accepted. */
  pubkey: string;
  /** The only kind whose events are accepted. */
  kind: number;
  /** NIP-42 handler for relays that demand authentication. */
  onAuthRequired: RelayAuthHandler;
  /** Runs on every relay-set change, before the new subscription opens. */
  onRelays: () => void;
}

/**
 * Live subscription to one user-authored list kind on the current relay set, retaining in the store only events that
 * pass the same kind, author and signature checks as {@link readUserList}. A subscription is never read evidence.
 */
export function watchUserList(options: UserListWatchOptions): Observable<NostrEvent> {
  const { kind, pubkey } = options;
  return options.relays$.pipe(
    distinctUntilChanged((a, b) => a.length === b.length && a.every((url, index) => url === b[index])),
    switchMap((relays) => {
      options.onRelays();
      return options.pool.subscription(relays, [{ kinds: [kind], authors: [pubkey] }], {
        waitForAuth: [pubkey],
        onAuthRequired: options.onAuthRequired,
      }).pipe(onlyEvents());
    }),
    filter((event) => event.kind === kind && event.pubkey === pubkey && verifyWrappedEvent(structuredClone(event))),
    mapEventsToStore(options.eventStore),
  );
}

/** Wait for `hydration`, or at most `ms` of real time (never the injectable duty clock), so a failed decrypt cannot hang. */
export async function waitBounded(
  hydration: Promise<void>,
  ms: number = COMMUNITY_LIST_READ_TIMEOUT_MS,
): Promise<void> {
  let cancel: (() => void) | undefined;
  try {
    await Promise.race([hydration, new Promise<void>((resolve) => (cancel = systemClock.schedule(ms, resolve)))]);
  } finally {
    cancel?.();
  }
}

/**
 * Adapt the user's relay auth handler to the sync loader's handler type. The loader passes
 * the pool's own Relay instance, and the user handler reads only the challenge's missing
 * identities, the relay `url` and `relay.authenticate`, so the structural cast is sound.
 */
export function userAuthForSync(handler: RelayAuthHandler): SyncAuthHandler {
  return (context) => handler(context as unknown as Parameters<RelayAuthHandler>[0]);
}

/** A relay refused or failed a Community List fragment publication; `transient` failures may be retried. */
export class ListRelayPublishError extends Error {
  constructor(
    message: string,
    readonly transient: boolean,
    readonly responses: readonly PublishResponse[] = [],
    cause?: unknown,
  ) {
    super(message, { cause });
    this.name = "ListRelayPublishError";
  }
}

/** A newer document or lifecycle superseded an in-flight Community List save: normal, so never reported as a failure. */
export class ListPublicationRetiredError extends Error {
  constructor() {
    super("Community List publication retired");
    this.name = "ListPublicationRetiredError";
  }
}

/** NIP-01 `OK` reason prefixes the same publication would get again; `error:` and `rate-limited:` may clear. */
const REFUSED_FOR_GOOD = /^(blocked|restricted|invalid|pow|auth-required):/;
/** applesauce-relay NIP-42 outcomes where the user declined the AUTH prompt or the relay required auth it never got;
 *  an auth timeout is transient. */
const AUTH_DECLINED = new Set(["AuthHandlerError", "AuthRequiredError"]);

function refusedForGood(response: PublishResponse): boolean {
  const name = (response.error as { name?: unknown } | undefined)?.name;
  return AUTH_DECLINED.has(String(name)) || REFUSED_FOR_GOOD.test(response.message ?? "");
}

/**
 * Publish one fragment and require a relay acknowledgment; every relay-side failure is a {@link ListRelayPublishError}.
 * It is transient unless every relay refused for good, so a declined AUTH prompt or a ban is never retried.
 */
export async function publishListFragment(
  pool: RelayPool,
  relays: string[],
  event: NostrEvent,
  options: Parameters<RelayPool["publish"]>[2],
): Promise<void> {
  let responses: PublishResponse[];
  try {
    responses = await pool.publish(relays, event, options);
  } catch (error) {
    const declined = AUTH_DECLINED.has(String((error as Error)?.name));
    throw new ListRelayPublishError((error as Error)?.message ?? String(error), !declined, [], error);
  }
  if (!responses.some((response) => response.ok)) {
    const transient = responses.length === 0 || !responses.every(refusedForGood);
    throw new ListRelayPublishError("No relay accepted the Community List fragment", transient, responses);
  }
}

/**
 * Whether the read duty may retry a failed held save: no relay accepted it for a transient reason, or the list changed
 * while it was signed. Encoding and size failures are deterministic, and a signer failure, a declined relay AUTH prompt
 * or a relay refusal such as `blocked:` would recur or only prompt the user again; those settle with their one
 * `community-list-save` diagnostic. A fragment record that could not be stored is retried, since storage quota or a
 * locked store can recover (D-08), unless the record could not be read: that refusal lasts until the next `start()`
 * (IN-01).
 */
export function retriesListSave(error: unknown): boolean {
  // The sync's concurrent-arrival refusal (community-list-sync.ts publishPrepared) has no dedicated class.
  return (error instanceof ListRelayPublishError && error.transient) ||
    (error instanceof FragmentPersistError && !(error instanceof FragmentRecordUnreadableError)) ||
    (error instanceof Error && error.message === "Community List changed during signing");
}

/** Retry budget for the Community List read duty (D-24). */
export interface CommunityListReadRetryBudget {
  /** Delay before the first retry attempt. */
  delayMs: number;
  /** Extra random delay of up to this long, spread through the duty clock. */
  jitterMs: number;
  /** Base backoff between failed attempts, doubled per attempt. */
  retryDelayMs: number;
  /** Attempts before the duty reports exhaustion once and goes quiet. */
  maxAttempts: number;
  /** Lifetime from the first request. */
  lifetimeMs: number;
}

/**
 * Budget for retrying an incomplete Community List read: 3 attempts within 60 s, a 5 s base delay with jitter. The
 * lifetime is deliberately longer than {@link COMMUNITY_LIST_READ_DEADLINE_MS} so one stalled attempt cannot spend it.
 */
export const COMMUNITY_LIST_READ_RETRY: CommunityListReadRetryBudget = {
  delayMs: 5_000,
  jitterMs: 1_000,
  retryDelayMs: 5_000,
  maxAttempts: 3,
  lifetimeMs: 60_000,
};

/**
 * Budget for repairing interrupted-repack residue: 3 attempts within 2 minutes. The initial delay and jitter let another
 * device's concurrent repack finish first, after which an attempt finds no residue and does nothing.
 */
export const COMMUNITY_LIST_REPAIR_RETRY: CommunityListReadRetryBudget = {
  delayMs: 2_000,
  jitterMs: 3_000,
  retryDelayMs: 5_000,
  maxAttempts: 3,
  lifetimeMs: 120_000,
};
