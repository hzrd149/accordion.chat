// ConcordClient — the thin multi-community manager.
//
// Owns the fragmented Community List (kind 33302, with legacy 13302 reads), the shared RelayPool / NIP-42
// authenticator / wrap-level EventStore, and a Map of single-community
// `ConcordCommunity` engines. It carries no community logic itself: joining,
// syncing, folding, and publishing all live in `ConcordCommunity`. One instance
// per logged-in user.

import {
  ConcordClientDisposedError,
  ConcordClientNotStartedError,
  type ConcordCommunityListStatus,
  ConcordCommunityListSync,
} from "./community-list-sync.ts";
import * as listDocument from "./community-list-document.ts";
import { publishListFragment, waitBounded } from "./community-list-read.ts";
import { CommunityListFragmentStore } from "./community-list-store.ts";
import { readMirrorDocument, writeMirrorDocument } from "./community-list-mirror.ts";
import { type ConcordMemberships, membershipsSnapshot, membershipsStream } from "./community-list-memberships.ts";
import {
  type CommunityListHost,
  CommunityListLane,
  laneRoutedSync,
  unlockStoredFragments,
} from "./community-list-lane.ts";
import { CommunityMotions, heldJoinAttribution } from "./community-motions.ts";
import {
  BehaviorSubject,
  debounceTime,
  filter,
  lastValueFrom,
  map,
  type Observable,
  of,
  Subject,
  type Subscription,
  switchMap,
  timeout,
} from "rxjs";
import { type Debugger, EventStore, mapEventsToTimeline } from "applesauce-core";
import { castUser, type User } from "applesauce-core/casts";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { unixNow } from "applesauce-core/helpers/time";
import type { RelayAuthHandler, RelayPool } from "applesauce-relay";
import type { ISigner } from "applesauce-signers";

import { logger } from "../logger.ts";
import { createUserAuthHandler } from "./auth.ts";
import { type ConcordStorage, type ConcordStoreFactory, type ConcordUploader, defaultStorage } from "./storage.ts";
// Side-effect import: registers the `User.concord*List$` getters used below (the named
// imports are type-only, so without this bare import the registration would be elided).
import "../casts/index.ts";
import type { ConcordCommunityList, ConcordInviteList } from "../casts/index.ts";
import type { ConcordCommunityListUser } from "../casts/community-list.ts";
import { createCommunity } from "../helpers/community.ts";
import {
  canonicalJson,
  COMMUNITY_LIST_KIND,
  getCommunityList,
  isCommunityLive,
  liveCommunities,
  mergeCommunities,
  mergeCommunityTombstones,
  type ParsedCommunityList,
} from "../helpers/community-list.ts";
import {
  getInviteBundle,
  INVITE_BUNDLE_KIND,
  isInviteBundleRevoked,
  isSafeInviteRelayURL,
  isValidInviteBundle,
  parseInviteLink,
  STOCK_RELAYS,
  validateInviteBundle,
} from "../helpers/invite-bundle.ts";
import { ExtraRelays, type ExtraRelaysOption } from "../helpers/relays.ts";
import { joinCommunity, leaveCommunity, refreshCommunity } from "../operations/community-list.ts";
import { JoinLeaveFactory } from "../factories/guestbook.ts";
import { InviteWatcher } from "./invite-watcher.ts";
import type { ConcordDirectInvite } from "../casts/direct-invite.ts";
import { ConcordInviteManager } from "./invite-manager.ts";
import type {
  CommunityListCommunity,
  CommunityState,
  CommunityTombstone,
  ConcordClientStatus,
  InviteBundle,
  JoinMaterial,
} from "../types.ts";
import { ConcordCommunity } from "./community.ts";
import { isAtCoordinate, newestAtCoordinate } from "./invite-coordinate.ts";
import { clientStatus$ } from "./client-status.ts";
import type { ConcordPinUpkeepOptions } from "./pin-maintainer.ts";
import { type ConcordPurgeScheduleOptions, PurgeSchedules } from "./expiration-purge.ts";
import { DutyScope } from "./lifecycle.ts";
import { type ConcordDiagnostic, DiagnosticsSink } from "./diagnostics.ts";

/** Debounce window for the opt-in post-sync community-list flush, so a burst of
 *  epoch adoptions (each community catching up as its walk finishes) collapses into
 *  a single {@link ConcordClient.saveCommunityList} call. */
const COMMUNITY_LIST_FLUSH_DEBOUNCE_MS = 200;

/** Options for constructing the multi-community {@link ConcordClient} manager. */
export interface ConcordClientOptions extends ConcordPinUpkeepOptions {
  /** The logged-in user's signer. */
  signer: ISigner;
  /** The applesauce RelayPool used for all subscriptions/publishes. */
  pool: RelayPool;
  /** Shared wrap-level store. Defaults to a fresh {@link EventStore}. */
  eventStore?: EventStore;
  /** Persistence for the membership/key material mirror + sync cursors. */
  storage?: ConcordStorage;
  /** Media uploader, passed through to every community. */
  uploader?: ConcordUploader;
  /** Fallback relays when a community defines none. */
  relays?: string[];
  /**
   * Additional transport targets for all Concord traffic; never included in
   * protocol state or published content. Does not replace {@link relays}.
   * Empty extras leave base targets unchanged; otherwise targets are normalized
   * and deduplicated. An extra relay can keep `connected$` true while protocol relays are down.
   *
   * Accepts a static array or live observable, initially treated as empty.
   * Each engine subscribes independently; use a hot/shared source to share updates.
   * Call {@link ConcordClient.dispose} to release all subscriptions; `stop()` only pauses.
   */
  extraRelays?: ExtraRelaysOption;
  /** Per-plane store factory (persistent cache), passed through to every community. */
  storeFactory?: ConcordStoreFactory;
  /** Automatically decrypt (unlock) the user's self-encrypted events with their signer: the
   *  Community fragments and legacy/Invite lists (kind 33302/13302/13303) as they arrive, and incoming Direct Invites.
   *  Defaults to `false` so the signer isn't invoked without intent — the app unlocks on demand
   *  (`.unlock(signer)` on the exposed cast, {@link InviteWatcher.readPending}). Community-plane
   *  decryptions (derived group keys, no prompt) always happen automatically regardless. */
  autoUnlock?: boolean;
  /** Automatically publish updated kind-33302 fragments after a sync when the community list has
   *  changed locally (an epoch caught up, a refounding removal). Defaults to `false` so the
   *  initial sync has **zero** side effects — no signer calls, no publishes. When `true`, a
   *  single debounced {@link saveCommunityList} runs once the sync settles, and only if the
   *  {@link communityListDirty$} flag was flipped. Explicit membership mutations
   *  ({@link joinByLink}, {@link leave}, {@link createNewCommunity}) always publish regardless
   *  of this flag — they are the sanctioned points to encrypt + sign the list. When `true` the client also
   *  repairs residue an interrupted repack left (duplicate or dormant fragments) once the List is complete and decrypted;
   *  otherwise residue is reported on {@link diagnostics$} and repaired by the next save, join or leave. */
  autoSaveCommunityList?: boolean;
  /** Watch the user's inbox for CORD-05 Direct Invites (community + private-channel invites) during
   *  {@link start}. Defaults to `true`. Discovery is read-only — the watcher never touches the user's
   *  signer unless {@link autoUnlock} is on (which gates its auto-decrypt / NIP-42 auth); otherwise
   *  invites stay pending until the app calls {@link InviteWatcher.readPending}. */
  watchDirectInvites?: boolean;
  /** A custom debug logger (defaults to the "applesauce:concord" namespace). */
  logger?: Debugger;
}

/**
 * The multi-community entry point: owns the user's fragmented Community List, the shared
 * relay pool, event store and storage, the per-community {@link ConcordCommunity} engines,
 * and the direct-invite watcher. One instance per signed-in session.
 */
export class ConcordClient {
  /** The signed-in user's signer, shared with every community engine this client owns. */
  readonly signer: ISigner;
  /** The client's debug logger — `options.logger` when injected, otherwise the
   *  `applesauce:concord` module base (D-01/D-02). One client per session, so
   *  no per-instance id suffix at this level (unlike `ConcordCommunity`). */
  private readonly log: Debugger;
  /** The `:invite` sub-logger, derived ONCE in the constructor and reused at
   *  every site that hands a logger to the invite manager/watcher — a fixed
   *  namespace, so a single field replaces what would otherwise be a repeated
   *  `this.log.extend("invite")` at each construction site (constructor +
   *  {@link ensureInviteWatcher}). */
  private readonly inviteLog: Debugger;
  private readonly diagnostics: DiagnosticsSink;
  /** Typed background failures from this client, its invite manager and Direct Invite watcher, and every community
   *  engine it owns (those carry `communityId`). Completes on {@link dispose}, not {@link stop}. These failures are no
   *  longer printed to the console; enable the `applesauce:concord` logger for text output. */
  readonly diagnostics$: Observable<ConcordDiagnostic>;
  /** The `:publish` sub-logger (D-03 light operational tracing), derived ONCE
   *  in the constructor and reused at every community-list publish trace/
   *  dual-emit site — never re-`.extend()`d per call. */
  private readonly publishLog: Debugger;
  /** Every joined community's current folded state. */
  readonly communities$: BehaviorSubject<CommunityState[]> = new BehaviorSubject<CommunityState[]>([]);
  /** `"idle"` before `start()`, `"starting"` during startup, `"ready"` afterward. */
  readonly phase$: BehaviorSubject<ConcordClientStatus["phase"]> = new BehaviorSubject<ConcordClientStatus["phase"]>(
    "idle",
  );
  /** A flat snapshot of the manager's status (lifecycle + aggregate sync/connection
   *  across every joined community), for UI to react to as one value. */
  readonly status$: Observable<ConcordClientStatus>;
  /** The active Direct Invite inbox watcher, or `undefined` before it starts. Reactive so UI can
   *  subscribe to its {@link InviteWatcher.pendingCount$} once it exists (see
   *  {@link watchDirectInvites} / {@link startDirectInviteWatcher}). It answers a gating inbox
   *  relay's refusal of one of its own reads with the user's key on demand — there is no
   *  separate proactive-auth entry point to watch or call. */
  readonly directInviteWatcher$: BehaviorSubject<InviteWatcher | undefined> = new BehaviorSubject<
    InviteWatcher | undefined
  >(undefined);
  /** The user's public invite-link manager (private kind-13303 list + community invite creation). */
  readonly invites: ConcordInviteManager;

  /** Fragment state and the receive/write API for kind-33302 membership sync; the read-evidence methods, `abandon()`
   *  and `restore()` stay internal and throw if called through this view. `receive()` authenticates a fragment, adds
   *  it to the event store and receives it after the client's other list work (WR-03). `write()` and `repack()` run as
   *  Community List lane steps after that work too, and ingest every stored fragment first (D-35). */
  readonly communityListSync: Pick<
    ConcordCommunityListSync,
    "fragments" | "status" | "status$" | "unreceived" | "clearPending" | "receive" | "write" | "repack"
  >;
  private readonly listSync: ConcordCommunityListSync; // the sync under that view; only the lane records evidence (IN-01)
  /** This lifecycle's serialized Community List reads, ingest, unlocks and saves (D-31); closed by {@link stop}. */
  private listLane?: CommunityListLane;

  private readonly pool: RelayPool;
  /** The user's own auth handler — built ONCE here (never per call, D-08) and threaded
   *  into {@link invites} and every {@link ConcordCommunity} this client constructs
   *  ({@link addCommunity}). Answers only the resolved user pubkey; `InviteWatcher`
   *  builds its own SEPARATE instance (D-09) rather than sharing this one. */
  private readonly userOnAuthRequired: RelayAuthHandler;
  private readonly eventStore: EventStore;
  private readonly storage: ConcordStorage;
  /** The durable record of the authenticated Community List fragments, restored first by every start (LIST-03). */
  private readonly fragmentStore: CommunityListFragmentStore;
  private readonly uploader?: ConcordUploader;
  private readonly defaultRelays: string[];
  /** The RAW `extraRelays` option, kept unresolved so every sub-engine (invite manager, invite
   *  watcher, every community) constructs its own reactive holder from the SAME live source
   *  (D-11/D-13) — never a resolved snapshot, which would freeze sub-engine reactivity. */
  private readonly extraRelaysOption?: ExtraRelaysOption;
  /** Automatic pin upkeep for every community; `false` turns it off. */
  private readonly pinUpkeep?: boolean;
  /** The client's own per-operation transport-only extras holder (D-04) — the sole merge
   *  point for this class's own pool calls, via {@link transport}. Never merged into signed
   *  or published content. */
  private readonly extras: ExtraRelays;
  private readonly storeFactory?: ConcordStoreFactory;
  private readonly autoUnlock: boolean;
  private readonly autoSaveCommunityList: boolean;
  private readonly watchDirectInvites: boolean;
  /** The logged-in user as a cast over the shared event store — the source of the exposed
   *  `communityList$` / `inviteList$` observables. Undefined until {@link start} resolves the
   *  pubkey; the exposed getters switch onto it reactively, so they never throw pre-start. */
  private readonly user$ = new BehaviorSubject<User | undefined>(undefined);

  private readonly communities = new Map<string, ConcordCommunity>();
  /** Each community's Join/Leave calls, in call order (D-34) and bound to the lifecycle they were called in (D-30). */
  private readonly motions = new CommunityMotions((lifecycle) => this.assertLifecycle(lifecycle));
  /** The opt-in client-wide purge schedule, attached to every engine this client builds. */
  private readonly purgeSchedules: PurgeSchedules = new PurgeSchedules();
  private readonly stateSubs = new Map<string, Subscription>();
  /** The authoritative membership union (CORD-02 §8): two merged, never-clobbered arrays. Both the
   *  local mirror and the relay copy are merged into these through the same primitives, and the
   *  running engine set is derived from them — so a leave on another device reaps the engine here
   *  instead of the stale engine resurrecting the membership. */
  private list: CommunityListCommunity[] = [];
  private tombstones: CommunityTombstone[] = [];
  /** Last-read document, retained to round-trip unknown fields (CORD-02 §6).
   *  Spread before assigning merged `entries`/`tombstones` so stale arrays cannot win.
   *  Excluded from the dirty fingerprint: these fields already exist on the relay
   *  and should travel on the next save without triggering a publish themselves. */
  private documentExtras: Record<string, unknown> = {};
  /** WR-01 (12.3-12): community_id -> canonicalJson fingerprint of the `current`
   *  material whose `addCommunity` construction most recently threw. Retrying an
   *  entry that fails IDENTICALLY on every Community List cast emission would cost
   *  a fresh `ConcordCommunity` construction — and therefore a fresh subscription
   *  to the app's `extraRelays` source — on every emission (the cast re-emits on
   *  outbox/replaceable churn). Fingerprinting on the MATERIAL, not the id alone,
   *  is what keeps a genuinely corrected entry retryable: cleared on success or
   *  on reap (see {@link reconcileCommunities}). */
  private readonly failedConstructionFingerprint = new Map<string, string>();
  /** Canonical fingerprint of the list content believed to be on the relay. When a save would
   *  produce identical content we skip the encrypt/sign/publish — 13302 is replaceable, so a
   *  spurious republish (new nonce, new signature, new created_at) can clobber a newer copy from
   *  another device. NIP-44's random nonce means we must compare plaintext content, not ciphertext.
   *  Seeded to the empty-list fingerprint so a brand-new user (no communities, no remote list) never
   *  republishes an empty document on startup; a genuine local-only membership still differs. */
  private publishedListFingerprint: string | null = canonicalJson({ entries: [], tombstones: [] });
  /** Resolves the first time the Community List cast is decrypted + reconciled (fingerprint seeded).
   *  `start()` awaits this before enabling the auto-save flush when the relay served a list, so an
   *  async (e.g. NIP-46 remote) signer's slow decrypt can't lose a race and clobber a newer remote
   *  copy with a save rebuilt from the local mirror. */
  private signalListHydrated?: () => void;
  private listHydration = new Promise<void>((resolve) => (this.signalListHydrated = resolve));
  /** Serializes material refreshes so each persistence snapshot starts from the latest committed list. */
  private communityListMutationTail: Promise<void> = Promise.resolve();
  /** Signals every change to the membership document (D-13); the trigger behind {@link memberships$}. */
  private readonly listChanged$: Subject<void> = new Subject<void>();
  private communityListRevision = 0;
  private readonly listPublicationInvalidators = new Set<() => void>();
  /** The synchronous echo already represents our validated document. */
  private publishingCommunityListId?: string;
  /** Only completed document/engine reconciliation authorizes replacing a selected edition. */
  private reconciledCommunityList?: { id: string; lifecycle: number };
  private observedCommunityListId?: string;
  /** An explicit or opted-in save deferred by unread remote material, scoped to its lifecycle. */
  private deferredCommunityListSaveLifecycle?: number;
  /** True when the in-memory community list has diverged from the copy we last saved to nostr —
   *  an epoch caught up during sync, or a refounding removal. UI can subscribe to show an
   *  "unpublished changes" indicator, and the opt-in auto-save debounces off it. Set by
   *  {@link markCommunityListDirty}; cleared by {@link saveCommunityList} once back in sync.
   *  Explicit join/leave/create request publication immediately; a selected unread edition
   *  defers it until reconciliation completes. The sync-time flush is opt-in via
   *  {@link ConcordClientOptions.autoSaveCommunityList}. */
  readonly communityListDirty$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  /** The debounced auto-save subscription over {@link communityListDirty$}, live only while
   *  {@link autoSaveCommunityList} is on (created after hydration in {@link start}). */
  private autoSaveSub?: Subscription;
  private listSub?: Subscription;
  /** Watches the user's gift-wrap inbox for CORD-05 §6 Direct Invites — the delivery
   *  channel for private-channel grants ({@link ConcordCommunity.grantChannelAccess}). */
  private inviteWatcher?: InviteWatcher;
  private directInviteSub?: Subscription;
  /** Direct-invite rumor ids already folded into a community, so a re-emit (the
   *  watcher republishes its full list on every change) doesn't re-merge. */
  private readonly handledInvites = new Set<string>();
  /** List event ids we've already auto-unlocked — the cast re-emits several times per event
   *  (outbox/replaceable churn), so we prompt the user's signer at most once per event id. */
  private readonly autoUnlocked = new Set<string>();
  private started = false;
  private disposed = false; // D-32: dispose() is terminal; start() and list mutations then reject
  private listLifecycle = 0;
  /** Owns the Community List read retry; cancelled by {@link stop}, disposed terminally by {@link dispose}. */
  private readonly listDuties: DutyScope = new DutyScope({ report: (report) => this.diagnostics.reportDuty(report) });
  /** The document and publication bookkeeping the list lane works on; publication never holds the document lane. */
  private readonly listHost: CommunityListHost = {
    document: () => ({ entries: this.list, tombstones: this.tombstones, extras: this.documentExtras }),
    fingerprint: () => this.communityListFingerprint(),
    revision: () => this.communityListRevision,
    published: () => this.publishedListFingerprint,
    markPublished: (fingerprint) => {
      this.publishedListFingerprint = fingerprint;
      this.communityListDirty$.next(false);
    },
    settled: () => this.communityListMutationTail,
    deferred: () => this.deferCommunityListSave(),
    adopt: (remote) => this.adoptFragments(remote, this.listLifecycle),
    held: () => this.heldSaveDue(),
    ready: () => this.phase$.value === "ready",
    onRetire: (retire) => {
      this.listPublicationInvalidators.add(retire);
      return () => this.listPublicationInvalidators.delete(retire);
    },
    retire: () => this.invalidateCommunityListPublication(),
    flagHeld: () => this.communityListDirty$.value || this.communityListDirty$.next(true),
  };

  /** Wires up shared infrastructure and derives the sub-loggers once. No relay or storage
   *  access happens until {@link start}. */
  constructor(options: ConcordClientOptions) {
    this.log = options.logger ?? logger;
    this.inviteLog = this.log.extend("invite");
    this.publishLog = this.log.extend("publish");
    this.diagnostics = new DiagnosticsSink(this.log);
    this.diagnostics$ = this.diagnostics.diagnostics$;
    this.signer = options.signer;
    this.listSync = new ConcordCommunityListSync(this.signer, async (event) => {
      const auth = { waitForAuth: [this.pubkey], onAuthRequired: this.userOnAuthRequired };
      await publishListFragment(this.pool, this.transport(), event, auth);
      this.listLane?.markOwn(event.id); // our own fragment never retires the save publishing it
      this.eventStore.add(event);
    }, {
      requireCompletedRead: true,
      // The closure reads the store and the pubkey only when called; before start() there is no user to store for.
      persist: (snapshot) => {
        const pubkey = this.user$.value?.pubkey;
        return pubkey ? this.fragmentStore.save(pubkey, snapshot) : Promise.resolve();
      },
      onDiagnostic: (diagnostic) => this.diagnostics.report(diagnostic),
    });
    this.communityListSync = laneRoutedSync(this.listSync, () => this.listLane, {
      eventStore: () => this.eventStore,
      pubkey: () => (this.disposed ? Promise.reject(new ConcordClientDisposedError()) : this.signer.getPublicKey()),
    });
    this.pool = options.pool;
    this.eventStore = options.eventStore ?? new EventStore();
    this.storage = options.storage ?? defaultStorage();
    this.fragmentStore = new CommunityListFragmentStore(this.storage, {
      report: (error) => this.diagnostics.report({ stage: "fragment-persist", error }),
      schedule: (ms, run) => this.listDuties.clock.schedule(ms, run), // the storage-wait bound (IN-02)
    });
    this.uploader = options.uploader;
    this.defaultRelays = options.relays?.length ? options.relays : STOCK_RELAYS;
    this.extraRelaysOption = options.extraRelays;
    this.pinUpkeep = options.pinUpkeep;
    this.extras = new ExtraRelays(options.extraRelays);
    this.log("extras configured=%s", options.extraRelays !== undefined);
    this.storeFactory = options.storeFactory;
    this.autoUnlock = options.autoUnlock ?? false;
    this.autoSaveCommunityList = options.autoSaveCommunityList ?? false;
    this.watchDirectInvites = options.watchDirectInvites ?? true;
    // Built ONCE, before the invite manager is constructed, so it can be threaded in —
    // a thunk (never `this.pubkey`, which throws pre-start) so it resolves to `undefined`
    // and no-ops until `start()` sets `this.user$` (D-08).
    this.userOnAuthRequired = createUserAuthHandler(this.signer, () => this.user$.value?.pubkey);
    this.invites = new ConcordInviteManager({
      signer: this.signer,
      pool: this.pool,
      eventStore: this.eventStore,
      relays: this.defaultRelays,
      extraRelays: this.extraRelaysOption,
      autoUnlock: this.autoUnlock,
      userOnAuthRequired: this.userOnAuthRequired,
      getCommunity: (communityId) => this.getCommunity(communityId),
      onDiagnostic: (diagnostic) => this.diagnostics.emit(diagnostic),
      logger: this.inviteLog,
    });

    this.status$ = clientStatus$(this.phase$, this.communities$, () => this.communities);
  }

  /** Merges `base` (defaulting to {@link defaultRelays}) with the current extras snapshot
   *  (D-04) — the ONLY merge point for this class's own transport calls. Every call site here
   *  is one-shot, so the synchronous {@link ExtraRelays.current} snapshot is the correct
   *  consumption shape (D-11) — never a first-value-only resolver. The result is a transport
   *  target set only: it must never be written into signed or published content. */
  private transport(base?: string[]): string[] {
    return this.extras.merge(base ?? this.defaultRelays);
  }

  /** The logged-in user's hex pubkey. Available after {@link start}. */
  get pubkey(): string {
    return this.requireUser().pubkey;
  }

  /** The user's Community List as one reactive value: live `entries`, `tombstones`, `knowledge` of the relay copy,
   *  whether a held fragment is still `locked` and whether a save is `pending`. Safe to subscribe before {@link start}
   *  (it emits the empty, unknown, unlocked value first), then emits on every membership, status and lock change, and
   *  completes on {@link dispose}. Entries carry key material. This replaces the legacy {@link communityList$} cast for
   *  reading memberships (D-13). */
  get memberships$(): Observable<ConcordMemberships> {
    return membershipsStream(this.listChanged$, this.listSync, () => this.memberships());
  }

  /** The current {@link memberships$} value, synchronously. Returns copies: changing them never changes the client. */
  memberships(): ConcordMemberships {
    return membershipsSnapshot(this.list, this.tombstones, this.listSync);
  }

  /** The user's Community List (kind 13302) as a reactive cast — emits `undefined` before
   *  {@link start} and until the event lands in the store; locked until `autoUnlock` or the app
   *  calls `.unlock(signer)`. Safe to subscribe to before start (it switches on once ready).
   *  @deprecated The legacy kind-13302 read/import surface: the client never publishes or dual-writes kind 13302.
   *  Read memberships with {@link memberships$}. */
  get communityList$(): Observable<ConcordCommunityList | undefined> {
    return this.user$.pipe(
      switchMap((user) => (user ? (user as ConcordCommunityListUser).concordCommunityList$ : of(undefined))),
    );
  }

  /** Status of the kind-33302 Community List as `{ knowledge, pending }`. `"unknown"` means no relay has
   *  completed the read (offline or failed) and saves are held until a later {@link start} completes it.
   *  The shape may gain fields. */
  get communityListStatus$(): Observable<ConcordCommunityListStatus> {
    return this.communityListSync.status$;
  }

  /** The user's Invite List (kind 13303) as a reactive cast — same lock/unlock semantics, also
   *  safe before start. */
  get inviteList$(): Observable<ConcordInviteList | undefined> {
    return this.invites.event$;
  }

  /** The started user, or a thrown explanation. Used by paths that cannot meaningfully
   *  degrade before {@link start} has resolved the signer's pubkey. */
  private requireUser(): User {
    const user = this.user$.value;
    if (!user) throw new ConcordClientNotStartedError();
    return user;
  }

  /** D-04: an app call is new input, so it renews an exhausted Community List read while the list is unknown. */
  private renewListRead(): void {
    this.listLane?.renew();
  }

  /** D-30: membership changes need a started client; nothing is applied, mirrored or published otherwise. */
  private assertStarted(): void {
    if (this.disposed) throw new ConcordClientDisposedError();
    if (!this.started) throw new ConcordClientNotStartedError();
  }

  /** Lifecycle rule (D-30, D-32): app work queued in one client lifecycle never takes effect in a later one. It rejects
   *  as {@link assertStarted} does, and with ConcordClientNotStartedError once a restart began a new lifecycle. */
  private assertLifecycle(lifecycle: number): void {
    this.assertStarted();
    if (lifecycle !== this.listLifecycle) throw new ConcordClientNotStartedError();
  }

  /** Brings the session up: resolve the user, restore memberships from the local mirror
   *  first so the UI is populated offline, then reconcile against relays. Idempotent;
   *  rejects with {@link ConcordClientDisposedError} after {@link dispose}. A start that rejects (for example, the
   *  signer's `getPublicKey` failed) leaves the client stopped, so a later `start()` tries again. */
  async start(): Promise<void> {
    if (this.disposed) throw new ConcordClientDisposedError();
    if (this.started) return this.renewListRead();
    this.started = true;
    const lifecycle = ++this.listLifecycle;
    try {
      await this.startLifecycle(lifecycle);
    } catch (error) {
      // D-30: never half-started, where membership changes would pass the started check with no lane to hold them.
      if (this.started && lifecycle === this.listLifecycle) this.stop();
      throw error;
    }
  }

  /** {@link start}'s body for one lifecycle. */
  private async startLifecycle(lifecycle: number): Promise<void> {
    // A stop() or dispose() during any await below retires this start: it then wires, reads and publishes nothing.
    const live = (): boolean => this.started && lifecycle === this.listLifecycle;
    this.invalidateCommunityListPublication();
    this.observedCommunityListId = undefined;
    this.phase$.next("starting");
    this.log("start requested");
    if (!this.user$.value) this.user$.next(castUser(await this.signer.getPublicKey(), this.eventStore));
    // Restore memberships from the local mirror first (instant, offline-safe),
    // then reconcile with the relay-published Community List (kind 13302).
    await this.loadMirror();
    await this.reconcileCommunities();
    if (!live()) return;
    this.watchLists();
    // D-31: this lifecycle's lane ingests stored fragments, reads both list kinds and records the read evidence; only
    // its completed, fully ingested read lets a gated write publish (CR-01). The duty scope is read now (tests swap it).
    const lane = (this.listLane = new CommunityListLane({
      lifecycle,
      sync: this.listSync,
      duties: this.listDuties,
      host: this.listHost,
      diagnostics: this.diagnostics,
      log: this.publishLog,
      signer: this.signer,
      autoUnlock: this.autoUnlock,
      autoRepair: this.autoSaveCommunityList,
      pool: this.pool,
      eventStore: this.eventStore,
      pubkey: this.pubkey,
      relays: () => this.transport(),
      relays$: this.extras.relays$.pipe(map(() => this.transport())),
      onAuthRequired: this.userOnAuthRequired,
      store: this.fragmentStore,
    }));
    await lane.start();
    if (!live()) return;
    // Awaiting the fetch only guarantees the ciphertext landed — not that watchLists decrypted and
    // reconciled it (auto-unlock is async, and slow for remote signers). If the relay served a list,
    // wait for that reconcile (which seeds `publishedListFingerprint` from the relay copy) before we
    // enable auto-save; otherwise a flush could rebuild the list from the local mirror and clobber a
    // newer remote copy. Bounded by the same timeout as the fetch so a decrypt failure can't hang.
    if (this.eventStore.getReplaceable(COMMUNITY_LIST_KIND, this.pubkey)) await waitBounded(this.listHydration);
    // Hydration signals document commit; engine reconciliation can enqueue another
    // lane turn. Finish it before start exposes the ready membership collection.
    if (!live()) return;
    await this.reconcileCommunities();
    if (!live()) return;
    await this.invites.start(this.requireUser());
    if (!live()) return;
    if (this.watchDirectInvites) {
      this.startDirectInviteWatcher();
    }
    // Epoch catch-ups publish only with autoSave on: the debounced flush is wired once the remote copy is merged,
    // so a dirty flag raised during the sync is replayed to it and flushed once. Whatever autoSave is set to, a
    // join or leave that the completed relay copy lacks (a held save, D-15/D-26) is published once below, and the
    // read duty does the same when it completes the read later.
    if (this.autoSaveCommunityList) this.startAutoSave();
    if (this.heldSaveDue()) void lane.save(); // D-15/D-26: false until this lifecycle's read is recorded
    this.phase$.next("ready");
    this.log("start complete communities=%d", this.communities.size);
  }

  /** Pause: tears down the running community engines and the invite watcher
   *  instance, restartable via {@link start}. This client's and the invite
   *  manager's extras holders stay subscribed to the app-supplied `extraRelays`
   *  source; the invite watcher instance is disposed and rebuilt by the next
   *  `start()`. {@link dispose} releases the rest. */
  stop(): void {
    this.listDuties.cancelAll("stop");
    this.listLane?.close(); // cancels its read and clears the read evidence: the next lifecycle completes its own
    this.listLane = undefined;
    const previousLifecycle = this.listLifecycle;
    this.started = false;
    this.listLifecycle++;
    this.motions.end(); // queued Join/Leave calls reject now; the next lifecycle starts fresh chains
    // Stopping preserves completed document knowledge for a new explicit
    // engine-less leave, while pending work loses its lifecycle ownership.
    if (
      this.reconciledCommunityList?.lifecycle === previousLifecycle &&
      this.eventStore.getReplaceable(COMMUNITY_LIST_KIND, this.pubkey)?.id === this.reconciledCommunityList.id
    ) {
      this.reconciledCommunityList = { ...this.reconciledCommunityList, lifecycle: this.listLifecycle };
    }
    this.invalidateCommunityListPublication();
    this.listSub?.unsubscribe();
    this.directInviteSub?.unsubscribe();
    this.handledInvites.clear();
    this.autoSaveSub?.unsubscribe();
    this.autoSaveSub = undefined;
    this.inviteWatcher?.dispose();
    this.invites.stop();
    this.inviteWatcher = undefined;
    this.directInviteWatcher$.next(undefined);
    for (const sub of this.stateSubs.values()) sub.unsubscribe();
    this.stateSubs.clear();
    this.purgeSchedules.detachAll();
    for (const community of this.communities.values()) community.dispose();
    this.communities.clear();
    this.communities$.next([]);
    this.communityListDirty$.next(false);
    this.phase$.next("idle");
  }

  /** Releases every engine's subscription to the app-supplied `extraRelays`
   *  source (WR-05): this client's own holder and the invite manager's.
   *  Unlike {@link stop}, the client is NOT restartable: `start()`, membership
   *  changes and `unlockCommunityListFragments()` then reject with
   *  {@link ConcordClientDisposedError}. */
  dispose(): void {
    this.disposed = true;
    this.stop();
    this.purgeSchedules.clear();
    this.listDuties.dispose();
    this.extras.dispose();
    this.invites.dispose();
    this.diagnostics.complete();
    this.listChanged$.complete(); // memberships$ completes with the client (IN-03)
  }

  /**
   * Start watching the user's gift-wrap inbox for CORD-05 §6 Direct Invites and
   * fold any private-channel grants ({@link ConcordCommunity.grantChannelAccess})
   * into the matching community. Shares the client's pool/store/auth; listens on
   * the user's NIP-17 inboxes plus the shared community relays (the fallback),
   * where a co-member's grant lands. Idempotent (guards against double-start). Throws
   * {@link ConcordClientDisposedError} after {@link dispose}.
   */
  startDirectInviteWatcher(): void {
    if (this.disposed) throw new ConcordClientDisposedError();
    this.ensureInviteWatcher();
  }

  /**
   * Opt-in periodic purge of expired Chat on every community, including ones joined later and the engines a later
   * {@link start} rebuilds (CORD-08 §3). Off by default; one sweep runs at once, another when an engine reaches
   * `live`, then one per `intervalMs` (default 300_000). Returns a disposer; a second call replaces the first. Throws
   * {@link ConcordClientDisposedError} after {@link dispose}.
   */
  schedulePurge(options?: ConcordPurgeScheduleOptions): () => void {
    if (this.disposed) throw new ConcordClientDisposedError();
    return this.purgeSchedules.set(options, this.communities.values());
  }

  /** The active direct-invite inbox watcher, if {@link watchDirectInvites} or
   *  {@link startDirectInviteWatcher} has started it. Prefer {@link directInviteWatcher$} in UI. */
  get directInviteWatcher(): InviteWatcher | undefined {
    return this.inviteWatcher;
  }

  /** Creates the direct-invite watcher on first use and wires its invites into community
   *  joins. Idempotent, so the auto-start path and an explicit call cannot produce two. */
  private ensureInviteWatcher(): void {
    if (this.inviteWatcher) return;
    this.inviteWatcher = new InviteWatcher({
      signer: this.signer,
      pool: this.pool,
      eventStore: this.eventStore,
      storage: this.storage,
      relays: this.defaultRelays,
      extraRelays: this.extraRelaysOption,
      // One gate, mirroring the client's `autoUnlock`: whether incoming Direct Invites are
      // decrypted automatically. Off by default so the app decrypts on demand via the exposed
      // watcher (`readPending`). The watcher answers a gating inbox relay's refusal of one of
      // its own reads with the user's key on demand — there is no separate auth gate here.
      autoDecrypt: this.autoUnlock,
      onDiagnostic: (diagnostic) => this.diagnostics.emit(diagnostic),
      logger: this.inviteLog,
    });
    this.directInviteSub = this.inviteWatcher.invites$.subscribe((invites) => {
      for (const invite of invites) this.onDirectInvite(invite);
    });
    this.directInviteWatcher$.next(this.inviteWatcher);
    void this.inviteWatcher.start().catch((error) => {
      this.diagnostics.report({ stage: "invite-watcher-start", error });
    });
  }

  /** Fold a decoded Direct Invite's channel keys into the granting community. Only
   *  communities we're already in are touched — a direct invite to a NEW community
   *  is a full-join flow left to the app, not an auto-join here. An invite for a
   *  community we have not joined yet stays unhandled, so {@link addCommunity}
   *  applies it once that community's engine exists. */
  private onDirectInvite(invite: ConcordDirectInvite): void {
    if (this.handledInvites.has(invite.id) || invite.expired()) return;
    const bundle = invite.bundle;
    if (!bundle) return;
    const community = this.communities.get(bundle.community_id);
    if (!community || !bundle.channels?.length) return;
    community.receiveChannelKeys(bundle.channels);
    this.handledInvites.add(invite.id);
  }

  /** The single-community engine for `cid`, or undefined if not joined. */
  getCommunity(cid: string): ConcordCommunity | undefined {
    return this.communities.get(cid);
  }

  /** Found a new community: mint its genesis material, record the membership, publish the opening control and
   *  guestbook rumors, and save the Community List. Returns the running engine. A rejection after the membership is
   *  recorded keeps it and still saves the list (D-34); calling this again founds another community (D-36). */
  async createNewCommunity(name: string, description: string, relays: string[]): Promise<ConcordCommunity> {
    this.assertStarted();
    const lifecycle = this.listLifecycle;
    this.renewListRead();
    // Never log `name`/`description`: it is unbounded user content in a package
    // whose premise is that community content is end-to-end encrypted. The
    // community id is traced below once `createCommunity` resolves, and that is
    // the stable handle to correlate on.
    this.log("creating community relays=%d", (relays.length ? relays : this.defaultRelays).length);
    const genesis = await createCommunity({
      ownerPubkey: this.pubkey,
      name,
      description,
      relays: relays.length ? relays : this.defaultRelays,
    });
    const community = await this.mutateCommunityList(async () => {
      this.assertLifecycle(lifecycle); // a stop() or a restart during the awaits above
      const recorded = this.recordJoin(genesis.material);
      await this.writeMirror();
      return recorded;
    });
    // Genesis control editions (plaintext seal) + owner Join, then the list save, an explicit mutation that always
    // publishes (independent of autoSaveCommunityList), even when a publication rejected (D-34).
    await this.publishThenSave(async () => {
      for (const rumor of genesis.controlRumors) {
        await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
      }
      for (const rumor of genesis.guestbookRumors) await community.publishToPlane({ plane: "guestbook" }, rumor, {});
    }, () => this.assertLifecycle(lifecycle));
    this.log("community created id=%s", community.communityId.slice(0, 8));
    return community;
  }

  /** Join via an invite link: resolve its bundle, take the membership material, and start
   *  the community. The link fragment is untrusted input, so its bootstrap relays are
   *  filtered here as well as at decode time. For a community already joined it re-publishes
   *  the user's guestbook Join and saves the list, so calling it again finishes a failed join (D-34). */
  async joinByLink(url: string): Promise<ConcordCommunity> {
    this.assertStarted();
    const lifecycle = this.listLifecycle; // the fetch below may span a stop() and start()
    const parsed = parseInviteLink(url);
    // WR-02/WR-03 (12.3-12): this is the defence-in-depth SECOND gate behind
    // `decodeFragment`'s own terminal filter — `parsed.bootstrapRelays` is the
    // one genuinely untrusted producer of a relay set on this path (an
    // attacker-controlled invite link fragment), so the untrusted-relay
    // predicate belongs here, not on the app's own configured relays below.
    // Filtering down to nothing falls through to `this.defaultRelays`, exactly
    // like an absent bootstrap set does today.
    const safeBootstrapRelays = parsed.bootstrapRelays.filter(isSafeInviteRelayURL);
    const relays = safeBootstrapRelays.length ? safeBootstrapRelays : this.defaultRelays;
    // D-05 (second leak surface in this file, mirroring plan 04's createInvite protocol/
    // transport split): `relays` above stays the unmerged bootstrap-or-default selection and
    // flows on, UNCHANGED, into `joinFromBundle` below — it becomes the joined community's
    // material relays (protocol state). `requestRelays` is a separate local that only widens
    // the bundle FETCH to the merged transport set; never substitute it for `relays` above.
    const requestRelays = this.transport(relays);
    // Collect the whole timeline once the request completes (EOSE), NOT the first
    // emission: `mapEventsToTimeline` seeds an immediate `[]` (via
    // `withImmediateValueOrDefault`) so the pipe never completes empty, which means
    // `firstValueFrom` would resolve with that synchronous `[]` before any relay
    // replies — the invite bundle would never be fetched. `lastValueFrom` waits for
    // completion and yields the fully-accumulated timeline.
    // INVITE-01/D-02: scope to the empty `d` identifier so a sibling coordinate
    // (same author+kind, different `d`) can never pollute the union.
    // D-16/D-17: we hold no key for the link signer at this moment — fetching the
    // bundle IS how we'd learn it — so the only identity that can satisfy a gating
    // bootstrap relay here is the user's own.
    const events = await lastValueFrom(
      this.pool
        .request(requestRelays, [{ kinds: [INVITE_BUNDLE_KIND], authors: [parsed.linkSigner], "#d": [""] }], {
          waitForAuth: true,
          onAuthRequired: this.userOnAuthRequired,
        })
        .pipe(mapEventsToTimeline(), timeout(10000)),
      { defaultValue: [] as NostrEvent[] },
    ).catch(() => [] as NostrEvent[]);

    // INVITE-01/D-01/D-03: collapse the FULL relay union (all editions, tombstone
    // included) to the single newest-at-coordinate winner FIRST, then evaluate
    // revocation on that single winner — filtering revoked editions out before
    // sorting would let a lagging relay's stale live bundle win (CORD-05 §2).
    // INVITE-01/D-02: re-enforce the coordinate on inbound events (see
    // isAtCoordinate) — a misbehaving relay is not trusted to have honored the
    // outgoing authors/#d filter, so an off-coordinate injected event can never
    // win the collapse.
    const winner = newestAtCoordinate(
      events.filter((e) => isValidInviteBundle(e) && isAtCoordinate(e, parsed.linkSigner)),
    );
    if (!winner || isInviteBundleRevoked(winner)) throw new Error("invite bundle not found or revoked");

    // Bound and self-certify the attacker-crafted bundle (CORD-05 §1).
    const bundle = validateInviteBundle(getInviteBundle(winner, parsed.token));
    if (!bundle) throw new Error("invite failed owner verification");

    return this.joinFromBundle(bundle, relays, lifecycle);
  }

  /**
   * Accept a Direct Invite bundle, validating it before joining (CORD-05 §6). For a community already joined it
   * re-publishes the user's guestbook Join, saves the list and returns the existing engine, so calling it again
   * finishes a failed join (D-34); {@link InviteWatcher} handles channel grants for communities already joined.
   */
  async joinByBundle(bundle: InviteBundle): Promise<ConcordCommunity> {
    this.assertStarted();
    const validated = validateInviteBundle(bundle);
    if (!validated) throw new Error("invite failed validation");
    return this.joinFromBundle(validated, this.defaultRelays, this.listLifecycle);
  }

  /** The shared tail of {@link joinByLink} / {@link joinByBundle}: turn an already-validated §1 bundle into a joined
   *  community (add engine, persist, publish our attributed Join, republish the list). An already-joined community
   *  gets its Join re-published with the standing attribution. A rejection after recording keeps the membership and
   *  still saves the list (D-34). */
  private async joinFromBundle(
    bundle: InviteBundle,
    fallbackRelays: string[],
    lifecycle: number,
  ): Promise<ConcordCommunity> {
    this.assertLifecycle(lifecycle); // a joinByLink() fetch may span a restart: never renew or queue a later lifecycle
    this.renewListRead();
    this.log("join requested community=%s", bundle.community_id.slice(0, 8));
    // INVITE-04/D-05: expires_at is unix SECONDS end-to-end — compare against unixNow() (seconds), never Date.now()
    // (JS's epoch clock, a different scale). See helpers/__tests__/invite-bundle.test.ts for the dual citation.
    if (bundle.expires_at && unixNow() > bundle.expires_at) throw new Error("invite expired");

    const material: JoinMaterial = {
      community_id: bundle.community_id,
      owner: bundle.owner,
      owner_salt: bundle.owner_salt,
      community_root: bundle.community_root,
      ...("control_pk" in bundle ? { control_pk: bundle.control_pk } : {}),
      root_epoch: bundle.root_epoch,
      channels: bundle.channels ?? [],
      // Fallbacks are trusted app relays or already-filtered bootstrap relays;
      // do not apply the untrusted gate to configured LAN/VPN ws:// endpoints.
      // Copy either branch so communities cannot share a mutable relay array.
      relays: bundle.relays.length ? [...bundle.relays] : [...fallbackRelays],
      name: bundle.name,
      // Canonicalize to [] (invite bundles omit held_roots) so this join material
      // is byte-identical to what the engine's `buildChain` settles on — otherwise
      // the post-start Community List refresh re-signs 13302 a second time (an extra
      // signer.signEvent + nip44.encrypt on every join). A genuine epoch adoption
      // during sync still legitimately differs and publishes.
      held_roots: bundle.held_roots ?? [],
      refounder: bundle.refounder,
    };

    const invite = bundle.creator_npub ? { creator: bundle.creator_npub, label: bundle.label } : undefined;
    return this.motions.run(material.community_id, lifecycle, async (assertLive) => {
      // One lane step decides, so concurrent joins of one community build one engine (D-34).
      const { community, added } = await this.mutateCommunityList(async () => {
        assertLive();
        const existing = this.communities.get(material.community_id);
        if (existing) return { community: existing, added: false };
        const recorded = this.recordJoin(material);
        await this.writeMirror();
        return { community: recorded, added: true };
      });
      // Our attributed Join (CORD-05 §1), re-published for a joined community (CORD-02 §5 coalesces it), then the list
      // save, an explicit mutation that always publishes, even when the Join rejected (D-34).
      await this.publishThenSave(async () => {
        const attribution = added ? invite : await heldJoinAttribution(community.guestbookStore, this.pubkey, invite);
        await community.publishToPlane(
          { plane: "guestbook" },
          await JoinLeaveFactory.create("join", { invite: attribution }),
          {},
        );
      }, assertLive);
      this.log(added ? "joined community=%s" : "join re-published community=%s", community.communityId.slice(0, 8));
      return community;
    });
  }

  /**
   * Tombstone a membership across devices and prune its dead entry (CORD-02 §8).
   * Check the document, not running engines, so unconstructable memberships can
   * still leave. Unknown community ids are a no-op; a client that is not started rejects (D-30). Joins and leaves of
   * one community take effect in call order (D-34).
   */
  async leave(cid: string): Promise<void> {
    this.assertStarted();
    this.renewListRead();
    await this.motions.run(cid, this.listLifecycle, (assertLive) => this.leaveInOrder(cid, assertLive));
  }

  /** {@link leave}'s body, run in call order with this community's other Join/Leave calls and refused by `assertLive`
   *  after each await once its lifecycle ended. */
  private async leaveInOrder(cid: string, assertLive: () => void): Promise<void> {
    const known = this.communities.has(cid) || this.list.some((e) => e.community_id === cid);
    if (!known) return;
    this.log("leave requested community=%s", cid.slice(0, 8));
    // Engine-less membership: still leavable (optional chain — a wedge case has no engine to await).
    await this.communities.get(cid)?.leave();
    await this.mutateCommunityList(async () => {
      assertLive();
      this.removeCommunity(cid); // already safe with no engine (every step optional-chained)
      // Tombstone the membership so the leave propagates across devices (a bare omission would merge back as
      // still-joined, CORD-02 §8). `leaveCommunity` derives it from (cid, timestamp), not from the entry, so it comes
      // first only to keep the two effects in reading order: mark dead, then remove the bytes.
      this.tombstones = leaveCommunity(cid, Date.now())(this.list, this.tombstones).tombstones;
      // CR-02(a)/(b): prune the entry's BYTES from the document, not just its
      // liveness — see {@link pruneDeadEntries} for the full argument (liveness
      // safety, idempotence, and why it must not itself mark the list dirty).
      this.pruneDeadEntries();
      await this.writeMirror();
    });
    // Leaving is an explicit mutation — always publish the tombstoned list, in this lifecycle only.
    assertLive();
    await this.saveCommunityList();
    this.log("left community=%s", cid.slice(0, 8));
  }

  /** Record an explicit join after engine construction succeeds (CORD-02 §8 has no membership cap). */
  private recordJoin(material: JoinMaterial): ConcordCommunity {
    const addedAt = Date.now();
    const prospective: CommunityListCommunity = {
      community_id: material.community_id,
      seed: material,
      current: material,
      added_at: addedAt,
    };
    const community = this.addCommunity(material);
    this.list = joinCommunity(prospective)(this.list, this.tombstones).communities;
    return community;
  }

  /**
   * D-34 (CORD-02 §8): run a join's or create's publication, then request the normal Community List save whether it
   * resolved or rejected, so a recorded membership is never left unsaved; then rethrow the publication's original
   * error. The save reports its own failures through `diagnostics$` and never replaces that error. `assertLive` refuses
   * the save once the call's lifecycle ended (D-30): the next lifecycle publishes the held membership itself.
   */
  private async publishThenSave(publish: () => Promise<void>, assertLive: () => void): Promise<void> {
    const failure = await publish().then(() => undefined, (error: unknown) => ({ error }));
    assertLive();
    await this.saveCommunityList().catch((error) => {
      if (!failure) throw error;
    });
    if (failure) throw failure.error;
  }

  /** Builds, registers and starts one community engine, subscribing to its state so the
   *  aggregate `communities$` stays current. */
  private addCommunity(material: JoinMaterial): ConcordCommunity {
    const community: ConcordCommunity = new ConcordCommunity({
      material,
      signer: this.signer,
      pubkey: this.pubkey,
      pool: this.pool,
      eventStore: this.eventStore,
      uploader: this.uploader,
      relays: this.defaultRelays,
      extraRelays: this.extraRelaysOption,
      pinUpkeep: this.pinUpkeep,
      storage: this.storage,
      storeFactory: this.storeFactory
        ? (_cid, planeKey) => this.storeFactory!(material.community_id, planeKey)
        : undefined,
      // Threaded through so the one NIP-59 Direct-Invite grant publish (D-16/D-17
      // exception) has a handler — see ConcordCommunityOptions.userOnAuthRequired.
      userOnAuthRequired: this.userOnAuthRequired,
      logger: this.log.extend("community").extend(material.community_id.slice(0, 8)),
      onMaterialChange: (changed) => this.persistMaterialChange(changed, community),
      onRemoved: (removed) => this.handleRemoved(removed),
      onInviteCreated: (invite) => this.invites.record(invite),
      onInviteRevoked: (invite) => this.invites.tombstone(invite),
      onRefounded: (cid) => this.refreshInvitesFor(cid),
      onDiagnostic: (diagnostic) => this.diagnostics.emit(diagnostic),
    });
    this.communities.set(material.community_id, community);
    this.stateSubs.set(
      material.community_id,
      community.state$.subscribe(() => this.emitCommunities()),
    );
    // Direct Invites that arrived before this community was joined apply now.
    for (const invite of this.inviteWatcher?.invites$.value ?? []) this.onDirectInvite(invite);
    void community.start();
    this.purgeSchedules.attach(community);
    this.emitCommunities();
    return community;
  }

  /** Persists a community's rolled-forward material through the serialized mutation lane,
   *  so concurrent rotations cannot interleave and lose one another's writes. */
  private persistMaterialChange(changed: JoinMaterial, source: ConcordCommunity): Promise<void> {
    return this.mutateCommunityList(async () => {
      const ownsMembership = () =>
        this.communities.get(changed.community_id) === source &&
        isCommunityLive(this.list, this.tombstones, changed.community_id);
      // Retired engines must not resurrect a leave or overwrite their replacement.
      if (!ownsMembership()) return;
      const previous = this.list.find((entry) => entry.community_id === changed.community_id);
      const current = previous ? listDocument.mergeMaterialChange(previous, changed) : changed;
      const staged = refreshCommunity(current)(this.list, this.tombstones).communities;
      await writeMirrorDocument(this.storage, this.pubkey, this.documentExtras, staged, this.tombstones);
      if (!ownsMembership()) {
        // stop/remove can retire the source during the accepted write. Restore
        // the unchanged document before releasing its lane to removal/restart.
        await writeMirrorDocument(this.storage, this.pubkey, this.documentExtras, this.list, this.tombstones);
        return;
      }
      this.list = staged;
      this.markCommunityListDirty();
    });
  }

  /** CORD-02 §8: every document mutation and mirror write shares one transaction lane.
   * Publication and engine restoration run outside it because their callbacks may enqueue writes. */
  private mutateCommunityList<T>(work: () => Promise<T> | T): Promise<T> {
    this.invalidateCommunityListPublication();
    const transaction = this.communityListMutationTail.then(async () => {
      const before = this.communityListFingerprint();
      try {
        return await work();
      } finally {
        const after = this.communityListFingerprint();
        if (after !== before) this.listChanged$.next();
        if (after !== before && after !== this.publishedListFingerprint) this.markCommunityListDirty();
      }
    });
    this.communityListMutationTail = transaction.then(() => undefined, () => undefined);
    return transaction;
  }

  /** Retire signer drafts immediately; their pending awaits may finish harmlessly later. */
  private invalidateCommunityListPublication(): void {
    this.communityListRevision++;
    for (const invalidate of this.listPublicationInvalidators) invalidate();
  }

  /** Compare canonical membership plaintext independently of randomized ciphertext. */
  private communityListFingerprint(): string {
    return canonicalJson({ entries: this.list, tombstones: this.tombstones });
  }

  /** Disposes one community engine and drops it from the aggregate. */
  private removeCommunity(cid: string): void {
    this.stateSubs.get(cid)?.unsubscribe();
    this.stateSubs.delete(cid);
    const community = this.communities.get(cid);
    if (community) this.purgeSchedules.detach(community);
    community?.dispose();
    this.communities.delete(cid);
    this.emitCommunities();
  }

  /** A Refounding excluded us (CORD-06): drop the community and tombstone it.
   *  WR-08: routes through the same {@link pruneDeadEntries} as `leave()` —
   *  an involuntary removal is the SAME "membership is now dead" transition,
   *  and two code paths for one transition with different document effects
   *  is exactly how the unrecoverable wedge was reached (an over-cap entry
   *  removed by Refounding has no engine afterward, so `leave()`'s own prune
   *  could never reach it either). Keeps its existing flag-dirty-rather-than-
   *  publish behavior unchanged — the prune itself never publishes. */
  private handleRemoved(cid: string): void {
    this.removeCommunity(cid);
    void this.mutateCommunityList(async () => {
      this.tombstones = leaveCommunity(cid, Date.now())(this.list, this.tombstones).tombstones;
      this.pruneDeadEntries();
      await this.writeMirror();
      // Involuntary removal during sync/live — flag dirty rather than publish inline so a sync stays
      // side-effect-free; the opt-in auto-save (or a later explicit mutation) propagates the tombstone.
      this.markCommunityListDirty();
    });
  }

  /**
   * Prune derived-dead entries, never tombstones (CORD-02 §8). Safe to repeat
   * after stale merges: only a newer explicit re-join restores liveness.
   * Does not mark dirty or publish, avoiding a publish loop with stale peers.
   */
  private pruneDeadEntries(): void {
    // Evaluated against a stable snapshot of the pre-filter array — isCommunityLive
    // maxes added_at across every duplicate community_id in the WHOLE array, so a
    // partially-rebuilt array fed back into it would give a wrong answer mid-filter.
    const snapshot = this.list;
    this.list = snapshot.filter((e) => isCommunityLive(snapshot, this.tombstones, e.community_id));
  }

  /** Re-emits the aggregate community snapshot from each engine's current state. */
  private emitCommunities(): void {
    this.communities$.next([...this.communities.values()].map((c) => c.state$.value));
  }

  /** Re-post a community's live invite bundles after a Refounding (CORD-05 §2). The
   *  Invite List holds the per-link signer secrets, so the refresh is driven here
   *  and handed to the community engine, which rebuilds each bundle from the fresh
   *  material. Revoked links are skipped — their coordinate is already a tombstone. */
  private refreshInvitesFor(cid: string): void {
    const community = this.communities.get(cid);
    if (!community) return;
    const links = this.invites.forCommunity(cid).filter((link) => !link.revoked);
    if (links.length === 0) return;
    this.publishLog("refreshing %d invite bundle(s) community=%s", links.length, cid.slice(0, 8));
    void community.refreshInviteBundles(links).catch((error) => {
      this.diagnostics.report({ stage: "invite-refresh", communityId: cid, error });
    });
  }

  /** Read the local mirror and merge it into the document. The mirror holds the same
   *  `{entries, tombstones}` shape the relay copy does, so local and remote state combine through
   *  the identical CORD-02 §8 primitives — a mirror can contribute an unpublished join but can
   *  never clobber a tombstone another device wrote. */
  private async loadMirror(): Promise<void> {
    try {
      await this.mutateCommunityList(async () => {
        // A restart must read after any accepted obsolete save is compensated.
        const mirror = await readMirrorDocument(this.storage, this.pubkey);
        if (!mirror) return;
        this.list = mergeCommunities(this.list, mirror.entries);
        this.tombstones = mergeCommunityTombstones(this.tombstones, mirror.tombstones);
        // Carry the mirror's document snapshot forward too (D-25), existing-first-then-new like `watchLists`.
        this.documentExtras = { ...this.documentExtras, ...mirror };
      });
    } catch (error) {
      this.diagnostics.report({ stage: "mirror-read", error });
    }
  }

  /** Writes the local membership mirror, which is what makes {@link start} instant and
   *  offline-safe. Keyed as `entries` to match the wire document so one helper parses both. */
  private saveMirror(): Promise<void> {
    return this.mutateCommunityList(() => this.writeMirror());
  }

  /** Write a mirror while already holding the document lane. */
  private async writeMirror(): Promise<void> {
    try {
      await writeMirrorDocument(this.storage, this.pubkey, this.documentExtras, this.list, this.tombstones);
    } catch (error) {
      this.diagnostics.report({ stage: "mirror-write", error });
    }
  }

  /** Subscribe to the exposed list casts: auto-unlock when configured, and (for the Community
   *  List) reconcile the decrypted memberships into our arrays and bootstrap the engines.
   *  Reconcile fires on every decrypted emission — whether the unlock was ours or the app's
   *  — because the cast's `communities$` re-emits on `update$` after `notifyEventUpdate`. */
  private watchLists(): void {
    this.listSub = (this.requireUser() as ConcordCommunityListUser)
      .concordCommunityList$.pipe(switchMap((cast) => (cast ? cast.communities$.pipe(map(() => cast)) : of(undefined))))
      .subscribe((cast) => {
        if (!cast) return;
        // A local echo already has validated, durably committed plaintext.
        // Skip its document transaction so publication cannot invalidate itself.
        if (cast.event.id === this.publishingCommunityListId) {
          this.observedCommunityListId = cast.event.id;
          return;
        }
        if (cast.event.id !== this.observedCommunityListId) {
          this.observedCommunityListId = cast.event.id;
          this.invalidateCommunityListPublication();
        }
        if (this.autoUnlock && !cast.unlocked) {
          this.autoUnlockCast(cast);
          return; // unlock → notifyEventUpdate re-emits us with the decrypted communities
        }
        const communities = cast.communities;
        if (!communities) return; // still locked → wait for the app to call .unlock()
        const lifecycle = this.listLifecycle;
        const transaction = this.mutateCommunityList(async () => {
          if (!this.started || lifecycle !== this.listLifecycle) return;
          // Merge into our arrays rather than replace (CORD-02 §8).
          const staged = mergeCommunities(this.list, communities, true);
          const tombstones = mergeCommunityTombstones(this.tombstones, cast.tombstones ?? []);
          const addsCapability = listDocument.addsControlCapability(this.list, staged);
          const document = getCommunityList(cast.event);
          const extras = document ? { ...this.documentExtras, ...document } : this.documentExtras;
          // A newly held secret crosses the same durable barrier as local material
          // transitions. Failed writes leave the running engine and local list unchanged.
          if (addsCapability || canonicalJson(staged) !== canonicalJson(this.list)) {
            await writeMirrorDocument(this.storage, this.pubkey, extras, staged, tombstones);
          }
          if (!this.started || lifecycle !== this.listLifecycle) return;
          this.list = staged;
          this.tombstones = tombstones;
          // Snapshot the document's top-level keys (WIRE-09/D-23), INCLUDING its own `entries`/
          // `tombstones` as of this read — {@link saveCommunityList}/{@link saveMirror} always
          // assign this client's own merged arrays AFTER spreading this snapshot, so a stale
          // `entries`/`tombstones` sitting in it from this read can never win. The cast exposes no
          // whole-document accessor by design — its public surface is unwidened — so read the
          // parsed document off the cast's own event via the helper instead. Existing-first-
          // then-new spread order: a key read earlier this session survives an emission that
          // happens not to carry it, while the freshest read for any given key wins.
          this.documentExtras = extras;
          // Seed the fingerprint from the REMOTE-only content (not the merged `this.list`) so a
          // genuine local-only addition can still publish, but a save that would reproduce exactly
          // what the relay already holds is skipped. A self-published event echoing back here
          // re-seeds this to the same value → idempotent, no loop.
          this.publishedListFingerprint = canonicalJson({
            entries: mergeCommunities([], communities),
            tombstones: mergeCommunityTombstones([], cast.tombstones ?? []),
          });
          this.signalListHydrated?.(); // release start()'s pre-auto-save wait now the relay copy is merged
        });
        void transaction.then(async () => {
          if (!this.started || lifecycle !== this.listLifecycle) return;
          await this.reconcileCommunities();
          await this.communityListMutationTail;
          if (
            !this.started || lifecycle !== this.listLifecycle ||
            this.eventStore.getReplaceable(COMMUNITY_LIST_KIND, this.pubkey)?.id !== cast.id
          ) return;
          // CORD-02 §8: only after engine adoption and its mirror writes finish
          // can this selected private edition be the baseline of a newer save.
          this.reconciledCommunityList = { id: cast.id, lifecycle };
          if (this.deferredCommunityListSaveLifecycle === lifecycle) {
            this.deferredCommunityListSaveLifecycle = undefined;
            await this.listLane?.save();
          }
        }).catch((error) => {
          this.signalListHydrated?.();
          this.diagnostics.report({ stage: "community-list-restore", error });
        });
      });
  }

  /** Unlock all retained fragment editions, reconcile their union into the local mirror, and publish a save that was
   *  held over the locked fragments. While started this is one step on the list lane. */
  async unlockCommunityListFragments(): Promise<void> {
    if (this.disposed) throw new ConcordClientDisposedError();
    this.renewListRead();
    if (this.listLane) return this.listLane.unlock();
    const lifecycle = this.listLifecycle;
    await this.adoptFragments(await unlockStoredFragments(this.listSync, this.eventStore, this.pubkey), lifecycle);
  }

  /** Merge a decrypted fragment document into the document and mirror, then reconcile the engines (CORD-02 §8). */
  private async adoptFragments(remote: ParsedCommunityList, lifecycle: number): Promise<void> {
    await this.mutateCommunityList(async () => {
      if (lifecycle !== this.listLifecycle) return;
      const entries = mergeCommunities(this.list, remote.entries, true);
      const tombstones = mergeCommunityTombstones(this.tombstones, remote.tombstones);
      const extras = { ...this.documentExtras, ...remote };
      await writeMirrorDocument(this.storage, this.pubkey, extras, entries, tombstones);
      if (lifecycle !== this.listLifecycle) return;
      this.list = entries;
      this.tombstones = tombstones;
      this.documentExtras = extras;
    });
    await this.reconcileCommunities();
  }

  /** Issue the user-signer decrypt of a list cast at most once per event id. The unlock's
   *  `notifyEventUpdate` re-emits the now-decrypted cast for the reconcile path. */
  private autoUnlockCast(cast: ConcordCommunityList): void {
    if (!this.signer.nip44 || this.autoUnlocked.has(cast.id)) return;
    this.autoUnlocked.add(cast.id);
    const lifecycle = this.listLifecycle;
    void cast.unlock(this.signer).catch((error) => {
      if (
        lifecycle !== this.listLifecycle ||
        this.eventStore.getReplaceable(COMMUNITY_LIST_KIND, this.pubkey)?.id !== cast.id
      ) return;
      this.markCommunityListDirty();
      this.diagnostics.report({ stage: "community-list-unlock", error });
    });
  }

  /** Match running engines to merged live memberships (CORD-02 §8).
   *  Prune dead entries before the first await so stale merges are cleaned in the same turn. */
  private async reconcileCommunities(): Promise<void> {
    const lifecycle = this.listLifecycle;
    const live = await this.mutateCommunityList(() => {
      this.pruneDeadEntries();
      return new Map(liveCommunities(this.list, this.tombstones).map((e) => [e.community_id, e]));
    });
    let changed = false;
    for (const cid of this.communities.keys()) {
      if (live.has(cid)) continue;
      this.removeCommunity(cid);
      // WR-01 (12.3-12): a reaped community is no longer live, so any recorded
      // failure fingerprint for it is stale — clear it so a future re-add
      // (e.g. a genuine re-join) is retried rather than permanently suppressed.
      this.failedConstructionFingerprint.delete(cid);
      changed = true;
    }
    for (const [cid, community] of live) {
      if (!this.started || lifecycle !== this.listLifecycle) return;
      if (!isCommunityLive(this.list, this.tombstones, cid)) continue;
      const existing = this.communities.get(cid);
      if (existing) {
        await existing.restoreHeldControl(community.current);
        continue;
      }
      if (!community.current?.community_id) continue;
      // Skip construction failures without deleting membership or blocking peers.
      // Fingerprint material, not just the id: unchanged failures are suppressed,
      // but corrected entries can retry without repeated subscriptions or logs.
      const fingerprint = canonicalJson(community.current);
      if (this.failedConstructionFingerprint.get(cid) === fingerprint) continue;
      try {
        this.addCommunity(community.current);
      } catch (err) {
        this.failedConstructionFingerprint.set(cid, fingerprint);
        this.log(
          "reconcile skipped an unconstructable community=%s: %s",
          cid.slice(0, 8),
          (err as Error)?.message ?? err,
        );
        continue;
      }
      this.failedConstructionFingerprint.delete(cid);
      changed = true;
    }
    if (changed) await this.saveMirror();
  }

  /** D-26: a held change derived from the mirror-seeded document versus the completed remote copy. */
  private heldSaveDue(): boolean {
    const imported = this.eventStore.getReplaceable(COMMUNITY_LIST_KIND, this.pubkey);
    return listDocument.heldSaveDue(this.communityListSync, this.list, this.tombstones, imported);
  }

  /** Flag the community list as needing a re-publish (a sync-time epoch catch-up or a refounding
   *  removal). Emitting on each change resets the auto-save debounce so a burst of adoptions
   *  collapses into one save; UI subscribers see the "unpublished changes" state. */
  private markCommunityListDirty(): void {
    this.communityListDirty$.next(true);
  }

  /** Wire the opt-in debounced flush: whenever the list is dirty, publish once after the changes
   *  settle. Created only after the remote copy is merged (post-hydration in {@link start}) so a
   *  flush can't rebuild from the local mirror and clobber a newer relay copy. Because
   *  {@link communityListDirty$} is a BehaviorSubject, a dirty flag raised before this subscription
   *  exists is replayed on subscribe and still flushes. */
  private startAutoSave(): void {
    if (this.autoSaveSub) return;
    this.autoSaveSub = this.communityListDirty$
      .pipe(
        filter((dirty) => dirty),
        debounceTime(COMMUNITY_LIST_FLUSH_DEBOUNCE_MS),
      )
      .subscribe(() => {
        if (this.communityListDirty$.value) void this.listLane?.save();
      });
  }

  /** Encrypt/sign/publish the user's Community List fragments (kind 33302) when local memberships
   *  differ from the last known relay copy. No-op (no signer call) when content is unchanged,
   *  and clears {@link communityListDirty$} once the list is back in sync. A document or
   *  lifecycle change retires this save; its obsolete signer prompt may still finish later.
   *  Newer unpublished changes remain dirty for the next save. A selected private edition
   *  that has not finished reconciliation defers this save, which retries after successful
   *  reconciliation. Manual unlock remains required when auto-unlock is disabled. */
  async saveCommunityList(): Promise<void> {
    if (!this.signer.nip44 || !this.started) return; // D-30: a stopped client holds nothing for later
    await this.listLane?.save({ explicit: true }); // an explicit save renews an exhausted read retry
  }

  /** CORD-02 §8: a selected kind-13302 edition not yet reconciled in this lifecycle defers a save until it is. */
  private deferCommunityListSave(): boolean {
    const selected = this.eventStore.getReplaceable(COMMUNITY_LIST_KIND, this.pubkey);
    const reconciled = this.reconciledCommunityList;
    if (!selected || (reconciled?.id === selected.id && reconciled.lifecycle === this.listLifecycle)) return false;
    this.deferredCommunityListSaveLifecycle = this.listLifecycle;
    // D-24: an edge only, or auto-save re-runs every debounce. watchLists replays the deferred save after
    // reconciliation, and the lane re-queues a retired save, so no repeated `true` emission is needed.
    this.listHost.flagHeld();
    return true;
  }
}
