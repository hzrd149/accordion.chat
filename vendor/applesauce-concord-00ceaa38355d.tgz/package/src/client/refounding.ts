import { mergeRelaySets, normalizeRelayUrl } from "applesauce-core/helpers/relays";
import type { PublishResponse } from "applesauce-relay";
import type { RefoundingPlan } from "../helpers/keys.ts";
import type { GroupKey } from "../helpers/crypto.ts";
import type { ChannelKey, JoinMaterial } from "../types.ts";
import type { NostrEvent } from "applesauce-core/helpers/event";

/** The four document kinds a Refounding publishes (CORD-06 §3). The two rekeys and the
 *  control compaction are mandatory; the guestbook snapshot is attempted afterwards and
 *  only warns on failure, so it is tracked separately from the rest. */
export type RefoundingArtifactKind = "root-rekey" | "channel-rekey" | "control-compaction" | "guestbook-snapshot";

/** One published Refounding document, identified well enough to prove its relay coverage. */
export interface RefoundingArtifact {
  /** Stable signed event identifier; never secret-bearing event content. */
  id: string;
  /** Which of the four Refounding documents this is. */
  kind: RefoundingArtifactKind;
}

/** The raw outcome of trying to publish one artifact, before it is judged against the relay set. */
export interface RefoundingArtifactPublication {
  /** The artifact that was published. */
  artifact: RefoundingArtifact;
  /** Per-relay acknowledgements actually received. Relays that never answered are simply absent. */
  responses: PublishResponse[];
  /** Original rejected publish cause, retained programmatically but never formatted. */
  cause?: unknown;
}

/** How one protocol relay answered for one artifact. `"missing"` means the relay never
 *  answered at all, while `"publish-failed"` means the publish itself threw, so no
 *  per-relay answer was ever possible — the two are kept apart because only the first
 *  can be resolved by retrying against that relay. */
export type RefoundingRelayStatus = "accepted" | "rejected" | "missing" | "publish-failed";

/** One relay's answer for one artifact. */
export interface RefoundingRelayEvidence {
  /** Normalized relay URL, always drawn from the configured protocol relay set. */
  relay: string;
  /** That relay's answer. */
  status: RefoundingRelayStatus;
}

/** The complete, auditable record of where one artifact did and did not land. */
export interface RefoundingArtifactEvidence {
  /** The artifact this evidence is about. */
  artifact: RefoundingArtifact;
  /** Just the relays that accepted it — the input to the common-relay intersection. */
  acceptedRelays: string[];
  /** Every protocol relay with its status, including the ones that refused or stayed silent. */
  relays: RefoundingRelayEvidence[];
  /** Publish and per-relay failure causes, retained for the app to inspect rather than formatted here. */
  causes: unknown[];
}

/** Whether a Refounding is durable enough to adopt. The test is deliberately a *common*
 *  majority rather than a per-artifact one: a member who reaches any relay in
 *  {@link commonRelays} finds the whole operation there, so the Refounding cannot be
 *  observed as a fragment split across relays that each hold only part of it. */
export interface RefoundingCoverage {
  /** True when something was published and the common set meets {@link required}. */
  accepted: boolean;
  /** The configured protocol relays, normalized and deduplicated. */
  protocolRelays: string[];
  /** Strict majority of {@link protocolRelays} — `floor(n / 2) + 1`. */
  required: number;
  /** Relays that accepted *every* artifact; the intersection, not a per-artifact union. */
  commonRelays: string[];
  /** Per-artifact evidence backing the verdict, so a rejection can be explained rather than just reported. */
  evidence: RefoundingArtifactEvidence[];
}

/** A non-fatal Refounding problem: the rotation is adopted, but something optional did not land. */
export interface RefoundingWarning {
  /** Only the guestbook snapshot degrades to a warning; every other artifact is mandatory. */
  kind: "guestbook-snapshot-publication";
  /** The rotation this warning belongs to. */
  rotationId: string;
  /** The artifacts that failed to reach a common majority. */
  artifactIds: string[];
  /** Full per-artifact evidence, so the app can show which relays are behind. */
  evidence: RefoundingArtifactEvidence[];
  /** The underlying failure causes, unformatted. */
  causes: unknown[];
}

/** A completed Refounding, as reported back to the app. */
export interface RefoundingResult {
  /** Identifies the rotation across its artifacts, evidence and any persisted record. */
  rotationId: string;
  /** The new root epoch now in force. */
  epoch: number;
  /** Optional artifacts that did not land. Empty on a fully clean Refounding. */
  warnings: RefoundingWarning[];
  /** Evidence for the mandatory artifacts. */
  evidence: RefoundingArtifactEvidence[];
  /** The relays that carry the whole operation. */
  commonRelays: string[];
}

/** How far a persisted Refounding got, so an interrupted one resumes at the right step
 *  instead of republishing work that already reached a common majority. */
export type PendingRefoundingStage =
  | "prepared"
  | "root-confirmed"
  | "mandatory-confirmed"
  | "adopted"
  | "snapshot-attempted";

/**
 * Why `refound()` refuses to finish a stored Refounding (CORD-06 §3), so `discardPendingRefounding()` may remove it:
 * `blocked` (the record was marked blocked), `other-epoch` (it belongs to another epoch) or `preparation-changed` (the
 * Control state it was prepared against has changed since).
 */
export type PendingRefoundingRefusal = "blocked" | "other-epoch" | "preparation-changed";

/** Complete, signed Refounding operation persisted between process lifetimes. */
export interface PendingRefoundingRecord {
  /** Immutable signed channel successors prepared on the committed winning chain (CORD-06 §3). */
  channelRepairs?: Array<{
    /** Complete winning base material at preparation; never the losing parent's pair. */
    winner: JoinMaterial;
    /** Independent channel continuity point on that chain. */
    predecessor: ChannelKey;
    /** Original losing-branch secret at the successor channel epoch. */
    next: ChannelKey;
    /** Exact address used to seal and sign these artifacts. */
    rekeyKey: GroupKey;
    /** Original signed envelopes, preserved unchanged on every retry. */
    wraps: NostrEvent[];
    /** Actual normalized protocol relay acknowledgements. */
    evidence: RefoundingArtifactEvidence[];
    /** Confirmation is durable before channel material is committed. */
    stage: "prepared" | "confirmed" | "adopted";
  }>;
  /** Normalized protocol membership captured once; transport extras never count. */
  protocolRelays?: string[];
  /** Captured authority/material and recipient identities, protected with the signed operation. */
  preparation?: {
    fingerprint: string;
    request: string;
    recipients: Array<{ pubkey: string; staff: boolean }>;
    excluded: string[];
    channelIds: string[];
  };
  /** A durable write completed after invalidation; this operation must not resume automatically. */
  blocked?: "stale-preparation";
  /** Record schema version. Anything else is refused on load rather than guessed at. */
  version: 1;
  /** The community this Refounding belongs to; checked on load so one community's record
   *  can never be applied to another. */
  communityId: string;
  /** The epoch being left behind. The plan's `newEpoch` must be exactly one past it. */
  priorEpoch: number;
  /** Identifies the rotation; must match the first rekey wrap in {@link plan}. */
  rotationId: string;
  /** How far the operation got before it was interrupted. */
  stage: PendingRefoundingStage;
  /** The signed wraps and rolled-forward key state to finish publishing. */
  plan: RefoundingPlan;
  /** Coverage already proven for the mandatory artifacts, so a resumed run does not re-publish them. */
  mandatoryEvidence: RefoundingArtifactEvidence[];
  /** The relays that carried the mandatory artifacts. */
  commonRelays: string[];
  /** Warnings accumulated so far, carried across the interruption. */
  warnings: RefoundingWarning[];
}

function normalizeOrigin(from: string | undefined): string | undefined {
  if (!from) return undefined;
  try {
    return normalizeRelayUrl(from);
  } catch {
    return undefined;
  }
}

/** Evaluate whether one strict majority of protocol relays accepted every artifact. */
export function evaluateCommonRelayCoverage(
  publications: RefoundingArtifactPublication[],
  configuredProtocolRelays: string[],
): RefoundingCoverage {
  const protocolRelays = mergeRelaySets(configuredProtocolRelays);
  const protocolSet = new Set(protocolRelays);
  const required = Math.floor(protocolRelays.length / 2) + 1;
  const evidence = publications.map(({ artifact, responses, cause }) => {
    const responseByRelay = new Map<string, PublishResponse>();
    for (const response of responses) {
      const relay = normalizeOrigin(response.from);
      if (relay && protocolSet.has(relay)) responseByRelay.set(relay, response);
    }
    const relays = protocolRelays.map((relay): RefoundingRelayEvidence => {
      const response = responseByRelay.get(relay);
      return {
        relay,
        status: cause !== undefined
          ? "publish-failed"
          : response?.ok === true
          ? "accepted"
          : response
          ? "rejected"
          : "missing",
      };
    });
    const causes = [
      ...(cause === undefined ? [] : [cause]),
      ...responses.flatMap((response) => (response.error === undefined ? [] : [response.error])),
    ];
    return {
      artifact,
      acceptedRelays: relays.filter(({ status }) => status === "accepted").map(({ relay }) => relay),
      relays,
      causes,
    };
  });
  const commonRelays = protocolRelays.filter((relay) => evidence.every((row) => row.acceptedRelays.includes(relay)));
  return {
    accepted: publications.length > 0 && commonRelays.length >= required,
    protocolRelays,
    required,
    commonRelays,
    evidence,
  };
}

/**
 * Thrown when a Refounding's mandatory artifacts never reached a common relay majority
 * ({@link evaluateCommonRelayCoverage}). An `AggregateError` because there is rarely one
 * failure to report: each artifact can fail at each relay, and the whole picture is what
 * makes the result actionable. The evidence travels on the error so a caller can show
 * which relays are behind without re-deriving it.
 */
export class RefoundingPublicationError extends AggregateError {
  /** Artifacts that carry a failure cause or were not accepted everywhere. */
  readonly failedArtifactIds: string[];
  /** Every underlying cause, flattened across artifacts. Also passed as this error's `errors`. */
  readonly causes: unknown[];

  /**
   * Derives the failed-artifact list and the flattened cause list from the evidence, and
   * hands the causes to `AggregateError` as this error's `errors`.
   *
   * @param rotationId The rotation that failed.
   * @param evidence Per-artifact relay evidence, retained for inspection and used to derive
   *   {@link failedArtifactIds} and {@link causes}.
   */
  constructor(
    public readonly rotationId: string,
    public readonly evidence: RefoundingArtifactEvidence[],
  ) {
    const causes = evidence.flatMap((row) => row.causes);
    super(causes, `refounding publication failed: common relay majority missing for rotation ${rotationId}`);
    this.name = "RefoundingPublicationError";
    this.causes = causes;
    this.failedArtifactIds = evidence
      .filter((row) => row.causes.length > 0 || row.relays.some(({ status }) => status !== "accepted"))
      .map((row) => row.artifact.id);
  }
}
