// CORD-04 §7 Pins: the community's pin surface. Reads project through the pure projection (display rules live in
// helpers/pin-projection.ts and models/pins.ts); this module only wires state, stores and publication. Internal: it is
// not exported from any barrel.
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";
import type { Rumor } from "applesauce-core/helpers/event";
import { combineLatest, distinctUntilChanged, map, startWith } from "rxjs";
import type { Observable } from "rxjs";

import { isAuthorDeleted } from "../helpers/author-deletion.ts";
import { channelGroupKey, pinsLocator } from "../helpers/crypto.ts";
import { EDIT_KIND } from "../helpers/edit.ts";
import { channelEpochOf, type ConcordKeys, type PlaneInfo, planeKeyFor } from "../helpers/keys.ts";
import { projectPins } from "../helpers/pin-projection.ts";
import {
  encodePinList,
  type PinEntry,
  type PinListRead,
  readPinList,
  type VerifiedPin,
  verifyPinEntry,
} from "../helpers/pins.ts";
import {
  canEditionEverVerify,
  collapsePinEntries,
  type EditionChainBase,
  isEditionRejectedByStanding,
  type PinUpkeepStage,
  pinWriteReadiness,
  withoutEdit,
} from "../helpers/pin-upkeep.ts";
import { ConcordPinsModel, type PinDisplayOptions } from "../models/pins.ts";
import { type CommunityState, type ConcordSyncPhase, type DecodedEvent, type JoinMaterial, VSK } from "../types.ts";
import type { EditionGuard } from "./admin.ts";
import type { DiagnosticsSink } from "./diagnostics.ts";
import type { DutyScope } from "./lifecycle.ts";
import { PinMaintainer } from "./pin-maintainer.ts";
import type { ConcordRumorStore } from "./storage.ts";

/**
 * Bounded memo of {@link verifyPinEntry}, keyed by channel and the exact entry bytes (CORD-04 §7 caching). It keeps its
 * own copy of each result and returns a fresh copy on every call, so a caller (or an app reading `pins()` and `pins$`)
 * that mutates a returned pin never changes a later result without re-verification.
 */
export class PinVerificationCache {
  private readonly cache = new Map<string, VerifiedPin | undefined>();

  /**
   * @param max Most entries retained; the oldest is evicted beyond it.
   * @param run The verifier to memoize.
   */
  constructor(
    private readonly max: number = 1_024,
    private readonly run: (entry: PinEntry, channelId: string) => VerifiedPin | undefined = verifyPinEntry,
  ) {}

  /** Verify an entry once per (channel, entry); undefined results are remembered too. Each call returns a fresh copy. */
  verify(entry: PinEntry, channelId: string): VerifiedPin | undefined {
    const key = `${channelId}:${bytesToHex(sha256(utf8ToBytes(JSON.stringify(entry))))}`;
    if (!this.cache.has(key)) {
      const result = this.run(entry, channelId);
      this.cache.set(key, result && structuredClone(result));
      while (this.cache.size > this.max) this.cache.delete(this.cache.keys().next().value as string);
    }
    const cached = this.cache.get(key);
    return cached && structuredClone(cached);
  }

  /** Forget every memoized result. */
  clear(): void {
    this.cache.clear();
  }
}

/** The epoch and conversation key a private channel's Pin List is sealed with, from one keys snapshot. */
export function privateChannelKeyOf(keys: ConcordKeys, channelId: string): { epoch: number; convKey: Uint8Array } {
  return {
    epoch: channelEpochOf(keys, channelId),
    convKey: planeKeyFor(keys, { plane: "channel", channelId }).convKey,
  };
}

/**
 * Why {@link ConcordCommunity.setPins} could not plan a Pin List write: `"not-synced"` (the community is not live yet),
 * `"suspended"` (the list's chain is unresolved), `"unreadable"` (a list exists but its sealed epoch key is not held,
 * or the channel is private and its current key, which a new list is sealed under, is not held),
 * `"changed"` (the list moved while the call was signing) or `"unverified-edition"` (the community is live, but a
 * known Pin List edition for the channel is not verified yet and could still verify once the Grant it cites syncs, so a
 * first list is not written over it; retrying while nothing changes will not help). An edition whose author was banned
 * or demoted after their cited Grant synced does not block: the new list is written over it.
 */
export type PinListNotReadyReason = "not-synced" | "suspended" | "unreadable" | "changed" | "unverified-edition";

/**
 * Thrown by `setPins` instead of writing when a Pin List write would be built from state it cannot trust (CORD-04 §7:
 * never rebuild a list from one that could not be read). Retry after the community sync is live, or re-read the pins with
 * `pins(channelId, { showBanned: true })`.
 */
export class PinListNotReadyError extends Error {
  /** The channel whose Pin List was not writable. */
  readonly channelId: string;
  /** Why the write was refused. */
  readonly reason: PinListNotReadyReason;

  /**
   * @param channelId The channel whose Pin List was not writable.
   * @param reason Why the write was refused.
   */
  constructor(channelId: string, reason: PinListNotReadyReason) {
    super(
      reason === "not-synced"
        ? `Pin List for channel ${channelId} is not ready: the community sync is not live or the list is not proven absent; retry after the community is live`
        : reason === "suspended"
        ? `Pin List for channel ${channelId} is suspended: its edition chain is unresolved`
        : reason === "unreadable"
        ? `Pin List for channel ${channelId} cannot be read or sealed with the keys held; refusing to write it`
        : reason === "unverified-edition"
        ? `Pin List for channel ${channelId} has an unverified edition whose cited Grant has not synced; refusing to write a first list over it`
        : `Pin List for channel ${channelId} changed while the write was being signed; re-read the pins with showBanned: true and retry`,
    );
    this.name = "PinListNotReadyError";
    this.channelId = channelId;
    this.reason = reason;
  }
}

/**
 * Whether a retained kind-3308 rumor names the entity coordinate `eid`, verified or not, leaving out editions that can
 * never verify ({@link canEditionEverVerify}, D-33) so an unauthorized injection cannot block a first Pin List, and
 * editions whose author current standing rejects ({@link isEditionRejectedByStanding}, D-34) so banning or demoting a
 * curator cannot freeze a channel's pins.
 */
export function hasRetainedEdition(history: Iterable<DecodedEvent>, eid: string, state: CommunityState): boolean {
  for (const decoded of history) {
    const { rumor } = decoded;
    if (
      rumor.kind === 3308 && rumor.tags.some((tag) => tag[0] === "eid" && tag[1]?.toLowerCase() === eid) &&
      canEditionEverVerify(decoded, state.material.owner, state.material.community_id) &&
      !isEditionRejectedByStanding(decoded, state)
    ) return true;
  }
  return false;
}

/** What {@link CommunityPins} needs from its community; closures keep it free of engine state. */
export interface CommunityPinsHost {
  /** The community id (hex). */
  communityId(): string;
  /** Current folded community state. */
  state(): CommunityState;
  /** Folded state changes. */
  state$: Observable<CommunityState>;
  /** Emits when channel key material changes outside the folded state. */
  materialChanged$: Observable<void>;
  /** Current join material, including held channel keys. */
  material(): JoinMaterial;
  /** Current community bans. */
  banlist$: Observable<Set<string>>;
  /** The raw store of a channel. */
  channelStore(channelId: string): ConcordRumorStore;
  /** Whether the local user may pin messages now. */
  canPin(): boolean;
  /** Epoch and conversation key sealing a private channel's Pin List. */
  privateChannelKey(channelId: string): { epoch: number; convKey: Uint8Array };
  /** The community sync phase. */
  phase(): ConcordSyncPhase;
  /**
   * Whether a retained kind-3308 edition names the entity coordinate, verified or not, unless it can never verify or
   * current standing rejects it.
   */
  retainedEdition(eid: string): boolean;
  /** The retained edition current standing rejects that a first write to the coordinate chains over (D-34). */
  rejectedEditionBase(eid: string): EditionChainBase | undefined;
  /** The community's duty scope, the only owner of background timers and retries (Phase 1 D-09). */
  duties(): DutyScope;
  /** Typed background diagnostics sink. */
  diagnostics: DiagnosticsSink;
  /** The local user's pubkey. */
  self: string;
  /** Sync phase changes. */
  phase$: Observable<ConcordSyncPhase>;
  /** Whether the local user may publish a Pin List now: not disposed or sealed, can sign Control, holds PIN_MESSAGES. */
  canWrite(): boolean;
  /** Whether to run automatic Pin List upkeep. */
  upkeep: boolean;
  /** Publish a Control edition, optionally guarded against a head that moves while signing. */
  publishEdition(
    vsk: number,
    eid: string,
    content: string,
    required?: boolean | string,
    guard?: EditionGuard,
  ): Promise<void>;
}

/** Pin reads and the explicit replacement write for one community. */
export class CommunityPins {
  private readonly cache = new PinVerificationCache();
  private readonly locators = new Map<string, string>();
  private readonly maintainer?: PinMaintainer;

  constructor(private readonly host: CommunityPinsHost) {
    if (!host.upkeep) return;
    this.maintainer = new PinMaintainer({
      duties: () => host.duties(),
      diagnostics: host.diagnostics,
      self: host.self,
      state: () => host.state(),
      state$: host.state$,
      phase: () => host.phase(),
      phase$: host.phase$,
      materialChanged$: host.materialChanged$,
      canWrite: () => host.canWrite(),
      pinList: (id) => this.pinList(id),
      headHash: (id) => this.headHash(id),
      headContent: (id) => this.headContent(id),
      channelInputs: (id) => host.channelStore(id).timeline([{ kinds: [5, EDIT_KIND] }], { batchWindow: false }),
      verify: (entry, id) => this.verify(entry, id),
      privateChannelKey: (id) => {
        try {
          return host.privateChannelKey(id);
        } catch {
          // No held key for this channel: the planner then refuses a sealed rewrite instead of guessing an epoch.
          return undefined;
        }
      },
      channelKeyEpochs: (id) => this.keyEpochs(id),
      publishPinList: (id, content, expectedHead, stage: PinUpkeepStage, check) =>
        host.publishEdition(VSK.PINS, this.locator(id), content, stage, { expectedHead, check }),
    });
  }

  private locator(channelId: string): string {
    let eid = this.locators.get(channelId);
    if (eid === undefined) {
      this.locators.set(channelId, eid = pinsLocator(hexToBytes(this.host.communityId()), channelId));
    }
    return eid;
  }

  /** The epochs of every key held for a channel, current first, as a fingerprint of which sealed lists can open. */
  private keyEpochs(channelId: string): string {
    const channel = this.host.material().channels.find((key) => key.id === channelId);
    return channel ? [channel, ...(channel.held ?? [])].map((key) => key.epoch).join(",") : "";
  }

  /** The selected verified, unsuspended Pin List head of a channel, when there is one. */
  private head(channelId: string) {
    const eid = this.locator(channelId);
    const verified = this.host.state().controlVerification;
    const head = verified?.heads.get(eid);
    return !head || verified?.suspended.has(eid) || head.vsk !== VSK.PINS ? undefined : head;
  }

  /** The hash of the selected verified Pin List head of a channel. */
  headHash(channelId: string): string | undefined {
    return this.head(channelId)?.hash;
  }

  /** The exact content of the selected verified Pin List head of a channel. */
  headContent(channelId: string): string | undefined {
    return this.head(channelId)?.edition.rumor.content;
  }

  /** Verify a Pin List entry for a channel through the bounded memo. */
  verify(entry: PinEntry, channelId: string): VerifiedPin | undefined {
    return this.cache.verify(entry, channelId);
  }

  /** Open a verified Pin List; an absent head or unavailable private epoch is not an empty list. */
  pinList(channelId: string): PinListRead {
    const eid = pinsLocator(hexToBytes(this.host.communityId()), channelId);
    const verified = this.host.state().controlVerification;
    const head = verified?.heads.get(eid);
    if (!head || verified?.suspended.has(eid) || head.vsk !== VSK.PINS) return { available: false };
    return readPinList(head.edition.rumor.content, (epoch) => {
      const channel = this.host.material().channels.find((key) => key.id === channelId);
      const held = channel && [channel, ...(channel.held ?? [])].find((key) => String(key.epoch) === epoch);
      return held && channelGroupKey(hexToBytes(held.key), hexToBytes(channelId), held.epoch).convKey;
    });
  }

  /** The pins a reader should see now: edited text, self-deleted, banned-author and expired pins hidden by default. */
  async pins(channelId: string, options: PinDisplayOptions = {}): Promise<VerifiedPin[]> {
    const state = this.host.state();
    return projectPins(this.pinList(channelId), channelId, {
      rumors: await this.host.channelStore(channelId).getTimeline([{ kinds: [5, EDIT_KIND] }]),
      now: Date.now() / 1000,
      showExpired: options.showExpired,
      showBanned: options.showBanned,
      isBanned: (pubkey) => state.banlist.has(pubkey),
      verify: (entry, id) => this.cache.verify(entry, id),
    });
  }

  /** Reactive {@link pins}: re-emits on a new Edit, self-deletion, Pin List head or key change, and at expiry. */
  pins$(channelId: string, options: PinDisplayOptions = {}): Observable<VerifiedPin[]> {
    const eid = pinsLocator(hexToBytes(this.host.communityId()), channelId);
    const list$ = combineLatest([this.host.state$, this.host.materialChanged$.pipe(startWith(undefined))]).pipe(
      map(([state]) => {
        const epochs = this.keyEpochs(channelId);
        const head = state.controlVerification?.heads.get(eid);
        const status = state.controlVerification?.suspended.has(eid) ? "suspended" : (head?.hash ?? "none");
        return `${status}|${epochs}`;
      }),
      distinctUntilChanged(),
      map(() => this.pinList(channelId)),
    );
    // Invoked directly, not through store.model(): that cache hashes its arguments (observables and functions here)
    // and keeps an unsubscribed model warm on a timer that would outlive the caller.
    return ConcordPinsModel(channelId, list$, {
      bans: this.host.banlist$,
      showExpired: options.showExpired,
      showBanned: options.showBanned,
      verify: (entry, id) => this.cache.verify(entry, id),
    })(this.host.channelStore(channelId));
  }

  /**
   * Publish a deliberate whole-list replacement. A channel with no Pin List head gets version 1, but only once the
   * community is live and the list is proven absent; otherwise this throws {@link PinListNotReadyError}. A head that
   * moves while the call is signing is never overwritten. A message listed more than once is published once, at its
   * first position, from the copy whose bundled Edit is newest; an Edit its author deleted never counts as newest
   * (D-32), and a kept copy bundling one is published without its `edit` bundle (D-31). Build `entries` from
   * `pins(channelId, { showBanned: true })`: a default read omits banned authors' pins, and this call would drop them.
   */
  async setPins(channelId: string, entries: PinEntry[]): Promise<void> {
    if (this.host.phase() !== "live") throw new PinListNotReadyError(channelId, "not-synced");
    if (!this.host.canPin()) throw new Error("PIN_MESSAGES required");
    const channel = this.host.state().channels.find((value) => value.channel_id === channelId);
    if (!channel) throw new Error("Unknown channel");
    if (entries.some((entry) => !verifyPinEntry(entry, channelId))) throw new Error("Invalid pin proof");
    const rumors = await this.host.channelStore(channelId).getTimeline([{ kinds: [5] }]);
    // D-31: a kept copy whose bundled Edit its author deleted is published without that bundle, never republished.
    const collapsed = collapsePinEntries(entries, channelId, {
      rumors,
      verify: (entry, id) => this.cache.verify(entry, id),
    })
      .map(({ entry, pin }) =>
        pin.edit !== undefined && isAuthorDeleted(pin.edit, rumors) ? withoutEdit(entry) : entry
      );
    const eid = pinsLocator(hexToBytes(this.host.communityId()), channelId);
    const state = this.host.state();
    const readiness = pinWriteReadiness({
      phase: this.host.phase(),
      eid,
      verification: state.controlVerification,
      displayHeads: state.heads,
      retained: (id) => this.host.retainedEdition(id),
      listAvailable: this.pinList(channelId).available,
    });
    if (!readiness.ready) throw new PinListNotReadyError(channelId, readiness.reason);
    let privateKey: { epoch: number; convKey: Uint8Array } | undefined;
    if (channel.private) {
      try {
        privateKey = this.host.privateChannelKey(channelId);
      } catch {
        // CORD-04 §7: a private list is sealed under the channel's current key; without it nothing can be written.
        throw new PinListNotReadyError(channelId, "unreadable");
      }
    }
    const before = this.pinnedIds(channelId);
    await this.host.publishEdition(VSK.PINS, eid, encodePinList(collapsed, privateKey), false, {
      expectedHead: readiness.head?.hash ?? null,
      headChanged: () => new PinListNotReadyError(channelId, "changed"),
      // CORD-04 §1: a first head over an edition current standing rejects climbs past it rather than tying at version 1.
      chainOver: readiness.head ? undefined : this.host.rejectedEditionBase(eid),
    });
    // The messages this call newly pinned are this client's own pins: their deletion is upkept at once (D-08). Earlier
    // own pins stay on record while the published list still carries them.
    const published = collapsed.flatMap((entry) => this.cache.verify(entry, channelId)?.rumor.id ?? []);
    this.maintainer?.notePinned(channelId, published.filter((id) => !before.has(id)), new Set(published));
  }

  /** The recomputed ids of every verified entry of a channel's current Pin List. */
  private pinnedIds(channelId: string): Set<string> {
    const list = this.pinList(channelId);
    const ids = new Set<string>();
    if (list.available) {
      for (const entry of list.entries) ids.add(this.cache.verify(entry, channelId)?.rumor.id ?? "");
    }
    ids.delete("");
    return ids;
  }

  /**
   * Publish the empty Pin List a new channel starts with, when the local user may pin. Channel creation publishes
   * nothing beyond this seed (D-05).
   */
  async seedChannel(channelId: string, isPrivate: boolean): Promise<void> {
    if (!this.host.canPin()) return;
    const privateKey = isPrivate ? this.host.privateChannelKey(channelId) : undefined;
    await this.host.publishEdition(
      VSK.PINS,
      pinsLocator(hexToBytes(this.host.communityId()), channelId),
      encodePinList([], privateKey),
    );
  }

  /**
   * Whether a channel kind-5 is a historical self-scrub that stays admissible after dissolution (CORD-02 §9: nothing
   * new is published or retained except a proven self-delete; CORD-04 §7: a pinned message's author may delete it).
   * Every target must be authored by the deleter and bound to the channel: either a retained message, or a message
   * missing from the local store that is a currently verified pinned entry whose proven author is the deleter, since
   * the proof demonstrates both existence and authorship. Only local retention changes; this never publishes a Pin List.
   */
  async isHistoricalSelfDelete(info: PlaneInfo, rumor: Pick<Rumor, "kind" | "tags" | "pubkey">): Promise<boolean> {
    if (info.type !== "channel" || !info.channelId || rumor.kind !== 5) return false;
    const targets = rumor.tags.filter((tag) => tag[0] === "e");
    if (!targets.length || rumor.tags.some((tag) => tag[0] === "a")) return false;
    const store = this.host.channelStore(info.channelId);
    let pinned: Set<string> | undefined;
    for (const tag of targets) {
      const target = await store.getEvent(tag[1]);
      if (target) {
        if (
          target.pubkey !== rumor.pubkey || target.kind === 5 ||
          !target.tags.some((t) => t[0] === "channel" && t[1] === info.channelId)
        ) return false;
        continue;
      }
      pinned ??= this.pinnedBy(info.channelId, rumor.pubkey);
      if (!pinned.has(tag[1])) return false;
    }
    return true;
  }

  /** The recomputed ids of the verified pinned entries of a channel whose proven author is `author`. */
  private pinnedBy(channelId: string, author: string): Set<string> {
    const list = this.pinList(channelId);
    const ids = new Set<string>();
    if (!list.available) return ids;
    for (const entry of list.entries) {
      const verified = this.cache.verify(entry, channelId);
      if (verified?.rumor.pubkey === author) ids.add(verified.rumor.id);
    }
    return ids;
  }

  /**
   * Record a binding-checked channel-plane input before it is stored, so a later pin edit refresh can prove an Edit
   * from its seal (CORD-04 §7). A no-op when upkeep is off.
   */
  noteChannelInput(info: PlaneInfo, decoded: DecodedEvent): void {
    this.maintainer?.noteChannelInput(info, decoded);
  }

  /** Forget the Edit seals whose signed expiry passed by `now`, in Unix seconds (CORD-08 §3). A no-op when upkeep is off. */
  forgetExpiredInputs(now: number): void {
    this.maintainer?.forgetExpiredInputs(now);
  }

  /**
   * Record that this client just rekeyed a private channel, so its Pin List reseal runs as a rotation duty (CORD-04
   * §7). A no-op when upkeep is off.
   */
  noteRotation(channelId: string): void {
    this.maintainer?.noteRotation(channelId);
  }

  /** Stop upkeep and release the verification cache. */
  dispose(): void {
    this.maintainer?.dispose();
    this.cache.clear();
  }
}
