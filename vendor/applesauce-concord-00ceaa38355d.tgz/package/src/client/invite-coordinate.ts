// INVITE-01: pure helpers that pick the single NIP-01 winner at an invite coordinate and reject events
// that do not sit at it. Internal to the client; not exported from any barrel.

import type { NostrEvent } from "applesauce-core/helpers/event";
import { getReplaceableIdentifier } from "applesauce-core/helpers";

/**
 * Collapse a multi-relay union of events at one addressable coordinate to its
 * single NIP-01 winner (newest `created_at`, tie -> lowest `id`) — replicated
 * verbatim from `EventStore`'s replaceable-history winner selection
 * (`event-store.ts:264-267`) since no store exists pre-join (INVITE-01/D-03).
 * MUST run BEFORE any liveness/revocation check: a tombstone is exactly as
 * durable as the bundle it replaced (CORD-05 §2) and must compete for
 * "newest" on equal footing, never be pre-excluded (D-01).
 */
export function newestAtCoordinate(events: NostrEvent[]): NostrEvent | undefined {
  let winner: NostrEvent | undefined;
  for (const e of events) {
    if (!winner || e.created_at > winner.created_at || (e.created_at === winner.created_at && e.id < winner.id)) {
      winner = e;
    }
  }
  return winner;
}

/**
 * Does `event` actually sit at the invite coordinate `(33301, linkSigner, "")`?
 * INVITE-01/D-02: the outgoing `pool.request` filter (`authors`, `#d`) is a
 * REQUEST to relays, not a guarantee — `mapEventsToTimeline` unions whatever
 * every queried relay returns and never re-checks it against the filter. So a
 * single misbehaving/compromised relay could otherwise inject a kind-33301
 * event with an arbitrary author or non-empty `d` tag, win the `created_at`
 * race in {@link newestAtCoordinate}, and be treated as "the" coordinate's
 * winner (denying an otherwise-valid join, or shadowing the real newest event).
 * Enforce the coordinate constraints on the INBOUND events, never trusting the
 * relay set to have honored the filter.
 */
export function isAtCoordinate(event: NostrEvent, linkSigner: string): boolean {
  return event.pubkey === linkSigner && getReplaceableIdentifier(event) === "";
}
