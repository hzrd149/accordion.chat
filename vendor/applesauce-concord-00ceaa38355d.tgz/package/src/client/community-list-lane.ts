// CORD-02 §8 / D-31: one serialized Community List lane per client lifecycle. The kind-33302 read and its evidence
// recording, store-fragment ingest, unlock and adoption, and saves are steps on one promise tail, so no read, ingest or
// save of one lifecycle can interleave with another step or outlive `close()`. Internal: never exported from a barrel.
//
// Lane view rule (CORD-02 §8, D-31): a save plans and publishes only from a view no older than the store. Before it
// plans, the save step ingests every stored fragment this lane has not ingested (the stored part of the union a read
// ingests). Before every fragment it publishes, the write re-checks viewCurrent(). Any arrival or document change while
// a write is in flight retires it, and a retired save is re-queued behind the retirement, never dropped. An app-requested
// `write()` or `repack()` through the client's `communityListSync` is a lane step under the same rule (D-35): it ingests
// every stored fragment first, re-checks viewCurrent() before every fragment and runs again when an arrival retires it.
// It never runs outside a lane: with no open lane, or once its lane closed, it rejects (D-30).
//
// Lifecycle rule (D-30): app work queued in one client lifecycle never takes effect in a later lifecycle. A routed
// `write()` or `repack()` rejects with ConcordClientNotStartedError as soon as its lane closes, even while it waits
// behind a step or a sync task that never settles, and a closed lane refuses every fragment it has not published yet.
//
// Repair rule (CORD-02 §8, D-05, D-07, D-19): an interrupted repack leaves duplicate or dormant fragments. The lane owns
// their repair as one `community-list-repair` duty, requested only when knowledge is complete and every held copy is
// decrypted (an unread copy is never overwritten). Each attempt runs as a lane write step, so it starts from the ingest
// fixpoint and the sync's baseline check stops it before a publication over a concurrent arrival. The duty is the only
// retry owner, bounded by COMMUNITY_LIST_REPAIR_RETRY; its own publications never request it again. A successful
// attempt adopts the repaired document in the same step (D-22). Without `autoRepair` residue is only reported, once per
// held state, until an explicit save asks for the repair.
//
// Lane rule: a step never awaits another lane entry point (`read`, `save`, `unlock`); it calls step bodies directly or
// enqueues without awaiting, otherwise the lane deadlocks. After every await inside a step, a closed lane returns
// without effect.

import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, utf8ToBytes } from "@noble/hashes/utils.js";
import { defer, distinctUntilChanged, map, type Observable, of, Subject, type Subscription } from "rxjs";
import type { Debugger, EventStore } from "applesauce-core";
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { RelayAuthHandler, RelayPool } from "applesauce-relay";
import type { ISigner } from "applesauce-signers";
import { COMMUNITY_LIST_FRAGMENT_KIND } from "../helpers/community-list-wire.ts";
import { COMMUNITY_LIST_KIND, type ParsedCommunityList } from "../helpers/community-list.ts";
import type { CommunityListCommunity, CommunityTombstone } from "../types.ts";
import { changedCommunityIds, describeCommunityListSize } from "./community-list-document.ts";
import {
  authenticCommunityListFragment,
  COMMUNITY_LIST_READ_RETRY,
  COMMUNITY_LIST_REPAIR_RETRY,
  ListPublicationRetiredError,
  readUserList,
  retriesListSave,
  userAuthForSync,
  watchUserList,
} from "./community-list-read.ts";
import {
  CommunityListUnknownError,
  ConcordClientNotStartedError,
  type ConcordCommunityListSync,
} from "./community-list-sync.ts";
import type { CommunityListFragmentStore } from "./community-list-store.ts";
import { type DiagnosticsSink, ReportedDutyFailure } from "./diagnostics.ts";
import { DutyCancelledError, type DutyContext, type DutyScope } from "./lifecycle.ts";

/** The client's local Community List document and publication bookkeeping, as the lane sees it. */
export interface CommunityListHost {
  /** The local memberships and the extra document fields to carry on the next save. */
  document(): { entries: CommunityListCommunity[]; tombstones: CommunityTombstone[]; extras: Record<string, unknown> };
  /** Canonical local memberships. Secret-bearing: never put it in a key, a log line or a diagnostic. */
  fingerprint(): string;
  /** The client's document revision; any change retires an in-flight save. */
  revision(): number;
  /** The fingerprint believed to be on the relay, if any. */
  published(): string | null;
  /** Record `fingerprint` as published and clear `communityListDirty$`. */
  markPublished(fingerprint: string): void;
  /** Resolves once the client's document mutation lane is idle. */
  settled(): Promise<void>;
  /** True, recording a deferral, while a selected kind-13302 edition is not reconciled yet. */
  deferred(): boolean;
  /** Merge a decrypted fragment document into the local document and mirror, then reconcile the engines. */
  adopt(remote: ParsedCommunityList): Promise<void>;
  /** Whether a Community List save is owed (D-26). */
  held(): boolean;
  /** Whether the client finished starting. */
  ready(): boolean;
  /** Register a callback that retires an in-flight save; returns its unregistration. */
  onRetire(retire: () => void): () => void;
  /** Retire every in-flight save (a newer fragment arrived). */
  retire(): void;
  /** D-24: flag the held write, setting `communityListDirty$` only on a false-to-true change. */
  flagHeld(): void;
}

/** Everything one {@link CommunityListLane} needs; the lane owns none of it except its own subscriptions. */
export interface CommunityListLaneOptions {
  /** The client lifecycle this lane belongs to; part of the read duty key. */
  lifecycle: number;
  /** The client's fragment sync, shared across lifecycles. */
  sync: ConcordCommunityListSync;
  /** The client's duty scope that owns the read retry. */
  duties: DutyScope;
  /** The client's document. */
  host: CommunityListHost;
  /** Receives background failures. */
  diagnostics: DiagnosticsSink;
  /** The publish logger. */
  log: Debugger;
  /** The user's signer. */
  signer: ISigner;
  /** Decrypt fragments as they are ingested. */
  autoUnlock: boolean;
  /** Pool for reads and the live subscription. */
  pool: RelayPool;
  /** The shared store fragments are ingested from. */
  eventStore: EventStore;
  /** The user's pubkey. */
  pubkey: string;
  /** Current transport targets. */
  relays: () => string[];
  /** Transport target changes. */
  relays$: Observable<string[]>;
  /** NIP-42 handler for the user's own relays. */
  onAuthRequired: RelayAuthHandler;
  /**
   * Repair interrupted-repack residue automatically (D-19: the client's `autoSaveCommunityList`). Without it residue is
   * only reported until an explicit save, join or leave runs the repair. Defaults to `false`.
   */
  autoRepair?: boolean;
  /** The durable fragment record restored first by `start()`, locked and never read evidence (D-04). */
  store?: CommunityListFragmentStore;
}

/** What one read step established. */
export interface CommunityListReadResult {
  /** A relay completed the read, every fragment was ingested and the read's evidence was recorded. */
  recorded: boolean;
  /** The lane closed or the read was cancelled. */
  cancelled: boolean;
  /** The read completed and ingested everything, but a newer read or a lost fragment made its token stale. */
  superseded: boolean;
  /** Why the read is not evidence, when it failed. */
  error?: unknown;
}

const CANCELLED: CommunityListReadResult = { recorded: false, cancelled: true, superseded: false };

/** A save request: `explicit` is an app save, `strict` rethrows a retriable failure for the read duty. */
interface SaveMode {
  explicit?: boolean;
  strict?: boolean;
}

/** How one write ended; a retired write is re-queued by its save step. */
type WriteOutcome = "published" | "unchanged" | "held" | "failed" | "retired" | "closed";

/**
 * One client lifecycle's serialized Community List work (CORD-02 §8, D-31): reads, ingest, unlocks and saves run one
 * step at a time, and `close()` refuses every later step and clears the read evidence it may have recorded.
 */
export class CommunityListLane {
  /** The client lifecycle this lane belongs to. */
  readonly lifecycle: number;
  private readonly options: CommunityListLaneOptions;
  private tail: Promise<unknown> = Promise.resolve();
  private isClosed = false;
  private ended!: () => void;
  /** Rejects once {@link close} ran: every routed app write races it, so none outlives this lane (01-REVIEW-GAPS-4). */
  private readonly refused = new Promise<never>((_, reject) => {
    this.ended = () => reject(new ConcordClientNotStartedError());
  });
  /** Set once `start()` finished its read: relay-set changes and lost evidence then arm the read duty. */
  private watching = false;
  /** True while a read step forgets the previous evidence itself, which is not a loss to react to. */
  private beginning = false;
  /** Fragment ids queued, ingested or published by this lane; nothing here is shared with another lane (CR-01). */
  private readonly known = new Set<string>();
  /** Fragment ids whose receive resolved in this lane, or that it published: the lane's view of the store (D-31). */
  private readonly ingested = new Set<string>();
  /** Saves enqueued and not yet started; a re-queue waits only while none is (WR-01). */
  private queuedSaves = 0;
  /** Fragment ids that failed to ingest at least once in this lifecycle. */
  private readonly failing = new Set<string>();
  /** The read episode; part of the duty key, advanced only for new input or an explicit renewal (D-04, CR-02). */
  private episode = 0;
  /** What the current episode has already seen; in memory only, as it embeds the secret-bearing fingerprint. */
  private episodeInput?: string;
  /** The repair episode; part of the repair duty key, advanced only by an explicit renewal of a spent repair. */
  private repairEpisode = 0;
  /** The held state residue was last reported for (public ids only), so one state is reported once. */
  private residueReported?: string;
  private readonly cancel = new Subject<void>();
  private readonly subscriptions: Subscription[] = [];

  /** Builds an open lane; nothing runs until {@link start} or a step is enqueued. */
  constructor(options: CommunityListLaneOptions) {
    this.options = options;
    this.lifecycle = options.lifecycle;
    this.refused.catch(() => {}); // a lane with no routed write still closes quietly
  }

  /** True once {@link close} ran. */
  get closed(): boolean {
    return this.isClosed;
  }

  /**
   * Restore the stored fragment record first (CORD-02 §8, D-04): its verified winners stay locked and are never read
   * evidence. Then ingest the store's fragments as they arrive, watch the relays, run the kind-13302 import read, then
   * this lifecycle's read step; afterwards a relay-set change or any loss of read evidence arms the read duty.
   */
  async start(): Promise<CommunityListReadResult> {
    const { eventStore, diagnostics, sync, pool, pubkey, relays$, onAuthRequired } = this.options;
    await this.restoreStored();
    if (this.isClosed) return CANCELLED;
    this.subscriptions.push(
      eventStore.timeline(this.filter, { batchWindow: false }).subscribe((events) => this.hydrate(events)),
    );
    this.subscriptions.push(
      watchUserList({
        relays$,
        pool,
        eventStore,
        pubkey,
        kind: COMMUNITY_LIST_FRAGMENT_KIND,
        onAuthRequired,
        // D-15: a relay-set change after startup is a new duty key, so an unknown list is read again.
        onRelays: () => this.watching && this.requestRead(),
      }).subscribe({ error: (error) => diagnostics.report({ stage: "fragment-subscription", error }) }),
    );
    await this.readKind(COMMUNITY_LIST_KIND); // import-only (D-22): never read evidence
    if (this.isClosed) return CANCELLED;
    const result = await this.read();
    if (this.isClosed) return result;
    // IN-01: a read another read superseded is not a failure.
    if (result.error && !result.cancelled && !result.superseded) {
      diagnostics.report({ stage: "community-list-read", error: result.error });
    }
    this.watching = true;
    // WR-01: every transition to "unknown" (a failed unlock, a failed ingest, a failed start read) re-arms the read.
    this.subscriptions.push(
      sync.status$.pipe(map((status) => status.knowledge), distinctUntilChanged()).subscribe((knowledge) => {
        if (knowledge === "unknown" && !this.beginning) this.requestRead(true);
      }),
    );
    this.considerRepair(false);
    return result;
  }

  /**
   * Put the stored fragment record back before any relay read (LIST-03). The sync re-verifies every event and keeps the
   * winners locked without touching the read evidence; each is then added to the event store, so unlock, ingest and the
   * view check (which iterate the store) see it. A record that cannot be read is dropped with one diagnostic, and
   * `start()` carries on (D-03).
   */
  private async restoreStored(): Promise<void> {
    const { store, sync, eventStore, diagnostics, pubkey } = this.options;
    if (!store) return;
    let loaded: Awaited<ReturnType<CommunityListFragmentStore["load"]>>;
    try {
      loaded = await store.load(pubkey);
    } catch (error) {
      diagnostics.report({ stage: "fragment-restore", error });
      return;
    }
    if (this.isClosed) return;
    if (loaded.dropped > 0) {
      const error = new Error(`${loaded.dropped} stored Community List record entries were malformed or over the cap`);
      diagnostics.report({ stage: "fragment-restore", error });
    }
    const { restored } = await sync.restore(loaded.events);
    if (this.isClosed) return;
    for (const event of restored) eventStore.add(event);
  }

  /** Enqueue one read step. */
  read(): Promise<CommunityListReadResult> {
    return this.enqueue(() => this.readStep()).then((result) => result ?? CANCELLED);
  }

  /** Enqueue one save step; resolves when it published, held, retired or failed for good. */
  save(mode: SaveMode = {}): Promise<void> {
    if (!this.isClosed) this.queuedSaves++;
    return this.enqueue(async () => {
      this.queuedSaves--;
      await this.saveStep(mode);
      this.considerRepair(mode.explicit === true);
    }).then(() => undefined);
  }

  /**
   * D-35: run an app-requested `write()` or `repack()` as one lane step under the lane view rule. The step ingests every
   * stored fragment to the same fixpoint as a save, then calls `run` with an `assertView` that refuses the next
   * fragment: with {@link ConcordClientNotStartedError} once the lane closed, otherwise with
   * {@link ListPublicationRetiredError} while its view is stale. A retired run is run again, and any other error rejects
   * unchanged. The call rejects with {@link ConcordClientNotStartedError} as soon as the lane closes (D-30), even while
   * it waits behind a step or the sync's serial tail: the call never runs outside its lane, where a later lifecycle's
   * read evidence would let it publish past that lifecycle's view rule (01-REVIEW-GAPS-3 CR-01, 01-REVIEW-GAPS-4 CR-01).
   */
  runSyncWrite<T>(run: (assertView: () => void) => Promise<T>): Promise<T> {
    let ran = false; // the step's result may be undefined, so "never ran" is a flag
    const assertView = () => {
      if (this.isClosed) throw new ConcordClientNotStartedError(); // never publish once this lane closed (D-30)
      if (!this.viewCurrent()) throw new ListPublicationRetiredError();
    };
    const step = this.enqueue(async (): Promise<T> => {
      ran = true;
      // Bounded: every repeat needs a fragment that reached the store after the previous attempt began, a finite input.
      for (;;) {
        // An app write never reads the client's document, so unlike saveStep it needs no host.settled().
        for (;;) {
          const ingested = await this.ingestStored();
          if (this.isClosed) throw new ConcordClientNotStartedError();
          if (!ingested || this.viewCurrent()) break;
        }
        try {
          return await run(assertView);
        } catch (error) {
          if (!(error instanceof ListPublicationRetiredError)) throw error;
          if (this.isClosed) throw new ConcordClientNotStartedError(); // never leak the internal retirement
        }
      }
    });
    const settled = step.then((result) => {
      if (!ran) throw new ConcordClientNotStartedError();
      return result as T;
    });
    // A step still waiting when the lane closes is refused at its next fragment by assertView, so rejecting now is safe.
    return Promise.race([settled, this.refused]);
  }

  /**
   * WR-03: the client view's `receive()` as one lane step, so it never runs beside a read, ingest, unlock or write. The
   * fragment is authenticated like a relay arrival before anything is retained, added to the event store (so the view
   * check sees it and a later unlock finds it) and received; with `unlock` the decrypted document is adopted as an
   * unlock adopts it. Rejects with {@link ConcordClientNotStartedError} once the lane closes (D-30).
   */
  receive(event: NostrEvent, unlock: boolean): Promise<boolean> {
    let ran = false;
    const step = this.enqueue(async (): Promise<boolean> => {
      ran = true;
      const { sync, eventStore, pubkey, host } = this.options;
      const authentic = authenticCommunityListFragment(event, pubkey);
      if (!authentic) return false;
      const accepted = await receiveSupplied(sync, eventStore, authentic.wire, unlock);
      if (this.isClosed) return accepted;
      this.ingested.add(authentic.wire.id);
      if (unlock) await host.adopt(sync.fragments.document);
      return accepted;
    });
    const settled = step.then((result) => {
      if (!ran) throw new ConcordClientNotStartedError();
      return result === true;
    });
    return Promise.race([settled, this.refused]);
  }

  /** Enqueue one unlock step: decrypt every stored fragment and adopt their document; rejects with a receive error. */
  unlock(): Promise<void> {
    return this.enqueue(() => this.unlockBody()).then(() => undefined);
  }

  /**
   * Arm the bounded read retry (D-04, D-15) while the lane is open and the list is unknown. An exhausted episode stays
   * quiet until new input (a fragment failing for the first time in this lifecycle, a changed local document), a
   * `renew` (lost evidence, an explicit app save) or a relay-set change, which is a new key.
   */
  requestRead(renew: boolean = false): void {
    if (this.isClosed || this.options.sync.status.knowledge !== "unknown") return;
    const input = this.input();
    const result = this.requestEpisode();
    if (result === "armed" || result === "coalesced") this.episodeInput = input;
    if (result !== "quiet" || (!renew && input === this.episodeInput)) return;
    this.episode++;
    this.episodeInput = input;
    this.requestEpisode();
  }

  /**
   * D-04: new input renews an exhausted read while the list is unknown: an app call (a membership change, an unlock,
   * an explicit save, a repeated start) or another device's fragment arriving. Ignored until start()'s own read is done.
   */
  renew(): void {
    if (this.watching) this.requestRead(true);
  }

  /** Our own publication: hydration skips it, so it never retires the save that published it. */
  markOwn(eventId: string): void {
    this.known.add(eventId);
    this.ingested.add(eventId); // the sync receives it inside the write; a failure there lands in `unreceived` (D-29)
  }

  /** Idempotent: refuse every later step and every routed app write, drop the subscriptions, cancel the read and clear
   *  the read evidence. */
  close(): void {
    if (this.isClosed) return;
    this.isClosed = true;
    this.ended();
    // Every task this lane queued refuses at its next assertCurrent, so the next lifecycle never waits behind a signer
    // prompt nobody answers (LIST-05).
    this.options.sync.abandon();
    this.options.store?.release(); // and none waits on a storage write past this lane (IN-02)
    for (const subscription of this.subscriptions.splice(0)) subscription.unsubscribe();
    this.cancel.next();
    this.cancel.complete();
    this.options.sync.clearReadEvidence(); // the next lifecycle completes its own read (D-29)
  }

  /** D-05: the List is complete, every held copy is decrypted and an interrupted repack left residue. */
  private repairDue(): boolean {
    const { sync } = this.options;
    return !this.isClosed && sync.status.knowledge === "complete" && !sync.locked && sync.fragments.residue;
  }

  /** Public ids only (`d` index and event id of every held fragment): never content, so safe in a duty key. */
  private heldSignature(): string {
    const held = this.options.eventStore.getTimeline(this.filter).map((event) =>
      `${event.tags.find((tag) => tag[0] === "d")?.[1] ?? ""}:${event.id}`
    );
    return bytesToHex(sha256(utf8ToBytes(held.sort().join(","))));
  }

  /**
   * D-19: request the repair when it is due and the app consented (`autoRepair`, or an explicit save, join or leave);
   * otherwise report the residue once per held state. Never called for the repair's own publications.
   */
  private considerRepair(explicit: boolean): void {
    if (!this.repairDue()) return;
    if (!this.options.autoRepair && !explicit) {
      const signature = this.heldSignature();
      if (signature === this.residueReported) return;
      this.residueReported = signature;
      this.options.diagnostics.report({
        stage: "community-list-residue",
        error: new Error(
          "an interrupted Community List repack left duplicate or dormant fragments; the next save repairs them",
        ),
      });
      return;
    }
    this.requestRepair(explicit);
  }

  /** Arm the bounded repair; an explicit call renews a spent repair, an automatic trigger never does. */
  private requestRepair(explicit: boolean): void {
    const request = () =>
      this.options.duties.request({
        // Public parts only: the lifecycle, an episode and a hash of held d indexes and event ids.
        key: `community-list-repair:${this.lifecycle}:${this.repairEpisode}:${this.heldSignature()}`,
        slot: "community-list-repair",
        stage: "community-list-repair",
        eligible: () => !this.isClosed,
        ...COMMUNITY_LIST_REPAIR_RETRY,
        run: (duty) => this.runRepair(duty),
      });
    if (request() !== "quiet" || !explicit) return;
    this.repairEpisode++;
    request();
  }

  /**
   * One repair attempt (D-07): an empty-local repack reorganizes only what is held, as a lane write step. It is the only
   * retry owner; a transient failure is retried within the budget, a declined signer or permanent refusal settles.
   */
  private async runRepair(duty: DutyContext): Promise<void> {
    if (!this.repairDue()) return; // state is read at fire time
    const { sync, diagnostics, host } = this.options;
    try {
      await this.runSyncWrite(async (assertView) => {
        // A retried run starts from a fresh view: an arrival that is locked again or already repaired ends the attempt.
        if (!this.repairDue()) return;
        await sync.repack({ entries: [], tombstones: [] }, () => {
          duty.assertAlive();
          assertView();
        });
        if (this.isClosed) return;
        // D-22: adopt the repaired document in this step, so memberships() shows what the repair brought back into
        // range. Every held copy was decrypted (repairDue), and the merge only adds; only a tombstone subtracts.
        await host.adopt(sync.fragments.document).catch((error) => {
          if (!this.isClosed) diagnostics.report({ stage: "fragment-reconcile", error });
        });
        if (this.isClosed) return;
        // WR-01: the adoption marks the document dirty against the pre-repair fingerprint, but the relays now hold
        // exactly what was adopted. When no membership differs from them, record it as published, as a save would.
        const { entries, tombstones } = host.document();
        if (changedCommunityIds(entries, tombstones, sync.fragments.document).length === 0) {
          host.markPublished(host.fingerprint());
        }
      });
    } catch (error) {
      if (
        this.isClosed || !duty.alive() || error instanceof ConcordClientNotStartedError ||
        error instanceof DutyCancelledError || error instanceof CommunityListUnknownError
      ) {
        // Withdrawn evidence is forgotten, not settled: the next completed read can request the repair again.
        throw new DutyCancelledError("Community List repair cancelled");
      }
      diagnostics.report({ stage: "community-list-repair", error });
      if (retriesListSave(error)) throw new ReportedDutyFailure(error);
    }
  }

  private requestEpisode() {
    const { duties, relays } = this.options;
    return duties.request({
      // Public parts only: never the document or its fingerprint.
      key: `community-list-read:${this.lifecycle}:${this.episode}:${relays().join(",")}`,
      slot: "community-list-read",
      stage: "community-list-read",
      eligible: () => !this.isClosed,
      ...COMMUNITY_LIST_READ_RETRY,
      run: (duty) => this.runDuty(duty),
    });
  }

  /** What would renew a quiet episode: the fragments that failed to ingest and the local memberships. */
  private input(): string {
    return `${[...this.failing].sort().join(",")}|${this.options.host.fingerprint()}`;
  }

  private get filter() {
    return [{ kinds: [COMMUNITY_LIST_FRAGMENT_KIND], authors: [this.options.pubkey] }];
  }

  private enqueue<T>(step: () => Promise<T>): Promise<T | undefined> {
    if (this.isClosed) return Promise.resolve(undefined);
    const run = this.tail.then(() => (this.isClosed ? undefined : step()));
    this.tail = run.catch(() => {});
    return run;
  }

  private readKind(kind: number) {
    const { pool, eventStore, relays, pubkey, onAuthRequired } = this.options;
    return readUserList({
      pool,
      eventStore,
      relays: relays(),
      pubkey,
      kind,
      onAuthRequired: userAuthForSync(onAuthRequired),
      cancelled$: defer(() => (this.isClosed ? of(undefined) : this.cancel)),
    });
  }

  /** Queue an ingest step for every stored fragment this lane has not seen; a new arrival retires the in-flight save. */
  private hydrate(events: NostrEvent[]): void {
    let queued = false;
    for (const event of events) {
      if (this.known.has(event.id)) continue;
      this.known.add(event.id);
      queued = true;
      void this.enqueue(async () => {
        if (!this.ingested.has(event.id)) { // a save step may have ingested it first
          await this.options.sync.receive(event, false);
          this.ingested.add(event.id);
        }
        if (!this.isClosed && this.options.autoUnlock) await this.unlockBody();
      }).then(() => (this.renew(), this.considerRepair(false)), (error) => this.ingestFailed(event, error));
    }
    if (queued) this.options.host.retire();
  }

  /** A failed ingest is retried by a later read; it never touches `communityListDirty$` (CR-02). */
  private ingestFailed(event: NostrEvent, error: unknown): void {
    if (this.isClosed) return;
    this.known.delete(event.id);
    this.failing.add(event.id);
    this.options.diagnostics.report({ stage: "fragment-reconcile", error });
    this.requestRead();
  }

  /** Read kind 33302, then ingest everything served, retained as failed, or stored, before recording (D-29, CR-01). */
  private async readStep(): Promise<CommunityListReadResult> {
    const { sync, eventStore, autoUnlock } = this.options;
    this.beginning = true;
    const token = sync.beginRead();
    this.beginning = false;
    const outcome = await this.readKind(COMMUNITY_LIST_FRAGMENT_KIND);
    if (this.isClosed || outcome.cancelled) return CANCELLED;
    const events = new Map<string, NostrEvent>();
    for (const event of [...outcome.events, ...sync.unreceived, ...eventStore.getTimeline(this.filter)]) {
      events.set(event.id, event);
    }
    let ingested = true;
    for (const event of events.values()) {
      await sync.receive(event, false).then(() => void this.ingested.add(event.id), () => {
        ingested = false;
        this.failing.add(event.id);
      });
      if (this.isClosed) return CANCELLED;
    }
    let result: CommunityListReadResult;
    if (!outcome.complete) {
      const error = outcome.error ?? new Error("no relay completed the Community List read");
      result = { recorded: false, cancelled: false, superseded: false, error };
    } else if (!ingested || sync.unreceived.length) {
      const error = new Error("Community List fragments could not be ingested");
      result = { recorded: false, cancelled: false, superseded: false, error };
    } else if (!sync.markReadComplete(token)) {
      result = { recorded: false, cancelled: false, superseded: true };
    } else {
      result = { recorded: true, cancelled: false, superseded: false };
    }
    if (autoUnlock && ingested) {
      await this.unlockBody().catch((error) => {
        if (!this.isClosed) this.options.diagnostics.report({ stage: "fragment-reconcile", error });
      });
    }
    return this.isClosed ? CANCELLED : result;
  }

  /** Decrypt every stored fragment, adopt their document and release a held save without awaiting it. */
  private async unlockBody(): Promise<void> {
    const { sync, host, eventStore } = this.options;
    for (const event of eventStore.getTimeline(this.filter)) {
      await sync.receive(event, true);
      this.ingested.add(event.id);
      if (this.isClosed) return;
    }
    await host.adopt(sync.fragments.document);
    if (this.isClosed) return;
    // D-15/D-26: release a save held over locked fragments unless start() or the read duty will (WR-03: a declined or
    // refused release is never prompted twice in one attempt). Only the read slot counts: a pending repair does not.
    if (host.ready() && host.held() && !this.options.duties.slotPending("community-list-read")) this.queueSave();
    this.considerRepair(false);
  }

  /**
   * Lane view rule (D-31): true when every stored fragment of this user was ingested by this lane or is retained by
   * the sync as unreceived, which the completed-read gate already refuses every write over (D-29).
   */
  private viewCurrent(): boolean {
    const unreceived = new Set(this.options.sync.unreceived.map((event) => event.id));
    return this.options.eventStore.getTimeline(this.filter).every((event) =>
      this.ingested.has(event.id) || unreceived.has(event.id)
    );
  }

  /**
   * Receive, without decrypting, every stored fragment this lane has not ingested and the sync does not retain as
   * unreceived. False after the first failure, which is reported and re-read like a failed hydration ingest.
   */
  private async ingestStored(): Promise<boolean> {
    const { sync, eventStore } = this.options;
    const unreceived = new Set(sync.unreceived.map((event) => event.id));
    for (const event of eventStore.getTimeline(this.filter)) {
      if (this.ingested.has(event.id) || unreceived.has(event.id)) continue;
      try {
        await sync.receive(event, false);
      } catch (error) {
        this.ingestFailed(event, error);
        return false;
      }
      if (this.isClosed) return false;
      this.ingested.add(event.id);
    }
    return true;
  }

  /**
   * Re-queue a retired save as a plain save (never strict: the duty attempt that started a strict save has finished).
   * Bounded: at most one save waits, and every re-queue needs a running save to be retired, which needs an arrival or a
   * document change, both finite inputs. A save never retires itself: its own fragments are marked own, and hydration
   * skips them.
   */
  private queueSave(): void {
    if (this.isClosed || this.queuedSaves > 0) return;
    void this.save();
  }

  /**
   * Publish the local document unless a newer document, a newer arrival or `close()` retires it first. Lane view rule
   * (D-31): it plans only once every stored fragment is ingested, and a retired save is re-queued, never dropped.
   */
  private async saveStep(mode: SaveMode): Promise<void> {
    const { host, signer } = this.options;
    if (mode.explicit) this.renew(); // even when there is nothing to publish
    if (!signer.nip44) return;
    // Each extra pass needs a new arrival, so this ends. A failed ingest withdrew the read evidence, so the write holds.
    for (;;) {
      const ingested = await this.ingestStored();
      await host.settled();
      if (this.isClosed) return;
      if (!ingested || this.viewCurrent()) break;
    }
    if (host.deferred()) return;
    const revision = host.revision();
    let retire!: () => void;
    const retired = new Promise<"retired">((resolve) => (retire = () => resolve("retired")));
    const unregister = host.onRetire(retire);
    let outcome: WriteOutcome;
    try {
      // A retired save releases the lane at once; its obsolete signer prompt may finish harmlessly later.
      const writing = this.write(revision, mode);
      writing.catch(() => {});
      outcome = await Promise.race([writing, retired]);
    } finally {
      unregister();
    }
    if (outcome === "retired") this.queueSave(); // behind the retirement's ingest steps (WR-01)
  }

  private async write(revision: number, mode: SaveMode): Promise<WriteOutcome> {
    const { sync, host, log, diagnostics, relays } = this.options;
    const wasPending = sync.status.pending;
    const { entries, tombstones, extras } = host.document();
    const fingerprint = host.fingerprint();
    const current = (): boolean => !this.isClosed && revision === host.revision() && fingerprint === host.fingerprint();
    try {
      if (!current()) return "retired";
      // Fragments are replaceable: never re-sign content the relay already holds (NIP-44 nonces defeat ciphertext
      // comparison, so compare canonical plaintext).
      if (fingerprint === host.published() && (sync.fragments.get(0) || (!entries.length && !tombstones.length))) {
        sync.clearPending();
        host.markPublished(fingerprint);
        return "unchanged";
      }
      log("community list size trace: %s", describeCommunityListSize(entries, tombstones));
      log(
        "publishing community list entries=%d tombstones=%d targets=%d",
        entries.length,
        tombstones.length,
        relays().length,
      );
      // Extras first, merged arrays after (WIRE-09/D-23): a stale `entries` key in the extras can never win.
      const ids = changedCommunityIds(entries, tombstones, sync.fragments.document);
      // D-31: a fragment that reached the store after the plan refuses the next fragment, as a retirement does.
      await sync.write({ ...extras, entries, tombstones }, ids, () => {
        if (!current() || !this.viewCurrent()) throw new ListPublicationRetiredError();
      });
      if (!current()) return "retired";
      host.markPublished(fingerprint);
      return "published";
    } catch (error) {
      if (this.isClosed) return "closed";
      // Only a read resolves "unknown" (a held write, or our own fragment failed to ingest after publishing, IN-02).
      if (sync.status.knowledge === "unknown") this.requestRead(mode.explicit);
      // Superseded by a newer document or arrival, so not a failure: its save step re-queues it. That includes a late
      // failure of the retired attempt, such as "Community List changed during signing".
      if (!current() || error instanceof ListPublicationRetiredError) return "retired";
      if (error instanceof CommunityListUnknownError) {
        host.flagHeld();
        log("community list write held until a relay completes the read");
        if (!wasPending) diagnostics.report({ stage: "community-list-write-blocked", error }); // once per episode
        return "held";
      }
      diagnostics.report({ stage: "community-list-save", error });
      // The read duty retries only a transient failure; a deterministic or declined one settles with this report.
      if (mode.strict && !this.isClosed && revision === host.revision() && retriesListSave(error)) {
        throw new ReportedDutyFailure(error);
      }
      return "failed";
    }
  }

  /** One read-duty attempt: read when unknown, then release a held save (D-06: state is read at fire time). */
  private async runDuty(duty: DutyContext): Promise<void> {
    try {
      await this.attempt(duty);
    } finally {
      // Fragments that failed during this episode's own reads belong to it: only later changes renew it.
      this.episodeInput = this.input();
    }
  }

  private async attempt(duty: DutyContext): Promise<void> {
    const { sync, host } = this.options;
    if (sync.status.knowledge === "unknown") {
      const result = await this.read();
      duty.assertAlive();
      if (result.cancelled) throw new DutyCancelledError("Community List read cancelled");
      if (!result.recorded) throw result.error ?? new Error("a newer read superseded this Community List read");
    }
    if (host.held()) {
      duty.assertAlive();
      await this.save({ strict: true });
    }
    duty.assertAlive();
    if (sync.status.knowledge === "unknown") throw new Error("Community List read evidence was withdrawn");
    this.considerRepair(false);
  }
}

/**
 * Members of the sync the lane alone may call: the serial-tail release, stored-fragment restore and the read-evidence
 * methods. Through the client's view they would bypass the lane (WR-06): an `abandon()` would let a routed write run
 * beside one in flight, and a `restore()` would hold events the lane never adds to the event store, so they could
 * never be unlocked. The view's type already leaves them out; at run time they throw. `receive()` is routed instead
 * ({@link CommunityListLane.receive}, WR-03).
 */
const LANE_OWNED: ReadonlySet<PropertyKey> = new Set([
  "abandon",
  "restore",
  "beginRead",
  "markReadComplete",
  "clearReadEvidence",
]);

/**
 * D-35: the client's public view of `sync`. `write()` and `repack()` run as steps of the current lane
 * ({@link CommunityListLane.runSyncWrite}), after the caller's own `assertCurrent`, and reject with
 * {@link ConcordClientNotStartedError} when no lane is open (before `start()` finishes, after `stop()` or `dispose()`):
 * a direct call would wait on the sync's serial tail and could pass the next lifecycle's read gate. `receive()` runs as
 * a lane step too ({@link CommunityListLane.receive}, WR-03), so the fragment lands in the event store and can be
 * unlocked; with no open lane it authenticates against `outside.pubkey()`, adds the fragment to `outside.eventStore()`
 * and receives it directly, where the next lane finds it (without `outside` it rejects). `abandon()`, `restore()` and
 * the read-evidence methods are standalone-only and throw on the view (WR-06). Every other member is read from `sync`
 * itself (getters evaluated on it, methods bound to it), and an assignment to a member defines it on `sync`, so the
 * view holds no state of its own.
 */
export function laneRoutedSync(
  sync: ConcordCommunityListSync,
  lane: () => CommunityListLane | undefined,
  outside?: { eventStore: () => EventStore; pubkey: () => Promise<string> },
): ConcordCommunityListSync {
  const route = (write: (assertView: () => void) => Promise<void>) =>
    lane()?.runSyncWrite(write) ?? Promise.reject(new ConcordClientNotStartedError());
  const routed = {
    write: (...[local, ids, assertCurrent]: Parameters<ConcordCommunityListSync["write"]>): Promise<void> =>
      route((assertView) => sync.write(local, ids, () => (assertCurrent?.(), assertView()))),
    repack: (...[local, assertCurrent]: Parameters<ConcordCommunityListSync["repack"]>): Promise<void> =>
      route((assertView) => sync.repack(local, () => (assertCurrent?.(), assertView()))),
    receive: async (event: NostrEvent, unlock: boolean = true): Promise<boolean> => {
      const open = lane();
      if (open) return await open.receive(event, unlock);
      if (!outside) throw new ConcordClientNotStartedError();
      const authentic = authenticCommunityListFragment(event, await outside.pubkey());
      return authentic ? await receiveSupplied(sync, outside.eventStore(), authentic.wire, unlock) : false;
    },
  };
  return new Proxy(sync, {
    get(target, property) {
      if (property === "write" || property === "repack" || property === "receive") return routed[property];
      if (LANE_OWNED.has(property)) {
        return () => {
          throw new Error(`communityListSync.${String(property)}() is standalone-only: ConcordClient's lane owns it`);
        };
      }
      const value = Reflect.get(target, property, target);
      return typeof value === "function" ? value.bind(target) : value;
    },
  });
}

/** Retain an authenticated app-supplied fragment where unlock finds it (the event store), then receive it (WR-03). */
async function receiveSupplied(
  sync: ConcordCommunityListSync,
  eventStore: EventStore,
  wire: NostrEvent,
  unlock: boolean,
): Promise<boolean> {
  eventStore.add(wire);
  return await sync.receive(wire, unlock);
}

/** Decrypt every stored fragment of `pubkey` without a lane (before `start()` or after `stop()`). */
export async function unlockStoredFragments(
  sync: ConcordCommunityListSync,
  eventStore: EventStore,
  pubkey: string,
): Promise<ParsedCommunityList> {
  for (const event of eventStore.getTimeline([{ kinds: [COMMUNITY_LIST_FRAGMENT_KIND], authors: [pubkey] }])) {
    await sync.receive(event);
  }
  return sync.fragments.document;
}
