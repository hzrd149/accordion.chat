// The serialized Community List lane in isolation (D-31, CORD-02 §8): a real fragment sync over a gated signer, a fake
// relay pool, a hand-written host and a duty scope on a manual clock.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { spy } from "@std/testing/mock";
import { EMPTY, type Observable, of, Subject, throwError } from "rxjs";
import { EventStore } from "applesauce-core";
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { Filter } from "applesauce-core/helpers/filter";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";

import { logger } from "../../logger.ts";
import { canonicalJson } from "../../helpers/community-list.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  decodeCommunityListFragment,
  encodeCommunityListFragment,
} from "../../helpers/community-list-wire.ts";
import type { CommunityListCommunity, CommunityTombstone } from "../../types.ts";
import { createUserAuthHandler } from "../auth.ts";
import { type CommunityListHost, CommunityListLane, laneRoutedSync } from "../community-list-lane.ts";
import {
  COMMUNITY_LIST_READ_RETRY,
  COMMUNITY_LIST_REPAIR_RETRY,
  ListRelayPublishError,
} from "../community-list-read.ts";
import { ConcordCommunityListSync } from "../community-list-sync.ts";
import { type ConcordDiagnostic, DiagnosticsSink } from "../diagnostics.ts";
import { DutyScope } from "../lifecycle.ts";
import { fakeRelayPool, Gate, gatedSigner, ManualClock, type SignerGates } from "./test-utils.ts";

const settle = () => new Promise((r) => setTimeout(r, 50));

/** Poll `ready` in real time (at most 2 s). */
async function until(ready: () => boolean): Promise<void> {
  for (let i = 0; i < 100 && !ready(); i++) await new Promise((r) => setTimeout(r, 20));
  expect(ready()).toBe(true);
}

/** A membership entry with a fixed id. */
function entry(index: number): CommunityListCommunity {
  const id = index.toString(16).padStart(64, "0");
  const material = {
    community_id: id,
    owner: "11".repeat(32),
    owner_salt: "22".repeat(32),
    community_root: "33".repeat(32),
    root_epoch: 0,
    channels: [],
    relays: [],
    name: "room",
  };
  return { community_id: id, current: material, seed: material, added_at: 1 };
}

/** Kind-33302 reads only: other kinds and the loader's next page are empty. */
const fragmentReads = (serve: () => Observable<NostrEvent>) => (filters: Filter[]) => {
  if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
  if (filters.some((f) => f.until !== undefined)) return EMPTY;
  return serve();
};

/** A lane over real sync state; every resource is released by `teardown()`. */
async function fixture(options: { autoUnlock?: boolean; autoRepair?: boolean; gates?: SignerGates } = {}) {
  const inner = new PrivateKeySigner(generateSecretKey());
  const pubkey = await inner.getPublicKey();
  const signer = gatedSigner(inner, options.gates ?? {});
  const net = fakeRelayPool({ events: [] });
  const eventStore = new EventStore();
  const published: NostrEvent[] = [];
  const attempts = { publish: 0, refuse: false };
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    attempts.publish++;
    if (attempts.refuse) throw new ListRelayPublishError("No relay accepted the Community List fragment", true);
    published.push(event);
  }, { requireCompletedRead: true });
  const diagnostics: ConcordDiagnostic[] = [];
  const log = logger.extend("lane-test");
  const sink = new DiagnosticsSink(log, (diagnostic) => diagnostics.push(diagnostic));
  const clock = new ManualClock();
  const duties = new DutyScope({ clock, report: (report) => sink.reportDuty(report) });
  const state = {
    entries: [] as CommunityListCommunity[],
    tombstones: [] as CommunityTombstone[],
    published: canonicalJson({ entries: [], tombstones: [] }) as string | null,
    revision: 0,
    held: false,
  };
  const calls: string[] = [];
  const retirers = new Set<() => void>();
  const host: CommunityListHost = {
    document: () => ({ entries: state.entries, tombstones: state.tombstones, extras: {} }),
    fingerprint: () => canonicalJson({ entries: state.entries, tombstones: state.tombstones }),
    revision: () => state.revision,
    published: () => state.published,
    markPublished: (fingerprint) => {
      calls.push("markPublished");
      state.published = fingerprint;
    },
    settled: () => Promise.resolve(),
    deferred: () => false,
    adopt: async () => void calls.push("adopt"),
    held: () => state.held,
    ready: () => true,
    onRetire: (retire) => {
      retirers.add(retire);
      return () => void retirers.delete(retire);
    },
    retire: () => {
      calls.push("retire");
      state.revision++;
      for (const retire of [...retirers]) retire();
    },
    flagHeld: () => void calls.push("flagHeld"),
  };
  const lanes: CommunityListLane[] = [];
  const lane = (): CommunityListLane => {
    const built = new CommunityListLane({
      lifecycle: 1,
      sync,
      duties,
      host,
      diagnostics: sink,
      log,
      signer,
      autoUnlock: options.autoUnlock ?? false,
      autoRepair: options.autoRepair ?? false,
      pool: net.pool,
      eventStore,
      pubkey,
      relays: () => ["wss://fake"],
      relays$: of(["wss://fake"]),
      onAuthRequired: createUserAuthHandler(signer, () => pubkey),
    });
    lanes.push(built);
    return built;
  };
  const fragment = async (index: number, entries: CommunityListCommunity[], frags = 1, created_at = 1_000) =>
    inner.signEvent({
      kind: COMMUNITY_LIST_FRAGMENT_KIND,
      created_at,
      tags: [["d", String(index)]],
      content: await inner.nip44!.encrypt(
        pubkey,
        encodeCommunityListFragment({ frags, entries, tombstones: [] } as never),
      ),
    });
  const teardown = async () => {
    for (const built of lanes) built.close();
    duties.dispose();
    await duties.idle();
    await settle();
    eventStore.dispose();
  };
  return {
    inner,
    net,
    eventStore,
    published,
    attempts,
    sync,
    diagnostics,
    clock,
    duties,
    state,
    calls,
    host,
    lane,
    fragment,
    teardown,
  };
}

/** The community ids a published fragment holds. */
async function documentOf(f: Awaited<ReturnType<typeof fixture>>, event: NostrEvent): Promise<string[]> {
  return decodeCommunityListFragment(await f.inner.nip44!.decrypt(event.pubkey, event.content)).entries.map((e) =>
    e.community_id
  );
}

describe("CommunityListLane (D-31)", () => {
  it("a closed lane runs no step and resolves later steps without effect", async () => {
    const signEvent = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const f = await fixture({ gates: { signEvent } });
    try {
      const lane = f.lane();
      expect((await lane.read()).recorded).toBe(true); // a completed empty read
      f.state.entries = [entry(1)];
      const first = lane.save();
      const parked = await signEvent.next();
      const receive = spy(f.sync, "receive");
      const write = spy(f.sync, "write");
      const beginRead = spy(f.sync, "beginRead");
      const queued = [lane.save(), lane.unlock(), lane.read()];
      lane.close();
      parked.release();
      await first;
      expect(await Promise.all(queued)).toEqual([undefined, undefined, {
        recorded: false,
        cancelled: true,
        superseded: false,
      }]);
      await settle();
      const after = [lane.save(), lane.unlock(), lane.read()];
      expect(await Promise.all(after)).toEqual([undefined, undefined, {
        recorded: false,
        cancelled: true,
        superseded: false,
      }]);
      expect(receive.calls).toHaveLength(0);
      expect(write.calls).toHaveLength(0);
      expect(beginRead.calls).toHaveLength(0);
      expect(f.calls).toEqual([]);
      expect(f.published).toHaveLength(0);
      expect(f.sync.status.knowledge).toBe("unknown");
      receive.restore();
      write.restore();
      beginRead.restore();
    } finally {
      await f.teardown();
    }
  });

  it("lane steps run one at a time in order, and a failing step does not block the next", async () => {
    const decrypt = new Gate<[pubkey: string, text: string], string>();
    const f = await fixture({ gates: { decrypt } });
    try {
      const stored = await f.fragment(0, [entry(1)]);
      f.eventStore.add(stored);
      let reads = 0;
      f.net.setRequest(fragmentReads(() => {
        reads++;
        return of(stored);
      }));
      const lane = f.lane();
      const unlocking = lane.unlock();
      const parked = await decrypt.next();
      const reading = lane.read();
      await settle();
      expect(reads).toBe(0); // the read waits for the parked unlock
      parked.fail(new Error("decrypt declined"));
      await expect(unlocking).rejects.toThrow("decrypt declined");
      expect((await reading).recorded).toBe(true);
      expect(reads).toBe(1);
    } finally {
      await f.teardown();
    }
  });

  it("a read step ingests every stored fragment before it records evidence", async () => {
    let stalling = true;
    const getPublicKey = new Gate<[], string>();
    const f = await fixture({ gates: { getPublicKey, getPublicKeyWhen: () => stalling } });
    try {
      // Stored from elsewhere (another device through a shared store); the relay read never returns it.
      f.eventStore.add(await f.fragment(0, [entry(1)], 2));
      const lane = f.lane();
      const reading = lane.read();
      (await getPublicKey.next()).fail(new Error("bunker reconnecting"));
      const failed = await reading;
      expect(failed.recorded).toBe(false);
      expect(failed.error).toBeInstanceOf(Error);
      expect(f.sync.status.knowledge).toBe("unknown");

      stalling = false;
      const recovered = await lane.read();
      expect(recovered.recorded).toBe(true);
      expect(f.sync.status.knowledge).toBe("partial"); // held and locked (autoUnlock is off)
    } finally {
      await f.teardown();
    }
  });

  it("close() clears read evidence and stops ingesting store arrivals", async () => {
    const f = await fixture();
    try {
      const lane = f.lane();
      expect((await lane.start()).recorded).toBe(true);
      expect(f.sync.status.knowledge).toBe("confirmed-empty");
      lane.close();
      expect(f.sync.status.knowledge).toBe("unknown");
      const receive = spy(f.sync, "receive");
      f.eventStore.add(await f.fragment(0, [entry(1)]));
      await settle();
      expect(receive.calls).toHaveLength(0);
      expect(f.calls).not.toContain("retire");
      receive.restore();
    } finally {
      await f.teardown();
    }
  });

  it("a read whose token went stale reports superseded without an error, and close() reports cancelled", async () => {
    const f = await fixture();
    try {
      const reads: Subject<NostrEvent>[] = [];
      f.net.setRequest(fragmentReads(() => {
        const read = new Subject<NostrEvent>();
        reads.push(read);
        return read;
      }));
      const lane = f.lane();
      const first = lane.read();
      for (let i = 0; i < 50 && reads.length < 1; i++) await settle();
      f.sync.beginRead(); // a newer read elsewhere makes this read's token stale
      reads[0].complete();
      expect(await first).toEqual({ recorded: false, cancelled: false, superseded: true });

      const second = lane.read();
      for (let i = 0; i < 50 && reads.length < 2; i++) await settle();
      lane.close();
      expect(await second).toEqual({ recorded: false, cancelled: true, superseded: false });
    } finally {
      await f.teardown();
    }
  });

  it("the read duty key carries only the lifecycle, episode and relays and runs at most maxAttempts attempts", async () => {
    const f = await fixture();
    try {
      let reads = 0;
      f.net.setRequest(fragmentReads(() => {
        reads++;
        return throwError(() => new Error("relay down"));
      }));
      f.state.entries = [entry(7)];
      const lane = f.lane();
      lane.requestRead();
      expect(f.duties.pending).toBe(1);
      for (const ms of [6_000, 6_000, 11_000, 60_000]) {
        f.clock.tick(ms);
        await f.duties.idle();
        await settle();
        await f.duties.idle();
      }
      expect(reads).toBe(COMMUNITY_LIST_READ_RETRY.maxAttempts);
      const exhausted = f.diagnostics.filter((d) => d.stage === "duty-exhausted");
      expect(exhausted).toHaveLength(1);
      expect(exhausted[0].key).toMatch(/^community-list-read:\d+:\d+:wss:\/\/fake$/);
      expect(exhausted[0].key).not.toContain(entry(7).community_id);
      expect(f.duties.pending).toBe(0);
    } finally {
      await f.teardown();
    }
  });

  it("a retired save publishes nothing stale, is re-queued once and publishes the newer document, and a held save flags the host once", async () => {
    const signEvent = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const f = await fixture({ gates: { signEvent } });
    try {
      const lane = f.lane();
      f.state.entries = [entry(1)];
      // Held: no read recorded yet, so the write is refused before any signer call.
      await lane.save();
      expect(f.calls.filter((call) => call === "flagHeld")).toHaveLength(1);
      await lane.save();
      expect(f.diagnostics.filter((d) => d.stage === "community-list-write-blocked")).toHaveLength(1);
      expect(f.sync.status).toEqual({ knowledge: "unknown", pending: true });

      // Retired: a newer document arrives while the save is parked in signing.
      expect((await lane.read()).recorded).toBe(true);
      const saving = lane.save();
      const parked = await signEvent.next();
      f.state.entries = [entry(1), entry(2)];
      f.host.retire(); // what the client does on every document mutation
      await saving; // released by the retirement while its signer prompt is still parked
      parked.release();
      await settle();
      expect(f.published).toHaveLength(0); // the retired attempt published nothing stale
      // WR-01: the retired save was re-queued; its signer prompt is the second one.
      await until(() => signEvent.calls.length === 2);
      (await signEvent.next()).release();
      await settle();
      expect(f.published).toHaveLength(1);
      expect(await documentOf(f, f.published[0])).toEqual([entry(1).community_id, entry(2).community_id]);
      expect(signEvent.calls).toHaveLength(2);
      expect(f.diagnostics.filter((d) => d.stage === "community-list-save")).toHaveLength(0);
    } finally {
      await f.teardown();
    }
  });

  it("a save queued behind a parked step ingests a fragment that arrived while it waited and holds instead of publishing a smaller count", async () => {
    let park = false; // one-shot: parks exactly the next getPublicKey call once set
    const getPublicKey = new Gate<[], string>();
    const f = await fixture({ gates: { getPublicKey, getPublicKeyWhen: () => (park ? (park = false, true) : false) } });
    try {
      f.eventStore.add(await f.fragment(0, [entry(1)], 1, 1_000));
      const lane = f.lane();
      expect((await lane.start()).recorded).toBe(true);
      await lane.unlock();
      expect(f.sync.status).toEqual({ knowledge: "complete", pending: false });

      park = true;
      const unlocking = lane.unlock(); // parks on its first receive
      const parked = await getPublicKey.next();
      f.state.entries = [entry(1), entry(2)];
      const saving = lane.save(); // queued behind the parked unlock
      f.eventStore.add(await f.fragment(1, [entry(3)], 2, 1_010)); // a newer, larger declaration
      parked.release();
      await unlocking;
      await saving;
      await settle();
      expect(f.published).toHaveLength(0); // never frags: 1 over frags: 2
      expect(f.sync.status).toEqual({ knowledge: "partial", pending: true });
    } finally {
      await f.teardown();
    }
  });

  it("arrivals during a parked write retire it and re-queue exactly one save", async () => {
    const signEvent = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const f = await fixture({ gates: { signEvent } });
    try {
      f.eventStore.add(await f.fragment(0, [entry(1)], 1, 1_000));
      const lane = f.lane();
      expect((await lane.start()).recorded).toBe(true);
      await lane.unlock();
      expect(f.sync.status).toEqual({ knowledge: "complete", pending: false });

      f.state.entries = [entry(1), entry(2)];
      const saving = lane.save();
      const parked = await signEvent.next();
      // Three stale leftovers, older than fragment 0 and past the governing count, so the list stays complete.
      const leftovers = await Promise.all([3, 4, 5].map((index) => f.fragment(index, [], index + 1, 900)));
      for (const leftover of leftovers) f.eventStore.add(leftover);
      await saving; // released by the first retirement
      parked.release();
      await until(() => signEvent.calls.length === 2);
      (await signEvent.next()).release();
      await settle();
      expect(f.published).toHaveLength(1);
      expect(signEvent.calls).toHaveLength(2);
      expect(f.sync.status).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await f.teardown();
    }
  });
});

/** A complete List whose fragment 1 sits above the declared count with content: interrupted-repack residue. */
async function residue(f: Awaited<ReturnType<typeof fixture>>): Promise<void> {
  f.eventStore.add(await f.fragment(0, [entry(1)], 1, 1_000));
  f.eventStore.add(await f.fragment(1, [entry(2)], 1, 900));
}

/** The keys of the duties currently armed or running (test-only view of the scope). */
function dutyKeys(f: Awaited<ReturnType<typeof fixture>>): string[] {
  return [...(f.duties as unknown as { entries: Map<string, unknown> }).entries.keys()];
}

/** Advance the manual clock in steps, letting every released attempt settle between them. */
async function run(f: Awaited<ReturnType<typeof fixture>>, steps: number[]): Promise<void> {
  for (const ms of steps) {
    f.clock.tick(ms);
    await f.duties.idle();
    await settle();
    await f.duties.idle();
  }
}

describe("the client's routed sync view (D-35, WR-06)", () => {
  it("receive() on the view waits behind an in-flight lane write, then stores the fragment so the lane can unlock it (WR-03)", async () => {
    const signEvent = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const f = await fixture({ gates: { signEvent } });
    try {
      const lane = f.lane();
      expect((await lane.read()).recorded).toBe(true);
      f.state.entries = [entry(1)];
      const saving = lane.save();
      const parked = await signEvent.next();
      const view = laneRoutedSync(f.sync, () => lane);
      const receive = spy(f.sync, "receive");
      const supplied = await f.fragment(0, [entry(1), entry(2)], 1, Math.floor(Date.now() / 1000) + 600);
      const receiving = view.receive(supplied, false);
      await settle();
      // The write owns the lane: the supplied fragment is neither stored nor received while it is in flight.
      expect(receive.calls.some((call) => call.args[0].id === supplied.id)).toBe(false);
      expect(f.eventStore.hasEvent(supplied.id)).toBe(false);
      parked.release();
      await saving;
      expect(await receiving).toBe(false); // received locked, as asked
      expect(f.eventStore.hasEvent(supplied.id)).toBe(true);
      expect(f.sync.locked).toBe(true);
      await lane.unlock(); // the lane finds it in the event store
      expect(f.sync.locked).toBe(false);
      expect(f.sync.fragments.get(0)?.id).toBe(supplied.id);
      // A fragment of another author is refused before anything is retained.
      const foreign = await new PrivateKeySigner(generateSecretKey()).signEvent({ ...supplied, tags: [["d", "1"]] });
      expect(await view.receive(foreign, false)).toBe(false);
      expect(f.eventStore.hasEvent(foreign.id)).toBe(false);
      expect(receive.calls.some((call) => call.args[0].id === foreign.id)).toBe(false);
    } finally {
      await f.teardown();
    }
  });

  it("abandon(), restore() and the read-evidence methods throw on the view and leave the sync untouched (WR-06)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const sync = new ConcordCommunityListSync(signer, async () => {}, { requireCompletedRead: true });
    const restore = spy(sync, "restore");
    const abandon = spy(sync, "abandon");
    const receive = spy(sync, "receive");
    const view = laneRoutedSync(sync, () => undefined);
    const event = await signer.signEvent({
      kind: COMMUNITY_LIST_FRAGMENT_KIND,
      created_at: 1,
      tags: [["d", "0"]],
      content: "x",
    });
    expect(() => view.abandon()).toThrow("standalone-only");
    expect(() => view.restore([event])).toThrow("standalone-only");
    expect(() => view.markReadComplete(view.beginRead())).toThrow("standalone-only");
    expect(() => view.clearReadEvidence()).toThrow("standalone-only");
    // WR-03: with no open lane and no lane-less path, receive() rejects instead of holding an event no lane stored.
    await expect(view.receive(event, false)).rejects.toThrow("not started");
    expect(receive.calls).toHaveLength(0);
    expect(restore.calls).toHaveLength(0);
    expect(abandon.calls).toHaveLength(0);
    expect(sync.status).toEqual({ knowledge: "unknown", pending: false });
    expect(sync.markReadComplete(sync.beginRead())).toBe(true); // the sync itself still works
    expect(view.status.knowledge).toBe("confirmed-empty"); // other members still read through
    await expect(view.write({ entries: [], tombstones: [] }, [])).rejects.toThrow("not started");
  });
});

describe("Community List repair duty (LIST-05, D-07, D-19)", () => {
  it("with autoRepair on, residue on a complete decrypted List arms one repair duty whose key holds only the lifecycle, episode and a hash of public ids (D-07)", async () => {
    const f = await fixture({ autoUnlock: true, autoRepair: true });
    try {
      await residue(f);
      const lane = f.lane();
      expect((await lane.start()).recorded).toBe(true);
      await settle();
      expect(f.sync.status.knowledge).toBe("complete");
      expect(f.sync.fragments.residue).toBe(true);
      expect(f.duties.pending).toBe(1);
      const keys = dutyKeys(f);
      expect(keys).toHaveLength(1);
      expect(keys[0]).toMatch(/^community-list-repair:1:0:[0-9a-f]{64}$/);
      expect(keys[0]).not.toContain(entry(2).community_id);
      expect(f.published).toHaveLength(0); // nothing before the delay
    } finally {
      await f.teardown();
    }
  });

  it("the repair runs through the lane and leaves a clean List (D-05, D-07)", async () => {
    const f = await fixture({ autoUnlock: true, autoRepair: true });
    try {
      await residue(f);
      const lane = f.lane();
      await lane.start();
      await settle();
      await run(f, [COMMUNITY_LIST_REPAIR_RETRY.delayMs + COMMUNITY_LIST_REPAIR_RETRY.jitterMs, 1_000]);
      expect(f.published.length).toBeGreaterThan(0);
      expect(f.sync.fragments.residue).toBe(false);
      expect(f.sync.fragments.document.entries.map((e) => e.community_id).sort()).toEqual(
        [entry(1).community_id, entry(2).community_id].sort(),
      );
      expect(f.duties.pending).toBe(0);
      expect(f.diagnostics.filter((d) => d.stage === "community-list-repair")).toHaveLength(0);
    } finally {
      await f.teardown();
    }
  });

  it("with autoRepair off, residue is reported once per held state and an explicit save arms the repair (D-19)", async () => {
    const f = await fixture({ autoUnlock: true, autoRepair: false });
    try {
      await residue(f);
      const lane = f.lane();
      await lane.start();
      await settle();
      await run(f, [60_000]);
      expect(f.published).toHaveLength(0);
      expect(f.duties.pending).toBe(0);
      expect(f.diagnostics.filter((d) => d.stage === "community-list-residue")).toHaveLength(1);
      await lane.unlock(); // the same held state is not reported again
      await settle();
      expect(f.diagnostics.filter((d) => d.stage === "community-list-residue")).toHaveLength(1);

      await lane.save({ explicit: true });
      expect(f.duties.pending).toBe(1);
      await run(f, [10_000, 1_000]);
      expect(f.sync.fragments.residue).toBe(false);
      expect(f.published.length).toBeGreaterThan(0);
    } finally {
      await f.teardown();
    }
  });

  it("a locked copy or a partial List never arms a repair (D-05)", async () => {
    const locked = await fixture({ autoUnlock: false, autoRepair: true });
    try {
      await residue(locked);
      const lane = locked.lane();
      await lane.start();
      await settle();
      expect(locked.sync.locked).toBe(true);
      expect(locked.duties.pending).toBe(0);
      expect(locked.diagnostics.filter((d) => d.stage === "community-list-residue")).toHaveLength(0);
    } finally {
      await locked.teardown();
    }
    const partial = await fixture({ autoUnlock: true, autoRepair: true });
    try {
      partial.eventStore.add(await partial.fragment(0, [entry(1)], 2, 1_000)); // declares 2, holds 1
      partial.eventStore.add(await partial.fragment(3, [entry(2)], 2, 900)); // dormant content
      const lane = partial.lane();
      await lane.start();
      await settle();
      expect(partial.sync.status.knowledge).toBe("partial");
      expect(partial.duties.pending).toBe(0);
      expect(partial.diagnostics.filter((d) => d.stage === "community-list-residue")).toHaveLength(0);
    } finally {
      await partial.teardown();
    }
  });

  it("a repair is never re-armed by its own publications and stays quiet once its budget is spent (LIST-05)", async () => {
    const f = await fixture({ autoUnlock: true, autoRepair: true });
    try {
      await residue(f);
      f.attempts.refuse = true; // every acknowledgment fails transiently
      const lane = f.lane();
      await lane.start();
      await settle();
      expect(f.duties.pending).toBe(1);
      await run(f, [3_500, 6_000, 11_000, 60_000, 60_000]);
      // One publication attempt per duty attempt: the first fragment of the first stage is refused.
      expect(f.attempts.publish).toBe(COMMUNITY_LIST_REPAIR_RETRY.maxAttempts);
      const exhausted = f.diagnostics.filter((d) => d.stage === "duty-exhausted");
      expect(exhausted).toHaveLength(1);
      expect(exhausted[0].duty).toBe("community-list-repair");
      expect(f.diagnostics.filter((d) => d.stage === "community-list-repair").length).toBeGreaterThan(0);
      expect(f.duties.pending).toBe(0);
      // The same held state, a later unlock and a non-explicit save stay quiet.
      await lane.unlock();
      await lane.save();
      await settle();
      await run(f, [60_000]);
      expect(f.attempts.publish).toBe(COMMUNITY_LIST_REPAIR_RETRY.maxAttempts);
      expect(f.duties.pending).toBe(0);
    } finally {
      await f.teardown();
    }
  });

  it("a repair that the signer declines settles after one community-list-repair report and is not retried (D-07)", async () => {
    const signEvent = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const f = await fixture({ autoUnlock: true, autoRepair: true, gates: { signEvent } });
    try {
      await residue(f);
      const lane = f.lane();
      await lane.start();
      await settle();
      f.clock.tick(3_500);
      const parked = await signEvent.next();
      parked.fail(new Error("user declined"));
      await f.duties.idle();
      await settle();
      await run(f, [60_000, 60_000]);
      expect(signEvent.calls).toHaveLength(1);
      const reports = f.diagnostics.filter((d) => d.stage === "community-list-repair");
      expect(reports).toHaveLength(1);
      expect(f.diagnostics.filter((d) => d.stage === "duty-exhausted")).toHaveLength(0);
      expect(f.published).toHaveLength(0);
      expect(f.duties.pending).toBe(0);
    } finally {
      await f.teardown();
    }
  });

  it("close() abandons a sync task waiting on the signer so the next lane's save runs (LIST-05)", async () => {
    const signEvent = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const f = await fixture({ autoUnlock: true, autoRepair: true, gates: { signEvent } });
    try {
      await residue(f);
      const first = f.lane();
      await first.start();
      await settle();
      f.clock.tick(3_500);
      const parked = await signEvent.next(); // the repair waits on a prompt nobody answers
      first.close();
      f.duties.cancelAll("stop");

      const second = f.lane();
      expect((await second.start()).recorded).toBe(true);
      f.state.entries = [entry(9)];
      const saving = second.save({ explicit: true });
      let timer: ReturnType<typeof setTimeout> | undefined;
      const next = await Promise.race([
        signEvent.next(),
        new Promise<never>((_, reject) => {
          timer = setTimeout(() => reject(new Error("save blocked behind the old task")), 3_000);
        }),
      ]).finally(() => clearTimeout(timer));
      next.release();
      await saving;
      await settle();
      const publishedBefore = f.published.length;
      expect(publishedBefore).toBeGreaterThan(0);
      parked.release(); // the abandoned task resumes and publishes nothing
      await settle();
      expect(f.published).toHaveLength(publishedBefore);
    } finally {
      await f.teardown();
    }
  });

  it("an unlock still releases a held save while only a repair duty is pending", async () => {
    const f = await fixture({ autoUnlock: true, autoRepair: true });
    try {
      await residue(f);
      const lane = f.lane();
      await lane.start();
      await settle();
      expect(f.duties.pending).toBe(1); // only the repair duty
      expect(f.duties.slotPending("community-list-read")).toBe(false);
      f.state.entries = [entry(1), entry(5)];
      f.state.held = true;
      await lane.unlock();
      await settle();
      expect(f.calls).toContain("markPublished"); // the held save ran
    } finally {
      await f.teardown();
    }
  });
});
