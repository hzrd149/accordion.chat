// readUserList completion evidence (D-13, D-21). Completeness comes only from a relay's
// own "complete" state; errors, liveness skips, timeouts and cancellation are incomplete
// (CORD-02 §8: a short read means incomplete).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { EMPTY, from, NEVER, of, throwError } from "rxjs";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { EventStore } from "applesauce-core";
import type { RelayPool } from "applesauce-relay";
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { Filter } from "applesauce-core/helpers/filter";

import { readUserList } from "../community-list-read.ts";

const KIND = 33302;

interface RelayScript {
  [url: string]: "good" | "bad" | "silent";
}

function multiPool(script: RelayScript, events: NostrEvent[]) {
  const relayFor = (url: string) => ({
    url,
    getSupported: async () => null,
    sync: () => EMPTY,
    request: (filters: Filter | Filter[]) => {
      const mode = script[url.replace(/\/$/, "")]; // the loader normalizes relay URLs
      if (mode === "bad") return throwError(() => new Error(`${url} failed`));
      if (mode === "silent") return NEVER;
      // A misbehaving relay may ignore the author/kind filter entirely; the reader must not trust it.
      const until = (Array.isArray(filters) ? filters : [filters])[0]?.until;
      return from(events.filter((event) => until === undefined || event.created_at <= until));
    },
  });
  const pool = { relay: (url: string) => relayFor(url) } as unknown as RelayPool & {
    filterRelays?: (relays: string[]) => string[];
  };
  return pool;
}

async function signed(signer: PrivateKeySigner, kind = KIND, content = "x") {
  return await signer.signEvent({ kind, created_at: 100, tags: [["d", "0"]], content });
}

describe("readUserList completion evidence (D-13, D-21)", () => {
  it("reports incomplete when every relay errors", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const outcome = await readUserList({
        pool: multiPool({ "wss://a": "bad", "wss://b": "bad" }, []),
        eventStore: store,
        relays: ["wss://a", "wss://b"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
      });
      expect(outcome.complete).toBe(false);
      expect(outcome.events).toEqual([]);
    } finally {
      store.dispose();
    }
  });

  it("reports incomplete when pool liveness skips every relay", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const pool = multiPool({ "wss://good": "good" }, [await signed(signer)]);
      pool.filterRelays = () => [];
      const outcome = await readUserList({
        pool,
        eventStore: store,
        relays: ["wss://good"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
      });
      expect(outcome.complete).toBe(false);
      expect(outcome.relays["wss://good/"]).toBe("skipped");
    } finally {
      store.dispose();
    }
  });

  it("reports complete when one relay completes and another errors", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const event = await signed(signer);
      const outcome = await readUserList({
        pool: multiPool({ "wss://good": "good", "wss://bad": "bad" }, [event]),
        eventStore: store,
        relays: ["wss://good", "wss://bad"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
      });
      expect(outcome.complete).toBe(true);
      expect(outcome.events.map((e) => e.id)).toEqual([event.id]);
      // D-21/D-28: per-relay evidence is kept so a stricter rule is a small later change.
      expect(outcome.relays["wss://good/"]).toBe("complete");
      expect(outcome.relays["wss://bad/"]).toBe("error");
    } finally {
      store.dispose();
    }
  });

  it("reports incomplete when a relay never answers before the timeout", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const outcome = await readUserList({
        pool: multiPool({ "wss://silent": "silent" }, []),
        eventStore: store,
        relays: ["wss://silent"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
        timeoutMs: 50,
      });
      expect(outcome.complete).toBe(false);
      expect(outcome.cancelled).toBe(false); // a relay failure, not a cancellation
    } finally {
      store.dispose();
    }
  });

  it("stops early and reports incomplete when cancelled", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const outcome = await readUserList({
        pool: multiPool({ "wss://silent": "silent" }, []),
        eventStore: store,
        relays: ["wss://silent"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
        cancelled$: of(undefined),
      });
      expect(outcome.complete).toBe(false);
      expect(outcome.cancelled).toBe(true);
      expect(outcome.events).toEqual([]);
    } finally {
      store.dispose();
    }
  });

  it("reports incomplete instead of rejecting when the store throws", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const throwing = Object.assign(Object.create(store), {
        add: () => {
          throw new Error("store unavailable");
        },
      }) as EventStore;
      const outcome = await readUserList({
        pool: multiPool({ "wss://good": "good" }, [await signed(signer)]),
        eventStore: throwing,
        relays: ["wss://good"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
      });
      expect(outcome.complete).toBe(false);
      expect(outcome.events).toEqual([]);
    } finally {
      store.dispose();
    }
  });

  it("ends at the overall deadline even while the per-relay stall clock has not fired", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const started = Date.now();
      const outcome = await readUserList({
        pool: multiPool({ "wss://silent": "silent" }, []),
        eventStore: store,
        relays: ["wss://silent"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
        timeoutMs: 10_000,
        deadlineMs: 50,
      });
      expect(outcome.complete).toBe(false);
      expect(outcome.cancelled).toBe(false);
      expect(Date.now() - started).toBeLessThan(5_000);
    } finally {
      store.dispose();
    }
  });

  it("keeps a relay that completed when the overall deadline cuts a silent one (WR-02, D-13, D-21)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const event = await signed(signer);
      const outcome = await readUserList({
        pool: multiPool({ "wss://good": "good", "wss://silent": "silent" }, [event]),
        eventStore: store,
        relays: ["wss://good", "wss://silent"],
        pubkey: await signer.getPublicKey(),
        kind: KIND,
        timeoutMs: 10_000,
        deadlineMs: 50,
      });
      expect(outcome.complete).toBe(true);
      expect(outcome.cancelled).toBe(false);
      expect(outcome.events.map((e) => e.id)).toEqual([event.id]);
      expect(outcome.relays["wss://good/"]).toBe("complete");
      expect(outcome.relays["wss://silent/"]).not.toBe("complete");
    } finally {
      store.dispose();
    }
  });

  it("never retains forged, off-author or off-kind events", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const other = new PrivateKeySigner(generateSecretKey());
    const store = new EventStore();
    try {
      const pubkey = await signer.getPublicKey();
      const valid = await signed(signer);
      const offAuthor = await signed(other);
      const offKind = await signed(signer, 1);
      const forged = { ...(await signed(signer, KIND, "original")), content: "altered" };
      const outcome = await readUserList({
        pool: multiPool({ "wss://good": "good" }, [valid, offAuthor, offKind, forged]),
        eventStore: store,
        relays: ["wss://good"],
        pubkey,
        kind: KIND,
      });
      expect(outcome.complete).toBe(true);
      expect(outcome.events.map((e) => e.id)).toEqual([valid.id]);
      const retained = store.getByFilters([{}]);
      expect([...retained].map((e) => e.id)).toEqual([valid.id]);
    } finally {
      store.dispose();
    }
  });
});
