// DutyScope contract (FND-01, FND-02) and the deferred-completion harness it is proven with (FND-05).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { spy } from "@std/testing/mock";
import { FakeTime } from "@std/testing/time";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { DutyCancelledError, type DutyContext, type DutyReport, DutyScope, systemClock } from "../lifecycle.ts";
import { deferred, Gate, gatedSigner, ManualClock } from "./test-utils.ts";

function fixture(options: { random?: number; maxSettledKeys?: number } = {}) {
  const clock = new ManualClock({ random: options.random });
  const reports: DutyReport[] = [];
  const scope = new DutyScope({
    clock,
    report: (report) => reports.push(report),
    maxSettledKeys: options.maxSettledKeys,
  });
  return { clock, reports, scope };
}

describe("deferred completion harness (FND-05)", () => {
  it("Gate delivers deferred completions in any order", async () => {
    const gate = new Gate<[number], number>();
    const wrapped = gate.wrap((n) => Promise.resolve(n * 2), (n) => n !== 99);
    const order: number[] = [];
    const first = wrapped(1).then((v) => order.push(v));
    const second = wrapped(2).then((v) => order.push(v));
    const failing = wrapped(3);
    const failure = expect(failing).rejects.toThrow("boom");

    const a = await gate.next();
    const b = await gate.next();
    const c = await gate.next();
    expect(gate.calls).toHaveLength(3);
    expect(a.args).toEqual([1]);
    c.fail(new Error("boom"));
    b.release();
    await second;
    expect(order).toEqual([4]);
    a.release();
    await first;
    await failure;
    expect(order).toEqual([4, 2]);

    // Calls not matching `match` pass straight through and never enter the gate.
    expect(await wrapped(99)).toBe(198);
    expect(gate.calls).toHaveLength(3);

    // next() waits for an entry instead of polling.
    const waiting = gate.next();
    const late = wrapped(5);
    const call = await waiting;
    call.release();
    expect(await late).toBe(10);

    const d = deferred<number>();
    d.resolve(3);
    expect(await d.promise).toBe(3);
  });

  it("ManualClock fires due callbacks in order and reports pending", () => {
    const clock = new ManualClock({ now: 1_000 });
    const fired: string[] = [];
    clock.schedule(50, () => fired.push("b"));
    clock.schedule(10, () => fired.push("a"));
    clock.schedule(50, () => fired.push("c"));
    const cancel = clock.schedule(20, () => fired.push("cancelled"));
    expect(clock.pending).toBe(4);
    cancel();
    expect(clock.pending).toBe(3);
    clock.tick(9);
    expect(fired).toEqual([]);
    expect(clock.now()).toBe(1_009);
    clock.tick(1);
    expect(fired).toEqual(["a"]);
    clock.schedule(5, () => fired.push("nested"));
    clock.tick(40);
    expect(fired).toEqual(["a", "nested", "b", "c"]);
    expect(clock.pending).toBe(0);
    expect(clock.now()).toBe(1_050);
  });
});

describe("DutyScope (FND-01, FND-02)", () => {
  it("slotPending reports only the named slot's armed or running duty", async () => {
    const { clock, scope } = fixture();
    const release = deferred<void>();
    expect(scope.slotPending("a")).toBe(false);
    scope.request({ key: "a1", slot: "a", stage: "test", run: () => release.promise });
    expect(scope.slotPending("a")).toBe(true); // armed
    expect(scope.slotPending("b")).toBe(false); // another slot does not count
    clock.tick(0);
    expect(scope.slotPending("a")).toBe(true); // running
    release.resolve();
    await scope.idle();
    expect(scope.slotPending("a")).toBe(false); // settled
    scope.request({ key: "a2", slot: "a", stage: "test", delayMs: 100, run: () => {} });
    scope.request({ key: "a3", slot: "a", stage: "test", delayMs: 100, run: () => {} });
    expect(scope.slotPending("a")).toBe(true);
    scope.cancelAll("test");
    expect(scope.slotPending("a")).toBe(false); // cancelled
    scope.dispose();
  });

  it("coalesces repeated requests for one key into a single run", async () => {
    const { clock, scope } = fixture();
    const run = spy(() => {});
    expect(scope.request({ key: "k", stage: "test", run })).toBe("armed");
    for (let i = 0; i < 99; i++) expect(scope.request({ key: "k", stage: "test", run })).toBe("coalesced");
    clock.tick(0);
    await scope.idle();
    expect(run.calls).toHaveLength(1);
    scope.dispose();
  });

  it("runs each stable key at most once", async () => {
    const { clock, scope } = fixture();
    const run = spy(() => {});
    scope.request({ key: "k", stage: "test", run });
    clock.tick(0);
    await scope.idle();
    expect(scope.request({ key: "k", stage: "test", run })).toBe("quiet");
    clock.tick(10_000);
    await scope.idle();
    expect(run.calls).toHaveLength(1);
    expect(scope.request({ key: "other", stage: "test", run })).toBe("armed");
    clock.tick(0);
    await scope.idle();
    expect(run.calls).toHaveLength(2);
    scope.dispose();
  });

  it("retries a failing duty within its budget and reports exhaustion once", async () => {
    const { clock, reports, scope } = fixture();
    const attempts: number[] = [];
    scope.request({
      key: "k",
      stage: "retry",
      retryDelayMs: 100,
      run: (ctx) => {
        attempts.push(ctx.attempt);
        throw new Error("nope");
      },
    });
    clock.tick(0);
    await scope.idle();
    expect(attempts).toEqual([1]);
    clock.tick(99);
    await scope.idle();
    expect(attempts).toEqual([1]);
    clock.tick(1);
    await scope.idle();
    expect(attempts).toEqual([1, 2]);
    clock.tick(200);
    await scope.idle();
    expect(attempts).toEqual([1, 2, 3]);
    clock.tick(60_000);
    await scope.idle();
    expect(attempts).toEqual([1, 2, 3]);
    expect(reports.map((report) => report.kind)).toEqual(["failed", "failed", "failed", "exhausted"]);
    expect(reports.every((report) => report.stage === "retry" && report.key === "k")).toBe(true);
    expect(scope.pending).toBe(0);
    scope.dispose();
  });

  it("stays quiet for an exhausted key until the key changes", async () => {
    const { clock, reports, scope } = fixture();
    const run = spy(() => {
      throw new Error("nope");
    });
    scope.request({ key: "k", stage: "test", run, maxAttempts: 1 });
    clock.tick(0);
    await scope.idle();
    expect(reports.map((report) => report.kind)).toEqual(["failed", "exhausted"]);
    expect(scope.request({ key: "k", stage: "test", run, maxAttempts: 1 })).toBe("quiet");
    expect(scope.request({ key: "k2", stage: "test", run, maxAttempts: 1 })).toBe("armed");
    clock.tick(0);
    await scope.idle();
    expect(run.calls).toHaveLength(2);
    scope.dispose();
  });

  it("honors the lifetime budget even when attempts remain", async () => {
    const { clock, reports, scope } = fixture();
    const attempts: number[] = [];
    scope.request({
      key: "k",
      stage: "test",
      maxAttempts: 10,
      retryDelayMs: 100,
      lifetimeMs: 150,
      run: (ctx) => {
        attempts.push(ctx.attempt);
        throw new Error("nope");
      },
    });
    for (let i = 0; i < 20; i++) {
      clock.tick(100);
      await scope.idle();
    }
    expect(attempts.length).toBeLessThan(10);
    expect(attempts.length).toBeGreaterThanOrEqual(2);
    expect(reports.filter((report) => report.kind === "exhausted")).toHaveLength(1);
    expect(scope.pending).toBe(0);
    scope.dispose();
  });

  it("dispose cancels every armed timer and is idempotent", () => {
    const { clock, scope } = fixture();
    const run = spy(() => {});
    scope.request({ key: "a", stage: "test", run, delayMs: 100 });
    scope.request({ key: "b", stage: "test", run, delayMs: 200 });
    expect(scope.pending).toBe(2);
    scope.dispose();
    expect(scope.disposed).toBe(true);
    expect(scope.pending).toBe(0);
    expect(clock.pending).toBe(0);
    scope.dispose();
    expect(scope.request({ key: "c", stage: "test", run })).toBe("refused");
    clock.tick(10_000);
    expect(run.calls).toHaveLength(0);
  });

  it("suspend refuses publication duties but admits local cleanup duties", async () => {
    const { clock, scope } = fixture();
    const publish = spy(() => {});
    const cleanup = spy(() => {});
    scope.request({ key: "pub", stage: "test", run: publish, delayMs: 100 });
    scope.request({ key: "armed-local", stage: "test", run: cleanup, delayMs: 100, publishes: false });
    expect(scope.pending).toBe(2);
    scope.suspend("dissolved");
    scope.suspend("second reason is ignored");
    expect(scope.suspendedReason).toBe("dissolved");
    expect(scope.pending).toBe(1);
    expect(scope.request({ key: "pub2", stage: "test", run: publish })).toBe("refused");
    expect(scope.request({ key: "local", stage: "test", run: cleanup, publishes: false })).toBe("armed");
    clock.tick(100);
    await scope.idle();
    expect(publish.calls).toHaveLength(0);
    expect(cleanup.calls).toHaveLength(2);
    scope.dispose();
  });

  it("reevaluate cancels armed duties whose eligibility was lost", async () => {
    const { clock, scope } = fixture();
    let eligible = true;
    const run = spy(() => {});
    scope.request({ key: "k", stage: "test", run, delayMs: 100, eligible: () => eligible });
    eligible = false;
    scope.reevaluate();
    expect(scope.pending).toBe(0);
    expect(clock.pending).toBe(0);
    clock.tick(100);
    await scope.idle();
    expect(run.calls).toHaveLength(0);
    // Cancelling for eligibility does not settle the key, so it can be re-armed later.
    eligible = true;
    expect(scope.request({ key: "k", stage: "test", run, eligible: () => eligible })).toBe("armed");
    clock.tick(0);
    await scope.idle();
    expect(run.calls).toHaveLength(1);
    scope.dispose();
  });

  it("cancelAll clears armed duties and budgets but keeps the scope usable", async () => {
    const { clock, scope } = fixture();
    const run = spy(() => {});
    scope.request({ key: "armed", stage: "test", run, delayMs: 100 });
    scope.request({ key: "settled", stage: "test", run });
    clock.tick(0);
    await scope.idle();
    expect(run.calls).toHaveLength(1);
    scope.cancelAll("client stop");
    expect(scope.pending).toBe(0);
    expect(clock.pending).toBe(0);
    expect(scope.disposed).toBe(false);
    expect(scope.suspendedReason).toBeUndefined();
    expect(scope.request({ key: "settled", stage: "test", run })).toBe("armed");
    clock.tick(0);
    await scope.idle();
    expect(run.calls).toHaveLength(2);
    scope.dispose();
  });

  it("a run resumed after dispose observes it is no longer alive", async () => {
    const { clock, reports, scope } = fixture();
    const signer = new PrivateKeySigner(generateSecretKey());
    const gate = new Gate<
      Parameters<PrivateKeySigner["signEvent"]>,
      Awaited<ReturnType<PrivateKeySigner["signEvent"]>>
    >();
    const gated = gatedSigner(signer, { signEvent: gate });
    const publish = spy((_event: unknown) => {});
    let context: DutyContext | undefined;
    scope.request({
      key: "k",
      stage: "test",
      run: async (ctx) => {
        context = ctx;
        const signed = await gated.signEvent({ kind: 1, content: "", tags: [], created_at: 1 });
        ctx.assertAlive();
        publish(signed);
      },
    });
    clock.tick(0);
    const call = await gate.next();
    expect(context?.alive()).toBe(true);
    scope.dispose();
    call.release();
    await scope.idle();
    expect(context?.alive()).toBe(false);
    expect(() => context?.assertAlive()).toThrow(DutyCancelledError);
    expect(publish.calls).toHaveLength(0);
    expect(reports).toEqual([]);
  });

  it("a superseded key's late completion never overwrites the newer key", async () => {
    const { clock, reports, scope } = fixture();
    const gate = new Gate<[], void>();
    const parked = gate.wrap(() => Promise.resolve());
    let result = "none";
    scope.request({
      key: "A",
      slot: "pins:c1",
      stage: "test",
      run: async (ctx) => {
        await parked();
        ctx.assertAlive();
        result = "A";
      },
    });
    clock.tick(0);
    const callA = await gate.next();
    expect(scope.request({
      key: "B",
      slot: "pins:c1",
      stage: "test",
      run: (ctx) => {
        ctx.assertAlive();
        result = "B";
      },
    })).toBe("armed");
    clock.tick(0);
    await Promise.resolve();
    expect(result).toBe("B");
    callA.release();
    await scope.idle();
    expect(result).toBe("B");
    expect(reports).toEqual([]);
    scope.dispose();
  });

  it("a run reads current state at fire time, not at request time", async () => {
    const { clock, scope } = fixture();
    let state = "at request";
    let seen = "";
    scope.request({
      key: "k",
      stage: "test",
      delayMs: 100,
      run: () => {
        seen = state;
      },
    });
    state = "at fire";
    clock.tick(100);
    await scope.idle();
    expect(seen).toBe("at fire");
    scope.dispose();
  });

  it("uses only the injected clock for delay, jitter and lifetime", async () => {
    const { clock, scope } = fixture({ random: 0.5 });
    const run = spy(() => {});
    scope.request({ key: "k", stage: "test", run, delayMs: 1_000, jitterMs: 100 });
    clock.tick(1_049);
    await scope.idle();
    expect(run.calls).toHaveLength(0);
    clock.tick(1);
    await scope.idle();
    expect(run.calls).toHaveLength(1);

    // Lifetime is measured on the same clock, not wall time.
    const attempts = spy((_ctx: DutyContext) => {
      throw new Error("nope");
    });
    scope.request({ key: "life", stage: "test", run: attempts, maxAttempts: 10, retryDelayMs: 10, lifetimeMs: 5 });
    clock.tick(0);
    await scope.idle();
    expect(attempts.calls).toHaveLength(1);
    scope.dispose();
  });

  it("bounds remembered settled keys", async () => {
    const { clock, scope } = fixture({ maxSettledKeys: 2 });
    const run = spy(() => {});
    for (const key of ["k1", "k2", "k3"]) {
      scope.request({ key, stage: "test", run });
      clock.tick(0);
      await scope.idle();
    }
    expect(scope.request({ key: "k3", stage: "test", run })).toBe("quiet");
    expect(scope.request({ key: "k2", stage: "test", run })).toBe("quiet");
    expect(scope.request({ key: "k1", stage: "test", run })).toBe("armed");
    scope.dispose();
  });

  it("leaves no pending FakeTime timers after dispose", () => {
    const time = new FakeTime(1_000);
    try {
      const run = spy(() => {});
      const control = new DutyScope();
      control.request({ key: "control", stage: "test", run, delayMs: 500 });
      time.tick(500);
      expect(run.calls).toHaveLength(1);
      control.dispose();

      const scope = new DutyScope();
      scope.request({ key: "k", stage: "test", run, delayMs: 500 });
      scope.dispose();
      expect(time.next()).toBe(false);
      expect(run.calls).toHaveLength(1);
    } finally {
      time.restore();
    }
  });

  it("a disposed real-timer duty leaves nothing for the sanitizer", () => {
    const scope = new DutyScope({ clock: systemClock });
    expect(scope.request({ key: "k", stage: "test", run: () => {}, delayMs: 60_000 })).toBe("armed");
    expect(scope.pending).toBe(1);
    scope.dispose();
    expect(scope.pending).toBe(0);
  });
});
