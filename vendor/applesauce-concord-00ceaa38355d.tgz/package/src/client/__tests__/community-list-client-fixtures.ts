// Shared ConcordClient fixtures for the Phase 3 Community List client tests (restart, repair, aggregate read). Not a
// test file: it only exports helpers. The same helpers live, unexported, in client.community-list-offline.test.ts.

import { expect } from "@std/expect";
import { filter, firstValueFrom, type Observable, race, timer } from "rxjs";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";
import { EventStore } from "applesauce-core";
import type { RelayPool } from "applesauce-relay";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { ConcordClient } from "../client.ts";
import type { JoinMaterial } from "../../types.ts";
import type { CommunityListCommunity } from "../../types.ts";
import { type ConcordStorage, memoryStorage } from "../storage.ts";
import type { ManualClock } from "./test-utils.ts";
import { type DutyReport, DutyScope } from "../lifecycle.ts";
import { createLegacyCommunity } from "../../helpers/__tests__/test-utils.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  type CommunityListFragment,
  decodeCommunityListFragment,
  encodeCommunityListFragment,
} from "../../helpers/community-list-wire.ts";
import { mergeCommunities } from "../../helpers/community-list.ts";

/** A short real-time pause for background work to finish. */
export const settle: () => Promise<unknown> = () => new Promise((r) => setTimeout(r, 200));
/** A longer pause that outlasts the auto-save debounce. */
export const settleFlush: () => Promise<unknown> = () => new Promise((r) => setTimeout(r, 700));

/** The published kind-33302 events among `published`. */
export const listPublishes = (published: NostrEvent[]): NostrEvent[] =>
  published.filter((e) => e.kind === COMMUNITY_LIST_FRAGMENT_KIND);

/** What {@link vault} builds. */
export interface Vault {
  /** The user's signer. */
  signer: PrivateKeySigner;
  /** The user's pubkey. */
  pubkey: string;
  /** Community A's join material. */
  material: JoinMaterial;
  /** The memberships the relay fragments (and the local mirror) hold. */
  entries: CommunityListCommunity[];
  /** The `created_at` of the relay fragments, in the past. */
  old: number;
  /** The signed fragments the relay holds. */
  events: NostrEvent[];
  /** Storage holding only the local mirror document. */
  storage: ConcordStorage;
}

/**
 * The vault: community A on a device whose relays hold two old fragments (`frags: 2`). `fragments` replaces the relay
 * documents (index by position); `entries` replaces the memberships the default documents and the mirror hold.
 */
export async function vault(
  options: { relayVault?: boolean; entries?: CommunityListCommunity[]; fragments?: unknown[] } = {},
): Promise<Vault> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const a = (await createLegacyCommunity({ ownerPubkey: pubkey, name: "A", relays: ["wss://fake"] })).material;
  const material = { ...a, held_roots: a.held_roots ?? [] };
  const entries = options.entries ?? mergeCommunities([], [{
    community_id: material.community_id,
    seed: material,
    current: material,
    added_at: 1,
  }]);
  const old = Math.floor(Date.now() / 1000) - 1000;
  const frag = async (index: number, doc: unknown) =>
    signer.signEvent({
      kind: COMMUNITY_LIST_FRAGMENT_KIND,
      created_at: old,
      tags: [["d", String(index)]],
      content: await signer.nip44!.encrypt(pubkey, encodeCommunityListFragment(doc as CommunityListFragment)),
    });
  const documents = options.fragments ?? [
    { frags: 2, entries, tombstones: [] },
    { frags: 2, entries: [], tombstones: [] },
  ];
  const events: NostrEvent[] = [];
  if (options.relayVault !== false) {
    for (const [index, doc] of documents.entries()) events.push(await frag(index, doc));
  }
  const storage = memoryStorage();
  await storage.setItem(pubkey, JSON.stringify({ entries, tombstones: [] }));
  return { signer, pubkey, material, entries, old, events, storage };
}

/** What {@link harness} returns. */
export interface Harness {
  /** The event store of every client built so far, in order. */
  stores: EventStore[];
  /** Builds a client on `signer`, `pool` and `storage`, torn down by {@link Harness.teardown}. */
  client(
    signer: ISigner,
    pool: RelayPool,
    storage: ConcordStorage,
    extra?: Partial<ConstructorParameters<typeof ConcordClient>[0]>,
  ): ConcordClient;
  /** Stops and disposes every client and event store the harness built. */
  teardown(): Promise<void>;
}

/** Everything a test builds, torn down in one place (background community.start() leaks intervals otherwise). */
export function harness(): Harness {
  const clients: ConcordClient[] = [];
  const stores: EventStore[] = [];
  return {
    stores,
    client(signer, pool, storage, extra = {}) {
      const store = new EventStore();
      stores.push(store);
      const client = new ConcordClient({
        signer,
        pool,
        eventStore: store,
        storage,
        relays: ["wss://fake"],
        watchDirectInvites: false,
        ...extra,
      });
      clients.push(client);
      return client;
    },
    async teardown() {
      await settle();
      for (const client of clients) {
        client.stop();
        client.dispose();
      }
      for (const store of stores) store.dispose();
      await settle();
    },
  };
}

/** Resolve with the first kind-33302 publish, or undefined after the guard elapses. */
export function firstListPublish(
  published$: Observable<NostrEvent>,
  ms: number = 4000,
): Promise<NostrEvent | undefined> {
  return firstValueFrom(
    race(published$.pipe(filter((e) => e.kind === COMMUNITY_LIST_FRAGMENT_KIND)), timer(ms)),
  ).then((value) => (typeof value === "number" ? undefined : value));
}

/** Decrypt a fragment event with the owner's signer. */
export async function fragmentOf(signer: PrivateKeySigner, event: NostrEvent): Promise<CommunityListFragment> {
  const pubkey = await signer.getPublicKey();
  return decodeCommunityListFragment(await signer.nip44!.decrypt(pubkey, event.content));
}

/** The client's current Community List status. */
export const statusOf = (client: ConcordClient): Promise<{ knowledge: string; pending: boolean }> =>
  firstValueFrom(client.communityListStatus$);

/** The `d` tag of a fragment event. */
export const dTag = (event: NostrEvent): string | undefined => event.tags.find((t) => t[0] === "d")?.[1];

/** The client internals a test swaps to drive the read duty by hand. */
export interface DutyInternals {
  listDuties: DutyScope;
  diagnostics: { reportDuty(report: DutyReport): void };
}

/** Replace the constructor-created scope with a ManualClock-driven one before `start()` (the real-time hydration wait is unaffected). */
export function injectClock(client: ConcordClient, clock: ManualClock): DutyInternals {
  const internals = client as unknown as DutyInternals;
  internals.listDuties.dispose();
  internals.listDuties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report) });
  return internals;
}

/** Advance the manual clock, then let the released duty attempt and the loader's real timers finish. */
export async function advance(internals: DutyInternals, clock: ManualClock, ms: number): Promise<void> {
  clock.tick(ms);
  await internals.listDuties.idle();
  await settle();
  await internals.listDuties.idle();
}

/** The community ids of a document's entries. */
export const idsOf = (doc: { entries: Array<{ community_id: string }> }): string[] =>
  doc.entries.map((e) => e.community_id);

/** A fresh membership owned by `pubkey`, in join-material form. */
export async function membership(pubkey: string, name: string): Promise<JoinMaterial> {
  const material = (await createLegacyCommunity({ ownerPubkey: pubkey, name, relays: ["wss://fake"] })).material;
  return { ...material, held_roots: material.held_roots ?? [] };
}

/** Community List entries for `materials`, in order, with increasing `added_at`. */
export const entriesOf = (materials: JoinMaterial[]): CommunityListCommunity[] =>
  mergeCommunities(
    [],
    materials.map((m, index) => ({ community_id: m.community_id, seed: m, current: m, added_at: index + 1 })),
  );

/** Poll `ready` in real time (at most 2 s). */
export async function until(ready: () => boolean): Promise<void> {
  for (let i = 0; i < 100 && !ready(); i++) await new Promise((r) => setTimeout(r, 20));
  expect(ready()).toBe(true);
}

/** `promise`'s outcome, or `"pending"` when it has not settled within `ms`: a bounded wait, so a hang is an assertion. */
export async function within<T>(promise: Promise<T>, ms: number): Promise<T | "pending"> {
  let timer = 0;
  const pending = new Promise<"pending">((resolve) => (timer = setTimeout(() => resolve("pending"), ms)));
  const outcome = await Promise.race([promise, pending]);
  clearTimeout(timer);
  return outcome;
}

/** One self-encrypted fragment at `index`, signed at `created_at`. */
export async function fragment(
  signer: PrivateKeySigner,
  index: number,
  doc: unknown,
  created_at: number,
): Promise<NostrEvent> {
  const pubkey = await signer.getPublicKey();
  return signer.signEvent({
    kind: COMMUNITY_LIST_FRAGMENT_KIND,
    created_at,
    tags: [["d", String(index)]],
    content: await signer.nip44!.encrypt(pubkey, encodeCommunityListFragment(doc as CommunityListFragment)),
  });
}
