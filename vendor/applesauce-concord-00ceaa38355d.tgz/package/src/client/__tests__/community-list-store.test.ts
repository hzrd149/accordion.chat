// Durable Community List fragment record (LIST-03, D-01, D-02): versioned, ciphertext-only, coalescing writer.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import type { NostrEvent } from "applesauce-core/helpers/event";
import {
  COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS,
  COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS,
  communityListFragmentsKey,
  CommunityListFragmentStore,
  FragmentPersistError,
} from "../community-list-store.ts";
import { retriesListSave } from "../community-list-read.ts";
import { type ConcordStorage, memoryStorage } from "../storage.ts";
import { Gate, gatedStorage, ManualClock } from "./test-utils.ts";

const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
const PUBKEY = await signer.getPublicKey();
const KEY = `concord:list-fragments:${PUBKEY}`;

/**
 * A real signed kind-33302 event as it reads back from storage (the signer's in-memory verification marker is not
 * part of the wire form); the content is opaque to the store, so any string stands in for ciphertext.
 */
const fragment = async (index: number, content: string, created_at = 1): Promise<NostrEvent> =>
  JSON.parse(
    JSON.stringify(await signer.signEvent({ kind: 33302, created_at, tags: [["d", String(index)]], content })),
  );

const record = (overrides: Record<string, unknown> = {}) =>
  JSON.stringify({ version: 1, pubkey: PUBKEY, fragments: [], ...overrides });

/** Storage whose writes fail while `state.failing` is set. */
function flakyStorage(state: { failing: boolean }) {
  const inner = memoryStorage();
  const writes: string[] = [];
  const storage: ConcordStorage = {
    getItem: (key) => inner.getItem(key),
    setItem: (key, value) => {
      if (state.failing) return Promise.reject(new Error("quota exceeded"));
      writes.push(value);
      return inner.setItem(key, value);
    },
    removeItem: (key) => inner.removeItem(key),
  };
  return { storage, inner, writes };
}

describe("Community List fragment record (LIST-03, D-01, D-02)", () => {
  it("load returns no events for a missing record", async () => {
    const store = new CommunityListFragmentStore(memoryStorage());
    expect(await store.load(PUBKEY)).toEqual({ events: [], dropped: 0 });
    expect(communityListFragmentsKey(PUBKEY)).toBe(KEY);
  });

  it("load refuses a record with another version, another pubkey or a malformed shape", async () => {
    const bad: string[] = [
      "{not json",
      record({ version: 2 }),
      JSON.stringify({ pubkey: PUBKEY, fragments: [] }), // no version
      record({ pubkey: "ab".repeat(32) }),
      record({ fragments: {} }),
      "[]",
      record({ count: 0 }),
      record({ count: 1.5 }),
      record({ count: "2" }),
      record({ count: null }),
    ];
    for (const raw of bad) {
      const storage = memoryStorage();
      await storage.setItem(KEY, raw);
      const store = new CommunityListFragmentStore(storage);
      await expect(store.load(PUBKEY)).rejects.toThrow("invalid Community List fragment record");
    }
    const storage = memoryStorage();
    await storage.setItem(KEY, record({ count: 3 }));
    expect(await new CommunityListFragmentStore(storage).load(PUBKEY)).toEqual({ events: [], count: 3, dropped: 0 });
  });

  it("save writes one versioned record of signed events and the advisory count under concord:list-fragments:<pubkey>", async () => {
    const storage = memoryStorage();
    const store = new CommunityListFragmentStore(storage);
    const one = await fragment(1, "cipher-one");
    const ten = await fragment(10, "cipher-ten");
    const zero = await fragment(0, "cipher-zero");
    // Handed over out of order: the record is sorted by d index ascending, so 10 follows 1 (not a string sort).
    await store.save(PUBKEY, { events: [ten, zero, one], count: 11 });
    const stored = JSON.parse((await storage.getItem(KEY))!);
    expect(stored.version).toBe(1);
    expect(stored.pubkey).toBe(PUBKEY);
    expect(stored.count).toBe(11);
    expect(stored.fragments).toEqual([zero, one, ten]);
    for (const event of stored.fragments as NostrEvent[]) {
      expect(typeof event.sig).toBe("string");
      expect(event.content.startsWith("cipher-")).toBe(true);
    }
    const loaded = await new CommunityListFragmentStore(storage).load(PUBKEY);
    expect(loaded.events).toEqual([zero, one, ten]);
    expect(loaded.count).toBe(11);
    expect(loaded.dropped).toBe(0);
  });

  it("a snapshot without a count keeps the last stored count", async () => {
    const storage = memoryStorage();
    const store = new CommunityListFragmentStore(storage);
    const zero = await fragment(0, "a");
    await store.save(PUBKEY, { events: [zero], count: 3 });
    await store.save(PUBKEY, { events: [zero, await fragment(1, "b")] });
    expect(JSON.parse((await storage.getItem(KEY))!).count).toBe(3);
    // A count loaded from a previous process is carried the same way.
    const next = new CommunityListFragmentStore(storage);
    await next.load(PUBKEY);
    await next.save(PUBKEY, { events: [zero] });
    expect(JSON.parse((await storage.getItem(KEY))!).count).toBe(3);
    // A fresh store with nothing known writes no count at all.
    const empty = memoryStorage();
    await new CommunityListFragmentStore(empty).save(PUBKEY, { events: [zero] });
    expect("count" in JSON.parse((await empty.getItem(KEY))!)).toBe(false);
  });

  it("an unchanged snapshot is not written again", async () => {
    const state = { failing: false };
    const { storage, writes } = flakyStorage(state);
    const store = new CommunityListFragmentStore(storage);
    const zero = await fragment(0, "a");
    await store.save(PUBKEY, { events: [zero], count: 1 });
    await store.save(PUBKEY, { events: [zero], count: 1 });
    await store.save(PUBKEY, { events: [zero] });
    expect(writes).toHaveLength(1);
    // A process that loaded the record writes nothing for the snapshot it just restored.
    const restarted = new CommunityListFragmentStore(storage);
    const loaded = await restarted.load(PUBKEY);
    await restarted.save(PUBKEY, { events: loaded.events, count: loaded.count });
    expect(writes).toHaveLength(1);
    await restarted.save(PUBKEY, { events: [zero, await fragment(1, "b")], count: 1 });
    expect(writes).toHaveLength(2);
  });

  it("a burst of saves writes at most twice and never lands an older snapshot after a newer one", async () => {
    const gate = new Gate<[key: string, value: string], void>();
    const inner = memoryStorage();
    const store = new CommunityListFragmentStore(gatedStorage(inner, { setItem: gate }));
    const events: NostrEvent[] = [];
    const saves: Promise<void>[] = [];
    for (let i = 0; i < 5; i++) {
      events.push(await fragment(i, `cipher-${i}`));
      saves.push(store.save(PUBKEY, { events: [...events] }));
    }
    const first = await gate.next();
    expect(JSON.parse(first.args[1]).fragments).toHaveLength(1); // the first save was already in flight
    first.release();
    const second = await gate.next();
    expect(JSON.parse(second.args[1]).fragments).toHaveLength(5); // the intermediate snapshots were superseded
    second.release();
    await Promise.all(saves);
    expect(gate.calls).toHaveLength(2);
    expect(JSON.parse((await inner.getItem(KEY))!).fragments).toEqual(events);
    // Every promise settled only once a record at least as new was stored; a late sixth save still lands last.
    const sixth = [...events, await fragment(5, "cipher-5")];
    const pending = store.save(PUBKEY, { events: sixth });
    (await gate.next()).release();
    await pending;
    expect(JSON.parse((await inner.getItem(KEY))!).fragments).toEqual(sixth);
  });

  it("a write that never settles fails its waiters after the bound, later waits at once, and release() rejects the rest (IN-02)", async () => {
    const gate = new Gate<[key: string, value: string], void>();
    const inner = memoryStorage();
    const clock = new ManualClock();
    const reported: FragmentPersistError[] = [];
    const store = new CommunityListFragmentStore(gatedStorage(inner, { setItem: gate }), {
      report: (error) => reported.push(error),
      schedule: (ms, run) => clock.schedule(ms, run),
    });
    const outcome = (save: Promise<void>) => save.then(() => "stored", (error: unknown) => error);
    const zero = await fragment(0, "a");
    let settled = false;
    const first = outcome(store.save(PUBKEY, { events: [zero] })).finally(() => (settled = true));
    const parked = await gate.next();
    clock.tick(COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS - 1);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(settled).toBe(false);
    clock.tick(1);
    expect(await first).toBeInstanceOf(FragmentPersistError);
    expect(reported).toHaveLength(1);
    // While that write is still parked, a later wait fails at once rather than waiting out the bound again.
    const one = await fragment(1, "b");
    expect(await outcome(store.save(PUBKEY, { events: [zero, one] }))).toBeInstanceOf(FragmentPersistError);
    expect(reported).toHaveLength(1);
    // The parked write lands, then the newest snapshot is still written after it.
    parked.release();
    (await gate.next()).release();
    for (let i = 0; i < 50 && JSON.parse((await inner.getItem(KEY)) ?? "{}").fragments?.length !== 2; i++) {
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
    expect(JSON.parse((await inner.getItem(KEY))!).fragments).toEqual([zero, one]);
    // release() (the client's stop) rejects a wait still pending, without reporting a storage failure.
    const pending = outcome(store.save(PUBKEY, { events: [zero, one, await fragment(2, "c")] }));
    const third = await gate.next();
    store.release();
    expect(await pending).toBeInstanceOf(FragmentPersistError);
    expect(reported).toHaveLength(1);
    third.release();
  });

  it("a failed write rejects with FragmentPersistError and reports once until a write succeeds", async () => {
    const state = { failing: true };
    const { storage, inner } = flakyStorage(state);
    const reported: FragmentPersistError[] = [];
    const store = new CommunityListFragmentStore(storage, { report: (error) => reported.push(error) });
    const zero = await fragment(0, "a");
    const failure = await store.save(PUBKEY, { events: [zero] }).then(() => undefined, (error) => error);
    expect(failure).toBeInstanceOf(FragmentPersistError);
    expect((failure as FragmentPersistError).cause).toEqual(new Error("quota exceeded"));
    expect(await inner.getItem(KEY)).toBeNull();
    // Consecutive failures report once.
    await expect(store.save(PUBKEY, { events: [zero], count: 2 })).rejects.toBeInstanceOf(FragmentPersistError);
    expect(reported).toHaveLength(1);
    // A later success re-arms the report, and the unchanged-snapshot shortcut does not hide an unstored record.
    state.failing = false;
    await store.save(PUBKEY, { events: [zero], count: 2 });
    expect(await inner.getItem(KEY)).not.toBeNull();
    state.failing = true;
    await expect(store.save(PUBKEY, { events: [zero, await fragment(1, "b")] })).rejects.toBeInstanceOf(
      FragmentPersistError,
    );
    expect(reported).toHaveLength(2);
    for (const error of reported) expect(error.message).not.toContain("cipher");
  });

  it("a record whose read failed is never overwritten until a later load reads it (WR-02)", async () => {
    const inner = memoryStorage();
    const zero = await fragment(0, "a");
    await inner.setItem(KEY, record({ fragments: [zero] }));
    const original = await inner.getItem(KEY);
    let failReads = true;
    let writes = 0;
    const storage: ConcordStorage = {
      getItem: (key) => failReads ? Promise.reject(new Error("database is locked")) : inner.getItem(key),
      setItem: (key, value) => (writes++, inner.setItem(key, value)),
      removeItem: (key) => inner.removeItem(key),
    };
    const reported: FragmentPersistError[] = [];
    const store = new CommunityListFragmentStore(storage, { report: (error) => reported.push(error) });
    await expect(store.load(PUBKEY)).rejects.toThrow("could not be read");
    const one = await fragment(1, "b");
    await expect(store.save(PUBKEY, { events: [one] })).rejects.toBeInstanceOf(FragmentPersistError);
    await expect(store.save(PUBKEY, { events: [one], count: 2 })).rejects.toBeInstanceOf(FragmentPersistError);
    expect(writes).toBe(0);
    expect(await inner.getItem(KEY)).toBe(original);
    expect(reported).toHaveLength(1);
    // IN-01: the refusal lasts until the next load, so it is told apart from a failed write and never retried.
    const refused = await store.save(PUBKEY, { events: [one], count: 3 }).catch((error: unknown) => error);
    expect((refused as Error).name).toBe("FragmentRecordUnreadableError");
    expect(reported[0].name).toBe("FragmentRecordUnreadableError");
    expect(retriesListSave(refused)).toBe(false);
    failReads = false;
    expect((await store.load(PUBKEY)).events).toEqual([zero]);
    await store.save(PUBKEY, { events: [zero, one] });
    expect(JSON.parse((await inner.getItem(KEY))!).fragments).toEqual([zero, one]);
  });

  it("an invalid record is still replaced by the next save (D-03)", async () => {
    const storage = memoryStorage();
    await storage.setItem(KEY, "{not json");
    const store = new CommunityListFragmentStore(storage);
    await expect(store.load(PUBKEY)).rejects.toThrow("invalid Community List fragment record");
    const zero = await fragment(0, "a");
    await store.save(PUBKEY, { events: [zero] });
    expect(JSON.parse((await storage.getItem(KEY))!).fragments).toEqual([zero]);
  });

  it("load keeps at most 4096 events and reports how many it dropped", async () => {
    expect(COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS).toBe(4_096);
    const storage = memoryStorage();
    const events = Array.from(
      { length: COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS + 2 },
      (_, i) => ({ kind: 33302, i }),
    );
    await storage.setItem(KEY, record({ fragments: [null, "text", [], ...events] }));
    const loaded = await new CommunityListFragmentStore(storage).load(PUBKEY);
    expect(loaded.events).toHaveLength(COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS);
    expect(loaded.dropped).toBe(3 + 2);
  });

  it("a persist failure is a retryable Community List save failure", () => {
    expect(retriesListSave(new FragmentPersistError(new Error("quota exceeded")))).toBe(true);
    expect(retriesListSave(new Error("encoding failure"))).toBe(false);
  });
});
