// Deferred-completion harness for client lifecycle tests (FND-05). Signer, storage and relay
// completions are parked on gates so a test releases them in any order, and `ManualClock`
// drives `DutyScope` timers without real or faked global time.

import { BehaviorSubject, EMPTY, NEVER, Observable, Subject, throwError } from "rxjs";
import type { PublishResponse, RelayPool } from "applesauce-relay";
import type { ISigner } from "applesauce-signers";
import { EventMemory, type IAsyncEventDatabase } from "applesauce-core";
import type { NostrEvent, Rumor } from "applesauce-core/helpers/event";
import type { Filter } from "applesauce-core/helpers/filter";
import type { ConcordStorage } from "../storage.ts";
import type { DutyClock } from "../lifecycle.ts";

/** A promise with its settle functions exposed. */
export interface Deferred<T> {
  /** Settles when `resolve` or `reject` is called. */
  promise: Promise<T>;
  /** Fulfils the promise. */
  resolve(value: T): void;
  /** Rejects the promise. */
  reject(error: unknown): void;
}

/** Creates a {@link Deferred} whose outcome the test decides. */
export function deferred<T = void>(): Deferred<T> {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

/** One call parked on a {@link Gate}. */
export interface GateCall<A extends unknown[]> {
  /** The arguments the wrapped function was called with. */
  readonly args: A;
  /** Runs the real implementation and settles the original caller with its outcome. */
  release(): void;
  /** Rejects the original caller with `error` without running the real implementation. */
  fail(error: unknown): void;
}

/** Parks calls to a wrapped async function until the test releases each one. */
export class Gate<A extends unknown[], R> {
  /** Every call that has entered the gate, in entry order. */
  readonly calls: GateCall<A>[] = [];
  private readonly unhanded: GateCall<A>[] = [];
  private readonly waiters: Array<(call: GateCall<A>) => void> = [];

  /** Wraps `inner`; calls for which `match` returns false pass straight through. */
  wrap(inner: (...args: A) => Promise<R>, match?: (...args: A) => boolean): (...args: A) => Promise<R> {
    return (...args: A): Promise<R> => {
      if (match && !match(...args)) return inner(...args);
      return new Promise<R>((resolve, reject) => {
        const call: GateCall<A> = {
          args,
          release: () => {
            try {
              inner(...args).then(resolve, reject);
            } catch (error) {
              reject(error);
            }
          },
          fail: (error) => reject(error),
        };
        this.calls.push(call);
        const waiter = this.waiters.shift();
        if (waiter) waiter(call);
        else this.unhanded.push(call);
      });
    };
  }

  /** Resolves with the oldest entered call not yet handed out, waiting for one if needed. */
  next(): Promise<GateCall<A>> {
    const call = this.unhanded.shift();
    if (call) return Promise.resolve(call);
    return new Promise<GateCall<A>>((resolve) => this.waiters.push(resolve));
  }
}

type SignEventArgs = Parameters<ISigner["signEvent"]>;
type SignEventResult = Awaited<ReturnType<ISigner["signEvent"]>>;
type CryptoArgs = [pubkey: string, text: string];

/** Gates for the signer calls a test wants to park. */
export interface SignerGates {
  /** Parks `signEvent`. */
  signEvent?: Gate<SignEventArgs, SignEventResult>;
  /** Parks `nip44.encrypt`. */
  encrypt?: Gate<CryptoArgs, string>;
  /** Parks `nip44.decrypt`. */
  decrypt?: Gate<CryptoArgs, string>;
  /** Parks `getPublicKey`, as a remote signer that stops answering does. */
  getPublicKey?: Gate<[], string>;
  /** Which `getPublicKey` calls park on {@link getPublicKey}; the rest pass through. Defaults to every call. */
  getPublicKeyWhen?: () => boolean;
}

/** Wraps `inner` so `signEvent`, `getPublicKey` and NIP-44 encrypt/decrypt park on the supplied gates. */
export function gatedSigner(inner: ISigner, gates: SignerGates): ISigner {
  const nip44 = inner.nip44
    ? {
      encrypt: gates.encrypt
        ? gates.encrypt.wrap((pubkey, text) => Promise.resolve(inner.nip44!.encrypt(pubkey, text)))
        : (pubkey: string, text: string) => Promise.resolve(inner.nip44!.encrypt(pubkey, text)),
      decrypt: gates.decrypt
        ? gates.decrypt.wrap((pubkey, text) => Promise.resolve(inner.nip44!.decrypt(pubkey, text)))
        : (pubkey: string, text: string) => Promise.resolve(inner.nip44!.decrypt(pubkey, text)),
    }
    : undefined;
  const signEvent = gates.signEvent
    ? gates.signEvent.wrap((draft) => Promise.resolve(inner.signEvent(draft)))
    : (draft: SignEventArgs[0]) => Promise.resolve(inner.signEvent(draft));
  const getPublicKey = gates.getPublicKey
    ? gates.getPublicKey.wrap(() => Promise.resolve(inner.getPublicKey()), gates.getPublicKeyWhen)
    : () => Promise.resolve(inner.getPublicKey());
  return {
    getPublicKey,
    signEvent,
    ...(inner.nip04 ? { nip04: inner.nip04 } : {}),
    ...(nip44 ? { nip44 } : {}),
  } as ISigner;
}

/** Gates for the storage calls a test wants to park. */
export interface StorageGates {
  /** Parks `getItem`. */
  getItem?: Gate<[key: string], string | null>;
  /** Parks `setItem`. */
  setItem?: Gate<[key: string, value: string], void>;
}

/** Wraps `inner` so `getItem` and `setItem` park on the supplied gates; `removeItem` passes through. */
export function gatedStorage(inner: ConcordStorage, gates: StorageGates): ConcordStorage {
  return {
    getItem: gates.getItem ? gates.getItem.wrap((key) => inner.getItem(key)) : (key) => inner.getItem(key),
    setItem: gates.setItem
      ? gates.setItem.wrap((key, value) => inner.setItem(key, value))
      : (key, value) => inner.setItem(key, value),
    removeItem: (key) => inner.removeItem(key),
  };
}

/** A hand-driven {@link DutyClock}: time only moves when the test calls {@link ManualClock.tick}. */
export class ManualClock implements DutyClock {
  private current: number;
  private readonly fixedRandom: number;
  private sequence = 0;
  private readonly entries = new Set<{ due: number; sequence: number; run: () => void }>();

  constructor(options: { now?: number; random?: number } = {}) {
    this.current = options.now ?? 0;
    this.fixedRandom = options.random ?? 0.5;
  }

  /** The current manual time in milliseconds. */
  now(): number {
    return this.current;
  }

  /** A fixed value in [0, 1). */
  random(): number {
    return this.fixedRandom;
  }

  /** Records `run` for `delayMs` from now and returns its cancel function. */
  schedule(delayMs: number, run: () => void): () => void {
    const entry = { due: this.current + Math.max(0, delayMs), sequence: this.sequence++, run };
    this.entries.add(entry);
    return () => void this.entries.delete(entry);
  }

  /** Advances time by `ms`, firing due callbacks in due then sequence order (including ones they schedule). */
  tick(ms: number): void {
    const target = this.current + ms;
    for (;;) {
      let earliest: { due: number; sequence: number; run: () => void } | undefined;
      for (const entry of this.entries) {
        if (entry.due > target) continue;
        if (
          !earliest || entry.due < earliest.due || (entry.due === earliest.due && entry.sequence < earliest.sequence)
        ) {
          earliest = entry;
        }
      }
      if (!earliest) break;
      this.entries.delete(earliest);
      this.current = Math.max(this.current, earliest.due);
      earliest.run();
    }
    this.current = target;
  }

  /** How many scheduled callbacks have neither fired nor been cancelled. */
  get pending(): number {
    return this.entries.size;
  }
}

/** Options for {@link fakeRelayPool}. */
export interface FakeRelayPoolOptions {
  /** Whether reads succeed; offline reads error. Defaults to true. */
  online?: boolean;
  /** Events served to matching requests. */
  events?: NostrEvent[];
  /** Mirrors RelayPool liveness: unhealthy relays are dropped from the cohort. */
  filterRelays?: (relays: string[]) => string[];
}

/** A relay-less RelayPool stand-in with controllable connectivity, reads and publish outcomes. */
export interface FakeRelayPool {
  /** The pool to hand to a client. */
  pool: RelayPool;
  /** Events accepted by `publish`, in call order. */
  published: NostrEvent[];
  /** Emits every recorded publish. */
  published$: Observable<NostrEvent>;
  /** Switches reads between succeeding and erroring. */
  setOnline(online: boolean): void;
  /** Replaces the events served to requests. */
  setEvents(events: NostrEvent[]): void;
  /** Overrides how requests are answered; omit to restore default serving. */
  setRequest(handler?: (filters: Filter[]) => Observable<NostrEvent>): void;
  /** Overrides publish outcomes; an Error rejects, an array resolves unrecorded, undefined falls through. */
  setPublishOutcome(handler?: (event: NostrEvent) => PublishResponse[] | Error | undefined): void;
}

/** Creates a {@link FakeRelayPool}. */
export function fakeRelayPool(options: FakeRelayPoolOptions = {}): FakeRelayPool {
  let online = options.online ?? true;
  let events = options.events ?? [];
  let requestHandler: ((filters: Filter[]) => Observable<NostrEvent>) | undefined;
  let outcomeHandler: ((event: NostrEvent) => PublishResponse[] | Error | undefined) | undefined;
  const published: NostrEvent[] = [];
  const published$ = new Subject<NostrEvent>();
  const request = (filters: Filter | Filter[]): Observable<NostrEvent> => {
    if (!online) return throwError(() => new Error("offline"));
    const fs = Array.isArray(filters) ? filters : [filters];
    if (requestHandler) return requestHandler(fs);
    return new Observable<NostrEvent>((subscriber) => {
      for (const event of events) {
        const matches = fs.some((f) =>
          (!f.authors || f.authors.includes(event.pubkey)) &&
          (!f.kinds || f.kinds.includes(event.kind)) &&
          (f.since === undefined || event.created_at >= f.since) &&
          (f.until === undefined || event.created_at <= f.until) &&
          (!f["#d"] || event.tags.some((t) => t[0] === "d" && f["#d"]!.includes(t[1])))
        );
        if (matches) subscriber.next(event);
      }
      subscriber.complete();
    });
  };
  const relay = {
    url: "wss://fake",
    challenge: null,
    challenge$: new BehaviorSubject<string | null>(null),
    isAuthenticated: () => true,
    authenticate: async () => ({ ok: true, from: "wss://fake" }),
    getSupported: async () => null,
    request,
    sync: () => EMPTY,
  };
  const pool = {
    status$: new Subject(),
    relay: () => relay,
    subscription: () => NEVER,
    // RelayPool.group silently drops liveness-unhealthy relays and completes with no events.
    request: (relays: string[], filters: Filter | Filter[]) =>
      options.filterRelays && options.filterRelays(relays).length === 0 ? EMPTY : request(filters),
    publish: async (_relays: string[], event: NostrEvent): Promise<PublishResponse[]> => {
      const outcome = outcomeHandler?.(event);
      if (outcome instanceof Error) throw outcome;
      if (outcome !== undefined) return outcome;
      published.push(event);
      published$.next(event);
      return [{ ok: true, from: "wss://fake" }];
    },
  } as unknown as RelayPool;
  if (options.filterRelays) (pool as unknown as { filterRelays: unknown }).filterRelays = options.filterRelays;
  return {
    pool,
    published,
    published$,
    setOnline(value) {
      online = value;
    },
    setEvents(value) {
      events = value;
    },
    setRequest(handler) {
      requestHandler = handler;
    },
    setPublishOutcome(handler) {
      outcomeHandler = handler;
    },
  };
}

/** An async persistent-store stand-in: the upstream database interface over an {@link EventMemory}. */
export type AsyncMemoryDatabase = IAsyncEventDatabase<Rumor> & {
  /** The backing memory. Rows added here bypass the store, as rows persisted in an earlier session do. */
  readonly mem: EventMemory<Rumor>;
};

/**
 * An `IAsyncEventDatabase<Rumor>` over an {@link EventMemory}, standing in for a host's persistent database. Seed an
 * "earlier session" row with `db.mem.add(rumor)`; an `AsyncRumorStore` built over it serves that row on any read.
 */
export function asyncMemoryDatabase(mem: EventMemory<Rumor> = new EventMemory<Rumor>()): AsyncMemoryDatabase {
  return {
    mem,
    add: (event) => Promise.resolve(mem.add(event)),
    remove: (event) => Promise.resolve(mem.remove(event)),
    removeByFilters: (filters) => {
      const matches = mem.getByFilters(filters);
      for (const event of matches) mem.remove(event);
      return Promise.resolve(matches.length);
    },
    hasEvent: (id) => Promise.resolve(mem.hasEvent(id)),
    getEvent: (id) => Promise.resolve(mem.getEvent(id)),
    hasReplaceable: (kind, pubkey, identifier) => Promise.resolve(mem.hasReplaceable(kind, pubkey, identifier)),
    getReplaceable: (kind, pubkey, identifier) => Promise.resolve(mem.getReplaceable(kind, pubkey, identifier)),
    getReplaceableHistory: (kind, pubkey, identifier) =>
      Promise.resolve(mem.getReplaceableHistory(kind, pubkey, identifier)),
    getByFilters: (filters) => Promise.resolve(mem.getByFilters(filters)),
    getTimeline: (filters) => Promise.resolve(mem.getTimeline(filters)),
  };
}
