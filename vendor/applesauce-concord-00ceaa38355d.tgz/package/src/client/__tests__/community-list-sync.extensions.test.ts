import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { ConcordCommunityListSync } from "../community-list-sync.ts";
import { CommunityListFragments } from "../community-list-fragments.ts";
import { type CommunityListFragment, decodeCommunityListFragment } from "../../helpers/community-list-wire.ts";
import { canonicalJson, type ParsedCommunityList } from "../../helpers/community-list.ts";
import type { CommunityListCommunity } from "../../types.ts";
import type { ConcordDiagnostic } from "../diagnostics.ts";
import { signFragment } from "./community-list-prefix.ts";

function entry(index: number): CommunityListCommunity {
  const id = index.toString(16).padStart(64, "0");
  const material = {
    community_id: id,
    owner: "11".repeat(32),
    owner_salt: "22".repeat(32),
    community_root: "33".repeat(32),
    root_epoch: 0,
    channels: [],
    relays: [],
    name: "room",
  };
  return { community_id: id, current: material, seed: material, added_at: 1 };
}

const A = entry(1);
const B = entry(2);

function doc(frags: number, entries: CommunityListCommunity[], extras: Record<string, unknown> = {}) {
  return { frags, entries, tombstones: [], ...extras } as CommunityListFragment;
}

/** The change a leave makes: a tombstone in the fragment that holds the membership. */
function leave(id: string, extras: Record<string, unknown> = {}): ParsedCommunityList {
  return { entries: [], tombstones: [{ community_id: id, removed_at: 5 }], ...extras };
}

async function fixture(options: { publish?: (event: NostrEvent) => Promise<void> } = {}) {
  const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
  const events: NostrEvent[] = [];
  const diagnostics: ConcordDiagnostic[] = [];
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    await options.publish?.(event);
    events.push(event);
  }, { onDiagnostic: (diagnostic) => diagnostics.push(diagnostic) });
  const hold = async (index: number, document: CommunityListFragment, created_at = 1) =>
    await sync.receive(await signFragment(signer, index, document, created_at));
  const open = async (event: NostrEvent): Promise<CommunityListFragment> =>
    decodeCommunityListFragment(await signer.nip44!.decrypt(await signer.getPublicKey(), event.content));
  const dTag = (event: NostrEvent): string => event.tags.find((tag) => tag[0] === "d")![1];
  return { signer, events, diagnostics, sync, hold, open, dTag };
}

describe("fragment-level extension placement (LIST-06)", () => {
  it("a scoped write to fragment 1 drops fragment-level fields that fragment 0 already carries (D-09)", async () => {
    const { sync, events, hold, open, dTag } = await fixture();
    await hold(0, doc(2, [A], { foreign: { a: 0 } }));
    await hold(1, doc(2, [B], { foreign: { a: 1 } }));
    await sync.write(leave(B.community_id), [B.community_id]);
    expect(events).toHaveLength(1);
    expect(dTag(events[0])).toBe("1");
    expect("foreign" in await open(events[0])).toBe(false);
    expect(sync.fragments.document.foreign).toEqual({ a: 0 });
  });

  it("a scoped write to fragment 1 writes fragment 0 first with stranded fields, then fragment 1 without them (D-18)", async () => {
    const { sync, events, hold, open, dTag } = await fixture();
    await hold(0, doc(2, [A], { zero: "z" }));
    await hold(1, doc(2, [B], { foreign: { a: 1 } }));
    await sync.write(leave(B.community_id), [B.community_id]);
    expect(events.map(dTag)).toEqual(["0", "1"]);
    const zero = await open(events[0]);
    expect(zero.foreign).toEqual({ a: 1 });
    expect(zero.zero).toBe("z");
    expect(zero.entries.map((e) => e.community_id)).toEqual([A.community_id]);
    expect("foreign" in await open(events[1])).toBe(false);
    expect(sync.fragments.document.foreign).toEqual({ a: 1 });
    expect(sync.fragments.document.zero).toBe("z");
  });

  it("a scoped write to fragment 1 keeps its fields and reports fragment-extension-retained when fragment 0 is not held (D-18)", async () => {
    const { sync, events, diagnostics, hold, open, dTag } = await fixture();
    await hold(1, doc(2, [B], { foreign: { a: 1 } }));
    await sync.write(leave(B.community_id), [B.community_id]);
    expect(events.map(dTag)).toEqual(["1"]);
    expect((await open(events[0])).foreign).toEqual({ a: 1 });
    const retained = diagnostics.filter((d) => d.stage === "fragment-extension-retained");
    expect(retained).toHaveLength(1);
    expect(retained[0].key).toBe("1");
    // Field names and values are decrypted content: the diagnostic never carries them.
    expect(String((retained[0].error as Error).message)).not.toContain("foreign");
  });

  it("the retention is reported once per fragment, and a throwing diagnostic callback never stops the write (IN-01)", async () => {
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const events: NostrEvent[] = [];
    let reports = 0;
    const sync = new ConcordCommunityListSync(signer, async (event) => void events.push(event), {
      onDiagnostic: (diagnostic) => {
        if (diagnostic.stage !== "fragment-extension-retained") return;
        reports++;
        throw new Error("consumer bug");
      },
    });
    await sync.receive(await signFragment(signer, 1, doc(2, [A, B], { foreign: { a: 1 } }), 1));
    await sync.write(leave(B.community_id), [B.community_id]);
    await sync.write(leave(A.community_id), [A.community_id]);
    expect(events).toHaveLength(2);
    expect(reports).toBe(1);
  });

  it("a scoped write never adds the writer's own list-level fields to a fragment above zero (D-09)", async () => {
    const { sync, events, hold, open, dTag } = await fixture();
    await hold(0, doc(2, [A]));
    await hold(1, doc(2, [B]));
    await sync.write(leave(B.community_id, { mine: "local" }), [B.community_id]);
    expect(events.map(dTag)).toEqual(["1"]);
    expect("mine" in await open(events[0])).toBe(false);
  });

  it("fragment-level fields union lowest index wins onto fragment 0 (D-10)", async () => {
    const { sync, events, hold, open, dTag } = await fixture();
    await hold(0, doc(3, [A], { x: 0 }));
    await hold(1, doc(3, [B], { x: 1, y: 1 }));
    await hold(2, doc(3, [], { y: 2, z: 2 }));
    await sync.write(leave(A.community_id), [A.community_id]);
    expect(events.map(dTag)).toEqual(["0"]);
    const zero = await open(events[0]);
    expect([zero.x, zero.y, zero.z]).toEqual([0, 1, 2]);
  });

  it("a write interrupted after fragment 0 still holds every stranded field (D-18)", async () => {
    let calls = 0;
    const { sync, events, hold, dTag } = await fixture({
      publish: async () => {
        if (++calls === 2) throw new Error("relay refused");
      },
    });
    await hold(0, doc(2, [A], { zero: "z" }));
    await hold(1, doc(2, [B], { foreign: { a: 1 } }));
    await expect(sync.write(leave(B.community_id), [B.community_id])).rejects.toThrow("relay refused");
    expect(events.map(dTag)).toEqual(["0"]);
    expect(sync.fragments.get(0)!.document.foreign).toEqual({ a: 1 });
    expect(sync.fragments.document.foreign).toEqual({ a: 1 });
  });

  it("strandedExtensionKeys names the list-level fields that only fragment 0 may carry", () => {
    const fragments = new CommunityListFragments();
    fragments.receive({ index: 1, created_at: 1, id: "b", document: doc(2, [B], { foreign: 1, other: 2 }) });
    expect(fragments.strandedExtensionKeys(1)).toEqual(["foreign", "other"]); // fragment 0 is not held
    expect(fragments.strandedExtensionKeys(0)).toEqual([]);
    expect(fragments.strandedExtensionKeys(7)).toEqual([]);
    fragments.receive({ index: 0, created_at: 1, id: "a", document: doc(2, [A], { other: 0 }) });
    expect(fragments.strandedExtensionKeys(1)).toEqual(["foreign"]);
    expect(fragments.strandedExtensionKeys(0)).toEqual([]);
  });
});

/** Opaque values at every level: nothing here is a documented wire field, so every one must ride through untouched. */
function foreign(index: number): CommunityListCommunity {
  const base = entry(index);
  const channel = {
    id: index.toString(16).padStart(64, "a"),
    key: "44".repeat(32),
    epoch: 0,
    name: "general",
    channel_future: { n: [1, { deep: null }], s: "c" },
  };
  const current = { ...base.current, channels: [channel], snapshot_future: { deep: [true, "s", 7] } };
  return { ...base, current, seed: current, entry_future: { nested: [1, 2, { three: "3" }], flag: false } };
}

/** d0 holds two memberships, a tombstone and a list field; d1 holds one membership and another list field. */
function vault(): { zero: CommunityListFragment; one: CommunityListFragment } {
  const tombstone = { community_id: entry(9).community_id, removed_at: 5, tombstone_future: { when: "later" } };
  return {
    zero: {
      frags: 2,
      entries: [foreign(1), foreign(2)],
      tombstones: [tombstone],
      x_frag: { from: "zero", list: [1, 2] },
    } as CommunityListFragment,
    one: { frags: 2, entries: [foreign(3)], tombstones: [], y_frag: { from: "one" } } as CommunityListFragment,
  };
}

/** Canonical JSON of every membership and tombstone held, keyed by community id. */
function records(list: ParsedCommunityList): Map<string, string> {
  return new Map([
    ...list.entries.map((e): [string, string] => [`entry ${e.community_id}`, canonicalJson(e)]),
    ...list.tombstones.map((t): [string, string] => [`tombstone ${t.community_id}`, canonicalJson(t)]),
  ]);
}

describe("unknown fields survive every write (LIST-06, D-11)", () => {
  it("a scoped write keeps every entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11)", async () => {
    const { sync, hold, open, events, dTag } = await fixture();
    const { zero, one } = vault();
    await hold(0, zero);
    await hold(1, one);
    const before = records(sync.fragments.document);
    // Leaving an unrelated membership rewrites fragment 0 around the kept records.
    await sync.write(leave(entry(2).community_id), [entry(2).community_id]);
    // Touching the membership on fragment 1 moves its stranded list field onto fragment 0.
    await sync.write({ entries: [foreign(3)], tombstones: [] }, [entry(3).community_id]);
    expect(events.map(dTag)).toContain("1");
    const after = records(sync.fragments.document);
    for (const key of [`entry ${entry(1).community_id}`, `entry ${entry(3).community_id}`]) {
      expect(after.get(key)).toBe(before.get(key));
    }
    const tombstone = `tombstone ${entry(9).community_id}`;
    expect(after.get(tombstone)).toBe(before.get(tombstone));
    expect(sync.fragments.document.x_frag).toEqual(zero.x_frag);
    expect(sync.fragments.document.y_frag).toEqual(one.y_frag);
    expect(sync.fragments.get(0)!.document.y_frag).toEqual(one.y_frag);
    expect("y_frag" in await open(events.filter((event) => dTag(event) === "1").at(-1)!)).toBe(false);
    // The retained entry still carries the nested values as written, not merely an equal-looking copy.
    const kept = sync.fragments.document.entries.find((e) => e.community_id === entry(1).community_id)!;
    expect(kept.entry_future).toEqual(foreign(1).entry_future);
    expect((kept.current.channels[0] as unknown as Record<string, unknown>).channel_future).toEqual({
      n: [1, { deep: null }],
      s: "c",
    });
    expect((kept.current as unknown as Record<string, unknown>).snapshot_future).toEqual({ deep: [true, "s", 7] });
  });

  it("a repack keeps every fragment, entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11, D-12)", async () => {
    const { sync, hold } = await fixture();
    const { zero, one } = vault();
    await hold(0, zero);
    await hold(1, one);
    const before = records(sync.fragments.document);
    expect(before.size).toBe(4);
    await sync.repack({ entries: [], tombstones: [] });
    expect(records(sync.fragments.document)).toEqual(before);
    expect(sync.fragments.document.x_frag).toEqual(zero.x_frag);
    expect(sync.fragments.document.y_frag).toEqual(one.y_frag);
    // List-level fields live on fragment 0 only.
    const { y_frag: _y, x_frag: _x, ...rest } = sync.fragments.get(0)!.document as Record<string, unknown>;
    expect(Object.keys(rest).sort()).toEqual(["entries", "frags", "tombstones"]);
    expect(sync.fragments.get(0)!.document.y_frag).toEqual(one.y_frag);
    for (const index of sync.fragments.indexes.filter((i) => i > 0)) {
      expect(Object.keys(sync.fragments.get(index)!.document).sort()).toEqual(["entries", "frags", "tombstones"]);
    }
  });
});
