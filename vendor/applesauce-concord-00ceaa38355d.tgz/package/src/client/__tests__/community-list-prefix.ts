// Test helper (not a test file): drive a Community List repack and restart a sync from any acknowledged prefix.
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { ISigner } from "applesauce-signers";
import { ConcordCommunityListSync, type ConcordCommunityListSyncOptions } from "../community-list-sync.ts";
import { type CommunityListFragment, encodeCommunityListFragment } from "../../helpers/community-list-wire.ts";
import type { ParsedCommunityList } from "../../helpers/community-list.ts";
import type { CommunityListCommunity } from "../../types.ts";

/** The community that only a tombstone mentions in {@link cyclicVault}. */
export const TOMBSTONED_COMMUNITY: string = "ff".repeat(32);

/** One membership with its own id and key material, carrying about 8 KB of unknown entry data. */
export function vaultEntry(index: number): CommunityListCommunity & { future: string } {
  const id = index.toString(16).padStart(64, "0");
  const material = {
    community_id: id,
    owner: "11".repeat(32),
    owner_salt: "22".repeat(32),
    community_root: index.toString(16).padStart(2, "0").repeat(32),
    root_epoch: 0,
    channels: [],
    relays: [],
    name: `room ${index}`,
  };
  return { community_id: id, current: material, seed: material, added_at: 1, future: "x".repeat(8000) };
}

/** NIP-01 winners per `d` index: the newer `created_at`, then the lower id. Ordered by index. */
export function winners(events: readonly NostrEvent[]): NostrEvent[] {
  const best = new Map<number, NostrEvent>();
  for (const event of events) {
    const index = Number(event.tags.find((tag) => tag[0] === "d")?.[1]);
    const held = best.get(index);
    if (
      !held || event.created_at > held.created_at || (event.created_at === held.created_at && event.id < held.id)
    ) best.set(index, event);
  }
  return [...best].sort(([a], [b]) => a - b).map(([, event]) => event);
}

/** Sign a fragment document as the list owner, like another device would. */
export async function signFragment(
  signer: ISigner,
  index: number,
  document: CommunityListFragment,
  created_at: number,
): Promise<NostrEvent> {
  return await signer.signEvent({
    kind: 33302,
    created_at,
    tags: [["d", String(index)]],
    content: await signer.nip44!.encrypt(await signer.getPublicKey(), encodeCommunityListFragment(document)),
  });
}

/**
 * Two fragments (frags 2) holding eight memberships, the first dated 100 seconds ahead so a repack must outrank it:
 * `d0` holds entries 0, 2, 4, 6 and `d1` holds 1, 3, 5, 7 plus a tombstone for {@link TOMBSTONED_COMMUNITY}, so a
 * repack that regroups them moves records between two existing nonempty fragments.
 */
export async function cyclicVault(
  signer: ISigner,
): Promise<{ old: NostrEvent[]; all: CommunityListCommunity[]; tombstoned: string }> {
  const all = Array.from({ length: 8 }, (_, i) => vaultEntry(i + 1));
  const tombstone = { community_id: TOMBSTONED_COMMUNITY, removed_at: 5 };
  const old = [
    await signFragment(
      signer,
      0,
      { frags: 2, entries: all.filter((_, i) => i % 2 === 0), tombstones: [] },
      Math.floor(Date.now() / 1000) + 100,
    ),
    await signFragment(
      signer,
      1,
      { frags: 2, entries: all.filter((_, i) => i % 2 === 1), tombstones: [tombstone] },
      Math.floor(Date.now() / 1000),
    ),
  ];
  return { old, all, tombstoned: TOMBSTONED_COMMUNITY };
}

/** Every event an uninterrupted repack of `old` publishes, in order (a standalone sync, no completed-read gate). */
export async function recordRepack(
  signer: ISigner,
  old: readonly NostrEvent[],
  local: ParsedCommunityList = { entries: [], tombstones: [] },
): Promise<NostrEvent[]> {
  const published: NostrEvent[] = [];
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    published.push(event);
  });
  for (const event of old) await sync.receive(event);
  await sync.repack(local);
  return published;
}

/**
 * A sync started after a restart: the `restored` record first (locked), then a completed relay read of `relay`, then
 * every held fragment decrypted. The relay may be ahead of the record.
 */
export async function restartedSync(
  signer: ISigner,
  relay: readonly NostrEvent[],
  restored: readonly NostrEvent[] = [],
  options: Pick<ConcordCommunityListSyncOptions, "persist"> & { publish?: (event: NostrEvent) => Promise<void> } = {},
): Promise<ConcordCommunityListSync> {
  const sync = new ConcordCommunityListSync(signer, options.publish ?? (async () => {}), {
    requireCompletedRead: true,
    persist: options.persist,
  });
  if (restored.length) await sync.restore(restored);
  const token = sync.beginRead();
  for (const event of relay) await sync.receive(event, false);
  sync.markReadComplete(token);
  for (const event of winners([...restored, ...relay])) await sync.receive(event);
  return sync;
}
