// Bounded witness upkeep (CORD-04 §7 Interaction with deletion; Phase 2 D-07..D-09). The maintainer runs on a fake
// host with a ManualClock-driven DutyScope over a real DiagnosticsSink, so every delay, retry and stop condition is
// exercised without a relay or real time.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { BehaviorSubject, Subject } from "rxjs";
import { PrivateKeySigner } from "applesauce-signers";
import type { Debugger } from "applesauce-core";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";

import { sealRumor } from "../../operations/gift-wrap.ts";
import type { CommunityState, ConcordSyncPhase } from "../../types.ts";
import { createPinProof, encodePinList, type PinEntry, verifyPinEntry } from "../../helpers/pins.ts";
import { type ConcordDiagnostic, DiagnosticsSink } from "../diagnostics.ts";
import { DutyScope } from "../lifecycle.ts";
import { PinMaintainer, type PinMaintainerHost, type PinMaintainerOptions } from "../pin-maintainer.ts";
import { RequiredPublishError } from "../revocation.ts";
import { type Deferred, deferred, ManualClock } from "./test-utils.ts";

const CHANNEL = "ab".repeat(32);
const CONV_KEY = new Uint8Array(32).fill(2);
const NOW_MS = 1_700_000_000_000;

const selfSigner = new PrivateKeySigner(new Uint8Array(32).fill(1));
const otherSigner = new PrivateKeySigner(new Uint8Array(32).fill(3));
const SELF = await selfSigner.getPublicKey();

interface Pinned {
  rumor: Rumor;
  entry: PinEntry;
}

/** A proven pinned message from `signer`, optionally with extra rumor tags such as an expiration. */
async function pinned(
  content: string,
  signer: PrivateKeySigner = otherSigner,
  tags: string[][] = [],
): Promise<Pinned> {
  const rumor = {
    pubkey: await signer.getPublicKey(),
    id: "",
    kind: 9,
    content,
    tags: [["channel", CHANNEL], ["epoch", "0"], ...tags],
    created_at: 10,
  };
  rumor.id = getEventHash(rumor);
  return { rumor, entry: createPinProof(await sealRumor(CONV_KEY, signer)(rumor), CONV_KEY) as PinEntry };
}

const CHANNEL_PLANE = { type: "channel", channelId: CHANNEL, convKey: CONV_KEY, epoch: 0 } as const;

/** A signed Edit of `target` at `ms` milliseconds after second 1000 and its seal, as the route funnel would see it. */
async function editOf(target: Rumor, signer: PrivateKeySigner, text: string, ms: number, tags: string[][] = []) {
  const rumor = {
    pubkey: await signer.getPublicKey(),
    id: "",
    kind: 3302,
    content: text,
    tags: [["e", target.id], ["channel", CHANNEL], ["epoch", "0"], ["ms", String(ms % 1000)], ...tags],
    created_at: 1000 + Math.floor(ms / 1000),
  };
  rumor.id = getEventHash(rumor);
  const seal = await sealRumor(CONV_KEY, signer)(rumor);
  const decoded = { rumor, author: rumor.pubkey, wrapId: "ee".repeat(32), sealKind: seal.kind, ms, seal };
  return { rumor, seal, decoded };
}

/** A kind-5 deletion of `target` signed by its own author. */
function deletionOf(target: Rumor): Rumor {
  const base = { pubkey: target.pubkey, id: "", kind: 5, content: "", tags: [["e", target.id]], created_at: 20 };
  return { ...base, id: getEventHash(base) };
}

interface PublishCall {
  channelId: string;
  content: string;
  expectedHead: string;
  stage: string;
}

interface HarnessOptions extends PinMaintainerOptions {
  random?: number;
  channelPrivate?: boolean;
  /** The head's stored content; defaults to the plaintext list of the current entries. */
  headContent?: string;
  sealKey?: { epoch: number; convKey: Uint8Array };
  /** Start with no maintainer so the test can arrange state first. */
  autoStart?: boolean;
}

/** A fake host with mutable head, entries and authority, and a recording publish that honors its check. */
function harness(initial: Pinned[], options: HarnessOptions = {}) {
  const clock = new ManualClock({ now: NOW_MS, random: options.random ?? 0 });
  const diagnostics: ConcordDiagnostic[] = [];
  const log = Object.assign(() => {}, { extend: () => log }) as unknown as Debugger;
  const sink = new DiagnosticsSink(log, (diagnostic) => diagnostics.push(diagnostic));
  const scope = new DutyScope({ clock, report: (report) => sink.reportDuty(report) });

  const channels = { live: true };
  const live = {
    entries: initial.map((pin) => pin.entry),
    head: "h1" as string | undefined,
    canWrite: true,
    phase: "live" as ConcordSyncPhase,
    /** Whether the head's list opens with the keys held. */
    readable: true,
    /** Fingerprint of every key epoch held for the channel. */
    keyEpochs: "0",
    bans: new Set<string>(),
  };
  const state$ = new BehaviorSubject<CommunityState>(stateOf(channels.live, options.channelPrivate === true));
  const phase$ = new BehaviorSubject<ConcordSyncPhase>("live");
  const materialChanged$ = new Subject<void>();
  const inputs$ = new BehaviorSubject<Rumor[]>([]);
  const calls: PublishCall[] = [];
  const control: {
    hold?: Deferred<void>;
    entered?: Deferred<void>;
    failWith?: () => Error;
  } = {};

  function stateOf(present: boolean, isPrivate: boolean): CommunityState {
    return {
      channels: present ? [{ channel_id: CHANNEL, private: isPrivate }] : [],
      banlist: new Set(live.bans),
    } as unknown as CommunityState;
  }

  const host: PinMaintainerHost = {
    duties: () => scope,
    diagnostics: sink,
    self: SELF,
    state: () => state$.value,
    state$,
    phase: () => live.phase,
    phase$,
    materialChanged$,
    canWrite: () => live.canWrite,
    pinList: () =>
      live.head === undefined || !live.readable ? { available: false } : { available: true, entries: live.entries },
    // A real Control Plane keeps serving a deleted channel's head and list, so the fake serves them regardless.
    headHash: () => live.head,
    headContent: () => options.headContent ?? JSON.stringify({ entries: live.entries }),
    channelInputs: () => inputs$,
    verify: (entry, channelId) => verifyPinEntry(entry, channelId),
    privateChannelKey: () => options.sealKey,
    channelKeyEpochs: () => live.keyEpochs,
    publishPinList: async (channelId, content, expectedHead, stage, check) => {
      control.entered?.resolve();
      if (control.hold) await control.hold.promise;
      if (control.failWith) throw control.failWith();
      check();
      calls.push({ channelId, content, expectedHead, stage });
    },
  };

  let maintainer: PinMaintainer | undefined;
  const start = () => (maintainer = new PinMaintainer(host, options));
  if (options.autoStart !== false) start();

  return {
    clock,
    scope,
    diagnostics,
    calls,
    control,
    live,
    state$,
    phase$,
    materialChanged$,
    inputs$,
    host,
    get maintainer(): PinMaintainer {
      return maintainer ?? start();
    },
    /** Publish a deletion into the channel inputs, as the store would after receiving a kind 5. */
    delete(...targets: Pinned[]): void {
      inputs$.next([...inputs$.value, ...targets.map((target) => deletionOf(target.rumor))]);
    },
    /** The folded state changes (a new head, a channel removed) and the engine re-evaluates duties. */
    setChannelPresent(present: boolean): void {
      channels.live = present;
      state$.next(stateOf(present, options.channelPrivate === true));
      scope.reevaluate();
    },
    /** The community ban list changes and the fold emits a new state. */
    setBans(pubkeys: string[]): void {
      live.bans = new Set(pubkeys);
      state$.next(stateOf(channels.live, options.channelPrivate === true));
    },
    /** The sync phase leaves live and returns, which makes the maintainer re-derive its whole watched set. */
    cyclePhase(): void {
      live.phase = "syncing";
      phase$.next("syncing");
      live.phase = "live";
      phase$.next("live");
    },
    moveHead(head: string, entries: PinEntry[]): void {
      live.head = head;
      live.entries = entries;
      state$.next(state$.value);
      scope.reevaluate();
    },
    async tick(ms: number): Promise<void> {
      clock.tick(ms);
      await scope.idle();
    },
    dispose(): void {
      maintainer?.dispose();
      scope.dispose();
    },
  };
}

describe("PinMaintainer upkeep", () => {
  it("the pinner acts immediately and a witness waits within the bounded window", async () => {
    const mine = await pinned("mine", selfSigner);
    const keep = await pinned("keep");
    const own = harness([mine, keep]);
    try {
      own.delete(mine);
      await own.tick(0);
      expect(own.calls).toHaveLength(1);
      expect(own.calls[0].stage).toBe("pin-omission");
      expect(own.calls[0].expectedHead).toBe("h1");
      expect(JSON.parse(own.calls[0].content).entries).toEqual([keep.entry]);
    } finally {
      own.dispose();
    }

    // A witness at the lower and upper ends of the drawn window.
    for (const [random, lowest] of [[0, 5_000], [0.9999, 29_997]] as const) {
      const theirs = await pinned("theirs");
      const witness = harness([theirs, keep], { random });
      try {
        witness.delete(theirs);
        await witness.tick(0);
        expect(witness.calls).toHaveLength(0);
        expect(witness.scope.pending).toBe(1);
        await witness.tick(lowest - 1);
        expect(witness.calls).toHaveLength(0);
        await witness.tick(1);
        expect(witness.calls).toHaveLength(1);
        expect(witness.calls[0].expectedHead).toBe("h1");
      } finally {
        witness.dispose();
      }
    }
  });

  it("a pin this client recorded through setPins is upkept immediately (A4)", async () => {
    const recorded = await pinned("recorded");
    const keep = await pinned("keep");
    const h = harness([recorded, keep]);
    try {
      h.maintainer.notePinned(CHANNEL, [recorded.rumor.id], new Set([recorded.rumor.id]));
      h.delete(recorded);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
    } finally {
      h.dispose();
    }

    // Without the record the same pin belongs to someone else's duty and waits.
    const unrecorded = harness([recorded, keep]);
    try {
      unrecorded.delete(recorded);
      await unrecorded.tick(0);
      expect(unrecorded.calls).toHaveLength(0);
      await unrecorded.tick(5_000);
      expect(unrecorded.calls).toHaveLength(1);
    } finally {
      unrecorded.dispose();
    }
  });

  it("the own-pin record is bounded per channel and in channel count", async () => {
    const h = harness([], { autoStart: false });
    try {
      const maintainer = h.maintainer;
      const ids = Array.from({ length: 40 }, (_, i) => i.toString(16).padStart(64, "0"));
      maintainer.notePinned(CHANNEL, ids, new Set(ids));
      expect(maintainer.pinnedCount(CHANNEL)).toBe(25);
      // Earlier ids no longer in the published list are dropped; those still listed are kept (WR-03).
      maintainer.notePinned(CHANNEL, ids.slice(0, 2), new Set(ids.slice(0, 2)));
      expect(maintainer.pinnedCount(CHANNEL)).toBe(2);
      maintainer.notePinned(CHANNEL, [], new Set(ids.slice(1, 2)));
      expect(maintainer.pinnedCount(CHANNEL)).toBe(1);
      for (let i = 0; i < 300; i++) {
        maintainer.notePinned(i.toString(16).padStart(64, "0"), ids.slice(0, 1), new Set(ids.slice(0, 1)));
      }
      expect(maintainer.pinnedChannelCount()).toBe(256);
      // The oldest channel was dropped first.
      expect(maintainer.pinnedCount(CHANNEL)).toBe(0);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: make notePinned replace the channel's record instead of merging it. The second call then forgets
  // `first`, its deletion waits the witness delay, and the immediate-publication assertion fails.
  it("a later record keeps this client's earlier pins that are still listed (WR-03)", async () => {
    const first = await pinned("first");
    const second = await pinned("second");
    const h = harness([first, second]);
    try {
      h.maintainer.notePinned(CHANNEL, [first.rumor.id], new Set([first.rumor.id]));
      h.maintainer.notePinned(CHANNEL, [second.rumor.id], new Set([first.rumor.id, second.rumor.id]));
      expect(h.maintainer.pinnedCount(CHANNEL)).toBe(2);
      h.delete(first);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].stage).toBe("pin-omission");
    } finally {
      h.dispose();
    }
  });

  it("a witness skips publishing when the head was already healed", async () => {
    const doomed = await pinned("doomed");
    const keep = await pinned("keep");
    const h = harness([doomed, keep]);
    try {
      h.delete(doomed);
      await h.tick(1_000);
      expect(h.scope.pending).toBe(1);
      // Another holder healed the list: a new head without the deleted entry.
      h.moveHead("h2", [keep.entry]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
      expect(h.scope.pending).toBe(0);
    } finally {
      h.dispose();
    }
  });

  it("one head publishes at most once", async () => {
    const mine = await pinned("mine", selfSigner);
    const keep = await pinned("keep");
    const h = harness([mine, keep]);
    try {
      h.delete(mine);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      // The fake host still serves the same head. Re-evaluate it by every route the engine has.
      h.inputs$.next([...h.inputs$.value]);
      h.cyclePhase();
      h.inputs$.next([...h.inputs$.value]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(1);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: drop the head hash from the duty key (request key `pin-upkeep:<channel>` only). The settled key then
  // answers quiet for the replayed head, so the assertion of a second publication built on the replayed head fails.
  it("a replayed head that re-seats a deleted entry re-arms and builds on the current head", async () => {
    const mine = await pinned("mine", selfSigner);
    const keep = await pinned("keep");
    const h = harness([mine, keep]);
    try {
      h.delete(mine);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].expectedHead).toBe("h1");
      // The omission edition lands, then a stale holder replays a head that re-seats the deleted entry.
      h.moveHead("h2", [keep.entry]);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      h.moveHead("h3", [mine.entry, keep.entry]);
      await h.tick(0);
      expect(h.calls).toHaveLength(2);
      expect(h.calls[1].expectedHead).toBe("h3");
      expect(JSON.parse(h.calls[1].content).entries).toEqual([keep.entry]);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: remove the canWrite() conjunct from the duty's eligible predicate. The reevaluated witness duty then
  // stays armed and publishes after the tick, so the pending 0 and no-publication assertions fail.
  it("demotion while armed cancels the duty", async () => {
    const doomed = await pinned("doomed");
    const keep = await pinned("keep");
    const h = harness([doomed, keep]);
    try {
      h.delete(doomed);
      await h.tick(1_000);
      expect(h.scope.pending).toBe(1);
      h.live.canWrite = false;
      h.state$.next(h.state$.value);
      h.scope.reevaluate();
      expect(h.scope.pending).toBe(0);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
      expect(h.diagnostics).toEqual([]);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: pass a no-op check to host.publishPinList instead of one that calls ctx.assertAlive(). The fake
  // publish then records the edition although canWrite turned false, so the no-publication assertion fails.
  it("demotion during publication aborts before the edition is published", async () => {
    const mine = await pinned("mine", selfSigner);
    const keep = await pinned("keep");
    const h = harness([mine, keep]);
    h.control.hold = deferred();
    h.control.entered = deferred();
    try {
      h.delete(mine);
      h.clock.tick(0);
      await h.control.entered.promise;
      h.live.canWrite = false;
      h.control.hold.resolve();
      await h.scope.idle();
      expect(h.calls).toHaveLength(0);
      // A cancelled attempt is silent: no failure and no exhaustion is reported.
      expect(h.diagnostics).toEqual([]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: remove the live-channel conjunct from eligible and let plan() treat a missing channel as a public one.
  // The armed duty then fires on the still-served head and publishes, so the no-publication assertion fails.
  it("a channel deleted while armed is not maintained", async () => {
    const doomed = await pinned("doomed");
    const keep = await pinned("keep");
    const h = harness([doomed, keep]);
    try {
      h.delete(doomed);
      await h.tick(1_000);
      expect(h.scope.pending).toBe(1);
      h.setChannelPresent(false);
      expect(h.scope.pending).toBe(0);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
    } finally {
      h.dispose();
    }
  });

  it("a failed acknowledgment retries within bounded attempts and then reports duty-exhausted", async () => {
    const mine = await pinned("mine", selfSigner);
    const keep = await pinned("keep");
    const h = harness([mine, keep]);
    let attempts = 0;
    h.control.failWith = () => {
      attempts++;
      return new RequiredPublishError("pin-omission", []);
    };
    try {
      h.delete(mine);
      await h.tick(0);
      expect(attempts).toBe(1);
      await h.tick(999);
      expect(attempts).toBe(1);
      await h.tick(1);
      expect(attempts).toBe(2);
      await h.tick(1_999);
      expect(attempts).toBe(2);
      await h.tick(1);
      expect(attempts).toBe(3);
      const exhausted = h.diagnostics.filter((d) => d.stage === "duty-exhausted");
      expect(exhausted).toHaveLength(1);
      const [report] = exhausted;
      if (report.stage !== "duty-exhausted") throw new Error("unreachable");
      expect(report.duty).toBe("pin-omission");
      expect(report.key).toContain(CHANNEL);
      // Settled: nothing retries and nothing else is reported.
      await h.tick(600_000);
      expect(attempts).toBe(3);
      expect(h.scope.pending).toBe(0);
    } finally {
      h.dispose();
    }
  });

  it("rate limiting defers upkeep and reports pin-upkeep-skipped", async () => {
    const first = await pinned("first", selfSigner);
    const second = await pinned("second", selfSigner);
    const keep = await pinned("keep");
    const h = harness([first, second, keep], { rateLimit: { max: 1, windowMs: 60_000 } });
    try {
      h.delete(first);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      h.moveHead("h2", [second.entry, keep.entry]);
      await h.tick(10_000);
      // A second head inside the window: deferred to the window end, reported once, never dropped.
      h.delete(second);
      h.inputs$.next([...h.inputs$.value]);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      expect(h.scope.pending).toBe(1);
      const skipped = h.diagnostics.filter((d) => d.stage === "pin-upkeep-skipped");
      expect(skipped).toHaveLength(1);
      if (skipped[0].stage !== "pin-upkeep-skipped") throw new Error("unreachable");
      expect(skipped[0].reason).toBe("rate-limited");
      expect(skipped[0].key).toBe(CHANNEL);
      await h.tick(49_999);
      expect(h.calls).toHaveLength(1);
      await h.tick(1);
      expect(h.calls).toHaveLength(2);
      expect(h.calls[1].expectedHead).toBe("h2");
      expect(h.diagnostics.filter((d) => d.stage === "pin-upkeep-skipped")).toHaveLength(1);
    } finally {
      h.dispose();
    }
  });

  it("the default rate limit allows four upkeep publications per channel and defers the fifth", async () => {
    const keep = await pinned("keep");
    const doomed: Pinned[] = [];
    for (let i = 0; i < 5; i++) doomed.push(await pinned(`doomed ${i}`, selfSigner));
    const h = harness([...doomed, keep]);
    try {
      for (let i = 0; i < 5; i++) {
        h.moveHead(`h${i + 2}`, [...doomed.slice(i).map((pin) => pin.entry), keep.entry]);
        h.delete(doomed[i]);
        await h.tick(1_000);
      }
      expect(h.calls).toHaveLength(4);
      const skipped = h.diagnostics.filter((d) => d.stage === "pin-upkeep-skipped");
      expect(skipped).toHaveLength(1);
      // The fifth publishes once the window since the first has passed.
      await h.tick(600_000);
      expect(h.calls).toHaveLength(5);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: in the planning input the maintainer builds, add a synthetic kind 5 by the pin's proven author
  // targeting each verified pin whose expiresAt is at or before the clock (expiry treated as a deletion). A duty is then
  // requested and publishes, so the pending 0 and no-publication assertions fail.
  it("expiry never schedules upkeep (D-02)", async () => {
    const expiresAt = NOW_MS / 1000 + 60;
    const expiring = await pinned("expiring", otherSigner, [["expiration", String(expiresAt)]]);
    const keep = await pinned("keep");
    const h = harness([expiring, keep]);
    try {
      expect(verifyPinEntry(expiring.entry, CHANNEL)?.expiresAt).toBe(expiresAt);
      await h.tick(0);
      h.clock.tick(120_000);
      // Re-emit everything the maintainer listens to after the pin expired.
      h.inputs$.next([]);
      h.cyclePhase();
      h.state$.next(h.state$.value);
      expect(h.scope.pending).toBe(0);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
      expect(h.scope.pending).toBe(0);
    } finally {
      h.dispose();
    }
  });

  it("a private-era Pin List on a public channel is never rewritten and is reported once", async () => {
    const mine = await pinned("mine", selfSigner);
    const keep = await pinned("keep");
    const h = harness([mine, keep], { headContent: JSON.stringify({ sealed: "x", epoch: "1" }) });
    try {
      h.delete(mine);
      h.inputs$.next([...h.inputs$.value]);
      h.inputs$.next([...h.inputs$.value]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
      expect(h.scope.pending).toBe(0);
      const skipped = h.diagnostics.filter((d) => d.stage === "pin-upkeep-skipped");
      expect(skipped).toHaveLength(1);
      if (skipped[0].stage !== "pin-upkeep-skipped") throw new Error("unreachable");
      expect(skipped[0].reason).toBe("private-era-list");
      expect(skipped[0].key).toBe(CHANNEL);
      // A new head is a new report.
      h.moveHead("h2", [mine.entry, keep.entry]);
      await h.tick(0);
      expect(h.diagnostics.filter((d) => d.stage === "pin-upkeep-skipped")).toHaveLength(2);
    } finally {
      h.dispose();
    }
  });

  it("a rewrite over the byte ceiling reports over-cap once and publishes nothing", async () => {
    const big = await Promise.all([1, 2, 3].map((i) => pinned(`${i}`.repeat(5_500), selfSigner)));
    const doomed = await pinned("doomed", selfSigner);
    const sealKey = { epoch: 1, convKey: CONV_KEY };
    // The plaintext head fits the ceiling but its sealed rewrite does not, so the executor cannot produce it.
    const plaintext = JSON.stringify({ entries: [...big.map((pin) => pin.entry), doomed.entry] });
    expect(new TextEncoder().encode(plaintext).length).toBeLessThan(32_768);
    expect(() => encodePinList(big.map((pin) => pin.entry), sealKey)).toThrow("ceiling");
    const h = harness([...big, doomed], { channelPrivate: true, sealKey });
    try {
      h.delete(doomed);
      await h.tick(0);
      h.inputs$.next([...h.inputs$.value]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
      const skipped = h.diagnostics.filter((d) => d.stage === "pin-upkeep-skipped");
      expect(skipped).toHaveLength(1);
      if (skipped[0].stage !== "pin-upkeep-skipped") throw new Error("unreachable");
      expect(skipped[0].reason).toBe("over-cap");
      // The key settled: no retry and no duty-exhausted.
      expect(h.diagnostics.filter((d) => d.stage === "duty-exhausted")).toEqual([]);
      expect(h.scope.pending).toBe(0);
    } finally {
      h.dispose();
    }
  });

  it("dispose leaves no pending duty or subscription", async () => {
    const doomed = await pinned("doomed");
    const keep = await pinned("keep");
    const h = harness([doomed, keep]);
    h.delete(doomed);
    await h.tick(1_000);
    expect(h.scope.pending).toBe(1);
    expect(h.state$.observed).toBe(true);
    expect(h.inputs$.observed).toBe(true);
    h.maintainer.dispose();
    expect(h.state$.observed).toBe(false);
    expect(h.phase$.observed).toBe(false);
    expect(h.materialChanged$.observed).toBe(false);
    expect(h.inputs$.observed).toBe(false);
    expect(h.scope.pending).toBe(0);
    await h.tick(60_000);
    expect(h.calls).toHaveLength(0);
    h.dispose();
  });

  it("suspension on dissolution refuses pin upkeep", async () => {
    const doomed = await pinned("doomed");
    const keep = await pinned("keep");
    const mine = await pinned("mine", selfSigner);
    const h = harness([doomed, mine, keep]);
    try {
      h.delete(doomed);
      await h.tick(1_000);
      expect(h.scope.pending).toBe(1);
      h.scope.suspend("dissolved");
      expect(h.scope.pending).toBe(0);
      // A later deletion, even of the client's own pin, is refused by the scope.
      h.moveHead("h2", [doomed.entry, mine.entry, keep.entry]);
      h.delete(mine);
      await h.tick(120_000);
      expect(h.calls).toHaveLength(0);
      expect(h.scope.pending).toBe(0);
    } finally {
      h.dispose();
    }
  });
});

type PinEditFixture = Awaited<ReturnType<typeof editOf>>;

describe("PinMaintainer edit-proof refresh", () => {
  /** An Edit reaches the channel: the route funnel notes its seal first, then the rumor reaches the store. */
  function receive(h: ReturnType<typeof harness>, edit: PinEditFixture, options: { seal?: boolean } = {}): void {
    if (options.seal !== false) h.maintainer.noteChannelInput(CHANNEL_PLANE, edit.decoded);
    h.inputs$.next([...h.inputs$.value, edit.rumor]);
  }

  /** The edit bundle id of each entry in a published Pin List. */
  function bundledEditIds(content: string): Array<string | undefined> {
    const entries = (JSON.parse(content) as { entries: PinEntry[] }).entries;
    return entries.map((entry) => verifyPinEntry(entry, CHANNEL)?.edit?.id);
  }

  it("the newest provable Edit at fire time wins over the one seen when the duty was armed", async () => {
    const theirs = await pinned("theirs");
    const h = harness([theirs]);
    try {
      const e1 = await editOf(theirs.rumor, otherSigner, "first correction", 5_000);
      receive(h, e1);
      await h.tick(0);
      expect(h.scope.pending).toBe(1);
      // The second correction's seal arrives while the duty is armed.
      const e2 = await editOf(theirs.rumor, otherSigner, "second correction", 6_000);
      receive(h, e2);
      await h.tick(5_000);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].stage).toBe("pin-edit-refresh");
      expect(h.calls[0].expectedHead).toBe("h1");
      expect(bundledEditIds(h.calls[0].content)).toEqual([e2.rumor.id]);
    } finally {
      h.dispose();
    }
  });

  it("a witness's three corrections within the delay window cost one publication", async () => {
    const theirs = await pinned("theirs");
    const h = harness([theirs]);
    try {
      const edits = [
        await editOf(theirs.rumor, otherSigner, "one", 5_000),
        await editOf(theirs.rumor, otherSigner, "two", 6_000),
        await editOf(theirs.rumor, otherSigner, "three", 7_000),
      ];
      for (const edit of edits) {
        receive(h, edit);
        await h.tick(1_000);
        expect(h.calls).toHaveLength(0);
      }
      await h.tick(2_000);
      expect(h.calls).toHaveLength(1);
      expect(bundledEditIds(h.calls[0].content)).toEqual([edits[2].rumor.id]);
      // The head did not move in this fake, and the same head never publishes twice.
      await h.tick(120_000);
      expect(h.calls).toHaveLength(1);
    } finally {
      h.dispose();
    }
  });

  it("an unprovable newer Edit keeps the entry's existing bundle", async () => {
    const theirs = await pinned("theirs");
    const h = harness([theirs]);
    try {
      const unprovable = await editOf(theirs.rumor, otherSigner, "no seal was ever recorded", 5_000);
      receive(h, unprovable, { seal: false });
      expect(h.scope.pending).toBe(0);
      await h.tick(120_000);
      expect(h.calls).toHaveLength(0);
      // The Edit itself is fine: once its seal is known the same state refreshes, so nothing above was a dead path.
      h.maintainer.noteChannelInput(CHANNEL_PLANE, unprovable.decoded);
      h.inputs$.next([...h.inputs$.value]);
      await h.tick(5_000);
      expect(h.calls).toHaveLength(1);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: in planPinUpkeep drop the strictly-newer test. The head's entry already bundles e2, e1 is the only
  // Edit with a recorded seal, and the mutated planner then rewrites the list to bundle e1, which fails calls.length 0.
  it("refresh never attaches an Edit older than the entry carries", async () => {
    const theirs = await pinned("theirs");
    const e1 = await editOf(theirs.rumor, otherSigner, "older", 5_000);
    const e2 = await editOf(theirs.rumor, otherSigner, "bundled", 6_000);
    const bundled = { ...theirs.entry, edit: createPinProof(e2.seal, CONV_KEY) } as PinEntry;
    const h = harness([{ rumor: theirs.rumor, entry: bundled }]);
    try {
      receive(h, e1);
      expect(h.scope.pending).toBe(0);
      await h.tick(120_000);
      expect(h.calls).toHaveLength(0);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: in PinMaintainer.evaluate's run, return normally (instead of throwing DutyCancelledError) when the
  // fire-time plan is no longer a rewrite. The scope then settles the head's duty key, the fresh Edit's request on the
  // same head answers quiet, and the single-publication assertion fails.
  it("a fire that finds nothing to publish leaves later upkeep on the same head possible (WR-01)", async () => {
    const theirs = await pinned("theirs");
    const h = harness([theirs]);
    try {
      const fleeting = await editOf(theirs.rumor, otherSigner, "fleeting", 5_000, [
        ["expiration", String(NOW_MS / 1000 + 2)],
      ]);
      receive(h, fleeting);
      await h.tick(0);
      expect(h.scope.pending).toBe(1);
      // The Edit expires while the witness duty is armed, so the fire-time plan has nothing to publish.
      await h.tick(5_000);
      expect(h.calls).toHaveLength(0);
      expect(h.scope.pending).toBe(0);
      // A fresh Edit on the same head is new due work and is still published.
      const fresh = await editOf(theirs.rumor, otherSigner, "fresh", 6_000);
      receive(h, fresh);
      expect(h.scope.pending).toBe(1);
      await h.tick(5_000);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].stage).toBe("pin-edit-refresh");
      expect(h.calls[0].expectedHead).toBe("h1");
      expect(bundledEditIds(h.calls[0].content)).toEqual([fresh.rumor.id]);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: drop the ban fingerprint from PinMaintainer.signature. Lifting the ban then changes no signature, the
  // channel is not re-planned, and the pending 1 assertion fails.
  it("lifting a ban re-plans a watched channel (WR-05)", async () => {
    const theirs = await pinned("theirs");
    const h = harness([theirs]);
    try {
      h.setBans([theirs.rumor.pubkey]);
      const e1 = await editOf(theirs.rumor, otherSigner, "correction", 5_000);
      receive(h, e1);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
      expect(h.scope.pending).toBe(0);
      h.setBans([]);
      expect(h.scope.pending).toBe(1);
      await h.tick(5_000);
      expect(h.calls).toHaveLength(1);
      expect(bundledEditIds(h.calls[0].content)).toEqual([e1.rumor.id]);
    } finally {
      h.dispose();
    }
  });

  it("the pinner refreshes an edit immediately (D-08)", async () => {
    const mine = await pinned("mine", selfSigner);
    const h = harness([mine]);
    try {
      const e1 = await editOf(mine.rumor, selfSigner, "my correction", 5_000);
      receive(h, e1);
      await h.tick(0);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].stage).toBe("pin-edit-refresh");
      expect(bundledEditIds(h.calls[0].content)).toEqual([e1.rumor.id]);
    } finally {
      h.dispose();
    }
  });
});

describe("PinMaintainer rekey refresh", () => {
  const OLD_HEAD = JSON.stringify({ sealed: "x", epoch: "1" });

  /** A private channel whose head is sealed at epoch 1 while the held current key is still epoch 1. */
  function privateHarness(entries: Pinned[], random = 0) {
    const options: HarnessOptions = {
      random,
      channelPrivate: true,
      headContent: OLD_HEAD,
      sealKey: { epoch: 1, convKey: CONV_KEY },
    };
    return { options, h: harness(entries, options) };
  }

  /** The channel moves to epoch 2: the key commit emits materialChanged$. */
  function rekey(h: ReturnType<typeof harness>, options: HarnessOptions): void {
    options.sealKey = { epoch: 2, convKey: CONV_KEY };
    h.materialChanged$.next();
  }

  // Non-vacuity: in PinMaintainer.evaluate, ignore the rotation flag (always use the witness delay); the rotator's
  // reseal is then not published at tick(0) and the first assertion fails. Treating the flag as permanent instead fails
  // the last assertion, where a later reseal by the same client must wait again.
  it("noteRotation makes the rotator's reseal immediate and others wait", async () => {
    const theirs = await pinned("theirs");
    const rotator = privateHarness([theirs]);
    try {
      await rotator.h.tick(60_000);
      expect(rotator.h.calls).toHaveLength(0);
      rotator.h.maintainer.noteRotation(CHANNEL);
      rekey(rotator.h, rotator.options);
      await rotator.h.tick(0);
      expect(rotator.h.calls).toHaveLength(1);
      expect(rotator.h.calls[0].stage).toBe("pin-rekey-refresh");
      expect(rotator.h.calls[0].expectedHead).toBe("h1");
      // The flag was consumed by that request: the next reseal of the channel waits the witness delay again.
      rotator.options.headContent = OLD_HEAD;
      rotator.h.moveHead("h2", [theirs.entry]);
      await rotator.h.tick(0);
      expect(rotator.h.calls).toHaveLength(1);
      await rotator.h.tick(5_000);
      expect(rotator.h.calls).toHaveLength(2);
    } finally {
      rotator.h.dispose();
    }

    const witness = privateHarness([theirs]);
    try {
      rekey(witness.h, witness.options);
      await witness.h.tick(0);
      expect(witness.h.calls).toHaveLength(0);
      expect(witness.h.scope.pending).toBe(1);
      await witness.h.tick(4_999);
      expect(witness.h.calls).toHaveLength(0);
      await witness.h.tick(1);
      expect(witness.h.calls).toHaveLength(1);
      expect(witness.h.calls[0].stage).toBe("pin-rekey-refresh");
      // The reseal carries the head's entries unchanged, sealed under the new key's epoch.
      const content = JSON.parse(witness.h.calls[0].content) as { epoch: string; sealed: string };
      expect(content.epoch).toBe("2");
    } finally {
      witness.h.dispose();
    }
  });

  it("a key change re-plans a watched private channel", async () => {
    const theirs = await pinned("theirs");
    const { options, h } = privateHarness([theirs]);
    try {
      await h.tick(60_000);
      expect(h.scope.pending).toBe(0);
      expect(h.calls).toHaveLength(0);
      rekey(h, options);
      expect(h.scope.pending).toBe(1);
      await h.tick(5_000);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].stage).toBe("pin-rekey-refresh");
      // A head already at the current epoch plans nothing.
      options.headContent = JSON.stringify({ sealed: "x", epoch: "2" });
      h.moveHead("h2", [theirs.entry]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(1);
    } finally {
      h.dispose();
    }
  });

  // Non-vacuity: drop the held key epochs from PinMaintainer.signature. Receiving the older key then leaves the
  // signature unchanged, the newly readable list is never watched, and the observed and pending assertions fail.
  it("receiving an older held key that opens the list starts watching it (WR-05)", async () => {
    const theirs = await pinned("theirs");
    const { options, h } = privateHarness([theirs]);
    try {
      // The head is sealed at epoch 1, but only the epoch 2 key is held: the list cannot be opened.
      options.sealKey = { epoch: 2, convKey: CONV_KEY };
      h.live.readable = false;
      h.live.keyEpochs = "2";
      h.materialChanged$.next();
      await h.tick(60_000);
      expect(h.inputs$.observed).toBe(false);
      expect(h.scope.pending).toBe(0);
      // A key expansion delivers the epoch 1 key; the current key is unchanged.
      h.live.readable = true;
      h.live.keyEpochs = "2,1";
      h.materialChanged$.next();
      expect(h.inputs$.observed).toBe(true);
      expect(h.scope.pending).toBe(1);
      await h.tick(5_000);
      expect(h.calls).toHaveLength(1);
      expect(h.calls[0].stage).toBe("pin-rekey-refresh");
    } finally {
      h.dispose();
    }
  });

  it("a witness skips the reseal when the head was already resealed", async () => {
    const theirs = await pinned("theirs");
    const { options, h } = privateHarness([theirs]);
    try {
      rekey(h, options);
      await h.tick(0);
      expect(h.scope.pending).toBe(1);
      // The rotator wins the race: the head moves to a list sealed at epoch 2 before the witness delay elapses.
      options.headContent = JSON.stringify({ sealed: "y", epoch: "2" });
      h.moveHead("h2", [theirs.entry]);
      await h.tick(60_000);
      expect(h.calls).toHaveLength(0);
    } finally {
      h.dispose();
    }
  });
});
