// Self-tests for the D-31 model runner: it must drive a real ConcordClient deterministically and record its evidence
// entries only from what it scripted and observed (checker BLOCKER 1), so the seeded model test can trust its traces.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { COMMUNITY_LIST_FRAGMENT_KIND, decodeCommunityListFragment } from "../../helpers/community-list-wire.ts";
import {
  buildMemberPool,
  fragmentView,
  type ModelRun,
  type ModelTrace,
  type PublishOutcome,
  type TraceEntry,
} from "./community-list-model-core.ts";
import { ModelHarnessError, modelUserSigner, runModel } from "./community-list-model-runner.ts";

const pool = await buildMemberPool(4);

type Entry<T extends TraceEntry["type"]> = Extract<TraceEntry, { type: T }>;
const only = <T extends TraceEntry["type"]>(trace: ModelTrace, type: T): Entry<T>[] =>
  trace.entries.filter((entry): entry is Entry<T> => entry.type === type);

/** Everything a run decides that must not depend on event ids, ciphertexts or real time. */
function outcomes(trace: ModelTrace) {
  const settled = new Map(only(trace, "op-settled").map((e) => [e.opSeq, `${e.result}:${e.errorName ?? ""}`]));
  return {
    ops: only(trace, "op").map((e) => `${e.op.kind}:${settled.get(e.seq) ?? `${e.result}:${e.errorName ?? ""}`}`),
    reads: only(trace, "read").map((e) => `${e.lifecycle}:${e.mode}:${e.outcome}:${e.served.length}`),
    publishes: only(trace, "publish").length,
    ingests: only(trace, "ingest").map((e) => `${e.lifecycle}:${e.unlock}:${e.outcome}`),
    resets: only(trace, "evidence-reset").map((e) => `${e.lifecycle}:${e.cause}`),
  };
}

const dOf = (event: NostrEvent): number => Number(event.tags.find((tag) => tag[0] === "d")?.[1]);

const BASIC: ModelRun = {
  seed: 7,
  autoSave: false,
  autoUnlock: true,
  initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [1] },
  ops: [
    { kind: "start" },
    { kind: "join", member: 2 },
    { kind: "advance", ms: 6_000 },
    { kind: "leave", member: 1 },
    { kind: "remote", action: "add", member: 3, delivery: "both" },
    { kind: "advance", ms: 1_000 },
  ],
};

describe("Community List model runner (D-31)", () => {
  it("the runner is deterministic for a fixed run", async () => {
    const first = await runModel(BASIC, { pool });
    const second = await runModel(BASIC, { pool });
    expect(outcomes(second)).toEqual(outcomes(first));
    expect(outcomes(first).publishes).toBeGreaterThan(0);
  });

  it("the runner records one read entry per kind-33302 read and one publish entry per publish", async () => {
    const run: ModelRun = {
      seed: 8,
      autoSave: false,
      autoUnlock: true,
      initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [] },
      ops: [
        { kind: "read-mode", mode: "slow" },
        { kind: "start" },
        { kind: "advance", ms: 1_000 },
        { kind: "stop" }, // abandons the parked slow read
        { kind: "read-mode", mode: "complete" },
        { kind: "start" },
        { kind: "join", member: 2 },
        { kind: "advance", ms: 6_000 },
      ],
    };
    const trace = await runModel(run, { pool });
    const starts = only(trace, "read-start");
    const reads = only(trace, "read");
    expect(new Set(starts.map((e) => e.readId)).size).toBe(starts.length);
    expect(reads.map((e) => e.readId).sort()).toEqual(starts.map((e) => e.readId).sort());
    for (const read of reads) {
      const start = starts.find((e) => e.readId === read.readId)!;
      expect(start.seq).toBeLessThan(read.seq);
      expect(start.lifecycle).toBe(read.lifecycle);
    }
    // The slow read the client unsubscribed from first is "abandoned", not an error or a completion.
    expect(reads[0]).toMatchObject({ lifecycle: 1, mode: "slow", outcome: "abandoned", served: [] });
    expect(reads.some((e) => e.lifecycle === 2 && e.outcome === "complete")).toBe(true);

    const pubkey = await modelUserSigner(run.seed).getPublicKey();
    const publishes = only(trace, "publish");
    expect(publishes.length).toBeGreaterThan(0);
    expect(new Set(publishes.map((e) => e.event.id)).size).toBe(publishes.length);
    for (const publish of publishes) {
      expect(publish.event.kind).toBe(COMMUNITY_LIST_FRAGMENT_KIND);
      expect(publish.event.pubkey).toBe(pubkey);
      expect(trace.fragments[publish.event.id]).toEqual(publish.event);
      expect(publish.storeFragmentIds).not.toContain(publish.event.id);
      // Recorded before the relay answered: the sync ingests its own fragment only after the publish resolved.
      const ingest = only(trace, "ingest").find((e) => e.eventId === publish.event.id);
      expect(ingest && ingest.seq > publish.seq).toBe(true);
    }
  });

  it("the runner records evidence resets and ingests from its own script", async () => {
    const run: ModelRun = {
      seed: 9,
      autoSave: false,
      autoUnlock: true,
      initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [] },
      ops: [
        { kind: "start" },
        { kind: "signer", method: "getPublicKey", mode: "fail" },
        { kind: "remote", action: "add", member: 1, delivery: "store" }, // step 2: authentication fails
        { kind: "signer", method: "getPublicKey", mode: "ok" },
        { kind: "signer", method: "decrypt", mode: "fail" },
        { kind: "remote", action: "add", member: 2, delivery: "store" }, // step 5: decrypt fails
        { kind: "signer", method: "decrypt", mode: "ok" },
        { kind: "remote", action: "add", member: 3, delivery: "relay" }, // step 7: never reaches the store
        { kind: "stop" },
        { kind: "start" },
        { kind: "start" }, // redundant
        { kind: "dispose" },
        { kind: "start" }, // after dispose
      ],
    };
    const trace = await runModel(run, { pool });
    const resets = only(trace, "evidence-reset");
    const cause = (name: string) => resets.filter((e) => e.cause === name);
    expect(cause("start").map((e) => [e.step, e.lifecycle])).toEqual([[0, 1], [9, 2]]);
    expect(cause("stop").map((e) => e.step)).toEqual([8]);
    expect(cause("dispose").map((e) => e.step)).toEqual([11]);

    const arrivals = cause("remote-arrived");
    expect(arrivals.map((e) => e.step)).toEqual([2, 5]);
    const [failing, locked] = arrivals.map((e) => e.eventId!);
    const ingests = only(trace, "ingest");
    // A scripted getPublicKey failure: "auth-failed" plus an "ingest-failed" reset for that event.
    expect(ingests.some((e) => e.eventId === failing && e.outcome === "auth-failed")).toBe(true);
    expect(cause("ingest-failed").some((e) => e.eventId === failing && e.step === 2)).toBe(true);
    // A scripted decrypt failure after authentication: "failed", and no reset for that event.
    expect(ingests.some((e) => e.eventId === locked && e.unlock && e.outcome === "failed")).toBe(true);
    expect(cause("ingest-failed").some((e) => e.eventId === locked)).toBe(false);

    // The start after dispose rejects; neither it nor the redundant start bumped the lifecycle.
    const lastStart = only(trace, "op").filter((e) => e.op.kind === "start" && e.step === 12)[0];
    const settled = only(trace, "op-settled").find((e) => e.opSeq === lastStart.seq);
    expect(settled).toMatchObject({ result: "rejected", errorName: "ConcordClientDisposedError" });
    expect(Math.max(...resets.map((e) => e.lifecycle))).toBe(2);
  });

  it("the runner parks only the next call of a parked signer method until release-stalls", async () => {
    const run: ModelRun = {
      seed: 10,
      autoSave: false,
      autoUnlock: false, // start() decrypts nothing, so the unlock makes the first decrypt call
      initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
      ops: [
        { kind: "start" },
        { kind: "park", method: "decrypt" },
        { kind: "release-stalls" }, // disarms the park before any decrypt call
        { kind: "park", method: "getPublicKey" },
        { kind: "unlock" }, // step 4: its getPublicKey parks, holding the lane step
        { kind: "join", member: 2 }, // step 5: the next getPublicKey call is not parked
        { kind: "release-stalls" }, // step 6
        { kind: "advance", ms: 1_000 },
      ],
    };
    const trace = await runModel(run, { pool });
    const calls = only(trace, "signer-call");
    expect(calls.filter((e) => e.outcome === "stall").map((e) => [e.step, e.method])).toEqual([[4, "getPublicKey"]]);
    const joinKeys = calls.filter((e) => e.step === 5 && e.method === "getPublicKey");
    expect(joinKeys.length).toBeGreaterThan(0);
    expect(joinKeys.every((e) => e.outcome === "ok")).toBe(true);
    const decrypts = calls.filter((e) => e.method === "decrypt");
    expect(decrypts.length).toBeGreaterThan(0);
    expect(decrypts.every((e) => e.outcome === "ok" && e.step >= 6)).toBe(true);
    // The parked unlock settles only after release-stalls.
    const ops = only(trace, "op");
    const unlock = ops.find((e) => e.step === 4)!;
    const release = ops.find((e) => e.step === 6)!;
    const settled = only(trace, "op-settled").find((e) => e.opSeq === unlock.seq);
    expect(settled?.result).toBe("ok");
    expect(settled!.seq).toBeGreaterThan(release.seq);
  });

  it("a stale remote write is older than every fragment and outside the governing count", async () => {
    const run: ModelRun = {
      seed: 11,
      autoSave: false,
      autoUnlock: true,
      initial: { fragments: 2, remoteMembers: [0, 1], mirrorMembers: [] },
      ops: [
        { kind: "start" },
        { kind: "remote", action: "grow", member: 2, delivery: "relay" }, // d=2 frags:3, relay only
        { kind: "remote", action: "stale", member: 3, delivery: "store" },
        { kind: "advance", ms: 1_000 },
      ],
    };
    const trace = await runModel(run, { pool });
    const arrivals = only(trace, "evidence-reset").filter((e) => e.cause === "remote-arrived" && e.step === 2);
    // The store delivery replays the relay-only d=2 first, then the stale copy.
    expect(arrivals).toHaveLength(2);
    const stale = trace.fragments[arrivals[1].eventId!];
    const others = Object.values(trace.fragments).filter((event) => event.id !== stale.id);
    expect(others.length).toBeGreaterThanOrEqual(3);
    for (const event of others) {
      expect(stale.created_at).toBeLessThan(event.created_at);
      expect(dOf(stale)).toBeGreaterThan(dOf(event));
    }
    const signer = modelUserSigner(run.seed);
    const pubkey = await signer.getPublicKey();
    const open = async (event: NostrEvent) => ({
      event,
      doc: decodeCommunityListFragment(await signer.nip44.decrypt(pubkey, event.content)),
    });
    const final = only(trace, "probe").find((e) => e.name === "final")!;
    expect(final.snapshot.storeIds).toContain(stale.id);
    const stored = await Promise.all(final.snapshot.storeIds.map((id) => open(trace.fragments[id])));
    const withStale = fragmentView(stored);
    const without = fragmentView(stored.filter(({ event }) => event.id !== stale.id));
    expect(withStale).toEqual(without);
    expect(dOf(stale)).toBeGreaterThanOrEqual(withStale.count);

    // With no fragment on the relay or in the store, a stale write delivers nothing and records no arrival.
    const empty = await runModel({
      ...run,
      initial: { fragments: 0, remoteMembers: [], mirrorMembers: [] },
      ops: [{ kind: "start" }, { kind: "remote", action: "stale", member: 3, delivery: "both" }],
    }, { pool });
    expect(only(empty, "evidence-reset").some((e) => e.cause === "remote-arrived")).toBe(false);
    expect(only(empty, "op").find((e) => e.step === 1)?.result).toBe("ok");
    expect(Object.keys(empty.fragments).length).toBe(only(empty, "publish").length);
  });

  it("the runner records the outcome it scripted for every publish", async () => {
    const run: ModelRun = {
      seed: 12,
      autoSave: false,
      autoUnlock: true,
      initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
      ops: [
        { kind: "start" },
        { kind: "join", member: 1 },
        { kind: "advance", ms: 1_000 },
        { kind: "publish-mode", mode: "refuse-transient" },
        { kind: "join", member: 2 },
        { kind: "advance", ms: 1_000 },
        { kind: "publish-mode", mode: "refuse-permanent" },
        { kind: "join", member: 3 },
        { kind: "advance", ms: 1_000 },
        { kind: "publish-mode", mode: "accept" },
        { kind: "save" },
        { kind: "advance", ms: 1_000 },
      ],
    };
    const trace = await runModel(run, { pool });
    const scripted: Record<string, PublishOutcome> = {
      "accept": "accepted",
      "refuse-transient": "refused-transient",
      "refuse-permanent": "refused-permanent",
    };
    const modes = only(trace, "op").filter((e) => e.op.kind === "publish-mode");
    const publishes = only(trace, "publish");
    for (const publish of publishes) {
      const mode = modes.filter((e) => e.seq < publish.seq).at(-1);
      const expected = mode && mode.op.kind === "publish-mode" ? scripted[mode.op.mode] : "accepted";
      expect(publish.outcome).toBe(expected);
    }
    expect(new Set(publishes.map((e) => e.outcome))).toEqual(
      new Set<PublishOutcome>(["accepted", "refused-transient", "refused-permanent"]),
    );
    // Probes record the store's ids: a refused fragment never reaches the store.
    const refused = new Set(publishes.filter((e) => e.outcome !== "accepted").map((e) => e.event.id));
    const probes = only(trace, "probe");
    expect(probes.length).toBeGreaterThan(0);
    for (const probe of probes) expect(probe.snapshot.storeIds.some((id) => refused.has(id))).toBe(false);
    const final = probes.find((e) => e.name === "final")!;
    expect(final.snapshot.storeIds.some((id) => publishes.some((e) => e.event.id === id && e.outcome === "accepted")))
      .toBe(true);
  });

  it("the runner fails only the next call of a fail-next signer method", async () => {
    // The join's guestbook seal is the next signEvent: it is declined, and the join's list save then signs again.
    const run: ModelRun = {
      seed: 13,
      autoSave: false,
      autoUnlock: true,
      initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
      ops: [
        { kind: "start" },
        { kind: "fail-next", method: "signEvent" },
        { kind: "join", member: 2 },
        { kind: "advance", ms: 1_000 },
      ],
    };
    const trace = await runModel(run, { pool });
    const armedAt = only(trace, "op").find((e) => e.op.kind === "fail-next")!.seq;
    const signs = only(trace, "signer-call").filter((e) => e.method === "signEvent" && e.seq > armedAt);
    expect(signs.length).toBeGreaterThanOrEqual(2);
    expect(signs.map((e) => e.outcome)).toEqual(["fail", ...signs.slice(1).map(() => "ok")]);
    const join = only(trace, "op").find((e) => e.op.kind === "join")!;
    expect(only(trace, "op-settled").find((e) => e.opSeq === join.seq)).toMatchObject({ result: "rejected" });

    // An unused fail-next is disarmed before quiescence: with autoUnlock off nothing decrypts until the app's nudge.
    const unused = await runModel({
      ...run,
      seed: 14,
      autoUnlock: false,
      ops: [{ kind: "start" }, { kind: "fail-next", method: "decrypt" }],
    }, { pool });
    const quiet = only(unused, "probe").find((e) => e.name === "quiescence-start")!.seq;
    const decrypts = only(unused, "signer-call").filter((e) => e.method === "decrypt");
    expect(decrypts.length).toBeGreaterThan(0);
    expect(decrypts.every((e) => e.seq > quiet && e.outcome === "ok")).toBe(true);
  });

  it("the runner records the draft kind and carried memberships of list-save signer calls and the community id of join and remote ops", async () => {
    const run: ModelRun = {
      seed: 15,
      autoSave: false,
      autoUnlock: true,
      initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
      ops: [
        { kind: "start" },
        { kind: "join", member: 2 },
        { kind: "advance", ms: 1_000 },
        { kind: "remote", action: "grow", member: 3, delivery: "relay" },
        { kind: "remote", action: "stale", member: 1, delivery: "store" },
      ],
    };
    const trace = await runModel(run, { pool });
    const [joined, grown] = [pool.materials[2].community_id, pool.materials[3].community_id];
    const ops = only(trace, "op");
    expect(ops[1]).toMatchObject({ op: { kind: "join" }, cid: joined });
    expect(ops[3]).toMatchObject({ op: { kind: "remote", action: "grow" }, cid: grown });
    expect(ops[4].cid).toBeUndefined(); // a stale copy touches no membership

    const calls = only(trace, "signer-call").filter((e) => e.step === 1);
    const seal = calls.find((e) => e.method === "signEvent" && e.kind !== COMMUNITY_LIST_FRAGMENT_KIND);
    expect(seal).toBeDefined();
    expect(seal!.carries).toBeUndefined();
    const encrypt = calls.find((e) => e.method === "encrypt");
    expect(encrypt?.carries).toContain(joined);
    const sign = calls.find((e) => e.method === "signEvent" && e.kind === COMMUNITY_LIST_FRAGMENT_KIND);
    expect(sign?.carries).toContain(joined);
    expect(sign!.carries).toEqual([...sign!.carries!].sort());
    // Only list-save calls carry memberships, and every signEvent records its draft kind.
    for (const call of only(trace, "signer-call")) {
      const listSave = call.method === "encrypt" ||
        (call.method === "signEvent" && call.kind === COMMUNITY_LIST_FRAGMENT_KIND);
      if (!listSave) expect(call.carries).toBeUndefined();
      if (call.method === "signEvent") expect(call.kind).toEqual(expect.any(Number));
    }
  });

  it("the runner reports a drain that never settles as a harness failure, not an invariant", async () => {
    const error = await runModel(BASIC, { pool, drainCap: 1 }).then(() => undefined, (e: unknown) => e);
    expect(error).toBeInstanceOf(ModelHarnessError);
    const message = (error as Error).message;
    expect(message).toContain("did not settle");
    expect(message).toContain(`seed ${BASIC.seed}`);
    expect(message).toMatch(/at step \d+/);
  });
});
