// Edit seal recovery for pin proof refresh (CORD-04 §7 Edits; Phase 2 PIN-05). The index is fed the way the route
// funnel feeds it, with real sealed Edits, so the proof, the self-check and the eviction rules run on real bytes.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";

import type { PlaneInfo } from "../../helpers/keys.ts";
import { sealRumor } from "../../operations/gift-wrap.ts";
import { createPinProof, type PinEntry, verifyPinEntry } from "../../helpers/pins.ts";
import type { DecodedEvent } from "../../types.ts";
import { PIN_EDIT_SEALS_PER_CHANNEL, PinEditSeals } from "../pin-edit-seals.ts";

const CHANNEL = "ab".repeat(32);
const CONV_KEY = new Uint8Array(32).fill(2);
const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
const stranger = new PrivateKeySigner(new Uint8Array(32).fill(5));

const info: PlaneInfo = { type: "channel", channelId: CHANNEL, convKey: CONV_KEY, epoch: 0 };

interface Pin {
  rumor: Rumor;
  entry: PinEntry;
}

/** A proven pinned message authored by `by` (default: the shared author). */
async function pin(content: string, by: PrivateKeySigner = signer): Promise<Pin> {
  const rumor = {
    pubkey: await by.getPublicKey(),
    id: "",
    kind: 9,
    content,
    tags: [["channel", CHANNEL], ["epoch", "0"]],
    created_at: 10,
  };
  rumor.id = getEventHash(rumor);
  return { rumor, entry: createPinProof(await sealRumor(CONV_KEY, by)(rumor), CONV_KEY) as PinEntry };
}

interface SealedEdit {
  rumor: Rumor;
  decoded: DecodedEvent;
}

/** A sealed Edit of `target` at `ms` milliseconds after second 1000, as the route funnel would receive it. */
async function edit(
  target: Rumor,
  text: string,
  ms: number,
  options: { by?: PrivateKeySigner; wrapId?: string; kind?: number; convKey?: Uint8Array; expiration?: number } = {},
): Promise<SealedEdit> {
  const by = options.by ?? signer;
  const rumor = {
    pubkey: await by.getPublicKey(),
    id: "",
    kind: options.kind ?? 3302,
    content: text,
    tags: [
      ["e", target.id],
      ["channel", CHANNEL],
      ["epoch", "0"],
      ["ms", String(ms % 1000)],
      ...(options.expiration === undefined ? [] : [["expiration", String(options.expiration)]]),
    ],
    created_at: 1000 + Math.floor(ms / 1000),
  };
  rumor.id = getEventHash(rumor);
  const seal = await sealRumor(options.convKey ?? CONV_KEY, by)(rumor);
  return {
    rumor,
    decoded: {
      rumor,
      author: rumor.pubkey,
      wrapId: options.wrapId ?? "ff".repeat(32),
      sealKind: seal.kind,
      ms: 1000 * 1000 + ms,
      seal,
    },
  };
}

describe("PinEditSeals", () => {
  it("keys Edit seals by recomputed rumor id, ignoring a forged embedded id", async () => {
    const target = await pin("original");
    const real = await edit(target.rumor, "corrected", 5);
    const forged = "ee".repeat(32);
    const seals = new PinEditSeals();
    seals.note(info, { ...real.decoded, rumor: { ...real.rumor, id: forged } });
    expect(seals.size(CHANNEL)).toBe(1);
    // Found under the recomputed id; the forged id is never what the proof is checked against.
    const proof = seals.proof(CHANNEL, target, { ...real.rumor, id: forged });
    expect(proof).toBeDefined();
    const opened = verifyPinEntry({ ...target.entry, edit: proof }, CHANNEL);
    expect(opened?.edit?.id).toBe(real.rumor.id);
    expect(opened?.edit?.id).not.toBe(forged);
    // An Edit that was never noted has no proof, and asking never invents one.
    const other = await edit(target.rumor, "never noted", 9);
    expect(seals.proof(CHANNEL, target, other.rumor)).toBeUndefined();
    // The result is memoized: the same object comes back.
    expect(seals.proof(CHANNEL, target, real.rumor)).toBe(proof);
  });

  it("a proof whose self-check fails is never returned", async () => {
    const target = await pin("original");
    const seals = new PinEditSeals();
    // An Edit by another author verifies as a seal but the entry drops it: the self-check refuses it.
    const foreign = await edit(target.rumor, "not the author", 5, { by: stranger });
    seals.note(info, foreign.decoded);
    expect(seals.size(CHANNEL)).toBe(1);
    expect(seals.proof(CHANNEL, target, foreign.rumor)).toBeUndefined();
    // A plane key that cannot open the seal makes createPinProof throw, which is no proof rather than an error.
    const wrongKey = await edit(target.rumor, "sealed elsewhere", 6, { convKey: new Uint8Array(32).fill(9) });
    seals.note(info, wrongKey.decoded);
    expect(seals.proof(CHANNEL, target, wrongKey.rumor)).toBeUndefined();
    // An Edit of a different message is not an Edit of this pin.
    const elsewhere = await pin("elsewhere");
    const mismatch = await edit(elsewhere.rumor, "other message", 7);
    seals.note(info, mismatch.decoded);
    expect(seals.proof(CHANNEL, target, mismatch.rumor)).toBeUndefined();
    // The honest Edit of the same pin still works, so the refusals above are not a broken index.
    const honest = await edit(target.rumor, "fine", 8);
    seals.note(info, honest.decoded);
    expect(seals.proof(CHANNEL, target, honest.rumor)).toBeDefined();
  });

  it("ignores non-Edit kinds, non-channel planes and decoded events without a seal", async () => {
    const target = await pin("original");
    const seals = new PinEditSeals();
    const message = await edit(target.rumor, "a plain message", 1, { kind: 9 });
    seals.note(info, message.decoded);
    const real = await edit(target.rumor, "an Edit", 2);
    seals.note({ ...info, type: "guestbook" }, real.decoded);
    seals.note({ ...info, type: "control" }, real.decoded);
    seals.note({ ...info, channelId: undefined }, real.decoded);
    const { seal: _seal, ...rehydrated } = real.decoded;
    seals.note(info, rehydrated);
    // A kind 3302 rumor without an `e` tag is not a valid Edit.
    const untargeted = await edit(target.rumor, "no target", 3);
    const bare = { ...untargeted.rumor, tags: untargeted.rumor.tags.filter((t) => t[0] !== "e") };
    seals.note(info, { ...untargeted.decoded, rumor: { ...bare, id: getEventHash(bare) } });
    expect(seals.size(CHANNEL)).toBe(0);
    // The same Edit on a channel plane is indexed.
    seals.note(info, real.decoded);
    expect(seals.size(CHANNEL)).toBe(1);
  });

  // Non-vacuity: evict by arrival order (delete the Map's first key) instead of rumor order. The channel then loses the
  // first Edit noted, which is the newest by rumor order, and the final assertion that it is still provable fails.
  it("keeps at most 512 Edit seals per channel, evicting by rumor order rather than arrival order", async () => {
    const seals = new PinEditSeals();
    const targets = await Promise.all(Array.from({ length: PIN_EDIT_SEALS_PER_CHANNEL + 1 }, (_, i) => pin(`m${i}`)));
    // Newest first: the first one noted is the newest by rumor order, the last one noted is the oldest.
    const edits: SealedEdit[] = [];
    for (let i = 0; i <= PIN_EDIT_SEALS_PER_CHANNEL; i++) {
      edits.push(await edit(targets[i].rumor, `e${i}`, 100_000 - i));
    }
    for (const sealed of edits) seals.note(info, sealed.decoded);
    expect(PIN_EDIT_SEALS_PER_CHANNEL).toBe(512);
    expect(seals.size(CHANNEL)).toBe(512);
    const newestFirstNoted = 0;
    const oldestLastNoted = PIN_EDIT_SEALS_PER_CHANNEL;
    expect(seals.proof(CHANNEL, targets[oldestLastNoted], edits[oldestLastNoted].rumor)).toBeUndefined();
    expect(seals.proof(CHANNEL, targets[newestFirstNoted], edits[newestFirstNoted].rumor)).toBeDefined();
    // Another channel has its own budget.
    expect(seals.size("cd".repeat(32))).toBe(0);
  });

  // Non-vacuity: drop the "not the newest of its original" preference so the lowest Edit overall is evicted (pure
  // rumor-order eviction). P1 is the oldest Edit by rumor order, so it is dropped and the P1 assertion fails.
  it("eviction never drops the newest Edit of an original while a superseded Edit is retained", async () => {
    const seals = new PinEditSeals();
    const x = await pin("busy original");
    const p = await pin("quiet pinned original");
    const p1 = await edit(p.rumor, "the only Edit of P", 10);
    seals.note(info, p1.decoded);
    const xEdits: SealedEdit[] = [];
    for (let i = 0; i < PIN_EDIT_SEALS_PER_CHANNEL + 1; i++) {
      const sealed = await edit(x.rumor, `x${i}`, 1_000 + i);
      xEdits.push(sealed);
      seals.note(info, sealed.decoded);
    }
    // 1 Edit of P plus 513 Edits of X were noted: two superseded Edits of X are gone, P1 and the newest X remain.
    expect(seals.size(CHANNEL)).toBe(512);
    expect(seals.proof(CHANNEL, p, p1.rumor)).toBeDefined();
    const newestX = xEdits[xEdits.length - 1];
    expect(seals.proof(CHANNEL, x, newestX.rumor)).toBeDefined();
    expect(seals.proof(CHANNEL, x, xEdits[0].rumor)).toBeUndefined();
    expect(seals.proof(CHANNEL, x, xEdits[1].rumor)).toBeUndefined();
    expect(seals.proof(CHANNEL, x, xEdits[2].rumor)).toBeDefined();
  });

  it("a duplicate Edit keeps the lowest wrap id", async () => {
    const target = await pin("original");
    const first = await edit(target.rumor, "corrected", 5);
    // The same rumor sealed again is a different seal (fresh nonce) delivered in another wrap.
    const second = await edit(target.rumor, "corrected", 5);
    const third = await edit(target.rumor, "corrected", 5);
    expect(second.rumor.id).toBe(first.rumor.id);
    expect(second.decoded.seal!.id).not.toBe(first.decoded.seal!.id);
    const seals = new PinEditSeals();
    seals.note(info, { ...first.decoded, wrapId: "99".repeat(32) });
    seals.note(info, { ...second.decoded, wrapId: "11".repeat(32) });
    seals.note(info, { ...third.decoded, wrapId: "55".repeat(32) });
    expect(seals.size(CHANNEL)).toBe(1);
    expect(seals.proof(CHANNEL, target, first.rumor)?.seal.id).toBe(second.decoded.seal!.id);
  });

  it("dropChannel and clear release every seal", async () => {
    const target = await pin("original");
    const seals = new PinEditSeals();
    const real = await edit(target.rumor, "corrected", 5);
    seals.note(info, real.decoded);
    expect(seals.proof(CHANNEL, target, real.rumor)).toBeDefined();
    seals.dropChannel(CHANNEL);
    expect(seals.size(CHANNEL)).toBe(0);
    expect(seals.proof(CHANNEL, target, real.rumor)).toBeUndefined();
    seals.note(info, real.decoded);
    seals.clear();
    expect(seals.size(CHANNEL)).toBe(0);
  });

  // Non-vacuity: an index that judged seals only through a purge finding the stored row keeps the seal of an Edit whose
  // row a store's own expiry timer removed, so every assertion below on a pruned seal would still find it.
  it("judges each seal by its signed Edit expiry, at note, at proof and on forgetExpired (CORD-08 §3)", async () => {
    const target = await pin("original");
    const seals = new PinEditSeals();
    const short = await edit(target.rumor, "short lived", 5, { expiration: 2_000 });
    const long = await edit(target.rumor, "long lived", 6, { expiration: 3_000, wrapId: "ee".repeat(32) });
    const permanent = await edit(target.rumor, "permanent", 7, { wrapId: "dd".repeat(32) });

    // An Edit already expired when it is noted is never recorded.
    seals.note(info, short.decoded, 2_000);
    expect(seals.size(CHANNEL)).toBe(0);

    // A noted seal yields a proof while live and is forgotten once a proof is asked for after its expiry.
    seals.note(info, short.decoded, 1_500);
    expect(seals.proof(CHANNEL, target, short.rumor, 1_999)).toBeDefined();
    expect(seals.proof(CHANNEL, target, short.rumor, 2_000)).toBeUndefined();
    expect(seals.size(CHANNEL)).toBe(0);

    // Noting another Edit forgets the channel's seals that expired by then.
    seals.note(info, short.decoded, 1_500);
    seals.note(info, long.decoded, 2_500);
    expect(seals.size(CHANNEL)).toBe(1);
    expect(seals.proof(CHANNEL, target, long.rumor, 2_500)).toBeDefined();

    // forgetExpired needs no stored row: it drops by signed expiry and keeps an Edit without one.
    seals.note(info, permanent.decoded, 2_500);
    seals.forgetExpired(2_999);
    expect(seals.size(CHANNEL)).toBe(2);
    seals.forgetExpired(3_000);
    expect(seals.size(CHANNEL)).toBe(1);
    expect(seals.proof(CHANNEL, target, long.rumor, 2_500)).toBeUndefined();
    expect(seals.proof(CHANNEL, target, permanent.rumor, 1e12)).toBeDefined();
  });
});
