import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import { spy } from "@std/testing/mock";
import type { NostrEvent } from "applesauce-core/helpers/event";
import {
  COMMUNITY_LIST_EVENT_MAX_BYTES,
  CommunityListUnknownError,
  ConcordCommunityListSync,
} from "../community-list-sync.ts";
import { canonicalJson, isCommunityLive } from "../../helpers/community-list.ts";
import { cyclicVault, recordRepack, restartedSync, signFragment, winners } from "./community-list-prefix.ts";
import { CommunityListFragments } from "../community-list-fragments.ts";
import { type CommunityListFragment, encodeCommunityListFragment } from "../../helpers/community-list-wire.ts";
import type { CommunityListCommunity } from "../../types.ts";
import type { ConcordDiagnostic } from "../diagnostics.ts";
import { deferred, Gate, gatedSigner } from "./test-utils.ts";

function entry(index: number): CommunityListCommunity {
  const id = index.toString(16).padStart(64, "0");
  const material = {
    community_id: id,
    owner: "11".repeat(32),
    owner_salt: "22".repeat(32),
    community_root: "33".repeat(32),
    root_epoch: 0,
    channels: [],
    relays: [],
    name: "room",
  };
  return { community_id: id, current: material, seed: material, added_at: 1 };
}
const document = (frags: number, entries: CommunityListCommunity[] = []): CommunityListFragment => ({
  frags,
  entries,
  tombstones: [],
});
async function fixture() {
  const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
  const events: NostrEvent[] = [];
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    events.push(event);
  });
  const signed = async (index: number, doc: CommunityListFragment, created_at = 1) =>
    signer.signEvent({
      kind: 33302,
      created_at,
      tags: [["d", String(index)]],
      content: await signer.nip44!.encrypt(await signer.getPublicKey(), encodeCommunityListFragment(doc)),
    });
  return { signer, events, sync, signed };
}

describe("fragment state and publication", () => {
  it("tracks mixed-age completeness and resolves count ties upward", () => {
    const fragments = new CommunityListFragments();
    fragments.receive({ index: 0, created_at: 3, id: "a", document: document(2, [entry(1)]) });
    expect(fragments.complete).toBe(false);
    fragments.receive({ index: 1, created_at: 2, id: "b", document: document(1, [entry(2)]) });
    expect(fragments.complete).toBe(true);
    fragments.receive({ index: 1, created_at: 3, id: "c", document: document(3, [entry(2)]) });
    expect(fragments.count).toBe(3);
    expect(fragments.complete).toBe(false);
    expect(fragments.document.entries).toHaveLength(2);
  });

  it("documentAll unions in-range and dormant fragments with the lowest index winning (D-20)", () => {
    const fragments = new CommunityListFragments();
    const [a, b, w] = [entry(1), entry(2), entry(3)];
    fragments.receive({ index: 0, created_at: 1, id: "a", document: { ...document(2, [a]), x: "zero" } });
    fragments.receive({ index: 1, created_at: 1, id: "b", document: { ...document(2, [b]), x: "one", y: 1 } });
    fragments.receive({ index: 3, created_at: 1, id: "c", document: { ...document(2, [w]), z: true } });
    const all = fragments.documentAll;
    expect(all.entries.map((e) => e.community_id).sort()).toEqual(
      [a, b, w].map((e) => e.community_id).sort(),
    );
    expect(all.x).toBe("zero");
    expect(all.y).toBe(1);
    expect(all.z).toBe(true);
    expect("frags" in all).toBe(false);
    expect(fragments.document.entries.map((e) => e.community_id).sort()).toEqual(
      [a, b].map((e) => e.community_id).sort(),
    );
    expect(fragments.document.z).toBeUndefined();
    expect(fragments.dormantResidue).toEqual([3]);
  });

  it("residue reports non-empty dormant fragments and memberships held in two in-range fragments", () => {
    const [a, b] = [entry(1), entry(2)];
    const held = (...versions: Array<[number, CommunityListFragment]>) => {
      const fragments = new CommunityListFragments();
      versions.forEach(([index, doc], i) => fragments.receive({ index, created_at: 1, id: `id${i}`, document: doc }));
      return fragments;
    };
    // An empty dormant document is not residue; one holding only an extra field is.
    const emptyDormant = held([0, document(1, [a])], [2, document(1)]);
    expect(emptyDormant.dormantResidue).toEqual([]);
    expect(emptyDormant.residue).toBe(false);
    const extraDormant = held([0, document(1, [a])], [2, { ...document(1), future: 1 }]);
    expect(extraDormant.dormantResidue).toEqual([2]);
    expect(extraDormant.residue).toBe(true);
    // A membership held in two in-range fragments is a duplicate.
    const twice = held([0, document(2, [a])], [1, document(2, [{ ...a, added_at: 2 }, b])]);
    expect(twice.duplicateResidue).toEqual([a.community_id]);
    expect(twice.dormantResidue).toEqual([]);
    expect(twice.residue).toBe(true);
    // A membership and its own tombstone in one fragment, and a dormant copy of an in-range membership, are not duplicates.
    const tombstone = { community_id: a.community_id, removed_at: 5 };
    const sameFragment = held([0, { ...document(1, [a]), tombstones: [tombstone] }]);
    expect(sameFragment.duplicateResidue).toEqual([]);
    expect(sameFragment.residue).toBe(false);
    const dormantCopy = held([0, document(1, [a])], [3, document(1, [a])]);
    expect(dormantCopy.duplicateResidue).toEqual([]);
    expect(dormantCopy.dormantResidue).toEqual([3]);
    // IN-04: a tombstone in one fragment and the old membership in another is a layout, not residue; a tombstone held
    // in two fragments still is.
    const split = held([0, { ...document(2), tombstones: [tombstone] }], [1, document(2, [a])]);
    expect(split.duplicateResidue).toEqual([]);
    expect(split.residue).toBe(false);
    const tombstonedTwice = held(
      [0, { ...document(2), tombstones: [tombstone] }],
      [1, { ...document(2, [b]), tombstones: [tombstone] }],
    );
    expect(tombstonedTwice.duplicateResidue).toEqual([a.community_id]);
  });

  it("a repack plan includes dormant memberships and empties every non-empty dormant index (D-20)", async () => {
    const fragments = new CommunityListFragments();
    const [a, b, w, v] = [entry(1), entry(2), entry(3), entry(4)];
    fragments.receive({ index: 0, created_at: 1, id: "a", document: document(2, [a]) });
    fragments.receive({ index: 1, created_at: 1, id: "b", document: document(2, [b]) });
    fragments.receive({ index: 3, created_at: 1, id: "c", document: document(2, [w]) });
    fragments.receive({ index: 5, created_at: 1, id: "d", document: document(2, [v]) });
    fragments.receive({ index: 6, created_at: 1, id: "e", document: document(2) });
    const plan = await fragments.repack({ entries: [], tombstones: [] }, async () => 100);
    const planned = [...plan.values()].flatMap((doc) => doc.entries.map((e) => e.community_id)).sort();
    expect(planned).toEqual([a, b, w, v].map((e) => e.community_id).sort());
    const count = plan.get(0)!.frags;
    expect(count).toBe(1);
    expect(plan.get(3)).toEqual({ frags: count, entries: [], tombstones: [] });
    expect(plan.get(5)).toEqual({ frags: count, entries: [], tombstones: [] });
    expect(plan.get(6)).toBeUndefined(); // already empty: nothing to publish there
  });

  it("a dormant membership never revives a community tombstoned in range (D-20)", async () => {
    const fragments = new CommunityListFragments();
    const w = entry(3);
    const tombstone = { community_id: w.community_id, removed_at: 5 };
    fragments.receive({ index: 0, created_at: 1, id: "a", document: { ...document(2), tombstones: [tombstone] } });
    fragments.receive({ index: 1, created_at: 1, id: "b", document: document(2) });
    fragments.receive({ index: 3, created_at: 1, id: "c", document: document(2, [w]) });
    const plan = await fragments.repack({ entries: [], tombstones: [] }, async () => 100);
    const drafts = [...plan.values()];
    const entries = drafts.flatMap((doc) => doc.entries);
    const tombstones = drafts.flatMap((doc) => doc.tombstones);
    expect(tombstones.map((t) => t.community_id)).toEqual([w.community_id]);
    expect(isCommunityLive(entries, tombstones, w.community_id)).toBe(false);
  });

  it("allows scoped writes during incomplete reads and keeps remote memberships", async () => {
    const { sync, events, signed } = await fixture();
    await sync.receive(await signed(0, document(2, [entry(1)])));
    await sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
    expect(events).toHaveLength(1);
    expect(events[0].kind).toBe(33302);
    expect(sync.fragments.document.entries).toHaveLength(2);
    expect(sync.fragments.complete).toBe(false);
    await expect(sync.repack({ entries: [], tombstones: [] })).rejects.toThrow("incomplete");
  });

  it("refuses locked newest copies and stale encrypted editions", async () => {
    const { sync, signed } = await fixture();
    await sync.receive(await signed(0, document(1, [entry(1)]), 1));
    const newer = await signed(0, document(1, [entry(2)]), 2);
    await sync.receive(newer, false);
    await expect(sync.write({ entries: [entry(3)], tombstones: [] }, [entry(3).community_id])).rejects.toThrow(
      "unread",
    );
    expect(await sync.receive(await signed(0, document(1), 1))).toBe(false);
    await sync.receive(newer);
    expect(sync.fragments.document.entries[0].community_id).toBe(entry(2).community_id);
  });

  it("timestamps every coordinate strictly above the known winner", async () => {
    const { sync, signed, events } = await fixture();
    const future = Math.floor(Date.now() / 1000) + 100;
    await sync.receive(await signed(0, document(1, [entry(1)]), future));
    await sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
    await sync.write({ entries: [entry(3)], tombstones: [] }, [entry(3).community_id]);
    expect(events.map((e) => e.created_at)).toEqual([future + 1, future + 2]);
  });

  it("empties dropped coordinates and carries extensions on fragment zero", async () => {
    const { sync, signed, events } = await fixture();
    await sync.receive(await signed(0, { ...document(2, [entry(1)]), future: { value: "zero" } }));
    await sync.receive(await signed(1, { ...document(2, [entry(2)]), future: { value: "one" }, other: true }));
    await sync.repack({ entries: [], tombstones: [] });
    expect(events.length).toBeGreaterThanOrEqual(2);
    expect(sync.fragments.count).toBe(1);
    expect(sync.fragments.document.entries).toHaveLength(2);
    expect(sync.fragments.document.future).toEqual({ value: "zero" });
    expect(sync.fragments.document.other).toBe(true);
    expect(sync.fragments.get(1)!.document).toEqual(document(1));
  });

  it("splits using final encrypted signed event sizes without losing records", async () => {
    const { sync, events } = await fixture();
    const entries = Array.from({ length: 100 }, (_, i) => {
      const value = entry(i + 1);
      return { ...value, future: "x".repeat(500) };
    });
    await sync.write({ entries, tombstones: [] }, entries.map((e) => e.community_id));
    expect(events.length).toBeGreaterThan(1);
    expect(sync.fragments.complete).toBe(true);
    expect(sync.fragments.document.entries).toHaveLength(100);
    for (const event of events) {
      expect(new TextEncoder().encode(JSON.stringify(event)).length).toBeLessThanOrEqual(56 * 1024);
    }
  });
});

it("retires a draft when a newer fragment arrives during signing", async () => {
  const { signer, signed } = await fixture();
  const old = await signed(0, document(1, [entry(1)]));
  const newer = await signed(0, document(1, [entry(2)]), 100);
  let release!: () => void;
  let entered!: () => void;
  const waiting = new Promise<void>((resolve) => {
    entered = resolve;
  });
  const barrier = new Promise<void>((resolve) => {
    release = resolve;
  });
  const published: NostrEvent[] = [];
  const delayed = {
    getPublicKey: () => signer.getPublicKey(),
    nip44: signer.nip44,
    signEvent: async (draft: Parameters<typeof signer.signEvent>[0]) => {
      entered();
      await barrier;
      return signer.signEvent(draft);
    },
  };
  const sync = new ConcordCommunityListSync(delayed, async (event) => {
    published.push(event);
  });
  await sync.receive(old);
  const write = sync.write({ entries: [entry(3)], tombstones: [] }, [entry(3).community_id]);
  await waiting;
  await sync.receive(newer);
  release();
  await expect(write).rejects.toThrow("changed during signing");
  expect(published).toEqual([]);
  expect(sync.fragments.get(0)?.id).toBe(newer.id);
});

it("abandon() lets the next write run while an earlier write waits on the signer, and the earlier write publishes nothing once refused (LIST-05)", async () => {
  const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
  const entered = deferred<void>();
  const hung = deferred<void>();
  let signs = 0;
  const parking = {
    getPublicKey: () => signer.getPublicKey(),
    nip44: signer.nip44,
    signEvent: async (draft: Parameters<typeof signer.signEvent>[0]) => {
      if (signs++ === 0) {
        entered.resolve();
        await hung.promise; // a signer prompt nobody answers, until the test releases it
      }
      return signer.signEvent(draft);
    },
  };
  const published: NostrEvent[] = [];
  const sync = new ConcordCommunityListSync(parking, async (event) => {
    published.push(event);
  });
  let current = true;
  const first = sync.write({ entries: [entry(1)], tombstones: [] }, [entry(1).community_id], () => {
    if (!current) throw new Error("lane closed");
  });
  const outcome = first.then(() => "published", (error: Error) => error.message);
  await entered.promise;
  // Without abandon() the next write queues behind the parked one and never starts.
  sync.abandon();
  current = false;
  await sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
  expect(published).toHaveLength(1);
  expect(sync.fragments.document.entries.map((e) => e.community_id)).toEqual([entry(2).community_id]);
  hung.resolve();
  expect(await outcome).not.toBe("published");
  expect(published).toHaveLength(1); // the abandoned write published nothing
});

it("keeps every membership readable after every acknowledged prefix of a cyclic repack", async () => {
  const { signer, signed } = await fixture();
  const all = Array.from({ length: 8 }, (_, i) => ({ ...entry(i + 1), future: "x".repeat(8000) }));
  const old = [
    await signed(0, document(2, all.filter((_, index) => index % 2 === 0)), Math.floor(Date.now() / 1000) + 100),
    await signed(1, document(2, all.filter((_, index) => index % 2 === 1))),
  ];
  const observer = new ConcordCommunityListSync(signer, async () => {});
  for (const event of old) await observer.receive(event);
  let acknowledged = 0;
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    await observer.receive(event);
    acknowledged++;
    expect(observer.fragments.document.entries.map((item) => item.community_id)).toEqual(
      all.map((item) => item.community_id),
    );
  });
  for (const event of old) await sync.receive(event);
  await sync.repack({ entries: [], tombstones: [] });
  expect(acknowledged).toBeGreaterThan(2);
  expect(sync.fragments.count).toBe(2);
  expect(sync.fragments.complete).toBe(true);
  for (const index of sync.fragments.indexes.filter((index) => index >= 2)) {
    expect(sync.fragments.get(index)?.document.entries).toEqual([]);
  }
});

it("does not rewrite source buckets after a staging publication fails", async () => {
  const { signer, signed } = await fixture();
  const old = [await signed(0, document(2, [entry(1)])), await signed(1, document(2, [entry(2)]))];
  const attempted: NostrEvent[] = [];
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    attempted.push(event);
    throw new Error("relay refused");
  });
  for (const event of old) await sync.receive(event);
  await expect(sync.repack({ entries: [], tombstones: [] })).rejects.toThrow("relay refused");
  expect(attempted).toHaveLength(1);
  expect(attempted[0].tags).toContainEqual(["d", "2"]);
  expect(sync.fragments.document.entries).toHaveLength(2);
  expect(sync.fragments.get(0)?.id).toBe(old[0].id);
  expect(sync.fragments.get(1)?.id).toBe(old[1].id);
});

it("retires a staged repack when another device adds content between phases", async () => {
  const { signer, signed } = await fixture();
  const old = await signed(0, document(1, [entry(1)]));
  const concurrent = await signed(0, document(2, [entry(1), entry(2)]), Math.floor(Date.now() / 1000) + 1000);
  let publications = 0;
  const sync = new ConcordCommunityListSync(signer, async () => {
    publications++;
    if (publications === 1) await sync.receive(concurrent);
  });
  await sync.receive(old);
  await expect(sync.repack({ entries: [], tombstones: [] })).rejects.toThrow("changed during signing");
  expect(publications).toBe(1);
  expect(sync.fragments.get(0)?.id).toBe(concurrent.id);
  expect(sync.fragments.document.entries).toHaveLength(2);
});

describe("repack restart prefixes (LIST-04, D-17, D-20)", () => {
  const empty = { entries: [], tombstones: [] };
  const signer = () => new PrivateKeySigner(new Uint8Array(32).fill(1));
  async function matrix() {
    const owner = signer();
    const { old, all, tombstoned } = await cyclicVault(owner);
    const original = await restartedSync(owner, old);
    const published = await recordRepack(owner, old);
    expect(published).toHaveLength(8);
    return { owner, old, all, tombstoned, original, published };
  }
  /** Every membership present with canonically equal key material, the tombstone kept and its community dead. */
  function expectIntact(
    sync: ConcordCommunityListSync,
    original: ConcordCommunityListSync,
    tombstoned: string,
    where: string,
  ) {
    const document = sync.fragments.document;
    expect(document.entries.map((e) => e.community_id).sort(), where).toEqual(
      original.fragments.document.entries.map((e) => e.community_id).sort(),
    );
    for (const before of original.fragments.document.entries) {
      const after = document.entries.find((e) => e.community_id === before.community_id)!;
      expect(canonicalJson(after.current), where).toBe(canonicalJson(before.current));
      expect(canonicalJson(after.seed), where).toBe(canonicalJson(before.seed));
    }
    expect(document.tombstones.map((t) => t.community_id), where).toContain(tombstoned);
    expect(isCommunityLive(document.entries, document.tombstones, tombstoned), where).toBe(false);
  }

  it("every acknowledged prefix of a repack is a complete List that keeps every membership, key and tombstone (D-17)", async () => {
    const { owner, old, tombstoned, original, published } = await matrix();
    for (let k = 0; k <= published.length; k++) {
      const sync = await restartedSync(owner, winners([...old, ...published.slice(0, k)]));
      expect(sync.status.knowledge, `prefix ${k}`).toBe("complete");
      expect(sync.fragments.complete, `prefix ${k}`).toBe(true);
      expectIntact(sync, original, tombstoned, `prefix ${k}`);
    }
  });

  it("a repair repack from every acknowledged prefix converges to a clean List with no dormant content or duplicates (LIST-04)", async () => {
    const { owner, old, tombstoned, original, published } = await matrix();
    const finished = await restartedSync(owner, winners([...old, ...published]));
    expect(finished.fragments.residue).toBe(false);
    for (let k = 0; k <= published.length; k++) {
      const sync = await restartedSync(owner, winners([...old, ...published.slice(0, k)]));
      await sync.repack(empty);
      const where = `prefix ${k}`;
      expect(sync.status.knowledge, where).toBe("complete");
      expect(sync.fragments.count, where).toBe(finished.fragments.count);
      expect(sync.fragments.dormantResidue, where).toEqual([]);
      expect(sync.fragments.duplicateResidue, where).toEqual([]);
      expectIntact(sync, original, tombstoned, where);
    }
  });

  it("a record one fragment behind the relay restores the same complete List at every prefix (LIST-04)", async () => {
    const { owner, old, tombstoned, original, published } = await matrix();
    for (let k = 1; k <= published.length; k++) {
      const relay = winners([...old, ...published.slice(0, k)]);
      const sync = await restartedSync(owner, relay, winners([...old, ...published.slice(0, k - 1)]));
      expect(sync.status.knowledge, `prefix ${k}`).toBe("complete");
      expectIntact(sync, original, tombstoned, `prefix ${k}`);
      await sync.repack(empty);
      expect(sync.fragments.dormantResidue, `prefix ${k}`).toEqual([]);
      expect(sync.fragments.duplicateResidue, `prefix ${k}`).toEqual([]);
      expectIntact(sync, original, tombstoned, `repaired ${k}`);
    }
  });

  it("staging copies declare the old count and the count first rises at the copy stage (D-17)", async () => {
    const { owner, published } = await matrix();
    const declared = await Promise.all(
      published.map(async (event) => ({
        d: event.tags.find((tag) => tag[0] === "d")![1],
        frags: JSON.parse(await owner.nip44!.decrypt(event.pubkey, event.content)).frags as number,
      })),
    );
    expect(declared[0]).toEqual({ d: "2", frags: 2 }); // staging declares the old governing count
    expect(declared[1]).toEqual({ d: "3", frags: 2 });
    expect(declared[2]).toEqual({ d: "0", frags: 4 }); // the first copy raises the count: d0..d3 are all held
    expect(declared[3]).toEqual({ d: "1", frags: 4 });
    expect(declared.slice(4).map((item) => item.frags)).toEqual([2, 2, 2, 2]);
  });

  it("a repack empties a non-empty dormant fragment beyond its staging range (LIST-08)", async () => {
    const owner = signer();
    const [a, w] = [entry(1), entry(2)];
    const old = [await signFragment(owner, 0, document(1, [a]), 2), await signFragment(owner, 5, document(1, [w]), 1)];
    const published: NostrEvent[] = [];
    const sync = await restartedSync(owner, old, [], {
      publish: async (event) => {
        published.push(event);
      },
    });
    expect(sync.fragments.dormantResidue).toEqual([5]);
    await sync.repack(empty);
    expect(sync.fragments.dormantResidue).toEqual([]);
    expect(sync.fragments.get(5)?.document).toEqual(document(1));
    expect(sync.fragments.document.entries.map((e) => e.community_id).sort()).toEqual(
      [a, w].map((e) => e.community_id).sort(),
    );
    expect(published.map((e) => e.tags.find((tag) => tag[0] === "d")![1])).toContain("5");
  });

  it("a locked dormant copy blocks a repack and nothing is published (D-05)", async () => {
    const { signer: owner, sync, events, signed } = await fixture();
    await sync.receive(await signed(0, document(1, [entry(1)]), 2));
    await sync.receive(await signed(4, document(1, [entry(2)]), 1), false);
    await expect(sync.repack(empty)).rejects.toThrow("unread");
    expect(events).toHaveLength(0);
    expect(owner).toBeDefined();
  });

  it("missing declared indexes keep a List partial and a repack is refused (D-05)", async () => {
    const owner = signer();
    const published: NostrEvent[] = [];
    const old = [
      await signFragment(owner, 0, document(3, [entry(1)]), 1),
      await signFragment(owner, 1, document(3, [entry(2)]), 1),
    ];
    const sync = await restartedSync(owner, old, [], {
      publish: async (event) => {
        published.push(event);
      },
    });
    expect(sync.status.knowledge).toBe("partial");
    await expect(sync.repack(empty)).rejects.toThrow("incomplete");
    expect(published).toHaveLength(0);
    expect(sync.fragments.get(2)).toBeUndefined(); // a missing index is unseen, never inferred empty
  });

  it("a repack stops before its next stage when a fragment arrives at a dormant index (D-06)", async () => {
    const { signer: owner, signed } = await fixture();
    const old = [await signed(0, document(2, [entry(1)])), await signed(1, document(2, [entry(2)]))];
    const arrival = await signed(5, document(2, [entry(3)]), Math.floor(Date.now() / 1000) + 1000);
    let publications = 0;
    const sync = new ConcordCommunityListSync(owner, async () => {
      publications++;
      if (publications === 1) await sync.receive(arrival);
    });
    for (const event of old) await sync.receive(event);
    await expect(sync.repack(empty)).rejects.toThrow("changed during signing");
    expect(publications).toBe(1);
    expect(sync.fragments.get(5)?.id).toBe(arrival.id);
  });

  it("a repack prompts the signer for nothing when the fragment record cannot be stored (D-08)", async () => {
    const owner = signer();
    const old = [
      await signFragment(owner, 0, document(2, [entry(1)]), 1),
      await signFragment(owner, 1, document(2, [entry(2)]), 1),
    ];
    const sign = spy(owner, "signEvent");
    const encrypt = spy(owner.nip44!, "encrypt");
    const published: NostrEvent[] = [];
    const sync = await restartedSync(owner, old, [], {
      persist: () => Promise.reject(new Error("disk full")),
      publish: async (event) => {
        published.push(event);
      },
    });
    await expect(sync.repack(empty)).rejects.toThrow("disk full");
    expect(sign.calls).toHaveLength(0);
    expect(encrypt.calls).toHaveLength(0);
    expect(published).toHaveLength(0);
  });
});

describe("completed-read gate (D-15, D-23)", () => {
  async function gated(options: { requireCompletedRead?: boolean } = { requireCompletedRead: true }) {
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const sign = spy(signer, "signEvent");
    const nip44 = spy(signer.nip44!, "encrypt");
    const events: NostrEvent[] = [];
    const sync = new ConcordCommunityListSync(signer, async (event) => {
      events.push(event);
    }, options);
    // A second signer with the same key, so spies on `signer` only count the sync's own calls.
    const other = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const signed = async (index: number, doc: CommunityListFragment, created_at = 1) =>
      other.signEvent({
        kind: 33302,
        created_at,
        tags: [["d", String(index)]],
        content: await other.nip44!.encrypt(await other.getPublicKey(), encodeCommunityListFragment(doc)),
      });
    return { signer, sign, nip44, events, sync, signed };
  }

  it("refuses a first write before any completed read", async () => {
    const { sync, sign, nip44, events } = await gated();
    await expect(sync.write({ entries: [entry(1)], tombstones: [] }, [entry(1).community_id])).rejects.toThrow(
      CommunityListUnknownError,
    );
    await expect(sync.repack({ entries: [entry(1)], tombstones: [] })).rejects.toThrow(CommunityListUnknownError);
    expect(sign.calls).toHaveLength(0);
    expect(nip44.calls).toHaveLength(0);
    expect(events).toHaveLength(0);
    expect(sync.status).toEqual({ knowledge: "unknown", pending: true });
  });

  it("allows the first fragment once a completed read confirms an empty list", async () => {
    const { sync, signer, events } = await gated();
    sync.markReadComplete(sync.beginRead());
    expect(sync.status.knowledge).toBe("confirmed-empty");
    await sync.write({ entries: [entry(1)], tombstones: [] }, [entry(1).community_id]);
    expect(events).toHaveLength(1);
    const plain = await signer.nip44!.decrypt(await signer.getPublicKey(), events[0].content);
    expect(JSON.parse(plain).frags).toBe(1);
    expect(sync.status).toEqual({ knowledge: "complete", pending: false });
  });

  it("keeps the declared count when only fragment zero is held", async () => {
    const { sync, signer, events, signed } = await gated();
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(0, document(3, [entry(1)])));
    expect(sync.status.knowledge).toBe("partial");
    await sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
    expect(events).toHaveLength(1);
    const plain = await signer.nip44!.decrypt(await signer.getPublicKey(), events[0].content);
    expect(JSON.parse(plain).frags).toBe(3);
  });

  it("refuses a write over a locked fragment at index 2 when nothing is held at index 0 (LIST-02)", async () => {
    const { sync, sign, nip44, events, signed } = await gated();
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(2, document(3, [entry(1)])), false);
    expect(sync.status).toEqual({ knowledge: "partial", pending: false });
    await expect(sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id])).rejects.toThrow(
      CommunityListUnknownError,
    );
    expect(sign.calls).toHaveLength(0);
    expect(nip44.calls).toHaveLength(0);
    expect(events).toHaveLength(0);
    expect(sync.status).toEqual({ knowledge: "partial", pending: true });
  });

  it("still refuses after a completed read while every held fragment is locked", async () => {
    const { sync, events, signed } = await gated();
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(2, document(3, [entry(1)])), false);
    await expect(sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id])).rejects.toThrow(
      CommunityListUnknownError,
    );
    expect(events).toHaveLength(0);
  });

  it("holds a write while a locked declaration is newer than the decrypted fragments (CR-01, LIST-02)", async () => {
    const { sync, signer, sign, events, signed } = await gated();
    sync.markReadComplete(sync.beginRead());
    const one = await signed(1, document(3, [entry(2)]), 20);
    const two = await signed(2, document(3, [entry(3)]), 20);
    await sync.receive(await signed(0, document(1, [entry(1)]), 10)); // decrypted, older frags: 1
    await sync.receive(one, false); // locked, newer frags: 3
    await sync.receive(two, false); // locked
    expect(sync.status).toEqual({ knowledge: "partial", pending: false });
    await expect(sync.write({ entries: [entry(9)], tombstones: [] }, [entry(9).community_id])).rejects.toThrow(
      CommunityListUnknownError,
    );
    expect(sign.calls).toHaveLength(0);
    expect(events).toHaveLength(0);
    expect(sync.status).toEqual({ knowledge: "partial", pending: true });
    await sync.receive(one);
    await sync.receive(two);
    expect(sync.status.knowledge).toBe("complete");
    await sync.write({ entries: [entry(9)], tombstones: [] }, [entry(9).community_id]);
    expect(events).toHaveLength(1);
    const plain = await signer.nip44!.decrypt(await signer.getPublicKey(), events[0].content);
    expect(JSON.parse(plain).frags).toBe(3);
  });

  it("treats fragments held before clearReadEvidence as unknown until a completed read is recorded (CR-01)", async () => {
    const { sync, signer, sign, events, signed } = await gated();
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(0, document(1, [entry(1)])));
    expect(sync.status).toEqual({ knowledge: "complete", pending: false });
    sync.clearReadEvidence(); // a new start: what the previous one decrypted is not evidence of the relay copy
    expect(sync.status).toEqual({ knowledge: "unknown", pending: false });
    await expect(sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id])).rejects.toThrow(
      CommunityListUnknownError,
    );
    await expect(sync.repack({ entries: [entry(2)], tombstones: [] })).rejects.toThrow(CommunityListUnknownError);
    expect(sign.calls).toHaveLength(0);
    expect(events).toHaveLength(0);
    expect(sync.status).toEqual({ knowledge: "unknown", pending: true });
    expect(sync.markReadComplete(sync.beginRead())).toBe(true);
    await sync.write({ entries: [entry(1), entry(2)], tombstones: [] }, [entry(2).community_id]);
    expect(events).toHaveLength(1);
    const plain = await signer.nip44!.decrypt(await signer.getPublicKey(), events[0].content);
    expect(JSON.parse(plain).entries).toHaveLength(2);
    expect(sync.status).toEqual({ knowledge: "complete", pending: false });
  });

  it("refuses to record a read while a fragment that failed to be received is outstanding (CR-01, CR-02)", async () => {
    const { signer, signed } = await gated();
    let fail = true;
    const flaky = Object.assign(Object.create(signer), {
      getPublicKey: () => fail ? Promise.reject(new Error("bunker reconnecting")) : signer.getPublicKey(),
    }) as PrivateKeySigner;
    const sync = new ConcordCommunityListSync(flaky, async () => {}, { requireCompletedRead: true });
    sync.markReadComplete(sync.beginRead());
    expect(sync.status.knowledge).toBe("confirmed-empty");
    const failed = await signed(1, document(2, [entry(1)]));
    const token = sync.beginRead();
    await expect(sync.receive(failed, false)).rejects.toThrow("reconnecting");
    expect(sync.status.knowledge).toBe("unknown"); // the failed fragment may be the newest declaration
    fail = false;
    expect(sync.markReadComplete(token)).toBe(false); // the failure came after the token was issued
    // A new read that does not return the failed fragment still cannot record: it is retained, not forgotten.
    expect(sync.unreceived.map((event) => event.id)).toEqual([failed.id]);
    expect(sync.markReadComplete(sync.beginRead())).toBe(false);
    expect(sync.status.knowledge).toBe("unknown");
    const next = sync.beginRead();
    await sync.receive(failed, false);
    expect(sync.unreceived).toHaveLength(0);
    expect(sync.markReadComplete(next)).toBe(true);
    expect(sync.status.knowledge).toBe("partial");
  });

  it("never records a read that began before a later clear or read (CR-01)", async () => {
    const { sync } = await gated();
    const first = sync.beginRead();
    const second = sync.beginRead(); // for example the retry duty's re-read, while the first read is still open
    expect(sync.markReadComplete(first)).toBe(false);
    expect(sync.status.knowledge).toBe("unknown");
    sync.clearReadEvidence(); // for example stop()
    expect(sync.markReadComplete(second)).toBe(false);
    expect(sync.markReadComplete(sync.beginRead())).toBe(true);
    expect(sync.status.knowledge).toBe("confirmed-empty");
  });

  it("refuses a write under a locked newer declaration even when the gate is not requested", async () => {
    const { sync, events, signed } = await gated({});
    await sync.receive(await signed(0, document(1, [entry(1)]), 10));
    await sync.receive(await signed(1, document(3, [entry(2)]), 20), false);
    await expect(sync.write({ entries: [entry(9)], tombstones: [] }, [entry(9).community_id])).rejects.toThrow(
      "unread",
    );
    expect(events).toHaveLength(0);
  });

  it("treats held ciphertext as unread even when the gate is not requested", async () => {
    const { sync, events, signed } = await gated({});
    await sync.receive(await signed(2, document(3, [entry(1)])), false);
    await expect(sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id])).rejects.toThrow(
      "unread",
    );
    expect(events).toHaveLength(0);
  });

  it("writes without a completed read when the gate is not requested", async () => {
    const { sync, signer, events } = await gated({});
    await sync.write({ entries: [entry(1)], tombstones: [] }, [entry(1).community_id]);
    expect(events).toHaveLength(1);
    const plain = await signer.nip44!.decrypt(await signer.getPublicKey(), events[0].content);
    expect(JSON.parse(plain).frags).toBe(1);
  });

  it("a write whose read evidence is withdrawn while it signs publishes nothing (D-31)", async () => {
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const gate = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const published: NostrEvent[] = [];
    const sync = new ConcordCommunityListSync(gatedSigner(signer, { signEvent: gate }), async (event) => {
      published.push(event);
    }, { requireCompletedRead: true });
    expect(sync.markReadComplete(sync.beginRead())).toBe(true);
    expect(sync.status.knowledge).toBe("confirmed-empty");
    const write = sync.write({ entries: [entry(1)], tombstones: [] }, [entry(1).community_id]);
    const signing = await gate.next();
    sync.clearReadEvidence(); // for example stop(), or a fragment that failed to authenticate
    signing.release();
    await expect(write).rejects.toThrow(CommunityListUnknownError);
    expect(published).toHaveLength(0);
    expect(sync.status.pending).toBe(true);
  });

  it("a write refused between fragment signatures asks the signer for nothing more (01-16 Phase 3 note)", async () => {
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    let signs = 0;
    let keys = 0;
    const counting = {
      getPublicKey: () => (keys++, signer.getPublicKey()),
      nip44: signer.nip44,
      signEvent: (draft: Parameters<typeof signer.signEvent>[0]) => {
        signs++;
        return signer.signEvent(draft);
      },
    };
    const published: NostrEvent[] = [];
    const sync = new ConcordCommunityListSync(counting, async (event) => {
      published.push(event);
    });
    const entries = Array.from({ length: 100 }, (_, i) => ({ ...entry(i + 1), future: "x".repeat(500) }));
    const refused = new Error("lifecycle ended");
    // Refuse once the first fragment is signed, as stop() does to a routed write already preparing.
    const write = sync.write({ entries, tombstones: [] }, entries.map((e) => e.community_id), () => {
      if (signs > 0) throw refused;
    });
    await expect(write).rejects.toBe(refused);
    expect(signs).toBe(1);
    expect(keys).toBe(1);
    expect(published).toHaveLength(0);
  });

  it("emits status only on change", async () => {
    const { sync } = await gated();
    const seen: string[] = [];
    const sub = sync.status$.subscribe((status) => seen.push(`${status.knowledge}/${status.pending}`));
    const token = sync.beginRead();
    sync.markReadComplete(token);
    sync.markReadComplete(token);
    sub.unsubscribe();
    expect(seen).toEqual(["unknown/false", "confirmed-empty/false"]);
  });
});

describe("fragment persistence seam (LIST-03)", () => {
  type Snapshot = { readonly events: readonly NostrEvent[]; readonly count?: number };
  const wait = (ms: number = 25) => new Promise<void>((resolve) => setTimeout(resolve, ms));
  const idsOf = (events: readonly NostrEvent[]) => events.map((event) => event.id);

  async function seam(
    options: { persist?: (snapshot: Snapshot) => Promise<void>; signer?: PrivateKeySigner } = {},
  ) {
    const signer = options.signer ?? new PrivateKeySigner(new Uint8Array(32).fill(1));
    const events: NostrEvent[] = [];
    const diagnostics: ConcordDiagnostic[] = [];
    const snapshots: Snapshot[] = [];
    const sync = new ConcordCommunityListSync(signer, async (event) => {
      events.push(event);
    }, {
      requireCompletedRead: true,
      persist: async (snapshot) => {
        snapshots.push(snapshot);
        await options.persist?.(snapshot);
      },
      onDiagnostic: (diagnostic) => diagnostics.push(diagnostic),
    });
    const signed = async (index: number, doc: CommunityListFragment, created_at = 1, by: PrivateKeySigner = signer) =>
      by.signEvent({
        kind: 33302,
        created_at,
        tags: [["d", String(index)]],
        content: await by.nip44!.encrypt(await by.getPublicKey(), encodeCommunityListFragment(doc)),
      });
    return { signer, events, diagnostics, snapshots, sync, signed };
  }

  it("restore() keeps stored winners locked and never counts them as read evidence (D-04)", async () => {
    const { sync, events, signed } = await seam();
    const a = await signed(0, document(2, [entry(1)]));
    const b = await signed(1, document(2, [entry(2)]));
    const result = await sync.restore([a, b]);
    expect(result.dropped).toBe(0);
    expect(idsOf(result.restored)).toEqual([a.id, b.id]);
    expect(sync.status).toEqual({ knowledge: "unknown", pending: false });
    expect(sync.locked).toBe(true);
    expect(sync.fragments.indexes).toEqual([]);
    const write = () => sync.write({ entries: [entry(3)], tombstones: [] }, [entry(3).community_id]);
    await expect(write()).rejects.toThrow(CommunityListUnknownError);
    expect(events).toHaveLength(0);
    expect(sync.status).toEqual({ knowledge: "unknown", pending: true });
    // A completed read alone does not release the write: the restored copies are still locked ciphertext.
    expect(sync.markReadComplete(sync.beginRead())).toBe(true);
    await expect(write()).rejects.toThrow(CommunityListUnknownError);
    expect(events).toHaveLength(0);
    await sync.receive(a);
    await sync.receive(b);
    expect(sync.locked).toBe(false);
    await write();
    expect(events).toHaveLength(1);
  });

  it("without requireCompletedRead, restored copies count like held fragments and permit a write once decrypted (IN-02)", async () => {
    const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const events: NostrEvent[] = [];
    const sync = new ConcordCommunityListSync(signer, async (event) => void events.push(event));
    const stored = await signFragment(signer, 0, document(1, [entry(1)]), 1);
    await sync.restore([stored]);
    expect(sync.status.knowledge).toBe("partial");
    await sync.receive(stored);
    expect(sync.status.knowledge).toBe("complete");
    await sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
    expect(events).toHaveLength(1);
  });

  it("restore() drops forged, foreign, wrong-kind and non-canonical events and reports one fragment-restore diagnostic (D-03)", async () => {
    const { signer, sync, diagnostics, signed } = await seam();
    const stranger = new PrivateKeySigner(new Uint8Array(32).fill(2));
    const good = await signed(3, document(1, [entry(1)]));
    const valid = await signed(0, document(1, [entry(2)]));
    const tampered = { ...valid, content: valid.content.slice(0, -1) + (valid.content.endsWith("A") ? "B" : "A") };
    const foreign = await signed(0, document(1, [entry(3)]), 1, stranger);
    const wrongKind = await signer.signEvent({
      kind: 13302,
      created_at: 1,
      tags: [["d", "0"]],
      content: valid.content,
    });
    const padded = await signer.signEvent({ kind: 33302, created_at: 1, tags: [["d", "01"]], content: valid.content });
    const twoTags = await signer.signEvent({
      kind: 33302,
      created_at: 1,
      tags: [["d", "1"], ["d", "2"]],
      content: valid.content,
    });
    const result = await sync.restore([tampered, foreign, wrongKind, padded, twoTags, good]);
    expect(result.dropped).toBe(5);
    expect(idsOf(result.restored)).toEqual([good.id]);
    expect(diagnostics).toHaveLength(1);
    expect(diagnostics[0].stage).toBe("fragment-restore");
    // The diagnostic states a count, never ids or content.
    expect(String((diagnostics[0].error as Error).message)).toContain("5");
    expect(String((diagnostics[0].error as Error).message)).not.toContain(good.id);
  });

  it("restore() keeps the NIP-01 winner when a record holds two copies of one index (D-03)", async () => {
    const { sync, diagnostics, signed } = await seam();
    const old = await signed(0, document(1, [entry(1)]), 1);
    const newer = await signed(0, document(1, [entry(2)]), 2);
    expect(idsOf((await sync.restore([old, newer])).restored)).toEqual([newer.id]);
    const second = await seam();
    expect(idsOf((await second.sync.restore([newer, old])).restored)).toEqual([newer.id]);
    // Equal created_at: the lower id wins, whichever order the record holds them in.
    const tieA = await signed(1, document(1, [entry(3)]), 5);
    const tieB = await signed(1, document(1, [entry(4)]), 5);
    const lowest = tieA.id < tieB.id ? tieA : tieB;
    expect(idsOf((await sync.restore([tieA, tieB])).restored)).toEqual([lowest.id]);
    expect(idsOf((await second.sync.restore([tieB, tieA])).restored)).toEqual([lowest.id]);
    // Restoring an event already held is neither dropped nor a status change.
    const before = sync.status;
    const again = await sync.restore([newer]);
    expect(again.dropped).toBe(0);
    expect(idsOf(again.restored)).toEqual([newer.id]);
    expect(sync.status).toEqual(before);
    expect(diagnostics).toHaveLength(0);
  });

  it("restore() refuses everything without side effects when the signer cannot name its key (D-03)", async () => {
    const { signer, sync, diagnostics, signed } = await seam();
    const event = await signed(0, document(1, [entry(1)]));
    let fail = false;
    const flaky = Object.assign(Object.create(signer), {
      getPublicKey: () => fail ? Promise.reject(new Error("bunker reconnecting")) : signer.getPublicKey(),
    }) as PrivateKeySigner;
    const reported: ConcordDiagnostic[] = [];
    const subject = new ConcordCommunityListSync(flaky, async () => {}, {
      requireCompletedRead: true,
      onDiagnostic: (diagnostic) => reported.push(diagnostic),
    });
    expect(subject.markReadComplete(subject.beginRead())).toBe(true);
    expect(subject.status.knowledge).toBe("confirmed-empty");
    fail = true;
    const result = await subject.restore([event, event]);
    expect(result).toEqual({ restored: [], dropped: 2 });
    expect(reported).toHaveLength(1);
    expect(reported[0].stage).toBe("fragment-restore");
    expect(subject.unreceived).toHaveLength(0);
    expect(subject.status).toEqual({ knowledge: "confirmed-empty", pending: false });
    expect(subject.locked).toBe(false);
    expect(sync.locked).toBe(false);
    expect(diagnostics).toHaveLength(0);
    fail = false;
    expect(subject.markReadComplete(subject.beginRead())).toBe(true); // the read evidence was never touched
  });

  it("a restored fragment decrypts on an explicit receive and a newer relay copy replaces it (D-04)", async () => {
    const { sync, signed } = await seam();
    const stored = await signed(0, document(1, [entry(1)]), 1);
    await sync.restore([stored]);
    expect(sync.locked).toBe(true);
    expect(await sync.receive(stored)).toBe(true);
    expect(sync.locked).toBe(false);
    expect(sync.fragments.get(0)?.id).toBe(stored.id);
    const newer = await signed(0, document(1, [entry(2)]), 2);
    expect(await sync.receive(newer)).toBe(true);
    expect(sync.fragments.get(0)?.id).toBe(newer.id);
    expect(sync.fragments.document.entries[0].community_id).toBe(entry(2).community_id);
    expect(sync.locked).toBe(false);
  });

  it("every new winner is handed to persist as signed events with the advisory count (D-01)", async () => {
    const { sync, snapshots, signed } = await seam();
    const one = await signed(1, document(2, [entry(2)]));
    const zero = await signed(0, document(2, [entry(1)]));
    await sync.receive(one, false);
    const locked = snapshots.at(-1)!;
    expect(locked.events).toEqual([one]);
    expect(locked.count).toBeUndefined();
    await sync.receive(zero, false);
    expect(idsOf(snapshots.at(-1)!.events)).toEqual([zero.id, one.id]);
    expect(snapshots.at(-1)!.count).toBeUndefined();
    await sync.receive(zero);
    const decrypted = snapshots.at(-1)!;
    expect(decrypted.count).toBe(2);
    expect(decrypted.events).toEqual([zero, one]); // the ciphertext and signature exactly as received
    // Nothing changed: nothing more is handed over.
    const calls = snapshots.length;
    await sync.receive(zero);
    expect(snapshots).toHaveLength(calls);
  });

  it("a write waits for persist before each fragment it publishes (D-08)", async () => {
    const parked = deferred<void>();
    let hold = true;
    const { sync, events, snapshots, signed } = await seam({
      persist: () => hold ? parked.promise : Promise.resolve(),
    });
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(0, document(1, [entry(1)])));
    const handed = snapshots.length;
    expect(handed).toBeGreaterThan(0);
    const write = sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
    await wait();
    expect(events).toHaveLength(0); // the record still lags the winner this write was planned over
    hold = false;
    parked.resolve();
    await write;
    expect(events).toHaveLength(1);
    expect(snapshots.length).toBeGreaterThan(handed); // the published fragment is a winner and was handed over too
  });

  it("a write asks the signer for nothing until the record holds every accepted fragment (WR-01, D-08)", async () => {
    const parked = deferred<void>();
    let hold = true;
    const owner = new PrivateKeySigner(new Uint8Array(32).fill(1));
    const { sync, events, signed } = await seam({
      signer: owner,
      persist: () => hold ? parked.promise : Promise.resolve(),
    });
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(0, document(1, [entry(1)])));
    const sign = spy(owner, "signEvent");
    const encrypt = spy(owner.nip44!, "encrypt");
    const write = sync.write({ entries: [entry(2)], tombstones: [] }, [entry(2).community_id]);
    await wait();
    expect(sign.calls).toHaveLength(0);
    expect(encrypt.calls).toHaveLength(0);
    hold = false;
    parked.resolve();
    await write;
    expect(sign.calls).toHaveLength(1);
    expect(events).toHaveLength(1);
  });

  it("a repack stops before its next fragment when persist rejects (D-08)", async () => {
    let published: NostrEvent[] = [];
    const { sync, events, signed } = await seam({
      persist: () => published.length > 0 ? Promise.reject(new Error("disk full")) : Promise.resolve(),
    });
    published = events;
    sync.markReadComplete(sync.beginRead());
    await sync.receive(await signed(0, document(2, [entry(1)])));
    await sync.receive(await signed(1, document(2, [entry(2)])));
    await expect(sync.repack({ entries: [], tombstones: [] })).rejects.toThrow("disk full");
    expect(events).toHaveLength(1); // the first staging copy; the restarted client repairs from the record
  });

  it("a scoped write still publishes every fragment when persist keeps rejecting, so a full store never blocks a leave (WR-03)", async () => {
    let persists = 0;
    const { sync, events, signed } = await seam({
      persist: () => (persists++, Promise.reject(new Error("quota exceeded"))),
    });
    sync.markReadComplete(sync.beginRead());
    const a = entry(1);
    const b = entry(2);
    await sync.receive(await signed(0, document(2, [a])));
    await sync.receive(await signed(1, document(2, [b])));
    const calls = persists;
    await sync.write({
      entries: [{ ...a, added_at: 9 }],
      tombstones: [{ community_id: b.community_id, removed_at: 9 }],
    }, [a.community_id, b.community_id]);
    expect(events).toHaveLength(2);
    expect(persists).toBeGreaterThan(calls); // every wait still tried to store the record first
    expect(sync.fragments.count).toBe(2); // a scoped write never changes the count
    expect(sync.fragments.document.tombstones.map((t) => t.community_id)).toEqual([b.community_id]);
  });

  it("a join that overflows its fragment needs a repack, so with persist rejecting it publishes nothing and never asks the signer (WR-02)", async () => {
    const { sync, events, signed, signer } = await seam({
      persist: () => Promise.reject(new Error("quota exceeded")),
    });
    sync.markReadComplete(sync.beginRead());
    // The largest fragment 0 that still fits the event ceiling; one more membership overflows it.
    let held: NostrEvent | undefined;
    let size = 100;
    for (;; size++) {
      const next = await signed(0, document(1, Array.from({ length: size + 1 }, (_, i) => entry(i + 1))));
      if (new TextEncoder().encode(JSON.stringify(next)).length > COMMUNITY_LIST_EVENT_MAX_BYTES) break;
      held = next;
    }
    expect(held).toBeDefined();
    await sync.receive(held!);
    const joined = entry(size + 2);
    const prompts = [spy(signer, "getPublicKey"), spy(signer, "signEvent"), spy(signer.nip44!, "encrypt")];
    try {
      await expect(sync.write({ entries: [...sync.fragments.document.entries, joined], tombstones: [] }, [
        joined.community_id,
      ])).rejects.toThrow("quota exceeded");
      expect(events).toHaveLength(0);
      for (const prompt of prompts) expect(prompt.calls).toHaveLength(0);
    } finally {
      for (const prompt of prompts) prompt.restore();
    }
  });

  /** Two held fragments and a write touching both; persist parks once the first fragment is published. */
  async function parkedWrite(assertCurrent: () => void = () => {}) {
    const parked = deferred<void>();
    let published: NostrEvent[] = [];
    let parkedCalls = 0;
    const fixture = await seam({
      persist: () => published.length > 0 ? (parkedCalls++, parked.promise) : Promise.resolve(),
    });
    published = fixture.events;
    fixture.sync.markReadComplete(fixture.sync.beginRead());
    const a = entry(1);
    const b = entry(2);
    await fixture.sync.receive(await fixture.signed(0, document(2, [a])));
    await fixture.sync.receive(await fixture.signed(1, document(2, [b])));
    const write = fixture.sync.write(
      {
        entries: [{ ...a, added_at: 9 }, { ...b, added_at: 9 }],
        tombstones: [],
      },
      [a.community_id, b.community_id],
      assertCurrent,
    );
    write.catch(() => {});
    for (let i = 0; i < 100 && parkedCalls === 0; i++) await wait(10);
    expect(fixture.events).toHaveLength(1); // the second fragment waits on the record of the first
    return { ...fixture, parked, write, a };
  }

  it("a write refused while it waits on persist publishes nothing more (CR-01, D-30)", async () => {
    let refused = false;
    const { events, parked, write } = await parkedWrite(() => {
      if (refused) throw new Error("lane closed");
    });
    refused = true; // stop() closes the lane while the record write is in flight
    parked.resolve();
    await expect(write).rejects.toThrow("lane closed");
    expect(events).toHaveLength(1);
  });

  it("a write whose read evidence is withdrawn while it waits on persist publishes nothing more (CR-01, D-31)", async () => {
    const { sync, events, parked, write } = await parkedWrite();
    sync.clearReadEvidence();
    parked.resolve();
    await expect(write).rejects.toThrow(CommunityListUnknownError);
    expect(events).toHaveLength(1);
  });

  it("another device's fragment ingested while a write waits on persist stops the stale write (CR-01, D-06)", async () => {
    const { sync, events, parked, write, signed, a } = await parkedWrite();
    const c = entry(3);
    const arrival = await signed(0, document(2, [a, c]), Math.floor(Date.now() / 1000) + 100);
    await sync.receive(arrival, false); // as the lane's ingest step does once a retired save freed the lane
    parked.resolve();
    await expect(write).rejects.toThrow("changed during signing");
    expect(events).toHaveLength(1);
  });

  it("locked$ reports held copies that are not decrypted", async () => {
    const { sync, signed } = await seam();
    const seen: boolean[] = [];
    const sub = sync.locked$.subscribe((value) => seen.push(value));
    const stored = await signed(0, document(1, [entry(1)]));
    await sync.restore([stored]);
    await sync.receive(stored, false); // same copy again: still locked, no new emission
    await sync.receive(stored);
    sub.unsubscribe();
    expect(seen).toEqual([false, true, false]);
  });
});
