// Shared Banlist fixtures for the plans that build the batch ban writer and the Banlist re-heal (05-03..05-06): owner
// and staff engines over a fake relay pool, sibling Banlist injection, published edition readers and a duty clock swap.
// Not a test module: it registers no tests.

import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { EventStore } from "applesauce-core";
import { getEventHash, type NostrEvent, type Rumor } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";
import type { Observable } from "rxjs";

import { EditionFactory } from "../../factories/control.ts";
import { banlistLocator, grantLocator } from "../../helpers/crypto.ts";
import { computeEditionHash } from "../../helpers/editions.ts";
import { decodeWrap } from "../../helpers/gift-wrap.ts";
import { type ConcordKeys, type PlaneInfo, wrapForTarget } from "../../helpers/keys.ts";
import { createLegacyCommunity } from "../../helpers/__tests__/test-utils.ts";
import { type DecodedEvent, type JoinMaterial, type VerifiedControlHead, VSK } from "../../types.ts";
import { ConcordCommunity, type ConcordCommunityOptions } from "../community.ts";
import type { ConcordDiagnostic } from "../diagnostics.ts";
import { DutyScope } from "../lifecycle.ts";
import { memoryStorage } from "../storage.ts";
import { type FakeRelayPool, fakeRelayPool, ManualClock } from "./test-utils.ts";

/** Wait long enough for the fake pool's asynchronous delivery and the folds to settle. */
export function settle(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 200));
}

/** An owner's community on a fake pool, started with its genesis published and settled. */
export interface OwnerEngine {
  /** The owner's engine. */
  community: ConcordCommunity;
  /** The fake relay pool the engine publishes through. */
  net: FakeRelayPool;
  /** The event store behind the engine. */
  store: EventStore;
  /** The owner's signer. */
  signer: PrivateKeySigner;
  /** The owner's hex pubkey. */
  pubkey: string;
  /** The id of the genesis general channel. */
  generalId: string;
}

/**
 * An owner's started community over a fresh fake pool, with its genesis published (as the pin fixtures do). `wrapSigner`
 * hands the engine a signer built around the owner's key (for parking signer calls); `OwnerEngine.signer` stays the
 * plain key signer.
 */
export async function ownerEngine(
  options: Partial<ConcordCommunityOptions> = {},
  wrapSigner?: (signer: PrivateKeySigner) => ISigner,
): Promise<OwnerEngine> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const net = fakeRelayPool();
  const genesis = await createLegacyCommunity({ ownerPubkey: pubkey, name: "Test", relays: ["wss://fake"] });
  const store = new EventStore();
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material: genesis.material,
    signer: wrapSigner ? wrapSigner(signer) : signer,
    pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    ...options,
  });
  await community.start();
  for (const rumor of genesis.controlRumors) {
    await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
  }
  for (const rumor of genesis.guestbookRumors) await community.publishToPlane({ plane: "guestbook" }, rumor, {});
  await settle();
  return { community, net, store, signer, pubkey, generalId: genesis.generalChannelId };
}

/** A staff member the owner granted a Role to. */
export interface StaffMember {
  /** The staff member's signer. */
  signer: PrivateKeySigner;
  /** The staff member's hex pubkey. */
  pubkey: string;
  /** The Role the owner granted. */
  roleId: string;
}

/** A fresh member holding a new Role at `position` with `permissions`, created and granted by the engine's admin. */
export async function staffMember(
  community: ConcordCommunity,
  options: { position: number; permissions: bigint },
): Promise<StaffMember> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const roleId = await community.admin.createRole(
    `staff-${options.position}`,
    options.position,
    options.permissions,
  );
  await community.admin.grantRoles(pubkey, [roleId]);
  await settle();
  return { signer, pubkey, roleId };
}

/** A started engine for another member over the events the source network has published so far. */
export interface MemberEngine {
  /** The member's engine. */
  community: ConcordCommunity;
  /** The member's own fake pool; its `published` list holds only what this member publishes. */
  net: FakeRelayPool;
  /** The event store behind the engine. */
  store: EventStore;
}

/** A fresh engine for `member` over the owner's published events and material, started and settled. */
export async function memberEngine(
  owner: Pick<OwnerEngine, "community" | "net">,
  member: { signer: ISigner; pubkey: string },
  options: Partial<ConcordCommunityOptions> = {},
): Promise<MemberEngine> {
  const net = fakeRelayPool({ events: [...owner.net.published] });
  const store = new EventStore();
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material: owner.community.material,
    signer: member.signer,
    pubkey: member.pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    ...options,
  });
  await community.start();
  await dutiesSettled(community);
  return { community, net, store };
}

/** Wait for the engine's duty scope to go idle, then settle. */
export async function dutiesSettled(community: ConcordCommunity): Promise<void> {
  await settle();
  await (community as unknown as { duties: DutyScope }).duties.idle();
  await settle();
}

/** Dispose an engine, its store and any extra engines; waits for in-flight work to drain. */
export async function disposeAll(...engines: Array<{ community: ConcordCommunity; store: EventStore }>): Promise<void> {
  for (const engine of engines) {
    engine.community.dispose();
    engine.store.dispose();
  }
  await settle();
}

/** The control keys of an engine, through its private field. */
function keysOf(community: ConcordCommunity): ConcordKeys {
  return (community as unknown as { keys: ConcordKeys }).keys;
}

/** The verified Banlist head the engine folded, or undefined. */
export function banlistHead(community: ConcordCommunity): VerifiedControlHead | undefined {
  const eid = banlistLocator(hexToBytes(community.communityId));
  return community.state$.value.controlVerification?.heads.get(eid);
}

/**
 * Deliver a Banlist edition authored by `author` straight into the engine's receive path, as a sibling admin's edition
 * arriving from a relay. A non-owner author cites their own verified Grant as `vac`. When `beat` names a rumor id the
 * edition is ground with a tag nonce until its rumor id is lower and it is the folded head (the equal-version
 * tiebreak). When `lose` names a rumor id the edition is ground until its rumor id is higher, so it loses the tiebreak
 * against an equal-version edition with that id and is delivered but not the folded head. Returns the delivered rumor
 * id, edition hash and the delivered wrap, which a restarted engine can be served.
 */
export async function injectBanlist(
  community: ConcordCommunity,
  author: { signer: ISigner; pubkey: string },
  options: { content: string; version: number; prevHash?: string; beat?: string; lose?: string },
): Promise<{ rumorId: string; hash: string; wrap: NostrEvent }> {
  const cid = hexToBytes(community.communityId);
  const eid = banlistLocator(cid);
  let vac: [string, string, string] | undefined;
  if (author.pubkey !== community.material.owner) {
    const grantEid = grantLocator(cid, author.pubkey);
    const grant = community.state$.value.controlVerification?.heads.get(grantEid);
    if (!grant) throw new Error("the injecting author has no verified Grant");
    vac = [grantEid, String(grant.version), grant.hash];
  }
  const template = await EditionFactory.create({
    vsk: VSK.BANLIST,
    eid,
    version: options.version,
    prevHash: options.prevHash,
    content: options.content,
    vac,
  });
  const hash = computeEditionHash({
    vsk: VSK.BANLIST,
    eid,
    version: options.version,
    prevHash: options.prevHash,
    content: options.content,
  });
  const deliver = (wrap: NostrEvent) =>
    (community as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(wrap);
  if (options.beat === undefined && options.lose === undefined) {
    const { wrap, rumorId } = await wrapForTarget(keysOf(community), { plane: "control" }, author.signer, template, {
      plaintext: true,
    });
    await deliver(wrap);
    await settle();
    return { rumorId, hash, wrap };
  }
  for (let nonce = 0; nonce < 20_000; nonce++) {
    const tagged = { ...template, tags: [...template.tags, ["nonce", String(nonce)]] };
    const { wrap, rumorId } = await wrapForTarget(keysOf(community), { plane: "control" }, author.signer, tagged, {
      plaintext: true,
    });
    if (options.beat === undefined ? rumorId <= options.lose! : rumorId >= options.beat) continue;
    await deliver(wrap);
    await settle();
    if (options.beat === undefined) return { rumorId, hash, wrap };
    if (banlistHead(community)?.edition.rumor.id === rumorId) return { rumorId, hash, wrap };
  }
  throw new Error("could not make the injected Banlist edition the folded head");
}

/** One control edition an engine published, with the fields the tests compare. */
export interface PublishedEdition {
  /** The edition's vsk. */
  vsk: number;
  /** The entity coordinate. */
  eid: string;
  /** The edition's version. */
  version: number;
  /** The `ep` tag, when the edition cites a predecessor. */
  prevHash?: string;
  /** The edition content. */
  content: string;
  /** The decoded rumor. */
  rumor: Rumor;
}

/** Every control edition the engine published through `net`, in publish order. */
export function controlEditionLog(community: ConcordCommunity, net: FakeRelayPool): PublishedEdition[] {
  const planes = (community as unknown as { keys: { planes: Map<string, PlaneInfo> } }).keys.planes;
  const log: PublishedEdition[] = [];
  for (const wrap of net.published) {
    const info = planes.get(wrap.pubkey);
    if (info?.type !== "control") continue;
    const rumor = decodeWrap(structuredClone(wrap), info.convKey)?.rumor;
    if (!rumor || rumor.kind !== 3308) continue;
    const tag = (name: string) => rumor.tags.find((t) => t[0] === name)?.[1];
    log.push({
      vsk: Number(tag("vsk")),
      eid: (tag("eid") ?? "").toLowerCase(),
      version: Number(tag("ev") ?? "1"),
      prevHash: tag("ep"),
      content: rumor.content,
      rumor,
    });
  }
  return log;
}

/** The Banlist editions the engine published so far, oldest first. */
export function banlistEditions(community: ConcordCommunity, net: FakeRelayPool): PublishedEdition[] {
  const eid = banlistLocator(hexToBytes(community.communityId));
  return controlEditionLog(community, net).filter((edition) => edition.vsk === VSK.BANLIST && edition.eid === eid);
}

/** The Grant editions the engine published for `member` so far, oldest first. */
export function grantEditions(community: ConcordCommunity, net: FakeRelayPool, member: string): PublishedEdition[] {
  const eid = grantLocator(hexToBytes(community.communityId), member);
  return controlEditionLog(community, net).filter((edition) => edition.vsk === VSK.GRANT && edition.eid === eid);
}

/** The retained Control history of the engine, as the Banlist writer reads it. */
export function retainedControl(community: ConcordCommunity): Iterable<DecodedEvent> {
  return (community as unknown as { controlHistory: Map<string, DecodedEvent> }).controlHistory.values();
}

/** Swap the engine's private duty scope for one on a fresh ManualClock set to the real time. */
export function useDutyClock(community: ConcordCommunity): { clock: ManualClock; duties: DutyScope } {
  const internals = community as unknown as {
    duties: DutyScope;
    diagnostics: { reportDuty(report: never): void };
  };
  const clock = new ManualClock({ now: Date.now() });
  internals.duties.dispose();
  const duties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report as never) });
  internals.duties = duties;
  return { clock, duties };
}

/** A restarted engine over the history another engine of the same account published. */
export interface RestartedEngine {
  /** The fresh engine, started and settled. */
  engine: ConcordCommunity;
  /** Its own fake pool; its `published` list holds only what the restarted engine publishes. */
  net: FakeRelayPool;
  /** The event store behind the engine. */
  store: EventStore;
  /** The ManualClock its duties run on. */
  clock: ManualClock;
  /** Its duty scope. */
  duties: DutyScope;
}

/**
 * A fresh engine for `source.signer`'s account, started over everything `source.net` published plus `extraWraps` (such
 * as a sibling edition that was only ever delivered to the first engine), as an app restart would. Its DutyScope is swapped
 * to a ManualClock before `start()`, so a heal evaluated at start is armed on the manual clock and not dropped.
 */
export async function restartEngine(
  source: { net: FakeRelayPool; signer: ISigner; pubkey: string },
  material: JoinMaterial,
  extraWraps: NostrEvent[] = [],
): Promise<RestartedEngine> {
  const net = fakeRelayPool({ events: [...source.net.published, ...extraWraps] });
  const store = new EventStore();
  const engine = new ConcordCommunity({
    storage: memoryStorage(),
    material,
    signer: source.signer,
    pubkey: source.pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
  });
  const { clock, duties } = useDutyClock(engine);
  await engine.start();
  await dutiesSettled(engine);
  return { engine, net, store, clock, duties };
}

/** The shape of the Banlist writer the tests reach through the community's private facade. */
export interface WriterView {
  /** The session intent ledger. */
  intents(): ReadonlyMap<
    string,
    {
      action: "ban" | "unban";
      seq: number;
      edition?: { eid: string; version: number; hash: string; prevHash?: string };
    }
  >;
  /** The ledger's revision: emits on subscription and after every recorded intent. */
  intents$: Observable<number>;
}

/** The engine's Banlist writer, through the private `banlist.writer` field. */
export function writerOf(community: ConcordCommunity): WriterView {
  return (community as unknown as { banlist: { writer: WriterView } }).banlist.writer;
}

/** A fresh random 64-hex public key standing in for a roleless member. */
export function randomMember(): string {
  return bytesToHex(generateSecretKey());
}

/**
 * Deliver the wraps `source` published from index `from` onward through the target's receive path, as a relay serving
 * them would, so a second engine sees the first engine's editions. Returns the new index to continue from.
 */
export async function relayInto(source: FakeRelayPool, target: ConcordCommunity, from = 0): Promise<number> {
  const deliver = (wrap: NostrEvent) =>
    (target as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(wrap);
  for (const wrap of source.published.slice(from)) await deliver(structuredClone(wrap));
  await settle();
  return source.published.length;
}

/** Collect every diagnostic the engine reports until `stop()` is called. */
export function diagnosticsOf(community: ConcordCommunity): { seen: ConcordDiagnostic[]; stop(): void } {
  const seen: ConcordDiagnostic[] = [];
  const subscription = community.diagnostics$.subscribe((diagnostic) => seen.push(diagnostic));
  return { seen, stop: () => subscription.unsubscribe() };
}

/** What {@link lostBan} set up. */
export interface LostBan {
  /** The member the owner banned and a sibling then displaced. */
  lost: string;
  /** The member only the winning sibling lists. */
  winner: string;
  /** The owner's own (displaced) version 1 edition. */
  own: PublishedEdition;
  /** The sibling's rumor id, edition hash and delivered wrap; it is the folded head. */
  sibling: { rumorId: string; hash: string; wrap: NostrEvent };
}

/**
 * The common setup of a lost ban: the owner bans `member` (version 1), then `staff` delivers a different version 1
 * Banlist edition that wins the equal-version tiebreak, so `member` drops out of the folded Banlist.
 */
export async function lostBan(
  owner: Pick<OwnerEngine, "community" | "net">,
  staff: { signer: ISigner; pubkey: string },
  member: string = randomMember(),
): Promise<LostBan> {
  await owner.community.ban(member);
  await settle();
  const own = banlistEditions(owner.community, owner.net)[0];
  const winner = randomMember();
  const sibling = await injectBanlist(owner.community, staff, {
    content: JSON.stringify([winner]),
    version: 1,
    beat: getEventHash(own.rumor),
  });
  return { lost: member, winner, own, sibling };
}
