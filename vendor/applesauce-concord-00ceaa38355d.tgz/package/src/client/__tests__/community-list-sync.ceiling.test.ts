import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { COMMUNITY_LIST_EVENT_MAX_BYTES, ConcordCommunityListSync } from "../community-list-sync.ts";
import { type CommunityListFragment, encodeCommunityListFragment } from "../../helpers/community-list-wire.ts";
import type { CommunityListCommunity } from "../../types.ts";

// CORD-02 §8: the fully encoded event, after encryption and signing, never exceeds 65,536 bytes; a client starts a new
// fragment instead of exceeding it or shedding unknown fields; and a write that strictly shrinks an oversized fragment is
// exempt, because leaving is the only way a member already over the ceiling can restore compliance.

const PAD = 200;
const CEILING = COMMUNITY_LIST_EVENT_MAX_BYTES;
const bytes = (event: NostrEvent): number => new TextEncoder().encode(JSON.stringify(event)).length;
const dTag = (event: NostrEvent): string | undefined => event.tags.find((tag) => tag[0] === "d")?.[1];

/** A membership whose unknown entry-level field makes it about one kilobyte on the wire. */
function entry(index: number): CommunityListCommunity & { future: string } {
  const id = index.toString(16).padStart(64, "0");
  const material = {
    community_id: id,
    owner: "11".repeat(32),
    owner_salt: "22".repeat(32),
    community_root: "33".repeat(32),
    root_epoch: 0,
    channels: [],
    relays: [],
    name: "room",
  };
  return { community_id: id, current: material, seed: material, added_at: 1, future: "x".repeat(PAD) };
}

const document = (entries: CommunityListCommunity[]): CommunityListFragment => ({ frags: 1, entries, tombstones: [] });

async function fixture() {
  const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
  const events: NostrEvent[] = [];
  const sync = new ConcordCommunityListSync(signer, async (event) => {
    events.push(event);
  });
  const signed = async (entries: CommunityListCommunity[]): Promise<NostrEvent> =>
    signer.signEvent({
      kind: 33302,
      created_at: 1,
      tags: [["d", "0"]],
      content: await signer.nip44!.encrypt(await signer.getPublicKey(), encodeCommunityListFragment(document(entries))),
    });
  return { events, sync, signed };
}

type Signed = Awaited<ReturnType<typeof fixture>>["signed"];

/** The fullest fragment 0 whose signed event still fits the ceiling: one more membership would not. */
async function fullest(signed: Signed): Promise<{ event: NostrEvent; count: number }> {
  let held: { event: NostrEvent; count: number } | undefined;
  for (let count = 30;; count++) {
    const event = await signed(Array.from({ length: count }, (_, i) => entry(i + 1)));
    if (bytes(event) > CEILING) return held!;
    held = { event, count };
  }
}

/** A fragment 0 already past the ceiling by a margin larger than one membership. */
async function overweight(signed: Signed): Promise<{ event: NostrEvent; count: number }> {
  for (let count = 30;; count++) {
    const event = await signed(Array.from({ length: count }, (_, i) => entry(i + 1)));
    if (bytes(event) > CEILING + 4_000) return { event, count };
  }
}

/** Join one membership onto the fullest fragment 0, which cannot take it without exceeding the ceiling. */
async function joinPastCeiling() {
  const { events, sync, signed } = await fixture();
  const { event, count } = await fullest(signed);
  await sync.receive(event);
  expect(sync.fragments.document.entries).toHaveLength(count);
  const joined = entry(count + 1);
  await sync.write({ entries: [...sync.fragments.document.entries, joined], tombstones: [] }, [joined.community_id]);
  return { events, sync, count };
}

describe("Community List event ceiling (CORD-02 §8)", () => {
  it("a join that would push a nearly full fragment past 65,536 bytes starts a new fragment and every published event stays within the ceiling (CORD-02 §8)", async () => {
    const { events, sync, count } = await joinPastCeiling();
    expect(events.length).toBeGreaterThan(0);
    for (const event of events) expect(bytes(event)).toBeLessThanOrEqual(CEILING);
    expect(sync.fragments.count).toBeGreaterThan(1);
    expect(sync.fragments.complete).toBe(true);
    expect(sync.fragments.document.entries).toHaveLength(count + 1);
  });

  it("starting a new fragment to fit the ceiling keeps every unknown field instead of shedding it (CORD-02 §8)", async () => {
    const { sync, count } = await joinPastCeiling();
    expect(sync.fragments.count).toBeGreaterThan(1);
    const held = sync.fragments.document.entries as Array<CommunityListCommunity & { future?: string }>;
    expect(held).toHaveLength(count + 1);
    for (const kept of held) expect(kept.future).toBe("x".repeat(PAD));
  });

  it("a write that strictly shrinks a fragment already past the ceiling is published in place, while one that grows it splits (CORD-02 §8)", async () => {
    const { events, sync, signed } = await fixture();
    const { event, count } = await overweight(signed);
    await sync.receive(event);
    const leaving = entry(1).community_id;
    const remaining = sync.fragments.document.entries.filter((held) => held.community_id !== leaving);
    await sync.write({ entries: remaining, tombstones: [{ community_id: leaving, removed_at: 5 }] }, [leaving]);
    // Leaving is exempt from the ceiling: one event, same fragment, smaller than before yet still over the ceiling.
    expect(events).toHaveLength(1);
    expect(dTag(events[0])).toBe("0");
    expect(sync.fragments.count).toBe(1);
    expect(bytes(events[0])).toBeLessThan(bytes(event));
    expect(bytes(events[0])).toBeGreaterThan(CEILING);
    expect(sync.fragments.document.entries).toHaveLength(count - 1);
    // A write that grows the same fragment is not exempt: it splits, and every event it publishes fits the ceiling.
    events.length = 0;
    const joined = entry(count + 1);
    await sync.write({
      entries: [...sync.fragments.document.entries, joined],
      tombstones: sync.fragments.document.tombstones,
    }, [joined.community_id]);
    expect(events.length).toBeGreaterThan(0);
    for (const published of events) expect(bytes(published)).toBeLessThanOrEqual(CEILING);
    expect(sync.fragments.count).toBeGreaterThan(1);
    expect(sync.fragments.document.entries).toHaveLength(count);
  });
});
