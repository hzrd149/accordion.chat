// The D-31 Community List model core: a pure, client-independent generator, trace format and invariant checker for
// the model-based interleaving test. The CORD-02 §8 fragment rules (newest wins per index, governing count, in-range
// union) are re-implemented here by hand so the checker never trusts the code under test. Never import from
// `src/client/*.ts`: only `src/helpers/`, `src/types.ts` and applesauce packages.

import { sha256 } from "@noble/hashes/sha2.js";
import { PrivateKeySigner } from "applesauce-signers";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { createLegacyCommunity } from "../../helpers/__tests__/test-utils.ts";
import { buildInviteBundle } from "../../helpers/invite-bundle.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  type CommunityListFragment,
  encodeCommunityListFragment,
} from "../../helpers/community-list-wire.ts";
import { liveCommunities, mergeCommunities, mergeCommunityTombstones } from "../../helpers/community-list.ts";
import type { CommunityListCommunity, CommunityTombstone, InviteBundle, JoinMaterial } from "../../types.ts";

// ---------------------------------------------------------------------------------------------------------------
// Seeded randomness
// ---------------------------------------------------------------------------------------------------------------

/** A deterministic pseudo-random source; the only randomness that decides a model run. */
export interface Rng {
  /** The next value in [0, 1). */
  next(): number;
  /** An integer in [0, maxExclusive). */
  int(maxExclusive: number): number;
  /** One element of a non-empty list. */
  pick<T>(items: readonly T[]): T;
  /** True with probability `p`. */
  chance(p: number): boolean;
}

/** Mulberry32, a 32-bit generator: the same seed always yields the same sequence. */
export function seededRng(seed: number): Rng {
  let state = seed >>> 0;
  const next = (): number => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4_294_967_296;
  };
  const int = (maxExclusive: number): number => Math.floor(next() * maxExclusive);
  return {
    next,
    int,
    pick: <T>(items: readonly T[]): T => {
      if (items.length === 0) throw new Error("pick from an empty list");
      return items[int(items.length)];
    },
    chance: (p: number): boolean => next() < p,
  };
}

// ---------------------------------------------------------------------------------------------------------------
// Ops, runs and templates
// ---------------------------------------------------------------------------------------------------------------

/** A scripted signer method. */
export type SignerMethod = "getPublicKey" | "signEvent" | "encrypt" | "decrypt";
/** How the scripted relay answers the next kind-33302 reads ("slow" parks them until `finish-slow`). */
export type ReadMode = "complete" | "error" | "partial" | "slow";

/**
 * One step of a model run. Client ops (`start` .. `save`) call the client; the others script the world:
 * `read-mode` and `publish-mode` set how the relay answers from now on, `finish-slow` settles parked reads,
 * `signer` sets how `method` behaves from now on ("stall" parks calls), `park` parks only the next call of `method`
 * (from any caller, one-shot) so any lane step can be held mid-flight, `fail-next` fails only the next call of `method`
 * (from any caller, one-shot: a declined prompt; an armed park takes that call first), after which the method keeps its
 * mode, `release-stalls` releases every parked signer call, disarms every armed park (an armed `fail-next` stays armed)
 * and returns stalling methods to "ok", `remote` writes another device's fragment
 * for `member` (to the event store, the relay or both; "stale" is a leftover staging copy older than every fragment and
 * at an index past all of them, so CORD-02 §8 ignores it) and `advance` moves the manual clock.
 */
export type ModelOp =
  | { kind: "start" }
  | { kind: "stop" }
  | { kind: "dispose" }
  | { kind: "join"; member: number }
  | { kind: "leave"; member: number }
  | { kind: "create" }
  | { kind: "unlock" }
  | { kind: "save" }
  | { kind: "read-mode"; mode: ReadMode }
  | { kind: "finish-slow"; outcome: "complete" | "error" }
  | { kind: "publish-mode"; mode: "accept" | "refuse-transient" | "refuse-permanent" }
  | { kind: "signer"; method: SignerMethod; mode: "ok" | "fail" | "stall" }
  | { kind: "park"; method: SignerMethod }
  | { kind: "fail-next"; method: SignerMethod }
  | { kind: "release-stalls" }
  | {
    kind: "remote";
    action: "add" | "remove" | "grow" | "stale";
    member: number;
    delivery: "store" | "relay" | "both";
  }
  | { kind: "advance"; ms: number };

const INPUT_KINDS: ReadonlySet<ModelOp["kind"]> = new Set<ModelOp["kind"]>([
  "start",
  "stop",
  "dispose",
  "join",
  "leave",
  "create",
  "unlock",
  "save",
  "remote",
]);

/** Whether an op is an input (a client call or another device's write) rather than a change of the scripted world. */
export function isInputOp(op: ModelOp): boolean {
  return INPUT_KINDS.has(op.kind);
}

/** The world before the first op: fragments on the relay (and in the store), their members and the local mirror. */
export interface ModelInitial {
  /** How many fragments of this user's list the relay holds (0 means a fresh account). */
  fragments: 0 | 1 | 2;
  /** Member indexes the relay's fragments hold. */
  remoteMembers: number[];
  /** Member indexes the client's local mirror holds. */
  mirrorMembers: number[];
}

/** One reproducible model run: everything a runner needs besides the member pool. */
export interface ModelRun {
  /** The seed the run was generated from. */
  seed: number;
  /** The client's `autoSaveCommunityList` option. */
  autoSave: boolean;
  /** The client's `autoUnlock` option. */
  autoUnlock: boolean;
  /** The scenario template woven into the run, if any. */
  template?: string;
  /** The initial world. */
  initial: ModelInitial;
  /** The ops, applied in order. */
  ops: ModelOp[];
}

/** A named scenario skeleton encoding a reviewed defect class; noise ops are woven around it. */
export interface ModelTemplate {
  /** Stable template name (printed in failures). */
  name: string;
  /** Client flags the scenario needs; `autoSave` must match the run's, `autoUnlock` is forced. */
  requires?: { autoSave?: boolean; autoUnlock?: boolean };
  /** Initial-world fields the scenario forces. */
  initial?: Partial<ModelInitial>;
  /** The skeleton ops, kept in this order. */
  ops: readonly ModelOp[];
  /** Relative chance of being picked among the compatible templates (default 1). */
  weight?: number;
}

/**
 * The reviewed defect classes (01-REVIEW-FOCUSED-2 CR-01, CR-02, WR-01, IN-01; LIST-02; D-32; 01-REVIEW-GAPS CR-01
 * and WR-01; D-34 resumable joins and 01-REVIEW-GAPS-2 WR-02) as op skeletons.
 */
export const MODEL_TEMPLATES: readonly ModelTemplate[] = [
  {
    // CR-01: an ingest parked on a stalled getPublicKey resumes after stop(); the next lifecycle must still ingest
    // the other device's larger declaration that reached the store while stopped.
    name: "restart-during-stalled-ingest",
    requires: { autoUnlock: true },
    initial: { fragments: 1 },
    ops: [
      { kind: "read-mode", mode: "slow" },
      { kind: "start" },
      { kind: "signer", method: "getPublicKey", mode: "stall" },
      { kind: "finish-slow", outcome: "complete" },
      { kind: "stop" },
      { kind: "remote", action: "grow", member: 1, delivery: "store" },
      { kind: "release-stalls" },
      { kind: "read-mode", mode: "complete" },
      { kind: "start" },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // CR-02: with auto-save, a held write plus a fragment that keeps failing to ingest must not re-arm reads forever.
    name: "failing-ingest-with-auto-save",
    requires: { autoSave: true, autoUnlock: true },
    initial: { fragments: 1 },
    ops: [
      { kind: "start" },
      { kind: "signer", method: "getPublicKey", mode: "fail" },
      { kind: "remote", action: "grow", member: 1, delivery: "store" },
      { kind: "create" },
      { kind: "advance", ms: 6_000 },
      { kind: "advance", ms: 11_000 },
      { kind: "advance", ms: 6_000 },
      { kind: "advance", ms: 11_000 },
      { kind: "advance", ms: 6_000 },
      { kind: "advance", ms: 11_000 },
      { kind: "advance", ms: 6_000 },
      { kind: "advance", ms: 11_000 },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // WR-01: an app unlock whose getPublicKey fails must not strand the held write once a retry succeeds.
    name: "unlock-failure-while-held",
    requires: { autoUnlock: false },
    initial: { fragments: 1 },
    ops: [
      { kind: "start" },
      { kind: "join", member: 0 },
      { kind: "signer", method: "getPublicKey", mode: "fail" },
      { kind: "unlock" },
      { kind: "signer", method: "getPublicKey", mode: "ok" },
      { kind: "unlock" },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // LIST-02: a restart while offline must hold the join, never publish a fresh frags:1 over the vault.
    name: "offline-restart-join",
    initial: { fragments: 2 },
    ops: [
      { kind: "start" },
      { kind: "stop" },
      { kind: "read-mode", mode: "error" },
      { kind: "start" },
      { kind: "join", member: 0 },
      { kind: "read-mode", mode: "complete" },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // IN-01: a held save while start()'s read is still open; the duty's read supersedes it.
    name: "save-during-start-read",
    ops: [
      { kind: "read-mode", mode: "slow" },
      { kind: "start" },
      { kind: "join", member: 0 },
      { kind: "advance", ms: 6_000 },
      { kind: "finish-slow", outcome: "complete" },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // D-32: dispose() is terminal; start() and every mutation afterwards reject.
    name: "dispose-then-start",
    ops: [
      { kind: "start" },
      { kind: "dispose" },
      { kind: "start" },
      { kind: "leave", member: 0 },
      { kind: "join", member: 1 },
      { kind: "unlock" },
    ],
  },
  {
    // 01-REVIEW-GAPS CR-01: a save queued behind a parked lane step (an unlock on getPublicKey) must ingest the larger
    // declaration that reached the store while it waited, never publish frags: 1 over it.
    name: "save-queued-behind-parked-step",
    initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
    ops: [
      { kind: "start" },
      { kind: "unlock" },
      { kind: "park", method: "getPublicKey" },
      { kind: "unlock" },
      { kind: "join", member: 2 },
      { kind: "remote", action: "grow", member: 3, delivery: "store" },
      { kind: "release-stalls" },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // 01-REVIEW-GAPS WR-01: a write parked on the user's encrypt (only the Community List save encrypts with it) and
    // retired by a stale arrival that leaves the list complete must be retried, never dropped.
    name: "save-retired-by-stale-arrival",
    requires: { autoUnlock: false },
    // Later app calls (an unlock, a join or a leave) legitimately release the dropped save, so this template is drawn
    // twice as often to keep a margin on catching a dropped re-queue (01-11 R2).
    weight: 2,
    initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
    ops: [
      { kind: "start" },
      { kind: "unlock" },
      { kind: "park", method: "encrypt" },
      { kind: "join", member: 2 },
      { kind: "advance", ms: 1_000 },
      { kind: "remote", action: "stale", member: 3, delivery: "store" },
      { kind: "release-stalls" },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // D-34: a join whose guestbook Join is declined rejects after recording the membership and still saves the list;
    // joining again re-publishes the Join and saves. The next signEvent is the join's seal, so only the Join fails.
    name: "rejected-join-then-retry",
    initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
    ops: [
      { kind: "start" },
      { kind: "fail-next", method: "signEvent" },
      { kind: "join", member: 2 },
      { kind: "advance", ms: 1_000 },
      { kind: "join", member: 2 },
      { kind: "advance", ms: 6_000 },
    ],
  },
  {
    // 01-REVIEW-GAPS-2 WR-02 under D-34: two concurrent joins of one community, the first parked on its rumor's
    // getPublicKey after recording the membership, the second taking the already-joined path with its seal declined.
    // Neither may un-join the other, and the membership must be saved.
    name: "concurrent-joins-one-declined",
    initial: { fragments: 1, remoteMembers: [0], mirrorMembers: [0] },
    ops: [
      { kind: "start" },
      { kind: "park", method: "getPublicKey" },
      { kind: "join", member: 2 },
      { kind: "fail-next", method: "signEvent" },
      { kind: "join", member: 2 },
      { kind: "release-stalls" },
      { kind: "advance", ms: 6_000 },
    ],
  },
];

/** Relative weights (out of 100) for noise ops; plan 01-09 may retune them, always here. */
export const MODEL_OP_WEIGHTS: Readonly<Record<ModelOp["kind"], number>> = {
  "start": 8,
  "stop": 6,
  "dispose": 1,
  "join": 10,
  "leave": 8,
  "create": 2,
  "unlock": 6,
  "save": 6,
  "read-mode": 8,
  "finish-slow": 4,
  "publish-mode": 5,
  "signer": 5,
  "park": 6,
  "fail-next": 3,
  "release-stalls": 6,
  "remote": 8,
  "advance": 8,
};

/** Clock advances a noise `advance` op draws from, in milliseconds. */
export const MODEL_ADVANCE_MS: readonly number[] = [200, 1_000, 6_000, 12_000, 30_000];

/** Options for {@link generateRun}. */
export interface GenerateOptions {
  /** Exact number of ops (template ops count toward it). */
  steps: number;
  /** The client's `autoSaveCommunityList` option; only compatible templates are chosen. */
  autoSave: boolean;
  /** Size of the member pool; member indexes are drawn from `0..members-1`. */
  members: number;
  /** Probability of weaving a template into the run (default 0.5). */
  templateChance?: number;
}

const READ_MODES: readonly ReadMode[] = ["complete", "error", "partial", "slow"];
const SIGNER_METHODS: readonly SignerMethod[] = ["getPublicKey", "signEvent", "encrypt", "decrypt"];

function templateFits(template: ModelTemplate, options: GenerateOptions): boolean {
  const autoSave = template.requires?.autoSave;
  if (autoSave !== undefined && autoSave !== options.autoSave) return false;
  if (template.ops.length > options.steps) return false;
  return template.ops.every((op) => !("member" in op) || op.member < options.members);
}

function subset(rng: Rng, members: number): number[] {
  const out: number[] = [];
  for (let i = 0; i < members; i++) if (rng.chance(0.4)) out.push(i);
  return out;
}

function noiseOp(rng: Rng, members: number): ModelOp {
  const kinds = Object.keys(MODEL_OP_WEIGHTS) as ModelOp["kind"][];
  const total = kinds.reduce((sum, kind) => sum + MODEL_OP_WEIGHTS[kind], 0);
  let roll = rng.next() * total;
  let kind = kinds[kinds.length - 1];
  for (const candidate of kinds) {
    roll -= MODEL_OP_WEIGHTS[candidate];
    if (roll < 0) {
      kind = candidate;
      break;
    }
  }
  switch (kind) {
    case "join":
    case "leave":
      return { kind, member: rng.int(members) };
    case "read-mode":
      return { kind, mode: rng.pick(READ_MODES) };
    case "finish-slow":
      return { kind, outcome: rng.pick(["complete", "error"] as const) };
    case "publish-mode":
      return { kind, mode: rng.pick(["accept", "refuse-transient", "refuse-permanent"] as const) };
    case "signer":
      return { kind, method: rng.pick(SIGNER_METHODS), mode: rng.pick(["ok", "fail", "stall"] as const) };
    case "park":
    case "fail-next":
      return { kind, method: rng.pick(SIGNER_METHODS) };
    case "remote":
      return {
        kind,
        action: rng.pick(["add", "remove", "grow", "stale"] as const),
        member: rng.int(members),
        delivery: rng.pick(["store", "relay", "both"] as const),
      };
    case "advance":
      return { kind, ms: rng.pick(MODEL_ADVANCE_MS) };
    default:
      return { kind } as ModelOp;
  }
}

/** One compatible template, by {@link ModelTemplate.weight} (one draw, like `rng.pick`). */
function pickTemplate(rng: Rng, templates: readonly ModelTemplate[]): ModelTemplate {
  const total = templates.reduce((sum, t) => sum + (t.weight ?? 1), 0);
  let roll = rng.next() * total;
  for (const template of templates) {
    roll -= template.weight ?? 1;
    if (roll < 0) return template;
  }
  return templates[templates.length - 1];
}

/** Generate a run from one seed: flags, initial world, an optional template and weighted noise, exactly `steps` ops. */
export function generateRun(seed: number, options: GenerateOptions): ModelRun {
  if (!Number.isInteger(options.steps) || options.steps < 1) throw new Error("steps must be a positive integer");
  if (!Number.isInteger(options.members) || options.members < 1) throw new Error("members must be positive");
  const rng = seededRng(seed);
  const compatible = MODEL_TEMPLATES.filter((t) => templateFits(t, options));
  const template = compatible.length > 0 && rng.chance(options.templateChance ?? 0.5)
    ? pickTemplate(rng, compatible)
    : undefined;
  const autoUnlock = template?.requires?.autoUnlock ?? rng.chance(0.5);
  const initial: ModelInitial = {
    fragments: rng.pick([0, 1, 2] as const),
    remoteMembers: subset(rng, options.members),
    mirrorMembers: subset(rng, options.members),
    ...template?.initial,
  };
  const ops: ModelOp[] = [];
  if (!template) {
    ops.push(rng.chance(0.9) ? { kind: "start" } : noiseOp(rng, options.members));
    while (ops.length < options.steps) ops.push(noiseOp(rng, options.members));
  } else {
    // A short noise prefix, the skeleton with occasional noise between its ops, then noise to fill.
    let noise = options.steps - template.ops.length;
    const prefix = rng.int(Math.min(noise, 3) + 1);
    for (let i = 0; i < prefix; i++) ops.push(noiseOp(rng, options.members));
    noise -= prefix;
    template.ops.forEach((op, index) => {
      if (index > 0 && noise > 0 && rng.chance(0.2)) {
        ops.push(noiseOp(rng, options.members));
        noise--;
      }
      ops.push(structuredClone(op));
    });
    while (ops.length < options.steps) ops.push(noiseOp(rng, options.members));
  }
  return {
    seed,
    autoSave: options.autoSave,
    autoUnlock,
    ...(template ? { template: template.name } : {}),
    initial,
    ops,
  };
}

// ---------------------------------------------------------------------------------------------------------------
// Members and fragments
// ---------------------------------------------------------------------------------------------------------------

/** Pre-built memberships the runner joins, leaves and writes from other devices. */
export interface MemberPool {
  /** Join material per member index. */
  materials: JoinMaterial[];
  /** The matching invite bundles, as `join` takes them. */
  bundles: InviteBundle[];
}

/** Build `count` memberships owned by a fixed key on `wss://fake`; build it once per test file (it is slow). */
export async function buildMemberPool(count: number): Promise<MemberPool> {
  const owner = new PrivateKeySigner(sha256(new TextEncoder().encode("concord model owner")));
  const ownerPubkey = await owner.getPublicKey();
  const materials: JoinMaterial[] = [];
  const bundles: InviteBundle[] = [];
  for (let i = 0; i < count; i++) {
    const name = `M${i}`;
    const created = (await createLegacyCommunity({ ownerPubkey, name, relays: ["wss://fake"] })).material;
    const material = { ...created, held_roots: created.held_roots ?? [] };
    materials.push(material);
    bundles.push(buildInviteBundle(material, { name }));
  }
  return { materials, bundles };
}

/** Another device's kind-33302 fragment at `index`, self-encrypted and signed by `signer`. */
export async function remoteFragment(
  signer: PrivateKeySigner,
  index: number,
  doc: CommunityListFragment,
  createdAt: number,
): Promise<NostrEvent> {
  const pubkey = await signer.getPublicKey();
  return signer.signEvent({
    kind: COMMUNITY_LIST_FRAGMENT_KIND,
    created_at: createdAt,
    tags: [["d", String(index)]],
    content: await signer.nip44.encrypt(pubkey, encodeCommunityListFragment(doc)),
  });
}

/** What a set of fragments says, by the CORD-02 §8 rules. */
export interface FragmentView {
  /** The governing fragment count. */
  count: number;
  /** Sorted ids of the live memberships in the in-range union. */
  live: string[];
  /** The merged tombstones of the in-range union. */
  tombstones: CommunityTombstone[];
}

function fragmentIndex(event: NostrEvent): number | undefined {
  const d = event.tags.find((tag) => tag[0] === "d")?.[1];
  if (d === undefined || !/^(0|[1-9]\d*)$/.test(d)) return undefined;
  const index = Number(d);
  return Number.isSafeInteger(index) ? index : undefined;
}

type OpenedFragment = { event: NostrEvent; doc: CommunityListFragment };

/** CORD-02 §8 by hand: the winner per index (newest; ties: lower id), the governing count and the newest winner age. */
function governing(fragments: readonly OpenedFragment[]): {
  winners: Map<number, OpenedFragment>;
  count: number;
  age: number;
} {
  const winners = new Map<number, OpenedFragment>();
  for (const fragment of fragments) {
    const index = fragmentIndex(fragment.event);
    if (index === undefined) continue;
    const prior = winners.get(index);
    if (
      !prior || fragment.event.created_at > prior.event.created_at ||
      (fragment.event.created_at === prior.event.created_at && fragment.event.id < prior.event.id)
    ) winners.set(index, fragment);
  }
  let age = -Infinity, count = 1;
  for (const { event, doc } of winners.values()) {
    if (event.created_at > age) {
      age = event.created_at;
      count = doc.frags;
    } else if (event.created_at === age) count = Math.max(count, doc.frags);
  }
  return { winners, count, age };
}

/**
 * CORD-02 §8 by hand: per index the higher `created_at` wins (ties: lower id); the newest winner's `frags` governs
 * (equal-age winners: the larger); the document is the union of winners below the count. No fragments: count 1.
 */
export function fragmentView(fragments: readonly { event: NostrEvent; doc: CommunityListFragment }[]): FragmentView {
  const { winners, count } = governing(fragments);
  let entries: CommunityListCommunity[] = [];
  let tombstones: CommunityTombstone[] = [];
  for (const [index, { doc }] of winners) {
    if (index >= count) continue;
    entries = mergeCommunities(entries, doc.entries);
    tombstones = mergeCommunityTombstones(tombstones, doc.tombstones);
  }
  const live = [...new Set(liveCommunities(entries, tombstones).map((e) => e.community_id))].sort();
  return { count, live, tombstones };
}

// ---------------------------------------------------------------------------------------------------------------
// Trace format
// ---------------------------------------------------------------------------------------------------------------

/** The client's knowledge states, mirrored locally so the core imports nothing from src/client. */
export type ModelKnowledge = "unknown" | "confirmed-empty" | "partial" | "complete";
/** Probes the runner records after the last op, in this order (liveness probes only while started). */
export type ProbeName = "quiescence-start" | "quiescence-end" | "liveness-healed" | "liveness-nudged" | "final";

/** One probe: the runner's own model state plus client outputs being graded and runner counters. */
export interface ProbeSnapshot {
  /** The runner's model state, never read from the client. */
  started: boolean;
  /** The runner's model state, never read from the client. */
  disposed: boolean;
  /** Client output: owned duties still pending. */
  pendingDuties: number;
  /** Client output: the reported Community List knowledge. */
  knowledge: ModelKnowledge;
  /** Client output: a held write is pending. */
  pending: boolean;
  /** Client output: the list is dirty. */
  dirty: boolean;
  /** Client output: live community ids of the local copy. */
  localLive: string[];
  /** Runner-derived: live community ids of the store's fragments, decrypted with the runner's key. */
  storeLive: string[];
  /** Runner-derived: ids of the user's kind-33302 fragments in the store at the probe. */
  storeIds: string[];
  /** Runner counter: kind-33302 reads so far. */
  reads: number;
  /** Runner counter: scripted signer calls so far. */
  signerCalls: number;
  /** Runner counter: ops not yet settled. */
  unsettledOps: number;
}

/** What the scripted relay answered to a kind-33302 publish. */
export type PublishOutcome = "accepted" | "refused-transient" | "refused-permanent";
/** What the scripted relay actually did with a read ("abandoned": the client unsubscribed first). */
export type ReadOutcome = "complete" | "error" | "partial" | "abandoned";
/** Why read evidence was invalidated ("remote-arrived" only demands an ingest before the next publish). */
export type EvidenceResetCause = "start" | "stop" | "dispose" | "ingest-failed" | "remote-arrived";

/**
 * One runner-recorded trace entry; `seq` is global and strictly increasing, `step` the op index.
 *
 * - `op.cid`: the pool member's community id the op touches, recorded for `join`, `leave` and remote `add`, `remove`
 *   and `grow` (a remote `stale` write touches no membership and records none).
 * - `signer-call.kind`: for `signEvent`, the draft's kind.
 * - `signer-call.carries`: for a Community List save's `encrypt` (a plaintext that decodes as a fragment) and its
 *   kind-33302 `signEvent`, the sorted community ids of that fragment's entries and tombstones, decoded by the runner
 *   with its own key; absent for every other call.
 */
export type TraceEntry =
  | {
    type: "op";
    seq: number;
    step: number;
    op: ModelOp;
    input: boolean;
    result: "ok" | "rejected" | "pending";
    errorName?: string;
    cid?: string;
  }
  | { type: "op-settled"; seq: number; step: number; opSeq: number; result: "ok" | "rejected"; errorName?: string }
  | { type: "read-start"; seq: number; step: number; lifecycle: number; readId: number }
  | {
    type: "read";
    seq: number;
    step: number;
    lifecycle: number;
    readId: number;
    mode: ReadMode;
    outcome: ReadOutcome;
    served: string[];
    storeIds: string[];
  }
  | {
    type: "ingest";
    seq: number;
    step: number;
    lifecycle: number;
    eventId: string;
    unlock: boolean;
    outcome: "ok" | "auth-failed" | "failed";
  }
  | {
    type: "evidence-reset";
    seq: number;
    step: number;
    lifecycle: number;
    cause: EvidenceResetCause;
    eventId?: string;
  }
  | {
    type: "publish";
    seq: number;
    step: number;
    lifecycle: number;
    event: NostrEvent;
    storeFragmentIds: string[];
    /** The client's reported knowledge: cross-check only, never a pass condition. */
    clientKnowledge: ModelKnowledge;
    /** What the runner scripted the relay to answer to this publish attempt. */
    outcome: PublishOutcome;
  }
  | {
    type: "signer-call";
    seq: number;
    step: number;
    method: SignerMethod;
    outcome: "ok" | "fail" | "stall";
    kind?: number;
    carries?: string[];
  }
  | { type: "diagnostic"; seq: number; step: number; stage: string; duty?: string; key?: string }
  | { type: "probe"; seq: number; step: number; name: ProbeName; snapshot: ProbeSnapshot };

/** A recorded run: the run, its entries and every kind-33302 event the runner created or saw published, by id. */
export interface ModelTrace {
  /** The run that produced the trace. */
  run: ModelRun;
  /** Entries in `seq` order. */
  entries: TraceEntry[];
  /** Kind-33302 events by id. */
  fragments: Record<string, NostrEvent>;
}

/** Retry budget the runner passes in (the library's read retry `maxAttempts`, never imported here). */
export interface ModelBudget {
  /** Read attempts per duty key. */
  maxAttempts: number;
}

/** One broken invariant, at the offending entry. */
export interface ModelViolation {
  /** D-31 invariant number. */
  invariant: 1 | 2 | 3 | 4 | 5 | 6;
  /** `seq` of the offending entry. */
  seq: number;
  /** Names the event id, `d` index, community id or probe involved. */
  message: string;
}

/** What the checker needs beyond the trace. */
export interface CheckContext {
  /** Decrypt a kind-33302 event with the runner's own key. */
  decrypt(event: NostrEvent): Promise<CommunityListFragment>;
  /** The retry budget. */
  budget: ModelBudget;
}

// ---------------------------------------------------------------------------------------------------------------
// Oracle helpers (runner-recorded entries only)
// ---------------------------------------------------------------------------------------------------------------

const HARD_RESETS: ReadonlySet<EvidenceResetCause> = new Set<EvidenceResetCause>([
  "start",
  "stop",
  "dispose",
  "ingest-failed",
]);
const NOT_STARTED_ERROR = "ConcordClientNotStartedError";
const DISPOSED_ERROR = "ConcordClientDisposedError";

type Entry<T extends TraceEntry["type"]> = Extract<TraceEntry, { type: T }>;
type Evidence = { ok: true; readId: number; readSeq: number } | { ok: false; reason: string };

const short = (id: string): string => id.slice(0, 8);
const dIndex = (event: NostrEvent): string => event.tags.find((tag) => tag[0] === "d")?.[1] ?? "?";

/** The latest ingest of `eventId` in `lifecycle` strictly between `from` and `to`. */
function latestIngest(
  entries: readonly TraceEntry[],
  eventId: string,
  lifecycle: number,
  from: number,
  to: number,
): Entry<"ingest"> | undefined {
  let latest: Entry<"ingest"> | undefined;
  for (const entry of entries) {
    if (entry.type !== "ingest" || entry.eventId !== eventId || entry.lifecycle !== lifecycle) continue;
    if (entry.seq <= from || entry.seq >= to) continue;
    if (!latest || entry.seq > latest.seq) latest = entry;
  }
  return latest;
}

/**
 * Trace-only read evidence at `seq` in runner lifecycle `lifecycle` (D-29, D-31 invariant 1): (a) a completed read of
 * this lifecycle whose read-start follows the latest hard reset; (b) every id it served or saw stored has, as its
 * latest ingest, an outcome other than "auth-failed" ("failed" is a post-authentication failure: it counts here and
 * invariant 2 independently grades any publish that hides the fragment's content), unless a newer copy of the same `d`
 * index is among the read's stored ids (CORD-02 §8: per index the newest wins, and the store refuses the older copy, so
 * it can never be ingested; the newer copy is itself held to this rule); (c) every arrival since the read began was
 * ingested (not "auth-failed") before `seq`. The client's reported status plays no part.
 */
function oracleEvidence(
  entries: readonly TraceEntry[],
  fragments: Readonly<Record<string, NostrEvent>>,
  seq: number,
  lifecycle: number,
): Evidence {
  let hard: Entry<"evidence-reset"> | undefined;
  const starts = new Map<number, number>();
  const completed: Entry<"read">[] = [];
  for (const entry of entries) {
    if (entry.seq >= seq) continue;
    if (entry.type === "evidence-reset" && HARD_RESETS.has(entry.cause)) {
      if (!hard || entry.seq > hard.seq) hard = entry;
    } else if (entry.type === "read-start" && entry.lifecycle === lifecycle) starts.set(entry.readId, entry.seq);
    else if (entry.type === "read" && entry.lifecycle === lifecycle && entry.outcome === "complete") {
      completed.push(entry);
    }
  }
  const after = hard?.seq ?? -Infinity;
  const candidates = completed.filter((read) => (starts.get(read.readId) ?? -Infinity) > after)
    .sort((a, b) => b.seq - a.seq);
  if (candidates.length === 0) {
    const since = hard ? `the "${hard.cause}" evidence reset at seq ${hard.seq}` : "the trace began";
    return { ok: false, reason: `no read completed in lifecycle ${lifecycle} that began after ${since}` };
  }
  let reason = "";
  for (const read of candidates) {
    const begun = starts.get(read.readId)!;
    const missing = [...new Set([...read.served, ...read.storeIds])].find((id) =>
      (latestIngest(entries, id, lifecycle, -Infinity, seq)?.outcome ?? "auth-failed") === "auth-failed" &&
      !supersededIn(fragments, id, read.storeIds)
    );
    if (missing !== undefined) {
      const latest = latestIngest(entries, missing, lifecycle, -Infinity, seq);
      reason ||= `fragment ${short(missing)} served or stored at read #${read.readId} (seq ${read.seq}) was not ` +
        `ingested (${latest ? `latest ingest ${latest.outcome} at seq ${latest.seq}` : "no ingest"})`;
      continue;
    }
    const arrival = entries.find((entry): entry is Entry<"evidence-reset"> =>
      entry.type === "evidence-reset" && entry.cause === "remote-arrived" && entry.lifecycle === lifecycle &&
      entry.seq > begun && entry.seq < seq &&
      (entry.eventId === undefined ||
        (latestIngest(entries, entry.eventId, lifecycle, entry.seq, seq)?.outcome ?? "auth-failed") === "auth-failed")
    );
    if (arrival) {
      reason ||= `fragment ${short(arrival.eventId ?? "?")} arrived at seq ${arrival.seq}, after read ` +
        `#${read.readId} began, and was not ingested before seq ${seq}`;
      continue;
    }
    return { ok: true, readId: read.readId, readSeq: read.seq };
  }
  return { ok: false, reason };
}

/** Whether a newer copy of `id`'s `d` index (CORD-02 §8 newest wins; ties: the lower id) is among `storeIds`. */
function supersededIn(fragments: Readonly<Record<string, NostrEvent>>, id: string, storeIds: readonly string[]) {
  const event = fragments[id];
  if (!event) return false;
  return storeIds.some((other) => {
    const newer = fragments[other];
    return other !== id && newer !== undefined && dIndex(newer) === dIndex(event) &&
      (newer.created_at > event.created_at || (newer.created_at === event.created_at && newer.id < event.id));
  });
}

/** The runner lifecycle current at `seq`: that of the latest lifecycle-carrying entry before it (0 if none). */
function lifecycleAt(entries: readonly TraceEntry[], seq: number): number {
  let lifecycle = 0, at = -Infinity;
  for (const entry of entries) {
    if (entry.seq >= seq || entry.seq <= at || !("lifecycle" in entry)) continue;
    at = entry.seq;
    lifecycle = entry.lifecycle;
  }
  return lifecycle;
}

const LIFECYCLE_RESETS: ReadonlySet<EvidenceResetCause> = new Set<EvidenceResetCause>(["start", "stop", "dispose"]);

/**
 * D-04 residual corroboration, from runner entries only: the last `maxAttempts` reads of `lifecycle` before `seq` all
 * began after its latest start, stop or dispose reset, and each attempt failed in the scripted world: the relay did not
 * complete it, or an ingest failed authentication (the scripted signer threw from `getPublicKey`) between its start and
 * the next read's start. Each such authentication failure is itself a hard reset, so "reads after the latest hard
 * reset" alone could never corroborate a retry exhausted by a failing signer.
 */
function exhaustedAttempts(entries: readonly TraceEntry[], seq: number, lifecycle: number, maxAttempts: number) {
  let boundary = -Infinity;
  for (const e of entries) {
    if (e.type === "evidence-reset" && LIFECYCLE_RESETS.has(e.cause) && e.seq < seq) {
      boundary = Math.max(boundary, e.seq);
    }
  }
  const starts = entries.filter((e): e is Entry<"read-start"> =>
    e.type === "read-start" && e.lifecycle === lifecycle && e.seq > boundary && e.seq < seq
  ).sort((a, b) => a.seq - b.seq);
  const attempts = starts.slice(-maxAttempts);
  if (attempts.length < maxAttempts) return false;
  return attempts.every((start, index) => {
    const read = entries.find((e): e is Entry<"read"> =>
      e.type === "read" && e.lifecycle === lifecycle && e.readId === start.readId && e.seq < seq
    );
    if (!read) return false;
    if (read.outcome !== "complete") return true;
    const until = attempts[index + 1]?.seq ?? seq;
    return entries.some((e) =>
      e.type === "ingest" && e.lifecycle === lifecycle && e.outcome === "auth-failed" && e.seq > start.seq &&
      e.seq < until
    );
  });
}

/** One op's final outcome: its op-settled entry when present, otherwise its own result. */
interface OpOutcome {
  op: Entry<"op">;
  result: "ok" | "rejected" | "pending";
  errorName?: string;
  started: boolean;
  disposed: boolean;
}

/**
 * The runner's model, rebuilt from op entries in `seq` order: a start invoked while stopped (and not disposed) sets
 * started unless its final outcome is rejected; stop clears it; dispose clears it for good. Each op carries the
 * state before it; `at(seq)` gives the state at any entry.
 */
function runnerModel(entries: readonly TraceEntry[]): {
  ops: OpOutcome[];
  at(seq: number): { started: boolean; disposed: boolean };
} {
  const settled = new Map<number, Entry<"op-settled">>();
  for (const entry of entries) if (entry.type === "op-settled") settled.set(entry.opSeq, entry);
  const ops: OpOutcome[] = [];
  const changes: { seq: number; started: boolean; disposed: boolean }[] = [];
  let started = false, disposed = false;
  for (const op of entries.filter((e): e is Entry<"op"> => e.type === "op").sort((a, b) => a.seq - b.seq)) {
    const final = settled.get(op.seq);
    const result = final?.result ?? op.result;
    ops.push({ op, result, errorName: final?.errorName ?? op.errorName, started, disposed });
    if (op.op.kind === "start" && !started && !disposed && result !== "rejected") started = true;
    else if (op.op.kind === "stop") started = false;
    else if (op.op.kind === "dispose") {
      started = false;
      disposed = true;
    }
    changes.push({ seq: op.seq, started, disposed });
  }
  return {
    ops,
    at(seq: number) {
      let state = { started: false, disposed: false };
      for (const change of changes) if (change.seq < seq) state = change;
      return { started: state.started, disposed: state.disposed };
    },
  };
}

/** The healed probe's membership difference (local live against the store's live ids): its text and differing ids. */
function liveDifference(snapshot: ProbeSnapshot): { text: string; ids: string[] } | undefined {
  const local = new Set(snapshot.localLive), stored = new Set(snapshot.storeLive);
  const localOnly = [...local].filter((id) => !stored.has(id));
  const storedOnly = [...stored].filter((id) => !local.has(id));
  if (localOnly.length === 0 && storedOnly.length === 0) return undefined;
  return {
    text: `local live [${[...local].join(", ")}] differs from stored live [${[...stored].join(", ")}] (local only ` +
      `[${localOnly.join(", ")}], stored only [${storedOnly.join(", ")}])`,
    ids: [...localOnly, ...storedOnly],
  };
}

/** Join rejections that come before a join records anything (the lane's started check, a disposed client). */
const PRE_RECORD_ERRORS: ReadonlySet<string> = new Set([NOT_STARTED_ERROR, DISPOSED_ERROR]);

/**
 * WR-05, the runner expectation at a "liveness-healed" probe: whether each judged pool membership must be live, built
 * only from runner-recorded op entries (`cid`), their settlements and `advance` ops, never from client state.
 *
 * - Effective ops on a membership: a join that settled ok; a join that rejected with any error other than
 *   {@link PRE_RECORD_ERRORS} (it recorded the membership and keeps it, D-34); a leave that settled ok. A rejected leave
 *   recorded nothing (its Leave is published before the tombstone).
 * - Judged only when it has an effective op, no remote op names it (another device's write), no join or leave of it is
 *   unsettled at the probe, and the latest change of intent is separated by the clock: an `advance` with `ms > 0` lies
 *   after the settlement of the last opposite-intent op and before the first op of the final same-intent run (CORD-02
 *   §8: `added_at` equal to `removed_at` is dead; the fake clock moves only in `advance` ops). Overlapping
 *   opposite-intent ops therefore stay undetermined.
 * - Expected live after a join, not live after a leave.
 */
function expectedMemberships(entries: readonly TraceEntry[], seq: number): Map<string, boolean> {
  const settled = new Map<number, Entry<"op-settled">>();
  for (const e of entries) if (e.type === "op-settled" && e.seq < seq) settled.set(e.opSeq, e);
  const ops = entries.filter((e): e is Entry<"op"> => e.type === "op" && e.seq < seq).sort((a, b) => a.seq - b.seq);
  const advances = ops.filter((e) => e.op.kind === "advance" && e.op.ms > 0).map((e) => e.seq);
  const byId = new Map<string, Entry<"op">[]>();
  for (const op of ops) if (op.cid !== undefined) byId.set(op.cid, [...(byId.get(op.cid) ?? []), op]);
  const expected = new Map<string, boolean>();
  for (const [id, touching] of byId) {
    if (touching.some((e) => e.op.kind === "remote")) continue;
    const effective: { seq: number; end: number; present: boolean }[] = [];
    let unsettled = false;
    for (const op of touching) {
      if (op.op.kind !== "join" && op.op.kind !== "leave") continue;
      const final = settled.get(op.seq);
      const result = final?.result ?? op.result;
      if (result === "pending") {
        unsettled = true;
        continue;
      }
      const errorName = final?.errorName ?? op.errorName ?? "";
      const end = final?.seq ?? op.seq;
      if (op.op.kind === "join" && (result === "ok" || !PRE_RECORD_ERRORS.has(errorName))) {
        effective.push({ seq: op.seq, end, present: true });
      } else if (op.op.kind === "leave" && result === "ok") effective.push({ seq: op.seq, end, present: false });
    }
    if (unsettled || effective.length === 0) continue;
    const present = effective[effective.length - 1].present;
    let first = effective.length - 1;
    while (first > 0 && effective[first - 1].present === present) first--;
    const previous = effective[first - 1];
    if (previous && !advances.some((at) => at > previous.end && at < effective[first].seq)) continue;
    expected.set(id, present);
  }
  return expected;
}

/**
 * E2 (invariant 5 at "liveness-healed"): a fragment among the probe's stored ids that is a CORD-02 §8 winner, relevant
 * (its index is below the governing count, or it is the newest declaration), was never unlock-ingested "ok" before the
 * probe, and that only the app can decrypt (`autoUnlock` off) or whose recorded unlock ingest failed (never
 * re-prompted). Decided from runner-recorded entries and the runner's own decryption only.
 */
async function lockedRelevantFragment(
  trace: ModelTrace,
  storeIds: readonly string[],
  seq: number,
  open: (event: NostrEvent) => Promise<CommunityListFragment>,
): Promise<string | undefined> {
  const stored: OpenedFragment[] = [];
  for (const id of storeIds) {
    const event = trace.fragments[id];
    if (!event) continue; // unknown to the runner: it can never excuse anything
    try {
      stored.push({ event, doc: await open(event) });
    } catch {
      // A fragment the runner's own key cannot open is not a relevant list fragment, so it excuses nothing.
    }
  }
  const { winners, count, age } = governing(stored);
  for (const [index, { event }] of winners) {
    if (index >= count && event.created_at !== age) continue;
    const unlocks = trace.entries.filter((e): e is Entry<"ingest"> =>
      e.type === "ingest" && e.eventId === event.id && e.unlock && e.seq < seq
    );
    if (unlocks.some((e) => e.outcome === "ok")) continue;
    if (!trace.run.autoUnlock || unlocks.some((e) => e.outcome === "failed")) return event.id;
  }
  return undefined;
}

/**
 * E3 (invariant 5 at "liveness-healed"), WR-04: a reported refusal of a save that carried membership `id`.
 *
 * - Window: after the later of this lifecycle's "start" reset, the latest accepted publish and `id`'s last op entry,
 *   and before the probe. The last op is the last one whose `cid` is `id` and that changes what the client or the store
 *   holds for it: a join, a leave, or another device's write delivered to the store (a relay-only write reaches neither
 *   until a read, model seed 40). For an id no op names, a created community, it is the latest `create` op.
 * - In the window: (i) a qualifying failure, then (ii) a `community-list-save` diagnostic.
 * - Qualifying: a `getPublicKey` failure (not attributable, so it counts for any membership); an `encrypt` failure, or
 *   a `signEvent` failure of a kind-33302 draft, whose recorded `carries` includes `id`; a publish the runner refused
 *   whose fragment, opened with the checker's own decrypt, holds `id` among its entries or tombstones. A `signEvent`
 *   failure of any other kind (a guestbook seal, a genesis edition) and a `decrypt` failure never qualify.
 * - With `id` undefined: a reported refusal of any list save in the window, with no op bound, the residual for a
 *   pending write with no membership difference.
 *
 * A reported refusal is an accepted residual: D-34 keeps a rejected join's membership, and its save may still be
 * refused.
 */
async function reportedFailure(
  entries: readonly TraceEntry[],
  seq: number,
  lifecycle: number,
  id: string | undefined,
  open: (event: NostrEvent) => Promise<CommunityListFragment>,
): Promise<boolean> {
  let from = -Infinity, lastOp = -Infinity, lastCreate = -Infinity;
  for (const e of entries) {
    if (e.seq >= seq) continue;
    if (e.type === "evidence-reset" && e.cause === "start" && e.lifecycle === lifecycle) from = Math.max(from, e.seq);
    if (e.type === "publish" && e.outcome === "accepted") from = Math.max(from, e.seq);
    if (e.type === "op" && id !== undefined && e.cid === id && (e.op.kind !== "remote" || e.op.delivery !== "relay")) {
      lastOp = Math.max(lastOp, e.seq);
    }
    if (e.type === "op" && e.op.kind === "create") lastCreate = Math.max(lastCreate, e.seq);
  }
  if (id !== undefined) from = Math.max(from, lastOp > -Infinity ? lastOp : lastCreate);
  const carries = (list: readonly string[] | undefined) =>
    list !== undefined && (id === undefined || list.includes(id));
  for (const e of entries) {
    if (e.seq <= from || e.seq >= seq) continue;
    let qualifies = false;
    if (e.type === "signer-call" && e.outcome === "fail") {
      qualifies = e.method === "getPublicKey" || (e.method === "encrypt" && carries(e.carries)) ||
        (e.method === "signEvent" && e.kind === COMMUNITY_LIST_FRAGMENT_KIND && carries(e.carries));
    } else if (e.type === "publish" && e.outcome !== "accepted") {
      try {
        const doc = await open(e.event);
        qualifies = carries([...doc.entries, ...doc.tombstones].map((item) => item.community_id));
      } catch {
        // A refused fragment the runner's key cannot open carries no membership it can attribute.
      }
    }
    if (!qualifies) continue;
    const failure = e.seq;
    if (
      entries.some((d) =>
        d.type === "diagnostic" && d.stage === "community-list-save" && d.seq > failure && d.seq < seq
      )
    ) {
      return true;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------------------------------------------
// Checker
// ---------------------------------------------------------------------------------------------------------------

/**
 * Evaluate the six D-31 invariants over a recorded trace and return every violation. Pass conditions come from
 * runner-recorded entries; client-reported probe values can only fail a run, never excuse one.
 */
export async function checkModelTrace(trace: ModelTrace, context: CheckContext): Promise<ModelViolation[]> {
  const { entries } = trace;
  const violations: ModelViolation[] = [];
  const report = (invariant: ModelViolation["invariant"], seq: number, message: string) =>
    violations.push({ invariant, seq, message });
  const model = runnerModel(entries);
  const publishes = entries.filter((e): e is Entry<"publish"> => e.type === "publish");
  const probes = entries.filter((e): e is Entry<"probe"> => e.type === "probe");
  const reads = entries.filter((e): e is Entry<"read"> => e.type === "read");
  const distinctFragments = Object.keys(trace.fragments).length;
  const { maxAttempts } = context.budget;

  // 1. Evidence (D-13, D-21, D-29): every publish needs this lifecycle's completed, fully ingested read.
  for (const publish of publishes) {
    const evidence = oracleEvidence(entries, trace.fragments, publish.seq, publish.lifecycle);
    if (!evidence.ok) {
      report(1, publish.seq, `publish ${short(publish.event.id)} d=${dIndex(publish.event)}: ${evidence.reason}`);
    }
  }

  // 2. No demotion or drop (LIST-02, CORD-02 §8): compare the store's view with and without the published fragment.
  const decrypted = new Map<string, Promise<CommunityListFragment>>();
  const open = (event: NostrEvent): Promise<CommunityListFragment> => {
    if (!decrypted.has(event.id)) decrypted.set(event.id, context.decrypt(event));
    return decrypted.get(event.id)!;
  };
  /** Own publications that raised the governing count above the view they replaced, with the count they declared. */
  const raisedTo = new Map<string, number>();
  for (const publish of publishes) {
    const label = `publish ${short(publish.event.id)} d=${dIndex(publish.event)}`;
    let known: { event: NostrEvent; doc: CommunityListFragment }[];
    let own: CommunityListFragment;
    try {
      known = await Promise.all(
        publish.storeFragmentIds.filter((id) => id !== publish.event.id).map(async (id) => {
          const event = trace.fragments[id];
          if (!event) throw new Error(`stored fragment ${short(id)} is missing from trace.fragments`);
          return { event, doc: await open(event) };
        }),
      );
      own = await open(publish.event);
    } catch (error) {
      report(2, publish.seq, `${label}: harness error: ${error instanceof Error ? error.message : String(error)}`);
      continue;
    }
    const before = fragmentView(known);
    const after = fragmentView([...known, { event: publish.event, doc: own }]);
    if (after.count > before.count) raisedTo.set(publish.event.id, after.count);
    if (after.count < before.count) {
      // A staged repack (CORD-02 §8, D-17) raises the count to a temporary value, copies the content, then lowers it
      // again; that demotion is lossless by construction and is graded below as a drop or a hidden membership. It is
      // excused only when this lifecycle's own earlier publication raised the count to the value being left and the
      // declaration governing the view is itself this lifecycle's own publication. Anything else (a count declared in
      // an earlier lifecycle, or another device's raise to a count this client once declared) is a plain demotion.
      const ownEarlier = publishes.filter((p) => p.seq < publish.seq && p.lifecycle === publish.lifecycle);
      const { winners, age } = governing(known);
      const governedByOwn = [...winners.values()].some(({ event, doc }) =>
        event.created_at === age && doc.frags === before.count && ownEarlier.some((p) => p.event.id === event.id)
      );
      const raised = ownEarlier.some((p) => raisedTo.get(p.event.id) === before.count);
      if (!governedByOwn || !raised) {
        report(2, publish.seq, `${label} lowers the governing count from ${before.count} to ${after.count}`);
      }
    }
    for (const tombstone of before.tombstones) {
      const kept = after.tombstones.some((t) =>
        t.community_id === tombstone.community_id && t.removed_at >= tombstone.removed_at
      );
      if (!kept) report(2, publish.seq, `${label} drops the tombstone of community ${tombstone.community_id}`);
    }
    for (const id of before.live) {
      if (after.live.includes(id)) continue;
      const left = entries.some((e) =>
        e.type === "op" && e.seq < publish.seq && e.op.kind === "leave" && e.cid === id &&
        (e.result === "ok" || e.result === "pending")
      );
      if (!left) report(2, publish.seq, `${label} hides the live membership ${id}`);
    }
  }

  // 3. Lifecycle (D-30, D-32): judged by the runner's model and each op's final outcome, never by client flags.
  for (const outcome of model.ops) {
    const { op } = outcome;
    const kind = op.op.kind;
    if (kind === "start" && outcome.disposed) {
      if (outcome.result === "ok" || (outcome.result === "rejected" && outcome.errorName !== DISPOSED_ERROR)) {
        report(
          3,
          op.seq,
          `start after dispose ${
            outcome.result === "ok" ? "succeeded" : `rejected with ${outcome.errorName}`
          }, expected ${DISPOSED_ERROR}`,
        );
      }
    } else if ((kind === "join" || kind === "leave" || kind === "create") && !outcome.started) {
      const expected = outcome.disposed ? DISPOSED_ERROR : NOT_STARTED_ERROR;
      if (outcome.result === "ok" || (outcome.result === "rejected" && outcome.errorName !== expected)) {
        report(
          3,
          op.seq,
          `${kind} while not started ${
            outcome.result === "ok" ? "succeeded" : `rejected with ${outcome.errorName}`
          }, expected ${expected}`,
        );
      }
    }
  }
  for (const publish of publishes) {
    const state = model.at(publish.seq);
    if (!state.started) {
      report(
        3,
        publish.seq,
        `publish ${short(publish.event.id)} d=${dIndex(publish.event)} while the runner's model is ${
          state.disposed ? "disposed" : "stopped"
        }`,
      );
    }
  }

  // 4. Bounded (D-04, D-24, FND-02): a linear read bound overall and quiet duties after a long quiet period.
  const starts = model.ops.filter((o) => o.op.op.kind === "start" && o.result !== "rejected").length;
  const inputs = entries.filter((e) => e.type === "op" && e.input).length;
  const readBound = starts + maxAttempts * (2 + inputs + distinctFragments);
  if (reads.length > readBound) {
    const offending = [...reads].sort((a, b) => a.seq - b.seq)[readBound];
    report(
      4,
      offending.seq,
      `${reads.length} kind-33302 reads exceed the bound ${readBound} (starts ${starts}, inputs ${inputs}, fragments ${distinctFragments})`,
    );
  }
  const quietStart = probes.find((p) => p.name === "quiescence-start");
  const quietEnd = probes.find((p) => p.name === "quiescence-end");
  if (quietEnd) {
    const from = quietStart?.seq ?? -Infinity;
    const between = (type: "read" | "signer-call") =>
      entries.filter((e) => e.type === type && e.seq > from && e.seq < quietEnd.seq).length;
    const readsDelta = Math.max(between("read"), quietEnd.snapshot.reads - (quietStart?.snapshot.reads ?? 0));
    const signerDelta = Math.max(
      between("signer-call"),
      quietEnd.snapshot.signerCalls - (quietStart?.snapshot.signerCalls ?? 0),
    );
    if (quietEnd.snapshot.pendingDuties > 0) {
      report(4, quietEnd.seq, `quiescence-end: ${quietEnd.snapshot.pendingDuties} duties still pending`);
    }
    if (readsDelta > maxAttempts * (1 + distinctFragments)) {
      report(
        4,
        quietEnd.seq,
        `quiescence-end: ${readsDelta} reads during quiescence exceed ${maxAttempts * (1 + distinctFragments)}`,
      );
    }
    const signerBound = (readsDelta + 1) * (distinctFragments + 2) * 4;
    if (signerDelta > signerBound) {
      report(4, quietEnd.seq, `quiescence-end: ${signerDelta} signer calls during quiescence exceed ${signerBound}`);
    }
  }

  // 5. No stranded evidence or held write (D-15, D-30): trace evidence first; client knowledge only as an output.
  // At "liveness-healed" (a quiescent point before any app nudge; only time advanced since the heal) a held write is
  // stranded unless runner-recorded entries excuse it (IN-02): E1 the exhausted read retry, E2 a relevant fragment only
  // the app can decrypt or whose decrypt failed, E3 a reported refusal of a save that carried that membership (WR-04).
  // Memberships are also judged against the runner expectation built from the app's own join and leave outcomes
  // (WR-05): against stored live it is excused like any difference, against local live never (only E1 excuses the whole
  // probe). There is no D-28 excuse: the runner is single-relay, so a vault relay down while another answers empty is
  // unreachable.
  const lastInput = entries.reduce((max, e) => (e.type === "op" && e.input ? Math.max(max, e.seq) : max), -Infinity);
  for (const probe of probes) {
    if (probe.name !== "liveness-healed" && probe.name !== "liveness-nudged") continue;
    if (!model.at(probe.seq).started) continue;
    const snapshot = probe.snapshot;
    if (probe.name === "liveness-healed") {
      const lifecycle = lifecycleAt(entries, probe.seq);
      const evidence = oracleEvidence(entries, trace.fragments, probe.seq, lifecycle);
      const evidenceProblems = [
        ...(evidence.ok ? [] : [evidence.reason]),
        ...(snapshot.knowledge === "unknown" ? ["the client reports knowledge unknown"] : []),
      ];
      // Membership problems, each excusable only by E2 or by E3 for its own ids; the runner expectation against the
      // local copy is never excused (an app call writes the local document in the lane whatever relays do).
      const local = new Set(snapshot.localLive), stored = new Set(snapshot.storeLive);
      const memberProblems: { text: string; ids: string[]; excusable: boolean }[] = [];
      for (const [id, present] of expectedMemberships(entries, probe.seq)) {
        const intent = present ? `${id} is joined` : `${id} was left`;
        if (local.has(id) !== present) {
          memberProblems.push({
            text: `runner expectation: ${intent} but local live ${present ? "lacks" : "holds"} ${id} (never excused)`,
            ids: [id],
            excusable: false,
          });
        }
        if (stored.has(id) !== present) {
          memberProblems.push({
            text: `runner expectation: ${intent} but stored live ${present ? "lacks" : "holds"} ${id}`,
            ids: [id],
            excusable: true,
          });
        }
      }
      const difference = liveDifference(snapshot);
      if (difference) memberProblems.push({ text: difference.text, ids: difference.ids, excusable: true });
      if (evidenceProblems.length === 0 && memberProblems.length === 0 && !snapshot.pending) continue;
      // E1, the D-04 accepted residual: an exhausted retry, proven by both the diagnostic and the runner's own reads.
      const exhausted = entries.some((e) =>
        e.type === "diagnostic" && e.stage === "duty-exhausted" && e.seq > lastInput && e.seq < probe.seq
      );
      if (exhausted && exhaustedAttempts(entries, probe.seq, lifecycle, maxAttempts)) continue;
      const absent = ["no exhausted retry (E1)"];
      const problems = [...evidenceProblems];
      const needsExcuse = memberProblems.some((p) => p.excusable) || (snapshot.pending && memberProblems.length === 0);
      const locked = needsExcuse ? await lockedRelevantFragment(trace, snapshot.storeIds, probe.seq, open) : undefined;
      if (needsExcuse && !locked) absent.push("no locked relevant fragment (E2)");
      const unreported = new Set<string>();
      let excuses = 0;
      for (const problem of memberProblems) {
        if (!problem.excusable) {
          problems.push(problem.text);
          continue;
        }
        let excused = locked !== undefined;
        if (!excused) {
          const missing: string[] = [];
          for (const id of problem.ids) {
            if (!(await reportedFailure(entries, probe.seq, lifecycle, id, open))) missing.push(id);
          }
          for (const id of missing) unreported.add(id);
          excused = missing.length === 0;
        }
        if (excused) excuses++;
        else problems.push(problem.text);
      }
      if (snapshot.pending) {
        // A pending write is excused only when every membership problem was excused by at least one excuse, or, with no
        // membership problem, by E2 or a reported refusal of any list save in the window.
        const allExcused = memberProblems.length > 0 && excuses === memberProblems.length;
        const alone = memberProblems.length === 0 &&
          (locked !== undefined || await reportedFailure(entries, probe.seq, lifecycle, undefined, open));
        if (!allExcused && !alone) {
          problems.push("a write is still pending");
          if (memberProblems.length === 0 && !locked) unreported.add("any list save");
        }
      }
      if (unreported.size > 0) {
        absent.push(`no corroborated reported failure (E3) for [${[...unreported].join(", ")}]`);
      }
      if (problems.length === 0) continue;
      report(5, probe.seq, `liveness-healed: ${problems.join("; ")} and ${absent.join(", ")} excuses it`);
    } else {
      const problems: string[] = [];
      if (snapshot.knowledge === "unknown" || snapshot.knowledge === "partial") {
        problems.push(`knowledge ${snapshot.knowledge}`);
      }
      if (snapshot.pending) problems.push("a write is still pending");
      if (snapshot.dirty) problems.push("the list is still dirty");
      if (snapshot.pendingDuties > 0) problems.push(`${snapshot.pendingDuties} duties pending`);
      const local = new Set(snapshot.localLive), stored = new Set(snapshot.storeLive);
      const differ = local.size !== stored.size || [...local].some((id) => !stored.has(id));
      if (differ) {
        problems.push(`local live [${[...local].join(", ")}] differs from stored live [${[...stored].join(", ")}]`);
      }
      if (problems.length > 0) report(5, probe.seq, `liveness-nudged: ${problems.join("; ")}`);
    }
  }

  // 6. Settled: every op settles once stalls are released.
  const settledOps = new Set(entries.flatMap((e) => (e.type === "op-settled" ? [e.opSeq] : [])));
  for (const probe of probes) {
    if (probe.name !== "final") continue;
    const unsettled = entries.filter((e) => e.type === "op" && e.result === "pending" && !settledOps.has(e.seq));
    if (probe.snapshot.unsettledOps > 0 || unsettled.length > 0) {
      const steps = unsettled.map((e) => e.step).join(", ");
      report(
        6,
        probe.seq,
        `final: ${Math.max(probe.snapshot.unsettledOps, unsettled.length)} ops never settled${
          steps ? ` (steps ${steps})` : ""
        }`,
      );
    }
  }

  return violations.sort((a, b) => a.seq - b.seq || a.invariant - b.invariant);
}

/**
 * Diagnostic notes where the client's reported knowledge disagrees with the trace-derived evidence (at publishes and
 * at "liveness-healed" and "final" probes). Never a violation; `checkModelTrace` never calls it.
 */
export function crossCheckModelTrace(trace: ModelTrace): string[] {
  const { entries } = trace;
  const model = runnerModel(entries);
  const notes: string[] = [];
  for (const entry of entries) {
    if (entry.type === "publish") {
      const evidence = oracleEvidence(entries, trace.fragments, entry.seq, entry.lifecycle);
      const known = entry.clientKnowledge !== "unknown";
      if (evidence.ok && !known) {
        notes.push(
          `seq ${entry.seq}: the client reported knowledge unknown while publishing ` +
            `${short(entry.event.id)}; the trace shows qualifying read #${evidence.readId}`,
        );
      } else if (!evidence.ok && known) {
        notes.push(
          `seq ${entry.seq}: the client reported knowledge ${entry.clientKnowledge} while publishing ` +
            `${short(entry.event.id)}; the trace shows ${evidence.reason}`,
        );
      }
    } else if (entry.type === "probe" && (entry.name === "liveness-healed" || entry.name === "final")) {
      if (!model.at(entry.seq).started) continue;
      const evidence = oracleEvidence(entries, trace.fragments, entry.seq, lifecycleAt(entries, entry.seq));
      const known = entry.snapshot.knowledge !== "unknown";
      if (evidence.ok !== known) {
        notes.push(
          `seq ${entry.seq}: ${entry.name} probe reports knowledge ${entry.snapshot.knowledge}; the trace ` +
            (evidence.ok ? `shows qualifying read #${evidence.readId}` : `shows ${evidence.reason}`),
        );
      }
    }
  }
  return notes;
}

// ---------------------------------------------------------------------------------------------------------------
// Shrinker and formatter
// ---------------------------------------------------------------------------------------------------------------

/**
 * Greedy delta debugging: remove halves, then quarters, down to single ops (repeating singles until stable), keeping
 * every removal that still fails. Calls `fails` at most `maxRuns` times and preserves op order.
 */
export async function shrinkOps(
  ops: readonly ModelOp[],
  fails: (ops: ModelOp[]) => Promise<boolean>,
  maxRuns: number = 200,
): Promise<ModelOp[]> {
  let current = [...ops];
  let runs = 0;
  const attempt = async (candidate: ModelOp[]): Promise<boolean> => {
    runs++;
    return await fails(candidate);
  };
  if (maxRuns < 1 || !(await attempt([...current]))) return current;
  let size = Math.max(1, Math.floor(current.length / 2));
  for (;;) {
    let changed = false;
    for (let start = 0; start < current.length && runs < maxRuns;) {
      const candidate = [...current.slice(0, start), ...current.slice(start + size)];
      if (candidate.length < current.length && await attempt(candidate)) {
        current = candidate;
        changed = true;
      } else start += size;
    }
    if (runs >= maxRuns) return current;
    if (size > 1) size = Math.max(1, Math.floor(size / 2));
    else if (!changed) return current;
  }
}

/** A one-line label for an op. */
function opLabel(op: ModelOp): string {
  switch (op.kind) {
    case "join":
    case "leave":
      return `${op.kind} member=${op.member}`;
    case "read-mode":
    case "publish-mode":
      return `${op.kind} ${op.mode}`;
    case "finish-slow":
      return `finish-slow ${op.outcome}`;
    case "signer":
      return `signer ${op.method} ${op.mode}`;
    case "park":
    case "fail-next":
      return `${op.kind} ${op.method}`;
    case "remote":
      return `remote ${op.action} member=${op.member} via ${op.delivery}`;
    case "advance":
      return `advance ${op.ms}ms`;
    default:
      return op.kind;
  }
}

/** A compact label for a trace entry: ids, indexes and outcomes only, never event content. */
function entryLabel(entry: TraceEntry): string {
  const head = `#${entry.seq} step ${entry.step}`;
  switch (entry.type) {
    case "op":
      return `${head} op ${opLabel(entry.op)} -> ${entry.result}${entry.errorName ? ` ${entry.errorName}` : ""}${
        entry.cid ? ` cid=${short(entry.cid)}` : ""
      }`;
    case "op-settled":
      return `${head} settled op #${entry.opSeq} -> ${entry.result}${entry.errorName ? ` ${entry.errorName}` : ""}`;
    case "read-start":
      return `${head} read-start #${entry.readId} L${entry.lifecycle}`;
    case "read":
      return `${head} read #${entry.readId} L${entry.lifecycle} ${entry.mode}->${entry.outcome} served=[${
        entry.served.map(short).join(",")
      }] store=[${entry.storeIds.map(short).join(",")}]`;
    case "ingest":
      return `${head} ingest ${short(entry.eventId)} L${entry.lifecycle}${
        entry.unlock ? " unlock" : ""
      } -> ${entry.outcome}`;
    case "evidence-reset":
      return `${head} evidence-reset ${entry.cause} L${entry.lifecycle}${
        entry.eventId ? ` ${short(entry.eventId)}` : ""
      }`;
    case "publish":
      return `${head} publish ${short(entry.event.id)} d=${dIndex(entry.event)} L${entry.lifecycle} store=[${
        entry.storeFragmentIds.map(short).join(",")
      }] ${entry.outcome} client=${entry.clientKnowledge}`;
    case "signer-call":
      return `${head} signer ${entry.method} -> ${entry.outcome}${
        entry.kind !== undefined ? ` kind=${entry.kind}` : ""
      }${entry.carries ? ` carries=[${entry.carries.map(short).join(",")}]` : ""}`;
    case "diagnostic":
      return `${head} diagnostic ${entry.stage}${entry.duty ? ` duty=${entry.duty}` : ""}`;
    case "probe": {
      const s = entry.snapshot;
      return `${head} probe ${entry.name} started=${s.started} disposed=${s.disposed} knowledge=${s.knowledge} ` +
        `pending=${s.pending} dirty=${s.dirty} duties=${s.pendingDuties} reads=${s.reads} signer=${s.signerCalls} ` +
        `unsettled=${s.unsettledOps} local=[${s.localLive.map(short).join(",")}] storeLive=[${
          s.storeLive.map(short).join(",")
        }] store=[${s.storeIds.map(short).join(",")}]`;
    }
  }
}

/** Printable failure: seed, flags, template, initial world, numbered ops, violations, trace tail and cross-check notes. */
export function formatModelFailure(
  run: ModelRun,
  violations: readonly ModelViolation[],
  entries?: readonly TraceEntry[],
  notes?: readonly string[],
): string {
  const lines = [
    `Community List model failure (D-31), seed ${run.seed}`,
    `Replay: set the replay constant in e2e/community-list-sync.model.test.ts to ${run.seed}`,
    `flags: autoSave=${run.autoSave} autoUnlock=${run.autoUnlock}`,
    `template: ${run.template ?? "(none)"}`,
    `initial: fragments=${run.initial.fragments} remoteMembers=[${run.initial.remoteMembers.join(", ")}] ` +
    `mirrorMembers=[${run.initial.mirrorMembers.join(", ")}]`,
    `ops (${run.ops.length}):`,
    ...run.ops.map((op, index) => `  ${String(index + 1).padStart(3)}. ${opLabel(op)}`),
    `violations (${violations.length}):`,
    ...violations.map((v) => `  invariant ${v.invariant} at seq ${v.seq}: ${v.message}`),
  ];
  if (entries && entries.length > 0) {
    const tail = entries.slice(-40);
    lines.push(`trace (last ${tail.length} of ${entries.length} entries):`, ...tail.map((e) => `  ${entryLabel(e)}`));
  }
  if (notes && notes.length > 0) lines.push("Cross-check (diagnostic only):", ...notes.map((note) => `  ${note}`));
  return lines.join("\n");
}
