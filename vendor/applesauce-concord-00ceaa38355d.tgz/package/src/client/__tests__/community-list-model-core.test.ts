// Self-tests for the D-31 Community List model core: the seeded generator, the scenario templates and the hand-written
// CORD-02 §8 fragment view must be deterministic and correct before any runner trusts them.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers";
import { sha256 } from "@noble/hashes/sha2.js";
import type { NostrEvent } from "applesauce-core/helpers/event";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  type CommunityListFragment,
  decodeCommunityListFragment,
} from "../../helpers/community-list-wire.ts";
import type { CommunityListCommunity, JoinMaterial } from "../../types.ts";
import {
  buildMemberPool,
  checkModelTrace,
  crossCheckModelTrace,
  type EvidenceResetCause,
  formatModelFailure,
  fragmentView,
  generateRun,
  isInputOp,
  MODEL_TEMPLATES,
  type ModelKnowledge,
  type ModelOp,
  type ModelRun,
  type ModelTrace,
  type ModelViolation,
  type ProbeName,
  type ProbeSnapshot,
  type PublishOutcome,
  type ReadMode,
  type ReadOutcome,
  remoteFragment,
  seededRng,
  shrinkOps,
  type SignerMethod,
  type TraceEntry,
} from "./community-list-model-core.ts";

const userSigner = new PrivateKeySigner(sha256(new TextEncoder().encode("model-core self-test user")));
const pool = await buildMemberPool(4);
const ids = pool.materials.map((m) => m.community_id);

const entry = (material: JoinMaterial, added_at: number): CommunityListCommunity => ({
  community_id: material.community_id,
  seed: material,
  current: material,
  added_at,
});

async function decrypt(event: NostrEvent): Promise<CommunityListFragment> {
  const pubkey = await userSigner.getPublicKey();
  return decodeCommunityListFragment(await userSigner.nip44.decrypt(pubkey, event.content));
}

/** A fragment event plus its document, as `fragmentView` takes it. */
async function frag(index: number, doc: CommunityListFragment, createdAt: number) {
  return { event: await remoteFragment(userSigner, index, doc, createdAt), doc };
}

const context = { decrypt, budget: { maxAttempts: 3 } };

const RUN: ModelRun = {
  seed: 1,
  autoSave: false,
  autoUnlock: true,
  initial: { fragments: 0, remoteMembers: [], mirrorMembers: [] },
  ops: [],
};

const PROBE: ProbeSnapshot = {
  started: true,
  disposed: false,
  pendingDuties: 0,
  knowledge: "complete",
  pending: false,
  dirty: false,
  localLive: [],
  storeLive: [],
  storeIds: [],
  reads: 0,
  signerCalls: 0,
  unsettledOps: 0,
};

/** Hand-built runner traces, following the runner semantics the checker relies on (plan 01-09). */
class TraceBuilder {
  readonly entries: TraceEntry[] = [];
  readonly fragments: Record<string, NostrEvent> = {};
  readonly ops: ModelOp[] = [];
  lifecycle = 0;
  /** The run's `autoUnlock` flag (E2 reads it). */
  autoUnlock = true;
  private seq = 0;
  private step = -1;
  private started = false;
  private disposed = false;
  private readId = 0;

  private push(entry: Record<string, unknown>): number {
    this.entries.push({ ...entry, seq: ++this.seq, step: Math.max(this.step, 0) } as TraceEntry);
    return this.seq;
  }

  /** A raw op entry with a synchronous result (no model bookkeeping). */
  op(op: ModelOp, result: "ok" | "rejected" | "pending" = "ok", extra: { errorName?: string; cid?: string } = {}) {
    this.step++;
    this.ops.push(op);
    return this.push({ type: "op", op, input: isInputOp(op), result, ...extra });
  }

  settle(opSeq: number, result: "ok" | "rejected", errorName?: string): this {
    this.push({ type: "op-settled", opSeq, result, ...(errorName ? { errorName } : {}) });
    return this;
  }

  reset(cause: EvidenceResetCause, eventId?: string): this {
    this.push({ type: "evidence-reset", lifecycle: this.lifecycle, cause, ...(eventId ? { eventId } : {}) });
    return this;
  }

  start(): this {
    const seq = this.op({ kind: "start" }, "pending");
    if (!this.started && !this.disposed) {
      this.lifecycle++;
      this.started = true;
      this.reset("start");
    }
    return this.settle(seq, "ok");
  }

  stop(): this {
    this.op({ kind: "stop" });
    this.started = false;
    return this.reset("stop");
  }

  dispose(): this {
    this.op({ kind: "dispose" });
    this.started = false;
    this.disposed = true;
    return this.reset("dispose");
  }

  readStart(): number {
    const readId = ++this.readId;
    this.push({ type: "read-start", lifecycle: this.lifecycle, readId });
    return readId;
  }

  readEnd(
    readId: number,
    outcome: ReadOutcome,
    served: NostrEvent[] = [],
    store: NostrEvent[] = [],
    mode: ReadMode = "complete",
  ): this {
    for (const event of [...served, ...store]) this.fragments[event.id] = event;
    this.push({
      type: "read",
      lifecycle: this.lifecycle,
      readId,
      mode,
      outcome,
      served: served.map((e) => e.id),
      storeIds: store.map((e) => e.id),
    });
    return this;
  }

  /** A read-start and its termination. */
  read(outcome: ReadOutcome, served: NostrEvent[] = [], store: NostrEvent[] = served): this {
    return this.readEnd(this.readStart(), outcome, served, store, outcome === "complete" ? "complete" : "error");
  }

  ingest(event: NostrEvent, outcome: "ok" | "auth-failed" | "failed" = "ok", unlock = true): this {
    this.fragments[event.id] = event;
    this.push({ type: "ingest", lifecycle: this.lifecycle, eventId: event.id, unlock, outcome });
    if (outcome === "auth-failed") this.reset("ingest-failed", event.id);
    return this;
  }

  /** A completed read serving `events`, each then ingested. */
  hydrate(...events: NostrEvent[]): this {
    this.read("complete", events);
    for (const event of events) this.ingest(event);
    return this;
  }

  /** Another device's fragment delivered to the store. */
  arrive(event: NostrEvent): this {
    this.op({ kind: "remote", action: "grow", member: 0, delivery: "store" });
    this.fragments[event.id] = event;
    return this.reset("remote-arrived", event.id);
  }

  publish(
    event: NostrEvent,
    store: NostrEvent[],
    clientKnowledge: ModelKnowledge = "complete",
    outcome: PublishOutcome = "accepted",
  ): number {
    for (const stored of [...store, event]) this.fragments[stored.id] = stored;
    return this.push({
      type: "publish",
      lifecycle: this.lifecycle,
      event,
      storeFragmentIds: store.map((e) => e.id),
      clientKnowledge,
      outcome,
    });
  }

  /** A scripted signer call; `extra` is a list save's draft kind (signEvent) and carried community ids. */
  signer(
    method: SignerMethod,
    outcome: "ok" | "fail" | "stall" = "ok",
    extra: { kind?: number; carries?: string[] } = {},
  ): this {
    this.push({ type: "signer-call", method, outcome, ...extra });
    return this;
  }

  diagnostic(stage: string, duty?: string): this {
    this.push({ type: "diagnostic", stage, ...(duty ? { duty, key: "list" } : {}) });
    return this;
  }

  probe(name: ProbeName, snapshot: Partial<ProbeSnapshot> = {}): this {
    this.push({
      type: "probe",
      name,
      snapshot: { ...PROBE, started: this.started, disposed: this.disposed, ...snapshot },
    });
    return this;
  }

  trace(): ModelTrace {
    return {
      run: { ...RUN, autoUnlock: this.autoUnlock, ops: [...this.ops] },
      entries: structuredClone(this.entries),
      fragments: { ...this.fragments },
    };
  }

  check(): Promise<ModelViolation[]> {
    return checkModelTrace(this.trace(), context);
  }
}

/** Every violation is of invariant `n`, and there is exactly `count` of them. */
function expectOnly(violations: ModelViolation[], n: ModelViolation["invariant"], count = 1): void {
  expect(violations.map((v) => v.invariant)).toEqual(Array(count).fill(n));
}

const doc = (frags: number, members: number[], tombstones: [number, number][] = []): CommunityListFragment => ({
  frags,
  entries: members.map((i) => entry(pool.materials[i], 1)),
  tombstones: tombstones.map(([i, removed_at]) => ({ community_id: ids[i], removed_at })),
});
const ev = (index: number, d: CommunityListFragment, createdAt: number) =>
  remoteFragment(userSigner, index, d, createdAt);

// Shared fragments: e0 is the relay's d=0, x another device's re-write of d=0, p01 the client's publish.
const e0 = await ev(0, doc(1, [0]), 1_000);
const x = await ev(0, doc(1, [0]), 1_500);
const p01 = await ev(0, doc(1, [0, 1]), 2_000);

describe("Community List model core (D-31)", () => {
  it("seededRng is deterministic per seed", () => {
    const a = seededRng(42), b = seededRng(42), c = seededRng(43);
    const xs = Array.from({ length: 1_000 }, () => a.next());
    const ys = Array.from({ length: 1_000 }, () => b.next());
    const zs = Array.from({ length: 1_000 }, () => c.next());
    expect(xs).toEqual(ys);
    expect(xs).not.toEqual(zs);
    for (const x of xs) {
      expect(x).toBeGreaterThanOrEqual(0);
      expect(x).toBeLessThan(1);
    }
    const r = seededRng(7);
    for (let i = 0; i < 200; i++) {
      const n = r.int(5);
      expect(Number.isInteger(n) && n >= 0 && n < 5).toBe(true);
    }
    expect(["x", "y"]).toContain(seededRng(1).pick(["x", "y"]));
  });

  it("generateRun returns the same run for the same seed", () => {
    const options = { steps: 30, autoSave: true, members: 4 };
    for (let seed = 1; seed <= 20; seed++) {
      const run = generateRun(seed, options);
      expect(generateRun(seed, options)).toEqual(run);
      expect(run.seed).toBe(seed);
      expect(run.ops).toHaveLength(30);
      expect(run.autoSave).toBe(true);
    }
    const distinct = new Set<string>();
    for (let seed = 1; seed <= 100; seed++) distinct.add(JSON.stringify(generateRun(seed, options).ops));
    expect(distinct.size).toBeGreaterThanOrEqual(95);
    const untemplated = generateRun(5, { ...options, templateChance: 0 });
    expect(untemplated.template).toBeUndefined();
    expect(untemplated.ops).toHaveLength(30);
  });

  it("every template is reachable and keeps its op order", () => {
    const seen = new Set<string>();
    for (const autoSave of [true, false]) {
      for (let seed = 1; seed <= 500; seed++) {
        const run = generateRun(seed, { steps: 30, autoSave, members: 4 });
        expect(run.ops).toHaveLength(30);
        if (!run.template) continue;
        seen.add(run.template);
        const template = MODEL_TEMPLATES.find((t) => t.name === run.template)!;
        expect(template).toBeDefined();
        if (template.requires?.autoSave !== undefined) expect(run.autoSave).toBe(template.requires.autoSave);
        if (template.requires?.autoUnlock !== undefined) expect(run.autoUnlock).toBe(template.requires.autoUnlock);
        for (const [key, value] of Object.entries(template.initial ?? {})) {
          expect(run.initial[key as keyof typeof run.initial]).toEqual(value);
        }
        // The template's ops form a subsequence of the run's ops.
        let next = 0;
        for (const op of run.ops) {
          if (next < template.ops.length && JSON.stringify(op) === JSON.stringify(template.ops[next])) next++;
        }
        expect(next).toBe(template.ops.length);
        if (!autoSave) expect(template.requires?.autoSave).not.toBe(true);
      }
    }
    expect([...seen].sort()).toEqual(MODEL_TEMPLATES.map((t) => t.name).sort());
    for (
      const name of [
        "restart-during-stalled-ingest",
        "failing-ingest-with-auto-save",
        "unlock-failure-while-held",
        "offline-restart-join",
        "save-during-start-read",
        "dispose-then-start",
        "save-queued-behind-parked-step",
        "save-retired-by-stale-arrival",
        "rejected-join-then-retry",
        "concurrent-joins-one-declined",
      ]
    ) expect(seen.has(name)).toBe(true);
  });

  it("isInputOp marks exactly the client and remote inputs", () => {
    const inputs: ModelOp[] = [
      { kind: "start" },
      { kind: "stop" },
      { kind: "dispose" },
      { kind: "join", member: 0 },
      { kind: "leave", member: 0 },
      { kind: "create" },
      { kind: "unlock" },
      { kind: "save" },
      { kind: "remote", action: "add", member: 0, delivery: "store" },
      { kind: "remote", action: "stale", member: 0, delivery: "store" },
    ];
    const others: ModelOp[] = [
      { kind: "park", method: "getPublicKey" },
      { kind: "park", method: "encrypt" },
      { kind: "fail-next", method: "signEvent" },
      { kind: "read-mode", mode: "slow" },
      { kind: "finish-slow", outcome: "complete" },
      { kind: "publish-mode", mode: "accept" },
      { kind: "signer", method: "getPublicKey", mode: "stall" },
      { kind: "release-stalls" },
      { kind: "advance", ms: 1_000 },
    ];
    for (const op of inputs) expect(isInputOp(op)).toBe(true);
    for (const op of others) expect(isInputOp(op)).toBe(false);
  });

  it("fragmentView applies newest-wins, governing count and in-range union", async () => {
    expect(fragmentView([])).toEqual({ count: 1, live: [], tombstones: [] });

    // Newest created_at wins per index.
    const old0 = await frag(0, { frags: 1, entries: [entry(pool.materials[0], 1)], tombstones: [] }, 1_000);
    const new0 = await frag(0, { frags: 1, entries: [entry(pool.materials[1], 1)], tombstones: [] }, 2_000);
    expect(fragmentView([new0, old0]).live).toEqual([ids[1]]);
    expect(fragmentView([old0, new0]).live).toEqual([ids[1]]);

    // Equal created_at: the lower event id wins.
    const tieA = await frag(0, { frags: 1, entries: [entry(pool.materials[2], 1)], tombstones: [] }, 3_000);
    const tieB = await frag(0, { frags: 1, entries: [entry(pool.materials[3], 1)], tombstones: [] }, 3_000);
    const lower = tieA.event.id < tieB.event.id ? tieA : tieB;
    expect(fragmentView([tieA, tieB]).live).toEqual([lower.doc.entries[0].community_id]);
    expect(fragmentView([tieB, tieA]).live).toEqual([lower.doc.entries[0].community_id]);

    // The newest winner's frags governs; indexes at or above the count are ignored.
    const d0 = await frag(0, { frags: 2, entries: [entry(pool.materials[0], 1)], tombstones: [] }, 1_000);
    const d1 = await frag(1, { frags: 2, entries: [entry(pool.materials[1], 1)], tombstones: [] }, 1_000);
    expect(fragmentView([d0, d1])).toEqual({ count: 2, live: [ids[0], ids[1]].sort(), tombstones: [] });
    const demoting0 = await frag(0, { frags: 1, entries: [entry(pool.materials[0], 1)], tombstones: [] }, 5_000);
    expect(fragmentView([d0, d1, demoting0])).toEqual({ count: 1, live: [ids[0]], tombstones: [] });
    const newer1 = await frag(1, { frags: 3, entries: [entry(pool.materials[1], 1)], tombstones: [] }, 6_000);
    expect(fragmentView([demoting0, newer1]).count).toBe(3);

    // Equal-age winners take the larger frags.
    const eq0 = await frag(0, { frags: 1, entries: [entry(pool.materials[0], 1)], tombstones: [] }, 7_000);
    const eq1 = await frag(1, { frags: 2, entries: [entry(pool.materials[1], 1)], tombstones: [] }, 7_000);
    expect(fragmentView([eq0, eq1])).toEqual({ count: 2, live: [ids[0], ids[1]].sort(), tombstones: [] });

    // A tombstone newer than an entry makes it not live, and the tombstones are merged.
    const tomb = { community_id: ids[1], removed_at: 10 };
    const t0 = await frag(0, { frags: 2, entries: [entry(pool.materials[0], 1)], tombstones: [tomb] }, 1_000);
    const t1 = await frag(1, { frags: 2, entries: [entry(pool.materials[1], 5)], tombstones: [] }, 1_000);
    const view = fragmentView([t0, t1]);
    expect(view.live).toEqual([ids[0]]);
    expect(view.tombstones).toEqual([tomb]);
    // A re-join newer than the tombstone is live again.
    const rejoin = await frag(1, { frags: 2, entries: [entry(pool.materials[1], 20)], tombstones: [] }, 1_000);
    expect(fragmentView([t0, rejoin]).live).toEqual([ids[0], ids[1]].sort());
  });

  it("remoteFragment round-trips through decryption", async () => {
    const pubkey = await userSigner.getPublicKey();
    const doc: CommunityListFragment = {
      frags: 2,
      entries: [entry(pool.materials[0], 3)],
      tombstones: [{ community_id: ids[2], removed_at: 1 }],
    };
    const event = await remoteFragment(userSigner, 1, doc, 1_234);
    expect(event.kind).toBe(COMMUNITY_LIST_FRAGMENT_KIND);
    expect(event.pubkey).toBe(pubkey);
    expect(event.created_at).toBe(1_234);
    expect(event.tags).toEqual([["d", "1"]]);
    expect(typeof event.sig).toBe("string");
    const decoded = await decrypt(event);
    expect(decoded.frags).toBe(2);
    expect(decoded.entries.map((e) => e.community_id)).toEqual([ids[0]]);
    expect(decoded.entries[0].added_at).toBe(3);
    expect(decoded.tombstones).toEqual([{ community_id: ids[2], removed_at: 1 }]);
    expect(pool.bundles).toHaveLength(4);
    expect(pool.bundles.map((b) => b.community_id)).toEqual(ids);
  });

  it("the checker reports a publish without this lifecycle's completed read (invariant 1)", async () => {
    // No read at all.
    const none = new TraceBuilder().start();
    none.publish(p01, [e0]);
    expectOnly(await none.check(), 1);

    // The only completed read belongs to the previous lifecycle.
    const previous = new TraceBuilder().start().hydrate(e0).stop().start();
    previous.publish(p01, [e0]);
    const reported = await previous.check();
    expectOnly(reported, 1);
    expect(reported[0].message).toContain(p01.id.slice(0, 8));

    // A read that began before an evidence loss never counts (D-29).
    const begunBefore = new TraceBuilder().start();
    const stale = begunBefore.readStart();
    begunBefore.ingest(x, "auth-failed").readEnd(stale, "complete", [e0], [e0]).ingest(e0);
    begunBefore.publish(p01, [e0]);
    expectOnly(await begunBefore.check(), 1);

    // An error read is not a completed read.
    const failed = new TraceBuilder().start().read("error", [e0]).ingest(e0);
    failed.publish(p01, [e0]);
    expectOnly(await failed.check(), 1);

    // Valid: this lifecycle's completed, fully ingested read.
    const valid = new TraceBuilder().start().hydrate(e0);
    valid.publish(p01, [e0]);
    expect(await valid.check()).toEqual([]);
  });

  it("the checker judges read evidence from the trace alone, never from the client's reported knowledge (invariant 1)", async () => {
    const claimed = new TraceBuilder().start();
    claimed.publish(p01, [e0], "complete");
    expectOnly(await claimed.check(), 1);

    const unknown = new TraceBuilder().start().hydrate(e0);
    const seq = unknown.publish(p01, [e0], "unknown");
    expect(await unknown.check()).toEqual([]);
    const notes = crossCheckModelTrace(unknown.trace());
    expect(notes).toHaveLength(1);
    expect(notes[0]).toContain(`seq ${seq}`);
    expect(notes[0]).toContain("unknown");
  });

  it("the checker requires a new read after an ingest failure and an ingest of every arrival (invariant 1)", async () => {
    // An auth-failed ingest after the qualifying read withdraws the evidence until a new read.
    const afterFailure = (fixed: boolean) => {
      const b = new TraceBuilder().start().hydrate(e0).arrive(x).ingest(x, "auth-failed");
      if (fixed) b.ingest(x).read("complete", [e0], [e0, x]);
      b.publish(p01, [e0, x]);
      return b.check();
    };
    expectOnly(await afterFailure(false), 1);
    expect(await afterFailure(true)).toEqual([]);

    // A stored fragment the read saw must be ingested.
    const stored = (fixed: boolean) => {
      const b = new TraceBuilder().start().read("complete", [e0], [e0, x]).ingest(e0);
      if (fixed) b.ingest(x);
      b.publish(p01, [e0, x]);
      return b.check();
    };
    const unIngested = await stored(false);
    expectOnly(unIngested, 1);
    expect(unIngested[0].message).toContain(x.id.slice(0, 8));
    expect(await stored(true)).toEqual([]);

    // Another device's fragment arriving after the read began must be ingested before the publish.
    const arrival = (fixed: boolean) => {
      const b = new TraceBuilder().start().hydrate(e0).arrive(x);
      if (fixed) b.ingest(x);
      b.publish(p01, [e0, x]);
      return b.check();
    };
    const unseen = await arrival(false);
    expectOnly(unseen, 1);
    expect(unseen[0].message).toContain("arrived");
    expect(await arrival(true)).toEqual([]);

    // A post-authentication failure ("failed", e.g. decrypt) counts as ingested for invariant 1.
    const decryptFailed = new TraceBuilder().start().read("complete", [e0]).ingest(e0, "failed");
    decryptFailed.publish(p01, [e0]);
    expect(await decryptFailed.check()).toEqual([]);
  });

  it("crossCheckModelTrace notes a client status that disagrees with the trace without failing the run", async () => {
    const build = (knowledge: [ModelKnowledge, ModelKnowledge], final: ModelKnowledge) => {
      const b = new TraceBuilder().start();
      b.publish(p01, [e0], knowledge[0]);
      b.hydrate(e0);
      b.publish(p01, [e0], knowledge[1]);
      b.probe("final", { knowledge: final });
      return b.trace();
    };
    const disagreeing = build(["complete", "unknown"], "unknown");
    const agreeing = build(["unknown", "complete"], "complete");
    const notes = crossCheckModelTrace(disagreeing);
    expect(notes).toHaveLength(3);
    expect(notes.some((n) => n.includes("final probe"))).toBe(true);
    expect(crossCheckModelTrace(agreeing)).toEqual([]);
    const a = await checkModelTrace(disagreeing, context);
    const b = await checkModelTrace(agreeing, context);
    expectOnly(a, 1);
    expect(a).toEqual(b);
    const text = formatModelFailure(disagreeing.run, a, disagreeing.entries, notes);
    expect(text).toContain("Cross-check (diagnostic only)");
  });

  it("the checker reports a fragment-count demotion and a dropped membership (invariant 2)", async () => {
    const s0 = await ev(0, doc(2, [0]), 1_000);
    const s1 = await ev(1, doc(2, []), 1_000);
    const demote = new TraceBuilder().start().hydrate(s0, s1);
    demote.publish(await ev(0, doc(1, [0, 2]), 2_000), [s0, s1]);
    const demoted = await demote.check();
    expectOnly(demoted, 2);
    expect(demoted[0].message).toContain("from 2 to 1");

    const h1 = await ev(1, doc(2, [1]), 1_000);
    const hide = new TraceBuilder().start().hydrate(s0, h1);
    hide.publish(await ev(1, doc(2, []), 2_000), [s0, h1]);
    const hidden = await hide.check();
    expectOnly(hidden, 2);
    expect(hidden[0].message).toContain(ids[1]);

    // Valid: a scoped publish that keeps the count and the union.
    const scoped = new TraceBuilder().start().hydrate(s0, h1);
    scoped.publish(await ev(1, doc(2, [1, 2]), 2_000), [s0, h1]);
    expect(await scoped.check()).toEqual([]);

    // A stored id missing from trace.fragments is a harness error, never a silent pass.
    const missing = new TraceBuilder().start().hydrate(s0);
    missing.publish(await ev(0, doc(2, [0]), 2_000), [s0]);
    const trace = missing.trace();
    delete trace.fragments[s0.id];
    const harness = await checkModelTrace(trace, context);
    expect(harness.some((v) => v.invariant === 2 && v.message.includes("harness error"))).toBe(true);
  });

  it("the checker allows a repack to lower a count its own earlier publication raised, and still grades what it hides (invariant 2)", async () => {
    const s0 = await ev(0, doc(2, [0]), 1_000);
    const s1 = await ev(1, doc(2, [1]), 1_000);
    const repack = new TraceBuilder().start().hydrate(s0, s1);
    // Stage 1 and 2: the copies declare the temporary count 4 and carry the final content.
    const staged = await ev(2, doc(2, [0, 1]), 2_000);
    repack.publish(staged, [s0, s1]);
    const raised = await ev(0, doc(4, [0, 1]), 2_100);
    repack.publish(raised, [s0, s1, staged]);
    // Stage 3: the final copy lowers the count to 1 after every destination is acknowledged.
    repack.publish(await ev(0, doc(1, [0, 1]), 2_200), [raised, s1, staged]);
    expect(await repack.check()).toEqual([]);

    // The same lowering without any earlier raise by this client stays a demotion.
    const bare = new TraceBuilder().start().hydrate(raised, s1, staged);
    bare.publish(await ev(0, doc(1, [0, 1]), 2_200), [raised, s1, staged]);
    const demoted = await bare.check();
    expectOnly(demoted, 2);
    expect(demoted[0].message).toContain("from 4 to 1");

    // A lowering after an own raise that hides a live membership is still reported as hidden.
    const lossy = new TraceBuilder().start().hydrate(s0, s1);
    lossy.publish(staged, [s0, s1]);
    lossy.publish(raised, [s0, s1, staged]);
    lossy.publish(await ev(0, doc(1, [0]), 2_200), [raised, s1, staged]);
    const hidden = await lossy.check();
    expectOnly(hidden, 2);
    expect(hidden[0].message).toContain(ids[1]);

    // A raise from an earlier lifecycle never excuses a later lifecycle's lowering (WR-04).
    const later = new TraceBuilder().start().hydrate(s0, s1);
    later.publish(staged, [s0, s1]);
    later.publish(raised, [s0, s1, staged]);
    later.stop().start().hydrate(raised, s1, staged);
    later.publish(await ev(0, doc(1, [0, 1]), 2_200), [raised, s1, staged]);
    const crossed = await later.check();
    expectOnly(crossed, 2);
    expect(crossed[0].message).toContain("from 4 to 1");

    // Another device raising the count back to a value this client raised to earlier is no own raise either (WR-04).
    const foreign = await ev(1, doc(4, [1]), 2_300);
    const echoed = new TraceBuilder().start().hydrate(s0, s1);
    echoed.publish(staged, [s0, s1]);
    echoed.publish(raised, [s0, s1, staged]);
    echoed.arrive(foreign);
    echoed.hydrate(raised, foreign, staged);
    echoed.publish(await ev(0, doc(1, [0, 1]), 2_400), [raised, foreign, staged]);
    const masked = await echoed.check();
    expectOnly(masked, 2);
    expect(masked[0].message).toContain("from 4 to 1");

    // An own declaration of the count that was not a raise excuses nothing (WR-04).
    const flat = new TraceBuilder().start().hydrate(raised, s1, staged);
    const restated = await ev(1, doc(4, [1]), 2_300);
    flat.publish(restated, [raised, s1, staged]);
    flat.publish(await ev(0, doc(1, [0, 1]), 2_400), [raised, restated, staged]);
    const unraised = await flat.check();
    expectOnly(unraised, 2);
    expect(unraised[0].message).toContain("from 4 to 1");
  });

  it("the checker reports a hidden fragment whose ingest failed after authentication (invariant 2)", async () => {
    const s0 = await ev(0, doc(1, [0]), 1_000);
    const grown = await ev(1, doc(2, [2]), 1_500);
    const b = new TraceBuilder().start().hydrate(s0).arrive(grown).ingest(grown, "failed");
    b.publish(await ev(0, doc(1, [0]), 2_000), [s0, grown]);
    const violations = await b.check();
    expectOnly(violations, 2, 2);
    expect(violations.some((v) => v.message.includes("from 2 to 1"))).toBe(true);
    expect(violations.some((v) => v.message.includes(ids[2]))).toBe(true);
  });

  it("the checker reports a dropped tombstone but not a membership the client left (invariant 2)", async () => {
    const tombstoned = await ev(0, doc(1, [0], [[3, 500]]), 1_000);
    const drop = new TraceBuilder().start().hydrate(tombstoned);
    drop.publish(await ev(0, doc(1, [0]), 2_000), [tombstoned]);
    const dropped = await drop.check();
    expectOnly(dropped, 2);
    expect(dropped[0].message).toContain(`tombstone of community ${ids[3]}`);

    const both = await ev(0, doc(1, [0, 1]), 1_000);
    const leaving = await ev(0, doc(1, [0], [[1, 100]]), 2_000);
    const left = new TraceBuilder().start().hydrate(both);
    left.op({ kind: "leave", member: 1 }, "ok", { cid: ids[1] });
    left.publish(leaving, [both]);
    expect(await left.check()).toEqual([]);

    const unasked = new TraceBuilder().start().hydrate(both);
    unasked.publish(leaving, [both]);
    const reported = await unasked.check();
    expectOnly(reported, 2);
    expect(reported[0].message).toContain(ids[1]);
  });

  it("the checker reports a publish after stop or dispose and an unrejected start after dispose (invariant 3)", async () => {
    // A read that began after the stop gives evidence, so only the lifecycle is wrong.
    const afterStop = new TraceBuilder().start().stop().hydrate(e0);
    afterStop.publish(p01, [e0]);
    expectOnly(await afterStop.check(), 3);
    const afterDispose = new TraceBuilder().start().dispose().hydrate(e0);
    afterDispose.publish(p01, [e0]);
    expectOnly(await afterDispose.check(), 3);

    const startAfterDispose = async (record: (b: TraceBuilder) => void) => {
      const b = new TraceBuilder().start().dispose();
      record(b);
      return b.check();
    };
    expectOnly(await startAfterDispose((b) => b.op({ kind: "start" }, "ok")), 3);
    expectOnly(await startAfterDispose((b) => b.op({ kind: "start" }, "rejected", { errorName: "Error" })), 3);
    expectOnly(await startAfterDispose((b) => b.settle(b.op({ kind: "start" }, "pending"), "ok")), 3);
    expect(
      await startAfterDispose((b) =>
        b.settle(b.op({ kind: "start" }, "pending"), "rejected", "ConcordClientDisposedError")
      ),
    ).toEqual([]);
    // A rejected start after dispose leaves the model stopped, so a later publish is still a violation.
    const b = new TraceBuilder().start().dispose();
    b.settle(b.op({ kind: "start" }, "pending"), "rejected", "ConcordClientDisposedError");
    b.hydrate(e0).publish(p01, [e0]);
    expectOnly(await b.check(), 3);

    // Mutations while not started.
    const before = new TraceBuilder();
    before.op({ kind: "join", member: 0 }, "ok");
    expectOnly(await before.check(), 3);
    const beforeRejected = new TraceBuilder();
    beforeRejected.settle(
      beforeRejected.op({ kind: "join", member: 0 }, "pending"),
      "rejected",
      "ConcordClientNotStartedError",
    );
    expect(await beforeRejected.check()).toEqual([]);
    const stopped = new TraceBuilder().start().stop();
    stopped.op({ kind: "create" }, "ok");
    expectOnly(await stopped.check(), 3);
    const disposedWrongName = new TraceBuilder().start().dispose();
    disposedWrongName.op({ kind: "leave", member: 0 }, "rejected", { errorName: "ConcordClientNotStartedError" });
    expectOnly(await disposedWrongName.check(), 3);
    const disposedRejected = new TraceBuilder().start().dispose();
    disposedRejected.op({ kind: "leave", member: 0 }, "rejected", { errorName: "ConcordClientDisposedError" });
    disposedRejected.op({ kind: "join", member: 1 }, "rejected", { errorName: "ConcordClientDisposedError" });
    expect(await disposedRejected.check()).toEqual([]);
  });

  it("the checker reports a read storm and a duty still pending after quiescence (invariant 4)", async () => {
    // One start, one input, no fragments: bound 1 + 3 * (2 + 1 + 0) = 10 reads.
    const storm = (reads: number) => {
      const b = new TraceBuilder().start();
      for (let i = 0; i < reads; i++) b.read("error");
      return b.check();
    };
    expect(await storm(10)).toEqual([]);
    expectOnly(await storm(11), 4);

    const quiet = (between: (b: TraceBuilder) => void, end: Partial<ProbeSnapshot> = {}) => {
      const b = new TraceBuilder().start().probe("quiescence-start");
      between(b);
      return b.probe("quiescence-end", end).check();
    };
    expect(await quiet(() => {})).toEqual([]);
    expectOnly(await quiet(() => {}, { pendingDuties: 1 }), 4);
    // Quiescence reads bound: 3 * (1 + 0) = 3.
    expect(await quiet((b) => [1, 2, 3].forEach(() => b.read("error")))).toEqual([]);
    expectOnly(await quiet((b) => [1, 2, 3, 4].forEach(() => b.read("error"))), 4);
    // Quiescence signer bound with no reads: (0 + 1) * (0 + 2) * 4 = 8.
    expect(await quiet((b) => Array.from({ length: 8 }, () => b.signer("getPublicKey")))).toEqual([]);
    expectOnly(await quiet((b) => Array.from({ length: 9 }, () => b.signer("getPublicKey"))), 4);
  });

  it("the checker reports unknown evidence without an exhausted retry, and accepts the exhausted residual (invariant 5)", async () => {
    const healed = (setup: (b: TraceBuilder) => void, knowledge: ModelKnowledge) => {
      const b = new TraceBuilder().start();
      setup(b);
      return b.probe("liveness-healed", { knowledge }).check();
    };
    const exhausted = (b: TraceBuilder, reads: number, diagnostic: boolean) => {
      for (let i = 0; i < reads; i++) b.read(i % 2 ? "partial" : "error");
      if (diagnostic) b.diagnostic("duty-exhausted", "community-list-read");
    };
    expectOnly(await healed(() => {}, "unknown"), 5);
    // The residual needs both the diagnostic and maxAttempts non-complete reads.
    expect(await healed((b) => exhausted(b, 3, true), "unknown")).toEqual([]);
    expectOnly(await healed((b) => exhausted(b, 1, true), "unknown"), 5);
    expectOnly(await healed((b) => exhausted(b, 3, false), "unknown"), 5);
    // A diagnostic before the last input does not count.
    expectOnly(await healed((b) => (exhausted(b, 3, true), b.op({ kind: "join", member: 0 }, "ok")), "unknown"), 5);
    // The client's claim cannot excuse missing evidence.
    expectOnly(await healed(() => {}, "complete"), 5);
    // With evidence, unknown knowledge is still a stranded status.
    expectOnly(await healed((b) => b.hydrate(e0), "unknown"), 5);
    expect(await healed((b) => b.hydrate(e0), "complete")).toEqual([]);
    expect(await healed((b) => b.hydrate(e0), "partial")).toEqual([]);
    // Not checked while the runner's model is stopped.
    expect(await healed((b) => b.stop(), "unknown")).toEqual([]);
  });

  it("the checker excuses only a served copy that a newer stored copy of its index supersedes (invariant 1)", async () => {
    // The relay serves the old d=0 (e0) while the store already holds the newer x: the store refuses e0, so it is never
    // ingested, and per CORD-02 §8 it cannot change the list.
    const superseded = new TraceBuilder().start();
    superseded.readEnd(superseded.readStart(), "complete", [e0], [x]);
    superseded.ingest(x).publish(p01, [x]);
    expect(await superseded.check()).toEqual([]);
    // The newer copy served but never ingested is not excused by an older stored one.
    const newer = new TraceBuilder().start();
    newer.readEnd(newer.readStart(), "complete", [x], [e0]);
    newer.ingest(e0).publish(p01, [e0]);
    expectOnly(await newer.check(), 1);
  });

  it("the checker accepts the exhausted residual only when every attempt failed in the scripted world (invariant 5)", async () => {
    // Each attempt's own authentication failure is a hard reset, so the attempts are bounded by the lifecycle instead.
    const healed = (failure: "auth-failed" | "failed" | "none", attempts = 3) => {
      const b = new TraceBuilder().start();
      for (let i = 0; i < attempts; i++) {
        b.read("complete", [e0]);
        if (failure !== "none") b.ingest(e0, failure);
      }
      b.diagnostic("duty-exhausted", "community-list-read");
      return b.probe("liveness-healed", { knowledge: "unknown" }).check();
    };
    expect(await healed("auth-failed")).toEqual([]);
    expectOnly(await healed("auth-failed", 2), 5);
    // Completed, ingested reads are not a failing world: the client had evidence and still reports unknown.
    expectOnly(await healed("failed"), 5);
    expectOnly(await healed("none"), 5);
    // Attempts from before a stop and restart never corroborate the new lifecycle's exhaustion.
    const b = new TraceBuilder().start();
    for (let i = 0; i < 3; i++) b.read("error");
    b.stop().start().diagnostic("duty-exhausted", "community-list-read");
    expectOnly(await b.probe("liveness-healed", { knowledge: "unknown" }).check(), 5);
  });

  it("the checker reports an incomplete release after the nudge (invariant 5)", async () => {
    const nudged = (snapshot: Partial<ProbeSnapshot>) =>
      new TraceBuilder().start().hydrate(e0).probe("liveness-nudged", {
        localLive: [ids[0]],
        storeLive: [ids[0]],
        ...snapshot,
      }).check();
    expect(await nudged({})).toEqual([]);
    expect(await nudged({ knowledge: "confirmed-empty" })).toEqual([]);
    expectOnly(await nudged({ knowledge: "unknown" }), 5);
    expectOnly(await nudged({ knowledge: "partial" }), 5);
    expectOnly(await nudged({ pending: true }), 5);
    expectOnly(await nudged({ dirty: true }), 5);
    expectOnly(await nudged({ pendingDuties: 1 }), 5);
    expectOnly(await nudged({ localLive: [ids[0], ids[1]] }), 5);
    expectOnly(await nudged({ storeLive: [ids[1]] }), 5);
  });

  it("the checker reports a stranded held write at liveness-healed, before any nudge (invariant 5)", async () => {
    // A clean nudge afterwards never hides a difference the healed probe saw (IN-02).
    const healed = (snapshot: Partial<ProbeSnapshot>) =>
      new TraceBuilder().start().hydrate(e0).probe("liveness-healed", {
        localLive: [ids[0]],
        storeLive: [ids[0]],
        storeIds: [e0.id],
        ...snapshot,
      }).probe("liveness-nudged", { localLive: [ids[0]], storeLive: [ids[0]], storeIds: [e0.id] }).check();
    expect(await healed({})).toEqual([]);
    const stranded = await healed({ localLive: [ids[0], ids[1]].sort() });
    expectOnly(stranded, 5);
    expect(stranded[0].message).toContain("liveness-healed");
    expect(stranded[0].message).toContain(`local only [${ids[1]}]`);
    expect(stranded[0].message).toContain("(E1)");
    expect(stranded[0].message).toContain("(E2)");
    expect(stranded[0].message).toContain("(E3)");
    expectOnly(await healed({ storeLive: [] }), 5);
    const pending = await healed({ pending: true });
    expectOnly(pending, 5);
    expect(pending[0].message).toContain("a write is still pending");
    // E1, the exhausted read retry, still excuses every healed problem.
    const exhausted = new TraceBuilder().start();
    for (let i = 0; i < 3; i++) exhausted.read("error");
    exhausted.diagnostic("duty-exhausted", "community-list-read");
    exhausted.probe("liveness-healed", { knowledge: "unknown", localLive: [ids[1]], pending: true });
    expect(await exhausted.check()).toEqual([]);
    // Not checked while the runner's model is stopped.
    const stopped = new TraceBuilder().start().hydrate(e0).stop();
    expect(await stopped.probe("liveness-healed", { localLive: [ids[1]] }).check()).toEqual([]);
  });

  it("the checker excuses a healed difference only for a locked relevant fragment or a corroborated reported failure (invariant 5)", async () => {
    const differ = { localLive: [ids[0], ids[1]].sort(), storeLive: [ids[0]], pending: true };
    // E2: with autoUnlock off, a relevant stored fragment only the app can decrypt (read and received, never unlocked).
    const locked = (setup: (b: TraceBuilder) => void, autoUnlock = false) => {
      const b = new TraceBuilder();
      b.autoUnlock = autoUnlock;
      b.start().read("complete", [e0]).ingest(e0, "ok", false);
      setup(b);
      return b.probe("liveness-healed", { ...differ, storeIds: [e0.id] }).check();
    };
    expect(await locked(() => {})).toEqual([]);
    // The same fragment unlock-ingested "ok" is no longer locked.
    expectOnly(await locked((b) => b.ingest(e0)), 5);
    // With autoUnlock on, only a failed decrypt prompt (never re-prompted) leaves it locked.
    expectOnly(await locked(() => {}, true), 5);
    expect(await locked((b) => b.ingest(e0, "failed"), true)).toEqual([]);
    // A locked stale copy (older and outside the governing count) is not relevant.
    const stale = await ev(3, doc(4, []), 500);
    const staleOnly = new TraceBuilder();
    staleOnly.autoUnlock = false;
    staleOnly.start().hydrate(e0).arrive(stale).ingest(stale, "ok", false);
    staleOnly.probe("liveness-healed", { ...differ, storeIds: [e0.id, stale.id] });
    expectOnly(await staleOnly.check(), 5);

    // E3: a runner-recorded failure the client also reported, after the latest accepted publish.
    const q = await ev(0, doc(1, [0, 1, 2]), 2_500);
    const reported = (setup: (b: TraceBuilder) => void) => {
      const b = new TraceBuilder().start().hydrate(e0);
      setup(b);
      return b.probe("liveness-healed", { ...differ, storeIds: [e0.id] }).check();
    };
    // A community-list-save diagnostic with no runner-recorded failure.
    expectOnly(await reported((b) => b.diagnostic("community-list-save")), 5);
    // The diagnostic after a publish the runner refused, after the latest accepted publish.
    expect(
      await reported((b) => {
        b.publish(p01, [e0]);
        b.publish(q, [e0, p01], "complete", "refused-transient");
        b.diagnostic("community-list-save");
      }),
    ).toEqual([]);
    // A refusal before a later accepted publish is outside the window.
    expectOnly(
      await reported((b) => {
        b.publish(q, [e0], "complete", "refused-permanent");
        b.diagnostic("community-list-save");
        b.publish(p01, [e0]);
      }),
      5,
    );
    // D-34: a rejected join that recorded its membership keeps it, so the membership must be saved. Unsaved, it is
    // excused only by a reported failure of a save that carried it, never by the declined seal or another diagnostic.
    const rejectedJoin = (outcome: "unsaved" | "unrelated" | "refused" | "rolled-back") => {
      const b = new TraceBuilder().start().hydrate(e0);
      const join = b.op({ kind: "join", member: 1 }, "pending", { cid: ids[1] });
      b.signer("signEvent", "fail", { kind: 20013 }); // the join's guestbook seal
      if (outcome === "unrelated") b.diagnostic("join"); // whatever the client reports for the join itself
      if (outcome === "refused") {
        b.signer("signEvent", "fail", { kind: COMMUNITY_LIST_FRAGMENT_KIND, carries: [ids[0], ids[1]].sort() });
        b.diagnostic("community-list-save");
      }
      b.settle(join, "rejected", "Error");
      const live = outcome === "rolled-back" ? { localLive: [ids[0]], storeLive: [ids[0]] } : differ;
      return b.probe("liveness-healed", { ...live, storeIds: [e0.id] }).check();
    };
    expectOnly(await rejectedJoin("unsaved"), 5);
    expectOnly(await rejectedJoin("unrelated"), 5);
    expect(await rejectedJoin("refused")).toEqual([]);
    // The former D-33 rollback (local and stored both lack the membership) is now caught by the runner expectation.
    const rolledBack = await rejectedJoin("rolled-back");
    expectOnly(rolledBack, 5);
    expect(rolledBack[0].message).toContain("runner expectation");
  });

  it("the checker judges memberships from the app's join and leave outcomes, not from the client's mirror (invariant 5, WR-05)", async () => {
    const both = (members: number[]) => ({
      localLive: members.map((i) => ids[i]).sort(),
      storeLive: members.map((i) => ids[i]).sort(),
    });
    const healed = (setup: (b: TraceBuilder) => void, live: Partial<ProbeSnapshot>) => {
      const b = new TraceBuilder().start().hydrate(e0);
      setup(b);
      return b.probe("liveness-healed", { ...live, storeIds: [e0.id] }).check();
    };
    const call = (b: TraceBuilder, kind: "join" | "leave", result: "ok" | "rejected", errorName?: string) =>
      b.settle(b.op({ kind, member: 1 }, "pending", { cid: ids[1] }), result, errorName);
    const advance = (b: TraceBuilder) => b.op({ kind: "advance", ms: 1_000 });

    // A resolved join that ends unjoined everywhere.
    const lost = await healed((b) => call(b, "join", "ok"), both([0]));
    expectOnly(lost, 5);
    expect(lost[0].message).toContain("runner expectation");
    expect(lost[0].message).toContain(ids[1]);
    // D-34: a join rejected after recording the membership keeps it.
    expectOnly(await healed((b) => call(b, "join", "rejected", "Error"), both([0])), 5);
    expect(await healed((b) => call(b, "join", "rejected", "Error"), both([0, 1]))).toEqual([]);
    // A join rejected before recording anything expects nothing.
    expect(await healed((b) => call(b, "join", "rejected", "ConcordClientNotStartedError"), both([0]))).toEqual([]);
    // A leave after a clock advance expects the membership gone.
    const leftLater = (b: TraceBuilder) => (call(b, "join", "ok"), advance(b), call(b, "leave", "ok"));
    expect(await healed(leftLater, both([0]))).toEqual([]);
    expectOnly(await healed(leftLater, both([0, 1])), 5);
    // Opposite intents in the same instant are a CORD-02 §8 tie: not judged.
    expect(await healed((b) => (call(b, "leave", "ok"), call(b, "join", "ok")), both([0]))).toEqual([]);
    // The tie stays undetermined through a later join of the same intent (that join finds the membership already
    // recorded and records nothing), and so do opposite intents whose ops overlap.
    expect(
      await healed(
        (b) => (call(b, "leave", "ok"), call(b, "join", "ok"), advance(b), call(b, "join", "ok")),
        both([0]),
      ),
    ).toEqual([]);
    expect(
      await healed((b) => {
        const leave = b.op({ kind: "leave", member: 1 }, "pending", { cid: ids[1] });
        call(b, "join", "ok");
        advance(b);
        b.settle(leave, "ok");
      }, both([0, 1])),
    ).toEqual([]);
    // Another device's write on the same membership: not judged by the expectation.
    expect(
      await healed((b) => {
        b.op({ kind: "remote", action: "grow", member: 1, delivery: "relay" }, "ok", { cid: ids[1] });
        call(b, "join", "ok");
      }, both([0])),
    ).toEqual([]);
    // Local holds it while stored lacks it, with no excuse: the stored side is named against the expectation.
    const unsaved = await healed((b) => call(b, "join", "ok"), {
      localLive: [ids[0], ids[1]].sort(),
      storeLive: [ids[0]],
    });
    expectOnly(unsaved, 5);
    expect(unsaved[0].message).toContain("runner expectation");
    expect(unsaved[0].message).toContain(`stored live lacks ${ids[1]}`);
  });

  it("a reported save failure excuses only the membership its failed save carried, after that membership's last op (invariant 5, WR-04)", async () => {
    const SEAL = 20013;
    const carried = (...members: number[]) => members.map((i) => ids[i]).sort();
    const stranded = (setup: (b: TraceBuilder) => void, before: (b: TraceBuilder) => void = () => {}) => {
      const b = new TraceBuilder().start().hydrate(e0);
      before(b);
      const join = b.op({ kind: "join", member: 1 }, "pending", { cid: ids[1] });
      setup(b);
      b.settle(join, "rejected", "Error");
      return b.probe("liveness-healed", {
        localLive: carried(0, 1),
        storeLive: [ids[0]],
        storeIds: [e0.id],
      }).check();
    };
    // The reviewer's e3 shape: an earlier, unrelated reported save failure, then the join's declined seal.
    expectOnly(
      await stranded(
        (b) => b.signer("signEvent", "fail", { kind: SEAL }),
        (b) => {
          b.op({ kind: "signer", method: "encrypt", mode: "fail" });
          b.op({ kind: "save" });
          b.signer("encrypt", "fail", { carries: carried(0) });
          b.diagnostic("community-list-save");
          b.op({ kind: "signer", method: "encrypt", mode: "ok" });
        },
      ),
      5,
    );
    // A declined kind-33302 signature of a fragment carrying the membership, reported: excused.
    expect(
      await stranded((b) => {
        b.signer("signEvent", "fail", { kind: COMMUNITY_LIST_FRAGMENT_KIND, carries: carried(0, 1) });
        b.diagnostic("community-list-save");
      }),
    ).toEqual([]);
    // The same failure for a fragment carrying only another membership excuses nothing here.
    expectOnly(
      await stranded((b) => {
        b.signer("signEvent", "fail", { kind: COMMUNITY_LIST_FRAGMENT_KIND, carries: carried(2) });
        b.diagnostic("community-list-save");
      }),
      5,
    );
    // A getPublicKey failure is not attributable, so it counts for any membership.
    expect(
      await stranded((b) => {
        b.signer("getPublicKey", "fail");
        b.diagnostic("community-list-save");
      }),
    ).toEqual([]);
    // A publish the runner refused whose fragment carries the membership, reported: excused.
    expect(
      await stranded((b) => {
        b.publish(p01, [e0], "complete", "refused-transient");
        b.diagnostic("community-list-save");
      }),
    ).toEqual([]);
    // Another device's write naming the membership reopens the window only once it reaches the store (model seed 40).
    const refusedThen = (delivery: "relay" | "store") =>
      stranded((b) => {
        b.signer("signEvent", "fail", { kind: COMMUNITY_LIST_FRAGMENT_KIND, carries: carried(0, 1) });
        b.diagnostic("community-list-save");
        b.op({ kind: "remote", action: "remove", member: 1, delivery }, "ok", { cid: ids[1] });
      });
    expect(await refusedThen("relay")).toEqual([]);
    expectOnly(await refusedThen("store"), 5);
    // A declined seal and a save report with no failed list save: not excused.
    expectOnly(
      await stranded((b) => {
        b.signer("signEvent", "fail", { kind: SEAL });
        b.diagnostic("community-list-save");
      }),
      5,
    );
  });

  it("the checker reports an op that never settled (invariant 6)", async () => {
    expect(await new TraceBuilder().start().probe("final").check()).toEqual([]);
    expectOnly(await new TraceBuilder().start().probe("final", { unsettledOps: 1 }).check(), 6);
    const pending = new TraceBuilder().start();
    pending.op({ kind: "join", member: 0 }, "pending");
    expectOnly(await pending.probe("final").check(), 6);
    const settled = new TraceBuilder().start();
    settled.settle(settled.op({ kind: "join", member: 0 }, "pending"), "ok");
    expect(await settled.probe("final").check()).toEqual([]);
  });

  it("the checker accepts a valid trace", async () => {
    const b = new TraceBuilder();
    b.op({ kind: "read-mode", mode: "complete" });
    b.start().signer("getPublicKey").hydrate(e0).signer("decrypt");
    const join = b.op({ kind: "join", member: 1 }, "pending");
    b.signer("encrypt").signer("signEvent");
    b.publish(p01, [e0]);
    b.settle(join, "ok").op({ kind: "advance", ms: 6_000 });
    b.diagnostic("community-list-read");
    const live = [ids[0], ids[1]].sort();
    b.probe("quiescence-start", { reads: 1, signerCalls: 4 })
      .probe("quiescence-end", { reads: 1, signerCalls: 4 })
      .probe("liveness-healed", { localLive: live, storeLive: live })
      .probe("liveness-nudged", { localLive: live, storeLive: live })
      .probe("final", { localLive: live, storeLive: live });
    const trace = b.trace();
    const types = new Set(trace.entries.map((e) => e.type));
    for (const type of ["op", "op-settled", "read-start", "read", "ingest", "evidence-reset", "publish", "probe"]) {
      expect(types.has(type as TraceEntry["type"])).toBe(true);
    }
    expect(await checkModelTrace(trace, context)).toEqual([]);
    expect(crossCheckModelTrace(trace)).toEqual([]);
  });

  it("shrinkOps reduces a failing op list to a minimal one", async () => {
    const a: ModelOp = { kind: "dispose" };
    const z: ModelOp = { kind: "create" };
    const ops: ModelOp[] = Array.from({ length: 20 }, (_, i) => ({ kind: "advance", ms: i }) as ModelOp);
    ops[5] = a;
    ops[14] = z;
    let calls = 0;
    const fails = (list: ModelOp[]) => {
      calls++;
      const i = list.findIndex((op) => op.kind === "dispose");
      return Promise.resolve(i >= 0 && list.findIndex((op) => op.kind === "create") > i);
    };
    expect(await shrinkOps(ops, fails)).toEqual([a, z]);
    expect(calls).toBeLessThanOrEqual(200);

    calls = 0;
    const bounded = await shrinkOps(ops, fails, 5);
    expect(calls).toBeLessThanOrEqual(5);
    expect(bounded.indexOf(a)).toBeLessThan(bounded.indexOf(z));

    const passing = ops.filter((op) => op !== z);
    expect(await shrinkOps(passing, fails)).toEqual(passing);
  });

  it("formatModelFailure prints the seed, ops, violations and cross-check notes", () => {
    const run = generateRun(77, { steps: 20, autoSave: true, members: 4, templateChance: 1 });
    expect(run.template).toBeDefined();
    const violations: ModelViolation[] = [
      { invariant: 1, seq: 12, message: "publish abc d=0: no read completed" },
      { invariant: 4, seq: 30, message: "11 kind-33302 reads exceed the bound 10" },
    ];
    const b = new TraceBuilder().start().hydrate(e0);
    b.publish(p01, [e0]);
    const text = formatModelFailure(run, violations, b.trace().entries, ["seq 9: disagreement"]);
    expect(text).toContain("seed 77");
    expect(text).toContain("autoSave=true");
    expect(text).toContain(`autoUnlock=${run.autoUnlock}`);
    expect(text).toContain(run.template!);
    run.ops.forEach((_, i) => expect(text).toMatch(new RegExp(`^ +${i + 1}\\. `, "m")));
    expect(text.split("\n").filter((line) => /^ +\d+\. /.test(line))).toHaveLength(run.ops.length);
    for (const v of violations) {
      expect(text).toContain(`invariant ${v.invariant}`);
      expect(text).toContain(v.message);
    }
    expect(text).toContain("Cross-check (diagnostic only)");
    expect(text).toContain("seq 9: disagreement");
    expect(text).toContain("replay constant");
    expect(text).not.toContain(p01.content);
    expect(formatModelFailure(run, violations)).not.toContain("Cross-check");
  });
});
