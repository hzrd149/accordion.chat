// The client's aggregate status fold (moved out of the ConcordClient constructor): behavior-free extraction, so these
// tests pin the operators the fold has always had.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { BehaviorSubject, type Subscription } from "rxjs";

import type { ConcordClientStatus, ConcordCommunityStatus } from "../../types.ts";
import { clientStatus$ } from "../client-status.ts";

function status(patch: Partial<ConcordCommunityStatus> = {}): ConcordCommunityStatus {
  return { phase: "live", epoch: 0, connected: true, error: null, ...patch };
}

/** An engine stand-in exposing only the observable the fold reads. */
function engine(initial: ConcordCommunityStatus) {
  return { status$: new BehaviorSubject<ConcordCommunityStatus>(initial) };
}

function fixture() {
  const phase$ = new BehaviorSubject<ConcordClientStatus["phase"]>("ready");
  const communities$ = new BehaviorSubject<number>(0);
  const engines = new Map<string, ReturnType<typeof engine>>();
  const seen: ConcordClientStatus[] = [];
  const subscription: Subscription = clientStatus$(phase$, communities$, () => engines).subscribe((value) =>
    seen.push(value)
  );
  return { phase$, communities$, engines, seen, subscription };
}

describe("clientStatus$", () => {
  it("clientStatus$ counts live, syncing and connected communities", () => {
    const { phase$, communities$, engines, seen, subscription } = fixture();
    try {
      expect(seen.at(-1)).toEqual({ phase: "ready", communities: 0, syncing: 0, live: 0, connected: false });
      engines.set("a", engine(status()));
      engines.set("b", engine(status({ phase: "syncing", connected: false })));
      communities$.next(1);
      expect(seen.at(-1)).toEqual({ phase: "ready", communities: 2, syncing: 1, live: 1, connected: true });
      phase$.next("starting");
      expect(seen.at(-1)?.phase).toBe("starting");
    } finally {
      subscription.unsubscribe();
    }
  });

  it("clientStatus$ rebuilds its fan-in only when the membership changes", () => {
    const { communities$, engines, seen, subscription } = fixture();
    try {
      const a = engine(status({ phase: "syncing", connected: false }));
      engines.set("a", a);
      communities$.next(1);
      expect(seen.at(-1)).toEqual({ phase: "ready", communities: 1, syncing: 1, live: 0, connected: false });
      // The same membership re-announced does not rebuild, and a child change still flows through the inner fan-in.
      communities$.next(2);
      a.status$.next(status());
      expect(seen.at(-1)).toEqual({ phase: "ready", communities: 1, syncing: 0, live: 1, connected: true });
      // A new member rebuilds the fan-in to include it.
      engines.set("b", engine(status({ phase: "syncing", connected: false })));
      communities$.next(3);
      expect(seen.at(-1)).toEqual({ phase: "ready", communities: 2, syncing: 1, live: 1, connected: true });
      // A removed member is dropped on the next membership change.
      engines.delete("a");
      communities$.next(4);
      expect(seen.at(-1)).toEqual({ phase: "ready", communities: 1, syncing: 1, live: 0, connected: false });
    } finally {
      subscription.unsubscribe();
    }
  });

  it("clientStatus$ emits only distinct snapshots", () => {
    const { phase$, communities$, engines, seen, subscription } = fixture();
    try {
      const a = engine(status());
      engines.set("a", a);
      communities$.next(1);
      const before = seen.length;
      // Changes that do not alter any counted field produce no new snapshot.
      a.status$.next(status({ epoch: 5, error: "boom" }));
      phase$.next("ready");
      communities$.next(2);
      expect(seen.length).toBe(before);
      a.status$.next(status({ connected: false }));
      expect(seen.length).toBe(before + 1);
    } finally {
      subscription.unsubscribe();
    }
  });
});
