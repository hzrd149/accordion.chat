import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { EventStore } from "applesauce-core";
import { castUser } from "applesauce-core/casts";
import type { EventTemplate, NostrEvent } from "applesauce-core/helpers/event";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import "applesauce-common/casts";
import "../../casts/index.ts";
import { bytesToHex } from "@noble/hashes/utils.js";

import { type ConcordInviteLink, ConcordInviteManager } from "../invite-manager.ts";
import { buildInviteLink, newInviteToken } from "../../helpers/invite-bundle.ts";
import { INVITE_LIST_KIND } from "../../helpers/invite-list.ts";
import { fakeRelayPool } from "./test-utils.ts";

const settle = () => new Promise((r) => setTimeout(r, 50));

function link(): ConcordInviteLink {
  const linkSk = generateSecretKey();
  const token = newInviteToken();
  return {
    token: bytesToHex(token),
    signerSk: bytesToHex(linkSk),
    signerPubkey: getPublicKey(linkSk),
    communityId: "ab".repeat(32),
    url: buildInviteLink("https://app.example", getPublicKey(linkSk), token, ["wss://fake"]),
    createdAt: 1,
    revoked: false,
  };
}

describe("ConcordInviteManager.save", () => {
  it("serializes overlapping saves so each signed Invite List is dated after the last and the newest wins", async () => {
    const inner = new PrivateKeySigner(generateSecretKey());
    const pubkey = await inner.getPublicKey();
    // Hold the first signature open so a second save is requested while the first is mid-flight.
    let releaseFirst!: () => void;
    const firstHeld = new Promise<void>((resolve) => (releaseFirst = resolve));
    let firstSignRequested!: () => void;
    const firstSigning = new Promise<void>((resolve) => (firstSignRequested = resolve));
    let signs = 0;
    const signer = {
      getPublicKey: () => inner.getPublicKey(),
      nip44: inner.nip44,
      async signEvent(draft: EventTemplate): Promise<NostrEvent> {
        if (signs++ === 0) {
          firstSignRequested();
          await firstHeld;
        }
        return inner.signEvent(draft);
      },
    };
    const fake = fakeRelayPool();
    const store = new EventStore();
    const invites = new ConcordInviteManager({
      signer,
      pool: fake.pool,
      eventStore: store,
      relays: ["wss://fake"],
      getCommunity: () => undefined,
    });
    await invites.start(castUser(pubkey, store));
    const first = link();
    const second = link();
    try {
      const a = invites.record(first);
      await firstSigning;
      const b = invites.record(second);
      releaseFirst();
      await Promise.all([a, b]);
      await settle();

      const lists = fake.published.filter((event) => event.kind === INVITE_LIST_KIND);
      expect(lists).toHaveLength(2);
      expect(lists[1].created_at).toBeGreaterThan(lists[0].created_at);
      const kept = store.getReplaceable(INVITE_LIST_KIND, pubkey)!;
      expect(kept.id).toBe(lists[1].id);
      const document = JSON.parse(await inner.nip44.decrypt(pubkey, kept.content));
      expect(document.entries.map((entry: { token: string }) => entry.token).sort()).toEqual(
        [first.token, second.token].sort(),
      );
    } finally {
      invites.dispose();
      store.dispose();
    }
  });
});
