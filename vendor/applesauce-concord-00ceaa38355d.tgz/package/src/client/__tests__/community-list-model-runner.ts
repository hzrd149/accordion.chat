// The D-31 Community List model runner: drives a real `ConcordClient` through one `ModelRun` under fake time, with a
// scripted signer and a scripted relay, and records an independent `ModelTrace` for `checkModelTrace`.
//
// Independence rule (checker BLOCKER 1): every evidence entry (`read-start`, `read`, `ingest`, `evidence-reset`) comes
// from what this runner scripted or observed: the relay answers it produced, the store deliveries it made and the
// signer errors it threw. The only client-reported values it records are `clientKnowledge` on publishes (cross-check
// only) and the graded outputs in probe snapshots.
//
// Time: one `FakeTime` per run, and a seeded `Math.random` (the duty jitter) so a replay is exact. The client's only
// asynchronous sources are promise chains, fake timers and the signer and relay this runner scripts (no real timer,
// WebCrypto call or message port), so after one full microtask drain it can only move when the runner ticks fake time,
// releases a parked call or acts. `drain` waits for exactly that idleness (see `turn`); an advance steps from one fake
// timer to the next with a drain between, so a retry scheduled by a promise chain is due at the right fake instant.

import { EMPTY, Observable, type Subscriber, type Subscription } from "rxjs";
import { FakeTime } from "@std/testing/time";
import { sha256 } from "@noble/hashes/sha2.js";
import { EventStore } from "applesauce-core";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";
import type { PublishResponse } from "applesauce-relay";
import { ConcordClient } from "../client.ts";
import { COMMUNITY_LIST_READ_RETRY } from "../community-list-read.ts";
import { memoryStorage } from "../storage.ts";
import { fakeRelayPool } from "./test-utils.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  type CommunityListFragment,
  decodeCommunityListFragment,
} from "../../helpers/community-list-wire.ts";
import {
  liveCommunities,
  mergeCommunities,
  mergeCommunityTombstones,
  parseCommunityList,
  type ParsedCommunityList,
} from "../../helpers/community-list.ts";
import type { CommunityListCommunity, JoinMaterial } from "../../types.ts";
import {
  type EvidenceResetCause,
  fragmentView,
  isInputOp,
  type MemberPool,
  type ModelKnowledge,
  type ModelOp,
  type ModelRun,
  type ModelTrace,
  type ProbeName,
  type ProbeSnapshot,
  type PublishOutcome,
  type ReadMode,
  type ReadOutcome,
  remoteFragment,
  seededRng,
  type SignerMethod,
  type TraceEntry,
} from "./community-list-model-core.ts";

/** What a run needs besides the run itself. */
export interface ModelEnv {
  /** The member pool, built once per test file. */
  pool: MemberPool;
  /** Macrotask turns before a drain that never goes idle fails as a harness error (default {@link MODEL_DRAIN_CAP}). */
  drainCap?: number;
}

/** Macrotask turns allowed before the runner reports a drain that never goes idle (a safety bound, not a settle rule). */
export const MODEL_DRAIN_CAP = 20;

/** Fake timer steps allowed in one advance before the runner reports it as a harness failure. */
const MODEL_STEP_CAP = 5_000;

/** The fixed fake start time of every run (ms). */
const MODEL_START_MS = 1_700_000_000_000;

/** A harness failure (a drain that never went idle), never an invariant violation. */
export class ModelHarnessError extends Error {
  /** Names the seed, step and op the harness could not settle. */
  constructor(message: string) {
    super(message);
    this.name = "ModelHarnessError";
  }
}

/** The user's signer for `seed`: its key is sha256 of the seed's decimal bytes, so the pubkey is stable per seed. */
export function modelUserSigner(seed: number): PrivateKeySigner {
  return new PrivateKeySigner(sha256(new TextEncoder().encode(`concord model user ${seed}`)));
}

type SignerMode = "ok" | "fail" | "stall";
type PublishMode = "accept" | "refuse-transient" | "refuse-permanent";
type Entry<T extends TraceEntry["type"]> = Extract<TraceEntry, { type: T }>;
type NewEntry = TraceEntry extends infer E ? E extends TraceEntry ? Omit<E, "seq" | "step"> : never : never;

interface TrackedTimer {
  due: number;
  delay: number;
  repeat: boolean;
}

interface SlowRead {
  serve(outcome: "complete" | "error"): void;
}

/**
 * One macrotask turn: Node's `setImmediate` runs its callback in the event loop's check phase, after the microtask and
 * `nextTick` queues have fully drained, so a resolved turn means every promise chain the client had runnable has run,
 * on a loaded machine too. FakeTime does not fake it, and Deno provides it globally (typed here, as the project has no
 * Node type definitions). Two cheaper turns are wrong here (01-13):
 *
 * - `crypto.subtle.digest`: on a busy machine its thread-pool work can finish before the op's eager first poll, and the
 *   promise then resolves after two microtask hops, overtaking a client chain that is still running. Drains then ended
 *   early, and seeded runs and self-tests failed under load.
 * - A `MessageChannel` message: once an npm module has loaded Node compatibility, it is delivered after two microtask
 *   hops as well.
 *
 * A real `setTimeout(0)` is correct but costs about 2 ms per turn.
 */
const { setImmediate } = globalThis as unknown as { setImmediate(callback: () => void): unknown };
const turn = (): Promise<void> => new Promise<void>((resolve) => setImmediate(resolve));

/** Track every fake timer's due time so an advance can step from one timer to the next. */
function trackTimers(time: FakeTime): Map<number, TrackedTimer> {
  const timers = new Map<number, TrackedTimer>();
  const g = globalThis as unknown as Record<string, (...args: unknown[]) => unknown>;
  const fake = {
    setTimeout: g.setTimeout,
    clearTimeout: g.clearTimeout,
    setInterval: g.setInterval,
    clearInterval: g.clearInterval,
  };
  const install = (repeat: boolean) => (callback: unknown, delay: unknown = 0, ...args: unknown[]): unknown => {
    const ms = Math.max(repeat ? 1 : 0, Math.floor(Number(delay) || 0));
    const timer: TrackedTimer = { due: time.now + ms, delay: ms, repeat };
    const wrapped = (...callArgs: unknown[]) => {
      if (repeat) timer.due += ms;
      else timers.delete(id);
      (callback as (...a: unknown[]) => void)(...callArgs);
    };
    const id = (repeat ? fake.setInterval : fake.setTimeout)(wrapped, ms, ...args) as number;
    timers.set(id, timer);
    return id;
  };
  const clear = (original: (...args: unknown[]) => unknown) => (id: unknown): unknown => {
    if (typeof id === "number") timers.delete(id);
    return original(id);
  };
  g.setTimeout = install(false);
  g.setInterval = install(true);
  g.clearTimeout = clear(fake.clearTimeout);
  g.clearInterval = clear(fake.clearInterval);
  return timers;
}

/** The newest fragment per `d` index (ties: the lower id), as a relay or the store keeps it. */
function newer(a: NostrEvent, b: NostrEvent | undefined): boolean {
  return !b || a.created_at > b.created_at || (a.created_at === b.created_at && a.id < b.id);
}

const dOf = (event: NostrEvent): number => Number(event.tags.find((tag) => tag[0] === "d")?.[1] ?? "0");

const entryFor = (material: JoinMaterial, added_at: number): CommunityListCommunity => ({
  community_id: material.community_id,
  seed: material,
  current: material,
  added_at,
});

/**
 * Run `run` against a real `ConcordClient` and return the recorded trace. Rejects with {@link ModelHarnessError} when
 * a drain does not settle within the cap; never records that as an entry.
 */
export async function runModel(run: ModelRun, env: ModelEnv): Promise<ModelTrace> {
  const time = new FakeTime(MODEL_START_MS);
  const timers = trackTimers(time);
  const random = Math.random;
  Math.random = seededRng(run.seed ^ 0x5eed).next; // the duty jitter, so a replay is exact
  const user = modelUserSigner(run.seed);
  const pubkey = await user.getPublicKey();
  const entries: TraceEntry[] = [];
  const fragments: Record<string, NostrEvent> = {};
  const cap = env.drainCap ?? MODEL_DRAIN_CAP;
  const { materials, bundles } = env.pool;

  let seq = 0;
  let step = 0;
  let stepLabel = "setup";
  let recording = true; // teardown records nothing: the returned trace ends at the "final" probe
  const record = (entry: NewEntry): TraceEntry => {
    const full = { ...entry, seq: seq++, step } as TraceEntry;
    if (recording) entries.push(full);
    return full;
  };

  // The runner's own model (plan 01-07): never read from the client.
  const model: { state: "stopped" | "started" | "disposed" } = { state: "stopped" };
  let lifecycle = 0;

  // Scripted signer.
  const modes: Record<SignerMethod, SignerMode> = { getPublicKey: "ok", signEvent: "ok", encrypt: "ok", decrypt: "ok" };
  const parked: Array<() => void> = [];
  // `park`: the next call of an armed method, from any caller, parks like "stall" once, then the method is disarmed.
  const armed = new Set<SignerMethod>();
  // `fail-next`: the next call of a method armed here, from any caller, fails like "fail" once (an armed park takes that
  // call first); `release-stalls` leaves it armed, quiescence and the heal disarm it.
  const failNext = new Set<SignerMethod>();
  // Community List memberships a list-save signer call carries, decoded with the runner's own key; awaited before the
  // trace is returned, never by the call itself.
  const carrying: Promise<void>[] = [];
  const carried = (doc: CommunityListFragment): string[] =>
    [...new Set([...doc.entries, ...doc.tombstones].map((item) => item.community_id))].sort();
  const keyErrors = new WeakSet<object>();
  let signerCalls = 0;
  // Runner-started crypto still running (a signer call that is not parked, a runner-side decrypt): a drain is idle only
  // when this is zero.
  let inFlight = 0;
  const running = <T>(work: () => Promise<T>): Promise<T> => {
    inFlight++;
    return work().finally(() => inFlight--);
  };
  /**
   * One scripted signer call. `extra` is recorded on its entry; `listDraft` is a kind-33302 draft's ciphertext, whose
   * carried memberships the runner fills in once its own key has decrypted it (never through this signer).
   */
  const call = <T>(
    method: SignerMethod,
    real: () => Promise<T>,
    extra: { kind?: number; carries?: string[] } = {},
    listDraft?: string,
  ): Promise<T> => {
    const mode: SignerMode = armed.delete(method) ? "stall" : failNext.delete(method) ? "fail" : modes[method];
    signerCalls++;
    const entry = record({ type: "signer-call", method, outcome: mode, ...extra }) as Entry<"signer-call">;
    if (listDraft !== undefined) {
      carrying.push(
        user.nip44.decrypt(pubkey, listDraft).then(
          (text) => void (entry.carries = carried(decodeCommunityListFragment(text))),
          () => {}, // not a fragment the runner's key opens: the call carries nothing
        ),
      );
    }
    if (mode === "fail") {
      const error = new Error(`scripted ${method} failure`);
      if (method === "getPublicKey") keyErrors.add(error);
      return Promise.reject(error);
    }
    if (mode === "stall") {
      return new Promise<T>((resolve, reject) => parked.push(() => running(real).then(resolve, reject)));
    }
    return running(real);
  };
  const signer: ISigner = {
    getPublicKey: () => call("getPublicKey", () => user.getPublicKey()),
    signEvent: (draft) =>
      call(
        "signEvent",
        () => user.signEvent(draft),
        { kind: draft.kind },
        draft.kind === COMMUNITY_LIST_FRAGMENT_KIND ? draft.content : undefined,
      ),
    nip44: {
      encrypt: (target: string, text: string) => {
        let carries: string[] | undefined;
        try {
          carries = carried(decodeCommunityListFragment(text));
        } catch {
          // Not a Community List fragment (another caller's plaintext): the call carries nothing.
        }
        return call("encrypt", () => user.nip44.encrypt(target, text), carries ? { carries } : {});
      },
      decrypt: (target: string, text: string) => call("decrypt", () => user.nip44.decrypt(target, text)),
    },
  };
  const releaseStalls = () => {
    for (const release of parked.splice(0)) release();
  };
  const disarmParks = () => armed.clear();

  // Runner-side decryption with the user's key (never through the scripted signer).
  const docs = new Map<string, Promise<CommunityListFragment>>();
  const open = (event: NostrEvent): Promise<CommunityListFragment> => {
    if (!docs.has(event.id)) {
      docs.set(event.id, running(() => user.nip44.decrypt(pubkey, event.content)).then(decodeCommunityListFragment));
    }
    return docs.get(event.id)!;
  };

  // The relay world: the newest fragment per d index.
  const world = new Map<number, NostrEvent>();
  const toWorld = (event: NostrEvent) => {
    if (newer(event, world.get(dOf(event)))) world.set(dOf(event), event);
  };
  const worldEvents = () => [...world.entries()].sort(([a], [b]) => a - b).map(([, event]) => event);

  const store = new EventStore();
  let inserts = 0;
  const subscriptions: Subscription[] = [store.insert$.subscribe(() => inserts++)];
  const listFilter = [{ kinds: [COMMUNITY_LIST_FRAGMENT_KIND], authors: [pubkey] }];
  const storeIds = () => store.getTimeline(listFilter).map((event) => event.id);

  // Initial world: 0, 1 or 2 fragments (relay and store) and the mirror.
  const past = Math.floor(MODEL_START_MS / 1000) - 1_000;
  const remote = run.initial.remoteMembers.filter((m) => m < materials.length);
  for (let index = 0; index < run.initial.fragments; index++) {
    const members = remote.filter((_, position) => position % run.initial.fragments === index);
    const doc: CommunityListFragment = {
      frags: run.initial.fragments,
      entries: mergeCommunities([], members.map((m) => entryFor(materials[m], m + 1))),
      tombstones: [],
    };
    const event = await remoteFragment(user, index, doc, past);
    fragments[event.id] = event;
    docs.set(event.id, Promise.resolve(doc));
    toWorld(event);
    store.add(event);
  }
  const storage = memoryStorage();
  const mirror = run.initial.mirrorMembers.filter((m) => m < materials.length);
  if (mirror.length > 0) {
    await storage.setItem(
      pubkey,
      JSON.stringify({
        entries: mergeCommunities([], mirror.map((m) => entryFor(materials[m], m + 1))),
        tombstones: [],
      }),
    );
  }

  // Scripted relay.
  const net = fakeRelayPool();
  let readMode: ReadMode = "complete";
  let publishMode: PublishMode = "accept";
  let readCounter = 0;
  let reads = 0;
  const slow: SlowRead[] = [];
  net.setRequest((filters) => {
    if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
    if (filters.some((f) => f.until !== undefined)) return EMPTY; // the loader's next page: never a read
    return new Observable<NostrEvent>((subscriber: Subscriber<NostrEvent>) => {
      const readId = ++readCounter;
      const mode = readMode;
      const readLifecycle = lifecycle;
      record({ type: "read-start", lifecycle: readLifecycle, readId });
      reads++;
      let done = false;
      const served: string[] = [];
      const serve = (events: NostrEvent[]) => {
        for (const event of events) {
          served.push(event.id);
          subscriber.next(event);
        }
      };
      const finish = (outcome: ReadOutcome) => {
        done = true;
        record({
          type: "read",
          lifecycle: readLifecycle,
          readId,
          mode,
          outcome,
          served: [...served],
          storeIds: storeIds(),
        });
      };
      const slowRead: SlowRead = {
        serve: (outcome) => {
          if (done) return;
          if (outcome === "complete") serve(worldEvents());
          finish(outcome);
          if (outcome === "complete") subscriber.complete();
          else subscriber.error(new Error("relay down"));
        },
      };
      if (mode === "complete") slowRead.serve("complete");
      else if (mode === "error") slowRead.serve("error");
      else if (mode === "partial") {
        const events = worldEvents();
        serve(events.slice(0, Math.ceil(events.length / 2)));
        finish("partial");
        subscriber.error(new Error("relay dropped the read"));
      } else slow.push(slowRead);
      return () => {
        const at = slow.indexOf(slowRead);
        if (at >= 0) slow.splice(at, 1);
        if (!done) finish("abandoned");
      };
    });
  });
  const finishSlow = (outcome: "complete" | "error") => {
    for (const read of slow.splice(0)) read.serve(outcome);
  };

  // The client and the ingest spy.
  const client = new ConcordClient({
    signer,
    pool: net.pool,
    eventStore: store,
    storage,
    relays: ["wss://fake"],
    watchDirectInvites: false,
    autoUnlock: run.autoUnlock,
    autoSaveCommunityList: run.autoSave,
  });
  const publishOutcomes: Record<PublishMode, PublishOutcome> = {
    "accept": "accepted",
    "refuse-transient": "refused-transient",
    "refuse-permanent": "refused-permanent",
  };
  net.setPublishOutcome((event): PublishResponse[] | undefined => {
    if (event.kind !== COMMUNITY_LIST_FRAGMENT_KIND) return undefined;
    fragments[event.id] = event;
    record({
      type: "publish",
      lifecycle,
      event,
      storeFragmentIds: storeIds().filter((id) => id !== event.id),
      clientKnowledge: client.communityListSync.status.knowledge as ModelKnowledge, // cross-check only
      outcome: publishOutcomes[publishMode], // what this runner scripts the relay to answer, below
    });
    if (publishMode === "accept") {
      toWorld(event);
      return undefined;
    }
    const message = publishMode === "refuse-transient" ? "error: busy" : "blocked: test";
    return [{ ok: false, from: "wss://fake", message }];
  });
  subscriptions.push(client.diagnostics$.subscribe((diagnostic) => {
    const extra = diagnostic as { duty?: string; key?: string };
    record({
      type: "diagnostic",
      stage: diagnostic.stage,
      ...(extra.duty !== undefined ? { duty: extra.duty } : {}),
      ...(extra.key !== undefined ? { key: extra.key } : {}),
    });
  }));
  // The client's own sync, which the lane calls directly; its public view routes receive() through the lane (WR-03).
  const sync = (client as unknown as { listSync: { receive(event: NostrEvent, unlock?: boolean): Promise<boolean> } })
    .listSync;
  const receive = sync.receive.bind(sync);
  sync.receive = async (event: NostrEvent, unlock: boolean = true): Promise<boolean> => {
    try {
      const result = await receive(event, unlock);
      record({ type: "ingest", lifecycle, eventId: event.id, unlock, outcome: "ok" });
      return result;
    } catch (error) {
      const auth = typeof error === "object" && error !== null && keyErrors.has(error);
      record({ type: "ingest", lifecycle, eventId: event.id, unlock, outcome: auth ? "auth-failed" : "failed" });
      if (auth) record({ type: "evidence-reset", lifecycle, cause: "ingest-failed", eventId: event.id });
      throw error;
    }
  };

  // Ops and settling.
  const pendingOps = new Set<number>();
  let settledOps = 0;
  const reset = (cause: EvidenceResetCause, eventId?: string) =>
    record({ type: "evidence-reset", lifecycle, cause, ...(eventId ? { eventId } : {}) });
  const progress = () => `${entries.length}:${inserts}:${settledOps}:${net.published.length}`;
  /**
   * Wait until the client is idle: a whole macrotask `turn` (a full microtask drain) recorded no trace entry, store
   * insert, op settlement or publish, and no runner-started crypto is in flight. What is still pending then waits only
   * on fake time, a parked signer call or a slow read, which only the runner can move. The cap bounds a client that
   * keeps itself busy; it is never a settle rule.
   */
  const drain = async (): Promise<void> => {
    for (let turns = 0; turns < cap; turns++) {
      const before = progress();
      await turn();
      if (inFlight === 0 && progress() === before) return;
    }
    throw new ModelHarnessError(
      `did not settle within ${cap} drain turns at step ${step} (op ${stepLabel}), seed ${run.seed}`,
    );
  };
  const advance = async (ms: number): Promise<void> => {
    const target = time.now + ms;
    for (let steps = 0;; steps++) {
      await drain();
      let next = Infinity;
      for (const timer of timers.values()) next = Math.min(next, timer.due);
      if (next > target) break;
      if (steps >= MODEL_STEP_CAP) {
        throw new ModelHarnessError(
          `did not settle within ${MODEL_STEP_CAP} timer steps at step ${step} (op ${stepLabel}), seed ${run.seed}`,
        );
      }
      time.tick(Math.max(0, next - time.now));
    }
    time.tick(target - time.now);
    await drain();
  };
  const track = (entry: Entry<"op">, promise: Promise<unknown>) => {
    pendingOps.add(entry.seq);
    promise.then(
      () => {
        pendingOps.delete(entry.seq);
        settledOps++;
        record({ type: "op-settled", opSeq: entry.seq, result: "ok" });
      },
      (error) => {
        pendingOps.delete(entry.seq);
        settledOps++;
        record({ type: "op-settled", opSeq: entry.seq, result: "rejected", errorName: (error as Error)?.name });
      },
    );
  };
  const clientCall = (entry: Entry<"op">, invoke: () => Promise<unknown> | void) => {
    try {
      const result = invoke();
      if (result instanceof Promise) track(entry, result);
      else entry.result = "ok";
    } catch (error) {
      entry.result = "rejected";
      entry.errorName = (error as Error)?.name;
    }
  };
  const startClient = (entry: Entry<"op">) => {
    if (model.state !== "stopped") {
      clientCall(entry, () => client.start()); // redundant, or after dispose: no lifecycle, no reset
      return;
    }
    lifecycle++;
    const mine = lifecycle;
    reset("start");
    model.state = "started";
    clientCall(entry, () =>
      client.start().catch((error) => {
        if (model.state === "started" && lifecycle === mine) model.state = "stopped";
        throw error;
      }));
    if (entry.result === "rejected" && lifecycle === mine) model.state = "stopped";
  };

  /**
   * Another device's leftover staging copy: older than every fragment the relay world or the store holds, at an index
   * past all of them and at or above every declared count, so CORD-02 §8 ignores it. Undefined when neither holds one.
   */
  const staleWrite = async (): Promise<NostrEvent | undefined> => {
    const held = [...worldEvents(), ...store.getTimeline(listFilter)];
    if (held.length === 0) return undefined;
    const declared = await Promise.all(held.map(async (event) => (await open(event)).frags));
    const index = Math.max(1 + Math.max(...held.map(dOf)), ...declared);
    const doc: CommunityListFragment = { frags: index + 1, entries: [], tombstones: [] };
    const createdAt = Math.min(...held.map((event) => event.created_at)) - 1;
    const event = await remoteFragment(user, index, doc, createdAt);
    docs.set(event.id, Promise.resolve(doc));
    fragments[event.id] = event;
    return event;
  };

  const remoteWrite = async (op: Extract<ModelOp, { kind: "remote" }>): Promise<NostrEvent> => {
    const events = worldEvents();
    const known = await Promise.all(events.map(async (event) => ({ event, doc: await open(event) })));
    const count = fragmentView(known).count;
    const material = materials[op.member % materials.length];
    const nowMs = time.now;
    // Strictly newer than every fragment the relay or the store holds, so a store delivery is always a real arrival
    // (a tie with a store-only fragment would make the store keep the other copy and drop this one).
    const createdAt = Math.max(
      Math.floor(nowMs / 1000) + 1,
      ...[...events, ...store.getTimeline(listFilter)].map((event) => event.created_at + 1),
    );
    let index: number;
    let doc: CommunityListFragment;
    // A grow needs fragments 0..count-1 to exist: on an empty relay world it writes d=0 like an add, otherwise the
    // world would declare a count no device can ever complete (index 0 would never exist).
    if (op.action === "grow" && known.length > 0) {
      index = count;
      doc = { frags: count + 1, entries: [entryFor(material, nowMs)], tombstones: [] };
    } else {
      const holding = known.find(({ event, doc }) =>
        dOf(event) < count && doc.entries.some((e) => e.community_id === material.community_id)
      );
      index = holding ? dOf(holding.event) : 0;
      const prior = known.find(({ event }) => dOf(event) === index)?.doc;
      const base = { entries: prior?.entries ?? [], tombstones: prior?.tombstones ?? [] };
      doc = op.action !== "remove"
        ? {
          ...prior,
          frags: count,
          entries: mergeCommunities(base.entries, [entryFor(material, nowMs)]),
          tombstones: base.tombstones,
        }
        : {
          ...prior,
          frags: count,
          entries: base.entries.filter((e) => e.community_id !== material.community_id),
          tombstones: mergeCommunityTombstones(base.tombstones, [
            { community_id: material.community_id, removed_at: nowMs },
          ]),
        };
    }
    const event = await remoteFragment(user, index, doc, createdAt);
    docs.set(event.id, Promise.resolve(doc));
    fragments[event.id] = event;
    return event;
  };

  const runOp = async (op: ModelOp): Promise<void> => {
    stepLabel = op.kind;
    const entry = record({ type: "op", op, input: isInputOp(op), result: "pending" }) as Entry<"op">;
    switch (op.kind) {
      case "start":
        startClient(entry);
        break;
      case "stop":
        reset("stop");
        if (model.state !== "disposed") model.state = "stopped";
        clientCall(entry, () => client.stop());
        break;
      case "dispose":
        reset("dispose");
        model.state = "disposed";
        clientCall(entry, () => client.dispose());
        break;
      case "join":
        entry.cid = materials[op.member % materials.length].community_id;
        clientCall(entry, () => client.joinByBundle(bundles[op.member % bundles.length]));
        break;
      case "leave": {
        const cid = materials[op.member % materials.length].community_id;
        entry.cid = cid;
        clientCall(entry, () => client.leave(cid));
        break;
      }
      case "create":
        clientCall(entry, () => client.createNewCommunity("M", "", ["wss://fake"]));
        break;
      case "unlock":
        clientCall(entry, () => client.unlockCommunityListFragments());
        break;
      case "save":
        clientCall(entry, () => client.saveCommunityList());
        break;
      case "read-mode":
        readMode = op.mode;
        entry.result = "ok";
        break;
      case "finish-slow":
        entry.result = "ok";
        finishSlow(op.outcome);
        break;
      case "publish-mode":
        publishMode = op.mode;
        entry.result = "ok";
        break;
      case "signer":
        modes[op.method] = op.mode;
        entry.result = "ok";
        break;
      case "park":
        entry.result = "ok";
        armed.add(op.method);
        break;
      case "fail-next":
        entry.result = "ok";
        failNext.add(op.method);
        break;
      case "release-stalls":
        entry.result = "ok";
        for (const method of Object.keys(modes) as SignerMethod[]) if (modes[method] === "stall") modes[method] = "ok";
        disarmParks();
        releaseStalls();
        break;
      case "remote": {
        entry.result = "ok";
        if (op.action !== "stale") entry.cid = materials[op.member % materials.length].community_id;
        const event = op.action === "stale" ? await staleWrite() : await remoteWrite(op);
        if (!event) break; // a stale copy needs something to be older than: nothing delivered, no reset
        if (op.delivery !== "store") toWorld(event);
        if (op.delivery !== "relay") {
          // A store delivery is the live subscription's: like a NIP-01 REQ it first replays what the relay holds and
          // the store lacks, then the new event. Each one is an arrival, recorded before the store delivers it.
          const replay = worldEvents().filter((e) => e.id !== event.id);
          for (const arrival of [...replay, event]) {
            const held = store.getReplaceable(COMMUNITY_LIST_FRAGMENT_KIND, pubkey, String(dOf(arrival)));
            if (held && !newer(arrival, held)) continue;
            reset("remote-arrived", arrival.id);
            store.add(arrival);
            if (!store.hasEvent(arrival.id)) throw new ModelHarnessError(`the store refused remote ${arrival.id}`);
          }
        }
        break;
      }
      case "advance":
        entry.result = "ok";
        await advance(op.ms);
        return;
    }
    await drain();
  };

  const liveIds = (list: ParsedCommunityList) =>
    [...new Set(liveCommunities(list.entries, list.tombstones).map((e) => e.community_id))].sort();
  const probe = async (name: ProbeName): Promise<void> => {
    const raw = await storage.getItem(pubkey);
    const local = parseCommunityList(raw ?? undefined);
    const stored = await Promise.all(
      store.getTimeline(listFilter).map(async (event) => ({ event, doc: await open(event) })),
    );
    const status = client.communityListSync.status;
    const snapshot: ProbeSnapshot = {
      started: model.state === "started",
      disposed: model.state === "disposed",
      pendingDuties: (client as unknown as { listDuties: { pending: number } }).listDuties.pending,
      knowledge: status.knowledge as ModelKnowledge,
      pending: status.pending,
      dirty: client.communityListDirty$.value,
      localLive: liveIds(local),
      storeLive: fragmentView(stored).live,
      storeIds: storeIds(),
      reads,
      signerCalls,
      unsettledOps: pendingOps.size,
    };
    record({ type: "probe", name, snapshot });
  };

  const lifetime = COMMUNITY_LIST_READ_RETRY.lifetimeMs;
  try {
    await drain();
    for (const [index, op] of run.ops.entries()) {
      step = index;
      await runOp(op);
    }
    step = run.ops.length;
    if (model.state === "stopped") await runOp({ kind: "start" });
    stepLabel = "quiescence";
    disarmParks(); // no call parks or fails once during quiescence
    failNext.clear();
    releaseStalls();
    for (const method of Object.keys(modes) as SignerMethod[]) if (modes[method] === "stall") modes[method] = "fail";
    finishSlow("error");
    await drain();
    await probe("quiescence-start");
    await advance(10 * lifetime);
    await probe("quiescence-end");
    if (model.state === "started") {
      stepLabel = "liveness";
      readMode = "complete";
      publishMode = "accept";
      for (const method of Object.keys(modes) as SignerMethod[]) modes[method] = "ok";
      disarmParks(); // nor after the heal
      failNext.clear();
      releaseStalls();
      finishSlow("complete");
      await advance(2 * lifetime);
      await probe("liveness-healed");
      // The app's nudge, twice: the read the first save renews may bring a fragment that only an app unlock decrypts
      // when autoUnlock is off, so the second unlock and save follow that read.
      for (let round = 0; round < 2; round++) {
        client.unlockCommunityListFragments().catch(() => {});
        client.saveCommunityList().catch(() => {});
        await advance(lifetime);
      }
      await probe("liveness-nudged");
    }
    await Promise.all(carrying); // every list-save signer call's carried memberships are in the trace
    await probe("final");
    return { run, entries, fragments };
  } finally {
    // Parked signer calls stay parked: releasing them now would only run obsolete work after the client is gone.
    recording = false;
    for (const subscription of subscriptions) subscription.unsubscribe();
    try {
      client.stop();
      client.dispose();
      store.dispose();
      for (let turns = 0; turns < 2; turns++) await turn();
    } finally {
      time.restore();
      Math.random = random;
    }
  }
}
