import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { assertSpyCalls, spy, stub } from "@std/testing/mock";
import { RumorStore } from "applesauce-core";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";

import { ConcordCommunityAdmin } from "../admin.ts";
import { foldControl } from "../../helpers/control.ts";
import { createLegacyCommunity } from "../../helpers/__tests__/test-utils.ts";
import type { RumorTemplate } from "../../types.ts";

/** An admin over a fresh community whose current invite registry content is `registry`. */
async function adminWithRegistry(registry: string | undefined) {
  const owner = getPublicKey(generateSecretKey());
  const genesis = await createLegacyCommunity({ ownerPubkey: owner, name: "Test", relays: ["wss://fake"] });
  const state = foldControl([], genesis.material);
  const publish = spy(async (_rumor: RumorTemplate): Promise<string> => "id");
  const publishRequired = spy(async (_rumor: RumorTemplate): Promise<string> => "id");
  const admin = new ConcordCommunityAdmin({
    community: {} as ConstructorParameters<typeof ConcordCommunityAdmin>[0]["community"],
    store: new RumorStore(),
    state: () => state,
    pubkey: owner,
    publish,
    publishRequired,
    mintChannelKey: () => {},
  });
  const head = stub(
    admin,
    "latestEdition",
    () =>
      Promise.resolve(registry === undefined ? undefined : { version: 1, hash: "00".repeat(32), content: registry }),
  );
  return { admin, publish, publishRequired, restore: () => head.restore() };
}

const LINK = "11".repeat(32);
const OTHER = "22".repeat(32);

describe("invite registry edits", () => {
  it("adds to and removes from a readable registry", async () => {
    const h = await adminWithRegistry(JSON.stringify([OTHER]));
    try {
      await h.admin.registerInviteLink(LINK);
      assertSpyCalls(h.publish, 1);
      expect(JSON.parse(h.publish.calls[0].args[0].content)).toEqual([OTHER, LINK]);
      await h.admin.unregisterInviteLink(OTHER);
      assertSpyCalls(h.publishRequired, 1);
      expect(JSON.parse(h.publishRequired.calls[0].args[0].content)).toEqual([]);
    } finally {
      h.restore();
    }
  });

  it("starts a new registry when none exists", async () => {
    const h = await adminWithRegistry(undefined);
    try {
      await h.admin.registerInviteLink(LINK);
      expect(JSON.parse(h.publish.calls[0].args[0].content)).toEqual([LINK]);
    } finally {
      h.restore();
    }
  });

  for (
    const [label, content] of [
      ["unparseable JSON", "not json"],
      ["a non-array document", JSON.stringify({ links: [OTHER] })],
      ["non-string entries", JSON.stringify([OTHER, 5])],
    ] as const
  ) {
    it(`refuses to publish over ${label}`, async () => {
      const h = await adminWithRegistry(content);
      try {
        await expect(h.admin.registerInviteLink(LINK)).rejects.toThrow(/invite registry is unreadable/);
        await expect(h.admin.unregisterInviteLink(OTHER)).rejects.toThrow(/invite registry is unreadable/);
        assertSpyCalls(h.publish, 0);
        assertSpyCalls(h.publishRequired, 0);
      } finally {
        h.restore();
      }
    });
  }
});
