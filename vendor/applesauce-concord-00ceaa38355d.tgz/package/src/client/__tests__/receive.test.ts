import { expect } from "@std/expect";
import { it } from "@std/testing/bdd";
import { setVerifyWrappedEventMethod, verifyEvent } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { EventStore } from "applesauce-core";
import { sealRumor, toRumor, wrapSeal } from "../../operations/gift-wrap.ts";
import { createCommunity } from "../../helpers/community.ts";
import { channelEpochOf, deriveConcordKeys, planeKeyFor, wrapForTarget } from "../../helpers/keys.ts";
import { foldControl } from "../../helpers/control.ts";
import { decoded } from "../../helpers/__tests__/test-utils.ts";
import { bindToChannel } from "../../operations/channel.ts";
import { addWrap, createReceiveDecoder, decodeReceivedWrap } from "../receive.ts";

it("receive reuse binds exact bytes and plane keys and keeps decoded evidence private", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const { material } = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "test", relays: [] });
  const keys = deriveConcordKeys(material, []);
  const { wrap } = await wrapForTarget(keys, { plane: "guestbook" }, signer, { kind: 1, tags: [], content: "valid" });
  const info = keys.planes.get(wrap.pubkey)!;
  const decode = createReceiveDecoder();
  const original = structuredClone(wrap);
  const first = decode(wrap, info)!;
  expect(first.rumor.content).toBe("valid");
  first.rumor.content = "changed";
  expect(decode(structuredClone(wrap), info)?.rumor.content).toBe("valid");
  wrap.content += "x";
  expect(decode(wrap, info)).toBeNull();
  expect(decode(original, { ...info, convKey: new Uint8Array(32) })).toBeNull();
  expect(decode(original, { ...info, type: "control" })).toBeNull();
  expect(decode(original, info)?.rumor.content).toBe("valid");
});

it("verifies each envelope once when a canonical copy has identical wire bytes", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const { material } = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "test", relays: [] });
  const keys = deriveConcordKeys(material, []);
  const { wrap } = await wrapForTarget(keys, { plane: "guestbook" }, signer, { kind: 1, tags: [], content: "valid" });
  const info = keys.planes.get(wrap.pubkey)!;
  let calls = 0;
  setVerifyWrappedEventMethod((event) => {
    calls++;
    return verifyEvent(event);
  });
  try {
    const decode = createReceiveDecoder();
    expect(decode(wrap, info)).not.toBeNull();
    expect(calls).toBe(2);
    expect(decode(structuredClone(wrap), info)).not.toBeNull();
    expect(calls).toBe(2);
    expect(decode({ ...wrap, content: wrap.content + "x" }, info)).toBeNull();
    expect(calls).toBe(3);
  } finally {
    setVerifyWrappedEventMethod(verifyEvent);
  }
});

it("rejects unbound, cross-community and malformed dissolution before retention", async () => {
  const { DissolutionFactory } = await import("../../factories/control.ts");
  const { giftWrap, rewrapSeal } = await import("../../operations/gift-wrap.ts");
  const { decodeWrap } = await import("../../helpers/gift-wrap.ts");
  const signer = new PrivateKeySigner(generateSecretKey());
  const ownerPubkey = await signer.getPublicKey();
  const first = await createCommunity({ ownerPubkey, name: "A", relays: [] });
  const second = await createCommunity({ ownerPubkey, name: "B", relays: [] });
  const a = deriveConcordKeys(first.material, []);
  const b = deriveConcordKeys(second.material, []);
  const { wrap } = await wrapForTarget(
    a,
    { plane: "dissolved" },
    signer,
    await DissolutionFactory.create(first.material.community_id),
    { plaintext: true },
  );
  const decode = createReceiveDecoder();
  expect(decode(wrap, a.planes.get(a.dissolved.pk)!)).not.toBeNull();
  const replay = rewrapSeal(decodeWrap(wrap, a.dissolved.convKey)!.seal!, b.dissolved.sk, b.dissolved.convKey);
  expect(decode(replay, b.planes.get(b.dissolved.pk)!)).toBeNull();
  const valid = await DissolutionFactory.create(second.material.community_id);
  const impostor = new PrivateKeySigner(generateSecretKey());
  for (
    const draft of [
      { ...valid, tags: [["vsk", "10"], ["eid", "00".repeat(32)]] },
      { ...valid, tags: [["vsk", "10"]] },
      { ...valid, kind: 9 },
      { ...valid, content: "unexpected" },
      { ...valid, tags: [...valid.tags, ["ev", "0"]] },
      { ...valid, tags: [...valid.tags, ["ep", "ab".repeat(32)]] },
      { ...valid, tags: [...valid.tags, ["vsk", "10"]] },
    ]
  ) {
    const invalid = await giftWrap(b.dissolved.sk, b.dissolved.convKey, signer, { plaintext: true })(draft);
    expect(decode(invalid, b.planes.get(b.dissolved.pk)!)).toBeNull();
  }
  const forged = await giftWrap(b.dissolved.sk, b.dissolved.convKey, impostor, { plaintext: true })(valid);
  expect(decode(forged, b.planes.get(b.dissolved.pk)!)).toBeNull();
});

it("enforces each plane's seal policy while generic stream builders remain flexible", async () => {
  const { giftWrap } = await import("../../operations/gift-wrap.ts");
  const { DissolutionFactory } = await import("../../factories/control.ts");
  const signer = new PrivateKeySigner(generateSecretKey());
  const owner = await signer.getPublicKey();
  const { material, generalChannelId } = await createCommunity({ ownerPubkey: owner, name: "test", relays: [] });
  const keys = deriveConcordKeys(material, [{ channel_id: generalChannelId, name: "general", private: false }]);
  const decode = createReceiveDecoder();
  for (const info of keys.planes.values()) {
    const draft = info.type === "dissolved"
      ? await DissolutionFactory.create(material.community_id)
      : { kind: info.type === "control" ? 3308 : 9, created_at: 1, tags: [], content: "test" };
    for (const plaintext of [true, false]) {
      const wrap = await giftWrap(generateSecretKey(), info.convKey, signer, { plaintext })(draft);
      const expected = info.type === "control" || info.type === "dissolved";
      expect(decode(wrap, info) !== null).toBe(plaintext === expected);
    }
  }
  for (
    const target of [
      { plane: "control" },
      { plane: "guestbook" },
      { plane: "dissolved" },
      { plane: "channel", channelId: generalChannelId },
    ] as const
  ) {
    const draft = target.plane === "dissolved"
      ? await DissolutionFactory.create(material.community_id)
      : { kind: target.plane === "control" ? 3308 : 9, created_at: 1, tags: [], content: "test" };
    const plaintext = target.plane === "control" || target.plane === "dissolved";
    const { wrap } = await wrapForTarget(keys, target, signer, draft);
    expect(decode(wrap, keys.planes.get(wrap.pubkey)!)?.sealKind).toBe(plaintext ? 20014 : 20013);
    await expect(wrapForTarget(keys, target, signer, draft, { plaintext: !plaintext })).rejects.toThrow(
      "invalid seal type",
    );
  }
});

it("addWrap keeps an authenticated wrap whose only refusal is a past outer expiration tag (CORD-08 §2)", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const { material } = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "test", relays: [] });
  const keys = deriveConcordKeys(material, []);
  const key = keys.guestbook;
  const wrapWith = async (content: string, expiration?: number) => {
    const rumor = await toRumor(signer)({ kind: 1, tags: [], content, created_at: Math.floor(Date.now() / 1000) });
    return wrapSeal(key.sk, key.convKey, { expiration })(await sealRumor(key.convKey, signer)(rumor));
  };
  const store = new EventStore();
  try {
    const past = await wrapWith("past", 1);
    const kept = addWrap(store, past);
    expect(kept).toEqual(past);
    // The upstream store refuses the wrap for its outer tag, so the wire comes back unstored.
    expect(store.hasEvent(past.id)).toBe(false);
    // The fallback is for Chat: on a channel plane it keeps the wire, and on any other known plane the refusal stands
    // so control state never folds an edition whose seal the store does not hold (CORD-06 §2).
    const info = keys.planes.get(past.pubkey)!;
    expect(addWrap(store, past, { ...info, type: "channel" })).toEqual(past);
    expect(addWrap(store, past, info)).toBeNull();
    expect(addWrap(store, past, { ...info, type: "control" })).toBeNull();
    // The store refuses a past outer tag before it verifies anything, so the fallback checks the bytes itself.
    expect(addWrap(store, { ...past, content: past.content + "x" })).toBeNull();
    expect(addWrap(store, { ...past, sig: "00".repeat(64) }, { ...info, type: "channel" })).toBeNull();

    const untagged = await wrapWith("untagged");
    expect(addWrap(store, untagged)?.id).toBe(untagged.id);
    expect(store.hasEvent(untagged.id)).toBe(true);

    const future = await wrapWith("future", Math.floor(Date.now() / 1000) + 3600);
    expect(addWrap(store, future)?.id).toBe(future.id);
    expect(store.hasEvent(future.id)).toBe(true);

    // Any other refusal, with an outer tag that is not past, stays a refusal.
    expect(addWrap({ add: () => null }, untagged)).toBeNull();
  } finally {
    store.dispose();
  }
});

it("the receive boundary refuses an already-expired Chat rumor whatever its outer tag says (CORD-08 §2, §3)", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const genesis = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "timer", relays: [] });
  const state = foldControl(genesis.controlRumors.map((r) => decoded(r, genesis.material.owner)), genesis.material);
  const keys = deriveConcordKeys(genesis.material, state.channels);
  const channelId = genesis.generalChannelId;
  const key = planeKeyFor(keys, { plane: "channel", channelId });
  const epoch = channelEpochOf(keys, channelId);
  const now = Math.floor(Date.now() / 1000);
  /** A Chat wrap whose signed rumor carries `signed` and whose outer wrap carries `outer`, set independently. */
  const chat = async (signed: number | undefined, outer: number | undefined) => {
    const template = await bindToChannel(channelId, epoch)({
      kind: 9,
      content: "x",
      tags: signed === undefined ? [] : [["expiration", String(signed)]],
      created_at: now - 600,
    });
    const seal = await sealRumor(key.convKey, signer)(await toRumor(signer)(template));
    return wrapSeal(key.sk, key.convKey, { expiration: outer })(seal);
  };
  const info = (wrap: { pubkey: string }) => keys.planes.get(wrap.pubkey)!;
  const past = now - 60;
  const future = now + 3600;

  // An expired rumor is refused with no outer tag and with a future outer tag, by the one-shot and the caching decoder.
  for (const outer of [undefined, future]) {
    const wrap = await chat(past, outer);
    expect({ outer, refused: decodeReceivedWrap(wrap, info(wrap)) === null }).toEqual({ outer, refused: true });
    expect({ outer, refused: createReceiveDecoder()(wrap, info(wrap)) === null }).toEqual({ outer, refused: true });
  }
  // Non-vacuity: the same wraps are accepted while the signed expiry is live, and a past outer tag alone refuses nothing
  // here, because the receive boundary reads the signed tag only.
  for (const [signed, outer] of [[future, undefined], [future, past], [undefined, past]] as const) {
    const wrap = await chat(signed, outer);
    expect({ signed, outer, kept: decodeReceivedWrap(wrap, info(wrap)) !== null }).toEqual({
      signed,
      outer,
      kept: true,
    });
    expect({ signed, outer, kept: createReceiveDecoder()(wrap, info(wrap)) !== null }).toEqual({
      signed,
      outer,
      kept: true,
    });
  }
});
