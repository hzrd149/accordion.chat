// CORD-02 §8: pure Community List document helpers shared by the client. Membership liveness is
// derived (newest add vs newest removal), tombstones are never dropped, and only a completed
// remote read can say whether a local change is still unpublished.

import { controlKeyFor } from "../helpers/crypto.ts";
import {
  canonicalJson,
  communityListByteSize,
  communityListEntryByteSize,
  getCommunityList,
  isCommunityLive,
  mergeCommunities,
  mergeCommunityTombstones,
  parseCommunityList,
  type ParsedCommunityList,
} from "../helpers/community-list.ts";
import type { CommunityListCommunity, CommunityTombstone, JoinMaterial } from "../types.ts";
import type { ConcordCommunityListStatus } from "./community-list-sync.ts";
import type { NostrEvent } from "applesauce-core/helpers/event";

/** Parse a mirror payload, migrating the legacy format (a bare `JoinMaterial[]` — a membership
 *  set with no `added_at` and no tombstones) in place. Legacy memberships seed `added_at: 0` so
 *  any tombstone the relay copy carries outranks them: a device whose mirror predates this format
 *  must not undo a leave it never witnessed. An unpublished legacy join still survives, because
 *  liveness only consults `added_at` when a tombstone exists at all. */
export function parseCommunityListMirror(raw: string): ParsedCommunityList {
  const parsed = JSON.parse(raw) as unknown;
  if (!Array.isArray(parsed)) return parseCommunityList(raw);
  return {
    entries: (parsed as JoinMaterial[])
      .filter((material) => typeof material?.community_id === "string")
      .map((material) => ({
        community_id: material.community_id,
        seed: material,
        current: material,
        added_at: 0,
      })),
    tombstones: [],
  };
}

/** The community ids whose local entries or tombstones differ canonically from the remote fragment document. */
export function changedCommunityIds(
  list: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
  remote: ParsedCommunityList,
): string[] {
  return [...new Set([...list.map((entry) => entry.community_id), ...tombstones.map((item) => item.community_id)])]
    .filter((id) =>
      canonicalJson({
        entries: list.filter((entry) => entry.community_id === id),
        tombstones: tombstones.filter((item) => item.community_id === id),
      }) !== canonicalJson({
        entries: remote.entries.filter((entry) => entry.community_id === id),
        tombstones: remote.tombstones.filter((item) => item.community_id === id),
      })
    );
}

/** Whether a staged list newly carries a usable control signing key. */
export function addsControlCapability(prior: CommunityListCommunity[], staged: CommunityListCommunity[]): boolean {
  return staged.some((entry) => {
    if (
      prior.find((item) => item.community_id === entry.community_id)?.current.control_root ===
        entry.current.control_root
    ) return false;
    try {
      return !!entry.current.control_root && !!controlKeyFor(entry.current).signing;
    } catch {
      return false;
    }
  });
}

/**
 * CORD-02 §8 / D-26: membership-level changes the local document holds that the remote copy does
 * not. The remote is merged into the local copy first, so a remote newer than the mirror never
 * reads as a local change; the result is the sorted ids whose liveness still differs from the
 * remote. A membership live only locally with a newest `added_at` of 0 (a legacy bare-array
 * mirror) is excluded, and material-only differences (a newer `current` for a membership both
 * sides hold live) are never held.
 */
export function heldMembershipIds(local: ParsedCommunityList, remote: ParsedCommunityList): string[] {
  const entries = mergeCommunities(local.entries, remote.entries, true);
  const tombstones = mergeCommunityTombstones(local.tombstones, remote.tombstones);
  const ids = new Set([...entries.map((entry) => entry.community_id), ...tombstones.map((t) => t.community_id)]);
  return [...ids].filter((id) => {
    const localLive = isCommunityLive(entries, tombstones, id);
    if (localLive === isCommunityLive(remote.entries, remote.tombstones, id)) return false;
    const newestAdd = Math.max(...local.entries.filter((e) => e.community_id === id).map((e) => e.added_at ?? 0), 0);
    return !(localLive && newestAdd === 0);
  }).sort();
}

/**
 * CORD-02 §8 / D-26: whether a Community List save is owed. False while knowledge is "unknown"
 * (the D-15 gate) and while it is "partial" (the remote copy cannot be compared); true when a
 * write was refused in this process (`pending`); otherwise true exactly when the local document
 * holds a membership change that neither the kind-33302 document nor a decrypted kind-13302
 * import (import-only, D-22) already carries.
 */
export function communityListSaveDue(
  status: ConcordCommunityListStatus,
  local: ParsedCommunityList,
  remote: ParsedCommunityList,
  imported?: ParsedCommunityList,
): boolean {
  if (status.knowledge === "unknown") return false;
  if (status.pending) return true;
  if (status.knowledge === "partial") return false;
  const base: ParsedCommunityList = imported
    ? {
      ...remote,
      entries: mergeCommunities(remote.entries, imported.entries),
      tombstones: mergeCommunityTombstones(remote.tombstones, imported.tombstones),
    }
    : remote;
  return heldMembershipIds(local, base).length > 0;
}

/** {@link communityListSaveDue} for the client's local document, its sync and its store's decrypted kind-13302 import. */
export function heldSaveDue(
  sync: { status: ConcordCommunityListStatus; fragments: { document: ParsedCommunityList } },
  entries: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
  imported: NostrEvent | undefined,
): boolean {
  const document = imported && getCommunityList(imported);
  return communityListSaveDue(sync.status, { entries, tombstones }, sync.fragments.document, document);
}

/** A one-line size trace of a Community List document for debug logs: total bytes, entry count, tombstone bytes and
 *  the largest entry. Informational only, never a refusal reason. */
export function describeCommunityListSize(list: CommunityListCommunity[], tombstones: CommunityTombstone[]): string {
  let largestEntryId = "";
  let largestEntryBytes = -1;
  for (const entry of list) {
    const entryBytes = communityListEntryByteSize(entry);
    if (entryBytes > largestEntryBytes) {
      largestEntryBytes = entryBytes;
      largestEntryId = entry.community_id;
    }
  }
  // Tombstone bytes are reported explicitly so a tombstone-dominated document does not misdirect an operator, and an
  // empty list omits the largest-entry clause rather than ending in a bare `community=`.
  const tombstoneBytes = new TextEncoder().encode(JSON.stringify(tombstones)).length;
  const largest = list.length === 0
    ? ""
    : ` — largest entry community=${largestEntryId.slice(0, 8)} (${largestEntryBytes} bytes)`;
  return `${
    communityListByteSize(list, tombstones)
  } bytes, ${list.length} entries, ${tombstoneBytes} tombstone bytes${largest}`;
}

/**
 * Merge a community's rolled-forward material into its existing membership entry (CORD-02 §8): the entry's newer
 * read of the root wins, a `control_root` the changed material lacks is carried only while the community coordinates
 * match, and `held_roots` are unioned. Pure: the caller stages and persists the result.
 */
export function mergeMaterialChange(previous: CommunityListCommunity, changed: JoinMaterial): JoinMaterial {
  const sameRead = previous.current.root_epoch === changed.root_epoch &&
    previous.current.community_root === changed.community_root;
  const proposed = { ...previous, current: changed };
  const merged =
    (sameRead ? mergeCommunities([previous], [proposed], true) : mergeCommunities([proposed], [previous], true))[
      0
    ].current;
  let current: JoinMaterial = previous.current.control_pk !== changed.control_pk && sameRead
    ? merged
    : { ...changed, ...(merged.held_roots ? { held_roots: merged.held_roots } : {}) };
  if (sameRead && merged.control_root === undefined) {
    const { control_root: _secret, ...read } = current;
    current = read;
  }
  const coordinates = [
    "community_id",
    "owner",
    "owner_salt",
    "community_root",
    "root_epoch",
    "control_pk",
  ] as const;
  if (merged.control_root && coordinates.every((field) => changed[field] === merged[field])) {
    current = { ...current, control_root: merged.control_root };
  }
  return current;
}
