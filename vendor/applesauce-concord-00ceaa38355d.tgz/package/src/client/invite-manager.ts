// ConcordInviteManager — client-owned CORD-05 Invite List management.
//
// The Community publishes public invite bundles and registry edits, but the
// creator's private kind-13303 Invite List is per-user account state. This
// manager owns that list the same way ConcordClient owns the Community List:
// merge remote copies, expose rich app-facing records, and publish only when the
// plaintext content actually changed.

import { assertEnvelopeCap } from "../helpers/caps.ts";
import { type Debugger, type EventStore, mapEventsToStore } from "applesauce-core";
import {
  BehaviorSubject,
  firstValueFrom,
  map,
  type Observable,
  of,
  Subject,
  type Subscription,
  switchMap,
  timeout,
  toArray,
} from "rxjs";
import type { User } from "applesauce-core/casts";
import { setHiddenContentCache } from "applesauce-core/helpers";
import { finalizeEvent } from "applesauce-core/helpers/event";
import { getPublicKey } from "applesauce-core/helpers/keys";
import { hexToBytes } from "@noble/hashes/utils.js";
import type { PublishResponse, RelayAuthHandler, RelayPool } from "applesauce-relay";
import type { ISigner } from "applesauce-signers";

import { logger } from "../logger.ts";
import { StreamSigners } from "./auth.ts";
import type { ConcordInviteList } from "../casts/index.ts";
import type { ConcordInviteListUser } from "../casts/invite-list.ts";
import { canonicalJson } from "../helpers/community-list.ts";
import { parseInviteLink } from "../helpers/invite-bundle.ts";
import { ExtraRelays, type ExtraRelaysOption } from "../helpers/relays.ts";
import { InviteBundleFactory } from "../factories/invite-bundle.ts";
import {
  getInviteList,
  INVITE_LIST_KIND,
  type InviteListInviteField,
  liveInviteEntries,
  mergeInvites,
  mergeTombstones,
  validateInviteListInvite,
} from "../helpers/invite-list.ts";
import type { InviteListInvite, InviteListTombstone } from "../types.ts";
import { InviteRevocationPublishError, reportUnacknowledgedPublish, requireInviteRevocationAck } from "./revocation.ts";
import { type ConcordDiagnostic, DiagnosticsSink } from "./diagnostics.ts";

/** One invite link as the app sees it: the private Invite List entry plus the derived
 *  fields a UI needs. Secret-bearing — `token` and `signerSk` are key material, so this
 *  shape belongs in the user's own encrypted list, never in a published document. */
export interface ConcordInviteLink {
  /** Hex-encoded invite unlock token. Also the Invite List merge key. */
  token: string;
  /** Hex-encoded link signer secret key, needed to refresh or revoke the bundle. */
  signerSk: string;
  /** The link signer's public key, i.e. the kind-33301 coordinate author. */
  signerPubkey: string;
  /** The community this link admits to. */
  communityId: string;
  /** The shareable invite URL, carrying the token and the bootstrap relays a joiner needs. */
  url: string;
  /** Optional label, kept in the creator's Invite List and also carried in the published bundle, so
   *  joiners can read it (and echo it in their guestbook Join). Do not put secrets here. */
  label?: string;
  /** Private channel ids this link grants. Omitted or empty grants none. */
  channels?: string[];
  /** Unix seconds, matching the CORD-05 Invite List wire field. */
  createdAt: number;
  /** Unix seconds (D-05), matching the CommunityInvite bundle field. */
  expiresAt?: number;
  /** Whether a tombstone exists for this token. Derived on read from the tombstone list
   *  rather than stored on the entry, and terminal — a revoked link never resurrects. */
  revoked: boolean;
}

/** One Invite List entry that failed validation and was quarantined. Emitted rather than
 *  thrown so a single malformed entry cannot cost the user every other invite in the list. */
export interface InviteListDiagnostic {
  /** Event id of the Invite List that carried the bad entry. */
  sourceId: string;
  /** Position of the entry within that document's `entries` array. */
  entryIndex: number;
  /** Quarantined entries are skipped, never repaired or republished. */
  status: "quarantined";
  /** Which field failed validation. */
  field: InviteListInviteField;
  /** Whether the field was absent or present but unusable. */
  reason: "missing" | "invalid";
}

/** Construction options for {@link ConcordInviteManager}. */
export interface ConcordInviteManagerOptions {
  /** The user's signer. NIP-44 is required to read and write the encrypted list. */
  signer: ISigner;
  /** Relay pool used for this manager's invite-list reads and publishes. */
  pool: RelayPool;
  /** Shared store the read Invite List events land in. */
  eventStore: EventStore;
  /** Receives background failures such as a failed Invite List publish; the owning client forwards them to its
   *  `diagnostics$`. */
  onDiagnostic?: (diagnostic: ConcordDiagnostic) => void;
  /** Default transport relays for this manager's own requests and publishes. */
  relays: string[];
  /** Decrypt the list as soon as it arrives instead of waiting for {@link
   *  ConcordInviteManager.unlock}. Off by default, because a prompting signer would
   *  otherwise challenge the user unbidden. */
  autoUnlock?: boolean;
  /** Bridge back to the owning client, so minting and revoking can go through the
   *  community's admin authority. Returns `undefined` once the user has left, which is
   *  what routes revocation down the membership-free path. */
  getCommunity: (communityId: string) =>
    | {
      admin: {
        createInvite: (options: CreateInviteOptions) => Promise<ConcordInviteLink>;
        revokeInvite: (invite: ConcordInviteLink) => Promise<ConcordInviteLink>;
      };
    }
    | undefined;
  /** Additional transport-only relays unioned onto every request/publish this
   *  manager performs (D-12). Never written into any published content, and
   *  purely additive: with no extras configured, {@link ExtraRelays.merge}'s
   *  identity fast path returns `relays` completely unchanged (D-14). When
   *  extras ARE configured, the merged transport set is normalized and
   *  deduplicated (`mergeRelaySets`), which changes the shape of relay-target
   *  strings and `pool.status$` lookup keys for that configuration. */
  extraRelays?: ExtraRelaysOption;
  /** The user's own auth handler, built ONCE by {@link ConcordClient} (D-08) — answers the
   *  two user-signed publishes/reads in this manager (the invite-list read and `save()`'s
   *  publish, D-17). Never used for `revokeBundle()`'s publish, which is signed by the
   *  invite-LINK key, not the user's. */
  userOnAuthRequired?: RelayAuthHandler;
  /** A custom debug logger (defaults to the "applesauce:concord" namespace, extended
   *  with "invite" when threaded from {@link ConcordClient}). */
  logger?: Debugger;
}

/** What the caller chooses when minting a new invite link. */
export interface CreateInviteOptions {
  /** Base URL the shareable invite link is built on. */
  base: string;
  /** Optional label, kept in the creator's Invite List and also carried in the published bundle, so
   *  joiners can read it (and echo it in their guestbook Join). Do not put secrets here. */
  label?: string;
  /** Unix seconds (D-05). */
  expiresAt?: number;
  /** Private channels this link grants, by channel id. Omit to grant none. */
  channels?: string[];
}

/**
 * Owns one user's private kind-13303 Invite List: merge remote copies, expose app-facing
 * records, and publish only when the plaintext actually changed. This is account state
 * rather than community state, which is why it lives beside {@link ConcordClient}'s
 * Community List instead of inside a community.
 */
export class ConcordInviteManager {
  /** The current Invite List cast, or `undefined` before one is read and after {@link stop}.
   *  Re-emits whenever a newer copy replaces it. */
  readonly event$: BehaviorSubject<ConcordInviteList | undefined> = new BehaviorSubject<ConcordInviteList | undefined>(
    undefined,
  );
  /** Every known link, revoked ones included, after merging local and remote state. Emits on
   *  each remote merge and each local mint or revocation. */
  readonly entries$: BehaviorSubject<ConcordInviteLink[]> = new BehaviorSubject<ConcordInviteLink[]>([]);
  /** The subset of {@link entries$} with no tombstone. Expiry is not applied here — an
   *  expired-but-unrevoked link still appears. */
  readonly live$: BehaviorSubject<ConcordInviteLink[]> = new BehaviorSubject<ConcordInviteLink[]>([]);
  /** The subset of {@link entries$} that has been tombstoned. */
  readonly revoked$: BehaviorSubject<ConcordInviteLink[]> = new BehaviorSubject<ConcordInviteLink[]>([]);
  /** Whether local state holds changes not yet published. Emits `true` on every local
   *  mutation and when no relay accepts a saved list, and `false` once a save hands the list
   *  to the relays or finds nothing to publish. */
  readonly dirty$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  /** Quarantined entries, emitted once per distinct problem — re-reading the same bad list
   *  does not re-report it. */
  readonly diagnostics$: Observable<InviteListDiagnostic>;
  private readonly diagnostics = new Subject<InviteListDiagnostic>();

  /** The invite manager's debug logger — `options.logger` when threaded from
   *  {@link ConcordClient}, otherwise the `applesauce:concord:invite` module base
   *  (D-01/D-02). */
  private readonly log: Debugger;
  private readonly backgroundFailures: DiagnosticsSink;
  private readonly signer: ISigner;
  private readonly pool: RelayPool;
  private readonly eventStore: EventStore;
  private readonly relays: string[];
  private readonly autoUnlock: boolean;
  private readonly getCommunity: ConcordInviteManagerOptions["getCommunity"];
  /** The per-engine transport-only extras holder (D-04) — merges into every
   *  network target this manager dials; `this.relays` itself is never touched. */
  private readonly extras: ExtraRelays;
  /** The user's own auth handler, threaded through from `ConcordClient` (D-08). */
  private readonly userOnAuthRequired?: RelayAuthHandler;
  /** This manager's own scope: holds the invite-LINK signer keys for the links this
   *  user minted, which are neither the user's identity key nor any community's stream
   *  keys — kept separate from both (T-15-01). Constructed in the constructor body
   *  (not a field initializer) because it needs `this.log`, which a field
   *  initializer cannot reference (T-15-26/WR-04). */
  private readonly signers: StreamSigners;

  private pubkey?: string;
  private sub?: Subscription;
  private invites: InviteListInvite[] = [];
  private tombstones: InviteListTombstone[] = [];
  /** A snapshot of the last-read Invite List document (every top-level key, INCLUDING its own
   *  `entries`/`tombstones` as of that read), captured on read ({@link reconcile}) and spread
   *  back FIRST in {@link save}, before `entries`/`tombstones` are assigned from this manager's
   *  own state (WIRE-09/D-23) — mirrors {@link ConcordClient}'s `documentExtras` field verbatim
   *  (`client.ts`'s doc comment carries the fuller explanation, including why this is not the
   *  carrier D-12 rejected: no whole document is ever held in memory by either engine beyond
   *  this snapshot). Cleared on {@link stop} alongside `invites`/`tombstones`/
   *  `publishedFingerprint`, so a restart cannot replay a previous session's snapshot onto a
   *  document this session never read. */
  private documentExtras: Record<string, unknown> = {};
  /** The fingerprint of the last list a relay holds: one read from a relay, or one {@link save} published and at least
   *  one relay accepted. Never set from a publish no relay has accepted yet. */
  private publishedFingerprint: string | null = canonicalJson({ entries: [], tombstones: [] });
  /** The {@link save} publish in flight, if any. A later save with the same content waits on its outcome instead of
   *  republishing. Cleared on {@link stop}, so an outcome that settles afterwards changes nothing. */
  private inFlight?: { id: string; fingerprint: string };
  /** The id of the newest list event this manager signed that no relay has accepted yet. {@link reconcile} never
   *  adopts it as published, even after a {@link stop} and {@link start} with the same store. */
  private unacknowledgedId?: string;
  /** The promise tail {@link save} calls queue on, so two saves never sign at once. */
  private saveTail: Promise<unknown> = Promise.resolve();
  /** The `created_at` of the newest Invite List this manager signed; the next one is dated after it. */
  private lastSignedAt = 0;
  private readonly autoUnlocked = new Set<string>();
  private readonly diagnosed = new Set<string>();

  /** Wires up state and this manager's own signer scope but performs no I/O — nothing is
   *  read or published until {@link start}. */
  constructor(options: ConcordInviteManagerOptions) {
    this.diagnostics$ = this.diagnostics.asObservable();
    this.log = options.logger ?? logger.extend("invite");
    this.backgroundFailures = new DiagnosticsSink(this.log, options.onDiagnostic);
    // Reports a rejected/erroring invite-LINK AUTH on this manager's own logger
    // (D-13's remedy for this scope: no error$ equivalent exists here, and D-10
    // deliberately removed the standing status surface — a log line on :invite
    // is the whole fix, T-15-26/WR-04). Built here, not as a field initializer,
    // because it needs `this.log`, which is assigned immediately above.
    this.signers = new StreamSigners({
      onAuthFailure: (message) => this.log("invite-link auth failed: %s", message),
    });
    this.signer = options.signer;
    this.pool = options.pool;
    this.eventStore = options.eventStore;
    this.relays = options.relays;
    this.autoUnlock = options.autoUnlock ?? false;
    this.getCommunity = options.getCommunity;
    this.extras = new ExtraRelays(options.extraRelays);
    this.userOnAuthRequired = options.userOnAuthRequired;
  }

  /** The merged transport target for this manager: `base` (defaulting to
   *  `this.relays`) unioned with the current extras snapshot (D-04) — the ONLY
   *  merge point in the class. Every call site here is one-shot, so the
   *  holder's synchronous snapshot is the correct consumption shape (D-11).
   *  The optional `base` exists for the revoke path, which merges onto the
   *  link's own bootstrap relays rather than this manager's default set (D-12). */
  private transport(base?: string[]): string[] {
    return this.extras.merge(base ?? this.relays);
  }

  /** Begins tracking `user`'s Invite List: subscribes to their list cast, then fetches it.
   *  Re-callable after {@link stop}; a second live subscription never accumulates. */
  async start(user: User): Promise<void> {
    this.log("starting invite manager for %s", user.pubkey.slice(0, 8));
    this.pubkey = user.pubkey;
    this.sub?.unsubscribe();
    this.sub = (user as ConcordInviteListUser).concordInviteList$
      .pipe(switchMap((cast) => (cast ? cast.invites$.pipe(map(() => cast)) : of(undefined))))
      .subscribe((cast) => {
        this.event$.next(cast);
        if (!cast) return;
        if (this.autoUnlock && !cast.unlocked) {
          this.autoUnlockCast(cast);
          return;
        }
        this.reconcile(cast);
      });
    await this.refresh();
  }

  /** Pause: resets the in-memory list state but leaves the extras holder
   *  ({@link ExtraRelays}) alive and subscribed to the app-supplied source —
   *  restartable via {@link start}. To actually release the app's extras
   *  source, call {@link dispose} instead. */
  stop(): void {
    this.sub?.unsubscribe();
    this.sub = undefined;
    this.pubkey = undefined;
    this.event$.next(undefined);
    this.invites = [];
    this.tombstones = [];
    this.documentExtras = {};
    this.publishedFingerprint = canonicalJson({ entries: [], tombstones: [] });
    this.inFlight = undefined;
    this.diagnosed.clear();
    this.emit();
    this.dirty$.next(false);
  }

  /** Releases this manager's subscription to the app-supplied `extraRelays`
   *  source (WR-05) — unlike {@link stop} (pause-only, restartable), the
   *  manager is NOT restartable after `dispose()`. */
  dispose(): void {
    this.stop();
    this.extras.dispose();
    this.diagnostics.complete();
    this.backgroundFailures.complete();
  }

  /** One-shot re-read of the user's Invite List. Resolves even when no relay answers: a
   *  failed refresh leaves existing state alone rather than clearing it. */
  async refresh(): Promise<void> {
    this.log("refreshing invite list");
    if (!this.pubkey) this.pubkey = await this.signer.getPublicKey();
    await firstValueFrom(
      this.pool
        .request(this.transport(), [{ kinds: [INVITE_LIST_KIND], authors: [this.pubkey] }], {
          waitForAuth: [this.pubkey],
          onAuthRequired: this.userOnAuthRequired,
        })
        .pipe(mapEventsToStore(this.eventStore), toArray(), timeout(8000)),
    ).catch(() => []);
  }

  /** Decrypts the held list with the user's signer, then folds it in. The deliberate
   *  decryption entry point when `autoUnlock` is off; a no-op if nothing is locked. */
  async unlock(): Promise<void> {
    const event = this.event$.value;
    if (!event || event.unlocked) return;
    await event.unlock(this.signer);
    this.reconcile(event);
  }

  /** Looks up one link by its unlock token, the Invite List merge key. */
  get(token: string): ConcordInviteLink | undefined {
    return this.entries$.value.find((invite) => invite.token === token);
  }

  /** Every link this user minted for one community, revoked ones included. */
  forCommunity(communityId: string): ConcordInviteLink[] {
    return this.entries$.value.filter((invite) => invite.communityId === communityId);
  }

  /** Mints an invite through the community's admin surface and records it privately.
   *  Requires current membership — minting publishes a bundle and a registry entry. */
  async create(communityId: string, options: CreateInviteOptions): Promise<ConcordInviteLink> {
    this.log("building invite bundle for community=%s", communityId.slice(0, 8));
    const community = this.getCommunity(communityId);
    if (!community) throw new Error("community not found");
    const invite = await community.admin.createInvite(options);
    if (!this.get(invite.token)) await this.record(invite);
    return this.get(invite.token) ?? invite;
  }

  /** Revokes a link and tombstones it locally. While still a member this also unregisters the
   *  public coordinate (CORD-05 §5); afterwards it falls back to revoking the bundle alone
   *  with the stored link key, so old invites remain cleanable after leaving. */
  async revoke(inviteOrToken: string | ConcordInviteLink | InviteListInvite): Promise<ConcordInviteLink> {
    const invite = typeof inviteOrToken === "string"
      ? this.get(inviteOrToken)
      : fromInviteListInvite(toInviteListInvite(inviteOrToken), this.tombstones);
    if (!invite) throw new Error("invite not found");
    // Identify the link by its PUBLIC signer pubkey, never by the token — the
    // token is 128 bits of secret key material, not a public identifier, so the
    // 8-char truncation convention used for event/community ids does not apply.
    this.log("revoking invite link=%s community=%s", invite.signerPubkey.slice(0, 8), invite.communityId.slice(0, 8));
    // While we're still a member the community revokes the bundle AND unregisters the public link
    // (CORD-05 §5). Once we've left, the registry — which holds only public link coordinates, never
    // any private material — is neither reachable nor needed: revoke the bundle straight from the
    // stored link key so old invites can still be cleaned up.
    const community = this.getCommunity(invite.communityId);
    const revoked = community ? await community.admin.revokeInvite(invite) : await this.revokeBundle(invite);
    if (!this.get(revoked.token)?.revoked) await this.tombstone(revoked);
    return this.get(revoked.token) ?? revoked;
  }

  /** Revoke just the bundle, membership-free: publish an empty vsk-9 edition signed by the invite's
   *  stored link key to its own bootstrap relays. The community-side registry unregister is skipped —
   *  it needs a membership we no longer have, and a stale registry link resolves to a revoked bundle. */
  private async revokeBundle(invite: ConcordInviteLink): Promise<ConcordInviteLink> {
    // D-17: this publish is signed by the invite-LINK key, not the user — the two
    // publishes in this file have different authors, so this deliberately takes the
    // link's own handler rather than `this.userOnAuthRequired`. Do not conflate them.
    this.signers.addSecretKey(hexToBytes(invite.signerSk));
    const signed = finalizeEvent(await InviteBundleFactory.revoke(), hexToBytes(invite.signerSk));
    // The revoke path merges the extras onto the LINK's own bootstrap relays
    // (falling back to this manager's default set), never the manager's set
    // directly (D-12) — the base-vs-merged split is kept visible here.
    const bootstrapRelays = parseInviteLink(invite.url).bootstrapRelays;
    const base = bootstrapRelays.length ? bootstrapRelays : this.relays;
    let responses: PublishResponse[];
    try {
      responses = await this.pool.publish(this.transport(base), signed, {
        waitForAuth: [signed.pubkey],
        onAuthRequired: this.signers.onAuthRequired,
      });
    } catch (cause) {
      throw new InviteRevocationPublishError("membership-free bundle publication", [], { cause });
    }
    requireInviteRevocationAck("membership-free bundle publication", responses);
    this.eventStore.add(signed);
    return { ...invite, revoked: true };
  }

  /** Record a newly minted link into the private Invite List and publish it. */
  async record(invite: ConcordInviteLink | InviteListInvite): Promise<void> {
    this.invites = mergeInvites(this.invites, [toInviteListInvite(invite)]);
    this.markDirty();
    await this.save();
  }

  /** Add the terminal private tombstone for a revoked link and publish it. */
  async tombstone(invite: ConcordInviteLink | InviteListInvite): Promise<void> {
    const entry = toInviteListInvite(invite);
    this.tombstones = mergeTombstones(this.tombstones, [{ token: entry.token, community_id: entry.community_id }]);
    this.markDirty();
    await this.save();
  }

  /** Publishes the Invite List, but only when the plaintext differs from the last list a relay
   *  accepted — the fingerprint check keeps repeated saves from minting pointless replaceable
   *  versions, and a save while the same content is still in flight publishes nothing. The
   *  publish itself is fire-and-forget: a pool error or no accepting relay is reported as
   *  `invite-list-publish`, not thrown, and turns {@link dirty$} back to `true`, so the next
   *  `save()` republishes the same entries and tombstones. Nothing is retried automatically.
   *  Concurrent calls run one after another, and each signed list is dated after the last. */
  save(): Promise<void> {
    const run = this.saveTail.then(() => this.saveStep());
    this.saveTail = run.catch(() => {});
    return run;
  }

  /** One serialized {@link save}: reads the current entries when it runs, not when it was queued. */
  private async saveStep(): Promise<void> {
    if (!this.signer.nip44) return;
    if (!this.pubkey) this.pubkey = await this.signer.getPublicKey();
    const fingerprint = canonicalJson({ entries: this.invites, tombstones: this.tombstones });
    if (fingerprint === this.publishedFingerprint || fingerprint === this.inFlight?.fingerprint) {
      this.dirty$.next(false);
      return;
    }
    // Carrier spread FIRST, `entries`/`tombstones` assigned AFTER — same load-bearing ordering
    // as ConcordClient.saveCommunityList (WIRE-09/D-23): a document carrying a stale `entries`
    // key must never override this manager's own merged state.
    const plaintext = JSON.stringify({ ...this.documentExtras, entries: this.invites, tombstones: this.tombstones });
    assertEnvelopeCap(plaintext);
    const content = await this.signer.nip44.encrypt(this.pubkey, plaintext);
    const previous = this.eventStore.getReplaceable(INVITE_LIST_KIND, this.pubkey);
    const createdAt = Math.max(
      Math.floor(Date.now() / 1000),
      (previous?.created_at ?? 0) + 1,
      this.lastSignedAt + 1,
    );
    const signed = await this.signer.signEvent({ kind: INVITE_LIST_KIND, content, tags: [], created_at: createdAt });
    this.lastSignedAt = Math.max(this.lastSignedAt, signed.created_at);
    setHiddenContentCache(signed, plaintext);
    // Registered before the store add: adding our own list re-runs `reconcile`, which must not
    // take this unacknowledged copy for one a relay holds.
    const attempt = { id: signed.id, fingerprint };
    this.inFlight = attempt;
    this.unacknowledgedId = signed.id;
    this.eventStore.add(signed);
    // D-17: this is D-17's OTHER user-signed publish — not in a loop, so a prompting
    // signer is asked at most once per save.
    let publication: Promise<PublishResponse[]>;
    try {
      publication = this.pool.publish(this.transport(), signed, {
        waitForAuth: [this.pubkey],
        onAuthRequired: this.userOnAuthRequired,
      });
    } catch (error) {
      this.settlePublish(attempt, false);
      throw error;
    }
    let refused = false;
    void reportUnacknowledgedPublish("invite-list-publish", publication, (error) => {
      refused = true;
      // Settle before reporting, so a diagnostic subscriber already sees the list as unpublished.
      this.settlePublish(attempt, false);
      this.backgroundFailures.report({ stage: "invite-list-publish", error });
    }).then(() => {
      if (!refused) this.settlePublish(attempt, true);
    });
    this.dirty$.next(false);
  }

  /** Records a {@link save} publish outcome. An accepted list becomes the published fingerprint; a refused one leaves
   *  the last accepted fingerprint in place and marks the list dirty, so the next save republishes it. An outcome for
   *  a publish a newer save replaced, or that settles after {@link stop}, changes nothing. */
  private settlePublish(attempt: { id: string; fingerprint: string }, accepted: boolean): void {
    if (accepted && this.unacknowledgedId === attempt.id) this.unacknowledgedId = undefined;
    if (this.inFlight !== attempt) return;
    this.inFlight = undefined;
    if (accepted) this.publishedFingerprint = attempt.fingerprint;
    else this.dirty$.next(true);
  }

  /** Merges a decrypted remote list into local state: valid entries merge, invalid ones are
   *  quarantined and reported, and the document's other top-level keys are snapshotted so a
   *  later save round-trips them (WIRE-09/D-23). */
  private reconcile(cast: ConcordInviteList): void {
    const invites = cast.invites;
    if (!invites) return;
    let nextInvites = this.invites;
    invites.forEach((raw, entryIndex) => {
      const result = validateInviteListInvite(raw);
      if (result.ok) {
        nextInvites = mergeInvites(nextInvites, [result.value]);
        return;
      }
      const diagnostic: InviteListDiagnostic = {
        sourceId: cast.id,
        entryIndex,
        status: "quarantined",
        field: result.field,
        reason: result.reason,
      };
      const key = `${diagnostic.sourceId}:${entryIndex}:${diagnostic.field}:${diagnostic.reason}`;
      if (!this.diagnosed.has(key)) {
        this.diagnosed.add(key);
        this.diagnostics.next(diagnostic);
      }
    });
    const nextTombstones = mergeTombstones(this.tombstones, cast.tombstones ?? []);
    // Snapshot the document's top-level keys (WIRE-09/D-23), INCLUDING its own `entries`/
    // `tombstones` as of this read — mirroring ConcordClient.watchLists. `save()` always
    // assigns this manager's own merged state AFTER spreading this snapshot, so a stale
    // `entries`/`tombstones` sitting in it can never win. Read off the cast's own event since
    // ConcordInviteList adds no whole-document accessor. Existing-first-then-new spread order.
    const document = getInviteList(cast.event);
    if (document) this.documentExtras = { ...this.documentExtras, ...document };
    // Our own list that no relay has accepted yet is not proof of what a relay holds: keep the
    // last accepted fingerprint, and once its publish has failed, flag the merged state dirty.
    const unacknowledged = cast.id === this.unacknowledgedId;
    if (!unacknowledged) {
      this.publishedFingerprint = canonicalJson({
        entries: mergeInvites([], invites),
        tombstones: mergeTombstones([], cast.tombstones ?? []),
      });
    }
    this.invites = nextInvites;
    this.tombstones = nextTombstones;
    this.emit();
    if (unacknowledged && this.inFlight?.id !== cast.id) this.dirty$.next(true);
  }

  /** Attempts one unprompted decryption per list event when `autoUnlock` is on. Tried once
   *  per cast id and failures are swallowed, so a signer that refuses is not asked in a loop. */
  private autoUnlockCast(cast: ConcordInviteList): void {
    if (!this.signer.nip44 || this.autoUnlocked.has(cast.id)) return;
    this.autoUnlocked.add(cast.id);
    void cast.unlock(this.signer).catch(() => {});
  }

  /** Re-emits derived state and flags the list as having unpublished local changes. */
  private markDirty(): void {
    this.emit();
    this.dirty$.next(true);
  }

  /** Re-derives the three entry subjects from one merged snapshot, so they can never
   *  disagree about whether a given token is revoked. */
  private emit(): void {
    const entries = this.invites.map((invite) => fromInviteListInvite(invite, this.tombstones));
    this.entries$.next(entries);
    const liveTokens = new Set(liveInviteEntries(this.invites, this.tombstones).map((invite) => invite.token));
    this.live$.next(entries.filter((invite) => liveTokens.has(invite.token)));
    this.revoked$.next(entries.filter((invite) => invite.revoked));
  }
}

function fromInviteListInvite(invite: InviteListInvite, tombstones: InviteListTombstone[] = []): ConcordInviteLink {
  return {
    token: invite.token,
    signerSk: invite.signer_sk,
    signerPubkey: getPublicKey(hexToBytes(invite.signer_sk)),
    communityId: invite.community_id,
    url: invite.url,
    label: invite.label,
    channels: invite.channels,
    createdAt: invite.created_at,
    expiresAt: invite.expires_at,
    revoked: tombstones.some((t) => t.token === invite.token),
  };
}

function toInviteListInvite(invite: ConcordInviteLink | InviteListInvite): InviteListInvite {
  if ("signer_sk" in invite) return invite;
  return {
    token: invite.token,
    signer_sk: invite.signerSk,
    community_id: invite.communityId,
    url: invite.url,
    label: invite.label,
    channels: invite.channels,
    created_at: invite.createdAt,
    expires_at: invite.expiresAt,
  };
}
