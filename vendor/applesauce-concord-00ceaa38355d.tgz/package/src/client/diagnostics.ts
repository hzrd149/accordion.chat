import { type Observable, Subject } from "rxjs";
import type { Debugger } from "applesauce-core";
import type { DutyReport } from "./lifecycle.ts";
import type { PendingRefoundingRefusal } from "./refounding.ts";

/**
 * The stable stage labels a {@link ConcordDiagnostic} can carry, one per background failure site. Stages are stable
 * strings an app can switch on.
 */
export type ConcordDiagnosticStage =
  | "invite-watcher-start"
  | "invite-refresh"
  | "mirror-read"
  | "mirror-write"
  | "community-list-save"
  | "community-list-restore"
  | "fragment-subscription"
  | "fragment-reconcile"
  | "community-list-unlock"
  | "community-list-read"
  | "community-list-write-blocked"
  | "channel-rekey-publish"
  | "invite-bundle-publish"
  | "invite-bundle-refresh-publish"
  | "invite-bundle-refresh-skipped"
  | "channel-grant-publish"
  | "plane-publish"
  | "invite-list-publish"
  | "direct-invite-dismissed-persist"
  | "direct-invite-cursor-persist"
  | "duty-exhausted"
  | "pin-upkeep-skipped"
  | "banlist-reheal"
  | "refounding-discarded"
  | "fragment-restore"
  | "fragment-persist"
  | "fragment-extension-retained"
  | "community-list-repair"
  | "community-list-residue"
  | "expiration-purge"
  | "material-persist";

/** Fields every {@link ConcordDiagnostic} carries. */
export interface ConcordDiagnosticBase {
  /** The originating failure, forwarded as thrown; the library adds no decrypted content, secrets or keys to it. */
  error: unknown;
  /** The community the failure belongs to, when one does. Client-level diagnostics from a community engine carry it. */
  communityId?: string;
  /**
   * A public identifier that narrows the failure, such as a channel id or an invite link signer pubkey. Never an
   * invite token, key or plaintext.
   */
  key?: string;
  /** Which attempt failed, for stages that retry (1-based). */
  attempt?: number;
}

/**
 * A typed background failure reported on `ConcordClient.diagnostics$` and `ConcordCommunity.diagnostics$`, instead of
 * being printed to the console. Discriminated on `stage`.
 *
 * - `plane-publish` also carries `plane`, the plane the fire-and-forget publish targeted.
 * - `plane-publish`, `channel-rekey-publish`, `channel-grant-publish`, `invite-bundle-publish`,
 *   `invite-bundle-refresh-publish` and `invite-list-publish` are reported when the pool throws (`error` is what it threw)
 *   or when no relay accepted the event (`error` is a `RequiredPublishError` holding every relay's response).
 * - `duty-exhausted` also carries `duty`, the name of the background duty that ran out of attempts.
 * - `pin-upkeep-skipped` also carries `reason`; its `key` is the channel id. `rate-limited` means the upkeep was
 *   postponed until the per-channel window frees; `over-cap` and `private-era-list` are terminal for that Pin List head.
 * - `banlist-reheal` carries a `BanlistReHealError` as `error` and the Banlist head hash as `key`. Its `reason` is
 *   `non-convergence` (three heal publications for one ban did not make it stick, so the member was given up on),
 *   `blocked` (the heal would carry a ban this account cannot vouch for, so nothing was published), `rate-limited` (local
 *   Banlist writes kept the rate window full through every allowed deferral, so the member was given up on) or
 *   `unban-not-durable` (an `unban()` could not republish the Banlist, so a restart of this client may re-apply the
 *   ban). A heal publication that runs out of attempts arrives as `duty-exhausted` with `duty` `banlist-reheal`.
 * - `refounding-discarded` is not a failure: `discardPendingRefounding()` removed a stored Refounding that `refound()`
 *   refuses to finish. It carries `reason` (`blocked`, `other-epoch` or `preparation-changed`) and the rotation id as
 *   `key`; its `error` only describes the removal.
 * - `fragment-restore` means a stored fragment or the stored fragment record was dropped while restoring it, or the
 *   record could not be read (it is then kept, and nothing is written over it until a later `start()` reads it).
 * - `fragment-persist` means the fragment record could not be written to storage, or was not written because it could
 *   not be read at start (an error named `FragmentRecordUnreadableError`; that lasts until the next `start()`).
 * - `fragment-extension-retained` carries the fragment index as `key`; list-level fields stay on that fragment because
 *   fragment 0 is not held. It is reported once per fragment until fragment 0 is held.
 * - `community-list-repair` means an interrupted-repack repair attempt failed.
 * - `community-list-residue` means an interrupted repack left duplicate or dormant fragments that wait for the next
 *   save.
 * - `expiration-purge` means a sweep of expired Chat failed for one channel store (its `key` is the channel id) or for the
 *   retained wraps (no `key`); the rest of the sweep still ran.
 * - Every other stage carries only the base fields; `communityId` and `key` are set where they apply.
 */
export type ConcordDiagnostic =
  | (ConcordDiagnosticBase & {
    stage: Exclude<
      ConcordDiagnosticStage,
      "plane-publish" | "duty-exhausted" | "pin-upkeep-skipped" | "refounding-discarded"
    >;
  })
  | (ConcordDiagnosticBase & { stage: "plane-publish"; plane: string })
  | (ConcordDiagnosticBase & { stage: "duty-exhausted"; duty: string })
  | (ConcordDiagnosticBase & {
    stage: "pin-upkeep-skipped";
    reason: "rate-limited" | "over-cap" | "private-era-list";
  })
  | (ConcordDiagnosticBase & { stage: "refounding-discarded"; reason: PendingRefoundingRefusal });

/**
 * A duty failure its owner already reported under its own stage, wrapped so the duty still retries it while
 * {@link DiagnosticsSink.reportDuty} does not report it a second time under the duty's stage. Internal.
 */
export class ReportedDutyFailure extends Error {
  /** Wraps `cause`, the failure as originally reported. */
  constructor(cause: unknown) {
    super((cause as Error)?.message ?? String(cause), { cause });
    this.name = "ReportedDutyFailure";
  }
}

/**
 * Logs a background failure on the engine's debug logger and emits it as a typed {@link ConcordDiagnostic}.
 * Internal: not exported from any barrel.
 */
export class DiagnosticsSink {
  private readonly subject: Subject<ConcordDiagnostic> = new Subject<ConcordDiagnostic>();
  private completed = false;
  /** Every diagnostic reported or forwarded through this sink. Completes with {@link complete}. */
  readonly diagnostics$: Observable<ConcordDiagnostic> = this.subject.asObservable();

  private readonly log: Debugger;
  private readonly forward: ((diagnostic: ConcordDiagnostic) => void) | undefined;
  private readonly defaults: Pick<ConcordDiagnosticBase, "communityId"> | undefined;

  constructor(
    log: Debugger,
    forward?: (diagnostic: ConcordDiagnostic) => void,
    defaults?: Pick<ConcordDiagnosticBase, "communityId">,
  ) {
    this.log = log;
    this.forward = forward;
    this.defaults = defaults;
  }

  /** Merges the defaults under `diagnostic`, writes one log line, then emits and forwards it. */
  report(diagnostic: ConcordDiagnostic): void {
    const error = diagnostic.error;
    this.log("%s failed: %s", diagnostic.stage, (error as Error)?.message ?? error);
    this.emit({ ...this.defaults, ...diagnostic });
  }

  /**
   * Maps a {@link DutyReport} from an owned `DutyScope` to a diagnostic. Exhaustion becomes `duty-exhausted` naming the
   * duty; a failed Community List read becomes `community-list-read`; a {@link ReportedDutyFailure} (already reported
   * under its own stage) and any other failed attempt are one log line only.
   */
  reportDuty(report: DutyReport): void {
    const { stage, key, attempt } = report;
    const reported = report.error instanceof ReportedDutyFailure;
    const error = reported ? (report.error as ReportedDutyFailure).cause : report.error;
    if (report.kind === "exhausted") this.report({ stage: "duty-exhausted", duty: stage, key, attempt, error });
    else if (stage === "community-list-read" && !reported) this.report({ stage, key, attempt, error });
    else this.log("%s attempt %d failed: %s", stage, attempt, (error as Error)?.message ?? error);
  }

  /** Emits and forwards `diagnostic` without logging, for diagnostics another sink has already logged. */
  emit(diagnostic: ConcordDiagnostic): void {
    if (!this.completed) this.subject.next(diagnostic);
    try {
      this.forward?.(diagnostic);
    } catch {
      // A consumer callback must never break a library failure path.
    }
  }

  /** Completes {@link diagnostics$}; later reports are logged and forwarded but no longer emitted. */
  complete(): void {
    if (this.completed) return;
    this.completed = true;
    this.subject.complete();
  }
}
