// CORD-02 §8 (D-01, D-02): durable storage of authenticated Community List fragment winners. Internal: never re-exported from a barrel.
import type { NostrEvent } from "applesauce-core/helpers/event";
import { communityListFragmentIndex } from "./community-list-fragments.ts";
import { systemClock } from "./lifecycle.ts";
import type { ConcordStorage } from "./storage.ts";

/** Version of the stored fragment record; a record of another version is dropped whole. */
export const COMMUNITY_LIST_FRAGMENT_RECORD_VERSION: number = 1;

/**
 * Longest a save waits for the storage write that covers it. A write still unsettled by then fails the wait like a
 * storage error, so a store that never answers cannot hold Community List work until `stop()` (IN-02).
 */
export const COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS: number = 10_000;

/** Most events {@link CommunityListFragmentStore.load} returns from one record; the rest are counted as dropped. */
export const COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS: number = 4_096;

/** The storage key of one user's fragment record. It falls under the documented `concord:` logout cleanup. */
export function communityListFragmentsKey(pubkey: string): string {
  return `concord:list-fragments:${pubkey}`;
}

/** What the sync hands the store: every authenticated winner as received, and the advisory governing count. */
export interface CommunityListFragmentSnapshot {
  /** Signed kind-33302 events exactly as received, locked and dormant indexes included. */
  readonly events: readonly NostrEvent[];
  /** The governing fragment count once a fragment is decrypted. Advisory only: no write ever takes its count from it. */
  readonly count?: number;
}

/** The fragment record could not be written to storage; `cause` is the storage error. Never carries event content. */
export class FragmentPersistError extends Error {
  /** Wraps the storage failure. */
  constructor(cause: unknown) {
    super("Community List fragments could not be stored", { cause });
    this.name = "FragmentPersistError";
  }
}

/**
 * Every save is refused because reading the stored record failed: nothing is written over a record that may hold copies
 * no relay has (WR-02). It lasts until a later {@link CommunityListFragmentStore.load} reads the record, which is the
 * next `start()`, so a retry in the same lifecycle cannot succeed and none is made (IN-01).
 */
export class FragmentRecordUnreadableError extends FragmentPersistError {
  /** Names the unreadable record; there is no storage error to wrap. */
  constructor() {
    super(new Error("the stored record could not be read, so it is not replaced until the next start()"));
    this.name = "FragmentRecordUnreadableError";
  }
}

/** One caller waiting for the write that covers its snapshot. */
interface Waiter {
  resolve: () => void;
  reject: (error: unknown) => void;
}

/** One write of a record text and everyone waiting on it. */
interface Job {
  text: string;
  waiters: Waiter[];
}

/** Per-user writer state: a single-flight writer with one pending slot. */
interface Slot {
  /** The last record text loaded or successfully written. */
  stored?: string;
  /** The advisory count last loaded or submitted; carried into a snapshot that has none. */
  count?: number;
  /** The write in flight. */
  current?: Job;
  /** The newest snapshot waiting behind it; older waiting snapshots are superseded by it. */
  next?: Job;
  /** Whether a failure was reported since the last success. */
  failing: boolean;
  /** Set when a wait outlasted the bound; cleared once the write in flight settles. Later waits fail at once. */
  stalled?: boolean;
  /**
   * Set when reading the record failed (not when it was invalid): the stored record may hold copies no relay has, so
   * nothing is written over it until a later {@link CommunityListFragmentStore.load} reads it (WR-02).
   */
  unreadable?: boolean;
}

/**
 * Persists one versioned record of signed ciphertext events and the advisory count per user (CORD-02 §8, D-01, D-02).
 * Nothing decrypted ever reaches storage. Loading never verifies signatures: the sync re-verifies every event it
 * restores, so there is a single verification path.
 */
export class CommunityListFragmentStore {
  private readonly slots = new Map<string, Slot>();
  private readonly report: ((error: FragmentPersistError) => void) | undefined;
  private readonly schedule: (ms: number, run: () => void) => () => void;
  /** Waits not settled yet; each owns one bound timer, cancelled when it settles or on {@link release}. */
  private readonly waiting = new Set<Waiter>();

  /**
   * Use the client's storage; `report` receives the first write failure of each failing streak, a wait that outlasted
   * {@link COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS} included. `schedule` runs the bound (the client's duty clock).
   */
  constructor(
    private readonly storage: ConcordStorage,
    options: {
      report?: (error: FragmentPersistError) => void;
      schedule?: (ms: number, run: () => void) => () => void;
    } = {},
  ) {
    this.report = options.report;
    this.schedule = options.schedule ?? ((ms, run) => systemClock.schedule(ms, run));
  }

  /**
   * Read the stored record. A missing record is empty. A record that is unparsable, of another version, of another
   * user or malformed throws, so the caller drops it whole with one diagnostic, and the next {@link save} replaces it
   * (D-03). When the storage read itself fails, it throws too, but the record is kept: every {@link save} for that user
   * is refused until a later `load` reads the record (WR-02). Entries that are not objects, and entries beyond
   * {@link COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS}, are counted in `dropped`.
   */
  async load(pubkey: string): Promise<{ events: NostrEvent[]; count?: number; dropped: number }> {
    const slot = this.slot(pubkey);
    let raw: string | null;
    try {
      raw = await this.storage.getItem(communityListFragmentsKey(pubkey));
    } catch (cause) {
      slot.unreadable = true;
      throw new Error("the stored Community List fragment record could not be read; it is kept", { cause });
    }
    slot.unreadable = false;
    if (raw === null) return { events: [], dropped: 0 };
    const stored = parseRecord(raw, pubkey);
    if (!slot.current && !slot.next) {
      slot.stored = raw;
      slot.count = stored.count;
    }
    const events: NostrEvent[] = [];
    let dropped = 0;
    for (const entry of stored.fragments) {
      if (events.length < COMMUNITY_LIST_FRAGMENT_RECORD_MAX_EVENTS && isPlainObject(entry)) {
        events.push(entry as unknown as NostrEvent);
      } else dropped++;
    }
    return stored.count === undefined ? { events, dropped } : { events, count: stored.count, dropped };
  }

  /**
   * Store `snapshot` as the user's record. An unchanged snapshot costs no write. Writes are single-flight: while one is
   * in flight, newer snapshots replace each other in one pending slot, so a burst costs at most two writes and an older
   * snapshot never lands after a newer one. Every caller settles with the write that covers its snapshot; a storage
   * failure rejects them with {@link FragmentPersistError}. While the user's record could not be read, nothing is
   * written and every save rejects with {@link FragmentRecordUnreadableError}, so a storage hiccup never replaces the
   * only durable copy with what the relays served (WR-02). A wait that outlasts
   * {@link COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS} rejects with {@link FragmentPersistError}, and until that write
   * settles every later wait does so at once; the queued writes still land in order when storage answers (IN-02).
   */
  save(pubkey: string, snapshot: CommunityListFragmentSnapshot): Promise<void> {
    const slot = this.slot(pubkey);
    if (slot.unreadable) {
      const error = new FragmentRecordUnreadableError();
      this.fail(slot, error);
      return Promise.reject(error);
    }
    if (snapshot.count !== undefined) slot.count = snapshot.count;
    const text = serialize(pubkey, snapshot.events, slot.count);
    return new Promise<void>((resolve, reject) => {
      if (!slot.current) {
        if (slot.stored === text) return resolve();
        slot.current = { text, waiters: [] };
        this.wait(slot, slot.current, resolve, reject);
        void this.drain(pubkey, slot);
        return;
      }
      let job: Job;
      if (slot.next?.text === text) job = slot.next;
      else if (!slot.next && slot.current.text === text) job = slot.current;
      else job = slot.next = { text, waiters: slot.next?.waiters ?? [] };
      this.wait(slot, job, resolve, reject);
    });
  }

  /**
   * Reject every wait still pending, without reporting a storage failure: the client stopped, so no Community List work
   * stays parked on storage past its lifecycle (IN-02). The writes themselves still land.
   */
  release(): void {
    const error = new FragmentPersistError(new Error("the client stopped before the record was stored"));
    for (const waiter of [...this.waiting]) waiter.reject(error);
  }

  /** Settle with `job`, or fail once the bound passes or {@link release} runs, whichever comes first. */
  private wait(slot: Slot, job: Job, resolve: () => void, reject: (error: unknown) => void): void {
    if (slot.stalled) {
      // The write in flight already outlasted the bound: this snapshot is queued behind it, so do not wait again.
      reject(new FragmentPersistError(new Error("an earlier write of the record has not settled")));
      return;
    }
    let cancel = (): void => {};
    const settle = () => {
      cancel();
      this.waiting.delete(waiter);
    };
    const waiter: Waiter = {
      resolve: () => (settle(), resolve()),
      reject: (error) => (settle(), reject(error)),
    };
    this.waiting.add(waiter);
    job.waiters.push(waiter);
    cancel = this.schedule(COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS, () => {
      const error = new FragmentPersistError(
        new Error(`storage did not finish writing the record within ${COMMUNITY_LIST_FRAGMENT_PERSIST_TIMEOUT_MS} ms`),
      );
      slot.stalled = true;
      this.fail(slot, error);
      waiter.reject(error);
    });
  }

  private slot(pubkey: string): Slot {
    let slot = this.slots.get(pubkey);
    if (!slot) {
      slot = { failing: false };
      this.slots.set(pubkey, slot);
    }
    return slot;
  }

  private async drain(pubkey: string, slot: Slot): Promise<void> {
    while (slot.current) {
      const job = slot.current;
      try {
        await this.storage.setItem(communityListFragmentsKey(pubkey), job.text);
        slot.stalled = false;
        slot.stored = job.text;
        slot.failing = false;
        for (const waiter of job.waiters) waiter.resolve();
      } catch (cause) {
        slot.stalled = false;
        const error = new FragmentPersistError(cause);
        this.fail(slot, error);
        for (const waiter of job.waiters) waiter.reject(error);
      }
      slot.current = slot.next;
      slot.next = undefined;
    }
  }

  /** Report the first failure of a failing streak. */
  private fail(slot: Slot, error: FragmentPersistError): void {
    if (slot.failing) return;
    slot.failing = true;
    try {
      this.report?.(error);
    } catch {
      // A consumer callback must never break a storage failure path.
    }
  }
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function parseRecord(raw: string, pubkey: string): { fragments: unknown[]; count?: number } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error("invalid Community List fragment record");
  }
  if (
    !isPlainObject(parsed) || parsed.version !== COMMUNITY_LIST_FRAGMENT_RECORD_VERSION || parsed.pubkey !== pubkey ||
    !Array.isArray(parsed.fragments)
  ) throw new Error("invalid Community List fragment record");
  const { count } = parsed;
  if (count === undefined) return { fragments: parsed.fragments };
  if (typeof count !== "number" || !Number.isSafeInteger(count) || count < 1) {
    throw new Error("invalid Community List fragment record");
  }
  return { fragments: parsed.fragments, count };
}

/** Index order for a stable record; an event without a canonical `d` sorts last, then by id. */
function order(a: NostrEvent, b: NostrEvent): number {
  const index = (event: NostrEvent) =>
    communityListFragmentIndex(event.tags?.find((tag) => tag[0] === "d")?.[1]) ?? Number.POSITIVE_INFINITY;
  const left = index(a), right = index(b);
  if (left !== right) return left < right ? -1 : 1;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

function serialize(pubkey: string, events: readonly NostrEvent[], count: number | undefined): string {
  return JSON.stringify({
    version: COMMUNITY_LIST_FRAGMENT_RECORD_VERSION,
    pubkey,
    ...(count === undefined ? {} : { count }),
    fragments: [...events].sort(order),
  });
}
