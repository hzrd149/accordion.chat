// The per-community Banlist facade (CORD-04 §§4, 6). It builds the BanlistWriter and the BanlistReHealer from the admin
// object and a handful of closures so community.ts only wires them, and it counts the Refoundings this client has in
// flight so a heal never races one. Internal: not exported from any barrel.

import type { ISigner } from "applesauce-signers";
import { BehaviorSubject, distinctUntilChanged, map, type Observable } from "rxjs";

import { assertBaseRotationSupported } from "../helpers/keys.ts";
import type { CommunityState, ConcordSyncPhase, DecodedEvent, JoinMaterial } from "../types.ts";
import type { ConcordCommunityAdmin } from "./admin.ts";
import { BanlistReHealer } from "./banlist-reheal.ts";
import { BanlistWriter, type BanMembersOptions, type BanMembersResult } from "./banlist.ts";
import type { ConcordDiagnostic } from "./diagnostics.ts";
import type { DutyScope } from "./lifecycle.ts";
import type { PendingRefoundingRecord, PendingRefoundingRefusal, RefoundingResult } from "./refounding.ts";

/** What the facade reads from its community. Every closure reads the community at call time. */
export interface CommunityBanlistHost {
  /** The logged-in user's pubkey. */
  self: string;
  /** The community's current folded state. */
  state(): CommunityState;
  /** The community's duty scope, whose clock the rate window is measured on (it can be swapped in tests). */
  duties(): DutyScope;
  /** The retained Control history. */
  retained(): Iterable<DecodedEvent>;
  /** The admin surface the writer publishes and strips roles through. */
  admin: Pick<ConcordCommunityAdmin, "latestEdition" | "publishEdition" | "grantRoles">;
  /** The community signer, checked for NIP-44 before a Refounding is attempted. */
  signer: ISigner;
  /** The community's current material. */
  material(): JoinMaterial;
  /** Throws when the community is disposed or dissolved. */
  assertActive(): void;
  /** The stored, unfinished Refounding record, or null when there is none. */
  loadPendingRefounding(): Promise<PendingRefoundingRecord | null>;
  /** Why `refound()` refuses to finish a stored record now, or undefined when it would resume it. */
  refoundRefusal(stored: PendingRefoundingRecord): PendingRefoundingRefusal | undefined;
  /** Run a Refounding that keeps `keep` and excludes `exclude`. */
  refound(options: { keep: string[]; exclude: string[] }): Promise<RefoundingResult>;
  /** Typed background diagnostics sink. */
  diagnostics: { report(diagnostic: ConcordDiagnostic): void };
  /** Folded state changes. */
  state$: Observable<CommunityState>;
  /** The community sync phase. */
  phase(): ConcordSyncPhase;
  /** Sync phase changes. */
  phase$: Observable<ConcordSyncPhase>;
  /** The current root epoch; a change means a Refounding was adopted. */
  epoch(): number;
  /** Whether the local user may publish a Banlist edition now: not disposed or sealed, can sign Control, holds BAN. */
  canWrite(): boolean;
  /** Whether a retained record sits at the current epoch's Control address. */
  current(record: DecodedEvent): boolean;
}

/** The Banlist writer wired to one community. */
export class CommunityBanlist {
  /** The serial, rate-limited writer; also holds the session intent ledger. */
  readonly writer: BanlistWriter;
  private readonly inFlight: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private readonly reHealer: BanlistReHealer;

  /** @param host The community the writer works through. */
  constructor(host: CommunityBanlistHost) {
    this.writer = new BanlistWriter({
      self: host.self,
      state: () => host.state(),
      epoch: () => host.epoch(),
      now: () => host.duties().clock.now(),
      retained: () => host.retained(),
      current: (record) => host.current(record),
      diagnostics: host.diagnostics,
      latestEdition: (eid) => host.admin.latestEdition(eid),
      publishEdition: (vsk, eid, content, required, guard) =>
        host.admin.publishEdition(vsk, eid, content, required, guard),
      stripRoles: (member) => host.admin.grantRoles(member, []),
      assertRefoundReady: () => {
        host.assertActive();
        assertBaseRotationSupported(host.material());
        if (!host.signer.nip44) throw new Error("this signer can't rotate keys (NIP-44 unsupported)");
      },
      pendingRefoundRecipients: async () => {
        const stored = await host.loadPendingRefounding();
        if (!stored) return undefined;
        // CORD-06 §3: refound() refuses a blocked record, one from another epoch and one whose preparation changed.
        if (host.refoundRefusal(stored)) return "blocked";
        return stored.preparation?.recipients.map((recipient) => recipient.pubkey.toLowerCase()) ?? "unknown";
      },
      refound: (options) => host.refound(options),
    });
    this.reHealer = new BanlistReHealer({
      duties: () => host.duties(),
      diagnostics: host.diagnostics,
      self: host.self,
      state: () => host.state(),
      state$: host.state$,
      phase: () => host.phase(),
      phase$: host.phase$,
      epoch: () => host.epoch(),
      canWrite: () => host.canWrite(),
      refounding: () => this.inFlight.value > 0,
      refounding$: this.inFlight.pipe(map((count) => count > 0), distinctUntilChanged()),
      retained: () => host.retained(),
      current: (record) => host.current(record),
      writer: this.writer,
    });
  }

  /** Count `operation` as an in-flight Refounding until it settles, so no heal runs meanwhile. Returns `operation`. */
  track<T>(operation: Promise<T>): Promise<T> {
    this.inFlight.next(this.inFlight.value + 1);
    const done = () => this.inFlight.next(Math.max(0, this.inFlight.value - 1));
    operation.then(done, done);
    return operation;
  }

  /** Stop the re-healer. */
  dispose(): void {
    this.reHealer.dispose();
  }

  /** Ban several members in one Banlist edition. */
  banMembers(members: string[], options?: BanMembersOptions): Promise<BanMembersResult> {
    return this.writer.banMembers(members, options);
  }

  /** Ban one member. */
  ban(member: string): Promise<void> {
    return this.writer.ban(member);
  }

  /** Lift a ban. */
  unban(member: string): Promise<void> {
    return this.writer.unban(member);
  }
}
