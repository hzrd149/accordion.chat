// Internal: one full author-batch sync with its loader-boundary counts (CORD-06 sync, D-05 litmus). Shared by the
// community walk (`sync.ts`) and the private-channel walk (`channel-sync.ts`); not exported from any barrel, so the
// public `syncAuthors` keeps its signature.
import type { EventStore } from "applesauce-core";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { createSyncLoader } from "applesauce-loaders/loaders";
import { filter, firstValueFrom, forkJoin, Observable, takeUntil, toArray } from "rxjs";

import { BACKFILL_KINDS } from "../helpers/gift-wrap.ts";
import type { PlaneInfo } from "../helpers/keys.ts";
import { addWrap, createReceiveDecoder, verifyReceiveEnvelope } from "./receive.ts";
import type { SyncContext } from "./sync.ts";

/** What one author batch synced: the accepted wraps and the arrivals refused at the loader boundary. */
export interface SyncBatch {
  events: NostrEvent[];
  dropped: number;
  skipped: number;
}

/**
 * `syncAuthors` with its counts: keeps rejected-arrival diagnostics without retaining rejected wire objects. Drops are
 * logged with the plane's own epoch (a rekey address derives at the next epoch), falling back to the walk's `epoch`,
 * the same rule live receive uses, so a wrap dropped live and during sync reports the same `epoch=`.
 */
export async function syncAuthorBatch(
  ctx: SyncContext,
  authors: string[],
  planes?: ReadonlyMap<string, PlaneInfo>,
  epoch?: number,
): Promise<SyncBatch> {
  const batch: SyncBatch = { events: [], dropped: 0, skipped: 0 };
  if (authors.length === 0 || ctx.alive?.() === false) return batch;
  const requested = new Set(authors);
  const decode = createReceiveDecoder();
  const accepts = (event: NostrEvent): boolean => {
    if (ctx.alive?.() === false) return false;
    if (!BACKFILL_KINDS.includes(event.kind) || !requested.has(event.pubkey)) {
      return false;
    }
    if (!planes) return verifyReceiveEnvelope(event);
    const info = planes.get(event.pubkey);
    return info !== undefined && decode(event, info) !== null;
  };
  // The installed loader funnels both NIP-77 and paginated REQ through
  // mapEventsToStore.add BEFORE emission. Forward to the same canonical store;
  // no alternate store, verification cache or downstream-only retention guard.
  const guarded:
    & Parameters<typeof createSyncLoader>[0]["eventStore"]
    & Pick<EventStore, "getByFilters" | "getTimeline" | "getEvent" | "hasEvent"> = {
      add: (event) => {
        if (accepts(event)) {
          const canonical = addWrap(ctx.eventStore, event, planes?.get(event.pubkey));
          if (canonical && accepts(canonical)) return canonical;
        }
        // Refused here or by the store, such as a non-channel wrap under a past outer tag: counted, never retained.
        const info = planes?.get(event?.pubkey);
        if (info) {
          batch.dropped++;
          const knownEpoch = info.epoch ?? epoch;
          const id = typeof event.id === "string" ? event.id.slice(0, 8) : "invalid";
          if (knownEpoch !== undefined) {
            ctx.decodeLogger("dropped wrap=%s plane=%s epoch=%d", id, info.type, knownEpoch);
          } else ctx.decodeLogger("dropped wrap=%s plane=%s", id, info.type);
        } else batch.skipped++;
        return null;
      },
      update: (event) => {
        if (accepts(event)) ctx.eventStore.update(event);
      },
      remove: (event) => ctx.eventStore.remove(event),
      getByFilters: (filters) => ctx.eventStore.getByFilters(filters),
      getTimeline: (filters) => ctx.eventStore.getTimeline(filters),
      getEvent: (id) => ctx.eventStore.getEvent(id),
      hasEvent: (id) => ctx.eventStore.hasEvent(id),
    };
  const loader = createSyncLoader({ eventStore: guarded, pool: ctx.pool });
  const { events$, status$ } = loader({
    relays: ctx.relays,
    filter: { kinds: BACKFILL_KINDS, authors },
    waitForAuth: authors.filter((pk) => ctx.signers.get(pk) !== undefined),
    onAuthRequired: ctx.onAuthRequired,
  });
  // Completion means all relays settled, including failures. Observe status in
  // the same shared run so an unavailable history cannot masquerade as an empty one.
  const cancelled$ = new Observable<void>((subscriber) => {
    if (ctx.alive?.() === false) {
      subscriber.next();
      return;
    }
    if (ctx.onCancel) return ctx.onCancel(() => subscriber.next());
    if (!ctx.alive) return;
    const timer = setInterval(() => {
      if (ctx.alive?.() === false) subscriber.next();
    }, 50);
    return () => clearInterval(timer);
  });
  const result = await firstValueFrom(
    forkJoin({ events: events$.pipe(filter(accepts), toArray()), status: status$ }).pipe(takeUntil(cancelled$)),
    { defaultValue: undefined },
  );
  if (!result || ctx.alive?.() === false) return batch;
  const outcomes = Object.values(result.status.relays);
  if (outcomes.length > 0 && !outcomes.some((relay) => relay.state === "complete")) {
    throw new AggregateError(
      outcomes.map((relay) => relay.error ?? new Error(`Sync relay ${relay.relay} was ${relay.state}`)),
      "History synchronization failed: no relay completed",
    );
  }
  for (const relay of outcomes) {
    if (relay.state === "error" || relay.state === "skipped") {
      ctx.logger("history relay=%s state=%s", relay.relay, relay.state);
    }
  }
  // Negentropy transfers only missing wraps. Rebuild folds from the verified
  // local history too, including wraps retained during an earlier failed run.
  const events = new Map(result.events.map((event) => [event.id, event]));
  for (const event of ctx.eventStore.getByFilters({ kinds: BACKFILL_KINDS, authors })) {
    if (!events.has(event.id) && accepts(event)) events.set(event.id, event);
  }
  batch.events = [...events.values()];
  return batch;
}
