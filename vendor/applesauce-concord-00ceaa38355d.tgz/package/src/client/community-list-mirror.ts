// CORD-02 §8: the local plaintext membership mirror, keyed by the raw user pubkey. Internal: never re-exported from a barrel.

import type { CommunityListCommunity, CommunityTombstone } from "../types.ts";
import type { ParsedCommunityList } from "../helpers/community-list.ts";
import { parseCommunityListMirror } from "./community-list-document.ts";
import type { ConcordStorage } from "./storage.ts";

/**
 * Read the local mirror. It holds the same `{entries, tombstones}` shape the relay copy does, so local and remote state
 * combine through the identical CORD-02 §8 primitives — a mirror can contribute an unpublished join but can never
 * clobber a tombstone another device wrote. The result carries the mirror's whole document snapshot (D-25's
 * lower-priority in-phase item): a client that has not fetched the relay copy this session and publishes from
 * mirror-only state would otherwise drop a key it read in a previous session. Callers spread it existing-first-then-new
 * (the same order as `watchLists`), and a stale `entries`/`tombstones` sitting in this snapshot can never win at the
 * write sites. The legacy (bare-array) branch of `parseCommunityListMirror` carries no extra top-level keys at all.
 *
 * Resolves `undefined` for a missing or empty value; throws on a parse or storage failure.
 */
export async function readMirrorDocument(
  storage: ConcordStorage,
  pubkey: string,
): Promise<ParsedCommunityList | undefined> {
  const raw = await storage.getItem(pubkey);
  if (!raw) return undefined;
  return parseCommunityListMirror(raw);
}

/**
 * Write the local mirror, which is what makes `start()` instant and offline-safe. Keyed as `entries` to match the wire
 * document (armada-compatible), so the mirror and the 13302 plaintext stay parseable by the same helper. The carrier
 * `extras` are spread FIRST and `entries`/`tombstones` assigned AFTER — the same load-bearing ordering as
 * `saveCommunityList` (WIRE-09/D-23). Throws on a storage failure.
 */
export async function writeMirrorDocument(
  storage: ConcordStorage,
  pubkey: string,
  extras: Record<string, unknown>,
  entries: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
): Promise<void> {
  await storage.setItem(pubkey, JSON.stringify({ ...extras, entries, tombstones }));
}
