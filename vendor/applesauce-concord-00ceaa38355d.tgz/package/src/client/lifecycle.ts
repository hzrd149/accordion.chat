// Duty ownership (Phase 1, D-01..D-06). One owner per client or community holds every
// library-owned timer, retry and re-heal loop together with its per-key budget, so
// disposal, stop and dissolution have exactly one place to cancel from. Nothing here is
// exported from a public barrel (D-02). A duty is identified by a stable key that must be
// a public identifier (channel id, head hash, community id) and never a token, key or
// plaintext: keys and stage labels are all that diagnostics reports carry.
//
// A duty runs at most once per stable key, one attempt at a time, within bounded
// attempts and lifetime (the RotationCoordinator budget). It reads current state when it
// fires and is handed `assertAlive` to pass as the publish path's `assertCurrent` check,
// so a signer or storage completion that arrives after disposal, suspension, supersession
// or lost eligibility cannot publish or overwrite newer state.

import { timer } from "rxjs";

/** Time source for duties: delay, jitter, retry backoff and lifetime all go through it (D-05). */
export interface DutyClock {
  /** Current time in milliseconds. */
  now(): number;
  /** A value in [0, 1) used to spread jitter. */
  random(): number;
  /** Schedule `run` after `delayMs`; returns a cancel function. */
  schedule(delayMs: number, run: () => void): () => void;
}

/** The production clock: `Date.now`, `Math.random` and an rxjs `timer` (the only timer created here). */
export const systemClock: DutyClock = {
  now: () => Date.now(),
  random: () => Math.random(),
  schedule(delayMs: number, run: () => void): () => void {
    const subscription = timer(Math.max(0, delayMs)).subscribe(() => run());
    return () => subscription.unsubscribe();
  },
};

/** Thrown by {@link DutyContext.assertAlive} once a duty attempt is no longer current. */
export class DutyCancelledError extends Error {
  constructor(message = "duty cancelled") {
    super(message);
    this.name = "DutyCancelledError";
  }
}

/** What a running duty attempt sees. */
export interface DutyContext {
  /** The duty's stable key. */
  readonly key: string;
  /** 1-based attempt number. */
  readonly attempt: number;
  /** False after dispose, suspension, supersession, cancellation or lost eligibility. */
  alive(): boolean;
  /** Throws {@link DutyCancelledError} when not alive; pass as the publish path's `assertCurrent` (D-06). */
  assertAlive(): void;
}

/** One duty request. */
export interface DutyOptions {
  /** Stable identity, e.g. `${channelId}:${headHash}`. */
  key: string;
  /** Defaults to `key`; a new key in the same slot supersedes the old one. */
  slot?: string;
  /** Diagnostics stage label. */
  stage: string;
  /** Default true; false marks a local cleanup duty that is still admitted after {@link DutyScope.suspend}. */
  publishes?: boolean;
  /** Default `() => true`; evaluated at fire time and inside `alive()`. A throwing predicate counts as false. */
  eligible?: () => boolean;
  /** The work. A rejection or throw is a failed attempt. */
  run: (context: DutyContext) => void | Promise<void>;
  /** Delay before the first attempt. Default 0. */
  delayMs?: number;
  /** Extra delay of up to `jitterMs * clock.random()`. Default 0. */
  jitterMs?: number;
  /** Base retry delay, doubled per failed attempt. Default 1_000. */
  retryDelayMs?: number;
  /** Attempt budget. Default 3 (as RotationCoordinator). */
  maxAttempts?: number;
  /** Lifetime budget from the first request. Default 8_000 (as RotationCoordinator). */
  lifetimeMs?: number;
}

/** A failed attempt, or the one-time notice that a key's budget is spent. */
export type DutyReport =
  | { kind: "failed"; stage: string; key: string; attempt: number; error: unknown }
  | { kind: "exhausted"; stage: string; key: string; attempt: number; error: unknown };

/** What {@link DutyScope.request} did with a request. */
export type DutyRequestResult = "armed" | "coalesced" | "quiet" | "refused";

/** Construction options for {@link DutyScope}. */
export interface DutyScopeOptions {
  /** Time source; defaults to {@link systemClock}. */
  clock?: DutyClock;
  /** Receives failures and exhaustion. A throwing reporter never breaks the scope. */
  report?: (report: DutyReport) => void;
  /** How many settled keys are remembered. Default 256; the oldest is forgotten first. */
  maxSettledKeys?: number;
}

interface Entry {
  readonly options: DutyOptions;
  readonly slot: string;
  attempts: number;
  readonly firstRequestedAt: number;
  cancelTimer: (() => void) | undefined;
  running: boolean;
  generation: number;
}

const DEFAULT_MAX_SETTLED_KEYS = 256;

/** Owns every duty timer and per-key budget for one client or community. */
export class DutyScope {
  /** The time source duties are scheduled on. */
  readonly clock: DutyClock;
  private readonly reporter: ((report: DutyReport) => void) | undefined;
  private readonly maxSettledKeys: number;
  private readonly entries = new Map<string, Entry>();
  private readonly slots = new Map<string, string>();
  private readonly settled = new Set<string>();
  private readonly running = new Set<Promise<void>>();
  private isDisposed = false;
  private suspended: string | undefined;

  constructor(options: DutyScopeOptions = {}) {
    this.clock = options.clock ?? systemClock;
    this.reporter = options.report;
    this.maxSettledKeys = options.maxSettledKeys ?? DEFAULT_MAX_SETTLED_KEYS;
  }

  /** True once {@link DutyScope.dispose} ran; terminal. */
  get disposed(): boolean {
    return this.isDisposed;
  }

  /** Why publication duties are refused, or undefined while the scope is not suspended. */
  get suspendedReason(): string | undefined {
    return this.suspended;
  }

  /** Armed timers plus running attempts. */
  get pending(): number {
    let armed = 0;
    for (const entry of this.entries.values()) if (entry.cancelTimer) armed++;
    return armed + this.running.size;
  }

  /** True while the duty currently occupying `slot` has an armed timer or a running attempt. */
  slotPending(slot: string): boolean {
    const key = this.slots.get(slot);
    const entry = key === undefined ? undefined : this.entries.get(key);
    return entry !== undefined && (entry.cancelTimer !== undefined || entry.running);
  }

  /** Ask for a duty to run. Repeated requests for one key coalesce; a settled key stays quiet. */
  request(options: DutyOptions): DutyRequestResult {
    if (this.isDisposed) return "refused";
    if (this.suspended !== undefined && options.publishes !== false) return "refused";
    if (this.settled.has(options.key)) return "quiet";
    if (this.entries.has(options.key)) return "coalesced";
    const slot = options.slot ?? options.key;
    const occupant = this.slots.get(slot);
    if (occupant !== undefined) {
      const prior = this.entries.get(occupant);
      if (prior) this.invalidate(prior);
    }
    const entry: Entry = {
      options,
      slot,
      attempts: 0,
      firstRequestedAt: this.clock.now(),
      cancelTimer: undefined,
      running: false,
      generation: 0,
    };
    this.entries.set(options.key, entry);
    this.slots.set(slot, options.key);
    this.arm(entry, (options.delayMs ?? 0) + this.jitter(options));
    return "armed";
  }

  /** Cancel armed (not running) duties whose eligibility was lost. They are not settled and may be re-requested. */
  reevaluate(): void {
    for (const entry of [...this.entries.values()]) {
      if (!entry.running && entry.cancelTimer && !this.eligibleNow(entry)) this.invalidate(entry);
    }
  }

  /** Cancel every duty and forget all budgets while keeping the scope usable (client stop). */
  cancelAll(_reason: string): void {
    for (const entry of [...this.entries.values()]) this.invalidate(entry);
    this.settled.clear();
  }

  /** Refuse and cancel publication duties from now on (dissolution); local cleanup duties still run. */
  suspend(reason: string): void {
    this.suspended ??= reason;
    for (const entry of [...this.entries.values()]) {
      if (entry.options.publishes !== false) this.invalidate(entry);
    }
  }

  /** Cancel everything and refuse all further requests. Idempotent and terminal. */
  dispose(): void {
    if (this.isDisposed) return;
    this.isDisposed = true;
    for (const entry of [...this.entries.values()]) this.invalidate(entry);
    this.settled.clear();
  }

  /** Resolves once no attempt is running. */
  async idle(): Promise<void> {
    while (this.running.size > 0) await Promise.allSettled([...this.running]);
  }

  private jitter(options: DutyOptions): number {
    return Math.floor((options.jitterMs ?? 0) * this.clock.random());
  }

  private arm(entry: Entry, delayMs: number): void {
    entry.cancelTimer = this.clock.schedule(delayMs, () => this.fire(entry));
  }

  private eligibleNow(entry: Entry): boolean {
    try {
      return entry.options.eligible?.() ?? true;
    } catch {
      return false;
    }
  }

  private isAlive(entry: Entry, generation: number): boolean {
    if (this.isDisposed || entry.generation !== generation) return false;
    if (this.suspended !== undefined && entry.options.publishes !== false) return false;
    return this.eligibleNow(entry);
  }

  /** Cancels an entry's timer, makes any running attempt see it is not alive, and forgets it unsettled. */
  private invalidate(entry: Entry): void {
    entry.generation++;
    entry.cancelTimer?.();
    entry.cancelTimer = undefined;
    this.forget(entry);
  }

  private forget(entry: Entry): void {
    const { key } = entry.options;
    if (this.entries.get(key) === entry) this.entries.delete(key);
    if (this.slots.get(entry.slot) === key) this.slots.delete(entry.slot);
  }

  private settle(key: string): void {
    this.settled.delete(key);
    this.settled.add(key);
    while (this.settled.size > this.maxSettledKeys) {
      const oldest = this.settled.values().next().value;
      if (oldest === undefined) break;
      this.settled.delete(oldest);
    }
  }

  private report(report: DutyReport): void {
    try {
      this.reporter?.(report);
    } catch {
      // A throwing reporter must never break the scope.
    }
  }

  private fire(entry: Entry): void {
    entry.cancelTimer = undefined;
    const generation = entry.generation;
    if (this.entries.get(entry.options.key) !== entry) return;
    if (!this.isAlive(entry, generation)) return this.forget(entry);
    entry.attempts++;
    entry.running = true;
    const attempt = entry.attempts;
    const { key, stage } = entry.options;
    const context: DutyContext = {
      key,
      attempt,
      alive: () => this.isAlive(entry, generation),
      assertAlive: () => {
        if (!this.isAlive(entry, generation)) throw new DutyCancelledError(`duty ${stage} ${key} is no longer current`);
      },
    };
    let outcome: Promise<void>;
    try {
      outcome = Promise.resolve(entry.options.run(context));
    } catch (error) {
      outcome = Promise.reject(error);
    }
    const tracked: Promise<void> = outcome
      .then(
        () => this.succeeded(entry, generation),
        (error) => this.failed(entry, generation, context, error),
      )
      .finally(() => void this.running.delete(tracked));
    this.running.add(tracked);
  }

  private succeeded(entry: Entry, generation: number): void {
    entry.running = false;
    if (entry.generation !== generation) return;
    this.forget(entry);
    this.settle(entry.options.key);
  }

  private failed(entry: Entry, generation: number, context: DutyContext, error: unknown): void {
    entry.running = false;
    if (entry.generation !== generation) return;
    if (error instanceof DutyCancelledError || !context.alive()) return this.forget(entry);
    const { key, stage } = entry.options;
    const attempt = entry.attempts;
    this.report({ kind: "failed", stage, key, attempt, error });
    const maxAttempts = entry.options.maxAttempts ?? 3;
    const lifetimeMs = entry.options.lifetimeMs ?? 8_000;
    if (attempt >= maxAttempts || this.clock.now() - entry.firstRequestedAt >= lifetimeMs) {
      this.report({ kind: "exhausted", stage, key, attempt, error });
      this.forget(entry);
      this.settle(key);
      return;
    }
    const backoff = (entry.options.retryDelayMs ?? 1_000) * 2 ** (attempt - 1);
    this.arm(entry, backoff + this.jitter(entry.options));
  }
}
