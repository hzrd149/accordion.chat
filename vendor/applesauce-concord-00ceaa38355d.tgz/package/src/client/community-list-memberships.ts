// CORD-02 §8 (D-13): the current aggregate Community List read surface.

import { combineLatest, map, Observable, startWith } from "rxjs";
import type { CommunityListCommunity, CommunityTombstone } from "../types.ts";
import { liveCommunities } from "../helpers/community-list.ts";
import type { CommunityListKnowledge, ConcordCommunityListStatus } from "./community-list-sync.ts";

/** The user's Community List as one value: what to read instead of combining the legacy list cast, the status stream
 *  and the fragment state. Read it from `ConcordClient.memberships$` or `ConcordClient.memberships()`. */
export interface ConcordMemberships {
  /** The live memberships, deduped. Each entry carries the community's key material, like the local mirror. */
  readonly entries: CommunityListCommunity[];
  /** The permanent leave records: a community listed here never comes back as a live membership. */
  readonly tombstones: CommunityTombstone[];
  /** How much of the relay copy backs this document: nothing yet, a confirmed empty list, some of it or all of it. */
  readonly knowledge: CommunityListKnowledge;
  /**
   * True while a held fragment is undecrypted. Until it is unlocked it blocks repacks and repairs, and any write that
   * targets it or whose newest declaration is locked; other scoped writes still run.
   */
  readonly locked: boolean;
  /** True while a save was refused and waits for a completed read of the relay copy. */
  readonly pending: boolean;
}

/**
 * Build the current value from the client's document and the sync's state. Entries and tombstones are deep copies, so
 * the caller can never change the client's list through them.
 */
export function membershipsSnapshot(
  list: CommunityListCommunity[],
  tombstones: CommunityTombstone[],
  sync: { readonly status: ConcordCommunityListStatus; readonly locked: boolean },
): ConcordMemberships {
  return {
    entries: structuredClone(liveCommunities(list, tombstones)),
    tombstones: structuredClone(tombstones),
    knowledge: sync.status.knowledge,
    locked: sync.locked,
    pending: sync.status.pending,
  };
}

/**
 * The value stream: it emits immediately (so it is safe before `start()`), then again whenever the document changes
 * (`changed$`), the status changes or the lock state changes. `read` supplies the value for each emission. It completes
 * once `changed$` completes (the client's `dispose()`); a subscription made after that receives the current value, then
 * completes.
 */
export function membershipsStream(
  changed$: Observable<unknown>,
  sync: {
    readonly status$: Observable<ConcordCommunityListStatus>;
    readonly locked$: Observable<boolean>;
  },
  read: () => ConcordMemberships,
): Observable<ConcordMemberships> {
  const values$ = combineLatest([changed$.pipe(startWith(undefined)), sync.status$, sync.locked$]).pipe(
    map(() => read()),
  );
  return new Observable<ConcordMemberships>((subscriber) => {
    // The values first, so a subscription after `changed$` completed still gets the current value before completing.
    const subscription = values$.subscribe(subscriber);
    subscription.add(changed$.subscribe({ complete: () => subscriber.complete() }));
    return subscription;
  });
}
