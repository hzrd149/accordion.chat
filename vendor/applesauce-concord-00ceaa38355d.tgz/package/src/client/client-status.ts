// The client's aggregate status fold, moved out of the ConcordClient constructor so client.ts stays within its size
// ceiling. Internal: not exported from any barrel.
import { combineLatest, distinctUntilChanged, map, type Observable, of, shareReplay, switchMap } from "rxjs";

import type { ConcordClientStatus, ConcordCommunityStatus } from "../types.ts";

/**
 * Fold every community's `status$` into a single client snapshot.
 *
 * @param phase$ The client lifecycle phase.
 * @param communities$ Emits when the community set changes; its values are ignored.
 * @param engines The current communities by id, read each time the set changes.
 */
export function clientStatus$(
  phase$: Observable<ConcordClientStatus["phase"]>,
  communities$: Observable<unknown>,
  engines: () => ReadonlyMap<string, { status$: Observable<ConcordCommunityStatus> }>,
): Observable<ConcordClientStatus> {
  // Aggregate status: fold every community's status$ into a single client snapshot.
  // Rebuild the fan-in only when the membership set changes (not on every state fold),
  // so a phase/connection change on a child propagates through the inner combineLatest.
  const childStatuses$ = communities$.pipe(
    map(() => [...engines().keys()].sort().join(",")),
    distinctUntilChanged(),
    switchMap(() => {
      const current = [...engines().values()];
      if (current.length === 0) return of([] as ConcordCommunityStatus[]);
      return combineLatest(current.map((c) => c.status$));
    }),
  );
  return combineLatest({ phase: phase$, children: childStatuses$ }).pipe(
    map(({ phase, children }): ConcordClientStatus => {
      const live = children.filter((s) => s.phase === "live").length;
      const connectedChildren = children.filter((s) => s.connected);
      return {
        phase,
        communities: children.length,
        syncing: children.length - live,
        live,
        connected: connectedChildren.length > 0,
      };
    }),
    distinctUntilChanged(
      (a, b) =>
        a.phase === b.phase &&
        a.communities === b.communities &&
        a.syncing === b.syncing &&
        a.live === b.live &&
        a.connected === b.connected,
    ),
    shareReplay(1),
  );
}
