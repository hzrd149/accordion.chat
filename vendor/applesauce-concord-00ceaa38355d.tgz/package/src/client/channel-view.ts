// CORD-03 §2 channel views for `channels$`. `view` is presentation only (D-05): an unknown wire value is shown as
// "chat" while the raw value stays in the folded channel, so every library write preserves it. The comparator
// (D-06) is by canonical content so a rename, view change or key grant re-emits and an unrelated fold does not.

import { canonicalJson } from "../helpers/community-list.ts";
import { channelViewMode } from "../helpers/forum.ts";
import type { ChannelMetadata, ChannelViewMode } from "../types.ts";

/** A folded channel plus the client-local `accessible` affordance (CHAN-06) and its presentation `view`.
 *  `accessible` is `true` for every public channel, and for a private channel iff `material.channels` currently holds
 *  a key for it. `view` is `"forum"` only for the exact folded value `"forum"` and `"chat"` otherwise (CORD-03 §2);
 *  the raw value stays in `state$.value.channels`. Neither is folded state: both ride only this emitted view, never
 *  {@link ChannelMetadata} or the control-plane fold. */
export type ChannelView = ChannelMetadata & { accessible: boolean; view: ChannelViewMode };

/** Map folded channels to emitted views, adding `accessible` and the presented `view`. */
export function channelViews(
  channels: readonly ChannelMetadata[],
  accessible: (channel: ChannelMetadata) => boolean,
): ChannelView[] {
  return channels.map((channel): ChannelView => ({
    ...channel,
    accessible: accessible(channel),
    view: channelViewMode(channel),
  }));
}

/** Content equality for `channels$`'s emitted `ChannelView[]` — a fresh array is mapped on every emission, so
 *  reference equality would never suppress a no-op re-emission. Compares each pair by canonical JSON, so a change to
 *  the name, privacy, custom data, view, accessibility or any preserved extra field re-emits. */
export function sameChannelViews(a: ChannelView[], b: ChannelView[]): boolean {
  if (a === b) return true;
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (canonicalJson(a[i]) !== canonicalJson(b[i])) return false;
  }
  return true;
}
