// The channel send methods of ONE community (CORD-03 §3): chat messages and titled forum posts, thread replies,
// reactions, edits and deletion requests. Moved out of community.ts to keep that module within its line budget; this
// module is internal and not exported from any barrel (only `ConcordSendMessageOptions` is public, re-exported by
// community.ts). It owns no engine state: the host closures read the community's keys, uploader and publish path at
// call time, so key rotation and test patches of `publishToPlane` apply to every send.

import { ChatMessageFactory, CommentFactory, ReactionFactory } from "applesauce-common/factories";
import { DeleteFactory, type Emoji } from "applesauce-core/factories";
import type { EventTemplate } from "applesauce-core/helpers/event";
import { ensureKTag } from "applesauce-core/helpers/factory";

import { assertSubject } from "../helpers/caps.ts";
import type { AttachmentEncryption, MediaAttachment } from "../helpers/imeta.ts";
import { EditFactory } from "../factories/edit.ts";
import { bindToChannel, includeMediaEncryption, includeSubject, type MediaEncryption } from "../operations/channel.ts";
import type { Rumor } from "../types.ts";
import type { ConcordRumorStore, ConcordUploader, ConcordUploadProgress } from "./storage.ts";

/** Options for {@link ConcordCommunity.sendMessage}. */
export interface ConcordSendMessageOptions {
  /** Reports attachment progress across the whole send, so a composer can show one
   *  aggregate indicator rather than guessing which file is in flight. */
  onUploadProgress?: (progress: ConcordUploadProgress) => void;
  /** Title of a forum post: the message carries one `subject` tag (CORD-03 §3). A blank or whitespace-only
   *  title publishes no tag; a longer title than 256 UTF-8 bytes rejects with a `RangeError` before anything is
   *  uploaded or signed. A non-blank title is published verbatim, never trimmed. */
  subject?: string;
}

/** An unsigned channel rumor ready to seal and wrap. */
type ChannelRumor = { kind: number; content: string; tags: string[][]; created_at?: number };

/** The parent a chat message replies to. */
type ReplyParent = { id: string; author: string };

/** What {@link CommunityMessaging} needs from its community; closures keep it free of engine state. */
export interface CommunityMessagingHost {
  /** The community id, passed to the uploader. */
  communityId(): string;
  /** The configured media uploader, when there is one. */
  uploader(): ConcordUploader | undefined;
  /** Throw `MissingChannelKeyError` for a known private channel whose key is not held. */
  requireChannelKey(channelId: string): void;
  /** Resolve the channel's wrapping key so an unknown channel fails before any upload. */
  assertChannel(channelId: string): void;
  /** The epoch a channel's outgoing messages bind to. */
  channelEpoch(channelId: string): number;
  /** The channel's raw rumor store, used to look up the kind of an edit target given by id. */
  channelStore(channelId: string): ConcordRumorStore;
  /** Seal, wrap and publish a bound rumor on the channel plane. */
  publish(channelId: string, rumor: ChannelRumor): Promise<string>;
}

/** Split `sendMessage`'s overloaded third argument into the reply parent and the options, refusing ambiguous calls. */
function sendMessageArguments(
  third: unknown,
  files: Blob[] | undefined,
  emojis: Emoji[] | undefined,
  positionalOptions: ConcordSendMessageOptions | undefined,
): { replyTo: ReplyParent | undefined; options: ConcordSendMessageOptions } {
  if (third === undefined || third === null) return { replyTo: undefined, options: positionalOptions ?? {} };
  if (typeof third !== "object") {
    throw new TypeError("sendMessage: the third argument must be a reply parent or options");
  }
  const fields = third as Record<string, unknown>;
  if (typeof fields.id === "string" && typeof fields.author === "string") {
    if ("subject" in fields) {
      throw new TypeError("sendMessage: pass subject in the options argument, not on the reply parent");
    }
    return { replyTo: { id: fields.id, author: fields.author }, options: positionalOptions ?? {} };
  }
  if ("id" in fields || "author" in fields) {
    throw new TypeError("sendMessage: a reply parent needs a string id and a string author");
  }
  if (files !== undefined || emojis !== undefined || positionalOptions !== undefined) {
    throw new TypeError(
      "sendMessage: an options object as the third argument takes no positional files, emojis or options",
    );
  }
  return { replyTo: undefined, options: third as ConcordSendMessageOptions };
}

/** The channel send methods of one community, delegated to by `ConcordCommunity`. */
export class CommunityMessaging {
  constructor(private readonly host: CommunityMessagingHost) {}

  /** Bind a built draft to its channel and publish it. */
  private async publishBound(channelId: string, build: () => PromiseLike<EventTemplate>): Promise<void> {
    this.host.requireChannelKey(channelId);
    const epoch = this.host.channelEpoch(channelId);
    await this.host.publish(channelId, await bindToChannel(channelId, epoch)(await build()));
  }

  /** Send a chat message, optionally titled, with attachments, a reply parent and custom emoji. Files are
   *  encrypted and uploaded before the message is published, so the rumor never references a blob that is not
   *  yet retrievable. The third argument is the reply parent when it has a string `id` and `author` (then `options`
   *  is the sixth argument) and the options object when it has neither key. Ambiguous calls reject with a
   *  `TypeError` before anything is uploaded: a third argument with only one of `id`/`author` or a non-string one, a
   *  reply parent carrying `subject`, or an options object combined with positional `files`, `emojis` or options. */
  async sendMessage(
    channelId: string,
    text: string,
    third?: ReplyParent | ConcordSendMessageOptions | null,
    files?: Blob[],
    emojis?: Emoji[],
    positionalOptions?: ConcordSendMessageOptions,
  ): Promise<void> {
    const { replyTo, options } = sendMessageArguments(third, files, emojis, positionalOptions);
    // Cap the title before the channel key, any upload or any signing (CORD-03 §3); a blank title adds no tag.
    const subject = typeof options.subject === "string" && options.subject.trim() !== "" ? options.subject : undefined;
    if (subject !== undefined) assertSubject(subject);

    this.host.requireChannelKey(channelId);
    this.host.assertChannel(channelId);
    const epoch = this.host.channelEpoch(channelId);
    let content = text;
    let attachments: MediaAttachment[] | undefined;
    if (files?.length) {
      const uploader = this.host.uploader();
      if (!uploader) throw new Error("no uploader configured: cannot send file attachments");
      attachments = [];
      for (let i = 0; i < files.length; i++) {
        let phase: ConcordUploadProgress["phase"] = "encrypting";
        const emit = (next: ConcordUploadProgress["phase"]) => {
          phase = next;
          options.onUploadProgress?.({ total: files.length, done: i, phase });
        };
        emit("encrypting");
        const attachment = await uploader.upload(files[i], this.host.communityId(), { onProgress: emit });
        if (!attachment.url) throw new Error("uploader did not return a url");
        attachments.push(attachment);
        options.onUploadProgress?.({ total: files.length, done: i + 1, phase });
        content = content ? `${content}\n${attachment.url}` : attachment.url;
      }
    }

    let factory = ChatMessageFactory.create(content, { emojis });
    if (replyTo) factory = factory.replyTo({ id: replyTo.id, author: replyTo.author });
    if (attachments?.length) factory = factory.attachments(attachments);
    const encryption: MediaEncryption[] = (attachments ?? [])
      .filter(
        (a): a is MediaAttachment & { url: string; encryption: AttachmentEncryption } => !!a.url && !!a.encryption,
      )
      .map((a) => ({ url: a.url, ...a.encryption }));

    let rumor: EventTemplate = await factory;
    if (subject !== undefined) rumor = await includeSubject(subject)(rumor);
    rumor = await bindToChannel(channelId, epoch)(rumor);
    rumor = await includeMediaEncryption(encryption)(rumor);
    await this.host.publish(channelId, rumor);
  }

  /**
   * Post a forum thread to a channel.
   *
   * @deprecated Use `sendMessage(channelId, body, { subject: title })`. This publishes a titled kind 9 post
   * (CORD-03 §3), never a kind 11; kind 11 roots already retained stay readable and are never rewritten.
   */
  sendThread(channelId: string, title: string, body = ""): Promise<void> {
    return this.sendMessage(channelId, body, { subject: title });
  }

  /** Reply to a channel thread with a NIP-22 kind 1111 comment. */
  replyToThread(channelId: string, parent: Rumor, body: string): Promise<void> {
    return this.publishBound(channelId, () => CommentFactory.create(parent, body));
  }

  /** React to a message with an emoji or a custom emoji reference. */
  react(channelId: string, target: Rumor, reaction: string | Emoji): Promise<void> {
    return this.publishBound(channelId, () => ReactionFactory.create(target, reaction));
  }

  /** Publish a replacement body for one of our own messages. `target` is the message rumor or its id. The edit's
   *  `k` tag names the target's kind (9, 1111, or 11 for a legacy root) when known: the rumor's own kind, or for a
   *  bare id the kind of the retained message in the channel store (no `k` when it is not retained). Receivers never
   *  require `k`. Readers apply the edit; the original rumor remains on relays. */
  editMessage(channelId: string, target: string | Pick<Rumor, "id" | "kind">, text: string): Promise<void> {
    return this.publishBound(channelId, async () => {
      const id = typeof target === "string" ? target : target.id;
      const kind = typeof target === "string"
        ? (await this.host.channelStore(channelId).getEvent(target))?.kind
        : target.kind;
      return EditFactory.create(id, text, kind);
    });
  }

  /** Request deletion of a message. A request, not an erasure — relays and peers that
   *  already hold the rumor decide whether to honour it. */
  deleteMessage(channelId: string, target: Rumor): Promise<void> {
    return this.publishBound(channelId, async () => {
      // A Concord Rumor never carries a `sig`, so `setDeleteEvents`' `isEvent(event)`
      // branch never fires for it and no "k" tag would be emitted. Pass only the id
      // (the bare-string branch) and apply `ensureKTag` explicitly with the target's
      // real kind on the awaited template before binding it to the channel.
      const template = await DeleteFactory.fromEvents([target.id]);
      return { ...template, tags: ensureKTag(template.tags, target.kind) };
    });
  }
}
