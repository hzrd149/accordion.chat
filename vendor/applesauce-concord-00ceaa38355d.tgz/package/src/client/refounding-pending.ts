// CORD-06 §3: a stored, unfinished Refounding resumes its own signed request, and `refound()` refuses it once it can no
// longer be finished. These checks are shared by `refound()`, `discardPendingRefounding()` and
// `banMembers({ refound: true })`, so all three agree on which stored records `refound()` refuses. Internal: not
// exported from any barrel.

import { isCurrentStaff } from "../helpers/permissions.ts";
import type { CommunityState, JoinMaterial } from "../types.ts";
import type { ConcordDiagnostic } from "./diagnostics.ts";
import type { PendingRefoundingRecord, PendingRefoundingRefusal } from "./refounding.ts";
import type { PendingRefoundingStore } from "./storage.ts";

/** A Refounding request: who keeps the new root, who is excluded, and which private channels are rotated for whom. */
export interface RefoundingRequest {
  /** Members who receive the new root. */
  keep: string[];
  /** Members who are excluded from it. */
  exclude?: string[];
  /** Private channels rotated alongside, each delivered to its own keep set. */
  channelRekeys?: Array<{ channelId: string; keep: string[] }>;
}

/** What a Refounding preparation is bound to, read from the community at call time. */
export interface PreparationView {
  /** The community's current material. */
  material: JoinMaterial;
  /** The rotating account. */
  actor: string;
  /** The community's current folded state. */
  state: CommunityState;
  /** The serialized original seals of every Control head; throws when one is unavailable. */
  originals(): string[];
}

/** The request a stored Refounding resumes instead of the caller's, or undefined when it does not record one. */
export function resumedRequest(stored: PendingRefoundingRecord): RefoundingRequest | undefined {
  if (!stored.preparation) return undefined;
  // CORD-06 §3: retries resume signed work, never caller replacement options.
  const saved = JSON.parse(stored.preparation.request) as {
    recipients: string[];
    excluded: string[];
    channels: Array<[string, string[]]>;
  };
  // The fingerprint lists recipients in the original call order, which `preparation.recipients` keeps and the sorted
  // request does not. Fall back to the request when the two do not name the same members.
  const ordered = stored.preparation.recipients.map((recipient) => recipient.pubkey);
  const same = JSON.stringify([...ordered].sort()) === JSON.stringify([...saved.recipients].sort());
  return {
    keep: same ? ordered : saved.recipients,
    exclude: saved.excluded,
    channelRekeys: saved.channels.map(([channelId, keep]) => ({ channelId, keep })),
  };
}

/** The recipients of the new root for `request`: the actor first, then every kept member once, minus the excluded. */
export function refoundingRecipients(actor: string, request: RefoundingRequest): string[] {
  const excluded = new Set(request.exclude ?? []);
  return [...new Set([actor, ...request.keep])].filter((pubkey) => !excluded.has(pubkey));
}

/**
 * The preparation fingerprint `refound()` stores with a record and compares on resume: the material, actor, roles,
 * grants, bans, channels, verified heads and original seals, and each recipient's staff standing.
 */
export function preparationFingerprint(view: PreparationView, recipients: readonly string[]): string {
  const { state } = view;
  const verification = state.controlVerification;
  return JSON.stringify({
    material: view.material,
    actor: view.actor,
    roles: [...state.roles].sort((a, b) => a.role_id.localeCompare(b.role_id)),
    grants: [...state.grants].sort(),
    bans: [...state.banlist].sort(),
    channels: state.channels,
    heads: verification
      ? [...verification.heads].map((
        [eid, h],
      ) => [eid, h.vsk, h.version, h.hash, h.edition.author, h.edition.rumor.id]).sort()
      : [],
    suspended: verification ? [...verification.suspended].sort() : [],
    support: verification
      ? [...verification.grantHistory].map((
        [eid, history],
      ) => [eid, history.map((h) => [h.version, h.hash]).sort()]).sort()
      : [],
    recipients: recipients.map((pubkey) => [pubkey, isCurrentStaff(state, pubkey)]),
    originals: view.originals(),
  });
}

/** Whether `stored` lost an equal-epoch race to a lower root, so `refound()` recovers it instead (CORD-06 §3). */
export function isLosingRefounding(stored: PendingRefoundingRecord, material: JoinMaterial): boolean {
  return material.root_epoch === stored.plan.newEpoch &&
    material.community_root < stored.plan.next.material.community_root;
}

/**
 * Why `refound()` refuses to finish `stored` at `material` (CORD-06 §3), or undefined when it would resume or recover
 * it. `fingerprint` is read only for a record prepared at the current epoch; undefined means it cannot be computed now,
 * which is not a refusal of the record.
 */
export function pendingRefoundingRefusal(
  stored: PendingRefoundingRecord,
  material: JoinMaterial,
  fingerprint: () => string | undefined,
): PendingRefoundingRefusal | undefined {
  if (isLosingRefounding(stored, material)) return undefined;
  if (stored.blocked) return "blocked";
  if (stored.preparation && stored.priorEpoch === material.root_epoch) {
    const current = fingerprint();
    if (current !== undefined && stored.preparation.fingerprint !== current) return "preparation-changed";
  }
  if (stored.priorEpoch !== material.root_epoch && stored.plan.next.material.root_epoch !== material.root_epoch) {
    return "other-epoch";
  }
  return undefined;
}

/** Why `refound()` refuses the stored record against the community `view`, computing the fingerprint of its request. */
export function storedRefoundingRefusal(
  stored: PendingRefoundingRecord,
  view: PreparationView,
): PendingRefoundingRefusal | undefined {
  return pendingRefoundingRefusal(stored, view.material, () => {
    const request = resumedRequest(stored);
    if (!request) return undefined;
    try {
      return preparationFingerprint(view, refoundingRecipients(view.actor, request));
    } catch {
      // A Control head whose original seal is not held yet is a sync gap, not a refusal of the record.
      return undefined;
    }
  });
}

/** What {@link discardRefusedRefounding} reads from its community. */
export interface DiscardRefoundingHost {
  /** The community's stored-Refounding slot. */
  store: Pick<PendingRefoundingStore, "load" | "remove">;
  /** The community as a preparation is bound to it, read after the record loads. */
  view(): PreparationView;
  /** Typed diagnostics sink. */
  diagnostics: { report(diagnostic: ConcordDiagnostic): void };
}

/**
 * Remove the stored Refounding when `refound()` refuses to finish it and report the removal on `diagnostics$` (stage
 * `refounding-discarded`). Resolves whether a record was removed; a record `refound()` can still finish is kept.
 */
export async function discardRefusedRefounding(host: DiscardRefoundingHost): Promise<boolean> {
  const stored = await host.store.load();
  if (!stored) return false;
  const reason = storedRefoundingRefusal(stored, host.view());
  if (!reason) return false;
  await host.store.remove();
  host.diagnostics.report({
    stage: "refounding-discarded",
    reason,
    key: stored.rotationId,
    error: new Error(`discarded a stored Refounding that refound() refuses (${reason})`),
  });
  return true;
}
