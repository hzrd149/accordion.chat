import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { EDIT_KIND } from "../../helpers/edit.ts";
import { bindToChannel } from "../../operations/channel.ts";
import { checkChatBinding } from "../../helpers/chat.ts";
import { EditFactory } from "../edit.ts";

describe("EditFactory", () => {
  it("targets a message with new content", async () => {
    const edit = await EditFactory.create("target", "new text");
    expect(edit.kind).toBe(EDIT_KIND);
    expect(edit.content).toBe("new text");
    expect(edit.tags).toContainEqual(["e", "target"]);
  });

  it("binds to a channel via bindToChannel", async () => {
    const edit = await bindToChannel("chan", 1)(await EditFactory.create("target", "new text"));
    expect(checkChatBinding(edit.tags, "chan", 1)).toBe(true);
  });

  it("EditFactory.create carries the target kind as a k tag when given (D-07)", async () => {
    const typed = await EditFactory.create("target", "t", 1111);
    expect(typed.tags).toContainEqual(["e", "target"]);
    expect(typed.tags.filter((tag) => tag[0] === "k")).toEqual([["k", "1111"]]);

    const untyped = await EditFactory.create("target", "t");
    expect(untyped.tags.some((tag) => tag[0] === "k")).toBe(false);
  });
});
