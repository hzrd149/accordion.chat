// Concord protocol types.

import type { Rumor } from "applesauce-common/helpers";
import type { NostrEvent } from "applesauce-core/helpers/event";

//
// Concord-specific protocol kinds live next to their domain helpers (e.g.
// GIFT_WRAP_KIND in helpers/gift-wrap.ts, CONTROL_KIND in helpers/control.ts),
// so each kind ships alongside the code that folds it. Standard Nostr content
// kinds that ride a channel (chat message 9, reaction 7, deletion 5, forum
// thread 11, NIP-22 comment 1111, …) are referenced from their canonical source
// (applesauce-core `kinds` / applesauce-common `COMMENT_KIND`).

/**
 * The Control Plane's entity sub-kind tags. Every control edition is the same
 * kind, so `vsk` is what says which entity an edition versions, and the fold
 * keys newest-wins per entity on it (CORD-04). Frozen wire values: the gaps are
 * reserved upstream, so never renumber these to close them.
 */
export const VSK = {
  METADATA: 0,
  ROLE: 1,
  CHANNEL: 2,
  GRANT: 3,
  BANLIST: 4,
  INVITE_REGISTRY: 8,
  DISSOLVED: 10,
  PINS: 11,
} as const;

/**
 * The CORD-04 §3 permission bits, as a bitmask over `bigint`. A role's
 * `permissions` string is the decimal encoding of an OR of these, and
 * {@link https://jsr.io/@applesauce/concord/doc/helpers | `hasPerm`} tests one.
 *
 * `bigint` rather than `number` because the mask is specified as a 64-bit field
 * and JavaScript numbers lose integer precision past 2^53. Frozen wire values:
 * bit 7 is deliberately skipped, matching the spec's reserved slot.
 */
export const PERM: {
  /** Create, edit, delete and reorder roles, and grant them to members. */
  readonly MANAGE_ROLES: bigint;
  /** Create, edit and delete channels, including their private/public setting. */
  readonly MANAGE_CHANNELS: bigint;
  /** Edit the community's name, description, icon, banner and relay list. */
  readonly MANAGE_METADATA: bigint;
  /** Remove a member from the community; they may rejoin with a fresh invite. */
  readonly KICK: bigint;
  /** Add a member to the banlist, which bars them from rejoining. */
  readonly BAN: bigint;
  /** Delete other members' messages on the Chat Plane. */
  readonly MANAGE_MESSAGES: bigint;
  /** Mint invite links for the community. */
  readonly CREATE_INVITE: bigint;
  /** Read the audit log of authority actions. */
  readonly VIEW_AUDIT_LOG: bigint;
  /** Use the `@everyone`/`@here` mentions that notify the whole community. */
  readonly MENTION_EVERYONE: bigint;
  /** Curate Control Plane pin lists (CORD-04 §3). */
  readonly PIN_MESSAGES: bigint;
} = {
  MANAGE_ROLES: 1n << 0n,
  MANAGE_CHANNELS: 1n << 1n,
  MANAGE_METADATA: 1n << 2n,
  KICK: 1n << 3n,
  BAN: 1n << 4n,
  MANAGE_MESSAGES: 1n << 5n,
  CREATE_INVITE: 1n << 6n,
  VIEW_AUDIT_LOG: 1n << 8n,
  MENTION_EVERYONE: 1n << 9n,
  PIN_MESSAGES: 1n << 11n,
} as const;

/** The name of a single {@link PERM} bit. */
export type PermName = keyof typeof PERM;

/**
 * The union of all management bits — a conventional "admin" role.
 *
 * It deliberately omits {@link PERM.PIN_MESSAGES} (PIN-11):
 * - CORD-04 §3: a Role granted everything today does not inherit a permission added later, so adding the bit to this
 *   exported constant would silently give editorial power to every role already built from it.
 * - `PIN_MESSAGES` is one of the six staff bits, so its holders receive the control root.
 * - A pin makes a message permanently attributable to future members.
 *
 * Grant pin authority explicitly with `ADMIN_PERMS | PERM.PIN_MESSAGES` or a dedicated curator role. The owner can
 * always pin, and automatic pin upkeep needs at least one online holder of the bit.
 */
export const ADMIN_PERMS: bigint = PERM.MANAGE_ROLES |
  PERM.MANAGE_CHANNELS |
  PERM.MANAGE_METADATA |
  PERM.KICK |
  PERM.BAN |
  PERM.MANAGE_MESSAGES |
  PERM.CREATE_INVITE |
  PERM.VIEW_AUDIT_LOG |
  PERM.MENTION_EVERYONE;

// Re-exported from applesauce-core so concord shares the single canonical
// rumor type instead of defining its own.
export type { Rumor };

/** An unsigned rumor template — the functional event before it is sealed/wrapped. */
export interface RumorTemplate {
  /** The Concord plane kind this rumor belongs to. */
  kind: number;
  /** The rumor body — JSON for structured planes, plaintext for chat. */
  content: string;
  /** The rumor's tags, including the plane's binding and ordering tags. */
  tags: string[][];
  /** Unix seconds; the factories leave it unset and the envelope stamps it. */
  created_at?: number;
}

/** A decoded plane event: the rumor plus its verified real author. */
export interface DecodedEvent {
  /** The innermost unsigned event, as recovered from the seal. */
  rumor: Rumor;
  /** The seal author's pubkey — the cryptographically proven writer, not the stream key. */
  author: string;
  /** The outer wrap's event id, used to dedupe a rumor delivered by several relays. */
  wrapId: string;
  /** Which seal carried this rumor: a plaintext seal survives a re-wrap, an encrypted one does not. */
  sealKind: number;
  /** millisecond-resolution ordering time (CORD-02 §4) */
  ms: number;
  /** The verified seal event — retained for CORD-06 compaction (re-wrapping a
   *  plaintext control seal into a new epoch). Absent on cache-rehydrated events. */
  seal?: NostrEvent;
}

/** An encrypted media reference: where the blob lives plus the key to read it. */
export interface BlobPointer {
  /** The server URL the encrypted blob is fetched from. */
  url: string;
  /** Hex symmetric key that decrypts the fetched blob. */
  key: string;
  /** Hex nonce for the decryption. */
  nonce: string;
  /** Hex hash of the blob, so a swapped or corrupted download is detected. */
  hash: string;
}
/** The community's own profile — the vsk 0 control entity (CORD-02 §6). */
export interface CommunityMetadata {
  /** Durable Chat lifetime in seconds; absent, zero or malformed means off (CORD-08 §1). */
  message_expiration?: number;
  /** Display name; byte-capped by CORD-02 §6. */
  name: string;
  /** Long-form description; byte-capped by CORD-02 §6. */
  description?: string;
  /** The community's relays — where every plane's stream is published and read. */
  relays: string[];
  /** Blossom media servers the community prefers for its encrypted images. */
  blossom_servers?: string[];
  /** The community icon, as an encrypted blob. */
  icon?: BlobPointer;
  /** The community banner, as an encrypted blob. */
  banner?: BlobPointer;
  /** Client-defined extensions. CORD-02 §6 reserves every top-level field outside
   *  `custom` for the protocol, so anything non-standard belongs in here. */
  custom?: Record<string, unknown>;
}

/** Where a role's permissions apply: the whole community, or one channel. */
export interface RoleScope {
  /** `"server"` for community-wide, `"channel"` to confine the grant to one channel. */
  kind: "server" | "channel";
  /** The channel the role is confined to; required when `kind` is `"channel"`. */
  channel_id?: string;
}
/** A named bundle of permissions at a given rank — the vsk 1 control entity. */
export interface Role {
  /** Stable identifier; the entity key this role's editions fold on. */
  role_id: string;
  /** Display name; byte-capped like the community name. */
  name: string;
  /** Rank. Authority checks compare positions, so this decides who may act on whom. */
  position: number;
  /** This role's permission bitmask — an OR of {@link PERM} bits, decimal-encoded. */
  permissions: string; // decimal string
  /** Whether the permissions apply community-wide or in a single channel. */
  scope: RoleScope;
  /** Display colour, as a packed RGB integer. */
  color: number;
  /** A deleted role stays in the fold (so it remains visible in state and
   *  compactable) but confers no permissions or rank — see {@link resolveStanding}. */
  deleted?: boolean;
}

/**
 * How a channel is presented (CORD-03 §2): `"chat"` is the default when the `view` field is absent, `"forum"` is the
 * titled-post layout. A client MUST present any other wire value as `"chat"` rather than reject the edition, while the
 * raw value stays verbatim in the folded {@link ChannelMetadata} so every write keeps it.
 */
export type ChannelViewMode = "chat" | "forum";

/**
 * Open channel metadata preserves unknown protocol fields (CORD-02 §6).
 * {@link CommunityMetadata} stays closed for patch typo checking; its fold
 * already preserves unknown runtime fields without an index signature.
 */
export interface ChannelMetadata {
  /** Stable identifier; the entity key this channel's editions fold on. */
  channel_id: string;
  /** Display name; byte-capped like the community name. */
  name: string;
  /** Whether the channel has its own derived key, so only key-holders can read it. */
  private: boolean;
  /** Marks a deletion edition. The fold drops deleted channels from {@link CommunityState.channels}; the
   *  tombstone edition itself stays selected in the control plane so the deletion replicates. */
  deleted?: boolean;
  /** Client-defined extensions, mirroring {@link CommunityMetadata.custom}. */
  custom?: Record<string, unknown>;
  /** Round-trip escape hatch for future protocol fields — see this interface's own doc (D-13). */
  [k: string]: unknown;
}

/** One member's role assignments — the vsk 3 control entity. */
export interface Grant {
  /** The member's pubkey. */
  member: string;
  /** Every role granted to them; their rank is the highest of these. */
  role_ids: string[];
  /** Epoch-bound staff root delivery: granter↔member NIP-44 ciphertext (CORD-04 §3; CORD-02 §5). */
  control_wrap?: string;
}

/**
 * Retained key entry shared by channel history and held roots, with one
 * validation rule table. `refounder` attributes the root epoch's creator;
 * channel history does not populate it.
 */
export interface HeldKeyEntry {
  /** The epoch this retained key decrypts. */
  epoch: number;
  /** The retained key, hex-encoded. */
  key: string;
  /** The npub whose Refounding minted this epoch; only ever set on `held_roots`. */
  refounder?: string;
}

/**
 * A privately held community root and its optional split capabilities for exactly
 * this entry's epoch (CORD-02 §5/§8; CORD-06 §3). Retained candidate provenance
 * grants historical read capability, never current authority or canonical selection.
 */
export interface HeldRootEntry extends HeldKeyEntry {
  /** Validated predecessor read root at epoch minus one; absent on older saved history. */
  prev_root?: string;
  /** Stable authenticated rotation identifier for retained candidate evidence. */
  candidate_id?: string;
  /** Exact Grant citation retained with validated non-owner rotation evidence. */
  vac?: [string, string, string];
  /** Held split control stream address for this root epoch. */
  control_pk?: string;
  /** Held staff-only control signing root, validated against this entry's root/epoch/address coordinate. */
  control_root?: string;
}

/** A private channel's current key material, plus the prior keys still needed to read its history. */
export interface ChannelKey {
  /** The channel id this key material unlocks. */
  id: string;
  /** The channel's key for `epoch`, hex-encoded — what decrypts its current messages. */
  key: string; // hex
  /** The channel's current epoch; bumps on each adopted channel Rekey. */
  epoch: number;
  /** The channel's name at the time the material was minted. */
  name: string;
  /** Retained prior channel keys ({@link HeldKeyEntry}) after a channel-scoped
   *  Rekey (CORD-06), newest-first — so messages under prior channel epochs
   *  still decode. Mirrors {@link JoinMaterial.held_roots} for the community
   *  root. */
  held?: HeldKeyEntry[];
}
/** Everything needed to read a community: its identity, root key, epoch, channels and relays. */
export interface JoinMaterial {
  /** The community's identifier, derived from the owner and their salt. */
  community_id: string;
  /** The owner's pubkey — the root of every authority chain in the community. */
  owner: string;
  /** The owner's salt, which with `owner` derives {@link JoinMaterial.community_id}. */
  owner_salt: string;
  /** The member read root for `root_epoch`; split control signing uses its independent staff root. */
  community_root: string;
  /** Held split control stream address; omitted only for legacy material. */
  control_pk?: string;
  /** Staff-only independent control signing root, matching control_pk at root_epoch. */
  control_root?: string;
  /** The epoch `community_root` belongs to; bumps on each adopted Refounding. */
  root_epoch: number;
  /** Validated predecessor read root for this transition; not a wire field. */
  prev_root?: string;
  /** Per-channel key material for the private channels this material grants. */
  channels: ChannelKey[];
  /** The community's relays, as known when the material was minted. */
  relays: string[];
  /** The community's name, as known when the material was minted. */
  name: string;
  /** Retained prior roots ({@link HeldRootEntry}) after a Refounding (CORD-06;
   *  armada-compatible). `refounder` is the npub whose Refounding minted THAT
   *  epoch (per-epoch attribution) — undefined for genesis (epoch 0) and for
   *  entries predating this field. */
  held_roots?: HeldRootEntry[];
  /** The npub whose Refounding minted the current `root_epoch` (CORD-06). */
  refounder?: string;
}

/** The join material an invite link hands over, plus the link's own presentation and limits (CORD-05 §1). */
export interface InviteBundle extends Omit<JoinMaterial, "control_root" | "held_roots" | "prev_root"> {
  /** Legacy member-safe history accepted on input; ordinary producers grant the current epoch only. */
  held_roots?: HeldKeyEntry[];
  /** The community icon, so a join preview can render before the invitee joins. */
  icon?: BlobPointer;
  /** Optional unix-seconds expiry (D-05); past it the preview still renders but joining refuses. */
  expires_at?: number;
  /** The npub that minted the link, for join attribution. */
  creator_npub?: string;
  /** The creator's own label for the link; carried into the join attribution. */
  label?: string;
}

// A member's private, self-encrypted membership document. One replaceable event
// per user; nothing is ever deleted and liveness is derived (a re-join
// resurrects a tombstoned id). The wire document keys the array as `entries`,
// but the in-memory API exposes it as `communities`.
/** One membership entry in a member's Community List (CORD-02 §8). */
export interface CommunityListCommunity {
  /** The community this entry is a membership in. */
  community_id: string;
  /** Earliest epoch held — the backfill anchor (only ever moves backward on merge). */
  seed: JoinMaterial;
  /** Freshest snapshot — replaced on every Refounding or rename. */
  current: JoinMaterial;
  /** ms; tiebreaks against a tombstone's removed_at. */
  added_at: number;
  /** Round-trip escape hatch, so another client's future fields survive this client's edits. */
  [k: string]: unknown;
}
/** A left community, retained permanently so the leave cannot be resurrected by a stale device. */
export interface CommunityTombstone {
  /** The community that was left. */
  community_id: string;
  /** ms. Permanent — pruning would let a long-offline device resurrect a leave. */
  removed_at: number;
  /** Round-trip escape hatch, so another client's future fields survive this client's edits. */
  [k: string]: unknown;
}

// A creator's private, self-encrypted bookkeeping for the invite links they
// have minted. One replaceable event per user; the full merged document is
// (re)published on every change.
/** One minted invite link in a creator's Invite List (CORD-05 §4). */
export interface InviteListInvite {
  /** The link's unlock secret and its merge key. */
  token: string;
  /** The `link_signer` secret key hex (CORD-05 §2). */
  signer_sk: string;
  /** The community the link grants access to. */
  community_id: string;
  /** The full shareable invite URL. */
  url: string;
  /** The creator's own label for this link. */
  label?: string;
  /** Private channel ids this link grants. Omitted or empty grants none. */
  channels?: string[];
  /** Unix seconds the link was minted. */
  created_at: number;
  /** Optional unix-seconds expiry (D-05; CORD-05 §4 magnitude reading). */
  expires_at?: number;
  /** Round-trip escape hatch, so another client's future fields survive this client's edits. */
  [k: string]: unknown;
}
/** A revoked invite link, retained so the revocation cannot be resurrected by a stale device. */
export interface InviteListTombstone {
  /** The revoked link's token — the merge key it is matched on. */
  token: string;
  /** The community the revoked link belonged to. */
  community_id: string;
  /** Round-trip escape hatch, so another client's future fields survive this client's edits. */
  [k: string]: unknown;
}

/** One authenticated, authority-verified CORD-04 control edition. */
export interface VerifiedControlHead {
  /** Original decoded edition; its seal is retained for verbatim compaction. */
  edition: DecodedEvent;
  /** Value-schema kind, binding this proof to its document type. */
  vsk: number;
  /** Canonical entity coordinate. */
  eid: string;
  /** Positive, safe edition version. */
  version: number;
  /** Hash of the original content bytes and edition chain fields. */
  hash: string;
  /** Exact preceding edition hash, when supplied. */
  prevHash?: string;
}

/** Historically authorized, correctly typed and coordinate-bound Grant evidence. */
export interface VerifiedGrantEdition extends VerifiedControlHead {
  /** Member bound to the derived Grant coordinate. */
  member: string;
  /** Role identities in this exact historical Grant. */
  roleIds: readonly string[];
}

/** Candidate-local evidence a caller may synchronize; pure folds perform no I/O. */
export interface ControlPendingEvidence {
  /** Entity or cited Grant coordinate needing evidence. */
  eid: string;
  /** Exact requested version, when known. */
  version?: number;
  /** Exact requested hash, when known. */
  hash?: string;
  /** Actor whose action is parked. */
  actor?: string;
  /** Why enforcement cannot use this candidate. */
  reason: "missing-pin" | "pin-mismatch" | "chain-gap" | "support-cycle";
}

/**
 * Verified control projection and historical provenance for one community.
 * Complete retained histories reconstruct this evidence. After cache truncation,
 * callers may restore a previously verified same-community value as continuity;
 * unverified relay snapshots are never a valid restoration input.
 */
export interface ControlVerification {
  /** Identity preventing verification reuse across communities. */
  communityId: string;
  /** Selected current control editions, keyed by entity coordinate. */
  heads: Map<string, VerifiedControlHead>;
  /** Verified Grant history, keyed by the derived Grant coordinate. */
  grantHistory: Map<string, VerifiedGrantEdition[]>;
  /** Entity coordinates with unresolved current support; retained display heads confer no enforcement authority. */
  suspended: Set<string>;
  /** Missing or inconsistent evidence, with deterministic deduplication. */
  pending: ControlPendingEvidence[];
  /** Accepted removal floors; loss of the removed authority cannot undo them. */
  removals: Map<string, VerifiedControlHead>;
}

/** A community's complete derived state — the output of folding its control and guestbook planes. */
export interface CommunityState {
  /** The key material and identity this state was folded against. */
  material: JoinMaterial;
  /** The folded vsk 0 metadata, absent until a metadata edition is seen. */
  metadata?: CommunityMetadata;
  /** Every live folded channel; deleted channels are omitted (see {@link ChannelMetadata.deleted}). */
  channels: ChannelMetadata[];
  /** Every folded role, including deleted ones (see {@link Role.deleted}). */
  roles: Role[];
  /** Each member's granted role ids — the folded vsk 3 entities, keyed by member pubkey. */
  grants: Map<string, string[]>; // member -> role_ids
  /** Banned members; they are barred from rejoining, not merely removed. */
  banlist: Set<string>;
  /** Aggregate live invite-link coordinates (link_signer pubkeys) folded from
   *  every authorized creator's Registry; non-empty ⇒ the Community is Public
   *  (CORD-05 §5). */
  inviteLinks: Set<string>;
  /** The present memberlist, after banned, kicked and unobserved members are removed. */
  members: Set<string>;
  /** Whether the owner has published the dissolution tombstone (vsk 10). */
  dissolved: boolean;
  /** Selected display heads (eid → decoded), including retained floors during gaps.
   * Enforcement and CORD-06 compaction additionally require unsuspended verified identities. */
  heads?: Map<string, DecodedEvent>;
  /** Current verified heads, exact Grant history and unresolved support evidence. */
  controlVerification?: ControlVerification;
}

/** A signed Nostr event exactly as a relay returns it — the outer wrap, before any Concord decode. */
export type RawEvent = NostrEvent;

// Flat, single-value status snapshots (one field per underlying observable),
// mirroring `RelayStatus` in applesauce-relay. Each engine exposes the granular
// `$` fields these are composed from plus a derived `status$` carrying the whole
// snapshot, so UI can react to either the individual signal or the aggregate.

/** The sync-lifecycle phase of a synced Concord entity (community or private channel). */
export type ConcordSyncPhase = "idle" | "syncing" | "live" | "removed" | "error";

/** A snapshot of a {@link CommunityState}-backed community engine's status. */
export interface ConcordCommunityStatus {
  /** Sync lifecycle, or `"dissolved"` once the owner dissolves the community. */
  phase: ConcordSyncPhase | "dissolved";
  /** The community's current root epoch (bumps on each adopted Refounding). */
  epoch: number;
  /** At least one of the community's relays has an open socket. */
  connected: boolean;
  /** The last sync error message, or null. Auth is a property of an individual
   *  operation now (D-10/D-11), not standing state — a failed NIP-42 AUTH
   *  surfaces here rather than through a dedicated status field. */
  error: string | null;
}

/** A snapshot of a private-channel sub-engine's status. */
export interface ConcordPrivateChannelStatus {
  /** The channel's sync lifecycle. */
  phase: ConcordSyncPhase;
  /** The channel's current epoch (bumps on each adopted channel Rekey). */
  epoch: number;
  /** At least one of the community's relays has an open socket. */
  connected: boolean;
  /** The last sync error message for this channel, or null. */
  error: string | null;
}

/** A snapshot of the multi-community {@link ConcordClient} manager's status. */
export interface ConcordClientStatus {
  /** `"idle"` before `start()`, `"starting"` during startup, `"ready"` after. */
  phase: "idle" | "starting" | "ready";
  /** Number of joined communities. */
  communities: number;
  /** Communities not yet caught up to their tip (phase ≠ "live"). */
  syncing: number;
  /** Communities caught up and live. */
  live: number;
  /** At least one community relay has an open socket. */
  connected: boolean;
}
