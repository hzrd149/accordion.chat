// CORD-04 §4: "Every honest client drops every event from a banned npub — message, reaction, edit, or authority
// action — so a banned member vanishes entirely." The channel timeline is the ban-aware input every message, reaction,
// edit and delete fold reads, so a banned author's rumors must leave it whatever their kind.

/// <reference lib="esnext.disposable" />
import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { FakeTime } from "@std/testing/time";
import { RumorStore } from "applesauce-core";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";
import { BehaviorSubject } from "rxjs";

import { ConcordChatTimelineModel } from "../chat.ts";

const BANNED = "bb".repeat(32);
const MEMBER = "aa".repeat(32);

function rumor(pubkey: string, kind: number): Rumor {
  const event = { id: "", pubkey, created_at: 5, kind, tags: [], content: `${pubkey.slice(0, 2)}-${kind}` };
  event.id = getEventHash(event);
  return event;
}

describe("the ban-aware channel timeline (CORD-04 §4)", () => {
  // Non-vacuity: before the ban every kind of both authors is shown, so the filtered result is not an empty timeline.
  it("drops a banned author's message, reaction, edit and comment, and keeps everyone else's", () => {
    const time = new FakeTime(1_000);
    const store = new RumorStore();
    const bans = new BehaviorSubject<ReadonlySet<string>>(new Set());
    const values: Rumor[][] = [];
    const sub = ConcordChatTimelineModel(bans)(store).subscribe((value) => values.push(value));
    try {
      const kinds = [9, 7, 3302, 1111];
      for (const kind of kinds) {
        store.add(rumor(BANNED, kind));
        store.add(rumor(MEMBER, kind));
      }
      expect(values.at(-1)).toHaveLength(kinds.length * 2);
      bans.next(new Set([BANNED]));
      const shown = values.at(-1)!;
      expect(shown.map((entry) => entry.pubkey)).toEqual(kinds.map(() => MEMBER));
      expect(shown.map((entry) => entry.kind).sort((a, b) => a - b)).toEqual([...kinds].sort((a, b) => a - b));
    } finally {
      sub.unsubscribe();
      store.dispose();
      time.restore();
    }
  });
});
