import { expect } from "@std/expect";
import { describe, it } from "@std/testing/bdd";
import { FakeTime } from "@std/testing/time";
import { RumorStore } from "applesauce-core";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";
import { PrivateKeySigner } from "applesauce-signers";
import { BehaviorSubject } from "rxjs";
import { EDIT_KIND } from "../../helpers/edit.ts";
import { createPinProof, type PinEntry, type PinListRead, type VerifiedPin } from "../../helpers/pins.ts";
import { retainChannelInput } from "../../client/channel-input.ts";
import { sealRumor } from "../../operations/gift-wrap.ts";
import { ConcordPinsModel } from "../pins.ts";

const channel = "ab".repeat(32);
const key = new Uint8Array(32).fill(2);
const signer = new PrivateKeySigner(new Uint8Array(32).fill(1));
const pubkey = await signer.getPublicKey();

function build(kind: number, content: string, createdAt: number, tags: string[][] = []): Rumor {
  const rumor = {
    pubkey,
    id: "",
    kind,
    content,
    tags: [["channel", channel], ["epoch", "0"], ...tags],
    created_at: createdAt,
  };
  return { ...rumor, id: getEventHash(rumor) };
}

async function pinned(expiration?: number): Promise<{ original: Rumor; list: PinListRead }> {
  const original = build(9, "original", 10, expiration ? [["expiration", String(expiration)]] : []);
  const entry = createPinProof(await sealRumor(key, signer)(original), key) as PinEntry;
  return { original, list: { available: true, entries: [entry] } };
}

const edit = (original: Rumor, content: string, at: number): Rumor =>
  build(EDIT_KIND, content, at, [["e", original.id]]);

/** Run a model over a fresh store, always releasing the subscription and the store. */
async function observe(
  list: PinListRead,
  options: Parameters<typeof ConcordPinsModel>[2],
  body: (store: RumorStore, seen: VerifiedPin[][]) => void | Promise<void>,
): Promise<void> {
  const store = new RumorStore();
  const seen: VerifiedPin[][] = [];
  const sub = ConcordPinsModel(channel, new BehaviorSubject(list), options)(store).subscribe((v) => seen.push(v));
  try {
    await body(store, seen);
  } finally {
    sub.unsubscribe();
    store.dispose();
  }
}

describe("ConcordPinsModel", () => {
  it("ConcordPinsModel re-emits when a newer Edit arrives", async () => {
    const { original, list } = await pinned();
    await observe(list, { now: () => 100 }, (store, seen) => {
      expect(seen.at(-1)?.[0].text).toBe("original");
      store.add(edit(original, "fixed", 20));
      expect(seen.at(-1)?.[0].text).toBe("fixed");
      expect(seen.at(-1)?.[0].edited).toBe(true);
      expect(seen.at(-1)?.[0].behind).toBe(true);
      store.add(edit(original, "older", 15));
      expect(seen.at(-1)?.[0].text).toBe("fixed");
    });
  });

  it("ConcordPinsModel hides a pin as soon as its author's deletion arrives", async () => {
    const { original, list } = await pinned();
    await observe(list, { now: () => 100 }, async (store, seen) => {
      expect(seen.at(-1)).toHaveLength(1);
      // A kind-5 rumor reaches a channel store through retainChannelInput; store.add would only feed its delete manager.
      await retainChannelInput(store, build(5, "", 30, [["e", original.id]]));
      expect(seen.at(-1)).toEqual([]);
    });
  });

  it("ConcordPinsModel re-emits at the next expiry boundary and leaves no timer after unsubscribe", async () => {
    const time = new FakeTime(1_000_000);
    try {
      const { list } = await pinned(1_000 + 5);
      const store = new RumorStore();
      const seen: VerifiedPin[][] = [];
      const sub = ConcordPinsModel(channel, new BehaviorSubject(list))(store).subscribe((v) => seen.push(v));
      try {
        expect(seen.at(-1)).toHaveLength(1);
        time.tick(4_999);
        expect(seen.at(-1)).toHaveLength(1);
        time.tick(1);
        expect(seen.at(-1)).toEqual([]);
        // Nothing further is scheduled once the only boundary has passed.
        expect(time.next()).toBe(false);
      } finally {
        sub.unsubscribe();
        store.dispose();
      }
      const second = new RumorStore();
      const again = ConcordPinsModel(channel, new BehaviorSubject((await pinned(1_000 + 60)).list))(second).subscribe();
      again.unsubscribe();
      second.dispose();
      expect(time.next()).toBe(false);
    } finally {
      time.restore();
    }
  });

  it("ConcordPinsModel keeps an expired pin with showExpired and exposes expiresAt", async () => {
    const { list } = await pinned(50);
    await observe(list, { now: () => 100 }, (_store, seen) => expect(seen.at(-1)).toEqual([]));
    await observe(list, { now: () => 100, showExpired: true }, (_store, seen) => {
      expect(seen.at(-1)).toHaveLength(1);
      expect(seen.at(-1)?.[0].expiresAt).toBe(50);
    });
  });

  // Non-vacuity: a model that ignored the ban set would keep the banned author's pin on the first assertion; one that
  // never re-emitted on a ban change would not restore it on unban.
  it("ConcordPinsModel hides a banned author's pin, restores it on unban and shows it with showBanned (CORD-04 §7)", async () => {
    const { list } = await pinned();
    const bans = new BehaviorSubject<ReadonlySet<string>>(new Set());
    await observe(list, { now: () => 100, bans }, (_store, seen) => {
      expect(seen.at(-1)).toHaveLength(1);
      bans.next(new Set([pubkey]));
      expect(seen.at(-1)).toEqual([]);
      bans.next(new Set());
      expect(seen.at(-1)).toHaveLength(1);
    });
    const alwaysBanned = new BehaviorSubject<ReadonlySet<string>>(new Set([pubkey]));
    await observe(list, { now: () => 100, bans: alwaysBanned }, (_store, seen) => expect(seen.at(-1)).toEqual([]));
    await observe(list, { now: () => 100, bans: alwaysBanned, showBanned: true }, (_store, seen) => {
      expect(seen.at(-1)).toHaveLength(1);
    });
  });
});
