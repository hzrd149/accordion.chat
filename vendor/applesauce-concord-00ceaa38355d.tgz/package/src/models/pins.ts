// CORD-04 §7: pins follow Edits and the author's own deletions as they arrive.
// CORD-08 §3: expiry is a reader-side display rule, so the model re-emits once at the next expiry boundary instead of
// polling, and never publishes anything.
import type { Model } from "applesauce-core/event-store";
import type { Rumor } from "applesauce-core/helpers/event";
import { combineLatest, distinctUntilChanged, EMPTY, expand, map, of, switchMap, timer } from "rxjs";
import type { Observable } from "rxjs";

import { EDIT_KIND } from "../helpers/edit.ts";
import { projectPins } from "../helpers/pin-projection.ts";
import type { PinEntry, PinListRead, VerifiedPin } from "../helpers/pins.ts";

/** Longest delay a single timer may carry (the 32-bit signed millisecond limit). */
const MAX_TIMER_MS = 2_147_483_647;

/** How a pin reader wants expired pins treated. */
export interface PinDisplayOptions {
  /** Include expired pins, exposing their `expiresAt`, instead of hiding them (DEC-01). Default false. */
  showExpired?: boolean;
  /** Include pins whose proven message author is currently banned instead of hiding them (CORD-04 §7). Default false. */
  showBanned?: boolean;
}

/** Options for {@link ConcordPinsModel}. */
export interface ConcordPinsModelOptions extends PinDisplayOptions {
  /** Current community bans; banned authors' local Edits are ignored and their pins hidden unless `showBanned`. */
  bans?: Observable<ReadonlySet<string>>;
  /** Entry verifier, for callers that cache verification. Defaults to `verifyPinEntry`. */
  verify?: (entry: PinEntry, channelId: string) => VerifiedPin | undefined;
  /** Clock in Unix seconds. Defaults to `Date.now() / 1000`. */
  now?: () => number;
}

function samePins(a: VerifiedPin[], b: VerifiedPin[]): boolean {
  return a.length === b.length && a.every((pin, i) => {
    const other = b[i];
    return pin.rumor.id === other.rumor.id && pin.edit?.id === other.edit?.id && pin.edited === other.edited &&
      pin.behind === other.behind && pin.text === other.text && pin.expiresAt === other.expiresAt;
  });
}

/**
 * Fold a channel's RumorStore and its Pin List into the pins a reader should see: the newest author-valid Edit's text,
 * author self-deleted pins dropped, pins of a banned author hidden unless `showBanned` is set, and expired pins hidden
 * unless `showExpired` is set. Re-emits when an Edit or
 * deletion arrives, when the list or bans change, and once at the next expiry boundary; there is no polling.
 * @param channelId Channel whose pins are shown.
 * @param list Current readable Pin List state of that channel.
 * @param options Display, ban, verification and clock options.
 */
export function ConcordPinsModel(
  channelId: string,
  list: Observable<PinListRead>,
  options: ConcordPinsModelOptions = {},
): Model<VerifiedPin[], Rumor> {
  const clock = options.now ?? (() => Date.now() / 1000);
  return (store) =>
    combineLatest([
      store.timeline([{ kinds: [5, EDIT_KIND] }], { batchWindow: false }),
      list,
      options.bans ?? of(new Set<string>()),
    ]).pipe(
      switchMap(([rumors, read, bans]) => {
        const compute = (): { pins: VerifiedPin[]; delay?: number } => {
          const now = clock();
          // One projection serves display and boundary: a pin is expired exactly when its expiresAt (the earlier
          // of the original's and the shown Edit's) has passed.
          const all = projectPins(read, channelId, {
            rumors,
            now,
            showExpired: true,
            isBanned: (pubkey) => bans.has(pubkey),
            showBanned: options.showBanned,
            verify: options.verify,
          });
          const pins = options.showExpired ? all : all.filter((p) => p.expiresAt === undefined || p.expiresAt > now);
          const upcoming = all.flatMap((p) => p.expiresAt !== undefined && p.expiresAt > now ? [p.expiresAt] : []);
          return {
            pins,
            delay: upcoming.length
              ? Math.min(MAX_TIMER_MS, Math.ceil((Math.min(...upcoming) - now) * 1000))
              : undefined,
          };
        };
        return of(compute()).pipe(
          expand(({ delay }) => delay === undefined ? EMPTY : timer(delay).pipe(map(compute))),
          map(({ pins }) => pins),
        );
      }),
      distinctUntilChanged(samePins),
    );
}
