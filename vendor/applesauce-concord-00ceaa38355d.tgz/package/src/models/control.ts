import type { Model } from "applesauce-core/event-store";
import type { Rumor } from "applesauce-core/helpers/event";
import { map, scan } from "rxjs";

import { CONTROL_KIND, foldControl } from "../helpers/control.ts";
import { PLAINTEXT_SEAL_KIND } from "../helpers/gift-wrap.ts";
import type { CommunityState, ControlVerification, JoinMaterial } from "../types.ts";
import { decodedFromRumor } from "./utils.ts";

/** Fold a Control Plane store, retaining verified floors across emissions.
 * @param material Community identity and key material.
 * @param previous Same-community continuity restored after cache truncation.
 */
export function ConcordControlModel(
  material: JoinMaterial,
  previous?: ControlVerification,
): Model<CommunityState, Rumor> {
  return (store) =>
    store.timeline([{ kinds: [CONTROL_KIND] }], { batchWindow: false }).pipe(
      scan((state, rumors) =>
        foldControl(
          rumors.map((rumor) => decodedFromRumor(rumor, PLAINTEXT_SEAL_KIND)),
          material,
          state.controlVerification,
        ), foldControl([], material, previous)),
    );
}

/** Select the folded banlist from a Control Plane store. */
export function ConcordBanlistModel(material: JoinMaterial): Model<Set<string>, Rumor> {
  return (store) => store.model(ConcordControlModel, material).pipe(map((state) => state.banlist));
}

/** Select the folded channels from a Control Plane store. */
export function ConcordChannelsModel(material: JoinMaterial): Model<CommunityState["channels"], Rumor> {
  return (store) => store.model(ConcordControlModel, material).pipe(map((state) => state.channels));
}

/** Select the folded roles from a Control Plane store. */
export function ConcordRolesModel(material: JoinMaterial): Model<CommunityState["roles"], Rumor> {
  return (store) => store.model(ConcordControlModel, material).pipe(map((state) => state.roles));
}
