import type { AsyncRumorStore, RumorStore } from "applesauce-core";
import type { Model } from "applesauce-core/event-store";
import type { Rumor } from "applesauce-core/helpers/event";
import { combineLatest, distinctUntilChanged, map, Observable, of } from "rxjs";

import { foldMembers, JOIN_LEAVE_KIND, KICK_KIND, SNAPSHOT_KIND } from "../helpers/guestbook.ts";
import { resolveStanding, vacVerifier } from "../helpers/permissions.ts";
import { PERM } from "../types.ts";
import type { CommunityState, ControlVerification, JoinMaterial, Role } from "../types.ts";
import { ConcordControlModel } from "./control.ts";
import { ConcordObservedAuthorsModel } from "./observed.ts";
import { decodedFromRumor, mergeObserved } from "./utils.ts";

/** The plane stores {@link ConcordCommunityStateModel} folds alongside the control store it is hosted on. */
export interface ConcordCommunityStores {
  /** Same-community verified floors retained across model recreation. */
  controlVerification?: ControlVerification;
  /** The community Guestbook Plane store — the in-memory {@link RumorStore}, or an
   *  {@link AsyncRumorStore} backed by an async event database. This names the union
   *  directly rather than through a local alias because `deno doc` treats a non-exported
   *  alias as a private type (D-80). It mirrors the client's `ConcordRumorStore` without
   *  importing it: models must not depend on src/client/. */
  guestbook?: RumorStore | AsyncRumorStore;
  /** Additional stores whose authors should count as observably present — in practice the
   *  community's channel stores. Same union as {@link ConcordCommunityStores.guestbook}. */
  observed?: Iterable<RumorStore | AsyncRumorStore>;
}

/** Fold control, guestbook, and observed plane stores into a complete community state. */
export function ConcordCommunityStateModel(
  material: JoinMaterial,
  stores: ConcordCommunityStores = {},
  nowMs: number = Date.now(),
): Model<CommunityState, Rumor> {
  return (controlStore) => {
    const control$ = controlStore.model(ConcordControlModel, material, stores.controlVerification);
    const guestbook$ =
      stores.guestbook?.timeline([{ kinds: [JOIN_LEAVE_KIND, KICK_KIND, SNAPSHOT_KIND] }], { batchWindow: false }) ??
        new Observable<Rumor[]>((sub) => {
          sub.next([]);
        });
    const decodedGuestbook$ = guestbook$.pipe(map((rumors) => rumors.map((rumor) => decodedFromRumor(rumor))));
    // Control is NOT counted as observed activity here (D-02/T-06-03): the control
    // store remains the fold host (`controlStore.model(...)` above) but its authors
    // no longer auto-count as "present" — narrowing observation is fail-safe (it can
    // only shrink the memberlist, never resurrect a removed member). The
    // current-epoch guestbook + caller-supplied stores (channels) are the only
    // observed inputs.
    const observedStores = [stores.guestbook, ...(stores.observed ?? [])].filter((
      s,
    ): s is RumorStore | AsyncRumorStore => !!s);
    const observed$ = observedStores.length
      ? combineLatest(observedStores.map((store) => store.model(ConcordObservedAuthorsModel))).pipe(map(mergeObserved))
      : of(new Map<string, number>());
    let previous: {
      control: CommunityState;
      guestbook: ReturnType<typeof decodedFromRumor>[];
      observed: Map<string, number>;
      state: CommunityState;
    } | undefined;

    return combineLatest([control$, decodedGuestbook$, observed$]).pipe(
      map(([control, guestbook, observed]) => {
        // CORD-02 §5: newer activity cannot remove an already-present author.
        // Refold whenever authority/Guestbook changes, an author disappears, or a
        // previously absent author might cross their latest departure time.
        if (previous && previous.control === control && previous.guestbook === guestbook) {
          const changed = new Set([...previous.observed.keys(), ...observed.keys()]);
          const needsFold = [...changed].some((author) => {
            const before = previous!.observed.get(author);
            const after = observed.get(author);
            return before !== after && (after === undefined || (before !== undefined && after < before) ||
              (!previous!.state.members.has(author) && (author === material.owner || !control.banlist.has(author))));
          });
          if (!needsFold) {
            previous.observed = observed;
            return previous.state;
          }
        }
        const roles = new Map<string, Role>(control.roles.map((role) => [role.role_id, role]));
        const standing = (member: string) => resolveStanding(member, material.owner, roles, control.grants);
        const state = {
          ...control,
          members: foldMembers(
            guestbook,
            observed,
            control.banlist,
            standing,
            nowMs,
            material.refounder,
            vacVerifier(control, PERM.KICK),
          ),
        };
        previous = { control, guestbook, observed, state };
        return state;
      }),
      distinctUntilChanged(),
    );
  };
}
