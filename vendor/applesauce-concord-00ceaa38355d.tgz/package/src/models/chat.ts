import type { Model } from "applesauce-core/event-store";
import type { Rumor } from "applesauce-core/helpers/event";
import type { Filter } from "applesauce-core/helpers/filter";
import { isRumorExpired, TIMER_NOTICE_KIND } from "../helpers/expiration.ts";
import { combineLatest, concat, interval, map, of } from "rxjs";
import type { Observable } from "rxjs";

/**
 * Expose retained channel rumors whose authors are absent from the current bans.
 * Ban emissions refilter cached history without new chat ingress. Ordering and
 * rumor identity are preserved; the host store remains raw diagnostic evidence.
 * Request every kind needed by downstream message/edit/reaction/delete folds so
 * banned effects are excluded before projection (CORD-03 §3).
 * @param bans Current resolved community bans; callers must keep this source current.
 * @param filters Nostr filters for the raw timeline, defaulting to every kind.
 */
export function ConcordChatTimelineModel(
  bans: Observable<ReadonlySet<string>>,
  filters: Filter[] = [{}],
  canManageMetadata: Observable<(author: string) => boolean> = of(() => false),
): Model<Rumor[], Rumor> {
  return (store) =>
    combineLatest([
      store.timeline(filters, { batchWindow: false }),
      bans,
      canManageMetadata,
      concat(of(0), interval(1000)),
    ]).pipe(
      map(([rumors, currentBans, authorized]) =>
        rumors.filter((rumor) =>
          !currentBans.has(rumor.pubkey) && !isRumorExpired(rumor) &&
          (rumor.kind !== TIMER_NOTICE_KIND || authorized(rumor.pubkey))
        )
      ),
    );
}
