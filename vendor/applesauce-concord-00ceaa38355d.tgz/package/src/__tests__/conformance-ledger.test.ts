// Guard for the REL-01 conformance ledger: every covered rule must cite tests that exist.

/// <reference lib="deno.ns" />
// Test-only: this guard reads the source tree, so it opts into the Deno namespace (see index.cord-citations.test.ts).

import { dirname, fromFileUrl, join } from "@std/path";
import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { citationsOutsideRegistry } from "./cord-wire-fixtures.ts";
import { CONFORMANCE_LEDGER, type LedgerEntry, ledgerProblems } from "./conformance-ledger.ts";
import { sweepGroupOf } from "./conformance-mutations.ts";

// Rooted at this module's URL, never the working directory.
const SRC_ROOT = join(dirname(fromFileUrl(import.meta.url)), "..");

function read(file: string): string | undefined {
  try {
    return Deno.readTextFileSync(join(SRC_ROOT, file));
  } catch {
    return undefined;
  }
}

const synthetic = (overrides: Partial<LedgerEntry>): LedgerEntry => ({
  id: "TEST.synthetic",
  requirement: "TEST-01",
  level: "MUST",
  rule: "synthetic",
  phase: 1,
  status: "covered",
  tests: [{ file: "__tests__/conformance-ledger.test.ts", name: "the ledger seeds every Phase 1 requirement" }],
  ...overrides,
});

describe("MUST/SHOULD conformance ledger (REL-01 skeleton, D-20)", () => {
  it("the ledger seeds every Phase 1 requirement", () => {
    expect(CONFORMANCE_LEDGER.length).toBeGreaterThan(0);
    const requirements = new Set(CONFORMANCE_LEDGER.map((entry) => entry.requirement));
    for (const id of ["FND-01", "FND-02", "FND-03", "FND-04", "FND-05", "LIST-01", "LIST-02"]) {
      expect(requirements.has(id)).toBe(true);
    }
  });

  it("the ledger covers the Phase 1 gap-closure rules (D-31, D-32)", () => {
    const ids = [
      "FND-01.terminal-dispose",
      "FND-02.edge-triggered-list-read",
      "LIST-01.single-lane",
      "LIST-01.no-stranded-held-write",
      "LIST-01.publish-needs-current-evidence",
      "LIST-02.no-demotion-under-interleaving",
      "LIST-01.dirty-reflects-relay-copy",
      "LIST-01.save-view-current",
      "FND-02.bounded-deferred-save",
      "LIST-01.resumable-join",
      "LIST-02.sync-api-on-lane",
      "LIST-02.sync-api-needs-open-lane",
      "LIST-01.motions-in-call-order",
      "FND-01.app-work-bound-to-lifecycle",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 1 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers the Phase 2 pin rules", () => {
    const ids = [
      "PIN-01.apply-newest-edit",
      "PIN-01.never-older-edit",
      "PIN-01.never-superseded-text",
      "PIN-01.cache-verification",
      "PIN-02.hide-self-deleted",
      "PIN-09.reactive-pins",
      "DEC-01.expired-hidden-reader-side",
      "DEC-01.no-publication-on-expiry",
      "DEC-02.first-pin-after-proven-absence",
      "DEC-02.setpins-head-guard",
      "PIN-11.admin-preset-omits-pin-messages",
      "PIN-03.self-delete-omission",
      "PIN-03.replay-rearms",
      "PIN-03.no-storm",
      "PIN-03.opt-out",
      "PIN-04.refresh-newest-provable",
      "PIN-04.no-other-form",
      "PIN-04.never-regress",
      "PIN-04.coalesced",
      "PIN-05.seal-from-retained-wraps",
      "PIN-05.newest-seal-retained",
      "PIN-06.rekey-refresh",
      "PIN-06.unavailable-old-epoch",
      "PIN-06.over-cap-terminal",
      "PIN-07.no-write-from-unreadable-list",
      "PIN-07.no-public-reform-by-automation",
      "PIN-07.no-mechanical-conversion",
      "PIN-07.unreadable-never-rebuilt",
      "PIN-08.stops-on-authority-loss",
      "PIN-08.dissolved-self-scrub-only",
      "PIN-10.deleted-channels",
      "PIN-10.collision-re-heal",
      "PIN-10.fresh-post-rotation-reader",
      "PIN-10.replayed-heads",
      "PIN-10.demotion",
      "PIN-10.post-dissolution",
    ];
    expect(ids).toHaveLength(36);
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 2 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers the Phase 2 deleted-Edit rule (D-31)", () => {
    for (const id of ["PIN-01.deleted-edit-ignored", "PIN-04.never-bundle-deleted-edit"]) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 2 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers the Phase 2 duplicate-entry rule (D-32)", () => {
    for (const id of ["PIN-01.duplicate-entries-newest-bundle", "PIN-04.duplicate-entries-never-regress"]) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 2 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers every Phase 2 requirement", () => {
    const requirements = [
      "PIN-01",
      "PIN-02",
      "PIN-03",
      "PIN-04",
      "PIN-05",
      "PIN-06",
      "PIN-07",
      "PIN-08",
      "PIN-09",
      "PIN-10",
      "PIN-11",
      "DEC-01",
      "DEC-02",
    ];
    for (const requirement of requirements) {
      const covered = CONFORMANCE_LEDGER.filter((entry) =>
        entry.requirement === requirement && entry.phase === 2 && entry.status === "covered"
      );
      expect({ requirement, covered: covered.length > 0 }).toEqual({ requirement, covered: true });
    }
  });

  it("the Phase 2 residual risks are recorded with their reasons", () => {
    for (const id of ["PIN-10.bounded-pin-backlog", "PIN-10.compaction-omits-deleted-channel-pins"]) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase, tests: entry?.tests.length }).toEqual({
        id,
        status: "residual",
        phase: 2,
        tests: 0,
      });
      expect(entry!.residual?.trim().length).toBeGreaterThan(0);
      expect(entry!.spec).toBe("CORD-04 §7");
      expect(entry!.level).toBe("SHOULD");
    }
  });

  it("the ledger covers the Phase 3 Community List rules", () => {
    const ids = [
      "LIST-03.persist-verified-winners",
      "LIST-03.restore-verified",
      "LIST-03.restore-before-relay",
      "LIST-03.restored-not-evidence",
      "LIST-03.unlock-retained",
      "LIST-04.prefix-complete",
      "LIST-04.repair-converges",
      "LIST-04.never-infer-missing",
      "LIST-04.baseline-recheck",
      "LIST-04.dormant-merged",
      "LIST-05.single-repair-owner",
      "LIST-05.repair-consent",
      "LIST-05.cancel-across-lifecycles",
      "LIST-05.durable-before-publish",
      "LIST-06.no-fragment-fields-above-zero",
      "LIST-06.stranded-to-zero",
      "LIST-06.unknown-fields-survive",
      "LIST-07.memberships-api",
      "LIST-07.legacy-read-only",
      "LIST-08.no-lost-keys",
      "LIST-08.no-revived-tombstones",
      "LIST-08.no-overwritten-unread",
      "LIST-08.no-wedged-cleanup",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 3 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers every Phase 3 requirement", () => {
    const requirements = ["LIST-03", "LIST-04", "LIST-05", "LIST-06", "LIST-07", "LIST-08"];
    for (const requirement of requirements) {
      const covered = CONFORMANCE_LEDGER.filter((entry) =>
        entry.requirement === requirement && entry.phase === 3 && entry.status === "covered"
      );
      expect({ requirement, covered: covered.length > 0 }).toEqual({ requirement, covered: true });
    }
  });

  it("the Phase 3 residual risk is recorded with its reason", () => {
    for (const id of ["LIST-03.new-device-single-relay"]) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase, tests: entry?.tests.length }).toEqual({
        id,
        status: "residual",
        phase: 3,
        tests: 0,
      });
      expect(entry!.residual?.trim().length).toBeGreaterThan(0);
      expect(entry!.spec).toBe("CORD-02 §8");
      expect(entry!.level).toBe("SHOULD");
    }
  });

  it("the ledger covers the Phase 4 disappearing-message rules", () => {
    const ids = [
      "EXP-01.every-folded-channel",
      "EXP-01.private-and-held-epochs",
      "EXP-01.bounded-sweep",
      "EXP-02.never-displayed",
      "EXP-02.never-retained",
      "EXP-03.opt-in-owned",
      "EXP-03.bounded",
      "EXP-03.client-fan-out",
      "EXP-04.signed-tag-only",
      "EXP-05.forged-outer-hide",
      "EXP-05.forged-outer-revive",
      "EXP-05.non-retroactive",
      "EXP-05.stamp-durable",
      "EXP-05.exempt-unstamped",
      "EXP-05.tombstones",
      "EXP-06.purge-pinned",
      "EXP-06.purge-wins",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 4 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers every Phase 4 requirement", () => {
    const requirements = ["EXP-01", "EXP-02", "EXP-03", "EXP-04", "EXP-05", "EXP-06"];
    for (const requirement of requirements) {
      const covered = CONFORMANCE_LEDGER.filter((entry) =>
        entry.requirement === requirement && entry.phase === 4 && entry.status === "covered"
      );
      expect({ requirement, covered: covered.length > 0 }).toEqual({ requirement, covered: true });
    }
  });

  it("the Phase 4 residual risks are recorded with their reasons", () => {
    const expected = [
      { id: "EXP-01.host-swept", spec: "CORD-08 §3" },
      { id: "EXP-04.app-store-nip40", spec: "CORD-08 §2" },
    ];
    for (const { id, spec } of expected) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase, tests: entry?.tests.length }).toEqual({
        id,
        status: "residual",
        phase: 4,
        tests: 0,
      });
      expect(entry!.residual?.trim().length).toBeGreaterThan(0);
      expect(entry!.spec).toBe(spec);
      expect(entry!.level).toBe("SHOULD");
    }
  });

  it("the ledger covers the Phase 5 forum post rules", () => {
    const ids = [
      "FORUM-01.subject-wire",
      "FORUM-01.subject-cap",
      "FORUM-02.display-truncation",
      "FORUM-05.kind-11-readable",
      "FORUM-05.reply-root-inheritance",
      "DEC-03.send-thread-alias",
      "FORUM-06.subject-exports",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 5 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers the Phase 5 channel view and edit rules", () => {
    const ids = [
      "FORUM-03.view-typed",
      "FORUM-03.view-preserved",
      "FORUM-03.channels-reemit",
      "FORUM-03.create-view",
      "FORUM-04.edit-k-tag",
      "FORUM-04.receiver-ignores-k",
      "FORUM-06.view-exports",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 5 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers every Phase 5 forum requirement", () => {
    for (const requirement of ["FORUM-01", "FORUM-02", "FORUM-03", "FORUM-04", "FORUM-05", "FORUM-06", "DEC-03"]) {
      const covered = CONFORMANCE_LEDGER.filter((entry) =>
        entry.requirement === requirement && entry.phase === 5 && entry.status === "covered"
      );
      expect({ requirement, covered: covered.length > 0 }).toEqual({ requirement, covered: true });
    }
  });

  it("the ledger covers the Phase 5 batch ban rules", () => {
    const ids = [
      "BAN-01.validated-first",
      "BAN-01.single-edition",
      "BAN-01.shared-refounding",
      "BAN-01.discard-refused-refounding",
      "BAN-02.serialized",
      "BAN-02.rate-limited",
      "BAN-02.last-intent-wins",
      "BAN-05.rejected-ack",
      "BAN-05.mixed-rank-write",
      "BAN-01.exports",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 5 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers the Phase 5 re-heal rules", () => {
    const ids = [
      "BAN-03.reheal-lost-sibling",
      "BAN-03.no-revive-unban",
      "BAN-03.no-revive-removal",
      "BAN-03.own-bans-only",
      "BAN-04.stops-on-authority-loss",
      "BAN-04.stops-on-lifecycle",
      "BAN-04.typed-non-convergence",
      "BAN-04.bounded-owned",
      "BAN-04.exports",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 5 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers the Phase 5 re-heal proof and banned-pinner rules", () => {
    const ids = [
      "BAN-05.concurrent-writers",
      "BAN-05.restart",
      "BAN-05.devices",
      "BAN-05.other-holders",
      "BAN-05.mixed-rank-heal",
      "BAN-05.refounding-scope",
      "DEC-04.fallback-no-republish",
      "DEC-04.writer-replaces-reverted-head",
      "DEC-04.banned-self-delete",
    ];
    for (const id of ids) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase }).toEqual({ id, status: "covered", phase: 5 });
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
  });

  it("the ledger covers every Phase 5 requirement", () => {
    const requirements = [
      "FORUM-01",
      "FORUM-02",
      "FORUM-03",
      "FORUM-04",
      "FORUM-05",
      "FORUM-06",
      "DEC-03",
      "BAN-01",
      "BAN-02",
      "BAN-03",
      "BAN-04",
      "BAN-05",
      "DEC-04",
    ];
    for (const requirement of requirements) {
      const covered = CONFORMANCE_LEDGER.filter((entry) =>
        entry.requirement === requirement && entry.phase === 5 && entry.status === "covered"
      );
      expect({ requirement, covered: covered.length > 0 }).toEqual({ requirement, covered: true });
    }
  });

  it("the Phase 5 residual risks are recorded with their reasons", () => {
    const expected = [
      { id: "DEC-04.republish-surviving-list", spec: "CORD-04 §7" },
      { id: "BAN-03.pre-refounding-loss", spec: "CORD-04 §4" },
      { id: "BAN-03.restart-scope", spec: "CORD-04 §4" },
    ];
    for (const { id, spec } of expected) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, status: entry?.status, phase: entry?.phase, tests: entry?.tests.length }).toEqual({
        id,
        status: "residual",
        phase: 5,
        tests: 0,
      });
      expect(entry!.residual?.trim().length).toBeGreaterThan(0);
      expect(entry!.spec).toBe(spec);
      expect(entry!.level).toBe("SHOULD");
    }
  });

  it("the ledger covers the Phase 6 CORD-07 key derivation rule", () => {
    const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === "AV-01.voice-key-derivation");
    expect({ status: entry?.status, phase: entry?.phase, level: entry?.level, spec: entry?.spec }).toEqual({
      status: "covered",
      phase: 6,
      level: "MUST",
      spec: "CORD-07 §1",
    });
    expect(entry!.tests.length).toBe(5);
    for (const test of entry!.tests) expect(test.file).toBe("helpers/__tests__/crypto.voice-keys.test.ts");
  });

  it("the ledger maps the CORD-02 §8 rules of the Phase 6 spec sweep", () => {
    const covered = [
      "REL-01.list-base64url-named-fields",
      "REL-01.list-snapshot-omits-community-id",
      "REL-01.list-seed-absent-when-equal",
      "REL-01.list-seed-cosmetics-from-current",
      "REL-01.list-snapshot-membership-subset",
      "REL-01.list-snapshot-merge-order",
      "REL-01.list-unknown-fields-codec",
      "REL-01.list-tombstone-wins-omit-entry",
      "REL-01.list-liveness-newest-wins",
      "REL-01.list-count-governs-newest-larger-wins",
      "REL-01.list-scoped-write-one-fragment",
      "REL-01.list-lowering-empties-dropped",
      "REL-01.list-event-ceiling",
      "REL-01.list-no-shed-for-ceiling",
      "REL-01.list-shrink-exempt",
      "REL-01.list-pack-target",
    ];
    const residual = ["REL-01.list-capture-keys-before-leave"];
    for (const id of [...covered, ...residual]) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, found: entry !== undefined }).toEqual({ id, found: true });
      expect(entry!.requirement).toBe("REL-01");
      expect(entry!.phase).toBe(6);
      expect(entry!.spec).toBe("CORD-02 §8");
      if (covered.includes(id)) {
        expect(entry!.status).toBe("covered");
        expect(entry!.tests.length).toBeGreaterThan(0);
      } else {
        expect(entry!.status).toBe("residual");
        expect(entry!.residual?.trim().length).toBeGreaterThan(0);
        expect(entry!.tests).toEqual([]);
      }
    }
    // The sweep rows are exactly these: a new REL-01.list-* row must be added here with its mapping.
    const swept = CONFORMANCE_LEDGER.filter((entry) => entry.id.startsWith("REL-01.list-")).map((entry) => entry.id);
    expect(swept.sort()).toEqual([...covered, ...residual].sort());
    // Only the pack target is a covered SHOULD; every other covered sweep row is a MUST.
    for (const id of covered) {
      const level = CONFORMANCE_LEDGER.find((entry) => entry.id === id)!.level;
      expect(level).toBe(id === "REL-01.list-pack-target" ? "SHOULD" : "MUST");
    }
  });

  it("the ledger maps the CORD-04 §7 rules of the Phase 6 spec sweep", () => {
    const covered = [
      "REL-01.pin-invalid-entry-dropped",
      "REL-01.pin-wrap-hint-untrusted",
      "REL-01.pin-edit-bundle-verified",
      "REL-01.pin-violating-edition-empty-list",
      "REL-01.pin-writer-form-follows-channel-type",
    ];
    // D-19: the moderation suppression SHOULD is implemented (hidden unless showBanned) and cites tests.
    const coveredShould = ["REL-01.pin-moderation-suppression"];
    const residual = ["REL-01.pin-remaining-budget"];
    for (const id of [...covered, ...coveredShould, ...residual]) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, found: entry !== undefined }).toEqual({ id, found: true });
      expect(entry!.requirement).toBe("REL-01");
      expect(entry!.phase).toBe(6);
      expect(entry!.spec).toBe("CORD-04 §7");
      if (covered.includes(id)) {
        expect(entry!.status).toBe("covered");
        expect(entry!.level).toBe("MUST");
        expect(entry!.tests.length).toBeGreaterThan(0);
      } else if (coveredShould.includes(id)) {
        expect(entry!.status).toBe("covered");
        expect(entry!.level).toBe("SHOULD");
        expect(entry!.tests.length).toBeGreaterThan(0);
      } else {
        expect(entry!.status).toBe("residual");
        expect(entry!.level).toBe("SHOULD");
        expect(entry!.residual?.trim().length).toBeGreaterThan(0);
        expect(entry!.tests).toEqual([]);
      }
    }
    // The sweep rows are exactly these: a new REL-01.pin-* row must be added here with its mapping.
    const swept = CONFORMANCE_LEDGER.filter((entry) => entry.id.startsWith("REL-01.pin-")).map((entry) => entry.id);
    expect(swept.sort()).toEqual([...covered, ...coveredShould, ...residual].sort());
    // The sweep did not remove the Phase 2 pin rows it leans on (the two PIN-10 residuals stay recorded).
    for (const id of ["PIN-10.bounded-pin-backlog", "PIN-10.compaction-omits-deleted-channel-pins"]) {
      expect(CONFORMANCE_LEDGER.find((entry) => entry.id === id)?.status).toBe("residual");
    }
  });

  it("the ledger maps the CORD-08 rules of the Phase 6 spec sweep", () => {
    const covered = [
      { id: "REL-01.exp-malformed-timer-off", spec: "CORD-08 §1", level: "MUST" },
      { id: "REL-01.exp-notice-gated", spec: "CORD-08 §4", level: "MUST" },
      { id: "REL-01.exp-timer-notice", spec: "CORD-08 §4", level: "SHOULD" },
    ];
    for (const { id, spec, level } of covered) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, found: entry !== undefined }).toEqual({ id, found: true });
      expect(entry!.requirement).toBe("REL-01");
      expect(entry!.phase).toBe(6);
      expect(entry!.spec).toBe(spec);
      expect(entry!.level).toBe(level);
      expect(entry!.status).toBe("covered");
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
    // The sweep rows are exactly these: a new REL-01.exp-* row must be added here with its mapping.
    const swept = CONFORMANCE_LEDGER.filter((entry) => entry.id.startsWith("REL-01.exp-")).map((entry) => entry.id);
    expect(swept.sort()).toEqual(covered.map((entry) => entry.id).sort());
    // The options type is pinned by its own row, so EXP-03.client-fan-out is judged by its behavior tests alone.
    const options = CONFORMANCE_LEDGER.find((entry) => entry.id === "EXP-03.options-type-only");
    expect({ status: options?.status, level: options?.level, phase: options?.phase }).toEqual({
      status: "covered",
      level: "MUST",
      phase: 6,
    });
    expect(options!.tests.every((test) => test.file === "__tests__/index.test.ts")).toBe(true);
    const fanOut = CONFORMANCE_LEDGER.find((entry) => entry.id === "EXP-03.client-fan-out")!;
    expect(fanOut.tests.some((test) => test.file === "__tests__/index.test.ts")).toBe(false);
    // The sweep did not remove the Phase 4 rows it leans on: the host-swept and app-store residuals stay recorded.
    for (const id of ["EXP-01.host-swept", "EXP-04.app-store-nip40"]) {
      expect(CONFORMANCE_LEDGER.find((entry) => entry.id === id)?.status).toBe("residual");
    }
  });

  it("the ledger maps the CORD-03 rules of the Phase 6 spec sweep", () => {
    // The two sweep rows (the channel and epoch binding of section 3), each a covered MUST citing tests.
    const swept = [
      "REL-01.forum-binding-commit",
      "REL-01.forum-binding-drop",
    ];
    for (const id of swept) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, found: entry !== undefined }).toEqual({ id, found: true });
      expect(entry!.requirement).toBe("REL-01");
      expect(entry!.phase).toBe(6);
      expect(entry!.spec).toBe("CORD-03 §3");
      expect(entry!.level).toBe("MUST");
      expect(entry!.status).toBe("covered");
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
    // The sweep rows are exactly these: a new REL-01.forum-* row must be added here with its mapping.
    const found = CONFORMANCE_LEDGER.filter((entry) => entry.id.startsWith("REL-01.forum-")).map((entry) => entry.id);
    expect(found.sort()).toEqual([...swept].sort());
    // Every row id the A8 spec rule map names exists: the Phase 5 forum rows the sweep mapped the section 2 and 3
    // sentences to. The two covered SHOULD rows stay SHOULD and the section's MUST rows stay MUST.
    const phase5 = [
      ["FORUM-01.subject-cap", "MUST", "CORD-03 §3"],
      ["FORUM-02.display-truncation", "MUST", "CORD-03 §3"],
      ["FORUM-03.view-typed", "MUST", "CORD-03 §2"],
      ["FORUM-03.view-preserved", "MUST", "CORD-03 §2"],
      ["FORUM-04.edit-k-tag", "SHOULD", "CORD-03 §3"],
      ["FORUM-05.reply-root-inheritance", "SHOULD", "CORD-03 §3"],
    ] as const;
    for (const [id, level, spec] of phase5) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, level: entry?.level, spec: entry?.spec, status: entry?.status }).toEqual({
        id,
        level,
        spec,
        status: "covered",
      });
    }
    // The receive row cites a test of each route that applies the check, so neither can lose it unnoticed.
    const drop = CONFORMANCE_LEDGER.find((entry) => entry.id === "REL-01.forum-binding-drop")!;
    expect(drop.tests.map((test) => test.file).sort()).toEqual([
      "../e2e/community.forum.test.ts",
      "../e2e/private-channel.test.ts",
      "helpers/__tests__/chat.test.ts",
    ]);
  });

  it("the ledger maps the CORD-04 §4 rules of the Phase 6 spec sweep", () => {
    // The sweep rows: who may ban, whom, what a banned npub loses and how the Banlist edition folds. Each is a covered
    // MUST of the registered section it comes from, citing tests.
    const swept = [
      ["REL-01.ban-signer-holds-ban", "CORD-04 §4"],
      ["REL-01.ban-strict-outrank", "CORD-04 §3"],
      ["REL-01.ban-owner-unbannable", "CORD-04 §2"],
      ["REL-01.ban-drops-authority-actions", "CORD-04 §4"],
      ["REL-01.ban-drops-chat-events", "CORD-04 §4"],
      ["REL-01.ban-member-vanishes", "CORD-04 §4"],
      ["REL-01.ban-head-replaces-list", "CORD-04 §4"],
      ["REL-01.ban-same-version-converges", "CORD-04 §4"],
      ["REL-01.ban-derived-coordinate", "CORD-04 §4"],
      ["REL-01.ban-wire-lowercase-hex", "CORD-04 §4"],
    ] as const;
    for (const [id, spec] of swept) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, found: entry !== undefined }).toEqual({ id, found: true });
      expect(entry!.requirement).toBe("REL-01");
      expect(entry!.phase).toBe(6);
      expect(entry!.spec).toBe(spec);
      expect(entry!.level).toBe("MUST");
      expect(entry!.status).toBe("covered");
      expect(entry!.tests.length).toBeGreaterThan(0);
    }
    // The sweep rows are exactly these: a new REL-01.ban-* row must be added here with its mapping.
    const found = CONFORMANCE_LEDGER.filter((entry) => entry.id.startsWith("REL-01.ban-")).map((entry) => entry.id);
    expect(found.sort()).toEqual(swept.map(([id]) => id).sort());
    // Every row id the A9 spec rule map names exists with the level the sweep recorded: the Phase 5 rows the Banlist
    // sentences were mapped to, the covered SHOULD rows that stay SHOULD, and the three residual rows with their reasons.
    const mapped = [
      ["BAN-01.validated-first", "MUST", "covered"],
      ["BAN-01.single-edition", "SHOULD", "covered"],
      ["BAN-01.shared-refounding", "SHOULD", "covered"],
      ["BAN-02.rate-limited", "SHOULD", "covered"],
      ["BAN-02.serialized", "MUST", "covered"],
      ["BAN-03.reheal-lost-sibling", "SHOULD", "covered"],
      ["BAN-05.concurrent-writers", "SHOULD", "covered"],
      ["DEC-04.fallback-no-republish", "MUST", "covered"],
      ["DEC-04.republish-surviving-list", "SHOULD", "residual"],
      ["BAN-03.pre-refounding-loss", "SHOULD", "residual"],
      ["BAN-03.restart-scope", "SHOULD", "residual"],
    ] as const;
    for (const [id, level, status] of mapped) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
      expect({ id, level: entry?.level, status: entry?.status }).toEqual({ id, level, status });
      if (status === "residual") expect(entry!.residual?.trim().length).toBeGreaterThan(0);
    }
    // The new rows cite the fold-level tests, so a writer-only test can no longer stand in for the receive side.
    const authority = CONFORMANCE_LEDGER.find((entry) => entry.id === "REL-01.ban-drops-authority-actions")!;
    expect(authority.tests.map((test) => test.file)).toEqual(["helpers/__tests__/banlist.test.ts"]);
    const chat = CONFORMANCE_LEDGER.find((entry) => entry.id === "REL-01.ban-drops-chat-events")!;
    expect(chat.tests.map((test) => test.file)).toContain("models/__tests__/chat.test.ts");
  });

  it("the ledger covers the CORD-02 Appendix B NIP-44 cap at every layer (D-18)", () => {
    const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === "REL-01.envelope-nip44-cap");
    expect({ status: entry?.status, phase: entry?.phase, level: entry?.level, spec: entry?.spec }).toEqual({
      status: "covered",
      phase: 6,
      level: "MUST",
      spec: "CORD-02 Appendix B",
    });
    // Each layer the rule names has its own boundary test: rumor, seal and wrap, the self-encrypted lists and the
    // invite bundle.
    expect(entry!.tests.map((test) => test.name)).toEqual([
      "enforces 65535/65536 UTF-8 bytes on plaintext and encrypted rumor layers before signing",
      "enforces the serialized seal boundary for wraps, rewraps and strict readers",
      "caps both self-encrypted list operation boundaries without shedding unknown fields",
      "caps encrypted invite bundle plaintext on write and read",
    ]);
    for (const test of entry!.tests) expect(test.file).toBe("operations/__tests__/gift-wrap.conformance.test.ts");
    // An envelope rule outside the A3 to A9 sweep groups: proven by its cited tests, not by the mutation sweep.
    expect(sweepGroupOf(entry!)).toBeUndefined();
  });

  it("every covered ledger entry names tests that exist", () => {
    expect(ledgerProblems(CONFORMANCE_LEDGER, read, 6)).toEqual([]);
  });

  it("planned ledger entries belong to a later phase", () => {
    expect(ledgerProblems([synthetic({ status: "planned", tests: [], phase: 1 })], read, 1)).toHaveLength(1);
    expect(ledgerProblems([synthetic({ status: "planned", tests: [], phase: 3 })], read, 1)).toEqual([]);
  });

  it("residual ledger entries state why they are accepted", () => {
    const noReason = ledgerProblems([synthetic({ status: "residual", tests: [] })], read, 2);
    expect(noReason).toHaveLength(1);
    expect(noReason[0]).toContain("reason");
    expect(ledgerProblems([synthetic({ status: "residual", residual: "   ", tests: [] })], read, 2)).toHaveLength(1);
    expect(ledgerProblems([synthetic({ status: "residual", residual: "accepted: reason", tests: [] })], read, 2))
      .toEqual([]);
    // Residual entries are not covered by tests, so naming one is a mistake the guard must catch.
    const withTests = ledgerProblems([synthetic({ status: "residual", residual: "accepted: reason" })], read, 2);
    expect(withTests).toHaveLength(1);
    expect(withTests[0]).toContain("cite no tests");
    // A residual entry is valid at any phase, including the current one.
    expect(
      ledgerProblems([synthetic({ status: "residual", residual: "accepted: reason", tests: [], phase: 2 })], read, 2),
    )
      .toEqual([]);
  });

  it("the checker rejects a ledger entry whose test name is missing", () => {
    const entry = synthetic({
      tests: [{ file: "__tests__/conformance-ledger.test.ts", name: "a test that does not exist" }],
    });
    expect(ledgerProblems([entry], read, 1)).toHaveLength(1);
  });

  it("every ledger citation names a registered CORD section", () => {
    for (const entry of CONFORMANCE_LEDGER) {
      if (entry.spec) expect(citationsOutsideRegistry(entry.spec)).toEqual([]);
    }
  });
});
