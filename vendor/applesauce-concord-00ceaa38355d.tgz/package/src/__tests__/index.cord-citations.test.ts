// Check source citations against the vendored CORD section registry.
// This proves a section exists, not that it supports the cited claim.

/// <reference lib="deno.ns" />
// Test-only: `deno.json` sets `lib` to ES2022+DOM without `deno.ns`, so library
// source cannot reach for Deno APIs and stays browser-safe. This file is a test
// guard that must read the source tree, so it opts into the Deno namespace here
// rather than widening `lib` for all of `src/`.

import { dirname, fromFileUrl, join } from "@std/path";

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { citationsOutsideRegistry, CORD_SECTIONS } from "./cord-wire-fixtures.ts";

// Resolved from this file's own module URL, never from process.cwd(), so the
// scan root does not depend on the working directory. The suite runs under
// `deno test` from the repository root.
const SELF = fromFileUrl(import.meta.url);
const SRC_ROOT = join(dirname(SELF), "..");
const SCAN_ROOTS = [SRC_ROOT, join(SRC_ROOT, "..", "e2e")];

// Exclude the scanner tests because they contain deliberately invalid citations.
const FIXTURE_SELF_TEST = join(dirname(SELF), "cord-wire-fixtures.test.ts");

/**
 * Recursively collects every `.ts` file under `dir`, including test and
 * fixture files (those carry valid citations too, e.g. the `CORD-01
 * §Deletions` sites in `cord-wire-fixtures.ts` and
 * `helpers/__tests__/keys.test.ts` — a guard that skipped tests would leave
 * those unguarded). The only exclusions are this guard's own file and
 * `cord-wire-fixtures.test.ts` (see comment above).
 */
function collectTsFiles(dir: string): string[] {
  const out: string[] = [];
  for (const entry of Deno.readDirSync(dir)) {
    const full = join(dir, entry.name);
    if (entry.isDirectory) out.push(...collectTsFiles(full));
    else if (entry.name.endsWith(".ts") && full !== SELF && full !== FIXTURE_SELF_TEST) out.push(full);
  }
  return out;
}

// A citation-shaped pattern used ONLY to independently count how many
// citations were encountered during the walk — computed without going
// through citationsOutsideRegistry's own valid/invalid filtering, so the
// file-count floor and this count cannot both be zero unnoticed (the second
// anti-vacuity assertion, alongside the file-count floor below).
const CITATION_COUNT_PATTERN = /CORD-\d{2} §[A-Za-z0-9][A-Za-z0-9-]*(?: [A-Z][A-Za-z0-9-]*)*/g;

describe("CORD section citation guard (WIRE-12/D-16)", () => {
  it("scans well over fifty .ts files under packages/concord/src (anti-vacuity: a broken glob cannot pass silently)", () => {
    const files = SCAN_ROOTS.flatMap(collectTsFiles);
    expect(files.length).toBeGreaterThan(50);
  });

  it("encountered at least one valid CORD-NN §X citation during the walk (anti-vacuity: a scanner matching nothing cannot pass silently)", () => {
    const files = SCAN_ROOTS.flatMap(collectTsFiles);
    let totalCitationMatches = 0;
    for (const file of files) {
      const text = Deno.readTextFileSync(file);
      totalCitationMatches += [...text.matchAll(CITATION_COUNT_PATTERN)].length;
    }
    expect(totalCitationMatches).toBeGreaterThan(0);
  });

  it("every CORD-NN §X citation in packages/concord/src names a section that exists", () => {
    const files = SCAN_ROOTS.flatMap(collectTsFiles);
    const offenders: string[] = [];

    for (const file of files) {
      const text = Deno.readTextFileSync(file);
      for (const citation of citationsOutsideRegistry(text)) {
        offenders.push(`${file}: ${citation}`);
      }
    }

    // On failure, the assertion output enumerates every offending
    // file-plus-citation pair, so a future contributor sees which file and
    // which citation without re-running anything.
    expect(offenders).toEqual([]);
  });

  it("the registry itself accepts CORD-01's named sections and CORD-05's numeric range endpoints", () => {
    // Confirms the import actually resolved to a populated registry, not an
    // empty object a typo'd import path could silently produce.
    expect(CORD_SECTIONS["CORD-01"]).toContain("Deletions");
    expect(CORD_SECTIONS["CORD-05"]).toContain("1");
    expect(CORD_SECTIONS["CORD-05"]).toContain("2");
  });
});
