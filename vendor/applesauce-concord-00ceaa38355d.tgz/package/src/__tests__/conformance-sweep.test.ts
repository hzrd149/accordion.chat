// Unit tests for the pure helpers of the REL-01 sweep runner (conformance-sweep.ts). The runner itself mutates only
// scratch clones and is never run by `deno task test`; these tests import its helpers, which need no permissions.
// The JUnit fixtures are shaped on real `deno test --reporter=junit` output captured inside a scratch clone: a BDD
// describe is one top-level testcase, each `it` is a `<describe> > <it>` testcase, an assertion failure sits on the step,
// a sanitizer leak sits on the top-level testcase, and a module-link failure produces no testcases at all.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import type { LedgerEntry, LedgerTestRef } from "./conformance-ledger.ts";
import type { GuardMutation, MutationExemption } from "./conformance-mutations.ts";
import {
  applyMutation,
  enclosingDescribe,
  filterArg,
  groupCoverage,
  type JunitCase,
  parseJunit,
  rowVerdict,
  type SweepResults,
  verdictEntries,
} from "./conformance-sweep.ts";

const ASSERT_XML = `<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="deno test" tests="6" failures="2" errors="0" time="0.063">
    <testsuite name="./src/helpers/__tests__/permissions.test.ts" tests="1" disabled="0" errors="0" failures="1">
        <testcase name="permissions" classname="./src/helpers/__tests__/permissions.test.ts" time="0.054" line="49" col="1">
            <failure message="1 test step failed">1 test step failed.</failure>
        </testcase>
    </testsuite>
    <testsuite name="ext:cli/40_test.js" tests="1" disabled="0" errors="0" failures="0">
        <testcase name="permissions &gt; parses and tests bits" classname="ext:cli/40_test.js" time="0.001" line="239" col="28">
        </testcase>
    </testsuite>
    <testsuite name="https://jsr.io/@std/testing/1.0.20/_test_suite.ts" tests="2" disabled="0" errors="0" failures="1">
        <testcase name="permissions &gt; a &amp; b &quot;q&quot; &apos;s&apos; &lt;t&gt;" classname="https://jsr.io/@std/testing/1.0.20/_test_suite.ts" time="0.000" line="415" col="15"/>
        <testcase name="permissions &gt; ADMIN_PERMS deliberately omits PIN_MESSAGES (PIN-11)" classname="https://jsr.io/@std/testing/1.0.20/_test_suite.ts" time="0.001" line="415" col="15">
            <failure message="Uncaught AssertionError: Values are not strictly equal.

    [Diff] Actual / Expected

-   2048n
+   0n
">AssertionError: Values are not strictly equal.

    at Proxy.&lt;anonymous&gt; (https://jsr.io/@std/expect/1.0.20/expect.ts:241:13)</failure>
        </testcase>
    </testsuite>
</testsuites>
`;

const LEAK_XML = `<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="deno test" tests="3" failures="1" errors="0" time="0.027">
    <testsuite name="./src/helpers/__tests__/zz-leak.test.ts" tests="1" disabled="0" errors="0" failures="1">
        <testcase name="leaky" classname="./src/helpers/__tests__/zz-leak.test.ts" time="0.018" line="2" col="1">
            <failure message="Leaks detected">Leaks detected:
  - A timer was started in this test, but never completed. This is often caused by not calling \`clearTimeout\`.
To get more details where leaks occurred, run again with the --trace-leaks flag.</failure>
        </testcase>
    </testsuite>
    <testsuite name="ext:cli/40_test.js" tests="1" disabled="0" errors="0" failures="0">
        <testcase name="leaky &gt; leaks a timer" classname="ext:cli/40_test.js" time="0.016" line="239" col="28">
        </testcase>
    </testsuite>
</testsuites>
`;

// A module-link failure ("does not provide an export named") loads no test file, so deno emits no testcases at all.
const LINK_XML = `<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="deno test" tests="0" failures="0" errors="0" time="0.007">
</testsuites>
`;

const PERMS = "helpers/__tests__/permissions.test.ts";
const PIN_11: LedgerTestRef = { file: PERMS, name: "ADMIN_PERMS deliberately omits PIN_MESSAGES (PIN-11)" };
const ASSERTION = "Uncaught AssertionError: Values are not strictly equal.";

const pass = (name: string, file?: string): JunitCase => ({ name, ...(file ? { file } : {}) });
const fail = (name: string, failure: string, file?: string): JunitCase => ({
  name,
  failure,
  ...(file ? { file } : {}),
});

describe("conformance sweep verdicts (REL-01)", () => {
  it("applyMutation replaces exactly one occurrence per site", () => {
    const mutation: GuardMutation = {
      id: "m",
      group: "A5",
      rows: [],
      sites: [
        { file: "a.ts", find: "one", replace: "uno" },
        { file: "b.ts", find: "red", replace: "rojo" },
        { file: "a.ts", find: "uno two", replace: "dos" },
      ],
      note: "synthetic",
    };
    const texts = { "a.ts": "one two three", "b.ts": "red green" };
    expect(applyMutation(texts, mutation)).toEqual({ "a.ts": "dos three", "b.ts": "rojo green" });
    // The input is not modified, and a replacement is literal ("$&" must not expand).
    expect(texts["a.ts"]).toBe("one two three");
    const dollar: GuardMutation = { ...mutation, sites: [{ file: "a.ts", find: "one", replace: "$&$&" }] };
    expect(applyMutation(texts, dollar)["a.ts"]).toBe("$&$& two three");

    const one = (find: string, file = "a.ts"): GuardMutation => ({
      ...mutation,
      sites: [{ file, find, replace: "x" }],
    });
    expect(() => applyMutation(texts, one("absent"))).toThrow();
    expect(() => applyMutation({ "a.ts": "aa" }, one("a"))).toThrow();
    expect(() => applyMutation(texts, one("one", "missing.ts"))).toThrow();
  });

  it("enclosingDescribe finds the top-level describe of a cited test", () => {
    const text = [
      'describe("outer one", () => {',
      '  it("first", () => {});',
      '  describe("nested", () => {',
      '    it("deep", () => {});',
      "  });",
      "});",
      "",
      'it("top-level it", () => {});',
      'Deno.test("top-level test", () => {});',
      'describe("outer two", () => {',
      '  it("second", () => {});',
      "});",
      "",
    ].join("\n");
    expect(enclosingDescribe(text, "first")).toBe("outer one");
    expect(enclosingDescribe(text, "deep")).toBe("outer one");
    expect(enclosingDescribe(text, "nested")).toBe("outer one");
    expect(enclosingDescribe(text, "second")).toBe("outer two");
    expect(enclosingDescribe(text, "outer one")).toBe("outer one");
    expect(enclosingDescribe(text, "top-level it")).toBe("top-level it");
    expect(enclosingDescribe(text, "top-level test")).toBe("top-level test");
    expect(enclosingDescribe(text, "absent")).toBeUndefined();
  });

  it("filterArg matches names literally", () => {
    expect(filterArg(["a", "b"])).toBe("/^(?:a|b)$/");
    const arg = filterArg(["a.b (c) [d] x/y", "e|f+"]);
    const pattern = new RegExp(arg.slice(1, -1));
    expect(pattern.test("a.b (c) [d] x/y")).toBe(true);
    expect(pattern.test("e|f+")).toBe(true);
    expect(pattern.test("aXb (c) [d] x/y")).toBe(false);
    expect(pattern.test("e")).toBe(false);
    expect(pattern.test("prefix a.b (c) [d] x/y")).toBe(false);
  });

  it("parseJunit reads testcases and unescapes names", () => {
    const cases = parseJunit(ASSERT_XML);
    expect(cases.map((c) => c.name)).toEqual([
      "permissions",
      "permissions > parses and tests bits",
      `permissions > a & b "q" 's' <t>`,
      "permissions > ADMIN_PERMS deliberately omits PIN_MESSAGES (PIN-11)",
    ]);
    expect(cases[0].failure).toContain("1 test step failed");
    expect(cases[1].failure).toBeUndefined();
    expect(cases[2].failure).toBeUndefined();
    expect(cases[3].failure).toContain("AssertionError");
    expect(cases[3].failure).toContain("Proxy.<anonymous>");
    expect(parseJunit(LEAK_XML).map((c) => c.name)).toEqual(["leaky", "leaky > leaks a timer"]);
    expect(parseJunit(LEAK_XML)[0].failure).toContain("Leaks detected");
    expect(parseJunit(LINK_XML)).toEqual([]);
  });

  it("rowVerdict finds a cited test whose own name contains ' > '", () => {
    // The junit name joins describe and test with ' > ', so a test named "b > a" must still be found by its whole name.
    const ref = { file: PERMS, name: "resumes with b > a sorted" };
    expect(rowVerdict([fail("d > resumes with b > a sorted", "AssertionError: x")], [ref]).verdict).toBe("killed");
    expect(rowVerdict([pass("d > resumes with b > a sorted")], [ref]).verdict).toBe("survived");
    expect(rowVerdict([pass("d > resumes with b")], [ref]).verdict).toBe("invalid");
    // A describe citation still covers its steps, and a bare top-level name still matches.
    expect(
      rowVerdict([fail("d > resumes with b > a sorted", "AssertionError: x")], [{ file: PERMS, name: "d" }]).verdict,
    )
      .toBe("killed");
    expect(rowVerdict([pass("resumes with b > a sorted")], [ref]).verdict).toBe("survived");
  });

  it("rowVerdict separates killed, leak, invalid and survived rows", () => {
    // Killed: the cited step fails with an assertion (the describe's own "1 test step failed" is only a summary).
    const killed = rowVerdict(parseJunit(ASSERT_XML), [PIN_11]);
    expect(killed.verdict).toBe("killed");
    expect(killed.failing).toBe("permissions > ADMIN_PERMS deliberately omits PIN_MESSAGES (PIN-11)");

    // Survived: every matching case passed, even though a sibling failed.
    const sibling = rowVerdict(parseJunit(ASSERT_XML), [{ file: PERMS, name: "parses and tests bits" }]);
    expect(sibling.verdict).toBe("survived");

    // A describe citation is killed by any assertion failing underneath it.
    expect(rowVerdict(parseJunit(ASSERT_XML), [{ file: PERMS, name: "permissions" }]).verdict).toBe("killed");

    // Leak: the cited step passed, but the sanitizer failed its describe.
    expect(rowVerdict(parseJunit(LEAK_XML), [{ file: "x.test.ts", name: "leaks a timer" }]).verdict).toBe("leak");

    // Invalid: nothing ran (a module-link failure loads no testcases), the filter matched nothing, or the failure is not
    // an assertion (link, syntax, type and plain thrown errors).
    expect(rowVerdict(parseJunit(LINK_XML), [PIN_11]).verdict).toBe("invalid");
    expect(rowVerdict(parseJunit(ASSERT_XML), [{ file: PERMS, name: "never ran" }]).verdict).toBe("invalid");
    const bad = (message: string): string => rowVerdict([fail("d > t", message)], [{ file: PERMS, name: "t" }]).verdict;
    expect(bad("SyntaxError: Unexpected token")).toBe("invalid");
    expect(bad("TS2305 [ERROR]: Module has no exported member")).toBe("invalid");
    expect(bad("TypeError: Module not found")).toBe("invalid");
    expect(bad("SyntaxError: The requested module './x.ts' does not provide an export named 'y'")).toBe("invalid");
    expect(bad("Uncaught Error: boom")).toBe("invalid");

    // A passing case matches and nothing else failed.
    expect(rowVerdict([pass("d > t")], [{ file: PERMS, name: "t" }]).verdict).toBe("survived");

    // Export-pinned rows are killed only by an assertion in an index.test.ts case, never by another cited file.
    const EXPORTS = "__tests__/index.test.ts";
    const refs: LedgerTestRef[] = [{ file: EXPORTS, name: "pinned" }, { file: PERMS, name: "t" }];
    const elsewhere = [fail("d > t", ASSERTION, PERMS), pass("e > pinned", EXPORTS)];
    expect(rowVerdict(elsewhere, refs).verdict).toBe("survived");
    const inExports = [pass("d > t", PERMS), fail("e > pinned", ASSERTION, EXPORTS)];
    expect(rowVerdict(inExports, refs).verdict).toBe("killed");
    // A non-assertion failure in index.test.ts is not a kill either.
    expect(rowVerdict([fail("e > pinned", "SyntaxError: x", EXPORTS)], refs).verdict).toBe("invalid");
    // Without the exports case there is nothing to judge.
    expect(rowVerdict([fail("d > t", ASSERTION, PERMS)], refs).verdict).toBe("invalid");
  });

  // The coverage fixtures: group A5 holds six covered MUST rows, one covered SHOULD row and one out-of-group row.
  const entry = (id: string, overrides: Partial<LedgerEntry> = {}): LedgerEntry => ({
    id,
    requirement: "PIN-99",
    level: "MUST",
    rule: "synthetic",
    phase: 6,
    status: "covered",
    tests: [{ file: PERMS, name: "t" }],
    ...overrides,
  });
  const ledger: LedgerEntry[] = [
    entry("PIN-99.r1"),
    entry("PIN-99.r2"),
    entry("PIN-99.r3"),
    entry("PIN-99.r4"),
    entry("PIN-99.r5"),
    entry("PIN-99.r6"),
    entry("PIN-99.should", { level: "SHOULD" }),
    entry("BAN-99.other", { requirement: "BAN-99" }),
  ];
  const mutations: GuardMutation[] = [
    {
      id: "m1",
      group: "A5",
      rows: ["PIN-99.r1", "PIN-99.r2", "PIN-99.r3", "PIN-99.r4", "PIN-99.r6"],
      sites: [],
      note: "n",
    },
    { id: "m2", group: "A5", rows: ["PIN-99.r5", "PIN-99.r6"], sites: [], note: "n" },
  ];
  const digests = { m1: "d1", m2: "d2" };
  const exemptions: MutationExemption[] = [{ row: "PIN-99.r2", reason: "reason", approval: "approval" }];
  const result = (
    id: string,
    digest: string,
    rows: Record<string, "killed" | "survived">,
  ): SweepResults["results"][number] => ({
    id,
    group: "A5",
    digest,
    sites: [],
    note: "n",
    durationMs: 1,
    rows: Object.entries(rows).map(([row, verdict]) => ({
      row,
      verdict,
      failing: verdict === "killed" ? `d > ${row}` : "",
    })),
  });
  const file = (
    finishedAt: string,
    cloneHead: string,
    results: SweepResults["results"],
    confirmed = true,
  ): SweepResults => ({
    runner: "conformance-sweep.ts",
    startedAt: finishedAt,
    finishedAt,
    cloneHead,
    confirmed,
    groups: [],
    ids: [],
    results,
  });
  const HEAD_A = "a".repeat(40);
  const HEAD_B = "b".repeat(40);
  const files: SweepResults[] = [
    file("2026-01-01T00:00:00.000Z", HEAD_A, [
      // r2 is exempt, so even a recorded kill cannot count.
      result("m1", "d1", {
        "PIN-99.r1": "killed",
        "PIN-99.r2": "killed",
        "PIN-99.r4": "survived",
        "PIN-99.r6": "killed",
      }),
      // Stale: recorded for a mutation whose sites have since changed.
      result("m2", "old", { "PIN-99.r5": "killed" }),
    ]),
    // A newer run of m1 supersedes the older run of the same mutation for r6, but m2 has no current result for it.
    file("2026-02-01T00:00:00.000Z", HEAD_B, [result("m1", "d1", { "PIN-99.r6": "survived" })]),
    // Unconfirmed kills never count.
    file("2026-03-01T00:00:00.000Z", HEAD_B, [result("m1", "d1", { "PIN-99.r3": "killed" })], false),
  ];

  it("groupCoverage counts exempt rows as missing and ignores stale results", () => {
    const coverage = groupCoverage("A5", files, ledger, mutations, exemptions, digests);
    // r2: exempt; r3: only an unconfirmed kill; r5: only a stale kill. r4 survived; r6's newest run survived.
    expect(coverage.missing).toEqual(["PIN-99.r2", "PIN-99.r3", "PIN-99.r5"]);
    expect(coverage.notKilled).toEqual(["PIN-99.r4", "PIN-99.r6"]);

    // Once a second current mutation kills r6, the row is covered; an exemption still never passes.
    const second = file("2026-04-01T00:00:00.000Z", HEAD_B, [
      result("m2", "d2", { "PIN-99.r5": "killed", "PIN-99.r6": "killed" }),
    ]);
    const after = groupCoverage("A5", [...files, second], ledger, mutations, exemptions, digests);
    expect(after.missing).toEqual(["PIN-99.r2", "PIN-99.r3"]);
    expect(after.notKilled).toEqual(["PIN-99.r4"]);
    // Rows of other groups and SHOULD rows are not required.
    expect(groupCoverage("A9", files, ledger, mutations, [], digests).missing).toEqual(["BAN-99.other"]);
  });

  it("verdictEntries prints current confirmed kills", () => {
    const second = file("2026-04-01T00:00:00.000Z", HEAD_B, [
      result("m2", "d2", { "PIN-99.r5": "killed", "PIN-99.r6": "killed" }),
    ]);
    const entries = verdictEntries("A5", [...files, second], ledger, mutations, exemptions, digests);
    expect(entries).toEqual([
      { row: "PIN-99.r1", verdict: "killed", mutation: "m1", digest: "d1", failing: "d > PIN-99.r1", sweptAt: HEAD_A },
      { row: "PIN-99.r5", verdict: "killed", mutation: "m2", digest: "d2", failing: "d > PIN-99.r5", sweptAt: HEAD_B },
      { row: "PIN-99.r6", verdict: "killed", mutation: "m2", digest: "d2", failing: "d > PIN-99.r6", sweptAt: HEAD_B },
    ]);
    // Nothing is printed for exempt, stale, unconfirmed or surviving rows.
    expect(verdictEntries("A5", files, ledger, mutations, exemptions, digests).map((e) => e.row)).toEqual([
      "PIN-99.r1",
    ]);
  });
});
