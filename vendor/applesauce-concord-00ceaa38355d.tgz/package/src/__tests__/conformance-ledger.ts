// Starts the REL-01 MUST/SHOULD conformance ledger (D-20). Each entry maps one rule of the
// library or of a CORD section to the tests that prove it, and `ledgerProblems` fails when a
// referenced test no longer exists. Test names must be static string literals in their `it(...)`
// or `describe(...)` call (the guard searches the file text), so never build them dynamically.
// Phase 1, Phase 2, Phase 3, Phase 4 (disappearing-message), Phase 5 (forum, Banlist and banned-pinner) and Phase 6
// (CORD-07 key derivation and the CORD-02 §8 spec sweep) rules are recorded; later phases append their own entries.

/** One test the ledger cites; `file` is relative to `src/`. */
export interface LedgerTestRef {
  /** Path relative to `src/`, for example `client/__tests__/lifecycle.test.ts` or `../e2e/community.test.ts`. */
  file: string;
  /** The exact static name passed to `it`, `describe` or `Deno.test`. */
  name: string;
}

/** One MUST/SHOULD rule and the tests that prove it. */
export interface LedgerEntry {
  /** Stable id, `<REQUIREMENT>.<rule>`. */
  id: string;
  /** The v1 requirement id, such as `FND-01`. */
  requirement: string;
  /** The CORD section the rule comes from, such as `CORD-02 §8`; absent for library rules. */
  spec?: string;
  /** RFC 2119 strength of the rule. */
  level: "MUST" | "SHOULD";
  /** A short plain-language paraphrase of the rule. */
  rule: string;
  /** Phase in which the entry is (to be) covered. */
  phase: number;
  /**
   * `covered` entries must name existing tests; `planned` entries belong to a later phase; `residual` entries are rules
   * this release deliberately does not implement, accepted as residual risk: they cite no tests and must state why.
   */
  status: "covered" | "planned" | "residual";
  /** Why the rule is accepted as residual risk; required (non-blank) when `status` is `residual`. */
  residual?: string;
  /** The proving tests. */
  tests: readonly LedgerTestRef[];
}

const LIFECYCLE = "client/__tests__/lifecycle.test.ts";
const WIRING = "../e2e/lifecycle.wiring.test.ts";
const OFFLINE = "../e2e/client.community-list-offline.test.ts";
const READ = "client/__tests__/community-list-read.test.ts";
const SYNC = "client/__tests__/community-list-sync.test.ts";
const DIAGNOSTICS = "../e2e/diagnostics.test.ts";
const REQUIRED = "../e2e/revocation.required-publish.test.ts";
const LINEAGE = "helpers/__tests__/edition-lineage.test.ts";
const LANE = "client/__tests__/community-list-lane.test.ts";
const MODEL = "../e2e/community-list-sync.model.test.ts";
const MODEL_CORE = "client/__tests__/community-list-model-core.test.ts";
const RUNNER = "client/__tests__/community-list-model-runner.test.ts";
const PIN_PROJECTION = "helpers/__tests__/pin-projection.test.ts";
const EDIT = "helpers/__tests__/edit.test.ts";
const PIN_PROOFS = "helpers/__tests__/pins.test.ts";
const PINS_MODEL = "models/__tests__/pins.test.ts";
const PINS = "../e2e/pins.test.ts";
const UPKEEP = "helpers/__tests__/pin-upkeep.test.ts";
const PERMS = "helpers/__tests__/permissions.test.ts";
const MAINTAINER = "client/__tests__/pin-maintainer.test.ts";
const SEALS = "client/__tests__/pin-edit-seals.test.ts";
const STORE = "client/__tests__/community-list-store.test.ts";
const RESTART = "../e2e/client.community-list-restart.test.ts";
const MEMBERSHIPS = "../e2e/community-list-memberships.test.ts";
const EXTENSIONS = "client/__tests__/community-list-sync.extensions.test.ts";
const EXPORTS = "__tests__/index.test.ts";
const WIRE = "helpers/__tests__/community-list-wire.test.ts";
const LIST_HELPERS = "helpers/__tests__/community-list.test.ts";
const CEILING = "client/__tests__/community-list-sync.ceiling.test.ts";
const PURGE = "../e2e/expiration-purge.test.ts";
const SCHEDULE = "../e2e/expiration-purge.schedule.test.ts";
const EXPIRY = "helpers/__tests__/expiration.test.ts";
const RECEIVE = "client/__tests__/receive.test.ts";
const PRIVATE = "../e2e/private-channel.test.ts";
const SYNC_WALK = "client/__tests__/sync.test.ts";
const CHANNEL_WALK = "client/__tests__/channel-sync.test.ts";
const FORUM_HELPERS = "helpers/__tests__/forum.test.ts";
const FORUM_OPS = "operations/__tests__/channel.forum.test.ts";
const FORUM = "../e2e/community.forum.test.ts";
const FACTORY_EDIT = "factories/__tests__/edit.test.ts";
const FACTORY_MESSAGE = "operations/__tests__/channel.message.test.ts";
const CHAT_HELPERS = "helpers/__tests__/chat.test.ts";
const CHAT_OPS = "operations/__tests__/channel.test.ts";
const BANLIST_HELPERS = "helpers/__tests__/banlist.test.ts";
const BANLIST = "../e2e/banlist.test.ts";
const REHEAL = "../e2e/banlist-reheal.test.ts";
const REHEAL_PLAN = "helpers/__tests__/banlist-reheal.test.ts";
const REFOUND_DISCARD = "../e2e/refounding.discard.test.ts";
const CONTROL = "helpers/__tests__/control.test.ts";
const GUESTBOOK = "helpers/__tests__/guestbook.test.ts";
const EDIT_HELPERS = "helpers/__tests__/edit.test.ts";
const COMMUNITY = "../e2e/community.test.ts";
const MODELS = "models/__tests__/index.test.ts";
const MODELS_CHAT = "models/__tests__/chat.test.ts";
const VOICE_KEYS = "helpers/__tests__/crypto.voice-keys.test.ts";
const ENVELOPE = "operations/__tests__/gift-wrap.conformance.test.ts";

const refs = (file: string, ...names: string[]): LedgerTestRef[] => names.map((name) => ({ file, name }));

/** Both seeded model-based interleaving tests (D-31). */
const MODEL_RUNS = refs(
  MODEL,
  "seeded interleavings with auto-save off keep every Community List invariant (D-31)",
  "seeded interleavings with auto-save on keep every Community List invariant (D-31)",
);

/**
 * Phase 1 rules (all covered, including the gap-closure rules D-31, D-32) and Phase 2 pin-lifecycle rules (covered,
 * plus two CORD-04 §7 SHOULDs recorded as residual risks, and the Phase 2 gap-closure rules D-31, an Edit its author
 * deleted is ignored, and D-32, a message listed more than once is read, upkept and published from its newest bundled
 * Edit), then Phase 3 Community List recovery rules (LIST-03 to LIST-08, covered, plus the new-device single-relay
 * residual risk), then Phase 4 disappearing-message rules (EXP-01 to EXP-06, covered, plus two residual risks: stores the
 * engine cannot reach and the upstream store's own NIP-40 check), then Phase 5 forum post rules (FORUM-01, FORUM-02,
 * FORUM-05, FORUM-06 and DEC-03, covered), then the Phase 5 channel view and edit target kind rules (FORUM-03, FORUM-04,
 * FORUM-06, covered), then the Phase 5 batch ban rules (BAN-01, BAN-02 and the write side of BAN-05, covered), the
 * Phase 5 Banlist re-heal rules (BAN-03, BAN-04, covered), and the Phase 5 closeout (the BAN-05 restart, device, holder,
 * rank and Refounding proofs and the DEC-04 banned-pinner policy, covered, plus three residual risks: the CORD-04 §7
 * surviving-list republish, a ban lost before a Refounding and the restart scope), then the Phase 6 CORD-07 key
 * derivation rule (AV-01, covered), and the Phase 6 CORD-02 §8 spec-sweep rows (REL-01.list-*, covered, plus one SHOULD
 * recorded as a residual risk: capturing a departing Community's keys before a leave), and the Phase 6 CORD-08 spec-sweep
 * rows (REL-01.exp-*, covered: the malformed-timer rule, the timer-notice display gate and the timer-notice SHOULD), and the
 * Phase 6 CORD-03 spec-sweep rows (REL-01.forum-*, covered: the channel and epoch binding on send and on receive), and
 * the Phase 6 CORD-04 §4 spec-sweep rows (REL-01.ban-*, covered: who may ban, whom, what a banned npub loses, and how
 * the Banlist edition folds), and the CORD-02 Appendix B NIP-44 cap at every layer (REL-01.envelope-nip44-cap, covered;
 * an envelope rule outside the A3 to A9 sweep groups, proven by its cited tests and not mutation-swept, D-18).
 */
export const CONFORMANCE_LEDGER: readonly LedgerEntry[] = [
  {
    id: "FND-01.owned-cancellation",
    requirement: "FND-01",
    level: "MUST",
    rule: "Stop, dispose, dissolution and demotion cancel every library-owned timer and retry.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        LIFECYCLE,
        "dispose cancels every armed timer and is idempotent",
        "suspend refuses publication duties but admits local cleanup duties",
        "leaves no pending FakeTime timers after dispose",
        "a disposed real-timer duty leaves nothing for the sanitizer",
      ),
      ...refs(
        WIRING,
        "dissolution suspends community publication duties with zero pending timers",
        "community dispose cancels armed duties with zero pending timers",
        "a folded state change reevaluates duty eligibility",
        "client stop cancels the list-read retry and dispose is terminal",
      ),
    ],
  },
  {
    id: "FND-02.once-per-key",
    requirement: "FND-02",
    level: "MUST",
    rule: "A background duty runs at most once per stable key, within bounded attempts, and reports exhaustion once.",
    phase: 1,
    status: "covered",
    tests: refs(
      LIFECYCLE,
      "coalesces repeated requests for one key into a single run",
      "runs each stable key at most once",
      "retries a failing duty within its budget and reports exhaustion once",
      "stays quiet for an exhausted key until the key changes",
      "a run reads current state at fire time, not at request time",
    ),
  },
  {
    id: "FND-02.fire-time-head",
    requirement: "FND-02",
    level: "MUST",
    rule:
      "A duty re-reads the current head immediately before publishing and never publishes a snapshot taken when it was scheduled.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(OFFLINE, "the held-save retry publishes the state current at fire time, not at scheduling time"),
      ...refs(LIFECYCLE, "a run reads current state at fire time, not at request time"),
    ],
  },
  {
    id: "FND-03.edition-lineage",
    requirement: "FND-03",
    spec: "CORD-04 §1",
    level: "MUST",
    rule:
      "An edition is classified against the current head as an ancestor, a lost sibling or unknown, and unproven history is never trusted.",
    phase: 1,
    status: "covered",
    tests: refs(
      LINEAGE,
      "classifies a same-version loser as a lost sibling",
      "classifies an earlier-version divergence as a lost sibling",
      "returns unknown when a compacted predecessor is missing",
      "returns unknown beyond the depth cap",
      "does not trust a retained edition whose content does not hash to the cited link",
    ),
  },
  {
    id: "FND-03.lost-addition",
    requirement: "FND-03",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule:
      "What an edition added over its predecessor is reported so a lost addition can be re-proposed, never guessed when the predecessor is missing.",
    phase: 1,
    status: "covered",
    tests: refs(
      LINEAGE,
      "reports additions against the predecessor",
      "refuses to guess when the predecessor is missing",
    ),
  },
  {
    id: "FND-04.typed-diagnostics",
    requirement: "FND-04",
    level: "MUST",
    rule: "Background failures are reported as typed, stage-labelled diagnostics and never printed to the console.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        DIAGNOSTICS,
        "client diagnostics$ reports a failed community list save with its stage",
        "community diagnostics$ reports a failed plane publish with its plane",
        "community diagnostics$ reports a plane publish that no relay accepted (D-22)",
        "background invite bundle and Invite List publishes that no relay accepted are reported (D-22)",
        "the token-leak walk finds a secret in an error's responses, transport errors and cause",
        "a channel rekey wrap the pool rejects is reported as channel-rekey-publish",
        "a channel rekey wrap the pool refuses is reported as channel-rekey-publish",
        "a channel grant the pool rejects is reported as channel-grant-publish",
        "a channel grant the pool refuses is reported as channel-grant-publish",
        "a bundle re-post the pool rejects is reported as invite-bundle-refresh-publish",
        "a bundle re-post the pool refuses is reported as invite-bundle-refresh-publish",
        "diagnostics never carry invite tokens",
        "no background failure is printed to the console",
      ),
      ...refs(
        REQUIRED,
        "a pin-stage required publish failure is labelled with its own stage",
        "invite revocation failures keep their legacy error class and message",
      ),
    ],
  },
  {
    id: "FND-05.stale-completions",
    requirement: "FND-05",
    level: "MUST",
    rule:
      "A read, signer or storage completion that arrives after stop, disposal or a document change never publishes or overwrites newer state.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        LIFECYCLE,
        "a run resumed after dispose observes it is no longer alive",
        "a superseded key's late completion never overwrites the newer key",
      ),
      ...refs(
        WIRING,
        "a stale list read completing after stop never updates status or publishes",
        "a stale signer completion after a document change never publishes",
        "a stale storage completion after stop restores the unchanged document",
      ),
    ],
  },
  {
    id: "LIST-01.no-local-only-fragment",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A missing fragment means unseen and a short read means incomplete, so a failed read never publishes a fresh fragment 0.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "a client restarted offline never publishes a fresh fragment 0 over a fragmented vault",
        "auto-save on an offline start publishes nothing and keeps the change pending",
        "a liveness-skipped relay cohort reads as unknown, not empty",
      ),
      ...refs(SYNC, "refuses a first write before any completed read"),
      ...refs(
        READ,
        "reports incomplete when every relay errors",
        "reports incomplete when pool liveness skips every relay",
        "reports incomplete when a relay never answers before the timeout",
        "never retains forged, off-author or off-kind events",
      ),
    ],
  },
  {
    id: "LIST-01.held-write-release",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A held Community List write is published once a relay completes the read, on the next start or by the bounded retry.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "the next start releases a pending write with the governing fragment count",
        "a pending write is released automatically once a relay completes the read",
        "an exhausted list-read retry reports once and waits for a new key",
        "a blocked offline save does not loop the auto-save pipeline",
      ),
      ...refs(SYNC, "allows the first fragment once a completed read confirms an empty list"),
    ],
  },
  {
    id: "LIST-01.restart-safe-pending",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A held save survives a real process restart and is published exactly once after the next completed read, derived by comparing the mirror with the completed remote document.",
    phase: 1,
    status: "covered",
    tests: refs(
      OFFLINE,
      "a pending write survives a process restart and is published once by the next client",
      "a restarted client whose mirror matches the relay copy publishes nothing",
      "a pending write from a previous process is released by the retry once a relay answers",
    ),
  },
  {
    id: "LIST-02.newest-seen-governs",
    requirement: "LIST-02",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "The newest fragment count seen governs a write, and every written coordinate is timestamped above the known winner.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "the next start releases a pending write with the governing fragment count",
        "a pending write survives a process restart and is published once by the next client",
      ),
      ...refs(
        SYNC,
        "keeps the declared count when only fragment zero is held",
        "timestamps every coordinate strictly above the known winner",
      ),
    ],
  },
  {
    id: "FND-01.terminal-dispose",
    requirement: "FND-01",
    level: "MUST",
    rule: "dispose() is terminal: a later start() rejects and every membership change stays rejected.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(OFFLINE, "start() after dispose() rejects and every membership change stays rejected (D-32)"),
      ...refs(
        WIRING,
        "client stop cancels the list-read retry and dispose is terminal",
        "every public ConcordClient method after dispose() rejects with ConcordClientDisposedError or starts no work (WR-03)",
      ),
    ],
  },
  {
    id: "FND-02.edge-triggered-list-read",
    requirement: "FND-02",
    level: "MUST",
    rule:
      "An exhausted Community List read retry reports once and stays quiet until new input renews it; it never loops on a failing fragment.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "with auto-save on, a fragment that keeps failing to ingest exhausts the read retry once and then stays quiet (CR-02)",
        "an exhausted list-read retry reports once and waits for a new key",
        "an explicit saveCommunityList() after an exhausted read retry arms a fresh retry",
        "an explicit saveCommunityList() with nothing to publish still renews an exhausted read (model seed 13)",
        "an app call that changes nothing still renews an exhausted read while the list is unknown (model seed 15)",
        "another device's fragment arriving after an exhausted read renews it (model seed 84)",
      ),
      ...refs(
        LANE,
        "the read duty key carries only the lifecycle, episode and relays and runs at most maxAttempts attempts",
      ),
      ...refs(MODEL, "seeded interleavings with auto-save on keep every Community List invariant (D-31)"),
      ...refs(MODEL_CORE, "the checker reports a read storm and a duty still pending after quiescence (invariant 4)"),
    ],
  },
  {
    id: "LIST-01.single-lane",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "One client lifecycle reads, ingests, unlocks and saves the Community List one step at a time, and stop() ends it.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "a read that resumes after stop() never hides a stored fragment from the next start, so no frags: 1 is published over frags: 2 (CR-01)",
        "a membership change made while start()'s read is still open waits for that read instead of superseding it (IN-01)",
      ),
      ...refs(
        LANE,
        "a closed lane runs no step and resolves later steps without effect",
        "lane steps run one at a time in order, and a failing step does not block the next",
      ),
      ...MODEL_RUNS,
    ],
  },
  {
    id: "LIST-01.no-stranded-held-write",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "While started and relays answer, missing read evidence or a held write is never stranded, checked at a quiescent point before any app nudge, beyond an exhausted retry, a fragment only the app can decrypt, or a signer or relay refusal of that membership's save that the client reports, and a nudge releases everything.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "a failed unlock that withdraws the read evidence re-arms the read, so the held join is published (WR-01)",
        "a start() that fails leaves the client stopped, so membership changes reject and the next start() reads (model seed 386)",
        "a save retired by another device's fragment is retried, so the held join is published while relays answer (WR-01)",
      ),
      ...refs(LANE, "arrivals during a parked write retire it and re-queue exactly one save"),
      ...MODEL_RUNS,
      ...refs(
        MODEL_CORE,
        "the checker reports unknown evidence without an exhausted retry, and accepts the exhausted residual (invariant 5)",
        "the checker reports an incomplete release after the nudge (invariant 5)",
        "the checker reports a stranded held write at liveness-healed, before any nudge (invariant 5)",
        "the checker excuses a healed difference only for a locked relevant fragment or a corroborated reported failure (invariant 5)",
        "a reported save failure excuses only the membership its failed save carried, after that membership's last op (invariant 5, WR-04)",
      ),
    ],
  },
  {
    id: "LIST-01.publish-needs-current-evidence",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Every Community List publish needs this lifecycle's completed read, begun after the last evidence loss, with every fragment ingested.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(SYNC, "a write whose read evidence is withdrawn while it signs publishes nothing (D-31)"),
      ...refs(
        MODEL_CORE,
        "the checker reports a publish without this lifecycle's completed read (invariant 1)",
        "the checker judges read evidence from the trace alone, never from the client's reported knowledge (invariant 1)",
      ),
      ...MODEL_RUNS,
    ],
  },
  {
    id: "LIST-02.no-demotion-under-interleaving",
    requirement: "LIST-02",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "No interleaving publishes a lower fragment count or drops a membership or tombstone the store holds.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "a read that resumes after stop() never hides a stored fragment from the next start, so no frags: 1 is published over frags: 2 (CR-01)",
        "a save queued behind a parked unlock ingests the fragment that arrived while it waited and holds instead of publishing frags: 1 over frags: 2 (CR-01)",
        "with autoUnlock on, a save queued behind a parked unlock publishes under the arrived fragment's larger count, never frags: 1 (CR-01)",
      ),
      ...refs(
        LANE,
        "a save queued behind a parked step ingests a fragment that arrived while it waited and holds instead of publishing a smaller count",
      ),
      ...MODEL_RUNS,
      ...refs(
        MODEL_CORE,
        "the checker reports a fragment-count demotion and a dropped membership (invariant 2)",
        "the checker reports a dropped tombstone but not a membership the client left (invariant 2)",
      ),
    ],
  },
  {
    id: "LIST-01.dirty-reflects-relay-copy",
    requirement: "LIST-01",
    level: "MUST",
    rule: "communityListDirty$ returns to false once the relay copy holds the local memberships.",
    phase: 1,
    status: "covered",
    tests: refs(
      OFFLINE,
      "communityListDirty$ returns to false after a held save across three fragments is released",
      "communityListDirty$ returns to false after an online createNewCommunity",
    ),
  },
  {
    id: "LIST-01.save-view-current",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A Community List save plans and publishes only after ingesting every fragment the store holds; an arrival or change during the write retires it, and the retired save is re-queued, never dropped.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "a save queued behind a parked unlock ingests the fragment that arrived while it waited and holds instead of publishing frags: 1 over frags: 2 (CR-01)",
        "with autoUnlock on, a save queued behind a parked unlock publishes under the arrived fragment's larger count, never frags: 1 (CR-01)",
        "a save retired by another device's fragment is retried, so the held join is published while relays answer (WR-01)",
      ),
      ...refs(
        LANE,
        "a retired save publishes nothing stale, is re-queued once and publishes the newer document, and a held save flags the host once",
        "a save queued behind a parked step ingests a fragment that arrived while it waited and holds instead of publishing a smaller count",
        "arrivals during a parked write retire it and re-queue exactly one save",
      ),
      ...refs(RUNNER, "the runner parks only the next call of a parked signer method until release-stalls"),
      ...MODEL_RUNS,
    ],
  },
  {
    id: "FND-02.bounded-deferred-save",
    requirement: "FND-02",
    level: "MUST",
    rule:
      "A save deferred by an unreconciled kind-13302 edition flags communityListDirty$ once and never loops, and runs once the edition is reconciled.",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "with auto-save on, a save deferred by a locked kind-13302 list flags dirty once, does not loop, and runs after the unlock (WR-02)",
        "a blocked offline save does not loop the auto-save pipeline",
      ),
      ...refs(LANE, "arrivals during a parked write retire it and re-queue exactly one save"),
    ],
  },
  {
    id: "LIST-01.resumable-join",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A join or create that rejects after recording the membership keeps it and saves the Community List (or holds the save until a relay answers); joining a community already joined re-publishes the user's guestbook Join, which CORD-02 §5 coalesces, and saves the list, so a retry finishes the join; concurrent joins share one engine (D-34).",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "a join rejected after it recorded the membership keeps it saved, and a retried join publishes exactly one Join and resolves (D-34, model seed 40)",
        "a createNewCommunity() rejected after it recorded the membership keeps it saved (D-34, model seed 40)",
        "a rejected join keeps an unrelated held change pending and holds its own membership with it (D-34, model seed 40)",
        "with auto-save on, a join rejected after its list was published stays joined, and a retry publishes exactly one Join (D-34, 01-REVIEW-GAPS-2 CR-01)",
        "a join interrupted by stop() is restored joined by the next start(), and a retry publishes exactly one Join (D-34, 01-REVIEW-GAPS-2 CR-01)",
        "concurrent joins of one community share one engine, and a declined Join leaves the other call's Join and the saved membership (D-34, 01-REVIEW-GAPS-2 WR-02)",
        "a join rejected while its list fragment awaits the relay's OK stays joined, and its fragment stands (D-34, 01-REVIEW-GAPS-2 CR-02)",
        "a join rejected while a kind-13302 list is reconciled stays joined and is published once (D-34, 01-REVIEW-GAPS-2 WR-01)",
        "a join rejected while the list is unknown holds its membership and publishes it once a relay answers (D-34, 01-REVIEW-GAPS-2 WR-03)",
      ),
      // The model observes the rule: invariant 5 judges memberships from the runner's own record of join and leave
      // outcomes (01-REVIEW-GAPS-2 WR-05), and the D-34 templates draw rejected, retried and concurrent joins.
      ...refs(
        MODEL_CORE,
        "the checker judges memberships from the app's join and leave outcomes, not from the client's mirror (invariant 5, WR-05)",
        "a reported save failure excuses only the membership its failed save carried, after that membership's last op (invariant 5, WR-04)",
        "the checker excuses a healed difference only for a locked relevant fragment or a corroborated reported failure (invariant 5)",
      ),
      ...refs(RUNNER, "the runner fails only the next call of a fail-next signer method"),
      ...MODEL_RUNS,
    ],
  },
  {
    id: "LIST-02.sync-api-on-lane",
    requirement: "LIST-02",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "client.communityListSync.write() and repack() run as Community List lane steps that ingest every stored fragment first and re-check the lane view before each fragment, so they never overwrite or hide another device's fragment that arrived meanwhile, receive() on that view authenticates a fragment, adds it to the event store and receives it as a lane step so it can be unlocked, and the lane-owned abandon(), restore() and read-evidence methods throw on that view (D-35, WR-06, WR-03).",
    phase: 1,
    status: "covered",
    tests: [
      ...refs(
        OFFLINE,
        "client.communityListSync.repack() queued behind a parked lane step ingests the arrived fragment first and never erases its membership (D-35, 01-REVIEW-GAPS-2 CR-03)",
        "client.communityListSync.write() queued behind a parked lane step never publishes frags: 1 over the arrived frags: 2 (D-35, 01-REVIEW-GAPS-2 CR-03)",
        "the client's communityListSync view leaves read evidence to the client (IN-01)",
        "a released held save that finds the relay copy already matching clears pending",
        "receive() on the client's view of a fragment that becomes the newest declaration can be unlocked and does not block later saves (WR-03)",
      ),
      ...refs(
        LANE,
        "abandon(), restore() and the read-evidence methods throw on the view and leave the sync untouched (WR-06)",
        "receive() on the view waits behind an in-flight lane write, then stores the fragment so the lane can unlock it (WR-03)",
      ),
    ],
  },
  {
    id: "LIST-02.sync-api-needs-open-lane",
    requirement: "LIST-02",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "client.communityListSync.write() and repack() never run outside a Community List lane: with no open lane (before start() finishes, after stop() or dispose()), or once the lane they queued on closed, they reject with ConcordClientNotStartedError, at once even behind a step or sync task that never settles, and a closed lane refuses every fragment they have not published, so a call that outlived its lifecycle cannot pass the next lifecycle's read gate and hide another device's fragment; a call refused before its sync task started signing never prompts the signer in a later lifecycle (D-30, D-35, 01-REVIEW-GAPS-3 CR-01, 01-REVIEW-GAPS-4 CR-01, 01-REVIEW-GAPS-5 CR-01).",
    phase: 1,
    status: "covered",
    tests: refs(
      OFFLINE,
      "client.communityListSync.repack() queued on a lane that stop() closed rejects with ConcordClientNotStartedError and never publishes after the restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)",
      "client.communityListSync.write() queued on a lane that stop() closed rejects with ConcordClientNotStartedError and never publishes after the restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)",
      "client.communityListSync.write() called on a stopped client rejects with ConcordClientNotStartedError and never publishes after a restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)",
      "client.communityListSync.write() whose lane step started and waits on the sync behind a retired save rejects with ConcordClientNotStartedError and never prompts the signer or publishes in the next lifecycle (D-30, D-35, 01-REVIEW-GAPS-4 CR-01, 01-REVIEW-GAPS-5 CR-01)",
      "client.communityListSync.write() queued behind a lane step that never settles rejects with ConcordClientNotStartedError as soon as stop() runs (D-30, D-35, 01-REVIEW-GAPS-4 CR-01)",
      "client.communityListSync.write() that stop() rejected while it waited on the sync behind a retired save never prompts the signer in the next lifecycle, whose joins still save (D-30, D-35, 01-REVIEW-GAPS-5 CR-01)",
      "client.communityListSync.repack() that stop() rejected while it waited on the sync behind a retired save never prompts the signer in the next lifecycle, whose joins still save (D-30, D-35, 01-REVIEW-GAPS-5 CR-01)",
    ),
  },
  {
    id: "LIST-01.motions-in-call-order",
    requirement: "LIST-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A community's own Join and Leave publications, with their Community List mutation and save, take effect in call order, so the newest guestbook motion (CORD-02 §5) and the list agree: a join called during a leave joins anew after it, a leave called during a join leaves after it, and a later join or leave always applies (D-34, 01-REVIEW-GAPS-3 CR-02).",
    phase: 1,
    status: "covered",
    tests: refs(
      OFFLINE,
      "a join called while a leave is publishing, the newest prompt answered first: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)",
      "a join called while a leave is publishing, both prompts answered in one tick: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)",
      "a leave called while a repeated join is publishing, the newest prompt answered first: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)",
      "after a join raced a leave, a later leave() and a later join still publish their motion and agree (D-34, 01-REVIEW-GAPS-3 CR-02)",
    ),
  },
  {
    id: "FND-01.app-work-bound-to-lifecycle",
    requirement: "FND-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "App work called in one client lifecycle never takes effect in a later lifecycle: a join, leave or create still queued when stop() or dispose() runs rejects at once with ConcordClientNotStartedError or ConcordClientDisposedError, even behind a signer prompt that never settles, and never blocks or queues on the next lifecycle's calls; a call already in progress settles when its own pending signer or relay step does, possibly with the engine's error, and records, tombstones, saves and prompts nothing after a restart, while a change it recorded before stop() stays and the next start() saves it (D-30, D-32, D-34, 01-REVIEW-GAPS-4 CR-02, 01-REVIEW-GAPS-5 WR-01, WR-02).",
    phase: 1,
    status: "covered",
    tests: refs(
      OFFLINE,
      "after a Leave prompt that is never answered, stop() and start() let the same community's join and leave run (D-30, D-34, 01-REVIEW-GAPS-4 CR-02)",
      "a join queued behind a Leave prompt that is never answered rejects with ConcordClientDisposedError as soon as dispose() runs (D-32, D-34, 01-REVIEW-GAPS-4 CR-02)",
      "a leave() called before stop() and queued behind a slow join rejects with ConcordClientNotStartedError and publishes nothing after the restart (D-30, D-34, 01-REVIEW-GAPS-4 CR-02)",
      "a join whose list mutation waits behind a slow mirror write when stop() and start() run rejects with ConcordClientNotStartedError and records nothing in the next lifecycle (D-30, D-34, 01-REVIEW-GAPS-4 audit)",
      "a leave whose list mutation waits behind a slow mirror write when stop() and start() run rejects with ConcordClientNotStartedError and tombstones nothing in the next lifecycle (D-30, D-34, 01-REVIEW-GAPS-4 audit)",
      "a leave whose own mirror write spans stop() and start() rejects with ConcordClientNotStartedError and the next lifecycle saves its tombstone (D-30, D-34, 01-REVIEW-GAPS-4 audit, 01-REVIEW-GAPS-5 WR-03)",
      "a joinByLink() whose bundle fetch spans stop() and start() rejects with ConcordClientNotStartedError and joins nothing (D-30, 01-REVIEW-GAPS-4 audit)",
      "a createNewCommunity() whose genesis spans stop() and start() rejects with ConcordClientNotStartedError and creates nothing (D-30, 01-REVIEW-GAPS-4 audit)",
      "a joinByLink() whose bundle fetch spans stop() and start() rejects with ConcordClientNotStartedError at once, even behind a next-lifecycle leave of that community that never settles (D-30, 01-REVIEW-GAPS-5 WR-01)",
    ),
  },
  // Phase 2: pin lifecycle (PIN-01..PIN-11, DEC-01, DEC-02).
  {
    id: "PIN-01.apply-newest-edit",
    requirement: "PIN-01",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A pinned message shows the newest author-valid Edit the reader knows, bundled or local, and marks the pin edited.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PIN_PROJECTION, "a newer local Edit replaces the bundled text and marks the pin edited and behind"),
      ...refs(EDIT, "newestValidEdit picks the newest author-valid Edit for the channel"),
      ...refs(PINS, "pins$ shows the newest local Edit of a pinned message as edited text"),
    ],
  },
  {
    id: "PIN-01.never-older-edit",
    requirement: "PIN-01",
    level: "MUST",
    rule: "A local Edit older than the Edit already bundled in the proof never replaces it.",
    phase: 2,
    status: "covered",
    tests: refs(PIN_PROJECTION, "a local Edit older than the bundled proof never replaces it"),
  },
  {
    id: "PIN-01.never-superseded-text",
    requirement: "PIN-01",
    level: "MUST",
    rule:
      "Library rule D-11: an expired newest Edit hides the pin by default, showExpired shows only that Edit's text, and superseded text is never shown as current.",
    phase: 2,
    status: "covered",
    tests: refs(
      PIN_PROJECTION,
      "an expired newest Edit hides the pin by default and showExpired shows only that Edit's text (D-11)",
      "an expired newer local Edit never falls back to the bundled or original text (D-11)",
    ),
  },
  {
    id: "PIN-01.deleted-edit-ignored",
    requirement: "PIN-01",
    level: "MUST",
    rule:
      "Library rule D-31: an Edit its own author deleted is never shown; the edit chooser and pins fall back to the newest undeleted Edit or the original text, and a deletion by another pubkey does not hide an Edit.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(
        EDIT,
        "newestValidEdit skips an Edit its own author deleted and falls back to the next undeleted Edit (D-31)",
        "newestValidEdit honours only the Edit author's own deletion of the recomputed Edit id (D-31)",
        "newestValidEdit skips malformed deletions without throwing (D-31)",
      ),
      ...refs(
        PIN_PROJECTION,
        "a local Edit its author deleted is never shown and the pin falls back to the newest undeleted Edit or the original (D-31)",
        "a bundled Edit its author deleted is not shown and the pin is marked behind (D-31)",
      ),
      ...refs(PINS, "pins$ never shows an Edit its author deleted and falls back to the original text (D-31)"),
    ],
  },
  {
    id: "PIN-01.duplicate-entries-newest-bundle",
    requirement: "PIN-01",
    level: "MUST",
    rule:
      "Library rule D-32: a Pin List naming one message more than once shows it once, at its first position, from the copy whose bundled Edit is newest; a copy bundling an Edit its author deleted never wins.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(
        PIN_PROJECTION,
        "a message listed twice shows the copy whose bundled Edit is newest at its first position (D-32)",
        "a duplicate whose bundled Edit its author deleted never wins over an undeleted bundle (D-32)",
      ),
      ...refs(
        PINS,
        "pins$ shows a message another client listed twice once, from the copy with the newest bundled Edit (D-32)",
      ),
    ],
  },
  {
    id: "PIN-01.cache-verification",
    requirement: "PIN-01",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule: "A client caches pin verification so each entry is verified once per channel, with a bounded cache.",
    phase: 2,
    status: "covered",
    tests: refs(PINS, "the pin verification cache verifies an entry once per channel and stays bounded"),
  },
  {
    id: "PIN-02.hide-self-deleted",
    requirement: "PIN-02",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A pin whose proven author deleted the message is hidden as soon as the deletion is known, with no new Pin List edition; a deletion by another pubkey does not hide it.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PIN_PROJECTION, "a self-deletion by the proven author hides the pin; one by another pubkey does not"),
      ...refs(PINS_MODEL, "ConcordPinsModel hides a pin as soon as its author's deletion arrives"),
      ...refs(PINS, "pins$ hides a pin as soon as its author deletes the message, before any new Pin List edition"),
    ],
  },
  {
    id: "PIN-09.reactive-pins",
    requirement: "PIN-09",
    level: "MUST",
    rule:
      "The reactive pins$ and the one-shot pins() apply the same projection rules, and the model re-emits when an Edit arrives.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PINS_MODEL, "ConcordPinsModel re-emits when a newer Edit arrives"),
      ...refs(PINS, "pins() applies the same rules as pins$"),
    ],
  },
  {
    id: "DEC-01.expired-hidden-reader-side",
    requirement: "DEC-01",
    level: "MUST",
    rule:
      "Library policy: an expired pin is hidden by default and exposed with expiresAt under showExpired; the model re-emits at the next expiry boundary without polling, and pinning an expiring message is allowed.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PIN_PROJECTION, "an expired pin is hidden unless showExpired, which exposes expiresAt"),
      ...refs(
        PINS_MODEL,
        "ConcordPinsModel re-emits at the next expiry boundary and leaves no timer after unsubscribe",
      ),
      ...refs(PINS, "pinning a message that carries an expiration tag is accepted and pins$ exposes expiresAt"),
    ],
  },
  {
    id: "DEC-01.no-publication-on-expiry",
    requirement: "DEC-01",
    level: "MUST",
    rule:
      "Expiry is reader-side only: it never schedules automatic upkeep and never changes what an upkeep rewrite carries.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(MAINTAINER, "expiry never schedules upkeep (D-02)"),
      ...refs(UPKEEP, "an omission rewrite carries an expired pin verbatim (D-02)"),
    ],
  },
  {
    id: "DEC-02.first-pin-after-proven-absence",
    requirement: "DEC-02",
    level: "MUST",
    rule:
      "The first pin of a channel publishes Pin List version 1 only after the community is live with no head, suspension, pending chain evidence or retained edition that could still verify; earlier calls reject with PinListNotReadyError, with reason unverified-edition while live when such an edition blocks it, and an edition that can never verify does not block it (D-33). An edition whose cited Grant resolved but whose author current standing rejects (banned or demoted) does not block either, and the new head chains over it at the next version (D-34).",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(
        PINS,
        "setPins publishes Pin List version 1 for a live channel with no head",
        "setPins rejects with PinListNotReadyError not-synced before the community sync is live",
        "setPins publishes Pin List version 1 over retained editions that can never verify (D-33)",
        "setPins rejects with unverified-edition while live when a retained edition may still verify (D-33)",
        "setPins writes over a banned curator's Pin List, chained at the next version (D-34)",
        "setPins writes over a demoted curator's Pin List, chained at the next version, and keeps it on re-promotion (D-34)",
      ),
      ...refs(
        UPKEEP,
        "pinWriteReadiness proves absence only when live with no head, suspension, pending evidence or retained edition",
        "pinWriteReadiness ignores Grant-citation evidence filed under the Pin List coordinate (D-33)",
        "canEditionEverVerify keeps owner editions and well-formed citations of the author's own Grant (D-33)",
        "canEditionEverVerify rejects non-owner editions with no vac tag or a malformed one (D-33)",
        "canEditionEverVerify rejects a citation of any coordinate other than the author's own Grant (D-33)",
        "a banned or demoted curator's only Pin List edition no longer blocks a first write (D-34)",
        "a citation of a Grant that has not synced still blocks a first write (D-34)",
        "rejectedChainBase names the highest standing-rejected edition and never an owner or unverifiable one (D-34)",
        "an owner Pin List chained over a rejected edition stays the head when the curator is restored (D-34)",
      ),
    ],
  },
  {
    id: "DEC-02.setpins-head-guard",
    requirement: "DEC-02",
    level: "MUST",
    rule: "A head that moves while setPins is signing is never overwritten; the call rejects with reason changed.",
    phase: 2,
    status: "covered",
    tests: refs(PINS, "setPins rejects with reason changed when the head moves while signing"),
  },
  {
    id: "PIN-11.admin-preset-omits-pin-messages",
    requirement: "PIN-11",
    spec: "CORD-04 §3",
    level: "MUST",
    rule:
      "ADMIN_PERMS deliberately omits PIN_MESSAGES, because a Role granted everything today does not inherit a later permission.",
    phase: 2,
    status: "covered",
    tests: refs(PERMS, "ADMIN_PERMS deliberately omits PIN_MESSAGES (PIN-11)"),
  },
  {
    id: "PIN-03.self-delete-omission",
    requirement: "PIN-03",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule:
      "A PIN_MESSAGES holder omits a self-deleted pin from the Pin List with one guarded edition; the pinner acts at once and a witness waits a bounded delay and skips when the head was already healed.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PINS, "the pinner's own self-deleted pin is omitted by one Pin List edition"),
      ...refs(
        MAINTAINER,
        "the pinner acts immediately and a witness waits within the bounded window",
        "a witness skips publishing when the head was already healed",
      ),
    ],
  },
  {
    id: "PIN-03.replay-rearms",
    requirement: "PIN-03",
    level: "MUST",
    rule:
      "One head publishes at most once, and a replayed head that re-seats a deleted entry re-arms upkeep on the current head.",
    phase: 2,
    status: "covered",
    tests: refs(
      MAINTAINER,
      "a replayed head that re-seats a deleted entry re-arms and builds on the current head",
      "one head publishes at most once",
    ),
  },
  {
    id: "PIN-03.no-storm",
    requirement: "PIN-03",
    level: "MUST",
    rule:
      "Upkeep is bounded: rate limiting defers work and reports pin-upkeep-skipped, and a failed acknowledgment retries a bounded number of times before duty-exhausted.",
    phase: 2,
    status: "covered",
    tests: refs(
      MAINTAINER,
      "rate limiting defers upkeep and reports pin-upkeep-skipped",
      "a failed acknowledgment retries within bounded attempts and then reports duty-exhausted",
    ),
  },
  {
    id: "PIN-03.opt-out",
    requirement: "PIN-03",
    level: "MUST",
    rule: "pinUpkeep false on a community or on the client publishes no automatic Pin List edition.",
    phase: 2,
    status: "covered",
    tests: refs(
      PINS,
      "pinUpkeep false publishes no automatic Pin List edition",
      "the client pinUpkeep option reaches every community engine",
    ),
  },
  {
    id: "PIN-04.refresh-newest-provable",
    requirement: "PIN-04",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule:
      "A holder republishes a pinned entry with the newest provable author Edit's own proof bundle, using the newest provable Edit at fire time.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PINS, "an edited pinned message is refreshed with the newest Edit's proof bundle"),
      ...refs(MAINTAINER, "the newest provable Edit at fire time wins over the one seen when the duty was armed"),
    ],
  },
  {
    id: "PIN-04.no-other-form",
    requirement: "PIN-04",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "Edit refresh replaces only the entry's edit bundle with a verified proof, and an unprovable newer Edit leaves the existing bundle in place.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(UPKEEP, "a refresh replaces only the entry's edit bundle with a verified proof"),
      ...refs(MAINTAINER, "an unprovable newer Edit keeps the entry's existing bundle"),
    ],
  },
  {
    id: "PIN-04.never-regress",
    requirement: "PIN-04",
    level: "MUST",
    rule:
      "Refresh never attaches an Edit that is not strictly newer than the bundled one, and never refreshes to older text when the newest Edit is expired.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(MAINTAINER, "refresh never attaches an Edit older than the entry carries"),
      ...refs(
        UPKEEP,
        "planPinUpkeep never attaches an Edit that is not strictly newer than the bundled one",
        "planPinUpkeep never refreshes to older text when the newest Edit is expired (D-11)",
      ),
    ],
  },
  {
    id: "PIN-04.never-bundle-deleted-edit",
    requirement: "PIN-04",
    level: "MUST",
    rule:
      "Library rule D-31: automatic upkeep never bundles an Edit its author deleted, and replaces a bundled Edit its author deleted with the newest undeleted provable Edit or removes the edit bundle; setPins publishes an entry whose bundled Edit its author deleted without that bundle.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(
        UPKEEP,
        "planPinUpkeep never bundles an Edit its author deleted (D-31)",
        "planPinUpkeep replaces a bundled Edit its author deleted with the newest undeleted provable Edit or removes it (D-31)",
      ),
      ...refs(
        PINS,
        "upkeep never bundles an Edit its author deleted before the message was pinned (D-31)",
        "a bundled Edit its author deletes is replaced by the newest undeleted Edit's proof (D-31)",
        "a bundled Edit its author deletes is removed from the Pin List when no undeleted Edit remains (D-31)",
        "setPins drops a bundled Edit its author deleted instead of republishing it (D-31)",
        "setPins drops a bundled Edit its author deleted from a private channel's sealed list (D-31)",
      ),
    ],
  },
  {
    id: "PIN-04.duplicate-entries-never-regress",
    requirement: "PIN-04",
    level: "MUST",
    rule:
      "Library rule D-32: upkeep rewrites and setPins keep one copy of a message listed more than once, the one whose bundled Edit is newest, so an unrelated rewrite never regresses the proven Edit; duplicates alone never trigger a rewrite.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(
        UPKEEP,
        "an omission rewrite keeps the duplicate whose bundled Edit is newest (D-32)",
        "duplicate entries alone never trigger a rewrite (D-32)",
        "a duplicate bundling an Edit its author deleted triggers a rewrite that keeps one undeleted copy (D-32)",
      ),
      ...refs(
        PINS,
        "setPins publishes a message listed twice once, keeping the copy with the newest bundled Edit (D-32)",
      ),
    ],
  },
  {
    id: "PIN-04.coalesced",
    requirement: "PIN-04",
    level: "MUST",
    rule:
      "Several corrections inside a witness's wait cost one publication, and the pinner refreshes an edit immediately.",
    phase: 2,
    status: "covered",
    tests: refs(
      MAINTAINER,
      "a witness's three corrections within the delay window cost one publication",
      "the pinner refreshes an edit immediately (D-08)",
    ),
  },
  {
    id: "PIN-05.seal-from-retained-wraps",
    requirement: "PIN-05",
    level: "MUST",
    rule:
      "Edit seals are indexed by recomputed rumor id (never a forged embedded id), rebuilt by sync after a restart, and used for public and private channels alike.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(SEALS, "keys Edit seals by recomputed rumor id, ignoring a forged embedded id"),
      ...refs(
        PINS,
        "after a restart the Edit seal index is rebuilt by sync before live",
        "a private channel's pinned edit is refreshed under its sealed form",
      ),
    ],
  },
  {
    id: "PIN-05.newest-seal-retained",
    requirement: "PIN-05",
    level: "MUST",
    rule:
      "Library rule: at most 512 Edit seals are kept per channel, evicting by rumor order rather than arrival order, and the newest Edit of an original is never dropped while a superseded one is kept.",
    phase: 2,
    status: "covered",
    tests: refs(
      SEALS,
      "keeps at most 512 Edit seals per channel, evicting by rumor order rather than arrival order",
      "eviction never drops the newest Edit of an original while a superseded Edit is retained",
    ),
  },
  {
    id: "PIN-06.rekey-refresh",
    requirement: "PIN-06",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule:
      "After a private channel rekey the rotator republishes its readable Pin List under the new key at once with byte-identical proof bundles, and other holders follow after the witness delay.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(
        PINS,
        "after a private channel rekey the rotator republishes its Pin List under the new key with byte-identical proof bundles",
        "a fresh reader holding only the new channel key reads the resealed pins",
      ),
      ...refs(
        MAINTAINER,
        "noteRotation makes the rotator's reseal immediate and others wait",
        "a key change re-plans a watched private channel",
      ),
    ],
  },
  {
    id: "PIN-06.unavailable-old-epoch",
    requirement: "PIN-06",
    level: "MUST",
    rule:
      "A holder lacking the old channel epoch key leaves the sealed Pin List unavailable and publishes nothing, and a reader holding only the old key cannot read the resealed list.",
    phase: 2,
    status: "covered",
    tests: refs(
      PINS,
      "a holder lacking the old channel epoch key leaves the sealed Pin List unavailable and publishes nothing",
      "a reader holding only the old channel key cannot read the resealed Pin List",
    ),
  },
  {
    id: "PIN-06.over-cap-terminal",
    requirement: "PIN-06",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A rewrite over the content ceiling reports over-cap once, publishes nothing and settles instead of retrying.",
    phase: 2,
    status: "covered",
    tests: refs(MAINTAINER, "a rewrite over the byte ceiling reports over-cap once and publishes nothing"),
  },
  {
    id: "PIN-07.no-write-from-unreadable-list",
    requirement: "PIN-07",
    spec: "CORD-04 §7",
    level: "MUST",
    rule: "A writer never rebuilds an unreadable (missing key) Pin List from empty; setPins refuses it.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PINS, "setPins refuses an unreadable private Pin List and never rebuilds it from empty"),
      ...refs(UPKEEP, "pinWriteReadiness refuses an unreadable head"),
    ],
  },
  {
    id: "PIN-07.no-public-reform-by-automation",
    requirement: "PIN-07",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "Automation never re-forms a sealed Pin List as public on a public channel; it reports private-era-list once instead.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(UPKEEP, "planPinUpkeep never re-forms a sealed head as public on a public channel"),
      ...refs(MAINTAINER, "a private-era Pin List on a public channel is never rewritten and is reported once"),
    ],
  },
  {
    id: "PIN-07.no-mechanical-conversion",
    requirement: "PIN-07",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A private-to-public conversion never mechanically re-forms the sealed Pin List as public, even with upkeep due.",
    phase: 2,
    status: "covered",
    tests: refs(
      PINS,
      "a private-to-public conversion never re-forms the sealed Pin List as public, even with upkeep due",
    ),
  },
  {
    id: "PIN-07.unreadable-never-rebuilt",
    requirement: "PIN-07",
    spec: "CORD-04 §7",
    level: "MUST",
    rule: "A Pin List sealed under an epoch key the holder lacks stays unavailable and is never rebuilt from empty.",
    phase: 2,
    status: "covered",
    tests: refs(
      PINS,
      "a holder lacking the old channel epoch key leaves the sealed Pin List unavailable and publishes nothing",
      "setPins refuses an unreadable private Pin List and never rebuilds it from empty",
    ),
  },
  {
    id: "PIN-08.stops-on-authority-loss",
    requirement: "PIN-08",
    level: "MUST",
    rule: "Pin upkeep stops on demotion (armed and mid-publication), disposal and dissolution.",
    phase: 2,
    status: "covered",
    tests: refs(
      MAINTAINER,
      "demotion while armed cancels the duty",
      "demotion during publication aborts before the edition is published",
      "dispose leaves no pending duty or subscription",
      "suspension on dissolution refuses pin upkeep",
    ),
  },
  {
    id: "PIN-08.dissolved-self-scrub-only",
    requirement: "PIN-08",
    spec: "CORD-02 §9",
    level: "MUST",
    rule:
      "A dissolved community lets an author hide their own pinned message locally, stored or not, publishes nothing and still refuses another author's deletion.",
    phase: 2,
    status: "covered",
    tests: refs(
      PINS,
      "after dissolution a self-deletion of a stored pinned message hides the pin and publishes no Pin List edition",
      "after dissolution a self-deletion of a pinned message missing from the local store still hides the pin",
      "after dissolution a deletion of another author's pinned message is still refused",
    ),
  },
  {
    id: "PIN-10.deleted-channels",
    requirement: "PIN-10",
    level: "MUST",
    rule: "A channel deleted while upkeep is armed is not maintained.",
    phase: 2,
    status: "covered",
    tests: refs(MAINTAINER, "a channel deleted while armed is not maintained"),
  },
  {
    id: "PIN-10.collision-re-heal",
    requirement: "PIN-10",
    level: "MUST",
    rule: "An omission lost to a concurrent sibling Pin List edition is re-applied on the winning head.",
    phase: 2,
    status: "covered",
    tests: refs(PINS, "an omission lost to a concurrent sibling edition is re-applied on the winning head"),
  },
  {
    id: "PIN-10.fresh-post-rotation-reader",
    requirement: "PIN-10",
    level: "MUST",
    rule:
      "A fresh reader after a Refounding verifies public pins without old-epoch Chat keys, and a keyless reader shows a bundled Edit as edited.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(PINS, "a fresh reader after a Refounding verifies public pins without old-epoch Chat keys"),
      ...refs(PIN_PROJECTION, "a keyless reader verifies a public pin and shows its bundled Edit as edited"),
    ],
  },
  {
    id: "PIN-10.replayed-heads",
    requirement: "PIN-10",
    level: "MUST",
    rule:
      "A replayed head re-arms upkeep on the current head, and a collision with a sibling edition re-heals on the winner.",
    phase: 2,
    status: "covered",
    tests: [
      ...refs(MAINTAINER, "a replayed head that re-seats a deleted entry re-arms and builds on the current head"),
      ...refs(PINS, "an omission lost to a concurrent sibling edition is re-applied on the winning head"),
    ],
  },
  {
    id: "PIN-10.demotion",
    requirement: "PIN-10",
    level: "MUST",
    rule: "A demoted holder's armed or in-flight pin upkeep is cancelled before it publishes.",
    phase: 2,
    status: "covered",
    tests: refs(
      MAINTAINER,
      "demotion while armed cancels the duty",
      "demotion during publication aborts before the edition is published",
    ),
  },
  {
    id: "PIN-10.post-dissolution",
    requirement: "PIN-10",
    spec: "CORD-02 §9",
    level: "MUST",
    rule:
      "After dissolution a stored or unstored pinned message of the deleting author is hidden locally and no Pin List edition is published.",
    phase: 2,
    status: "covered",
    tests: refs(
      PINS,
      "after dissolution a self-deletion of a stored pinned message hides the pin and publishes no Pin List edition",
      "after dissolution a self-deletion of a pinned message missing from the local store still hides the pin",
    ),
  },
  {
    id: "PIN-10.bounded-pin-backlog",
    requirement: "PIN-10",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule: "A client bounds its retained pin-edition backlog.",
    phase: 2,
    status: "residual",
    residual:
      "Not implemented in Phase 2: the engine's retained Control history is unbounded for a long-lived engine, which costs memory only and never shows or publishes a wrong pin. Accepted as a residual risk with no later owner phase.",
    tests: [],
  },
  {
    id: "PIN-10.compaction-omits-deleted-channel-pins",
    requirement: "PIN-10",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule: "A compaction omits the Pin List of a terminally deleted Channel.",
    phase: 2,
    status: "residual",
    residual:
      "Not implemented in Phase 2: a Refounding still re-wraps a deleted channel's Pin List head, so its proofs stay readable to later joiners while nothing re-displays them because the channel is not live. Accepted as a residual risk with no later owner phase.",
    tests: [],
  },
  // Phase 6 spec sweep of CORD-04 §7 (plan 06-09): rules the pin tests asserted without a ledger row.
  {
    id: "REL-01.pin-invalid-entry-dropped",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "An entry that fails any verifier step (seal kind 20013 and signature, MAC, rumor author equal to the seal's, kind 9 or 1111, the rumor's channel tag equal to the list's with absence failing) is dropped alone and its neighbours and edition fold normally; an entry's identity is the recomputed rumor id, never an embedded one.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        PIN_PROOFS,
        "an entry failing any verifier step is invalid and dropped alone (CORD-04 §7 proof bundle)",
        "drops malformed entries individually, deduplicates and honors only the original author's deletion",
      ),
      ...refs(PIN_PROJECTION, "drops invalid entries one at a time and dedupes by recomputed id"),
    ],
  },
  {
    id: "REL-01.pin-wrap-hint-untrusted",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "An entry's wrap locator hint is treated as untrusted: verification, text, identity and deduplication ignore it, so a forged or malformed hint changes nothing about what is shown as proven.",
    phase: 6,
    status: "covered",
    tests: refs(
      PIN_PROOFS,
      "a wrap hint is never trusted: verification, identity and deduplication ignore it (CORD-04 §7)",
    ),
  },
  {
    id: "REL-01.pin-edit-bundle-verified",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A bundled Edit is accepted only when it verifies by the same steps as an entry with the kind 3302 substituted, so an Edit sealed in another Channel or without the channel tag is refused, its proven author equals the original's, and its e tag names the original's recomputed rumor id; a refused Edit leaves the original shown unedited.",
    phase: 6,
    status: "covered",
    tests: refs(
      PIN_PROOFS,
      "an edit bundle is accepted only as kind 3302 by the original's author, naming the original, in this channel (CORD-04 §7)",
      "accepts only message kinds and author-matched edits targeting the proven original",
    ),
  },
  {
    id: "REL-01.pin-violating-edition-empty-list",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A Pin List edition over 25 entries or 32,768 carried content bytes is not refused: it folds, chains and compacts like any edition, while every reader treats its content as an empty list; the byte cap is judged on the exact carried bytes of either form without needing a key, the entry cap by whoever can open the form, and both limits are inclusive.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        PIN_PROOFS,
        "a violating edition reads as an empty list in either form, judged on the exact carried bytes (CORD-04 §7 Limits)",
        "distinguishes unavailable private keys from readable empty and enforces both caps",
      ),
      ...refs(
        PINS,
        "an over-cap Pin List edition still folds and chains but reads as an empty list (CORD-04 §7 Limits)",
      ),
    ],
  },
  {
    id: "REL-01.pin-writer-form-follows-channel-type",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "MUST",
    rule:
      "A writer uses the Pin List form matching the Channel's folded type: plaintext entries for a public Channel and an epoch-stamped sealed envelope for a private one.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        PINS,
        "setPins writes the plaintext form for a public channel and the sealed form for a private one (CORD-04 §7)",
        "setPins replaces an existing private list at the next version in the channel's form",
      ),
    ],
  },
  {
    id: "REL-01.pin-remaining-budget",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule:
      "A client should surface the remaining Pin List budget instead of a bare count, because the 32,768-byte cap rather than the 25-entry cap binds a private Channel.",
    phase: 6,
    status: "residual",
    residual:
      "Not implemented: the library exports PIN_LIST_MAX_ENTRIES and PIN_LIST_MAX_BYTES and encodePinList throws over either cap, but it offers no remaining-budget calculation. An app that shows a pin counter must measure the encoded content itself. It costs no data and never shows or publishes a wrong pin.",
    tests: [],
  },
  {
    id: "REL-01.pin-moderation-suppression",
    requirement: "REL-01",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule:
      "A client implementing local moderation suppression should extend it to the pin entry of a suppressed message: a pin whose proven author is banned is hidden by default and shown with showBanned, and an unban restores it.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        PIN_PROJECTION,
        "a pin whose proven author is banned is hidden unless showBanned is set (CORD-04 §7 moderation suppression)",
      ),
      ...refs(
        PINS_MODEL,
        "ConcordPinsModel hides a banned author's pin, restores it on unban and shows it with showBanned (CORD-04 §7)",
      ),
      ...refs(
        PINS,
        "a banned author's pin is hidden from pins() and pins$, shown with showBanned, and restored on unban (CORD-04 §7)",
      ),
    ],
  },
  {
    id: "LIST-03.persist-verified-winners",
    requirement: "LIST-03",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Every authenticated Community List fragment winner is stored as signed ciphertext with an advisory count, nothing in the record is plaintext, and a record whose storage read failed is kept until a later start reads it.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        STORE,
        "save writes one versioned record of signed events and the advisory count under concord:list-fragments:<pubkey>",
        "a burst of saves writes at most twice and never lands an older snapshot after a newer one",
        "a record whose read failed is never overwritten until a later load reads it (WR-02)",
        "an invalid record is still replaced by the next save (D-03)",
      ),
      ...refs(
        SYNC,
        "every new winner is handed to persist as signed events with the advisory count (D-01)",
      ),
      ...refs(
        RESTART,
        "the stored record holds only signed ciphertext events, never membership plaintext (LIST-03)",
        "a record that cannot be read at start is kept, never replaced by what the relays served, and restored by the next start (WR-02)",
      ),
    ],
  },
  {
    id: "LIST-03.restore-verified",
    requirement: "LIST-03",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A stored fragment is re-verified (author, kind, canonical index, signature) before it is restored, and forged, foreign or malformed ones are dropped and reported.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        STORE,
        "load refuses a record with another version, another pubkey or a malformed shape",
      ),
      ...refs(
        SYNC,
        "restore() drops forged, foreign, wrong-kind and non-canonical events and reports one fragment-restore diagnostic (D-03)",
        "restore() keeps the NIP-01 winner when a record holds two copies of one index (D-03)",
        "restore() refuses everything without side effects when the signer cannot name its key (D-03)",
      ),
      ...refs(
        RESTART,
        "a corrupt or forged stored record is dropped with a fragment-restore diagnostic and start() still resolves (D-03)",
      ),
    ],
  },
  {
    id: "LIST-03.restore-before-relay",
    requirement: "LIST-03",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "A restarted client holds its stored fragments before any relay answers and unlocks them on request.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        RESTART,
        "a restarted client restores its stored fragments before any relay answers and unlocks them on request (LIST-03)",
      ),
    ],
  },
  {
    id: "LIST-03.restored-not-evidence",
    requirement: "LIST-03",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Restored fragments are never read evidence: a restart does not make an empty relay answer look like an empty List or demote the fragment count.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "restore() keeps stored winners locked and never counts them as read evidence (D-04)",
      ),
      ...refs(
        RESTART,
        "restored fragments are not read evidence: an offline restart still holds a join (D-04)",
        "after a restart, an empty completed read never reports confirmed-empty or publishes frags: 1 over the restored vault (T-01-06)",
        "a stored advisory count never decides the fragment count of a write (D-20)",
      ),
    ],
  },
  {
    id: "LIST-03.unlock-retained",
    requirement: "LIST-03",
    level: "MUST",
    rule: "A restored fragment stays locked until it is unlocked, is reported as locked, and decrypts on request.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a restored fragment decrypts on an explicit receive and a newer relay copy replaces it (D-04)",
        "locked$ reports held copies that are not decrypted",
      ),
      ...refs(
        MEMBERSHIPS,
        "memberships().locked stays true while a held fragment is undecrypted and turns false after unlockCommunityListFragments() (D-13)",
      ),
    ],
  },
  {
    id: "LIST-04.prefix-complete",
    requirement: "LIST-04",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Every acknowledged step of a Community List repack leaves a complete List with every membership, key and tombstone, including after a client restart.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "every acknowledged prefix of a repack is a complete List that keeps every membership, key and tombstone (D-17)",
        "staging copies declare the old count and the count first rises at the copy stage (D-17)",
        "keeps every membership readable after every acknowledged prefix of a cyclic repack",
      ),
      ...refs(
        RESTART,
        "a client restarted after every acknowledged repack prefix keeps every membership, key and tombstone and repairs the List once with auto-save on (LIST-04, LIST-08)",
      ),
    ],
  },
  {
    id: "LIST-04.repair-converges",
    requirement: "LIST-04",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A repair repack from any acknowledged prefix converges to a clean List, also when the stored record is behind the relay.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a repair repack from every acknowledged prefix converges to a clean List with no dormant content or duplicates (LIST-04)",
        "a record one fragment behind the relay restores the same complete List at every prefix (LIST-04)",
      ),
      ...refs(
        RESTART,
        "a repack refused by the relay after its first acknowledgment is repaired by the restarted client from its stored record (LIST-04, D-08)",
      ),
    ],
  },
  {
    id: "LIST-04.never-infer-missing",
    requirement: "LIST-04",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "A client never writes a fragment index it does not hold, and a partial List is never repacked.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "missing declared indexes keep a List partial and a repack is refused (D-05)",
      ),
      ...refs(
        RESTART,
        "a restart from a partial read with missing declared fragments never writes the missing indexes (D-05)",
      ),
    ],
  },
  {
    id: "LIST-04.baseline-recheck",
    requirement: "LIST-04",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A repack re-checks the held fragments before each stage and stops or restarts when another device's fragment arrived.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a repack stops before its next stage when a fragment arrives at a dormant index (D-06)",
        "retires a staged repack when another device adds content between phases",
        "another device's fragment ingested while a write waits on persist stops the stale write (CR-01, D-06)",
      ),
      ...refs(
        RESTART,
        "a repair interrupted by another device's fragment restarts from a fresh merge and keeps that device's membership (D-06)",
      ),
    ],
  },
  {
    id: "LIST-04.dormant-merged",
    requirement: "LIST-04",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "Content held at indexes above the declared count is merged into the new List before it is emptied.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "documentAll unions in-range and dormant fragments with the lowest index winning (D-20)",
        "a repack plan includes dormant memberships and empties every non-empty dormant index (D-20)",
        "residue reports non-empty dormant fragments and memberships held in two in-range fragments",
      ),
    ],
  },
  {
    id: "LIST-05.single-repair-owner",
    requirement: "LIST-05",
    level: "MUST",
    rule:
      "One bounded repair duty owns the repair of repack leftovers, is never re-armed by its own publications, reports exhaustion once, and never retries a refusal that cannot clear in its lifecycle (a declined signer, an unreadable fragment record).",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        LANE,
        "with autoRepair on, residue on a complete decrypted List arms one repair duty whose key holds only the lifecycle, episode and a hash of public ids (D-07)",
        "the repair runs through the lane and leaves a clean List (D-05, D-07)",
        "a repair is never re-armed by its own publications and stays quiet once its budget is spent (LIST-05)",
        "a repair that the signer declines settles after one community-list-repair report and is not retried (D-07)",
        "an unlock still releases a held save while only a repair duty is pending",
      ),
      ...refs(
        RESTART,
        "a repair whose relay acknowledgments keep failing retries within its budget, reports exhaustion once and then stays quiet (LIST-05)",
        "a repair over a fragment record that could not be read is reported once and not retried in that lifecycle (IN-01)",
      ),
    ],
  },
  {
    id: "LIST-05.repair-consent",
    requirement: "LIST-05",
    level: "MUST",
    rule:
      "Without autoSaveCommunityList the client only reports repack leftovers and repairs them on the next explicit save, join or leave; a locked or partial List is never repaired.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        LANE,
        "with autoRepair off, residue is reported once per held state and an explicit save arms the repair (D-19)",
        "a locked copy or a partial List never arms a repair (D-05)",
      ),
      ...refs(
        RESTART,
        "with auto-save off, a restart reports interrupted-repack residue once and the next saveCommunityList() repairs it (D-19)",
      ),
    ],
  },
  {
    id: "LIST-05.cancel-across-lifecycles",
    requirement: "LIST-05",
    level: "MUST",
    rule:
      "A repair or write parked on a signer prompt or a storage write publishes nothing after stop() and never blocks the next lifecycle.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        LANE,
        "close() abandons a sync task waiting on the signer so the next lane's save runs (LIST-05)",
      ),
      ...refs(
        SYNC,
        "abandon() lets the next write run while an earlier write waits on the signer, and the earlier write publishes nothing once refused (LIST-05)",
        "a write refused while it waits on persist publishes nothing more (CR-01, D-30)",
        "a write whose read evidence is withdrawn while it waits on persist publishes nothing more (CR-01, D-31)",
      ),
      ...refs(
        RESTART,
        "a repair waiting on a signer prompt nobody answers publishes nothing after stop(), and the next start() saves a join at once (LIST-05)",
        "a repair waiting on a slow fragment record publishes nothing after stop() (CR-01, D-30)",
      ),
    ],
  },
  {
    id: "LIST-05.durable-before-publish",
    requirement: "LIST-05",
    level: "MUST",
    rule:
      "Before each fragment is published, every earlier accepted fragment is stored; when the record cannot be stored a repack, including a join or leave that overflows its fragment, stops before the signer is asked or before its next fragment, while a scoped write whose fragments fit still publishes, so only those joins and leaves are never blocked; a storage write that never settles fails the wait after a bound, and stop() ends any wait still pending.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a write waits for persist before each fragment it publishes (D-08)",
        "a write asks the signer for nothing until the record holds every accepted fragment (WR-01, D-08)",
        "a repack stops before its next fragment when persist rejects (D-08)",
        "a scoped write still publishes every fragment when persist keeps rejecting, so a full store never blocks a leave (WR-03)",
        "a repack prompts the signer for nothing when the fragment record cannot be stored (D-08)",
        "a join that overflows its fragment needs a repack, so with persist rejecting it publishes nothing and never asks the signer (WR-02)",
      ),
      ...refs(
        RESTART,
        "a repair whose fragment record cannot be stored halts before its next publication and succeeds on a later attempt (D-08)",
        "a leave still reaches the relays while the fragment record cannot be stored, and the failure is reported once (WR-03)",
        "a write of the fragment record that never settles holds a leave only for a bounded time, reported once (IN-02)",
      ),
      ...refs(
        STORE,
        "a failed write rejects with FragmentPersistError and reports once until a write succeeds",
        "a write that never settles fails its waiters after the bound, later waits at once, and release() rejects the rest (IN-02)",
      ),
    ],
  },
  {
    id: "LIST-06.no-fragment-fields-above-zero",
    requirement: "LIST-06",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "List-level fields are written only on fragment 0; a scoped write to a higher fragment never copies them there.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        EXTENSIONS,
        "a scoped write to fragment 1 drops fragment-level fields that fragment 0 already carries (D-09)",
        "a scoped write never adds the writer's own list-level fields to a fragment above zero (D-09)",
      ),
    ],
  },
  {
    id: "LIST-06.stranded-to-zero",
    requirement: "LIST-06",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A list-level field only a higher fragment carries is moved onto fragment 0 first, or kept and reported when fragment 0 is not held.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        EXTENSIONS,
        "a scoped write to fragment 1 writes fragment 0 first with stranded fields, then fragment 1 without them (D-18)",
        "a scoped write to fragment 1 keeps its fields and reports fragment-extension-retained when fragment 0 is not held (D-18)",
        "a write interrupted after fragment 0 still holds every stranded field (D-18)",
        "fragment-level fields union lowest index wins onto fragment 0 (D-10)",
        "strandedExtensionKeys names the list-level fields that only fragment 0 may carry",
      ),
    ],
  },
  {
    id: "LIST-06.unknown-fields-survive",
    requirement: "LIST-06",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "Every unknown field survives scoped writes and repacks byte for byte.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        EXTENSIONS,
        "a scoped write keeps every entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11)",
        "a repack keeps every fragment, entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11, D-12)",
      ),
      ...refs(
        SYNC,
        "empties dropped coordinates and carries extensions on fragment zero",
      ),
    ],
  },
  {
    id: "LIST-07.memberships-api",
    requirement: "LIST-07",
    level: "MUST",
    rule:
      "memberships$ and memberships() report live entries, tombstones, knowledge, locked and pending as copies, safe before start(), with no new runtime export, and reflect the client's own repair at once, which leaves communityListDirty$ false when nothing else is unpublished; memberships$ completes on dispose().",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        MEMBERSHIPS,
        "memberships() before start() is empty and unknown, and memberships$ emits that value (D-13)",
        "memberships() reports live entries, tombstones, knowledge and pending matching communityListStatus$ (D-13)",
        "memberships$ emits again on a join, a leave and another device's fragment (D-13)",
        "memberships() returns copies, so changing them never changes the client's list (D-13)",
        "an offline start reports unknown knowledge and a pending join through memberships() (D-13)",
        "memberships$ completes on dispose(), and a later subscription gets the current value, then completes (IN-03)",
      ),
      ...refs(
        RESTART,
        "after its own repair, memberships() and memberships$ hold the membership it brought back into range, with no unlock or restart (D-22)",
      ),
      ...refs(
        EXPORTS,
        "client barrel exposes the ConcordMemberships type for memberships$ (D-13)",
      ),
    ],
  },
  {
    id: "LIST-07.legacy-read-only",
    requirement: "LIST-07",
    level: "MUST",
    rule:
      "The client never publishes or dual-writes a kind 13302 list and still imports a legacy list through communityList$.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        MEMBERSHIPS,
        "the client publishes only kind-33302 fragments, never a kind-13302 list (D-15)",
        "a legacy kind-13302 list is still read and imported through communityList$ (D-15)",
      ),
    ],
  },
  {
    id: "LIST-08.no-lost-keys",
    requirement: "LIST-08",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "No repack step or restart loses a membership's key material.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "every acknowledged prefix of a repack is a complete List that keeps every membership, key and tombstone (D-17)",
      ),
      ...refs(
        RESTART,
        "a client restarted after every acknowledged repack prefix keeps every membership, key and tombstone and repairs the List once with auto-save on (LIST-04, LIST-08)",
      ),
    ],
  },
  {
    id: "LIST-08.no-revived-tombstones",
    requirement: "LIST-08",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "A dormant or duplicate copy never revives a community that a tombstone left.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a dormant membership never revives a community tombstoned in range (D-20)",
      ),
      ...refs(
        RESTART,
        "a client restarted after every acknowledged repack prefix keeps every membership, key and tombstone and repairs the List once with auto-save on (LIST-04, LIST-08)",
      ),
    ],
  },
  {
    id: "LIST-08.no-overwritten-unread",
    requirement: "LIST-08",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "A locked or unread dormant copy is never overwritten by a repack or repair.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a locked dormant copy blocks a repack and nothing is published (D-05)",
      ),
      ...refs(
        RESTART,
        "a locked dormant fragment blocks the repair until it is unlocked, so an unread copy is never overwritten (D-05, LIST-08)",
      ),
    ],
  },
  {
    id: "LIST-08.no-wedged-cleanup",
    requirement: "LIST-08",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Cleanup empties every held dormant index, including one beyond the staging range, so leftovers never wedge the List.",
    phase: 3,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "a repack empties a non-empty dormant fragment beyond its staging range (LIST-08)",
      ),
      ...refs(
        RESTART,
        "a repack refused by the relay after its first acknowledgment is repaired by the restarted client from its stored record (LIST-04, D-08)",
      ),
    ],
  },
  {
    id: "LIST-03.new-device-single-relay",
    requirement: "LIST-03",
    spec: "CORD-02 §8",
    level: "SHOULD",
    rule:
      "A device with no stored fragments should not take one relay's completed empty read as proof that the Community List is empty.",
    phase: 3,
    status: "residual",
    residual:
      "Not tightened in Phase 3 (D-20): stored fragments close the same-device case (T-01-06), but a new device or wiped storage still trusts the first relay that completes the read; recorded for the Phase 6 release review.",
    tests: [],
  },
  // Phase 6 CORD-02 §8 spec sweep (D-14): sentences of the pinned section that had tests but no ledger row. Each row cites
  // the tests that assert it; the evidence file maps every other sentence to an existing row or a reason.
  {
    id: "REL-01.list-base64url-named-fields",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Every 32-byte value the Community List names is written as unpadded base64url at any depth, including inside snapshots and each channels entry, re-encoded on every serialization whatever its internal spelling, and never case-folded.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "uses base64url, inherits identity, elides equal seeds and preserves staff roots",
        "writes every named 32-byte value as unpadded base64url at any depth, including each channels entry (CORD-02 §8)",
        "keeps case-significant keys distinct and rejects mismatched embedded runtime identity",
        "chooses base64url wire bytes rather than internal hex spelling",
      ),
    ],
  },
  {
    id: "REL-01.list-snapshot-omits-community-id",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A snapshot embedded in an entry carries no community_id (it inherits the entry's), while a standalone snapshot keeps it.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "uses base64url, inherits identity, elides equal seeds and preserves staff roots",
        "keeps case-significant keys distinct and rejects mismatched embedded runtime identity",
      ),
    ],
  },
  {
    id: "REL-01.list-seed-absent-when-equal",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "seed is absent whenever it equals current, so two devices holding the same state write the same bytes, and an absent seed reads as equal to current.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "uses base64url, inherits identity, elides equal seeds and preserves staff roots",
        "rewrites seed cosmetics and strips local history without modifying recovery state",
      ),
    ],
  },
  {
    id: "REL-01.list-seed-cosmetics-from-current",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Seed's name, relays and channel names are overwritten from current on every serialization, so a rename never forks the two snapshots.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "rewrites seed cosmetics and strips local history without modifying recovery state",
        "retains an older seed anchor and rewrites matching channel names without serializing channel history",
      ),
    ],
  },
  {
    id: "REL-01.list-snapshot-membership-subset",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A snapshot carries the membership subset plus control_root when the member holds it, and never the icon, the invite-link fields or local history.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "uses base64url, inherits identity, elides equal seeds and preserves staff roots",
        "rewrites seed cosmetics and strips local history without modifying recovery state",
        "never writes the icon, invite-link fields or local history into a membership snapshot (CORD-02 §8)",
      ),
    ],
  },
  {
    id: "REL-01.list-snapshot-merge-order",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Merging keeps the lower-epoch seed and the higher-epoch current, and an epoch tie breaks on the lowest canonical wire bytes of the whole snapshot, a total order so two devices never flap.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(LIST_HELPERS, "community merge is commutative and idempotent"),
      ...refs(
        WIRE,
        "chooses base64url wire bytes rather than internal hex spelling",
        "keeps the lower-epoch seed and the higher-epoch current in either merge order (CORD-02 §8)",
        "ignores local history when choosing equal-epoch wire snapshots",
        "retains valid staff secrets through all input permutations and repeated merges",
      ),
    ],
  },
  {
    id: "REL-01.list-unknown-fields-codec",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Unknown fields round-trip verbatim through the codec and the merges on the fragment, every entry, every seed and current snapshot, every tombstone and every channels entry, and are part of the canonical bytes.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "round-trips opaque fields at all levels without re-encoding nested lookalike keys",
        "round-trips unknown fields on a seed that differs from current, on its channels entries and on a tombstone (CORD-02 §8)",
        "preserves prototype-named extensions and orders Unicode keys by UTF-8 bytes",
        "unions opaque entry and tombstone extensions independently of input order",
      ),
      ...refs(
        EXTENSIONS,
        "a scoped write keeps every entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11)",
        "a repack keeps every fragment, entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11, D-12)",
      ),
    ],
  },
  {
    id: "REL-01.list-tombstone-wins-omit-entry",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "An entry whose added_at does not exceed its Community's removed_at is omitted from the written fragment, while the tombstone is kept.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        WIRE,
        "omits covered entries but retains tombstones and local backfill material",
        "omits an entry whose added_at ties its tombstone's removed_at and keeps one added a millisecond later (CORD-02 §8)",
      ),
    ],
  },
  {
    id: "REL-01.list-liveness-newest-wins",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "The newest of added_at and removed_at wins: a re-join resurrects a membership, a stale or dormant add never re-adds a tombstoned id, and one tombstone per Community keeps the later removed_at.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        LIST_HELPERS,
        "tombstone merge keeps the newest removal",
        "liveness: leave kills, later re-join resurrects",
      ),
      ...refs(SYNC, "a dormant membership never revives a community tombstoned in range (D-20)"),
    ],
  },
  {
    id: "REL-01.list-count-governs-newest-larger-wins",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "frags is read from the newest fragment seen and the larger value wins at equal age, a List is complete when a fragment is held at every index below it whatever their ages, and fragments are unioned so a membership held twice merges to one.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "tracks mixed-age completeness and resolves count ties upward",
        "documentAll unions in-range and dormant fragments with the lowest index winning (D-20)",
      ),
    ],
  },
  {
    id: "REL-01.list-scoped-write-one-fragment",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "Adding, updating or tombstoning one membership rewrites only the fragment holding it and needs only that fragment, so a fragment stranded on an unreachable relay never blocks a join or a leave.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "allows scoped writes during incomplete reads and keeps remote memberships",
        "a scoped write still publishes every fragment when persist keeps rejecting, so a full store never blocks a leave (WR-03)",
      ),
      ...refs(
        RESTART,
        "a leave still reaches the relays while the fragment record cannot be stored, and the failure is reported once (WR-03)",
      ),
    ],
  },
  {
    id: "REL-01.list-lowering-empties-dropped",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A repack that lowers frags republishes each dropped fragment as a zero-element List, with no entries and no tombstones, carrying the new frags.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        SYNC,
        "empties dropped coordinates and carries extensions on fragment zero",
        "a repack plan includes dormant memberships and empties every non-empty dormant index (D-20)",
      ),
    ],
  },
  {
    id: "REL-01.list-event-ceiling",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "The fully encoded fragment event, after encryption and signing, never exceeds 65,536 bytes: it is measured before publishing and a new fragment is started rather than exceeding it.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        CEILING,
        "a join that would push a nearly full fragment past 65,536 bytes starts a new fragment and every published event stays within the ceiling (CORD-02 §8)",
      ),
      ...refs(
        SYNC,
        "splits using final encrypted signed event sizes without losing records",
        "a join that overflows its fragment needs a repack, so with persist rejecting it publishes nothing and never asks the signer (WR-02)",
      ),
    ],
  },
  {
    id: "REL-01.list-no-shed-for-ceiling",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule: "Unknown fields are never shed to fit the event ceiling; the client starts a new fragment instead.",
    phase: 6,
    status: "covered",
    tests: refs(
      CEILING,
      "starting a new fragment to fit the ceiling keeps every unknown field instead of shedding it (CORD-02 §8)",
    ),
  },
  {
    id: "REL-01.list-shrink-exempt",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "MUST",
    rule:
      "A write that strictly shrinks a fragment already past the ceiling is exempt from it, so a member over the ceiling can still leave, while a write that grows such a fragment splits.",
    phase: 6,
    status: "covered",
    tests: refs(
      CEILING,
      "a write that strictly shrinks a fragment already past the ceiling is published in place, while one that grows it splits (CORD-02 §8)",
    ),
  },
  {
    id: "REL-01.list-pack-target",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "SHOULD",
    rule:
      "Fragments are packed to a target comfortably under the ceiling (the reference target is 56 KiB), treating the ceiling as the refusal line and never the goal.",
    phase: 6,
    status: "covered",
    tests: refs(SYNC, "splits using final encrypted signed event sizes without losing records"),
  },
  {
    id: "REL-01.list-capture-keys-before-leave",
    requirement: "REL-01",
    spec: "CORD-02 §8",
    level: "SHOULD",
    rule:
      "A client whose users expect pre-leave history to survive a leave should capture the departing Community's keys locally before tombstoning it.",
    phase: 6,
    status: "residual",
    residual:
      "leave() tombstones the membership and prunes its entry, keys included, and the library keeps no local copy of the departing Community's keys; an app whose users expect pre-leave history must read the Community's material itself and store it before calling leave(). Recorded for the Phase 6 release review and the docs plans.",
    tests: [],
  },
  {
    id: "EXP-01.every-folded-channel",
    requirement: "EXP-01",
    spec: "CORD-08 §3",
    level: "SHOULD",
    rule:
      "Purge removes expired Chat from the store of every folded non-deleted channel, including persistent stores not opened this session, and never opens a deleted channel's store.",
    phase: 4,
    status: "covered",
    tests: refs(
      PURGE,
      "purge sweeps a persistent channel store never opened this session",
      "purge never opens a deleted channel's store (D-03)",
    ),
  },
  {
    id: "EXP-01.private-and-held-epochs",
    requirement: "EXP-01",
    spec: "CORD-08 §3",
    level: "SHOULD",
    rule:
      "Purge reaches private channels, including ones the user left, and retained wraps under every held epoch, including older private epochs after a restart.",
    phase: 4,
    status: "covered",
    tests: refs(
      PURGE,
      "purge sweeps the store of a private channel the user left (D-18)",
      "purge removes expired wraps under an older private epoch after a restart (D-02, D-18)",
      "the wrap sweep plane map reaches every held private epoch from material alone (D-18)",
    ),
  },
  {
    id: "EXP-01.bounded-sweep",
    requirement: "EXP-01",
    level: "MUST",
    rule:
      "Purge judges expiry on the engine's duty clock, reports a failing store as expiration-purge and keeps going, and does nothing after dispose.",
    phase: 4,
    status: "covered",
    tests: refs(
      PURGE,
      "purge judges expiry on the injected duty clock (D-07)",
      "a failing channel store is reported as expiration-purge and the sweep continues",
      "a store factory that throws for one channel is reported with its id and the other channels are still swept",
      "purge after dispose resolves 0 and opens no store",
    ),
  },
  {
    id: "EXP-02.never-displayed",
    requirement: "EXP-02",
    spec: "CORD-08 §3",
    level: "MUST",
    rule: "An expired Chat rumor is never displayed, including one stored before its expiry passed.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(
        PURGE,
        "an expired cached rumor is never displayed and is removed from the database when its store opens",
      ),
      ...refs(EXPIRY, "hides messages without new traffic and gates notices on changing authority"),
    ],
  },
  {
    id: "EXP-02.never-retained",
    requirement: "EXP-02",
    spec: "CORD-08 §3",
    level: "MUST",
    rule:
      "An expired Chat rumor is refused before retention and an expired cached rumor is deleted when its store opens, public or private.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(EXPIRY, "rejects expired rumors before retention"),
      ...refs(
        RECEIVE,
        "the receive boundary refuses an already-expired Chat rumor whatever its outer tag says (CORD-08 §2, §3)",
      ),
      ...refs(
        PURGE,
        "an expired cached rumor is never displayed and is removed from the database when its store opens",
        "a private channel's cached expired rumor is removed when its engine opens the store",
        "live cached rumors and timer notices survive the open-time sweep",
        "purge counts rows the open-time sweep removed",
        "the open-time sweep runs once per store and never after dispose",
      ),
    ],
  },
  {
    id: "EXP-03.opt-in-owned",
    requirement: "EXP-03",
    level: "MUST",
    rule:
      "Periodic purge is opt-in, off by default, owned by the community's duty scope, and stops on its disposer, dispose and dissolution.",
    phase: 4,
    status: "covered",
    tests: refs(
      SCHEDULE,
      "no purge is scheduled by default",
      "schedulePurge sweeps at once, then once per interval",
      "the disposer stops the schedule and a second schedule replaces the first",
      "dispose and dissolution stop the schedule",
      "a schedule armed before the engine is live sweeps again once sync reaches live",
      "a fresh sweep waiting on a running sweep starts none once its schedule stopped meanwhile",
    ),
  },
  {
    id: "EXP-03.bounded",
    requirement: "EXP-03",
    level: "MUST",
    rule:
      "A purge schedule validates its interval, never overlaps sweeps and reports failures without throwing from the timer.",
    phase: 4,
    status: "covered",
    tests: refs(
      SCHEDULE,
      "schedulePurge rejects an invalid interval before arming anything",
      "a scheduled sweep never overlaps another sweep",
      "a failed scheduled sweep is reported as expiration-purge and the next tick retries",
    ),
  },
  {
    id: "EXP-03.client-fan-out",
    requirement: "EXP-03",
    level: "MUST",
    rule: "client.schedulePurge reaches current, later-joined and rebuilt communities and its disposer stops them all.",
    phase: 4,
    status: "covered",
    tests: refs(
      SCHEDULE,
      "client.schedulePurge reaches current and later-joined communities and survives stop and start",
      "the client disposer stops every community's schedule and schedulePurge throws after dispose",
    ),
  },
  {
    id: "EXP-03.options-type-only",
    requirement: "EXP-03",
    level: "MUST",
    rule:
      "The purge schedule options are a public type only: the client barrel exposes no runtime value for ConcordPurgeScheduleOptions and keeps the purge engine and its schedule registry internal. (Split from EXP-03.client-fan-out in Phase 6 so that row is judged by its behavior tests, not by the barrel test alone.)",
    phase: 6,
    status: "covered",
    tests: refs(EXPORTS, "client barrel exposes the ConcordPurgeScheduleOptions type for schedulePurge (D-09)"),
  },
  {
    id: "EXP-04.signed-tag-only",
    requirement: "EXP-04",
    spec: "CORD-08 §2",
    level: "MUST",
    rule:
      "Expiry is judged only by the signed rumor's expiration tag with the strict rule; the outer wrap tag is a relay hint.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(
        PURGE,
        "a live rumor under a forged past outer tag is retained and displayed",
        "purge removes retained wraps by the signed rumor alone, whatever the outer tag says (D-06)",
        "a control edition under a past outer tag stays refused, so a Refounding still recovers every head seal",
      ),
      ...refs(
        RECEIVE,
        "addWrap keeps an authenticated wrap whose only refusal is a past outer expiration tag (CORD-08 §2)",
      ),
      ...refs(
        CHANNEL_WALK,
        "a channel rekey under a past outer tag is not adopted by the walk, as live receive drops it (D-22)",
      ),
      ...refs(EXPIRY, "judges the expiration tag by the library's strict rule (D-21)"),
    ],
  },
  {
    id: "EXP-05.forged-outer-hide",
    requirement: "EXP-05",
    spec: "CORD-08 §2",
    level: "MUST",
    rule: "A forged past outer tag cannot hide a live message at community, private-channel or sync receive.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(PURGE, "a live rumor under a forged past outer tag is retained and displayed"),
      ...refs(
        PRIVATE,
        "a private channel retains a live rumor under a forged past outer tag through sync and live receive (D-17)",
      ),
      ...refs(SYNC_WALK, "syncAuthors retains a live channel rumor under a forged past outer tag (D-17)"),
    ],
  },
  {
    id: "EXP-05.forged-outer-revive",
    requirement: "EXP-05",
    spec: "CORD-08 §3",
    level: "MUST",
    rule: "An absent or future outer tag cannot keep an expired message.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(
        PURGE,
        "an expired rumor under an absent or future outer tag is refused at ingest",
        "purge removes retained wraps by the signed rumor alone, whatever the outer tag says (D-06)",
      ),
      ...refs(
        RECEIVE,
        "the receive boundary refuses an already-expired Chat rumor whatever its outer tag says (CORD-08 §2, §3)",
      ),
    ],
  },
  {
    id: "EXP-05.non-retroactive",
    requirement: "EXP-05",
    spec: "CORD-08 §2",
    level: "MUST",
    rule: "Timer changes affect only later sends.",
    phase: 4,
    status: "covered",
    tests: refs(
      PURGE,
      "timer changes are not retroactive: only messages stamped under a timer expire (CORD-08 §2)",
    ),
  },
  {
    id: "EXP-05.stamp-durable",
    requirement: "EXP-05",
    spec: "CORD-08 §2",
    level: "MUST",
    rule:
      "Every durable Chat send carries created_at plus the timer on the rumor and the same value on the outer wrap.",
    phase: 4,
    status: "covered",
    tests: refs(
      EXPIRY,
      "stamps every durable Chat kind on the rumor and its outer wrap (CORD-08 §2)",
      "copies author expiration onto the durable wrap and rechecks cached receives as time advances",
    ),
  },
  {
    id: "EXP-05.exempt-unstamped",
    requirement: "EXP-05",
    spec: "CORD-08 §2",
    level: "MUST",
    rule: "Deletions, timer notices, ephemeral kinds and non-Chat planes never carry an expiration.",
    phase: 4,
    status: "covered",
    tests: refs(
      EXPIRY,
      "never stamps exempt kinds or non-Chat planes (CORD-08 §2)",
      "stamps final Unix-second time and strips tags from exempt kinds",
    ),
  },
  {
    id: "EXP-05.tombstones",
    requirement: "EXP-05",
    spec: "CORD-08 §2",
    level: "MUST",
    rule: "Retained deletions never expire and keep a purged target from being resurrected.",
    phase: 4,
    status: "covered",
    tests: refs(
      PURGE,
      "retained deletion tombstones survive purge and hydration and a purged target is never resurrected (D-15)",
    ),
  },
  {
    id: "EXP-06.purge-pinned",
    requirement: "EXP-06",
    level: "MUST",
    rule:
      "Purge removes an expired pinned message like any other, the pin stays hidden and expiry publishes no Control edition.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(
        PINS,
        "purge removes an expired pinned message while the pin stays hidden and no Control edition is published (EXP-06)",
      ),
      ...refs(MAINTAINER, "expiry never schedules upkeep (D-02)"),
    ],
  },
  {
    id: "EXP-06.purge-wins",
    requirement: "EXP-06",
    level: "MUST",
    rule:
      "Purge removes an expired newest Edit even when a pin then shows older bundled text, a refreshed bundle keeps the pin hidden, and purge drops every expired Edit's seal from memory by its signed expiry, even after a store's own expiry timer removed the Edit.",
    phase: 4,
    status: "covered",
    tests: [
      ...refs(
        PINS,
        "purge removes an expired newest Edit even when a pin then shows older bundled text (D-19)",
        "a pin whose bundled Edit was refreshed stays hidden after its expired Edit is purged (D-19)",
        "a purge drops an Edit's seal after the stores' own expiry timers removed its row and wrap (CORD-08 §3)",
        "an Edit already expired when retention judges it is never noted as a seal (CORD-08 §3)",
        "the seal of an Edit the store refuses in its last half-second is dropped by the next purge (CORD-08 §3, D-21)",
      ),
      ...refs(SEALS, "judges each seal by its signed Edit expiry, at note, at proof and on forgetExpired (CORD-08 §3)"),
    ],
  },
  {
    id: "EXP-01.host-swept",
    requirement: "EXP-01",
    spec: "CORD-08 §3",
    level: "SHOULD",
    rule: "Expired Chat in stores and wraps outside the engine's reach should also be purged.",
    phase: 4,
    status: "residual",
    residual:
      "The engine cannot enumerate or decrypt external app caches, deleted channels' stores, the channel stores of communities the user left, was removed from or was refounded out of, a dissolved community's stores once dissolution ended its schedule, or wraps whose keys it no longer holds (D-02, D-03, D-13); docs/guide/storage.md names them for the host to sweep.",
    tests: [],
  },
  {
    id: "EXP-04.app-store-nip40",
    requirement: "EXP-04",
    spec: "CORD-08 §2",
    level: "SHOULD",
    rule: "Expiry should be judged only by the strict signed-tag rule wherever a rumor is stored.",
    phase: 4,
    status: "residual",
    residual:
      "applesauce-core rumor stores apply their own lenient NIP-40 check when a rumor is added (D-21), so an app's store can refuse a non-compliant message with a malformed tag that the library would keep; documented in docs/guide/storage.md and not changed in Phase 4.",
    tests: [],
  },
  {
    id: "REL-01.exp-malformed-timer-off",
    requirement: "REL-01",
    spec: "CORD-08 §1",
    level: "MUST",
    rule:
      "A message_expiration that is absent, zero or malformed (not a positive whole number of seconds) reads as off, and a reader never guesses a default from it: the sender stamps neither the rumor nor its outer wrap.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        EXPIRY,
        "stamps final Unix-second time and strips tags from exempt kinds",
        "a malformed or absent community timer stamps nothing on the rumor or its wrap (CORD-08 §1)",
      ),
      ...refs(
        PURGE,
        "a malformed message_expiration in the folded metadata reads as off, so a send carries no expiration (CORD-08 §1)",
      ),
    ],
  },
  {
    id: "REL-01.exp-notice-gated",
    requirement: "REL-01",
    spec: "CORD-08 §4",
    level: "MUST",
    rule:
      "A timer notice (kind 1740) is displayed only if its author holds MANAGE_METADATA in the fold and is dropped otherwise; the spec words this as a reader behavior without a keyword, and the ledger treats it as a MUST.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(EXPIRY, "hides messages without new traffic and gates notices on changing authority"),
      ...refs(
        PURGE,
        "a timer notice is displayed only when its author holds MANAGE_METADATA in the fold (CORD-08 §4)",
      ),
    ],
  },
  {
    id: "REL-01.exp-timer-notice",
    requirement: "REL-01",
    spec: "CORD-08 §4",
    level: "SHOULD",
    rule:
      "After publishing a timer change, the actor posts one timer notice (kind 1740, the channel binding and a timer tag with the new seconds, no expiration) into each channel whose key they hold, and none where the key is not held.",
    phase: 6,
    status: "covered",
    tests: refs(
      PURGE,
      "setMessageExpiration posts one timer notice into each channel whose key the actor holds (CORD-08 §4)",
    ),
  },
  {
    id: "FORUM-01.subject-wire",
    requirement: "FORUM-01",
    level: "MUST",
    rule:
      "A titled forum post is a kind 9 message with exactly one subject tag plus the channel, epoch and ms tags, sent through sendMessage with a subject option or an options object (the spec's own keyword for the tag is MAY, which the ledger does not model); a blank title publishes no tag and a non-blank title is never trimmed.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        FORUM,
        "sendMessage with a subject publishes kind 9 with one subject tag and the channel binding (CORD-03 §3)",
        "sendMessage takes an options object as its third argument and keeps the positional reply parent (D-18)",
        "an empty or whitespace-only subject publishes no subject tag (D-22)",
      ),
      ...refs(FORUM_OPS, "includeSubject sets exactly one subject tag and keeps the title verbatim"),
    ],
  },
  {
    id: "FORUM-01.subject-cap",
    requirement: "FORUM-01",
    spec: "CORD-03 §3",
    level: "MUST",
    rule:
      "The subject must not exceed 256 bytes of UTF-8; an over-cap title is rejected before anything is uploaded or signed.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        FORUM_HELPERS,
        "assertSubject accepts exactly 256 UTF-8 bytes and rejects 257 with a RangeError (D-03)",
        "assertSubject counts multibyte and astral characters in UTF-8 bytes",
        "assertSubject never echoes the subject in its error message",
      ),
      ...refs(FORUM, "an over-cap subject rejects with RangeError before any upload or publish (D-03)"),
    ],
  },
  {
    id: "FORUM-02.display-truncation",
    requirement: "FORUM-02",
    spec: "CORD-03 §3",
    level: "MUST",
    rule:
      "A receiver truncates an over-long subject for display on a code-point boundary and never drops the message because of it.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        FORUM_HELPERS,
        "displaySubject returns a subject within the cap unchanged",
        "displaySubject truncates an overlong subject to 256 bytes on a code-point boundary with no ellipsis (D-04)",
        "displaySubject never splits a four-byte character at any cut position",
        "displaySubject is total for lone surrogates and custom caps",
        "getSubject reads the first subject tag and ignores malformed tags",
      ),
      ...refs(
        FORUM,
        "a received post with an overlong subject is kept and displays truncated on a code-point boundary (FORUM-02, D-04)",
      ),
    ],
  },
  {
    id: "FORUM-05.kind-11-readable",
    requirement: "FORUM-05",
    level: "MUST",
    rule:
      "Kind 11 thread roots already retained stay readable with their ids unchanged and are never rewritten, and getSubject reads their NIP-7D title tag so they keep their titles.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(FORUM, "a retained kind 11 thread root stays readable in channelTimeline"),
      ...refs(FORUM_HELPERS, "getSubject falls back to the title tag of a legacy kind 11 thread root (FORUM-05, D-08)"),
    ],
  },
  {
    id: "FORUM-05.reply-root-inheritance",
    requirement: "FORUM-05",
    spec: "CORD-03 §3",
    level: "SHOULD",
    rule:
      "Replies are kind 1111 and inherit their parent's uppercase root tags verbatim, so a reply to a kind 9 or kind 11 root keeps that root at any depth (the section states the rule without a keyword).",
    phase: 5,
    status: "covered",
    tests: refs(
      FORUM,
      "a reply to a titled post roots at the kind 9 post (CORD-03 §3)",
      "replies to a kind 11 root carry K=11 and a depth-2 reply inherits that root",
    ),
  },
  {
    id: "DEC-03.send-thread-alias",
    requirement: "DEC-03",
    level: "MUST",
    rule:
      "sendThread is a deprecated alias that publishes a titled kind 9 post and never a kind 11; an empty title publishes an untitled message.",
    phase: 5,
    status: "covered",
    tests: refs(
      FORUM,
      "sendThread publishes a titled kind 9 and never a kind 11 (DEC-03, D-02)",
      "sendThread with an empty title publishes an untitled kind 9 (D-22)",
    ),
  },
  {
    id: "FORUM-06.subject-exports",
    requirement: "FORUM-06",
    level: "MUST",
    rule: "The subject helpers and includeSubject are public runtime exports pinned by the export tests.",
    phase: 5,
    status: "covered",
    tests: refs(EXPORTS, "forum subject helpers and includeSubject are public runtime exports (FORUM-06)"),
  },
  {
    id: "FORUM-03.view-typed",
    requirement: "FORUM-03",
    spec: "CORD-03 §2",
    level: "MUST",
    rule:
      "A channel's view is chat by default and forum only for the exact value forum; an unknown or malformed value is presented as chat rather than rejected.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        FORUM_HELPERS,
        "channelViewMode presents forum only for the exact value and chat for anything else (D-05)",
      ),
      ...refs(FORUM, "an unknown view value presents as chat and survives deleteChannel unchanged (D-05)"),
    ],
  },
  {
    id: "FORUM-03.view-preserved",
    requirement: "FORUM-03",
    spec: "CORD-03 §2",
    level: "MUST",
    rule:
      "The view field is preserved on every edition the library publishes, including an unknown value carried into a deletion.",
    phase: 5,
    status: "covered",
    tests: refs(FORUM, "an unknown view value presents as chat and survives deleteChannel unchanged (D-05)"),
  },
  {
    id: "FORUM-03.channels-reemit",
    requirement: "FORUM-03",
    level: "MUST",
    rule:
      "channels$ emits again when a channel is renamed or its view changes and stays quiet when an unrelated control edition folds.",
    phase: 5,
    status: "covered",
    tests: refs(
      FORUM,
      "channels$ re-emits when a channel is renamed (D-06)",
      "channels$ re-emits when a channel's view changes (D-06)",
      "channels$ stays quiet when an unrelated control edition folds",
    ),
  },
  {
    id: "FORUM-03.create-view",
    requirement: "FORUM-03",
    level: "MUST",
    rule:
      "createChannel writes view forum only for a forum channel, omits the view for chat, and rejects any other value with a TypeError before a key is minted.",
    phase: 5,
    status: "covered",
    tests: refs(
      FORUM,
      "createChannel with view forum writes view forum and channels$ presents it (D-23)",
      "createChannel without a view writes no view field and channels$ presents chat",
      "createChannel rejects an unknown view before minting a key",
    ),
  },
  {
    id: "FORUM-04.edit-k-tag",
    requirement: "FORUM-04",
    spec: "CORD-03 §3",
    level: "SHOULD",
    rule:
      "An edit carries a k tag naming the kind of the message it edits (9, 1111, or 11 for a legacy root) when that kind is known.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(FORUM_OPS, "includeEditTarget adds a k tag only when the target kind is known (D-07)"),
      ...refs(FACTORY_EDIT, "EditFactory.create carries the target kind as a k tag when given (D-07)"),
      ...refs(
        FORUM,
        "editMessage with a rumor target carries k=9 for a message and k=1111 for a reply",
        "editMessage with a bare id looks the kind up in the channel store and omits k when the target is unknown",
        "editMessage of a legacy kind 11 root carries k=11 (D-07)",
      ),
    ],
  },
  {
    id: "FORUM-04.receiver-ignores-k",
    requirement: "FORUM-04",
    level: "MUST",
    rule: "A receiver never requires the k tag: an edit with no k, a wrong k or k=11 still applies to its target.",
    phase: 5,
    status: "covered",
    tests: refs(FORUM, "an Edit with no k, a wrong k or k=11 still applies to its target"),
  },
  {
    id: "FORUM-06.view-exports",
    requirement: "FORUM-06",
    level: "MUST",
    rule: "channelViewMode is a public runtime export pinned by the export tests.",
    phase: 5,
    status: "covered",
    tests: refs(EXPORTS, "channelViewMode is a public runtime export (FORUM-06)"),
  },
  {
    id: "REL-01.forum-binding-commit",
    requirement: "REL-01",
    spec: "CORD-03 §3",
    level: "MUST",
    rule:
      "Each Chat-plane message commits [channel, channel_id] and [epoch, n] inside the author-signed rumor: the binding operation stamps both tags, and a sent message carries them.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(CHAT_OPS, "includeChannelBinding adds channel + epoch tags"),
      ...refs(FACTORY_MESSAGE, "binds channel/epoch, p-tags mentions, emoji-tags shortcodes"),
      ...refs(
        FORUM,
        "sendMessage with a subject publishes kind 9 with one subject tag and the channel binding (CORD-03 §3)",
      ),
    ],
  },
  {
    id: "REL-01.forum-binding-drop",
    requirement: "REL-01",
    spec: "CORD-03 §3",
    level: "MUST",
    rule:
      "A receiver checks the channel and epoch tags strict-equal against the Channel and epoch whose key decrypted the wrap and drops a mismatch, on the community route and on the private channel route, for a wrong value, a padded epoch and a missing tag alike.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        CHAT_HELPERS,
        "checkChatBinding accepts only the exact channel id and the exact epoch number (CORD-03 §3)",
      ),
      ...refs(
        FORUM,
        "a received rumor whose channel or epoch tag does not strict-equal its plane is dropped (CORD-03 §3)",
      ),
      ...refs(
        PRIVATE,
        "a private channel drops a rumor whose channel or epoch tag does not strict-equal its key (CORD-03 §3)",
      ),
    ],
  },
  {
    id: "REL-01.ban-signer-holds-ban",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "A Banlist edition is honored only if its signer holds BAN: a ranked member without the bit that outranks the target bans nobody, on the fold and on the local writer.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(BANLIST_HELPERS, "honors a Banlist only when its signer holds BAN (CORD-04 §4)"),
      ...refs(
        COMMUNITY,
        "ban() rejects locally before any publish when the caller lacks BAN or does not outrank the target (AUTH-05)",
      ),
    ],
  },
  {
    id: "REL-01.ban-strict-outrank",
    requirement: "REL-01",
    spec: "CORD-04 §3",
    level: "MUST",
    rule:
      "A Banlist entry takes effect only when its signer strictly outranks the target: a junior cannot ban a senior and a peer of equal position cannot ban a peer, on the fold and on the local writer.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        BANLIST_HELPERS,
        "honors a Banlist entry only when its signer strictly outranks the target: a peer is not banned (CORD-04 §3)",
        "banTargetFailures lists every failing target with its reason (D-09)",
      ),
      ...refs(
        CONTROL,
        "honors a banlist entry only when the signer strictly outranks the target, and the owner is never bannable (D-14)",
      ),
    ],
  },
  {
    id: "REL-01.ban-owner-unbannable",
    requirement: "REL-01",
    spec: "CORD-04 §2",
    level: "MUST",
    rule:
      "The owner is supreme and unremovable: no Banlist edition, whoever signs it, bans the owner, and a Banlist set that carries the owner key still leaves the owner a member.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        BANLIST_HELPERS,
        "never bans the owner, whoever signs the list (CORD-04 §2)",
        "banTargetFailures lets the owner ban any member except the owner and self",
      ),
      ...refs(
        GUESTBOOK,
        "leaves the owner a member when a banlist carries their pk, while still removing a banned non-owner",
      ),
    ],
  },
  {
    id: "REL-01.ban-drops-authority-actions",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "An authority action (a Control edition) signed by a banned npub is dropped from the fold, while the editions of everyone else stay.",
    phase: 6,
    status: "covered",
    tests: refs(BANLIST_HELPERS, "drops the authority actions of a banned npub (CORD-04 §4)"),
  },
  {
    id: "REL-01.ban-drops-chat-events",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "A banned npub's message, reaction, edit and comment never reach the ban-aware channel timeline that every fold and every rendering reads, and an Edit signed by a banned author is ignored.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(MODELS_CHAT, "drops a banned author's message, reaction, edit and comment, and keeps everyone else's"),
      ...refs(
        EDIT_HELPERS,
        "newestValidEdit ignores wrong author, wrong channel, edit of an edit, malformed ms, expired and banned edits",
      ),
    ],
  },
  {
    id: "REL-01.ban-member-vanishes",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "A banned npub vanishes from membership: its Guestbook entries count for nothing and its observed activity does not make it a member.",
    phase: 6,
    status: "covered",
    tests: [
      ...refs(
        BANLIST_HELPERS,
        "removes a banned author from observed activity",
        "ignores the membership effects of a banned author, including a secondhand Snapshot",
      ),
      ...refs(GUESTBOOK, "coalesces joins/leaves, honors banlist"),
      ...refs(MODELS, "removes banned observed authors from community state"),
    ],
  },
  {
    id: "REL-01.ban-head-replaces-list",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "The Banlist is replaced entire on every edit: only the highest version's list counts, so a lifted ban stays lifted and a relay replaying a stale version changes nothing, in either delivery order.",
    phase: 6,
    status: "covered",
    tests: refs(
      BANLIST_HELPERS,
      "replaces the whole list with the highest version and refuses to downgrade (CORD-04 §1, §4)",
    ),
  },
  {
    id: "REL-01.ban-same-version-converges",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "Two authorized Banlist editions at the same version converge on one: the fold keeps the lower rumor id in every delivery order and the other edition's addition drops until it is re-applied.",
    phase: 6,
    status: "covered",
    tests: refs(
      BANLIST_HELPERS,
      "keeps one of two same-version Banlist editions, the lower rumor id, and drops the other's addition (CORD-04 §1, §4)",
    ),
  },
  {
    id: "REL-01.ban-derived-coordinate",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "The Banlist is one Community-wide entity at the coordinate derived from the community id: a Banlist edition at any other coordinate is not folded, whichever arrives first.",
    phase: 6,
    status: "covered",
    tests: refs(CONTROL, "folds the banlist only at its derived coordinate"),
  },
  {
    id: "REL-01.ban-wire-lowercase-hex",
    requirement: "REL-01",
    spec: "CORD-04 §4",
    level: "MUST",
    rule:
      "A Banlist edition a client writes carries the whole list as lowercase 64-hex public keys: targets are lowercased and deduplicated, and the next list is built from the head content.",
    phase: 6,
    status: "covered",
    tests: refs(
      BANLIST_HELPERS,
      "normalizeBanTargets lowercases, dedupes and reports invalid keys",
      "planBanlistWrite builds from the head content, not the effective set",
    ),
  },
  {
    id: "BAN-01.validated-first",
    requirement: "BAN-01",
    level: "MUST",
    rule:
      "banMembers checks every target first (invalid key, owner, self, not outranked, missing MANAGE_ROLES) and on any failure throws BanMembersError listing each member and reason, publishing nothing.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(BANLIST, "banMembers validates every target first and publishes nothing when any fails (D-09)"),
      ...refs(BANLIST_HELPERS, "banTargetFailures lists every failing target with its reason (D-09)"),
    ],
  },
  {
    id: "BAN-01.single-edition",
    requirement: "BAN-01",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule:
      "A bulk ban puts every target in one Banlist edition, and the roles of targets that hold any are stripped alongside.",
    phase: 5,
    status: "covered",
    tests: refs(
      BANLIST,
      "banMembers publishes one Banlist edition, strips each role holder and returns the banned members",
      "a batch too large for one Banlist edition rejects before anything is published",
    ),
  },
  {
    id: "BAN-01.shared-refounding",
    requirement: "BAN-01",
    spec: "CORD-04 §6",
    level: "SHOULD",
    rule:
      "A batch ban publishes the Banlist edition first, the Grant strips alongside and one shared Refounding that excludes every target last; a failed Refounding leaves the ban published. A stored Refounding that would still deliver the root to a target (refounding-pending, finish it with refound()) or that refound() refuses to finish because it is blocked, from another epoch or prepared against a since-changed state (refounding-blocked, remove it with discardPendingRefounding()) refuses the call before anything is published. An interrupted shared Refounding resumes with refound() whatever the order of the members it keeps.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        BANLIST,
        "banMembers with refound runs one shared Refounding that excludes every target",
        "a failed shared Refounding leaves the Banlist edition published",
        "banMembers with refound refuses when a stored Refounding would still deliver the root to a target",
        "banMembers with refound refuses every target while a stored Refounding cannot be finished",
      ),
      ...refs(
        REFOUND_DISCARD,
        "refuses with refounding-blocked when the stored preparation no longer matches, and publishes nothing",
        "refound({ keep: [b, a] }) with b > a resumes and completes after an interruption",
        "an interrupted banMembers({ refound: true }) keeping two or more members resumes with refound()",
      ),
    ],
  },
  {
    id: "BAN-01.discard-refused-refounding",
    requirement: "BAN-01",
    spec: "CORD-06 §3",
    level: "SHOULD",
    rule:
      "discardPendingRefounding() removes a stored Refounding only when refound() refuses to finish it (blocked, from another epoch, or prepared against a since-changed state), reports the removal on diagnostics$ as refounding-discarded and resolves true, after which refound() runs again; a record refound() can still finish is kept and the call resolves false.",
    phase: 5,
    status: "covered",
    tests: refs(
      REFOUND_DISCARD,
      "removes a record prepared against a since-changed state, reports it, and refound() works again",
      "removes a record marked blocked, and refound() works again",
      "removes a record left from another epoch, and refound() works again",
      "keeps a record refound() can still finish and returns false; refound() then resumes it",
    ),
  },
  {
    id: "BAN-02.serialized",
    requirement: "BAN-02",
    level: "MUST",
    rule:
      "Local ban, unban and banMembers calls on one community run through one serial queue in call order, each building on the head the previous write produced, so parallel bans keep every ban.",
    phase: 5,
    status: "covered",
    tests: refs(BANLIST, "parallel ban calls chain into consecutive editions and keep every ban (D-10)"),
  },
  {
    id: "BAN-02.rate-limited",
    requirement: "BAN-02",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule:
      "At most 10 Banlist editions per minute per community, counting queued writes; the next call rejects at once with BanlistRateLimitError and never waits.",
    phase: 5,
    status: "covered",
    tests: refs(
      BANLIST,
      "the eleventh Banlist edition within a minute rejects with BanlistRateLimitError and passes after the window (D-11)",
      "queued writes count toward the rate limit when they are enqueued (D-11)",
    ),
  },
  {
    id: "BAN-02.last-intent-wins",
    requirement: "BAN-02",
    level: "MUST",
    rule:
      "The last local intent per member wins; an unban of a member the head omits publishes nothing unless this client's own Banlist history still lists the member, in which case the head content is republished unchanged.",
    phase: 5,
    status: "covered",
    tests: refs(
      BANLIST,
      "a ban and an unban in flight together leave the member unbanned (D-12)",
      "unban of a member absent from the head publishes nothing and records the cancel (D-12)",
      "unban of a lost own ban republishes the head unchanged so the ban cannot be revived (D-12, D-21)",
    ),
  },
  {
    id: "BAN-05.rejected-ack",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "Every Banlist write waits for a relay acknowledgment; when none accepts it, the call rejects with RequiredPublishError and local state, recorded intents and the rate window are unchanged.",
    phase: 5,
    status: "covered",
    tests: refs(
      BANLIST,
      "a rejected acknowledgment rejects with RequiredPublishError and changes no local state (D-20)",
      "recorded intents name the edition each ban or unban published (D-13)",
    ),
  },
  {
    id: "BAN-05.mixed-rank-write",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "A Banlist write never carries or lifts a ban the writer does not strictly outrank: it rejects with BanlistWriteBlockedError and publishes nothing, while the owner can unban anyone.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        BANLIST,
        "a junior writer refuses to carry a senior's ban it cannot vouch for (D-19)",
        "unban refuses when the remaining list carries an entry the writer cannot vouch for (D-19)",
        "a junior's unban of a ban it cannot vouch for is refused and publishes nothing, while the owner's unban succeeds (D-19)",
      ),
      ...refs(
        BANLIST_HELPERS,
        "planBanlistWrite blocks a write that would carry an entry the writer cannot vouch for (D-19)",
        "planBanlistWrite refuses to remove an entry the writer cannot vouch for (D-19)",
      ),
    ],
  },
  {
    id: "BAN-01.exports",
    requirement: "BAN-01",
    level: "MUST",
    rule: "The Banlist write errors are public runtime exports of the client and root barrels.",
    phase: 5,
    status: "covered",
    tests: refs(EXPORTS, "Banlist write errors are public runtime exports of the client and root barrels (BAN-01)"),
  },
  {
    id: "BAN-03.reheal-lost-sibling",
    requirement: "BAN-03",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule:
      "A ban this client published that a concurrent sibling edition displaced is re-applied once on top of the winning verified head, citing the winner's hash, through the serialized acknowledged Banlist writer, also when the sibling arrives while the ban awaits its acknowledgment; a replayed head publishes nothing more.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        REHEAL,
        "a ban lost to a concurrent sibling is re-applied once on the winning head (BAN-03)",
        "a ban lost to a sibling that arrives while its acknowledgment is pending is re-applied (BAN-03)",
        "a replayed head publishes no second heal",
      ),
      ...refs(
        REHEAL_PLAN,
        "a ban lost to a same-version sibling heals on top of the winning head (D-13)",
      ),
    ],
  },
  {
    id: "BAN-03.no-revive-unban",
    requirement: "BAN-03",
    level: "MUST",
    rule:
      "A later local unban is never revived: the unban counts from its call, even when it is refused, rate-limited or completes after an earlier queued ban; the waiting heal plans again when it fires and drops the member, and a heal already queued or waiting on the signer is abandoned before it is sent (D-12).",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(
        REHEAL,
        "a later unban is never revived by a waiting heal (D-12)",
        "a refused unban never lets a waiting heal revive the ban (D-12)",
        "a rate-limited unban never lets a deferred heal revive the ban (D-11, D-12)",
        "an unban called while a heal waits in the write queue cancels that heal (D-12)",
        "a rate-limited unban cancels a heal already waiting in the write queue (D-11, D-12)",
        "a heal cancelled by an unban of one member still re-applies the other lost members (D-12)",
        "an unban called while a heal waits on the signer cancels that heal (D-12)",
        "a ban that completes after a later unban was called never overrides it (D-12)",
      ),
      ...refs(REHEAL_PLAN, "a later session unban cancels a lost ban (D-12)"),
    ],
  },
  {
    id: "BAN-03.no-revive-removal",
    requirement: "BAN-03",
    level: "MUST",
    rule: "A ban that appeared on the head chain and was later removed by anyone is never revived.",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL_PLAN,
      "a ban that appeared on the head chain and was later removed is never revived (BAN-03)",
    ),
  },
  {
    id: "BAN-03.own-bans-only",
    requirement: "BAN-03",
    level: "MUST",
    rule:
      "Only editions this account published seed a heal, and a heal never removes a head entry other than the owner key (D-14, D-19).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL_PLAN,
      "only editions this client authored seed candidates (D-14)",
      "a heal never removes a head-content entry other than the owner key (D-19)",
    ),
  },
  {
    id: "BAN-04.stops-on-authority-loss",
    requirement: "BAN-04",
    level: "MUST",
    rule:
      "A waiting or running heal stops on demotion and on losing rank over the target, and nothing publishes afterwards (D-15).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "demotion while a heal waits cancels it (D-15)",
      "losing rank over the target stops the heal (D-15)",
    ),
  },
  {
    id: "BAN-04.stops-on-lifecycle",
    requirement: "BAN-04",
    level: "MUST",
    rule:
      "A heal stops on dissolution, dispose() and a Refounding adoption (which also clears this session's old-epoch intents but keeps those recorded at the new epoch), and no heal runs while a Refounding is in flight; it resumes if that Refounding fails.",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "dissolution and dispose cancel a waiting heal (D-15)",
      "a Refounding adoption cancels the heal and clears this session's intents (D-15)",
      "intents recorded at the new epoch while this client's Refounding completes survive it (D-12, D-15)",
      "no heal runs while a Refounding is in flight, and a failed Refounding lets it resume",
    ),
  },
  {
    id: "BAN-04.typed-non-convergence",
    requirement: "BAN-04",
    level: "MUST",
    rule:
      "After three heal publications for one ban without it holding, the member is given up and a BanlistReHealError with reason non-convergence is reported once on diagnostics$ (D-15).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "three heal publications without convergence report BanlistReHealError non-convergence once (D-15)",
    ),
  },
  {
    id: "BAN-04.bounded-owned",
    requirement: "BAN-04",
    level: "MUST",
    rule:
      "Every heal is a DutyScope-owned duty with three attempts and a bounded lifetime, a rejected acknowledgment ends in duty-exhausted, and a full Banlist rate window defers the heal instead of rejecting or dropping it, at most five times in a row per ban before reporting rate-limited (D-11, D-13).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "a rejected heal acknowledgment retries with backoff, then reports duty-exhausted",
      "a heal waits for the Banlist rate-limit window instead of rejecting (D-11)",
      "a heal the rate window keeps deferring gives up after a bound and reports rate-limited once (D-11)",
      "the deferral bound restarts after a successful heal (D-11)",
      "a stale signer completion after supersession never publishes a heal",
    ),
  },
  {
    id: "BAN-04.exports",
    requirement: "BAN-04",
    level: "MUST",
    rule: "BanlistReHealError is a public runtime export of the client and root barrels; the re-healer stays internal.",
    phase: 5,
    status: "covered",
    tests: refs(EXPORTS, "BanlistReHealError is a public runtime export of the client and root barrels (BAN-04)"),
  },
  {
    id: "BAN-05.concurrent-writers",
    requirement: "BAN-05",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule:
      "Concurrent writers converge to the union: a ban a sibling edition displaced is re-applied once on the winning head, and two engines of one account publish at most one heal between them.",
    phase: 5,
    status: "covered",
    tests: [
      ...refs(REHEAL, "a ban lost to a concurrent sibling is re-applied once on the winning head (BAN-03)"),
      ...refs(REHEAL, "two engines with one signer publish at most one heal between them"),
    ],
  },
  {
    id: "BAN-05.restart",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "A restarted engine over the same relay history heals a lost newest own ban once, after the retained-source window, and never revives a ban that a later own unban cancelled (D-21).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "a restarted engine heals a lost newest own ban once (D-21)",
      "a restarted engine never revives a ban its later own unban cancelled (D-21)",
    ),
  },
  {
    id: "BAN-05.devices",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "Two engines signing with one key publish at most one heal between them: the session-sourced heal runs first and the retained-sourced one plans again and finds nothing to do.",
    phase: 5,
    status: "covered",
    tests: refs(REHEAL, "two engines with one signer publish at most one heal between them"),
  },
  {
    id: "BAN-05.other-holders",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "Another BAN holder never re-applies a ban it did not write, even when it holds the displaced edition (D-14).",
    phase: 5,
    status: "covered",
    tests: refs(REHEAL, "another BAN holder never re-applies a ban it did not write (D-14)"),
  },
  {
    id: "BAN-05.mixed-rank-heal",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "A senior re-applies its ban when a junior's sibling wins the tie and re-signs a junior head that carried its ban without vouching for it, content unchanged; a junior whose lost ban sits under a senior's head publishes nothing and reports BanlistReHealError blocked once (D-19).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "a senior re-applies its ban when a junior's sibling wins the tie (mixed rank)",
      "a senior re-signs a junior head that carried its ban without vouching for it, content unchanged (mixed rank)",
      "a junior whose lost ban sits under a senior's head is blocked and reports BanlistReHealError (mixed rank)",
    ),
  },
  {
    id: "BAN-05.refounding-scope",
    requirement: "BAN-05",
    level: "MUST",
    rule:
      "A ban lost before a Refounding is not re-applied after a restart into the new epoch: its edition is only at the old epoch's Control address (D-15).",
    phase: 5,
    status: "covered",
    tests: refs(
      REHEAL,
      "a ban lost before a Refounding is not re-applied after a restart into the new epoch (D-15)",
    ),
  },
  {
    id: "DEC-04.fallback-no-republish",
    requirement: "DEC-04",
    level: "MUST",
    rule:
      "Banning a pinner who edited the Pin List makes readers fall back to the last valid list, and the library publishes no Pin List edition, even with pin upkeep on past the witness window (D-16).",
    phase: 5,
    status: "covered",
    tests: refs(
      PINS,
      "banning a pinner who edited the Pin List falls back to the earlier list and publishes no Pin List edition (D-16)",
    ),
  },
  {
    id: "DEC-04.writer-replaces-reverted-head",
    requirement: "DEC-04",
    level: "MUST",
    rule:
      "The next authorized writer replaces the reverted Pin List head, chaining over a banned edition only when no eligible head exists (D-16, Phase 2 D-34).",
    phase: 5,
    status: "covered",
    tests: refs(
      PINS,
      "the next authorized writer replaces a reverted Pin List head after a pinner is banned (D-16)",
    ),
  },
  {
    id: "DEC-04.banned-self-delete",
    requirement: "DEC-04",
    level: "MUST",
    rule:
      "A banned author's own deletion of a pinned message still hides it at once and is upkept with one omission edition: self-erasure outranks curation (D-16).",
    phase: 5,
    status: "covered",
    tests: refs(PINS, "a banned author's own deletion of a pinned message still hides it and is upkept once (D-16)"),
  },
  {
    id: "DEC-04.republish-surviving-list",
    requirement: "DEC-04",
    spec: "CORD-04 §7",
    level: "SHOULD",
    rule:
      "Any authorized holder should republish the surviving Pin List after the Banlist drops a pinner's editions, the same re-heal.",
    phase: 5,
    status: "residual",
    residual:
      "Deliberate library policy (D-16): banning a pinner never triggers an automatic republish. Readers fall back to the newest list written by someone still allowed to pin, and the next authorized writer chains over it. A republish would turn every ban of a curator into a publication storm and would pin or unpin messages without any member asking for it; an app that wants the republish calls setPins itself.",
    tests: [],
  },
  {
    id: "BAN-03.pre-refounding-loss",
    requirement: "BAN-03",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule: "A ban displaced by a concurrent edit should be re-applied.",
    phase: 5,
    status: "residual",
    residual:
      "Decision D-15: a ban lost before a Refounding is not re-applied after the Refounding is adopted or after a restart into the new epoch, because its edition lives only at the old epoch's Control address and the refounder chose what to carry forward. Ban the member again in the new epoch.",
    tests: [],
  },
  {
    id: "BAN-03.restart-scope",
    requirement: "BAN-03",
    spec: "CORD-04 §4",
    level: "SHOULD",
    rule: "A ban displaced by a concurrent edit should be re-applied, including after the client restarts.",
    phase: 5,
    status: "residual",
    residual:
      "Decisions D-13 and D-21: ban intents are not persisted, so after a restart only the additions of this account's newest own Banlist edition at the current epoch seed a heal. An older displaced ban, or an unban that published no edition, is not remembered across a restart.",
    tests: [],
  },
  {
    id: "AV-01.voice-key-derivation",
    requirement: "AV-01",
    spec: "CORD-07 §1",
    level: "MUST",
    rule:
      "Call keys derive from the Channel's chat secret and epoch with the CORD-07 labels; the room keypair and media root roll with the epoch, per-sender keys hash the SFU identity and omit the epoch (§3), and a private channel whose key is not held derives nothing.",
    phase: 6,
    status: "covered",
    tests: refs(
      VOICE_KEYS,
      "voiceGroupKey derives the room keypair from concord/voice-signer and rolls with the epoch (CORD-07 §1)",
      "voiceMediaKey derives the media root from concord/voice-media and rolls with the epoch (CORD-07 §1)",
      "voiceSenderKey hashes the SFU identity and omits the epoch (CORD-07 §3)",
      "voiceKeysFor uses the community root for a public channel and the held key for a private one (CORD-07 §1)",
      "voiceKeysFor derives nothing for a private channel whose key is not held (CORD-07 §1)",
    ),
  },
  {
    id: "REL-01.envelope-nip44-cap",
    requirement: "REL-01",
    spec: "CORD-02 Appendix B",
    level: "MUST",
    rule:
      "The library itself holds every NIP-44 plaintext layer to 65,535 UTF-8 bytes: an over-cap rumor is refused before its seal is signed, an over-cap seal is refused by wrap, rewrap and direct-invite wrap, a strict reader drops a seal or wrap whose plaintext is over the cap, the self-encrypted Community and Invite Lists are capped where they are encrypted, and an invite bundle is capped on encrypt and decrypt.",
    phase: 6,
    status: "covered",
    tests: refs(
      ENVELOPE,
      "enforces 65535/65536 UTF-8 bytes on plaintext and encrypted rumor layers before signing",
      "enforces the serialized seal boundary for wraps, rewraps and strict readers",
      "caps both self-encrypted list operation boundaries without shedding unknown fields",
      "caps encrypted invite bundle plaintext on write and read",
    ),
  },
];

/** True when `text` declares a test or suite with exactly the static name `name`. */
function declaresTest(text: string, name: string): boolean {
  const quoted = JSON.stringify(name);
  return [`it(${quoted}`, `describe(${quoted}`, `Deno.test(${quoted}`].some((needle) => text.includes(needle));
}

/**
 * Returns one message per problem: a covered entry with no tests, a covered test whose file cannot be read or does not
 * declare the named test, a planned entry whose phase is not later than `currentPhase`, or a residual entry with a
 * missing or blank reason or any cited test.
 */
export function ledgerProblems(
  entries: readonly LedgerEntry[],
  read: (file: string) => string | undefined,
  currentPhase: number,
): string[] {
  const problems: string[] = [];
  for (const entry of entries) {
    if (entry.status === "residual") {
      if (!entry.residual?.trim()) problems.push(`${entry.id}: residual entry states no reason`);
      if (entry.tests.length > 0) problems.push(`${entry.id}: residual entries cite no tests`);
      continue;
    }
    if (entry.status === "planned") {
      if (entry.phase <= currentPhase) {
        problems.push(`${entry.id}: planned entry belongs to phase ${entry.phase}, which is not after ${currentPhase}`);
      }
      continue;
    }
    if (entry.tests.length === 0) problems.push(`${entry.id}: covered entry names no tests`);
    for (const test of entry.tests) {
      const text = read(test.file);
      if (text === undefined) problems.push(`${entry.id}: cannot read ${test.file}`);
      else if (!declaresTest(text, test.name)) {
        problems.push(`${entry.id}: ${test.file} has no test named "${test.name}"`);
      }
    }
  }
  return problems;
}
