// Drift guard for the REL-01 guard-mutation manifest (D-04): the manifest must stay structurally sound, map only real
// covered ledger rows, and never hold an exemption the user did not approve. It does not run any mutation (the sweep
// runner does that, only inside scratch clones); it keeps the normal test run honest about what the manifest claims.

/// <reference lib="deno.ns" />
// Test-only: this guard reads the source tree, so it opts into the Deno namespace (see index.cord-citations.test.ts).

import { dirname, fromFileUrl, join } from "@std/path";
import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { CONFORMANCE_LEDGER, type LedgerEntry } from "./conformance-ledger.ts";
import {
  GUARD_MUTATIONS,
  type GuardMutation,
  manifestProblems,
  MUTATION_EXEMPTIONS,
  mutationDigest,
  type MutationExemption,
  SWEEP_GROUPS,
  sweepGroupOf,
  unmappedRows,
} from "./conformance-mutations.ts";

// Rooted at this module's URL, never the working directory.
const SRC_ROOT = join(dirname(fromFileUrl(import.meta.url)), "..");

function read(file: string): string | undefined {
  try {
    return Deno.readTextFileSync(join(SRC_ROOT, file));
  } catch {
    return undefined;
  }
}

const EXPORTS = "__tests__/index.test.ts";
const SAMPLE_TEST = "helpers/__tests__/sample.test.ts";

/** A tiny synthetic source tree for the structural checks. */
const FILES: Readonly<Record<string, string>> = {
  "helpers/sample.ts": "alpha\nbeta\nbeta\n",
  "helpers/index.ts": 'export * from "./sample.ts";\n',
  [SAMPLE_TEST]: "x\n",
};
const readFake = (file: string): string | undefined => FILES[file];

const row = (overrides: Partial<LedgerEntry> = {}): LedgerEntry => ({
  id: "PIN-99.sample",
  requirement: "PIN-99",
  level: "MUST",
  rule: "synthetic",
  phase: 6,
  status: "covered",
  tests: [{ file: SAMPLE_TEST, name: "x" }],
  ...overrides,
});

const mutation = (overrides: Partial<GuardMutation> = {}): GuardMutation => ({
  id: "m",
  group: "A5",
  rows: ["PIN-99.sample"],
  sites: [{ file: "helpers/sample.ts", find: "alpha", replace: "omega" }],
  note: "synthetic",
  ...overrides,
});

const exemption = (overrides: Partial<MutationExemption> = {}): MutationExemption => ({
  row: "PIN-99.sample",
  reason: "synthetic reason",
  approval: "synthetic approval, 2026-10-30",
  ...overrides,
});

const ledger = [row()];

describe("guard mutation manifest (REL-01, D-04)", () => {
  it("the manifest has no structural problems", () => {
    expect(manifestProblems(GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER, read)).toEqual([]);
    expect(GUARD_MUTATIONS.some((entry) => entry.id === "pin-11-admin-preset-grants-pins")).toBe(true);
    // Every mapped row belongs to a sweep group.
    for (const entry of GUARD_MUTATIONS) {
      for (const id of entry.rows) {
        const ledgerRow = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
        expect({ id, group: ledgerRow && sweepGroupOf(ledgerRow) !== undefined }).toEqual({ id, group: true });
      }
    }
    // The synthetic baseline is itself clean, so each rejection below is caused by exactly one defect.
    expect(manifestProblems([mutation()], [], ledger, readFake)).toEqual([]);
  });

  it("the checker rejects malformed mutations", () => {
    const one = (m: GuardMutation, entries: readonly LedgerEntry[] = ledger): string[] =>
      manifestProblems([m], [], entries, readFake);
    const site = (file: string, find: string, replace: string): GuardMutation["sites"] => [{ file, find, replace }];

    expect(one(mutation({ rows: ["PIN-99.missing"] }))).toHaveLength(1);
    expect(one(mutation(), [row({ status: "planned", tests: [] })])).toHaveLength(1);
    expect(one(mutation(), [row({ status: "residual", tests: [], residual: "accepted" })])).toHaveLength(1);
    expect(one(mutation({ sites: [] }))).toHaveLength(1);
    expect(one(mutation({ sites: site("helpers/nope.ts", "alpha", "omega") }))).toHaveLength(1);
    expect(one(mutation({ sites: site(SAMPLE_TEST, "x", "y") }))).toHaveLength(1);
    expect(one(mutation({ sites: site("../outside.ts", "alpha", "omega") }))).toHaveLength(1);
    expect(one(mutation({ sites: site("helpers/../helpers/sample.ts", "alpha", "omega") }))).toHaveLength(1);
    expect(one(mutation({ sites: site("/etc/passwd", "alpha", "omega") }))).toHaveLength(1);
    expect(one(mutation({ sites: site("helpers/sample.ts", "gamma", "omega") }))).toHaveLength(1);
    expect(one(mutation({ sites: site("helpers/sample.ts", "beta", "omega") }))).toHaveLength(1);
    expect(one(mutation({ sites: site("helpers/sample.ts", "alpha", "alpha") }))).toHaveLength(1);
    // A row that belongs to no sweep group cannot be swept.
    expect(one(mutation({ rows: ["FND-99.sample"] }), [row({ id: "FND-99.sample", requirement: "FND-99" })]))
      .toHaveLength(1);
    expect(manifestProblems([mutation(), mutation()], [], ledger, readFake)).toHaveLength(1);

    // Two sites in one file apply in order, so the second find may only exist after the first replace.
    expect(
      one(mutation({
        sites: [
          { file: "helpers/sample.ts", find: "alpha", replace: "omega" },
          { file: "helpers/sample.ts", find: "omega", replace: "sigma" },
        ],
      })),
    ).toEqual([]);

    // A barrel mutation must list rows that an index.test.ts test pins; covered SHOULD rows may sit beside MUST rows.
    const barrel = site(
      "helpers/index.ts",
      'export * from "./sample.ts";',
      'export * from "./sample.ts"; export const x = undefined;',
    );
    expect(one(mutation({ sites: barrel }))).toHaveLength(1);
    const pinned = row({ tests: [{ file: EXPORTS, name: "x" }] });
    const pinnedShould = row({ id: "PIN-99.other", level: "SHOULD", tests: [{ file: EXPORTS, name: "y" }] });
    expect(
      one(mutation({ sites: barrel, rows: ["PIN-99.sample", "PIN-99.other"] }), [pinned, pinnedShould]),
    ).toEqual([]);
  });

  it("the checker rejects exemptions without a reason and a user approval", () => {
    const check = (exemptions: readonly MutationExemption[], mutations: readonly GuardMutation[] = []): string[] =>
      manifestProblems(mutations, exemptions, ledger, readFake);

    expect(check([exemption()])).toEqual([]);
    expect(check([exemption({ reason: "  " })])).toHaveLength(1);
    expect(check([exemption({ approval: "" })])).toHaveLength(1);
    expect(check([exemption({ row: "PIN-99.missing" })])).toHaveLength(1);
    expect(check([exemption()], [mutation()])).toHaveLength(1);
    // The real table holds no exemption at all: only the user may approve one, through the orchestrator.
    for (const entry of MUTATION_EXEMPTIONS) {
      expect(entry.approval.trim().length).toBeGreaterThan(0);
      expect(entry.reason.trim().length).toBeGreaterThan(0);
    }
  });

  it("every in-scope ledger row belongs to exactly one sweep group", () => {
    expect(SWEEP_GROUPS).toEqual(["A3-offline", "A3-recovery", "A4", "A5", "A8", "A9"]);
    const expected = (entry: LedgerEntry): string | undefined => {
      const { requirement: r, id } = entry;
      if (/^(FND|AV)-/.test(r)) return undefined;
      if (/^LIST-0[123]$/.test(r)) return "A3-offline";
      if (/^LIST-0[4-8]$/.test(r) || id.startsWith("REL-01.list-")) return "A3-recovery";
      if (r.startsWith("EXP-") || id.startsWith("REL-01.exp-")) return "A4";
      if (r.startsWith("PIN-") || r === "DEC-01" || r === "DEC-02" || id.startsWith("REL-01.pin-")) return "A5";
      if (r.startsWith("FORUM-") || r === "DEC-03" || id.startsWith("REL-01.forum-")) return "A8";
      if (r.startsWith("BAN-") || r === "DEC-04" || id.startsWith("REL-01.ban-")) return "A9";
      return undefined;
    };
    const counts = new Map<string, number>();
    for (const entry of CONFORMANCE_LEDGER) {
      const group = sweepGroupOf(entry);
      expect({ id: entry.id, group }).toEqual({ id: entry.id, group: expected(entry) });
      if (group && entry.status === "covered" && entry.level === "MUST") {
        counts.set(group, (counts.get(group) ?? 0) + 1);
      }
    }
    // In-scope covered MUST rows at the time this plan was written; spec-sweep rows only add to them.
    const minimum: Record<string, number> = { "A3-offline": 19, "A3-recovery": 18, A4: 15, A5: 36, A8: 12, A9: 22 };
    for (const [group, count] of Object.entries(minimum)) {
      expect({ group, enough: (counts.get(group) ?? 0) >= count }).toEqual({ group, enough: true });
    }
    // Spec-sweep rows carry requirement REL-01 and are placed by id prefix.
    for (
      const [prefix, group] of [["list", "A3-recovery"], ["exp", "A4"], ["pin", "A5"], ["forum", "A8"], ["ban", "A9"]]
    ) {
      expect(sweepGroupOf(row({ id: `REL-01.${prefix}-x`, requirement: "REL-01" }))).toBe(group);
    }
    expect(sweepGroupOf(row({ id: "REL-01.other", requirement: "REL-01" }))).toBeUndefined();
    expect(sweepGroupOf(row({ id: "AV-01.voice-key-derivation", requirement: "AV-01" }))).toBeUndefined();
  });

  it("unmappedRows lists covered MUST rows with no mutation or exemption", () => {
    const entries = [
      row({ id: "PIN-99.mapped" }),
      row({ id: "PIN-99.exempt" }),
      row({ id: "PIN-99.unmapped" }),
      row({ id: "PIN-99.should", level: "SHOULD" }),
      row({ id: "PIN-99.residual", status: "residual", tests: [], residual: "accepted" }),
      row({ id: "BAN-99.elsewhere", requirement: "BAN-99" }),
    ];
    const mapped = [mutation({ rows: ["PIN-99.mapped"] })];
    const exempt = [exemption({ row: "PIN-99.exempt" })];
    expect(unmappedRows("A5", mapped, exempt, entries)).toEqual(["PIN-99.unmapped"]);
    expect(unmappedRows("A9", mapped, exempt, entries)).toEqual(["BAN-99.elsewhere"]);
    // The seed mutation is the only mapped row so far, and it is not reported.
    const real = unmappedRows("A5", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER);
    expect(real).not.toContain("PIN-11.admin-preset-omits-pin-messages");
  });

  it("every A3-offline MUST row is mapped to a guard mutation or a user-approved exemption (LIST-01, LIST-02, LIST-03)", () => {
    // Non-vacuity: the group must actually hold covered MUST rows of all three requirements, or an empty group would pass.
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A3-offline"
    );
    for (const requirement of ["LIST-01", "LIST-02", "LIST-03"]) {
      expect(rows.some((entry) => entry.requirement === requirement)).toBe(true);
    }
    expect(unmappedRows("A3-offline", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // Every mapped row is named by a guard mutation of the group; none rests on an exemption alone.
    const mapped = new Set(
      GUARD_MUTATIONS.filter((mutation) => mutation.group === "A3-offline").flatMap((mutation) => mutation.rows),
    );
    for (const entry of rows) expect(mapped.has(entry.id)).toBe(true);
  });

  it("every A3-recovery MUST row is mapped to a guard mutation or a user-approved exemption (LIST-04 to LIST-08, CORD-02 §8)", () => {
    // Non-vacuity: the group must hold covered MUST rows of every recovery requirement and of the Phase 6 spec sweep.
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A3-recovery"
    );
    for (const requirement of ["LIST-04", "LIST-05", "LIST-06", "LIST-07", "LIST-08", "REL-01"]) {
      expect(rows.some((entry) => entry.requirement === requirement)).toBe(true);
    }
    expect(rows.length).toBeGreaterThanOrEqual(18 + 15);
    expect(unmappedRows("A3-recovery", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // Every mapped row is named by a guard mutation of the group; none rests on an exemption alone.
    const mapped = new Set(
      GUARD_MUTATIONS.filter((mutation) => mutation.group === "A3-recovery").flatMap((mutation) => mutation.rows),
    );
    for (const entry of rows) expect(mapped.has(entry.id)).toBe(true);
    expect(MUTATION_EXEMPTIONS.filter((exemption) => rows.some((entry) => entry.id === exemption.row))).toEqual([]);
  });

  it("every A5 MUST row is mapped to a guard mutation or a user-approved exemption (PIN-01 to PIN-11, DEC-01, DEC-02, CORD-04 §7)", () => {
    // Non-vacuity: the group must hold covered MUST rows of every pin requirement and of the Phase 6 spec sweep.
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A5"
    );
    const requirements = ["DEC-01", "DEC-02", "REL-01"];
    for (let n = 1; n <= 11; n++) requirements.push(`PIN-${String(n).padStart(2, "0")}`);
    for (const requirement of requirements) {
      expect(rows.some((entry) => entry.requirement === requirement)).toBe(true);
    }
    expect(rows.length).toBeGreaterThanOrEqual(36 + 5);
    expect(unmappedRows("A5", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // Every mapped row is named by a guard mutation of the group; none rests on an exemption alone.
    const mapped = new Set(
      GUARD_MUTATIONS.filter((mutation) => mutation.group === "A5").flatMap((mutation) => mutation.rows),
    );
    for (const entry of rows) expect(mapped.has(entry.id)).toBe(true);
    expect(MUTATION_EXEMPTIONS.filter((exemption) => rows.some((entry) => entry.id === exemption.row))).toEqual([]);
  });

  it("every A4 MUST row is mapped to a guard mutation or a user-approved exemption (EXP-01 to EXP-06, CORD-08)", () => {
    // Non-vacuity: the group must hold covered MUST rows of every disappearing-message requirement and of the Phase 6
    // spec sweep, or an empty group would pass.
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A4"
    );
    for (const requirement of ["EXP-01", "EXP-02", "EXP-03", "EXP-04", "EXP-05", "EXP-06", "REL-01"]) {
      expect(rows.some((entry) => entry.requirement === requirement)).toBe(true);
    }
    expect(rows.length).toBeGreaterThanOrEqual(15 + 2);
    expect(unmappedRows("A4", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // Every mapped row is named by a guard mutation of the group; none rests on an exemption alone.
    const mapped = new Set(
      GUARD_MUTATIONS.filter((mutation) => mutation.group === "A4").flatMap((mutation) => mutation.rows),
    );
    for (const entry of rows) expect(mapped.has(entry.id)).toBe(true);
    expect(MUTATION_EXEMPTIONS.filter((exemption) => rows.some((entry) => entry.id === exemption.row))).toEqual([]);
  });

  it("every A8 MUST row is mapped to a guard mutation or a user-approved exemption (FORUM-01 to FORUM-06, DEC-03, CORD-03)", () => {
    // Non-vacuity: the group must hold covered MUST rows of every forum requirement and of the Phase 6 spec sweep, or
    // an empty group would pass.
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A8"
    );
    for (
      const requirement of ["FORUM-01", "FORUM-02", "FORUM-03", "FORUM-04", "FORUM-05", "FORUM-06", "DEC-03", "REL-01"]
    ) {
      expect(rows.some((entry) => entry.requirement === requirement)).toBe(true);
    }
    expect(rows.length).toBeGreaterThanOrEqual(12 + 2);
    expect(unmappedRows("A8", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // Every mapped row is named by a guard mutation of the group; none rests on an exemption alone.
    const mapped = new Set(
      GUARD_MUTATIONS.filter((mutation) => mutation.group === "A8").flatMap((mutation) => mutation.rows),
    );
    for (const entry of rows) expect(mapped.has(entry.id)).toBe(true);
    expect(MUTATION_EXEMPTIONS.filter((exemption) => rows.some((entry) => entry.id === exemption.row))).toEqual([]);
  });

  it("every A9 MUST row is mapped to a guard mutation or a user-approved exemption (BAN-01 to BAN-05, DEC-04, CORD-04 §4)", () => {
    // Non-vacuity: the group must hold covered MUST rows of every batch-ban and re-heal requirement, of the banned-pinner
    // policy and of the Phase 6 spec sweep, or an empty group would pass.
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A9"
    );
    for (const requirement of ["BAN-01", "BAN-02", "BAN-03", "BAN-04", "BAN-05", "DEC-04", "REL-01"]) {
      expect(rows.some((entry) => entry.requirement === requirement)).toBe(true);
    }
    expect(rows.length).toBeGreaterThanOrEqual(22 + 10);
    expect(unmappedRows("A9", GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // Every mapped row is named by a guard mutation of the group; none rests on an exemption alone.
    const mapped = new Set(
      GUARD_MUTATIONS.filter((mutation) => mutation.group === "A9").flatMap((mutation) => mutation.rows),
    );
    for (const entry of rows) expect(mapped.has(entry.id)).toBe(true);
    expect(MUTATION_EXEMPTIONS.filter((exemption) => rows.some((entry) => entry.id === exemption.row))).toEqual([]);
  });

  it("every in-scope MUST row of A3, A4, A5, A8 and A9 is mapped to a guard mutation or a user-approved exemption", () => {
    // The guard walks every sweep group, so a group added later or a row added to an old group cannot lose its mapping
    // unnoticed. Non-vacuity: each group holds covered MUST rows, so an empty group cannot pass.
    expect([...SWEEP_GROUPS]).toEqual(["A3-offline", "A3-recovery", "A4", "A5", "A8", "A9"]);
    for (const group of SWEEP_GROUPS) {
      const rows = CONFORMANCE_LEDGER.filter((entry) =>
        entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === group
      );
      expect({ group, populated: rows.length > 0 }).toEqual({ group, populated: true });
      expect({ group, unmapped: unmappedRows(group, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER) })
        .toEqual({ group, unmapped: [] });
      // Every mutation of the group names rows that belong to it, so a mapping cannot sit in the wrong group.
      for (const entry of GUARD_MUTATIONS.filter((mutation) => mutation.group === group)) {
        for (const id of entry.rows) {
          const ledgerRow = CONFORMANCE_LEDGER.find((candidate) => candidate.id === id);
          expect({ id, group: ledgerRow && sweepGroupOf(ledgerRow) }).toEqual({ id, group });
        }
      }
    }
    // The guard fails when a row loses its mapping: a group with one row removed from every mutation reports it.
    const [victim] = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A9"
    );
    const without = GUARD_MUTATIONS.map((entry) => ({ ...entry, rows: entry.rows.filter((id) => id !== victim.id) }));
    expect(unmappedRows("A9", without, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([victim.id]);
  });

  it("mutationDigest changes when a site changes", async () => {
    const base = mutation();
    const bytes = new TextEncoder().encode(JSON.stringify(base.sites));
    const expected = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)))
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
    const digest = await mutationDigest(base);
    expect(digest).toBe(expected);
    expect(digest).toMatch(/^[0-9a-f]{64}$/);
    // Rows, notes and ids are not part of the digest; the sites are.
    expect(await mutationDigest(mutation({ id: "other", note: "other", rows: [] }))).toBe(digest);
    const edit = (patch: Partial<GuardMutation["sites"][number]>): GuardMutation =>
      mutation({ sites: [{ ...base.sites[0], ...patch }] });
    expect(await mutationDigest(edit({ file: "helpers/other.ts" }))).not.toBe(digest);
    expect(await mutationDigest(edit({ find: "beta" }))).not.toBe(digest);
    expect(await mutationDigest(edit({ replace: "sigma" }))).not.toBe(digest);
    expect(await mutationDigest(mutation({ sites: [...base.sites, ...base.sites] }))).not.toBe(digest);
  });
});
