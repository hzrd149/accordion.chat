// Pin the runtime exports of all seven JSR entrypoints; public API changes
// require an explicit update to these lists.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import * as root from "../index.ts";
import * as helpers from "../helpers/index.ts";
import * as operations from "../operations/index.ts";
import * as factories from "../factories/index.ts";
import * as casts from "../casts/index.ts";
import * as models from "../models/index.ts";
import * as client from "../client/index.ts";
import type { ConcordMemberships, ConcordPurgeScheduleOptions } from "../client/index.ts";

describe("concord exports", () => {
  it("root barrel exports exactly its 47 pinned symbols", () => {
    expect(Object.keys(root).sort()).toEqual([
      "ADMIN_PERMS",
      "BanMembersError",
      "BanlistHeadChangedError",
      "BanlistRateLimitError",
      "BanlistReHealError",
      "BanlistWriteBlockedError",
      "COMMUNITY_LIST_EVENT_MAX_BYTES",
      "Casts",
      "CommunityListFragments",
      "CommunityListUnknownError",
      "ConcordClient",
      "ConcordClientDisposedError",
      "ConcordClientNotStartedError",
      "ConcordCommunity",
      "ConcordCommunityAdmin",
      "ConcordCommunityAdminInvites",
      "ConcordCommunityListSync",
      "ConcordInviteManager",
      "ConcordPrivateChannel",
      "Factories",
      "Helpers",
      "InviteRevocationPublishError",
      "InviteWatcher",
      "MessageAlreadyExpiredError",
      "MissingChannelKeyError",
      "Models",
      "Operations",
      "PERM",
      "PinListNotReadyError",
      "RefoundingPublicationError",
      "RequiredPublishError",
      "Storage",
      "StreamSigners",
      "VSK",
      "buildChain",
      "channelLiveAuthors",
      "communityListFragmentIndex",
      "decodeReceivedWrap",
      "evaluateCommonRelayCoverage",
      "logger",
      "planeStoreKey",
      "syncAuthors",
      "syncChannelEpochs",
      "syncEpoch",
      "syncEpochs",
      "unionCommunityList",
      "verifyReceiveEnvelope",
    ]);
  });

  it("helpers barrel exports exactly its 238 pinned symbols", () => {
    expect(Object.keys(helpers).sort()).toEqual([
      "BACKFILL_KINDS",
      "BLOB_POINTER_FIELD_RULES",
      "CHANNEL_KEY_FIELD_RULES",
      "CHANNEL_KEY_FOLD_DISPOSITION",
      "CHANNEL_KEY_STRIPPED_FIELDS",
      "CHANNEL_METADATA_FOLD_RULES",
      "COMMUNITY_LIST_FRAGMENT_KIND",
      "COMMUNITY_LIST_KIND",
      "COMMUNITY_LIST_MAX_MEMBERSHIPS",
      "CONTROL_KIND",
      "CommunityListSymbol",
      "DEFAULT_EDITION_LINEAGE_DEPTH",
      "DESCRIPTION_MAX_BYTES",
      "DIRECT_INVITE_INDEX",
      "DIRECT_INVITE_KIND",
      "DirectInviteBundleSymbol",
      "EDIT_KIND",
      "ENCRYPTED_SEAL_KIND",
      "ENVELOPE_MAX_BYTES",
      "EPHEMERAL_GIFT_WRAP_KIND",
      "EditTargetPointerSymbol",
      "ExtraRelays",
      "GIFT_WRAP_KIND",
      "HELD_KEY_FIELD_RULES",
      "INVITE_BUNDLE_FIELD_RULES",
      "INVITE_BUNDLE_KIND",
      "INVITE_BUNDLE_MAX_CHANNELS",
      "INVITE_BUNDLE_MAX_HELD_CHANNEL_KEYS",
      "INVITE_BUNDLE_MAX_HELD_ROOTS",
      "INVITE_BUNDLE_MAX_RELAY_URL_LENGTH",
      "INVITE_BUNDLE_MAX_TEXT_LENGTH",
      "INVITE_BUNDLE_RELAY_CAP",
      "INVITE_BUNDLE_VSK_LIVE",
      "INVITE_BUNDLE_VSK_REVOKED",
      "INVITE_LIST_INVITE_FIELDS",
      "INVITE_LIST_KIND",
      "InvalidMediaAttachmentEncryptionError",
      "InviteBundleSymbol",
      "InviteListSymbol",
      "JOIN_LEAVE_KIND",
      "JOIN_VERB",
      "KICK_KIND",
      "LEAVE_VERB",
      "LEGACY_COMMUNITY_LIST_KIND",
      "LIST_MAX_BYTES",
      "MAX_ROLES",
      "MediaAttachmentError",
      "MessageAlreadyExpiredError",
      "NAME_MAX_BYTES",
      "PIN_LIST_MAX_BYTES",
      "PIN_LIST_MAX_ENTRIES",
      "PLAINTEXT_SEAL_KIND",
      "REKEY_BLOBS_PER_EVENT",
      "REKEY_KIND",
      "RELAY_DICTIONARY",
      "ROOT_SCOPE_HEX",
      "RULE_TABLE_SUBJECT_PROOF",
      "SNAPSHOT_CHUNK",
      "SNAPSHOT_KIND",
      "STOCK_RELAYS",
      "SUBJECT_MAX_BYTES",
      "TIMER_NOTICE_KIND",
      "TYPING_KIND",
      "UnsupportedMediaAttachmentAlgorithmError",
      "VOICE_PRESENCE_KIND",
      "WEBXDC_KIND",
      "addChannelKey",
      "assertBaseRotationSupported",
      "assertByteCap",
      "assertEnvelopeCap",
      "assertSubject",
      "banlistLocator",
      "base64ToBytes",
      "baseRekeyGroupKey",
      "buildChannelRekey",
      "buildInviteBundle",
      "buildInviteLink",
      "buildRefounding",
      "buildRekeyRumors",
      "bytesToBase64",
      "canActOn",
      "canonicalJson",
      "channelEpochOf",
      "channelGroupKey",
      "channelKeyFor",
      "channelRekeyGroupKey",
      "channelViewMode",
      "checkChatBinding",
      "checkContinuity",
      "classifyEditionLineage",
      "classifyRotationAuthority",
      "communityId",
      "communityListByteSize",
      "communityListEntryByteSize",
      "computeEditionHash",
      "concordHkdf",
      "controlGroupKey",
      "controlKeyFor",
      "controlSignerGroupKey",
      "createCommunity",
      "createPinProof",
      "currentBaseRekeys",
      "decodeBaseWrappedKey",
      "decodeCommunityListFragment",
      "decodeControlRootDelivery",
      "decodeFragment",
      "decodeLegacyCommunityList",
      "decodeWrap",
      "decodeWrapCached",
      "decodeWrappedKey",
      "decryptBundle",
      "deriveChannelKeys",
      "deriveConcordKeys",
      "deriveKeys",
      "describePinList",
      "directInviteFilter",
      "displaySubject",
      "dissolvedGroupKey",
      "editionAdditions",
      "editionHash",
      "encodeBaseWrappedKey",
      "encodeCommunityListFragment",
      "encodeCommunityListSnapshot",
      "encodeControlRootDelivery",
      "encodeFragment",
      "encodePinList",
      "encodeWrappedKey",
      "encryptBundle",
      "epochKeyCommitment",
      "findBlob",
      "foldControl",
      "foldMembers",
      "getCommunityList",
      "getDecodedWrap",
      "getDirectInviteBundle",
      "getDirectInviteExpiration",
      "getDirectInviteRecipient",
      "getEditTarget",
      "getEditText",
      "getInviteBundle",
      "getInviteBundleContent",
      "getInviteBundleLocator",
      "getInviteBundlePointer",
      "getInviteBundleVsk",
      "getInviteList",
      "getLiveCommunities",
      "getLiveInvites",
      "getSealRumor",
      "getSubject",
      "getWrapRumor",
      "getWrapSeal",
      "grantLocator",
      "groupKey",
      "groupRotations",
      "guestbookGroupKey",
      "hasChannelKey",
      "hasMalformedMs",
      "hasPerm",
      "inviteBundleKey",
      "inviteLinksLocator",
      "isCommunityListUnlocked",
      "isCommunityLive",
      "isCurrentStaff",
      "isDirectInviteUnlocked",
      "isDissolution",
      "isInviteBundleRevoked",
      "isInviteBundleUnlocked",
      "isInviteListUnlocked",
      "isInviteLive",
      "isRumorExpired",
      "isSafeInviteRelayURL",
      "isStaffPermissionMask",
      "isStrictlyLowerKey",
      "isValidCommunityList",
      "isValidDirectInvite",
      "isValidDirectInviteRumor",
      "isValidEdit",
      "isValidInviteBundle",
      "isValidInviteList",
      "liveCommunities",
      "liveInviteEntries",
      "lockDirectInvite",
      "lowerKeyWins",
      "mergeCommunities",
      "mergeCommunityTombstones",
      "mergeInvites",
      "mergeTombstones",
      "messageExpiration",
      "newInviteToken",
      "newestValidEdit",
      "parseCommunityList",
      "parseImeta",
      "parseInviteLink",
      "parseInviteList",
      "parseMs",
      "parsePermissions",
      "parseRekey",
      "parseRekeyResult",
      "permNames",
      "pinsLocator",
      "planeKeyFor",
      "projectPins",
      "readChannelRekey",
      "readPinList",
      "readRekey",
      "rebuildByRules",
      "recipientLocator",
      "refoundAuthority",
      "rekeyLocator",
      "rekeyScopeId",
      "resolveEditionPin",
      "resolveStanding",
      "rollForward",
      "rollForwardChannel",
      "rumorExpiration",
      "rumorMs",
      "sameRelaySet",
      "sha256Hex",
      "splitTime",
      "stampMessageExpiration",
      "toRelaysObservable",
      "unlockCommunityList",
      "unlockDirectInvite",
      "unlockInviteBundle",
      "unlockInviteList",
      "utf8ByteLength",
      "vacVerifier",
      "validateInviteBundle",
      "validateInviteListInvite",
      "verifiedPins",
      "verifyOwner",
      "verifyPinEntry",
      "voiceGroupKey",
      "voiceKeysFor",
      "voiceMediaKey",
      "voiceSenderKey",
      "walkEditionChain",
      "wrapForTarget",
    ]);
  });

  it("forum subject helpers and includeSubject are public runtime exports (FORUM-06)", () => {
    expect(typeof helpers.SUBJECT_MAX_BYTES).toBe("number");
    expect(typeof helpers.assertSubject).toBe("function");
    expect(typeof helpers.getSubject).toBe("function");
    expect(typeof helpers.displaySubject).toBe("function");
    expect(typeof operations.includeSubject).toBe("function");
  });

  it("channelViewMode is a public runtime export (FORUM-06)", () => {
    expect(typeof helpers.channelViewMode).toBe("function");
  });

  it("operations barrel exports exactly its 30 pinned symbols", () => {
    expect(Object.keys(operations).sort()).toEqual([
      "bindToChannel",
      "directInvite",
      "giftWrap",
      "includeChannelBinding",
      "includeEditTarget",
      "includeEdition",
      "includeInviteAttribution",
      "includeKickTarget",
      "includeMediaEncryption",
      "includeMs",
      "includeRekeyChunk",
      "includeSnapshotChunk",
      "includeSubject",
      "joinCommunity",
      "leaveCommunity",
      "mintInvite",
      "modifyCommunityList",
      "modifyInviteList",
      "refreshCommunity",
      "revokeInvite",
      "rewrapSeal",
      "sealRumor",
      "setDirectInviteBundle",
      "setDissolution",
      "setInviteBundle",
      "setJoinLeave",
      "setRevocation",
      "toRumor",
      "wrapDirectInvite",
      "wrapSeal",
    ]);
  });

  it("factories barrel exports exactly its 11 pinned symbols", () => {
    expect(Object.keys(factories).sort()).toEqual([
      "CommunityListFactory",
      "DirectInviteFactory",
      "DissolutionFactory",
      "EditFactory",
      "EditionFactory",
      "InviteBundleFactory",
      "InviteListFactory",
      "JoinLeaveFactory",
      "KickFactory",
      "SnapshotFactory",
      "buildSnapshotFactories",
    ]);
  });

  it("casts barrel exports exactly its 4 pinned symbols", () => {
    expect(Object.keys(casts).sort()).toEqual([
      "ConcordCommunityList",
      "ConcordDirectInvite",
      "ConcordInviteBundle",
      "ConcordInviteList",
    ]);
  });

  it("models barrel exports exactly its 12 pinned symbols", () => {
    expect(root.Models.ConcordChatTimelineModel).toBe(models.ConcordChatTimelineModel);
    expect(Object.keys(models).sort()).toEqual([
      "ConcordBanlistModel",
      "ConcordChannelsModel",
      "ConcordChatTimelineModel",
      "ConcordCommunityStateModel",
      "ConcordControlModel",
      "ConcordMembersModel",
      "ConcordObservedAuthorsModel",
      "ConcordPinsModel",
      "ConcordRolesModel",
      "decodedFromRumor",
      "mergeObserved",
      "observedAuthors",
    ]);
  });

  // Rotation and revocation internals stay unexported (only the revocation error class is public). Receive validation and
  // publication evidence are deliberate public consumer contracts.
  it("client barrel exports exactly its 38 pinned symbols", () => {
    expect(Object.keys(client).sort()).toEqual([
      "BanMembersError",
      "BanlistHeadChangedError",
      "BanlistRateLimitError",
      "BanlistReHealError",
      "BanlistWriteBlockedError",
      "COMMUNITY_LIST_EVENT_MAX_BYTES",
      "CommunityListFragments",
      "CommunityListUnknownError",
      "ConcordClient",
      "ConcordClientDisposedError",
      "ConcordClientNotStartedError",
      "ConcordCommunity",
      "ConcordCommunityAdmin",
      "ConcordCommunityAdminInvites",
      "ConcordCommunityListSync",
      "ConcordInviteManager",
      "ConcordPrivateChannel",
      "InviteRevocationPublishError",
      "InviteWatcher",
      "MessageAlreadyExpiredError",
      "MissingChannelKeyError",
      "PinListNotReadyError",
      "RefoundingPublicationError",
      "RequiredPublishError",
      "Storage",
      "StreamSigners",
      "buildChain",
      "channelLiveAuthors",
      "communityListFragmentIndex",
      "decodeReceivedWrap",
      "evaluateCommonRelayCoverage",
      "planeStoreKey",
      "syncAuthors",
      "syncChannelEpochs",
      "syncEpoch",
      "syncEpochs",
      "unionCommunityList",
      "verifyReceiveEnvelope",
    ]);
  });

  // D-13/D-14: the aggregate Community List read surface is a type only; no runtime export or write API is added.
  it("client barrel exposes the ConcordMemberships type for memberships$ (D-13)", () => {
    const memberships: ConcordMemberships = {
      entries: [],
      tombstones: [],
      knowledge: "unknown",
      locked: false,
      pending: false,
    };
    expect(Object.keys(memberships).sort()).toEqual(["entries", "knowledge", "locked", "pending", "tombstones"]);
    expect(Object.keys(client)).not.toContain("ConcordMemberships");
  });

  // BAN-03: the chain walker is the one public piece of the re-heal work; the planner stays internal like planPinUpkeep.
  it("walkEditionChain is a public helpers export (BAN-03)", () => {
    expect(typeof helpers.walkEditionChain).toBe("function");
    expect(Object.keys(helpers)).not.toContain("planBanlistReHeal");
  });

  // BAN-01: the Banlist write errors are the consumer contract for batch bans; the writer and its facade stay internal.
  it("Banlist write errors are public runtime exports of the client and root barrels (BAN-01)", () => {
    for (
      const name of [
        "BanlistRateLimitError",
        "BanMembersError",
        "BanlistWriteBlockedError",
        "BanlistHeadChangedError",
      ] as const
    ) {
      expect(typeof client[name]).toBe("function");
      expect(typeof root[name]).toBe("function");
    }
    expect(Object.keys(client)).not.toContain("BanlistWriter");
    expect(Object.keys(root)).not.toContain("BanlistWriter");
    expect(Object.keys(client)).not.toContain("CommunityBanlist");
  });

  // BAN-04: the re-heal report is the consumer contract on diagnostics$; the re-healer itself stays internal.
  it("BanlistReHealError is a public runtime export of the client and root barrels (BAN-04)", () => {
    expect(typeof client.BanlistReHealError).toBe("function");
    expect(typeof root.BanlistReHealError).toBe("function");
    expect(Object.keys(client)).not.toContain("BanlistReHealer");
    expect(Object.keys(root)).not.toContain("BanlistReHealer");
  });

  // CORD-08 §2 (06-REVIEW IN-02): every send can reject with this error, so client consumers catch it without reaching
  // into `/helpers`; it is the helpers class itself, not a copy, so `instanceof` agrees across barrels.
  it("MessageAlreadyExpiredError is a public runtime export of the client and root barrels (CORD-08 §2)", () => {
    expect(typeof client.MessageAlreadyExpiredError).toBe("function");
    expect(client.MessageAlreadyExpiredError).toBe(helpers.MessageAlreadyExpiredError);
    expect(root.MessageAlreadyExpiredError).toBe(helpers.MessageAlreadyExpiredError);
  });

  // D-09: the schedulePurge options are a type only; the purge engine and its registry stay internal.
  it("client barrel exposes the ConcordPurgeScheduleOptions type for schedulePurge (D-09)", () => {
    const options: ConcordPurgeScheduleOptions = { intervalMs: 60_000 };
    expect(Object.keys(options)).toEqual(["intervalMs"]);
    expect(Object.keys(client)).not.toContain("ConcordPurgeScheduleOptions");
    expect(Object.keys(client)).not.toContain("PurgeSchedules");
  });
});
