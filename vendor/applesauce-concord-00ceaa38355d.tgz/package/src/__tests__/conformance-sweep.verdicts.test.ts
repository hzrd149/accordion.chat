// The tracked, reproducible REL-01 verdict table (D-04). Each entry records that a guard mutation made a ledger row's own
// cited test fail, with the digest of the mutation that did it, so anyone can re-check the proof from a clone. Entries
// are produced by the sweep runner's `--verdicts` mode after a confirmed sweep (see conformance-sweep.ts) and pasted
// into `CONFORMANCE_VERDICTS`. `exempt-approved` is allowed only for a row the user explicitly approved, relayed by the
// orchestrator and recorded in `MUTATION_EXEMPTIONS`; it is a recorded deviation from ROADMAP SC3, never a default.
// Per-group completeness tests are added by the plans that prove each group (A3-offline: plan 06-06; A3-recovery: plan 06-08; A5: plan 06-10; A4: plan 06-11; A8: plan 06-12; A9: plan 06-14).
// The all-group completeness test and the re-proof of verdicts whose cited tests changed after their sweep: plan 06-15.
// A verdict whose recorded failing testcase is no longer one of its row's cited tests is reported as stale (06-REVIEW
// WR-03); an edit inside a still-cited test's body is not detected here, so re-sweep the rows that cite an edited test.
// That staleness check compares names only (iteration-2 IN-01): a verdict records no file, so a citation moved to a test
// or describe of the same name in another file still passes. Recording the file soundly would mean re-sweeping every
// kill, because the results files keep no testcase file and filling it in from today's ledger would only restate the
// current citations. No recorded `failing` name matches citations in two files today; when re-pointing a citation to a
// same-named test in another file, re-sweep that row.

/// <reference lib="deno.ns" />
// Test-only: see conformance-ledger.test.ts for why this guard opts into the Deno namespace.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { CONFORMANCE_LEDGER, type LedgerEntry } from "./conformance-ledger.ts";
import {
  GUARD_MUTATIONS,
  type GuardMutation,
  MUTATION_EXEMPTIONS,
  mutationDigest,
  type MutationExemption,
  SWEEP_GROUPS,
  type SweepGroup,
  sweepGroupOf,
} from "./conformance-mutations.ts";
import { failingIsCited } from "./conformance-sweep.ts";

/** One recorded sweep verdict. */
interface RecordedVerdict {
  /** Ledger row id. */
  row: string;
  /** `killed`: a mutation made one of the row's own cited tests fail. `exempt-approved`: the user approved an exemption. */
  verdict: "killed" | "exempt-approved";
  /** Id of the mutation that killed the row. */
  mutation?: string;
  /** `mutationDigest` of that mutation when it was swept. */
  digest?: string;
  /** The failing testcase, `<describe> > <it>`. */
  failing?: string;
  /** The 40-character commit id the scratch clone was at when the sweep ran. */
  sweptAt: string;
}

const CONFORMANCE_VERDICTS: readonly RecordedVerdict[] = [
  {
    row: "LIST-01.dirty-reflects-relay-copy",
    verdict: "killed",
    mutation: "list-dirty-flag-not-cleared",
    digest: "3f162b0754c7cc03aa5ca54cdaff4ba04a5ff5ec98b220e58d81989f3a7856e0",
    failing:
      "Community List lane regressions (D-31, REVIEW-FOCUSED-2) > communityListDirty$ returns to false after a held save across three fragments is released",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.held-write-release",
    verdict: "killed",
    mutation: "list-held-write-release-paths",
    digest: "efdba0c5954e92ec2f683bd9cb38466fddaf59f8fa1af941a0b1720ed20625c1",
    failing:
      "Community List pending-write retry (LIST-01, D-15, D-24, D-26) > a pending write is released automatically once a relay completes the read",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.motions-in-call-order",
    verdict: "killed",
    mutation: "list-motions-not-in-call-order",
    digest: "c88b8e3f61bba905a0b468ddf79b6b0c0e8fa3f910bb2ecb6443607d37b7966c",
    failing:
      "Resumable joins (D-34) > a join called while a leave is publishing, the newest prompt answered first: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.no-local-only-fragment",
    verdict: "killed",
    mutation: "list-read-complete-always",
    digest: "b7856b8cce287e0ba172ee505419e3c0dda09fae94e7fc0bb01522e724e07bf0",
    failing:
      "Community List offline-write gate (LIST-01, LIST-02) > a client restarted offline never publishes a fresh fragment 0 over a fragmented vault",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.no-stranded-held-write",
    verdict: "killed",
    mutation: "list-lane-retired-save-dropped",
    digest: "413eb0c2b47ba9442c92131c908e213b652ac4741eedd9729a06fb79499ef9f9",
    failing:
      "Community List gap regressions (01-REVIEW-GAPS) > a save retired by another device's fragment is retried, so the held join is published while relays answer (WR-01)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.publish-needs-current-evidence",
    verdict: "killed",
    mutation: "list-publish-evidence-recheck-skipped",
    digest: "465380e2385a55c63fc6ecbd816744eef526ca4a60a9d3b4ba558923be642cf4",
    failing:
      "completed-read gate (D-15, D-23) > a write whose read evidence is withdrawn while it signs publishes nothing (D-31)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.restart-safe-pending",
    verdict: "killed",
    mutation: "list-held-write-release-paths",
    digest: "efdba0c5954e92ec2f683bd9cb38466fddaf59f8fa1af941a0b1720ed20625c1",
    failing:
      "Community List offline-write gate (LIST-01, LIST-02) > a pending write survives a process restart and is published once by the next client",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.resumable-join",
    verdict: "killed",
    mutation: "list-join-save-skipped-after-failed-publish",
    digest: "1f8a108ef846f194e350d8560f33b6bcd03c4348f0a7a6785ab0657ba48b8fff",
    failing:
      "Resumable joins (D-34) > a join rejected after it recorded the membership keeps it saved, and a retried join publishes exactly one Join and resolves (D-34, model seed 40)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.save-view-current",
    verdict: "killed",
    mutation: "list-lane-retired-save-dropped",
    digest: "413eb0c2b47ba9442c92131c908e213b652ac4741eedd9729a06fb79499ef9f9",
    failing:
      "Community List gap regressions (01-REVIEW-GAPS) > a save retired by another device's fragment is retried, so the held join is published while relays answer (WR-01)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-01.single-lane",
    verdict: "killed",
    mutation: "list-lane-serial-tail",
    digest: "0d092c47cf4e8ead3dbcbe17f319077901aeb7d908bb3901e154c21c93d1f674",
    failing:
      "Community List lane regressions (D-31, REVIEW-FOCUSED-2) > a membership change made while start()'s read is still open waits for that read instead of superseding it (IN-01)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-02.newest-seen-governs",
    verdict: "killed",
    mutation: "list-sign-timestamp-not-above-winner",
    digest: "1f96b196b31c637c2e4d414694380d88357357775c7cc733b5a5550de77f4782",
    failing: "fragment state and publication > timestamps every coordinate strictly above the known winner",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-02.no-demotion-under-interleaving",
    verdict: "killed",
    mutation: "list-lane-stored-view-not-checked",
    digest: "d5a4adda0ff1af0403f9d560091a3edfd8866413182e979d1c03b1781ac4d0eb",
    failing:
      "Community List gap regressions (01-REVIEW-GAPS) > a save queued behind a parked unlock ingests the fragment that arrived while it waited and holds instead of publishing frags: 1 over frags: 2 (CR-01)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-02.sync-api-needs-open-lane",
    verdict: "killed",
    mutation: "list-sync-view-runs-without-lane",
    digest: "2e17e771afe57c11a01b67594050eac5f66d385a8e32454323f1a458664fcf6d",
    failing:
      "Community List sync API on the lane (D-35) > client.communityListSync.write() called on a stopped client rejects with ConcordClientNotStartedError and never publishes after a restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-02.sync-api-on-lane",
    verdict: "killed",
    mutation: "list-sync-view-bypasses-lane",
    digest: "b4b47014f3c10663eee74f0927f90dfaf65a4bfc256027dd6db0cd32bfa172df",
    failing:
      "Community List sync API on the lane (D-35) > client.communityListSync.repack() queued behind a parked lane step ingests the arrived fragment first and never erases its membership (D-35, 01-REVIEW-GAPS-2 CR-03)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-03.persist-verified-winners",
    verdict: "killed",
    mutation: "list-persist-skipped",
    digest: "cb9b47981af5a73a45258f2495600b99160c8f289d486acd198cac69e657d0c5",
    failing:
      "Community List restart recovery (LIST-03) > the stored record holds only signed ciphertext events, never membership plaintext (LIST-03)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-03.restore-before-relay",
    verdict: "killed",
    mutation: "list-restore-skipped-at-start",
    digest: "f82239378bd6e95172faa68be941c2089116e529210fc03f081ebafffc2e3e81",
    failing:
      "Community List restart recovery (LIST-03) > a restarted client restores its stored fragments before any relay answers and unlocks them on request (LIST-03)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-03.restore-verified",
    verdict: "killed",
    mutation: "list-restore-skips-authentication",
    digest: "96e690809e4b6f693ce2547f97e2e0b241808aa029fa33b2a64cc00f88b01e8a",
    failing:
      "fragment persistence seam (LIST-03) > restore() drops forged, foreign, wrong-kind and non-canonical events and reports one fragment-restore diagnostic (D-03)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-03.restored-not-evidence",
    verdict: "killed",
    mutation: "list-restore-counts-as-read-evidence",
    digest: "118d507def543543307f8f1e85e9e0cb46539d4be9e26328c446e666237526ec",
    failing:
      "fragment persistence seam (LIST-03) > restore() keeps stored winners locked and never counts them as read evidence (D-04)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-03.unlock-retained",
    verdict: "killed",
    mutation: "list-locked-never-reported",
    digest: "6aa7eabda75c9a75a4a357e478a28b8544aaf053ca0d4aa109a76bd08055f556",
    failing:
      "fragment persistence seam (LIST-03) > a restored fragment decrypts on an explicit receive and a newer relay copy replaces it (D-04)",
    sweptAt: "024cf60f5b1277f69a47e7154a09b9d1d9949440",
  },
  {
    row: "LIST-04.baseline-recheck",
    verdict: "killed",
    mutation: "list-repack-baseline-recheck-skipped",
    digest: "af7652a1ad3dd482ebd45e1c3508b2bb9486ac5d1541c142191c27497c80d93c",
    failing: "retires a staged repack when another device adds content between phases",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-04.dormant-merged",
    verdict: "killed",
    mutation: "list-repack-drops-dormant-content",
    digest: "29cca9d46649ff211e58cafb578e0b10744a454aa94ed8112a1ecfa82b0aae24",
    failing:
      "fragment state and publication > a repack plan includes dormant memberships and empties every non-empty dormant index (D-20)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-04.never-infer-missing",
    verdict: "killed",
    mutation: "list-repack-ignores-incomplete",
    digest: "532065c58488f7b0b93b42d6fb9bee29a5331149354d860d2c9dd45af3c76b7a",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > missing declared indexes keep a List partial and a repack is refused (D-05)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-04.prefix-complete",
    verdict: "killed",
    mutation: "list-repack-staging-raises-count",
    digest: "ec728ca4b42dc421d40c633d9fe5aa5b9318b194f0a3c496c061b15e0e3ef8cf",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > every acknowledged prefix of a repack is a complete List that keeps every membership, key and tombstone (D-17)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-04.repair-converges",
    verdict: "killed",
    mutation: "list-repack-cleanup-skipped",
    digest: "f807d7072baa3f0d6e10016dbc855ad5cb39c6ee8ad36ef4723384014bf24c02",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > a repair repack from every acknowledged prefix converges to a clean List with no dormant content or duplicates (LIST-04)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-05.cancel-across-lifecycles",
    verdict: "killed",
    mutation: "list-publish-assert-current-skipped",
    digest: "17fc652cad194511ce2143538958c6ccb53237bd359112d39bce0a6a0f1740cb",
    failing:
      "fragment persistence seam (LIST-03) > a write refused while it waits on persist publishes nothing more (CR-01, D-30)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-05.durable-before-publish",
    verdict: "killed",
    mutation: "list-repack-durable-wait-skipped",
    digest: "957c51345c3195ad36a4ab2fe3cebb9295062564d853124568ae0411a1a90066",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > a repack prompts the signer for nothing when the fragment record cannot be stored (D-08)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-05.repair-consent",
    verdict: "killed",
    mutation: "list-repair-without-consent",
    digest: "2468f1ee81cce689c8e2785256d178cb383ae294e62517a26e17f25dd1456bcd",
    failing:
      "Community List repair duty (LIST-05, D-07, D-19) > with autoRepair off, residue is reported once per held state and an explicit save arms the repair (D-19)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-05.single-repair-owner",
    verdict: "killed",
    mutation: "list-repair-rearmed-by-automatic-trigger",
    digest: "704b94e8395bedde95e30846625a333683edfd6e807f20cfb33719b931e8dcc0",
    failing:
      "Community List repair duty (LIST-05, D-07, D-19) > a repair is never re-armed by its own publications and stays quiet once its budget is spent (LIST-05)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-06.no-fragment-fields-above-zero",
    verdict: "killed",
    mutation: "list-scoped-write-keeps-fields-above-zero",
    digest: "137c56e78c7c1f8ce91c7deaa4eb1ea7f918418547d7cb474786f4c4d12bbc0e",
    failing:
      "fragment-level extension placement (LIST-06) > a scoped write to fragment 1 drops fragment-level fields that fragment 0 already carries (D-09)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-06.stranded-to-zero",
    verdict: "killed",
    mutation: "list-stranded-extension-keys-hidden",
    digest: "c9d96975bde9648d02b9a5fb46c6af548b7a48448d0dae17fbaf3f26bfceccb9",
    failing:
      "fragment-level extension placement (LIST-06) > a scoped write to fragment 1 writes fragment 0 first with stranded fields, then fragment 1 without them (D-18)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-06.unknown-fields-survive",
    verdict: "killed",
    mutation: "list-wire-fragment-extras-dropped",
    digest: "f5f51f8becefa4c07ba2b547370607ed8b96c51992821f84fef4b997d488bd2c",
    failing:
      "unknown fields survive every write (LIST-06, D-11) > a scoped write keeps every entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-07.legacy-read-only",
    verdict: "killed",
    mutation: "list-legacy-import-skipped",
    digest: "b1f413c69d33bdb523d657435c56d4774512538fdcf77198eee3d0833ec2c1de",
    failing:
      "legacy Community List surfaces (D-14, D-15) > a legacy kind-13302 list is still read and imported through communityList$ (D-15)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-07.memberships-api",
    verdict: "killed",
    mutation: "list-memberships-runtime-export",
    digest: "7fa038b8da1c0a800a35002e3997051a28287e4b1d438e42d83ac4e8534efe15",
    failing: "concord exports > client barrel exposes the ConcordMemberships type for memberships$ (D-13)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "LIST-08.no-lost-keys",
    verdict: "killed",
    mutation: "list-repack-staging-raises-count",
    digest: "ec728ca4b42dc421d40c633d9fe5aa5b9318b194f0a3c496c061b15e0e3ef8cf",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > every acknowledged prefix of a repack is a complete List that keeps every membership, key and tombstone (D-17)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-08.no-overwritten-unread",
    verdict: "killed",
    mutation: "list-assert-readable-disabled",
    digest: "7256fa52c53b67029afd64c81fda772d1ab8321dc16d74bb9dcf741e878e99dd",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > a locked dormant copy blocks a repack and nothing is published (D-05)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-08.no-revived-tombstones",
    verdict: "killed",
    mutation: "list-repack-drops-tombstones",
    digest: "9d636f98e2c87a5ad7226ba9c77b8071e89cc4e1275f3805948f0a37fdb5ef3b",
    failing:
      "fragment state and publication > a dormant membership never revives a community tombstoned in range (D-20)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "LIST-08.no-wedged-cleanup",
    verdict: "killed",
    mutation: "list-repack-cleanup-skipped",
    digest: "f807d7072baa3f0d6e10016dbc855ad5cb39c6ee8ad36ef4723384014bf24c02",
    failing:
      "repack restart prefixes (LIST-04, D-17, D-20) > a repack empties a non-empty dormant fragment beyond its staging range (LIST-08)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-base64url-named-fields",
    verdict: "killed",
    mutation: "list-wire-keys-not-reencoded",
    digest: "ee64072ac39ddc291dff3b450c1019a42eb4c06d938b509d80d4ec321a020410",
    failing:
      "CORD-02 §8 fragment wire boundary > uses base64url, inherits identity, elides equal seeds and preserves staff roots",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-count-governs-newest-larger-wins",
    verdict: "killed",
    mutation: "list-count-ties-resolve-smaller",
    digest: "77dd1d5c23b8459b1230d14254c0ca1d55015be459f262b9815ee8d4da8bedca",
    failing: "fragment state and publication > tracks mixed-age completeness and resolves count ties upward",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-event-ceiling",
    verdict: "killed",
    mutation: "list-event-overflow-ignored",
    digest: "6dbeedc4703cfd17b6aa509f76a9bbfd769a10b82c2b7270d1dcfad16f9bbb71",
    failing:
      "Community List event ceiling (CORD-02 §8) > a join that would push a nearly full fragment past 65,536 bytes starts a new fragment and every published event stays within the ceiling (CORD-02 §8)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-liveness-newest-wins",
    verdict: "killed",
    mutation: "list-tombstone-keeps-older-removal",
    digest: "814bd001c10264fa8c7c6cc002ee329edaa4d491eb107f1b3be1e95098ed9e16",
    failing: "community-list CRDT > tombstone merge keeps the newest removal",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-lowering-empties-dropped",
    verdict: "killed",
    mutation: "list-repack-cleanup-skipped",
    digest: "f807d7072baa3f0d6e10016dbc855ad5cb39c6ee8ad36ef4723384014bf24c02",
    failing: "fragment state and publication > empties dropped coordinates and carries extensions on fragment zero",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-no-shed-for-ceiling",
    verdict: "killed",
    mutation: "list-repack-sheds-unknown-fields",
    digest: "a791e2fb8cc037c1a9a1308d61bd2b33e1689518ace36eacbd3730e0d42f3fea",
    failing:
      "Community List event ceiling (CORD-02 §8) > starting a new fragment to fit the ceiling keeps every unknown field instead of shedding it (CORD-02 §8)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-scoped-write-one-fragment",
    verdict: "killed",
    mutation: "list-scoped-write-needs-complete-list",
    digest: "58896f7bc9cb9b04b8ffe33f77a880fb7bd8d90c42caae8b309e999bcdcfcaa7",
    failing:
      "fragment state and publication > allows scoped writes during incomplete reads and keeps remote memberships",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-seed-absent-when-equal",
    verdict: "killed",
    mutation: "list-wire-seed-always-written",
    digest: "ed9f21490b8a3af1940f3b3de9cf0119388827892b3c7ffb27b81cb2aa34d959",
    failing:
      "CORD-02 §8 fragment wire boundary > uses base64url, inherits identity, elides equal seeds and preserves staff roots",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-seed-cosmetics-from-current",
    verdict: "killed",
    mutation: "list-wire-seed-name-not-rewritten",
    digest: "33fec524089ac5fc1f39c63d4e1c6cafca479c295ab471bc5f812f1ca7fdcad9",
    failing:
      "CORD-02 §8 fragment wire boundary > rewrites seed cosmetics and strips local history without modifying recovery state",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-shrink-exempt",
    verdict: "killed",
    mutation: "list-shrink-exemption-removed",
    digest: "fc0753073744338a8671244845ed787e13f6f57f7d7844d95b44d90d3b9ee7d1",
    failing:
      "Community List event ceiling (CORD-02 §8) > a write that strictly shrinks a fragment already past the ceiling is published in place, while one that grows it splits (CORD-02 §8)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-snapshot-membership-subset",
    verdict: "killed",
    mutation: "list-wire-local-fields-written",
    digest: "a0c630f41cecf26a557c09c62c6fc9a703b47001dd141a5df641fccaa889d924",
    failing:
      "CORD-02 §8 fragment wire boundary > rewrites seed cosmetics and strips local history without modifying recovery state",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-snapshot-merge-order",
    verdict: "killed",
    mutation: "list-merge-current-keeps-lower-epoch",
    digest: "4e7bbf4c179c46af7f4ae4a525f640436a451925d14ed746fbdaa12bfcb068da",
    failing:
      "snapshot merge convergence > keeps the lower-epoch seed and the higher-epoch current in either merge order (CORD-02 §8)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-snapshot-omits-community-id",
    verdict: "killed",
    mutation: "list-wire-embedded-keeps-community-id",
    digest: "9f77f2560a25d5b41a06774885d9f31b4187732184c76e2cd23d5396cbc4b196",
    failing:
      "CORD-02 §8 fragment wire boundary > uses base64url, inherits identity, elides equal seeds and preserves staff roots",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-tombstone-wins-omit-entry",
    verdict: "killed",
    mutation: "list-covered-entry-written",
    digest: "f67011e3d0178de2bc16f4676f034db9106a21803cadb88425b43a720420e624",
    failing:
      "CORD-02 §8 fragment wire boundary > omits covered entries but retains tombstones and local backfill material",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "REL-01.list-unknown-fields-codec",
    verdict: "killed",
    mutation: "list-wire-fragment-extras-dropped",
    digest: "f5f51f8becefa4c07ba2b547370607ed8b96c51992821f84fef4b997d488bd2c",
    failing:
      "unknown fields survive every write (LIST-06, D-11) > a scoped write keeps every entry, snapshot, tombstone and channel-entry unknown field byte for byte (D-11)",
    sweptAt: "6e5c400e4e45c393c826407b000f967e1a878c72",
  },
  {
    row: "DEC-01.expired-hidden-reader-side",
    verdict: "killed",
    mutation: "pin-model-no-expiry-boundary",
    digest: "52004df46bdbccce988435f2e7b2206e6c4e687a4eaf77c5a94e9b2f298b58d7",
    failing:
      "ConcordPinsModel > ConcordPinsModel re-emits at the next expiry boundary and leaves no timer after unsubscribe",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "DEC-01.no-publication-on-expiry",
    verdict: "killed",
    mutation: "pin-expiry-counts-as-omission",
    digest: "7584017ca0bd0c0636dca8fb0021f73989e0fa7d4c54e04c7c61d0d6ca678a29",
    failing: "PinMaintainer upkeep > expiry never schedules upkeep (D-02)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "DEC-02.first-pin-after-proven-absence",
    verdict: "killed",
    mutation: "pin-first-write-absence-not-proved",
    digest: "8321fdcbf021ab31fda2c70f6b2225bfbab6fbfda5edbcca0e59e91c5e1bb41a",
    failing:
      "ConcordCommunity setPins bootstrap > setPins rejects with unverified-edition while live when a retained edition may still verify (D-33)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "DEC-02.setpins-head-guard",
    verdict: "killed",
    mutation: "pin-setpins-head-unguarded",
    digest: "6b962b3b029396d4c479197c9f12e82f46c6ff71f21ffde95ee4253fe37ade20",
    failing:
      "ConcordCommunity setPins bootstrap > setPins rejects with reason changed when the head moves while signing",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "PIN-01.apply-newest-edit",
    verdict: "killed",
    mutation: "pin-projection-ignores-local-edits",
    digest: "1cada84e8740ee816b78f9b2554383244e5feed46cad2ad16bc013bb4ef815d8",
    failing: "pin projection > a newer local Edit replaces the bundled text and marks the pin edited and behind",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-01.deleted-edit-ignored",
    verdict: "killed",
    mutation: "pin-edit-deletions-ignored",
    digest: "300722f6440a98695c479ecbf3ba3593f6eddd366eb94df551444a1080dbb11c",
    failing:
      "edit helpers > newestValidEdit > newestValidEdit skips an Edit its own author deleted and falls back to the next undeleted Edit (D-31)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-01.duplicate-entries-newest-bundle",
    verdict: "killed",
    mutation: "pin-edit-deletions-ignored",
    digest: "300722f6440a98695c479ecbf3ba3593f6eddd366eb94df551444a1080dbb11c",
    failing:
      "pin projection > a message listed more than once > a duplicate whose bundled Edit its author deleted never wins over an undeleted bundle (D-32)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-01.never-older-edit",
    verdict: "killed",
    mutation: "pin-edit-chooser-takes-oldest",
    digest: "b08a7ef4f0a4d70e859eace0644234f12320cd973214aef825674a961f5f486e",
    failing: "pin projection > a local Edit older than the bundled proof never replaces it",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-01.never-superseded-text",
    verdict: "killed",
    mutation: "pin-projection-shows-expired",
    digest: "4c484afe40dbb58cd42e589ec6b64dc1c757a26de7919b13d09da21332bbf848",
    failing:
      "pin projection > an expired newest Edit hides the pin by default and showExpired shows only that Edit's text (D-11)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-02.hide-self-deleted",
    verdict: "killed",
    mutation: "pin-deletion-matches-any-author",
    digest: "f778edfe871e4a3feced923ddd99340a0079eafccd9fab8258dccadf1c47e8d6",
    failing: "pin projection > a self-deletion by the proven author hides the pin; one by another pubkey does not",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-03.no-storm",
    verdict: "killed",
    mutation: "pin-rate-limit-never-defers",
    digest: "526c1d9a73d56d7df40ada75dfd32317212fcc0d6f77f4c3cef4178bec2cdf46",
    failing: "PinMaintainer upkeep > rate limiting defers upkeep and reports pin-upkeep-skipped",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-03.opt-out",
    verdict: "killed",
    mutation: "pin-upkeep-opt-out-ignored",
    digest: "623b280cfd8627ed38888783cc4da018af78cbd6b0f4127cf37e71f786ec4ed2",
    failing: "pinUpkeep opt-out (D-07) > pinUpkeep false publishes no automatic Pin List edition",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "PIN-03.replay-rearms",
    verdict: "killed",
    mutation: "pin-duty-key-drops-head",
    digest: "1e6ce491928009e45c6530574836a48f3f4d8ad714af0eb561b5161b61cc5bfd",
    failing:
      "PinMaintainer upkeep > a replayed head that re-seats a deleted entry re-arms and builds on the current head",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-04.coalesced",
    verdict: "killed",
    mutation: "pin-pinner-waits-witness-delay",
    digest: "77726fe51dfd0b698f0e95596b0ddce90a6035c6b831804f35285803c0de35b5",
    failing: "PinMaintainer edit-proof refresh > the pinner refreshes an edit immediately (D-08)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-04.duplicate-entries-never-regress",
    verdict: "killed",
    mutation: "pin-collapse-last-copy-wins",
    digest: "6cbdd898048c0b31672eda6e1a22dd7506d522f07d0d250522a4f039a689f856",
    failing:
      "planPinUpkeep duplicate entries > an omission rewrite keeps the duplicate whose bundled Edit is newest (D-32)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-04.never-bundle-deleted-edit",
    verdict: "killed",
    mutation: "pin-setpins-republishes-retracted-edit",
    digest: "0147a3810ea92418db9b7da3cf6c71c845e2354228a30f74b3e2d8bc134fb8af",
    failing:
      "ConcordCommunity setPins bootstrap > setPins drops a bundled Edit its author deleted instead of republishing it (D-31)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "PIN-04.never-regress",
    verdict: "killed",
    mutation: "pin-refresh-regresses-to-older-edit",
    digest: "c68db8935feb2fa527c46b42232093146a9793fd7c4eebe3973da55cac7a091c",
    failing: "PinMaintainer edit-proof refresh > refresh never attaches an Edit older than the entry carries",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-04.no-other-form",
    verdict: "killed",
    mutation: "pin-refresh-attaches-unproven-edit",
    digest: "ebc6145c3a9ba2f83de911c9b0fd2cf2bdf97c1c9e8fccc89660a6bb1d7089f5",
    failing: "planPinUpkeep edit-proof refresh > a refresh replaces only the entry's edit bundle with a verified proof",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-05.newest-seal-retained",
    verdict: "killed",
    mutation: "pin-edit-seals-evict-by-arrival",
    digest: "c5d951db74d58e75c29d0779a43f813c457ef3d284613d6b24fba8acec20db27",
    failing:
      "PinEditSeals > keeps at most 512 Edit seals per channel, evicting by rumor order rather than arrival order",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-05.seal-from-retained-wraps",
    verdict: "killed",
    mutation: "pin-edit-seals-trust-embedded-id",
    digest: "67353c03166742399672d8928b75497224d2230d14a40cf921f6cca7e5108989",
    failing: "PinEditSeals > keys Edit seals by recomputed rumor id, ignoring a forged embedded id",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-06.over-cap-terminal",
    verdict: "killed",
    mutation: "pin-rewrite-over-ceiling-published",
    digest: "87c67236dd6f68582ed311b986af52702f7bcb8f83dbfeb7be14358de51f77f6",
    failing: "PinMaintainer upkeep > a rewrite over the byte ceiling reports over-cap once and publishes nothing",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-06.unavailable-old-epoch",
    verdict: "killed",
    mutation: "pin-missing-epoch-key-reads-empty",
    digest: "e9eaef22f2ed7a14eecd6309c1ea9271e839cbb1e79999e02ebd01a8f466b9c2",
    failing:
      "ConcordCommunity pin conversion, missing keys and rekey safety > a holder lacking the old channel epoch key leaves the sealed Pin List unavailable and publishes nothing",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-07.no-mechanical-conversion",
    verdict: "killed",
    mutation: "pin-sealed-head-reformed-public",
    digest: "89e02fc58f289a606eae17622ea812289f6a53cfae79cc62c5c70331affc8509",
    failing:
      "ConcordCommunity pin conversion, missing keys and rekey safety > a private-to-public conversion never re-forms the sealed Pin List as public, even with upkeep due",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-07.no-public-reform-by-automation",
    verdict: "killed",
    mutation: "pin-sealed-head-reformed-public",
    digest: "89e02fc58f289a606eae17622ea812289f6a53cfae79cc62c5c70331affc8509",
    failing: "planPinUpkeep > planPinUpkeep never re-forms a sealed head as public on a public channel",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-07.no-write-from-unreadable-list",
    verdict: "killed",
    mutation: "pin-write-readiness-ignores-availability",
    digest: "e3ad1d6b1f337631866fb62cee5d46d820337cbd58a204abbecc4a02bb2b2bff",
    failing: "pinWriteReadiness > pinWriteReadiness refuses an unreadable head",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-07.unreadable-never-rebuilt",
    verdict: "killed",
    mutation: "pin-missing-epoch-key-reads-empty",
    digest: "e9eaef22f2ed7a14eecd6309c1ea9271e839cbb1e79999e02ebd01a8f466b9c2",
    failing:
      "ConcordCommunity pin conversion, missing keys and rekey safety > a holder lacking the old channel epoch key leaves the sealed Pin List unavailable and publishes nothing",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-08.dissolved-self-scrub-only",
    verdict: "killed",
    mutation: "pin-dissolved-self-scrub-not-retained",
    digest: "291b3ab740f478049708ea101787b4b61a77117f93cb688e8c11ec153d1c6ffa",
    failing:
      "ConcordCommunity pins after dissolution > after dissolution a self-deletion of a stored pinned message hides the pin and publishes no Pin List edition",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "PIN-08.stops-on-authority-loss",
    verdict: "killed",
    mutation: "pin-duty-eligible-ignores-write-authority",
    digest: "f1391ff1c6367334fc9d4e327f481bfbf38e1f6e97daec18d5ecec9041f942ce",
    failing: "PinMaintainer upkeep > demotion while armed cancels the duty",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-09.reactive-pins",
    verdict: "killed",
    mutation: "pin-model-ignores-edits",
    digest: "c358b268ea9f473a9db8e06a1e9e8d9e3194ef0e3fc58b01fc8d835ad5fd4258",
    failing: "ConcordPinsModel > ConcordPinsModel re-emits when a newer Edit arrives",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-10.collision-re-heal",
    verdict: "killed",
    mutation: "pin-duty-key-drops-head",
    digest: "1e6ce491928009e45c6530574836a48f3f4d8ad714af0eb561b5161b61cc5bfd",
    failing:
      "ConcordCommunity pin regressions across heads and Refoundings > an omission lost to a concurrent sibling edition is re-applied on the winning head",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-10.deleted-channels",
    verdict: "killed",
    mutation: "pin-duty-for-deleted-channel",
    digest: "8944c73a3190ac1bd42a4937912b293890a39ecdb064d23aa17767226079a857",
    failing: "PinMaintainer upkeep > a channel deleted while armed is not maintained",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-10.demotion",
    verdict: "killed",
    mutation: "pin-duty-eligible-ignores-write-authority",
    digest: "f1391ff1c6367334fc9d4e327f481bfbf38e1f6e97daec18d5ecec9041f942ce",
    failing: "PinMaintainer upkeep > demotion while armed cancels the duty",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-10.fresh-post-rotation-reader",
    verdict: "killed",
    mutation: "pin-projection-ignores-bundled-edit",
    digest: "8fb88fe703a0923e7995a4ed1fddf3167ebad815e817cf4252c85f8cf528de8b",
    failing: "pin projection > a keyless reader verifies a public pin and shows its bundled Edit as edited",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-10.post-dissolution",
    verdict: "killed",
    mutation: "pin-dissolved-self-scrub-not-retained",
    digest: "291b3ab740f478049708ea101787b4b61a77117f93cb688e8c11ec153d1c6ffa",
    failing:
      "ConcordCommunity pins after dissolution > after dissolution a self-deletion of a stored pinned message hides the pin and publishes no Pin List edition",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "PIN-10.replayed-heads",
    verdict: "killed",
    mutation: "pin-duty-key-drops-head",
    digest: "1e6ce491928009e45c6530574836a48f3f4d8ad714af0eb561b5161b61cc5bfd",
    failing:
      "PinMaintainer upkeep > a replayed head that re-seats a deleted entry re-arms and builds on the current head",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "PIN-11.admin-preset-omits-pin-messages",
    verdict: "killed",
    mutation: "pin-11-admin-preset-grants-pins",
    digest: "397053bdb2e385eabde1d8a357aa1589d73ec6f92b7a85c5f0e6bda96d7ef309",
    failing: "permissions > ADMIN_PERMS deliberately omits PIN_MESSAGES (PIN-11)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "REL-01.pin-edit-bundle-verified",
    verdict: "killed",
    mutation: "pin-proof-channel-binding-unchecked",
    digest: "9cd0f1aee19d0e747954ab109358a98bad64a021dd7f27e23bae6879ff78408d",
    failing:
      "pin verifier steps (CORD-04 §7 proof bundle) > an edit bundle is accepted only as kind 3302 by the original's author, naming the original, in this channel (CORD-04 §7)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "REL-01.pin-invalid-entry-dropped",
    verdict: "killed",
    mutation: "pin-collapse-stops-at-invalid-entry",
    digest: "948520a3615a3e05051e6923629ffcb16b5e1928113fffed2de177bd8f0f375b",
    failing:
      "pin verifier steps (CORD-04 §7 proof bundle) > an entry failing any verifier step is invalid and dropped alone (CORD-04 §7 proof bundle)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "REL-01.pin-violating-edition-empty-list",
    verdict: "killed",
    mutation: "pin-oversize-edition-unavailable",
    digest: "6651988a9c1a464ff52dc95dbfa904271bfcb9826e5576875fe035db4da20f83",
    failing:
      "ConcordCommunity Pin List limits and form (CORD-04 §7) > an over-cap Pin List edition still folds and chains but reads as an empty list (CORD-04 §7 Limits)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "REL-01.pin-wrap-hint-untrusted",
    verdict: "killed",
    mutation: "pin-wrap-hint-validated",
    digest: "593946eb66f4a6fd111c3b83cf4dba4d5c9cc635328458a64f999497036d2926",
    failing:
      "pin verifier steps (CORD-04 §7 proof bundle) > a wrap hint is never trusted: verification, identity and deduplication ignore it (CORD-04 §7)",
    sweptAt: "cd17076bc0818e6200e38696215648177e6e46c7",
  },
  {
    row: "REL-01.pin-writer-form-follows-channel-type",
    verdict: "killed",
    mutation: "pin-writer-ignores-channel-form",
    digest: "b0cc1f15f729ac64c5d96885166e26ad95ca2ea7fcc3daf12167da6e9a6f5117",
    failing:
      "ConcordCommunity Pin List limits and form (CORD-04 §7) > setPins writes the plaintext form for a public channel and the sealed form for a private one (CORD-04 §7)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-01.bounded-sweep",
    verdict: "killed",
    mutation: "exp-purge-wall-clock",
    digest: "14a5cb61e184c101642c2dd4ca86f84dc4184c562bcaf1ac7de5edfea8ab993d",
    failing: "purge reach (EXP-01, CORD-08 §3) > purge judges expiry on the injected duty clock (D-07)",
    sweptAt: "5f3b586e195d3214ac176b96a71557f5a7dfe3e6",
  },
  {
    row: "EXP-02.never-displayed",
    verdict: "killed",
    mutation: "exp-open-sweep-skipped",
    digest: "174ee7a85595ca3a775193b6419cff28112cdd0448f10a116bd67675b71d1ef1",
    failing:
      "cache hydration (EXP-02, CORD-08 §3) > an expired cached rumor is never displayed and is removed from the database when its store opens",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-02.never-retained",
    verdict: "killed",
    mutation: "exp-open-sweep-skipped",
    digest: "174ee7a85595ca3a775193b6419cff28112cdd0448f10a116bd67675b71d1ef1",
    failing:
      "cache hydration (EXP-02, CORD-08 §3) > an expired cached rumor is never displayed and is removed from the database when its store opens",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-03.bounded",
    verdict: "killed",
    mutation: "exp-schedule-never-rearms",
    digest: "fcf212bdc9a6bbe9c461cd58fc680de6c2fa9534d4063ec9d496f347ca3b237e",
    failing: "community.schedulePurge (EXP-03, D-09..D-12) > a scheduled sweep never overlaps another sweep",
    sweptAt: "5f3b586e195d3214ac176b96a71557f5a7dfe3e6",
  },
  {
    row: "EXP-03.client-fan-out",
    verdict: "killed",
    mutation: "exp-client-schedule-misses-later-joined",
    digest: "fd685609761219048943f37753b9df8045b65a1db728f8e17343c72d731106b7",
    failing:
      "client.schedulePurge (EXP-03, D-09, D-20) > client.schedulePurge reaches current and later-joined communities and survives stop and start",
    sweptAt: "5f3b586e195d3214ac176b96a71557f5a7dfe3e6",
  },
  {
    row: "EXP-03.opt-in-owned",
    verdict: "killed",
    mutation: "exp-schedule-default-on",
    digest: "48c0a9d9ee6c49e899faff1ab31a798c7df18daff8c53e7ac5153c4e8b6ba6bc",
    failing: "community.schedulePurge (EXP-03, D-09..D-12) > no purge is scheduled by default",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-03.options-type-only",
    verdict: "killed",
    mutation: "exp-purge-options-exported-as-value",
    digest: "f5d743517d64530ab05c53c9048beee160520476993d19006fc217fe553cb48e",
    failing: "concord exports > client barrel exposes the ConcordPurgeScheduleOptions type for schedulePurge (D-09)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-04.signed-tag-only",
    verdict: "killed",
    mutation: "exp-strict-tag-rule-lenient",
    digest: "1714829ae118ca10e0eb92435a876e59856419eb22e29559acc8d3977f243962",
    failing: "disappearing Chat > judges the expiration tag by the library's strict rule (D-21)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-05.exempt-unstamped",
    verdict: "killed",
    mutation: "exp-stamp-keeps-caller-tag",
    digest: "da560990353e5ce437e0d310b62f0f8192400403c59b73d0bf812ba5741b85b0",
    failing: "disappearing Chat > stamps final Unix-second time and strips tags from exempt kinds",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-05.forged-outer-hide",
    verdict: "killed",
    mutation: "exp-community-addwrap-plain",
    digest: "4a5a6b3370c2eb9ea562c9e6dda1ffee30326bc20eb4134949ea2cff432b769d",
    failing:
      "forged outer expiration tags (CORD-08 §2, D-06) > a live rumor under a forged past outer tag is retained and displayed",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-05.forged-outer-revive",
    verdict: "killed",
    mutation: "exp-ingest-accepts-expired",
    digest: "3ad28c05c043fcd0a5ccf99f518c4c195e35689bf0f9324edbfa96247a4703ac",
    failing: "the receive boundary refuses an already-expired Chat rumor whatever its outer tag says (CORD-08 §2, §3)",
    sweptAt: "5f3b586e195d3214ac176b96a71557f5a7dfe3e6",
  },
  {
    row: "EXP-05.non-retroactive",
    verdict: "killed",
    mutation: "exp-community-timer-unread",
    digest: "0c5fa775c5326f3ff45ea43a0be83540d0ae493aa9ff3ea8bdc42be76646287f",
    failing:
      "purge reach (EXP-01, CORD-08 §3) > timer changes are not retroactive: only messages stamped under a timer expire (CORD-08 §2)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-05.stamp-durable",
    verdict: "killed",
    mutation: "exp-stamp-skipped",
    digest: "5db8b1ca412140d46e8b286f78f611d6cdc114731891cdc3271a9a0ba2c46f8e",
    failing: "copies author expiration onto the durable wrap and rechecks cached receives as time advances",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-05.tombstones",
    verdict: "killed",
    mutation: "exp-tombstones-expire",
    digest: "2b322e0348252e992b000df0d7db6f47460a82eb9482c30e3f0d49be6d07ec00",
    failing:
      "cache hydration (EXP-02, CORD-08 §3) > retained deletion tombstones survive purge and hydration and a purged target is never resurrected (D-15)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "EXP-06.purge-pinned",
    verdict: "killed",
    mutation: "exp-purge-skips-chat-messages",
    digest: "feeb5a2f59b6990f17a760acda0726a9e51a4055ff711f8ecf4d055f4cf2224b",
    failing:
      "ConcordCommunity pins and expiration purge (EXP-06) > purge removes an expired pinned message while the pin stays hidden and no Control edition is published (EXP-06)",
    sweptAt: "5f3b586e195d3214ac176b96a71557f5a7dfe3e6",
  },
  {
    row: "EXP-06.purge-wins",
    verdict: "killed",
    mutation: "exp-purge-skips-edits",
    digest: "a77b47a202d18474766fbd77eda80e64e030b71952eb0f9cfc9f1171b04f6301",
    failing:
      "ConcordCommunity pins and expiration purge (EXP-06) > purge removes an expired newest Edit even when a pin then shows older bundled text (D-19)",
    sweptAt: "5f3b586e195d3214ac176b96a71557f5a7dfe3e6",
  },
  {
    row: "REL-01.exp-malformed-timer-off",
    verdict: "killed",
    mutation: "exp-community-timer-unread",
    digest: "0c5fa775c5326f3ff45ea43a0be83540d0ae493aa9ff3ea8bdc42be76646287f",
    failing:
      "the timer and its notices (CORD-08 §1, §4) > a malformed message_expiration in the folded metadata reads as off, so a send carries no expiration (CORD-08 §1)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "REL-01.exp-notice-gated",
    verdict: "killed",
    mutation: "exp-notice-authority-open",
    digest: "3334d91d486307c454008b4ff96ce207d5e7ee3992343fe890a48425949596ba",
    failing:
      "the timer and its notices (CORD-08 §1, §4) > a timer notice is displayed only when its author holds MANAGE_METADATA in the fold (CORD-08 §4)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "DEC-03.send-thread-alias",
    verdict: "killed",
    mutation: "forum-subject-tag-omitted",
    digest: "d7881c8e5db3206678a51f2ee77bf75f65fac4358a2de2f713462b5000d928fc",
    failing:
      "titled forum posts (FORUM-01, FORUM-02, DEC-03) > sendThread publishes a titled kind 9 and never a kind 11 (DEC-03, D-02)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-01.subject-cap",
    verdict: "killed",
    mutation: "forum-subject-cap-unchecked",
    digest: "f0f85d4d026ce7ba496c84f36b62a08ced09c000bd3312afcdbb23b528a028a0",
    failing:
      "forum subjects (CORD-03 §3, FORUM-01, FORUM-02) > assertSubject accepts exactly 256 UTF-8 bytes and rejects 257 with a RangeError (D-03)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-01.subject-wire",
    verdict: "killed",
    mutation: "forum-subject-tag-omitted",
    digest: "d7881c8e5db3206678a51f2ee77bf75f65fac4358a2de2f713462b5000d928fc",
    failing:
      "titled forum posts (FORUM-01, FORUM-02, DEC-03) > sendMessage with a subject publishes kind 9 with one subject tag and the channel binding (CORD-03 §3)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-02.display-truncation",
    verdict: "killed",
    mutation: "forum-overlong-subject-dropped",
    digest: "276541b2e7477edfaef674db51dad3da9ebfe91315f44935f1b3f4fdaa190dfb",
    failing:
      "titled forum posts (FORUM-01, FORUM-02, DEC-03) > a received post with an overlong subject is kept and displays truncated on a code-point boundary (FORUM-02, D-04)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "FORUM-03.channels-reemit",
    verdict: "killed",
    mutation: "forum-channel-views-always-chat",
    digest: "e071ead0cd43d8ed6f4c38e691adfd6390a00a22655558760e65f43beccd8547",
    failing: "channel view mode (FORUM-03, D-05, D-06, D-23) > channels$ re-emits when a channel's view changes (D-06)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-03.create-view",
    verdict: "killed",
    mutation: "forum-create-view-validated-after-mint",
    digest: "09b28987a2851acab87562a1ad00f0d1ebc71fda01df2c935a60f2761cf4390a",
    failing:
      "channel view mode (FORUM-03, D-05, D-06, D-23) > createChannel rejects an unknown view before minting a key",
    sweptAt: "b42ea0441368b65f0ace046a2c4cc980d256cdb6",
  },
  {
    row: "FORUM-03.view-preserved",
    verdict: "killed",
    mutation: "forum-fold-rejects-unknown-view",
    digest: "eafe86609af27585e6c37e6fdbf1abeece1bc5f7d09c3ee7b8bcfe33f8ccf857",
    failing:
      "channel view mode (FORUM-03, D-05, D-06, D-23) > an unknown view value presents as chat and survives deleteChannel unchanged (D-05)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-03.view-typed",
    verdict: "killed",
    mutation: "forum-view-unknown-presented",
    digest: "2e448a9443898fff3c4764677757db77ee886c265449a7fe3233d23432dc44cd",
    failing:
      "channel view mode (CORD-03 §2, FORUM-03) > channelViewMode presents forum only for the exact value and chat for anything else (D-05)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-04.receiver-ignores-k",
    verdict: "killed",
    mutation: "forum-edit-requires-k",
    digest: "5a67ff77207dc6779b096868fbdcf572a633805201c2553c48200728ffdb6c70",
    failing: "edit target kinds (FORUM-04, D-07) > an Edit with no k, a wrong k or k=11 still applies to its target",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-05.kind-11-readable",
    verdict: "killed",
    mutation: "forum-kind-11-dropped-on-receive",
    digest: "70644cc886febf5001fe217788b1291fe8d98333933c4ad176f45a77a3a589d4",
    failing:
      "legacy kind 11 history (FORUM-05, D-08) > a retained kind 11 thread root stays readable in channelTimeline",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "FORUM-06.subject-exports",
    verdict: "killed",
    mutation: "forum-export-subject-max-bytes-hidden",
    digest: "746c3b8c040e12bc3c340a2a7e962e7bddac8393099077d7f62b54c562cec33b",
    failing: "concord exports > forum subject helpers and includeSubject are public runtime exports (FORUM-06)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "FORUM-06.view-exports",
    verdict: "killed",
    mutation: "forum-export-channel-view-mode-hidden",
    digest: "a5c2a274aa61583b7485aad463fef0b3e59ce6d0fdf451426ea8886e47646832",
    failing: "concord exports > channelViewMode is a public runtime export (FORUM-06)",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "REL-01.forum-binding-commit",
    verdict: "killed",
    mutation: "forum-binding-channel-tag-omitted",
    digest: "0544aa487c41daa5a9b1f6b6bd2d7bd9b111d4c741c8a3d3d290c6ff106adcc0",
    failing: "chat operations > includeChannelBinding adds channel + epoch tags",
    sweptAt: "88000d6794cb703eff14a8ca853f64c3f305d011",
  },
  {
    row: "REL-01.forum-binding-drop",
    verdict: "killed",
    mutation: "forum-community-route-skips-binding",
    digest: "ec8420f8a63976f0322b68795ba45fef72252477f1e328b1f6b0b206b2eb47ee",
    failing:
      "channel and epoch binding (CORD-03 §3) > a received rumor whose channel or epoch tag does not strict-equal its plane is dropped (CORD-03 §3)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "BAN-01.exports",
    verdict: "killed",
    mutation: "ban-export-rate-limit-error-hidden",
    digest: "36e736b21c573235fd0010f113a18913794a4a5db731bc8691a0d40d8b0d7a92",
    failing:
      "concord exports > Banlist write errors are public runtime exports of the client and root barrels (BAN-01)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "BAN-01.validated-first",
    verdict: "killed",
    mutation: "ban-validation-skipped",
    digest: "6202465315be29bde5aea5691afb86167d92a4332873b51a864ab9c776e19eee",
    failing:
      "batch bans (BAN-01, D-09) > banMembers validates every target first and publishes nothing when any fails (D-09)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-02.last-intent-wins",
    verdict: "killed",
    mutation: "ban-unban-lost-own-not-republished",
    digest: "06a06379d57ec8f0fe49fd4d08e6bdc4d6828f75a2ec22aeaca70df94077a792",
    failing:
      "serialized and rate-limited Banlist writes (BAN-02, D-10, D-11, D-12) > unban of a lost own ban republishes the head unchanged so the ban cannot be revived (D-12, D-21)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-02.serialized",
    verdict: "killed",
    mutation: "ban-writes-not-serialized",
    digest: "bf915ce77595f05018328ef76eba879b033aa2b11d476250aa63c27de0db60a7",
    failing:
      "serialized and rate-limited Banlist writes (BAN-02, D-10, D-11, D-12) > parallel ban calls chain into consecutive editions and keep every ban (D-10)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-03.no-revive-removal",
    verdict: "killed",
    mutation: "ban-heal-revives-removed-ban",
    digest: "7ce5208dcbadcd593c43cc73f0784a32b1022c0e94ca9a500c779a1c3e4129fc",
    failing:
      "planBanlistReHeal (CORD-04 §4, BAN-03, D-12..D-15, D-19, D-21) > a ban that appeared on the head chain and was later removed is never revived (BAN-03)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-03.no-revive-unban",
    verdict: "killed",
    mutation: "ban-unban-intent-not-recorded",
    digest: "815622fce97d1f7e0bb1b85cc500544961956a98212202c33225bdda732e35bc",
    failing:
      "ban re-heal (BAN-03, BAN-04, D-11..D-15) > a refused unban never lets a waiting heal revive the ban (D-12)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-03.own-bans-only",
    verdict: "killed",
    mutation: "ban-heal-seeds-foreign-edition",
    digest: "49d39aa4f31d71bd21a277987266d894339785a51d671d6abd45a8b5b13ecc66",
    failing:
      "planBanlistReHeal (CORD-04 §4, BAN-03, D-12..D-15, D-19, D-21) > only editions this client authored seed candidates (D-14)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-04.bounded-owned",
    verdict: "killed",
    mutation: "ban-heal-attempts-cut-to-one",
    digest: "aea685a9611b30a0a7a5eeb8bd00c243433ed02c25a7767a8a5fbed0fb33e330",
    failing:
      "ban re-heal (BAN-03, BAN-04, D-11..D-15) > a rejected heal acknowledgment retries with backoff, then reports duty-exhausted",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-04.exports",
    verdict: "killed",
    mutation: "ban-export-reheal-error-hidden",
    digest: "a49019ff244b703726b4db20f52a2b8a3fd7426b2ac0d36a0de271fabb821eb4",
    failing: "concord exports > BanlistReHealError is a public runtime export of the client and root barrels (BAN-04)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "BAN-04.stops-on-authority-loss",
    verdict: "killed",
    mutation: "ban-heal-authority-loss-unchecked",
    digest: "bb578b96ebe95c049ce8c7bde2d6098bec617abe0f60f60de55b195ece6841ec",
    failing: "ban re-heal (BAN-03, BAN-04, D-11..D-15) > demotion while a heal waits cancels it (D-15)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-04.stops-on-lifecycle",
    verdict: "killed",
    mutation: "ban-heal-survives-dissolution",
    digest: "212aed6ee31bdf45906ff83c773c3859eae9617dfb2f444e226fbb3dfb80a60e",
    failing: "ban re-heal (BAN-03, BAN-04, D-11..D-15) > dissolution and dispose cancel a waiting heal (D-15)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "BAN-04.typed-non-convergence",
    verdict: "killed",
    mutation: "ban-heal-never-gives-up",
    digest: "94efe7b9048163b38b8886d0aadde7944cc7042ba67b8fbf93a0ebca5f59ba14",
    failing:
      "ban re-heal (BAN-03, BAN-04, D-11..D-15) > three heal publications without convergence report BanlistReHealError non-convergence once (D-15)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.devices",
    verdict: "killed",
    mutation: "ban-heal-not-keyed-to-head",
    digest: "8565a584284a0f063d87b890e0df3b21f04b405dcbe91793fe7c552320189a48",
    failing:
      "ban re-heal across restarts, devices and ranks (BAN-05, D-14, D-15, D-19, D-21) > two engines with one signer publish at most one heal between them",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.mixed-rank-heal",
    verdict: "killed",
    mutation: "ban-heal-blocked-plan-skipped",
    digest: "3979bdcd360741b6f305bf64c8600a1adfb6ff7cfc8f888387f05f6ed37812c7",
    failing:
      "ban re-heal across restarts, devices and ranks (BAN-05, D-14, D-15, D-19, D-21) > a junior whose lost ban sits under a senior's head is blocked and reports BanlistReHealError (mixed rank)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.mixed-rank-write",
    verdict: "killed",
    mutation: "ban-write-carries-unvouched",
    digest: "681e037b7d357ea312a78b1b92aea75686c1accf988fdeeda78cc6d1da2c9d71",
    failing:
      "acknowledged and rank-safe Banlist writes (D-13, D-19, D-20) > a junior writer refuses to carry a senior's ban it cannot vouch for (D-19)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.other-holders",
    verdict: "killed",
    mutation: "ban-heal-seeds-foreign-edition",
    digest: "49d39aa4f31d71bd21a277987266d894339785a51d671d6abd45a8b5b13ecc66",
    failing:
      "ban re-heal across restarts, devices and ranks (BAN-05, D-14, D-15, D-19, D-21) > another BAN holder never re-applies a ban it did not write (D-14)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.refounding-scope",
    verdict: "killed",
    mutation: "ban-heal-ignores-epoch-address",
    digest: "8bc242eb3cdbcf3343cf665a5f35893665ee41766828b6437f17cfd4c646bbd1",
    failing:
      "ban re-heal across restarts, devices and ranks (BAN-05, D-14, D-15, D-19, D-21) > a ban lost before a Refounding is not re-applied after a restart into the new epoch (D-15)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.rejected-ack",
    verdict: "killed",
    mutation: "ban-publish-not-acknowledged",
    digest: "5f9761a89146f910de6167cee5038001d68530ba2bac2af2ed45c7c798437cbf",
    failing:
      "acknowledged and rank-safe Banlist writes (D-13, D-19, D-20) > a rejected acknowledgment rejects with RequiredPublishError and changes no local state (D-20)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "BAN-05.restart",
    verdict: "killed",
    mutation: "ban-unban-lost-own-not-republished",
    digest: "06a06379d57ec8f0fe49fd4d08e6bdc4d6828f75a2ec22aeaca70df94077a792",
    failing:
      "ban re-heal across restarts, devices and ranks (BAN-05, D-14, D-15, D-19, D-21) > a restarted engine never revives a ban its later own unban cancelled (D-21)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "DEC-04.banned-self-delete",
    verdict: "killed",
    mutation: "ban-self-delete-ignored-by-upkeep",
    digest: "9d6f33282d0cf30cceaa05ba9058baa3bd579d6d301d7da7ce771ad3730a0867",
    failing:
      "banned pinners (DEC-04, D-16) > a banned author's own deletion of a pinned message still hides it and is upkept once (D-16)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "DEC-04.fallback-no-republish",
    verdict: "killed",
    mutation: "ban-pinner-edition-kept-after-ban",
    digest: "cf2cc0818a2eadcfa6b7e2cbed4f304e31f3a5e8d98103b31056e3d0c2038bd1",
    failing:
      "banned pinners (DEC-04, D-16) > banning a pinner who edited the Pin List falls back to the earlier list and publishes no Pin List edition (D-16)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "DEC-04.writer-replaces-reverted-head",
    verdict: "killed",
    mutation: "ban-writer-chains-over-rejected-edition",
    digest: "a14740f868890d05c9083a67d0df2cebec7e42871c56a221a43ce33e66e43b58",
    failing:
      "banned pinners (DEC-04, D-16) > the next authorized writer replaces a reverted Pin List head after a pinner is banned (D-16)",
    sweptAt: "d86edbe4de516f50f777a11240b8e993d132572a",
  },
  {
    row: "REL-01.ban-derived-coordinate",
    verdict: "killed",
    mutation: "ban-coordinate-unchecked",
    digest: "fca011661ccb18e947746afe4228b226996528d42da8aff18db5f86a011a75b7",
    failing: "control fold > folds the banlist only at its derived coordinate",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-drops-authority-actions",
    verdict: "killed",
    mutation: "ban-authority-actions-not-dropped",
    digest: "b84346e825054d9213a0b9cd2ee03eebe3d8be6ef9ec26b01880bb19d40900bf",
    failing: "Banlist fold (CORD-04 §§1, 3, 4, 5) > drops the authority actions of a banned npub (CORD-04 §4)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-drops-chat-events",
    verdict: "killed",
    mutation: "ban-timeline-keeps-banned",
    digest: "18f7ee27392d540ab5ec8685379e00419474bd99b6b8338501d25980fdb12ffb",
    failing:
      "the ban-aware channel timeline (CORD-04 §4) > drops a banned author's message, reaction, edit and comment, and keeps everyone else's",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-head-replaces-list",
    verdict: "killed",
    mutation: "ban-head-lowest-version",
    digest: "638569995ec4ad44747103d3f7230149c45fb7d5d0d4f72bfac15c717987257b",
    failing:
      "Banlist fold (CORD-04 §§1, 3, 4, 5) > replaces the whole list with the highest version and refuses to downgrade (CORD-04 §1, §4)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-member-vanishes",
    verdict: "killed",
    mutation: "ban-guestbook-banned-counted",
    digest: "443816ddad340d0e58dcfb51ca805b0b52eae9ea0836168ee6d35996b341f6be",
    failing:
      "a banned npub vanishes from membership (CORD-04 §4) > ignores the membership effects of a banned author, including a secondhand Snapshot",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-owner-unbannable",
    verdict: "killed",
    mutation: "ban-fold-owner-bannable",
    digest: "cdf6bb77072f536ad51a207c42f6b1d0dd0b7d8ec1ed28718ee9f349217d9d5d",
    failing: "Banlist fold (CORD-04 §§1, 3, 4, 5) > never bans the owner, whoever signs the list (CORD-04 §2)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-same-version-converges",
    verdict: "killed",
    mutation: "ban-tie-higher-rumor-id",
    digest: "93d3be5a4cc9f89f36723da6bdbb2f373ad64a988a5845d5906ed307dbea74ea",
    failing:
      "Banlist fold (CORD-04 §§1, 3, 4, 5) > keeps one of two same-version Banlist editions, the lower rumor id, and drops the other's addition (CORD-04 §1, §4)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-signer-holds-ban",
    verdict: "killed",
    mutation: "ban-fold-bit-unchecked",
    digest: "43c17b4222036dec40ea54b4edc6bd9bb50b004da8b45e3509cf3574e482ad53",
    failing: "Banlist fold (CORD-04 §§1, 3, 4, 5) > honors a Banlist only when its signer holds BAN (CORD-04 §4)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-strict-outrank",
    verdict: "killed",
    mutation: "ban-fold-rank-not-strict",
    digest: "e2132ffafe5ca18ea7ebb6360dccc2d57108545b4b5ddbf5a699db50546d6e37",
    failing:
      "Banlist fold (CORD-04 §§1, 3, 4, 5) > honors a Banlist entry only when its signer strictly outranks the target: a peer is not banned (CORD-04 §3)",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
  {
    row: "REL-01.ban-wire-lowercase-hex",
    verdict: "killed",
    mutation: "ban-targets-not-lowercased",
    digest: "ff1af101344ed596dd4c12a0391a3004ac837e998887fa9cac11362d66a50f71",
    failing:
      "Banlist write planning (CORD-04 §§4, 6, BAN-01, D-09, D-19) > normalizeBanTargets lowercases, dedupes and reports invalid keys",
    sweptAt: "2591e500a8c1b786b0974c2174b752e097916a07",
  },
];

/**
 * Returns one message per problem: a verdict for an unknown or repeated row, a `sweptAt` that is not a commit id, a
 * `killed` verdict whose mutation is gone, no longer lists the row or changed since the sweep, a `killed` verdict whose
 * recorded `failing` testcase is missing or is no longer one of the row's current cited tests, or an `exempt-approved`
 * verdict without an approved exemption.
 */
async function verdictProblems(
  verdicts: readonly RecordedVerdict[],
  mutations: readonly GuardMutation[],
  exemptions: readonly MutationExemption[],
  ledger: readonly LedgerEntry[],
): Promise<string[]> {
  const problems: string[] = [];
  const seen = new Set<string>();
  for (const verdict of verdicts) {
    const label = verdict.row;
    const entry = ledger.find((candidate) => candidate.id === verdict.row);
    if (!entry) {
      problems.push(`${label}: not a ledger row`);
      continue;
    }
    if (seen.has(verdict.row)) problems.push(`${label}: recorded more than once`);
    seen.add(verdict.row);
    if (!/^[0-9a-f]{40}$/.test(verdict.sweptAt)) problems.push(`${label}: sweptAt is not a 40-character commit id`);
    if (verdict.verdict === "killed") {
      const mutation = mutations.find((candidate) => candidate.id === verdict.mutation);
      if (!mutation) problems.push(`${label}: mutation "${verdict.mutation}" does not exist`);
      else if (!mutation.rows.includes(verdict.row)) {
        problems.push(`${label}: mutation ${mutation.id} no longer lists it`);
      } else if (verdict.digest !== await mutationDigest(mutation)) {
        problems.push(`${label}: mutation ${mutation.id} changed since the sweep`);
      }
      // A kill proves the row only through one of its own cited tests; a citation re-pointed or dropped after the sweep
      // leaves the recorded failure proving nothing about the current row, so it needs a re-sweep.
      if (!failingIsCited(verdict.failing ?? "", entry.tests)) {
        problems.push(`${label}: failing testcase is not one of the row's current cited tests`);
      }
    } else {
      const exemption = exemptions.find((candidate) => candidate.row === verdict.row);
      if (!exemption || !exemption.reason.trim() || !exemption.approval.trim()) {
        problems.push(`${label}: exempt-approved without an approved exemption`);
      }
    }
  }
  return problems;
}

const SWEPT_AT = "0123456789abcdef0123456789abcdef01234567";

const row = (id: string): LedgerEntry => ({
  id,
  requirement: "PIN-99",
  level: "MUST",
  rule: "synthetic",
  phase: 6,
  status: "covered",
  tests: [{ file: "helpers/__tests__/sample.test.ts", name: "x" }],
});

const mutation = (overrides: Partial<GuardMutation> = {}): GuardMutation => ({
  id: "m",
  group: "A5",
  rows: ["PIN-99.a"],
  sites: [{ file: "helpers/sample.ts", find: "alpha", replace: "omega" }],
  note: "synthetic",
  ...overrides,
});

describe("recorded sweep verdicts (REL-01, D-04)", () => {
  it("every recorded verdict names a ledger row and a current mutation or an approved exemption", async () => {
    expect(
      await verdictProblems(CONFORMANCE_VERDICTS, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER),
    ).toEqual([]);
    // Non-vacuity: the table holds the 157 kills of the swept groups, each naming the testcase that failed, so the
    // citation check above compares real names rather than passing over an emptied table.
    const kills = CONFORMANCE_VERDICTS.filter((verdict) => verdict.verdict === "killed");
    expect(kills.length).toBeGreaterThanOrEqual(157);
    expect(kills.filter((verdict) => !verdict.failing)).toEqual([]);
  });

  it("every A3-offline MUST row has a killed verdict or a user-approved exemption", async () => {
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A3-offline"
    ).map((entry) => entry.id);
    // Non-vacuity: LIST-01, LIST-02 and LIST-03 each contribute rows, so an emptied group cannot pass.
    expect(rows.length).toBeGreaterThanOrEqual(19);
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => rows.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...rows].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
  });

  it("every A3-recovery MUST row has a killed verdict or a user-approved exemption", async () => {
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A3-recovery"
    ).map((entry) => entry.id);
    // Non-vacuity: LIST-04 to LIST-08 and the CORD-02 §8 spec-sweep rows each contribute rows, so an emptied group
    // cannot pass.
    expect(rows.length).toBeGreaterThanOrEqual(33);
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => rows.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...rows].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
  });

  it("every A5 MUST row has a killed verdict or a user-approved exemption", async () => {
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A5"
    ).map((entry) => entry.id);
    // Non-vacuity: PIN-01 to PIN-11, DEC-01, DEC-02 and the CORD-04 §7 spec-sweep rows each contribute rows, so an
    // emptied group cannot pass.
    expect(rows.length).toBeGreaterThanOrEqual(41);
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => rows.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...rows].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
  });

  it("every A4 MUST row has a killed verdict or a user-approved exemption", async () => {
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A4"
    ).map((entry) => entry.id);
    // Non-vacuity: EXP-01 to EXP-06 and the CORD-08 spec-sweep rows each contribute rows, so an emptied group cannot
    // pass.
    expect(rows.length).toBeGreaterThanOrEqual(18);
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => rows.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...rows].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
  });

  it("every A8 MUST row has a killed verdict or a user-approved exemption", async () => {
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A8"
    ).map((entry) => entry.id);
    // Non-vacuity: FORUM-01 to FORUM-06, DEC-03 and the CORD-03 spec-sweep rows each contribute rows, so an emptied
    // group cannot pass.
    expect(rows.length).toBeGreaterThanOrEqual(14);
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => rows.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...rows].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
  });

  it("every A9 MUST row has a killed verdict or a user-approved exemption", async () => {
    const rows = CONFORMANCE_LEDGER.filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === "A9"
    ).map((entry) => entry.id);
    // Non-vacuity: BAN-01 to BAN-05, DEC-04 and the CORD-04 §4 spec-sweep rows each contribute rows, so an emptied
    // group cannot pass.
    expect(rows.length).toBeGreaterThanOrEqual(32);
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => rows.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...rows].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
  });

  it("every in-scope MUST row of A3, A4, A5, A8 and A9 has a killed verdict or a user-approved exemption", async () => {
    // Non-vacuity: the covered MUST rows each group held when it was proven (plans 06-06 to 06-14); spec-sweep rows only
    // add to them, so an emptied or dropped group cannot pass.
    const minimum: Record<SweepGroup, number> = {
      "A3-offline": 19,
      "A3-recovery": 33,
      A4: 18,
      A5: 41,
      A8: 14,
      A9: 32,
    };
    expect(SWEEP_GROUPS).toEqual(["A3-offline", "A3-recovery", "A4", "A5", "A8", "A9"]);
    const inScope: string[] = [];
    for (const group of SWEEP_GROUPS) {
      const rows = CONFORMANCE_LEDGER.filter((entry) =>
        entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === group
      ).map((entry) => entry.id);
      expect({ group, rows: rows.length >= minimum[group] }).toEqual({ group, rows: true });
      inScope.push(...rows);
    }
    const recorded = CONFORMANCE_VERDICTS.filter((verdict) => inScope.includes(verdict.row));
    expect(recorded.map((verdict) => verdict.row).sort()).toEqual([...inScope].sort());
    expect(await verdictProblems(recorded, GUARD_MUTATIONS, MUTATION_EXEMPTIONS, CONFORMANCE_LEDGER)).toEqual([]);
    // A row is proven only by a mutation of its own group.
    for (const verdict of recorded.filter((candidate) => candidate.verdict === "killed")) {
      const entry = CONFORMANCE_LEDGER.find((candidate) => candidate.id === verdict.row)!;
      const mutation = GUARD_MUTATIONS.find((candidate) => candidate.id === verdict.mutation)!;
      expect({ row: verdict.row, group: mutation.group }).toEqual({ row: verdict.row, group: sweepGroupOf(entry) });
    }
    // The table claims nothing outside the in-scope MUST rows.
    expect(CONFORMANCE_VERDICTS.filter((verdict) => !inScope.includes(verdict.row)).map((verdict) => verdict.row))
      .toEqual([]);
  });

  it("the verdict checker rejects stale or malformed entries", async () => {
    const ledger = [row("PIN-99.a"), row("PIN-99.b")];
    const mutations = [mutation()];
    const digest = await mutationDigest(mutations[0]);
    const killed: RecordedVerdict = {
      row: "PIN-99.a",
      verdict: "killed",
      mutation: "m",
      digest,
      failing: "sample > x",
      sweptAt: SWEPT_AT,
    };
    const check = (verdicts: readonly RecordedVerdict[], exemptions: readonly MutationExemption[] = []) =>
      verdictProblems(verdicts, mutations, exemptions, ledger);

    // The synthetic baseline and the empty table are clean, so each rejection below has exactly one cause.
    expect(await check([])).toEqual([]);
    expect(await check([killed])).toEqual([]);

    expect(await check([{ ...killed, row: "PIN-99.missing" }])).toHaveLength(1);
    expect(await check([{ ...killed, mutation: "gone" }])).toHaveLength(1);
    expect(await check([{ ...killed, row: "PIN-99.b" }])).toHaveLength(1);
    expect(await check([{ ...killed, digest: "0".repeat(64) }])).toHaveLength(1);
    expect(await check([{ ...killed, digest: undefined }])).toHaveLength(1);
    expect(await check([{ ...killed, sweptAt: "abc123" }])).toHaveLength(1);
    expect(await check([killed, killed])).toHaveLength(1);

    // A mutation whose sites changed after the sweep no longer vouches for the verdict.
    const edited = [mutation({ sites: [{ file: "helpers/sample.ts", find: "alpha", replace: "sigma" }] })];
    expect(await verdictProblems([killed], edited, [], ledger)).toHaveLength(1);

    // A kill must name one of the row's current cited tests: a missing or uncited failing name, or a row whose citation
    // moved to another test after the sweep, no longer vouches for the verdict.
    expect(await check([{ ...killed, failing: undefined }])).toHaveLength(1);
    expect(await check([{ ...killed, failing: "" }])).toHaveLength(1);
    expect(await check([{ ...killed, failing: "sample > y" }])).toHaveLength(1);
    const repointed = [{ ...row("PIN-99.a"), tests: [{ file: "helpers/__tests__/sample.test.ts", name: "z" }] }];
    expect(await verdictProblems([killed], mutations, [], repointed)).toHaveLength(1);
    const dropped = [{ ...row("PIN-99.a"), tests: [] }];
    expect(await verdictProblems([killed], mutations, [], dropped)).toHaveLength(1);
    // A row that cites `__tests__/index.test.ts` is killed only through that file's citations, as the runner judges it.
    const pinned = [{
      ...row("PIN-99.a"),
      tests: [{ file: "helpers/__tests__/sample.test.ts", name: "x" }, {
        file: "__tests__/index.test.ts",
        name: "e",
      }],
    }];
    expect(await verdictProblems([killed], mutations, [], pinned)).toHaveLength(1);
    expect(await verdictProblems([{ ...killed, failing: "exports > e" }], mutations, [], pinned)).toEqual([]);

    const exempt: RecordedVerdict = { row: "PIN-99.b", verdict: "exempt-approved", sweptAt: SWEPT_AT };
    const approved: MutationExemption = {
      row: "PIN-99.b",
      reason: "the guard cannot be disabled offline",
      approval: "approved by the user, 2026-10-30",
    };
    expect(await check([exempt])).toHaveLength(1);
    expect(await check([exempt], [approved])).toEqual([]);
    expect(await check([exempt], [{ ...approved, approval: " " }])).toHaveLength(1);
  });
});
