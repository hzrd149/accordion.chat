/// <reference lib="deno.ns" />

import { basename, dirname, fromFileUrl, join } from "@std/path";
import { expect } from "@std/expect";
import { it } from "@std/testing/bdd";

const SRC_ROOT = fromFileUrl(new URL("../", import.meta.url));

function collectFiles(directory: string): string[] {
  return Array.from(Deno.readDirSync(directory)).flatMap((entry) => {
    const path = join(directory, entry.name);
    return entry.isDirectory ? collectFiles(path) : [path];
  });
}

it("module test suites live in adjacent __tests__ folders and use their source module's name", () => {
  const files = collectFiles(SRC_ROOT);
  const paths = new Set(files);
  const tests = files.filter((path) => /(?:\.test\.ts|\.spec\.ts|_test\.ts)$/.test(path));
  expect(tests.length).toBeGreaterThan(0);

  const misplaced = tests.filter((path) => {
    const directory = dirname(path);
    if (basename(directory) !== "__tests__") return true;
    const module = basename(path).split(".")[0];
    // Suites for shared test utilities sit beside those utilities inside __tests__.
    return !paths.has(join(directory, "..", `${module}.ts`)) && !paths.has(join(directory, `${module}.ts`));
  });
  expect(misplaced).toEqual([]);
});
