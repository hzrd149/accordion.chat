// The REL-01 guard-mutation manifest (D-04). Each entry disables one guard of the library and lists every conformance
// ledger row that guard defends; the sweep runner (conformance-sweep.ts) applies an entry only inside a scratch
// `git clone --local` copy (D-10) and judges each listed row by its own cited tests failing.
//
// - A site's `file` is relative to `src/`; `find` is exact text that occurs exactly once in that file; `replace` is the
//   smallest edit that disables the guard without breaking parsing. An entry may have several sites, applied together,
//   when the rule is enforced in several places.
// - Barrels (`index.ts`) re-export with `export *`. Removing a symbol from its source module breaks other modules'
//   imports at link time, so an export-pinned row is hidden at the barrel instead, with a shadowing
//   `export const <name> = undefined;` beside the star re-export; such an entry must list only rows that cite a test in
//   `__tests__/index.test.ts`, because only that test can fail for the right reason.
// - `MUTATION_EXEMPTIONS` may hold only rows the user explicitly approved, relayed by the orchestrator, with the
//   approval quoted and dated; never an executor's own judgement. The runner counts every exempt row as missing, so an
//   exemption never lets a group pass on its own (a recorded deviation from ROADMAP SC3).

import { CONFORMANCE_LEDGER, type LedgerEntry } from "./conformance-ledger.ts";

/** A group of ledger rows swept together; one group per research area. */
export type SweepGroup = "A3-offline" | "A3-recovery" | "A4" | "A5" | "A8" | "A9";

/** Every sweep group, in sweep order. */
export const SWEEP_GROUPS: readonly SweepGroup[] = ["A3-offline", "A3-recovery", "A4", "A5", "A8", "A9"];

/**
 * The sweep group of a ledger row, or `undefined` for a row that is out of scope (FND-* and AV-01 rows). Rows are placed
 * by requirement; spec-sweep rows carry requirement `REL-01` and are placed by their id prefix.
 */
export function sweepGroupOf(entry: LedgerEntry): SweepGroup | undefined {
  const { requirement, id } = entry;
  if (/^LIST-0[123]$/.test(requirement)) return "A3-offline";
  if (/^LIST-0[4-8]$/.test(requirement) || id.startsWith("REL-01.list-")) return "A3-recovery";
  if (requirement.startsWith("EXP-") || id.startsWith("REL-01.exp-")) return "A4";
  if (
    requirement.startsWith("PIN-") || requirement === "DEC-01" || requirement === "DEC-02" ||
    id.startsWith("REL-01.pin-")
  ) return "A5";
  if (requirement.startsWith("FORUM-") || requirement === "DEC-03" || id.startsWith("REL-01.forum-")) return "A8";
  if (requirement.startsWith("BAN-") || requirement === "DEC-04" || id.startsWith("REL-01.ban-")) return "A9";
  return undefined;
}

/** One edit of one source file. */
export interface MutationSite {
  /** Path relative to `src/`. */
  file: string;
  /** Exact text that occurs exactly once in the file. */
  find: string;
  /** The replacement text. */
  replace: string;
}

/** One guard disabled by a set of sites, and every ledger row that guard defends. */
export interface GuardMutation {
  /** Stable kebab-case id. */
  id: string;
  /** The sweep group the mutation is swept with. */
  group: SweepGroup;
  /** Ids of the ledger rows whose cited tests must fail under this mutation. */
  rows: readonly string[];
  /** The edits, applied together. */
  sites: readonly MutationSite[];
  /** Why the edit disables the guard. */
  note: string;
}

/** A row the user explicitly agreed may pass without a guard mutation. */
export interface MutationExemption {
  /** Ledger row id. */
  row: string;
  /** Why the guard cannot be disabled by a source edit. */
  reason: string;
  /** The user's explicit approval as relayed by the orchestrator, quoted, with its date. */
  approval: string;
}

/** The guard mutations. */
export const GUARD_MUTATIONS: readonly GuardMutation[] = [
  {
    id: "pin-11-admin-preset-grants-pins",
    group: "A5",
    rows: ["PIN-11.admin-preset-omits-pin-messages"],
    sites: [{
      file: "types.ts",
      find: "  PERM.MENTION_EVERYONE;",
      replace: "  PERM.MENTION_EVERYONE |\n  PERM.PIN_MESSAGES;",
    }],
    note:
      "The admin preset must not grant pin authority (PIN-11); adding PIN_MESSAGES to ADMIN_PERMS removes that guard.",
  },
  {
    id: "list-read-complete-always",
    group: "A3-offline",
    rows: ["LIST-01.no-local-only-fragment"],
    sites: [
      {
        file: "client/community-list-read.ts",
        find: '    complete: !failure && Object.values(relays).some((state) => state === "complete"),',
        replace: "    complete: true,",
      },
    ],
    note:
      "A Community List read counts as complete only when a relay reached its own complete state (CORD-02 §8, a short read means incomplete); reporting every read as complete lets an offline or failed read look like an empty list.",
  },
  {
    id: "list-write-gate-assert-known",
    group: "A3-offline",
    rows: ["LIST-01.no-local-only-fragment"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    if (!this.requireCompletedRead) return;",
        replace: "    if (!this.requireCompletedRead || true) return;",
      },
    ],
    note:
      "The write gate refuses a first fragment until a completed read confirms what the relay holds (CORD-02 §8, a missing fragment means unseen); skipping it lets a client publish a fresh fragment 0 without having read the list.",
  },
  {
    id: "list-held-write-release-paths",
    group: "A3-offline",
    rows: ["LIST-01.held-write-release", "LIST-01.restart-safe-pending"],
    sites: [
      {
        file: "client/client.ts",
        find: "    if (this.heldSaveDue()) void lane.save();",
        replace: "    if (false && this.heldSaveDue()) void lane.save();",
      },
      {
        file: "client/community-list-lane.ts",
        find:
          '    if (host.ready() && host.held() && !this.options.duties.slotPending("community-list-read")) this.queueSave();',
        replace:
          '    if (false && host.ready() && host.held() && !this.options.duties.slotPending("community-list-read")) this.queueSave();',
      },
      {
        file: "client/community-list-lane.ts",
        find: "    if (host.held()) {\n      duty.assertAlive();",
        replace: "    if (false && host.held()) {\n      duty.assertAlive();",
      },
    ],
    note:
      "A held Community List write is released once a relay completes the read: by start() when its read is recorded, by an unlock, and by the read duty (D-15, D-26); disabling all three leaves the write held for good.",
  },
  {
    id: "list-held-save-never-due",
    group: "A3-offline",
    rows: ["LIST-01.restart-safe-pending"],
    sites: [
      {
        file: "client/community-list-document.ts",
        find: "  return heldMembershipIds(local, base).length > 0;",
        replace: "  return heldMembershipIds(local, base).length < 0;",
      },
    ],
    note:
      "A save is owed when the local document holds a membership change the completed relay copy lacks (CORD-02 §8, D-26); never owing one drops a held write, including one that survived a restart.",
  },
  {
    id: "list-mirror-not-loaded",
    group: "A3-offline",
    rows: ["LIST-01.restart-safe-pending"],
    sites: [
      {
        file: "client/client.ts",
        find: "        this.list = mergeCommunities(this.list, mirror.entries);",
        replace: "        this.list = this.list;",
      },
    ],
    note:
      "start() merges the local mirror into the document first, which is what lets a held write survive a process restart; not merging it forgets the unpublished change.",
  },
  {
    id: "list-lane-serial-tail",
    group: "A3-offline",
    rows: ["LIST-01.single-lane"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "    const run = this.tail.then(() => (this.isClosed ? undefined : step()));",
        replace: "    const run = Promise.resolve().then(() => (this.isClosed ? undefined : step()));",
      },
    ],
    note:
      "Every Community List step waits for the previous one on a single promise tail (CORD-02 §8, D-31); starting each step at once lets reads, ingests, unlocks and saves interleave.",
  },
  {
    id: "list-lane-closed-runs-steps",
    group: "A3-offline",
    rows: ["LIST-01.single-lane"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "    if (this.isClosed) return Promise.resolve(undefined);\n    const run",
        replace: "    const run",
      },
      {
        file: "client/community-list-lane.ts",
        find: ".then(() => (this.isClosed ? undefined : step()))",
        replace: ".then(() => step())",
      },
    ],
    note:
      "A closed lane runs no later step (stop() ends the lane); removing both closed checks lets a step queued or enqueued after stop() run.",
  },
  {
    id: "list-lane-retired-save-dropped",
    group: "A3-offline",
    rows: ["LIST-01.no-stranded-held-write", "LIST-01.save-view-current"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: '    if (outcome === "retired") this.queueSave();',
        replace: '    if (outcome === "retired" && false) this.queueSave();',
      },
    ],
    note:
      "A save retired by a newer document or arrival is re-queued, never dropped; dropping it strands the held write.",
  },
  {
    id: "list-lane-read-rearm-skipped",
    group: "A3-offline",
    rows: ["LIST-01.no-stranded-held-write"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: '        if (knowledge === "unknown" && !this.beginning) this.requestRead(true);',
        replace: '        if (false && knowledge === "unknown" && !this.beginning) this.requestRead(true);',
      },
    ],
    note:
      "Every transition of the list to unknown (a failed unlock or ingest) re-arms the read duty so a held write is not stranded; skipping the re-arm leaves it waiting.",
  },
  {
    id: "list-join-save-skipped-after-failed-publish",
    group: "A3-offline",
    rows: ["LIST-01.resumable-join"],
    sites: [
      {
        file: "client/client.ts",
        find: "    assertLive();\n    await this.saveCommunityList().catch((error) => {",
        replace:
          "    if (failure) throw failure.error;\n    assertLive();\n    await this.saveCommunityList().catch((error) => {",
      },
    ],
    note:
      "A join or create that rejects after recording the membership still saves the Community List (D-34); rethrowing before the save leaves the recorded membership unsaved.",
  },
  {
    id: "list-motions-not-in-call-order",
    group: "A3-offline",
    rows: ["LIST-01.motions-in-call-order"],
    sites: [
      {
        file: "client/community-motions.ts",
        find: "    const run = Promise.race([chains.get(cid) ?? Promise.resolve(), this.ending]).then(() => {",
        replace: "    const run = Promise.race([Promise.resolve(), this.ending]).then(() => {",
      },
    ],
    note:
      "Each community's Join and Leave calls wait for the earlier call of that community (CORD-02 §5 and §8, D-34); not waiting lets a later motion overtake an earlier one.",
  },
  {
    id: "list-dirty-flag-not-cleared",
    group: "A3-offline",
    rows: ["LIST-01.dirty-reflects-relay-copy"],
    sites: [
      {
        file: "client/client.ts",
        find: "      this.publishedListFingerprint = fingerprint;\n      this.communityListDirty$.next(false);",
        replace: "      this.publishedListFingerprint = fingerprint;",
      },
    ],
    note:
      "Recording a fingerprint as published clears communityListDirty$; keeping it set leaves the list flagged as unpublished after the relay copy holds the memberships.",
  },
  {
    id: "list-publish-evidence-recheck-skipped",
    group: "A3-offline",
    rows: ["LIST-01.publish-needs-current-evidence"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "      if (this.requireCompletedRead && (!this.readComplete || this.readEpoch !== epoch)) {",
        replace: "      if (false && this.requireCompletedRead && (!this.readComplete || this.readEpoch !== epoch)) {",
      },
    ],
    note:
      "Before each fragment a write re-checks that this lifecycle's completed read still stands (D-31); skipping the check lets a write whose evidence was withdrawn while it signed publish.",
  },
  {
    id: "list-lane-stored-view-not-checked",
    group: "A3-offline",
    rows: ["LIST-02.no-demotion-under-interleaving", "LIST-01.save-view-current"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "  private async ingestStored(): Promise<boolean> {\n",
        replace: "  private async ingestStored(): Promise<boolean> {\n    if (this.options) return true;\n",
      },
      {
        file: "client/community-list-lane.ts",
        find: "  private viewCurrent(): boolean {\n",
        replace: "  private viewCurrent(): boolean {\n    if (this.options) return true;\n",
      },
    ],
    note:
      "A save ingests every stored fragment and checks the lane view before it plans or publishes (CORD-02 §8, D-31); skipping both lets it publish a smaller count over a fragment that arrived meanwhile.",
  },
  {
    id: "list-sign-timestamp-not-above-winner",
    group: "A3-offline",
    rows: ["LIST-02.newest-seen-governs"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "        (this.seen.get(index)?.created_at ?? 0) + 1,\n",
        replace: "        0,\n",
      },
    ],
    note:
      "Every signed fragment is timestamped above the winner already seen at its index (CORD-02 §8); without that floor a fast clock lets an older timestamp lose to the held copy.",
  },
  {
    id: "list-sync-view-bypasses-lane",
    group: "A3-offline",
    rows: ["LIST-02.sync-api-on-lane"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "    lane()?.runSyncWrite(write) ?? Promise.reject(new ConcordClientNotStartedError());",
        replace: "    lane() ? write(() => {}) : Promise.reject(new ConcordClientNotStartedError());",
      },
    ],
    note:
      "write() and repack() on the client's communityListSync run as steps of the open lane (D-35); calling the sync directly skips the lane's ingest and view check.",
  },
  {
    id: "list-sync-view-lane-owned-methods-open",
    group: "A3-offline",
    rows: ["LIST-02.sync-api-on-lane"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "      if (LANE_OWNED.has(property)) {",
        replace: "      if (false && LANE_OWNED.has(property)) {",
      },
    ],
    note:
      "abandon(), restore() and the read-evidence methods belong to the lane and throw on the client's view (WR-06); exposing them lets an app bypass the lane.",
  },
  {
    id: "list-sync-view-runs-without-lane",
    group: "A3-offline",
    rows: ["LIST-02.sync-api-needs-open-lane"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "    lane()?.runSyncWrite(write) ?? Promise.reject(new ConcordClientNotStartedError());",
        replace: "    lane()?.runSyncWrite(write) ?? write(() => {});",
      },
    ],
    note:
      "write() and repack() on the client's communityListSync reject when no lane is open (D-30, D-35); running them directly lets a call outside a lifecycle pass the next lifecycle's read gate.",
  },
  {
    id: "list-sync-write-outlives-lane",
    group: "A3-offline",
    rows: ["LIST-02.sync-api-needs-open-lane"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find:
          "    // A step still waiting when the lane closes is refused at its next fragment by assertView, so rejecting now is safe.\n    return Promise.race([settled, this.refused]);",
        replace: "    return settled;",
      },
    ],
    note:
      "A routed write rejects as soon as its lane closes, even behind a step that never settles (D-30); waiting for the step instead keeps the caller pending past stop().",
  },
  {
    id: "list-persist-skipped",
    group: "A3-offline",
    rows: ["LIST-03.persist-verified-winners"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    if (!persist) return;",
        replace: "    return;",
      },
    ],
    note:
      "Every new authenticated winner is handed to the persist callback (CORD-02 §8, D-01); never handing it over leaves nothing to restore after a restart.",
  },
  {
    id: "list-store-overwrites-unreadable-record",
    group: "A3-offline",
    rows: ["LIST-03.persist-verified-winners"],
    sites: [
      {
        file: "client/community-list-store.ts",
        find: "    if (slot.unreadable) {",
        replace: "    if (false && slot.unreadable) {",
      },
    ],
    note:
      "A fragment record whose storage read failed is never replaced until a later start reads it (WR-02); replacing it can destroy copies no relay holds.",
  },
  {
    id: "list-restore-skips-authentication",
    group: "A3-offline",
    rows: ["LIST-03.restore-verified"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "        const accepted = this.accept(event, pubkey);",
        replace: "        const accepted = this.shape(event);",
      },
    ],
    note:
      "A stored fragment passes the same author, kind, index and signature check as a relay arrival before it is restored (D-03); checking only its shape keeps forged and foreign events.",
  },
  {
    id: "list-store-load-accepts-foreign-record",
    group: "A3-offline",
    rows: ["LIST-03.restore-verified"],
    sites: [
      {
        file: "client/community-list-store.ts",
        find:
          "    !isPlainObject(parsed) || parsed.version !== COMMUNITY_LIST_FRAGMENT_RECORD_VERSION || parsed.pubkey !== pubkey ||",
        replace: "    !isPlainObject(parsed) ||",
      },
    ],
    note:
      "A stored record of another version or another user is refused whole (D-03); dropping those checks restores a foreign record.",
  },
  {
    id: "list-restore-skipped-at-start",
    group: "A3-offline",
    rows: ["LIST-03.restore-before-relay"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "    await this.restoreStored();\n    if (this.isClosed) return CANCELLED;",
        replace: "    await Promise.resolve();\n    if (this.isClosed) return CANCELLED;",
      },
    ],
    note:
      "start() puts the stored fragment record back before any relay read (CORD-02 §8, D-04); skipping it leaves a restarted client without its fragments until a relay answers.",
  },
  {
    id: "list-restore-counts-as-read-evidence",
    group: "A3-offline",
    rows: ["LIST-03.restored-not-evidence"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    this.refreshStatus();\n    this.kickPersist();\n    if (dropped > 0)",
        replace:
          "    this.readComplete = true;\n    this.refreshStatus();\n    this.kickPersist();\n    if (dropped > 0)",
      },
    ],
    note:
      "Restored fragments are never read evidence (D-04); treating a restore as a completed read lets an empty relay answer look like an empty list.",
  },
  {
    id: "list-locked-never-reported",
    group: "A3-offline",
    rows: ["LIST-03.unlock-retained"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    return [...this.seen].some(([index, event]) => this.fragments.get(index)?.id !== event.id);",
        replace: "    return false;",
      },
    ],
    note:
      "A fragment that is held but not decrypted is reported as locked (CORD-02 §8, D-04); never reporting it hides the unlock the app must request.",
  },
  {
    id: "list-repack-staging-raises-count",
    group: "A3-recovery",
    rows: ["LIST-04.prefix-complete", "LIST-08.no-lost-keys"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find:
          "      staging.set(base + index, { frags: base, entries: document.entries, tombstones: document.tombstones });",
        replace:
          "      staging.set(base + index, { frags: temporaryCount, entries: document.entries, tombstones: document.tombstones });",
      },
    ],
    note:
      "Staging copies declare the old count so they stay dormant (CORD-02 §8, D-17); declaring the raised count at the staging stage makes every acknowledged prefix an incomplete List that can hide a membership.",
  },
  {
    id: "list-repack-copy-stage-skipped",
    group: "A3-recovery",
    rows: ["LIST-04.prefix-complete", "LIST-08.no-lost-keys"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    await publishPhase(copies, baseline);",
        replace: "    void copies;",
      },
    ],
    note:
      "The copy stage raises the count only after every staging copy is acknowledged (CORD-02 §8, D-17); jumping from staging to the final count lets a prefix hide records that are not yet in range.",
  },
  {
    id: "list-repack-cleanup-skipped",
    group: "A3-recovery",
    rows: ["LIST-04.repair-converges", "LIST-08.no-wedged-cleanup", "REL-01.list-lowering-empties-dropped"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    await publishPhase(new Map([...cleanup].sort(([a], [b]) => a - b)), baseline);",
        replace: "    void cleanup;",
      },
    ],
    note:
      "The last repack stage republishes every dropped or staging index as a zero-element List (CORD-02 §8); skipping it leaves dormant content that a later count raise brings back and the repair never converges.",
  },
  {
    id: "list-repack-dormant-beyond-staging-kept",
    group: "A3-recovery",
    rows: ["LIST-08.no-wedged-cleanup"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "      if (index >= temporaryCount) cleanup.set(index, { frags: count, entries: [], tombstones: [] });",
        replace:
          "      if (false && index >= temporaryCount) cleanup.set(index, { frags: count, entries: [], tombstones: [] });",
      },
    ],
    note:
      "Cleanup also empties held dormant indexes beyond the staging range (LIST-08); leaving them wedges the List with residue the repair can never clear.",
  },
  {
    id: "list-repack-dropped-not-emptied",
    group: "A3-recovery",
    rows: ["REL-01.list-lowering-empties-dropped"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    for (let index = count; index < temporaryCount; index++) {",
        replace: "    for (let index = count; index < count; index++) {",
      },
    ],
    note:
      "A repack that lowers frags republishes each dropped fragment as a zero-element List carrying the new count (CORD-02 §8); never emptying the dropped range leaves stale memberships a later raise merges back in.",
  },
  {
    id: "list-repack-ignores-incomplete",
    group: "A3-recovery",
    rows: ["LIST-04.never-infer-missing"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find:
          '    if (!this.complete && this.versions.size) throw new Error("Cannot repack an incomplete Community List");',
        replace:
          '    if (false && !this.complete && this.versions.size) throw new Error("Cannot repack an incomplete Community List");',
      },
    ],
    note:
      "A repack needs the complete List (CORD-02 §8, a missing fragment is unseen, never empty); repacking a partial read silently drops every membership in the fragments it never read.",
  },
  {
    id: "list-repack-baseline-recheck-skipped",
    group: "A3-recovery",
    rows: ["LIST-04.baseline-recheck"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: '      if (this.seen.size !== baseline.size) throw new Error("Community List changed during signing");',
        replace: '      if (false) throw new Error("Community List changed during signing");',
      },
      {
        file: "client/community-list-sync.ts",
        find: "        if (this.seen.get(coordinate)?.id !== baseline.get(coordinate)) {",
        replace: "        if (false) {",
      },
    ],
    note:
      "Each stage re-checks the held fragments against the baseline taken before signing (D-06); skipping it publishes stale content over another device's fragment that arrived meanwhile.",
  },
  {
    id: "list-repack-drops-dormant-content",
    group: "A3-recovery",
    rows: ["LIST-04.dormant-merged"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: "    const merged = unionCommunityList(this.documentAll, local);",
        replace: "    const merged = unionCommunityList(this.document, local);",
      },
    ],
    note:
      "A repack merges content held at indexes above the declared count before emptying it (CORD-02 §8, D-20); planning from in-range fragments only destroys dormant memberships.",
  },
  {
    id: "list-repack-drops-tombstones",
    group: "A3-recovery",
    rows: ["LIST-08.no-revived-tombstones"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: "      ...tombstones.map((tombstone) => ({ tombstone })),",
        replace: "      ...[],",
      },
    ],
    note:
      "A repack carries every tombstone into the new List (CORD-02 §8, only a tombstone subtracts a membership); dropping them lets a dormant or duplicate copy revive a community that was left.",
  },
  {
    id: "list-assert-readable-disabled",
    group: "A3-recovery",
    rows: ["LIST-08.no-overwritten-unread"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find:
          '    if (this.seen.get(index)?.id !== this.fragments.get(index)?.id) throw new Error("Newest fragment is unread");',
        replace: '    if (false) throw new Error("Newest fragment is unread");',
      },
    ],
    note:
      "A locked or failed newest copy blocks overwriting that coordinate (D-05); a repack that overwrites an unread dormant copy destroys content the device never saw.",
  },
  {
    id: "list-repair-rearmed-by-automatic-trigger",
    group: "A3-recovery",
    rows: ["LIST-05.single-repair-owner"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: '    if (request() !== "quiet" || !explicit) return;',
        replace: '    if (request() !== "quiet") return;',
      },
    ],
    note:
      "Only an explicit save renews a spent repair (D-07); letting an automatic trigger renew it re-arms the repair from its own publications and retries without end.",
  },
  {
    id: "list-repair-retries-every-failure",
    group: "A3-recovery",
    rows: ["LIST-05.single-repair-owner"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "      if (retriesListSave(error)) throw new ReportedDutyFailure(error);",
        replace: "      throw new ReportedDutyFailure(error);",
      },
    ],
    note:
      "A refusal that cannot clear in this lifecycle (a declined signer, an unreadable record) settles after one report (D-07); retrying every failure spends the budget on a refusal that repeats.",
  },
  {
    id: "list-repair-without-consent",
    group: "A3-recovery",
    rows: ["LIST-05.repair-consent"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find: "    if (!this.options.autoRepair && !explicit) {",
        replace: "    if (false) {",
      },
    ],
    note:
      "Without autoSaveCommunityList the client only reports repack leftovers until an explicit save, join or leave (D-19); repairing on its own writes without the app's consent.",
  },
  {
    id: "list-repair-on-partial-or-locked",
    group: "A3-recovery",
    rows: ["LIST-05.repair-consent"],
    sites: [
      {
        file: "client/community-list-lane.ts",
        find:
          '    return !this.isClosed && sync.status.knowledge === "complete" && !sync.locked && sync.fragments.residue;',
        replace: "    return !this.isClosed && sync.fragments.residue;",
      },
    ],
    note:
      "A repair is due only on a complete, fully decrypted List (D-05); repairing a partial or locked List rewrites fragments it never read.",
  },
  {
    id: "list-publish-assert-current-skipped",
    group: "A3-recovery",
    rows: ["LIST-05.cancel-across-lifecycles"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "      this.assertReadable(index);\n      assertCurrent();\n      // D-31: evidence withdrawn",
        replace: "      this.assertReadable(index);\n      // D-31: evidence withdrawn",
      },
    ],
    note:
      "Every fragment re-checks that its caller is still current before it is published (D-30); a write parked on a signer or storage wait would otherwise publish after stop().",
  },
  {
    id: "list-repack-durable-wait-skipped",
    group: "A3-recovery",
    rows: ["LIST-05.durable-before-publish"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    await this.durable();\n    assertCurrent();\n    const baseline = this.baseline();",
        replace: "    await Promise.resolve();\n    assertCurrent();\n    const baseline = this.baseline();",
      },
    ],
    note:
      "A repack waits for the fragment record before the signer is asked for anything (D-08); without the wait an unstored record is discovered only after fragments were signed.",
  },
  {
    id: "list-publish-persist-wait-skipped",
    group: "A3-recovery",
    rows: ["LIST-05.durable-before-publish"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "      await this.stored(required);\n      if (this.seen.size !== baseline.size)",
        replace: "      await Promise.resolve();\n      if (this.seen.size !== baseline.size)",
      },
    ],
    note:
      "Before each fragment is published every earlier accepted fragment is stored (D-08); publishing ahead of the record lets a restart lose acknowledged stages.",
  },
  {
    id: "list-repack-persist-failure-swallowed",
    group: "A3-recovery",
    rows: ["LIST-05.durable-before-publish"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    if (required) return await this.durable();",
        replace: "    if (false && required) return await this.durable();",
      },
    ],
    note:
      "A repack stage stops when the record cannot be stored (D-08, WR-02); swallowing the failure lets the repack continue with stages no restart can repair from.",
  },
  {
    id: "list-scoped-write-persist-failure-blocks",
    group: "A3-recovery",
    rows: ["LIST-05.durable-before-publish"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    } catch {\n      // Reported by the persist callback",
        replace: "    } catch (error) {\n      throw error;\n      // Reported by the persist callback",
      },
    ],
    note:
      "A scoped write whose fragments fit still publishes when the record cannot be stored (WR-03); blocking it keeps a leave off every other device while storage fails.",
  },
  {
    id: "list-store-failure-reported-every-time",
    group: "A3-recovery",
    rows: ["LIST-05.durable-before-publish"],
    sites: [
      {
        file: "client/community-list-store.ts",
        find: "    if (slot.failing) return;",
        replace: "    if (false) return;",
      },
    ],
    note:
      "A failing storage streak is reported once until a write succeeds (D-08); reporting every failure floods the app.",
  },
  {
    id: "list-scoped-write-keeps-fields-above-zero",
    group: "A3-recovery",
    rows: ["LIST-06.no-fragment-fields-above-zero"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find:
          "    const own = retainExtensions ? previous!.document : {};\n    return { ...own, frags: this.count, entries, tombstones };",
        replace: "    return { ...previous?.document, ...merged, frags: this.count, entries, tombstones };",
      },
    ],
    note:
      "List-level fields belong to fragment 0 (CORD-02 §8, D-09); a scoped write to a higher fragment that keeps or adds them duplicates the List's fields across fragments.",
  },
  {
    id: "list-stranded-extension-keys-hidden",
    group: "A3-recovery",
    rows: ["LIST-06.stranded-to-zero"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: "    return Object.keys(extras).filter((key) => !zero || !(key in zero)).sort();",
        replace: "    return [];",
      },
    ],
    note:
      "A list-level field only a higher fragment carries is moved onto fragment 0 first (D-18); not reporting it strands the field where the next repack can drop it.",
  },
  {
    id: "list-wire-fragment-extras-dropped",
    group: "A3-recovery",
    rows: ["LIST-06.unknown-fields-survive", "REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "  return canonicalWire({\n    ...fragment,\n    entries,",
        replace: "  return canonicalWire({\n    frags: fragment.frags,\n    entries,",
      },
    ],
    note:
      "Unknown fields on the fragment itself round-trip verbatim (CORD-02 §8); serializing only the known fields destroys them on every republish.",
  },
  {
    id: "list-wire-entry-extras-dropped",
    group: "A3-recovery",
    rows: ["LIST-06.unknown-fields-survive", "REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "        ...extras,\n        community_id: key(entry.community_id, true),",
        replace: "        added_at: entry.added_at,\n        community_id: key(entry.community_id, true),",
      },
    ],
    note:
      "Unknown fields on every entry round-trip verbatim (CORD-02 §8); writing only the known entry fields destroys material a newer client wrote.",
  },
  {
    id: "list-wire-snapshot-extras-dropped",
    group: "A3-recovery",
    rows: ["LIST-06.unknown-fields-survive", "REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "  const out = { ...value };",
        replace:
          "  const out: Record<string, unknown> = {\n    community_id: value.community_id,\n    owner: value.owner,\n    owner_salt: value.owner_salt,\n    community_root: value.community_root,\n    control_pk: value.control_pk,\n    control_root: value.control_root,\n    root_epoch: value.root_epoch,\n    channels: value.channels,\n    relays: value.relays,\n    name: value.name,\n  };",
      },
    ],
    note:
      "Unknown fields on every seed and current snapshot round-trip verbatim (CORD-02 §8); copying only the known snapshot fields destroys a scope or key a newer client wrote.",
  },
  {
    id: "list-wire-channel-extras-dropped",
    group: "A3-recovery",
    rows: ["REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find:
          "    const result: Record<string, unknown> = { ...channel, id: key(channel.id, encode), key: key(channel.key, encode) };",
        replace:
          "    const result: Record<string, unknown> = { id: key(channel.id, encode), key: key(channel.key, encode), epoch: channel.epoch, name: channel.name };",
      },
    ],
    note:
      "Unknown fields on every channels entry round-trip verbatim (CORD-02 §8); the List is the only copy of a channel's keys, so a dropped field is lost on every device.",
  },
  {
    id: "list-wire-tombstone-extras-dropped",
    group: "A3-recovery",
    rows: ["REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "      return { ...t, community_id: key(t.community_id, true) };",
        replace: "      return { community_id: key(t.community_id, true), removed_at: t.removed_at };",
      },
    ],
    note:
      "Unknown fields on every tombstone round-trip verbatim (CORD-02 §8); writing only the known tombstone fields drops them.",
  },
  {
    id: "list-merge-entry-extras-dropped",
    group: "A3-recovery",
    rows: ["REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "    ...mergeOpaque(x, y),\n    community_id: x.community_id,",
        replace: "    community_id: x.community_id,",
      },
    ],
    note:
      "Merging two copies of an entry unions their unknown fields (CORD-02 §8); keeping neither loses what only one device wrote.",
  },
  {
    id: "list-merge-tombstone-extras-dropped",
    group: "A3-recovery",
    rows: ["REL-01.list-unknown-fields-codec"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "          ...mergeOpaque(prev, t),\n          community_id: t.community_id,",
        replace: "          community_id: t.community_id,",
      },
    ],
    note:
      "Merging two copies of a tombstone unions their unknown fields (CORD-02 §8); keeping neither loses what only one device wrote.",
  },
  {
    id: "list-memberships-runtime-export",
    group: "A3-recovery",
    rows: ["LIST-07.memberships-api"],
    sites: [
      {
        file: "client/index.ts",
        find: 'export type { ConcordMemberships } from "./community-list-memberships.ts";',
        replace:
          'export type { ConcordMemberships } from "./community-list-memberships.ts";\nexport const ConcordMemberships = undefined;',
      },
    ],
    note:
      "The aggregate read surface is a type only, with no new runtime export (D-13, D-14); a runtime symbol beside it breaks the pinned export shape.",
  },
  {
    id: "list-legacy-import-skipped",
    group: "A3-recovery",
    rows: ["LIST-07.legacy-read-only"],
    sites: [
      {
        file: "client/client.ts",
        find: "          const staged = mergeCommunities(this.list, communities, true);",
        replace: "          const staged = this.list;",
      },
    ],
    note:
      "A legacy kind-13302 list is still read and imported into the document (D-15); discarding the imported memberships strands those only ever saved in the retired format.",
  },
  {
    id: "list-publishes-legacy-kind",
    group: "A3-recovery",
    rows: ["LIST-07.legacy-read-only"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: '      kind: COMMUNITY_LIST_FRAGMENT_KIND,\n      tags: [["d", String(index)]],\n      content,',
        replace: '      kind: 13302,\n      tags: [["d", String(index)]],\n      content,',
      },
    ],
    note:
      "The client publishes only kind-33302 fragments and never a retired kind-13302 list (D-15); publishing the legacy kind dual-writes the retired format.",
  },
  {
    id: "list-wire-keys-not-reencoded",
    group: "A3-recovery",
    rows: ["REL-01.list-base64url-named-fields"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "    return base64urlnopad.encode(hexToBytes(value));",
        replace: "    return value;",
      },
    ],
    note:
      "Every named 32-byte value is re-encoded as unpadded base64url on every serialization (CORD-02 §8); writing the internal hex spelling leaves one value with two spellings.",
  },
  {
    id: "list-wire-channel-keys-not-reencoded",
    group: "A3-recovery",
    rows: ["REL-01.list-base64url-named-fields"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find:
          "    const result: Record<string, unknown> = { ...channel, id: key(channel.id, encode), key: key(channel.key, encode) };",
        replace: "    const result: Record<string, unknown> = { ...channel };",
      },
    ],
    note:
      "The base64url rule holds at any depth, including each channels entry (CORD-02 §8); skipping the channel id and key leaves hex inside the snapshot.",
  },
  {
    id: "list-wire-embedded-keeps-community-id",
    group: "A3-recovery",
    rows: ["REL-01.list-snapshot-omits-community-id"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "  if (embedded) delete out.community_id;\n  else out.community_id = key(out.community_id, encode);",
        replace: "  out.community_id = key(out.community_id, encode);",
      },
    ],
    note:
      "A snapshot embedded in an entry carries no community_id (CORD-02 §8, required); keeping it writes a second spelling of the entry's identity into every snapshot.",
  },
  {
    id: "list-wire-seed-always-written",
    group: "A3-recovery",
    rows: ["REL-01.list-seed-absent-when-equal"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "        ...(canonicalWire(seed) === canonicalWire(current) ? {} : { seed }),",
        replace: "        seed,",
      },
    ],
    note:
      "seed is absent whenever it equals current (CORD-02 §8, required); always writing it makes two devices holding identical state serialize different bytes.",
  },
  {
    id: "list-wire-seed-name-not-rewritten",
    group: "A3-recovery",
    rows: ["REL-01.list-seed-cosmetics-from-current"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "      seed.name = current.name;",
        replace: "      seed.name = seed.name;",
      },
    ],
    note:
      "seed's name is overwritten from current on every serialization (CORD-02 §8); a stale seed name forks the snapshots after one rename.",
  },
  {
    id: "list-wire-seed-relays-not-rewritten",
    group: "A3-recovery",
    rows: ["REL-01.list-seed-cosmetics-from-current"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "      seed.relays = current.relays;",
        replace: "      seed.relays = seed.relays;",
      },
    ],
    note:
      "seed's relays are overwritten from current on every serialization (CORD-02 §8); stale seed relays fork the snapshots.",
  },
  {
    id: "list-wire-seed-channel-names-not-rewritten",
    group: "A3-recovery",
    rows: ["REL-01.list-seed-cosmetics-from-current"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find: "        return latest ? { ...channel, name: latest.name } : channel;",
        replace: "        return channel;",
      },
    ],
    note:
      "Each seed channel's name is overwritten from current on every serialization (CORD-02 §8); a stale channel name forks the snapshots.",
  },
  {
    id: "list-wire-local-fields-written",
    group: "A3-recovery",
    rows: ["REL-01.list-snapshot-membership-subset"],
    sites: [
      {
        file: "helpers/community-list-wire.ts",
        find:
          '  for (const field of ["held_roots", "prev_root", "refounder", "icon", "expires_at", "creator_npub", "label"]) {',
        replace: "  for (const field of [] as string[]) {",
      },
    ],
    note:
      "A snapshot is the membership subset only, never the icon, link fields or local history (CORD-02 §8); writing them spends bytes on every device and leaks invite attribution.",
  },
  {
    id: "list-merge-current-keeps-lower-epoch",
    group: "A3-recovery",
    rows: ["REL-01.list-snapshot-merge-order"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "  if (a.root_epoch !== b.root_epoch) return a.root_epoch > b.root_epoch ? a : b;",
        replace: "  if (a.root_epoch !== b.root_epoch) return a.root_epoch < b.root_epoch ? a : b;",
      },
    ],
    note:
      "current keeps the higher epoch (CORD-02 §8); keeping the lower one makes a fresh device rebuild an old epoch.",
  },
  {
    id: "list-merge-seed-keeps-higher-epoch",
    group: "A3-recovery",
    rows: ["REL-01.list-snapshot-merge-order"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "  if (a.root_epoch !== b.root_epoch) return a.root_epoch < b.root_epoch ? a : b;",
        replace: "  if (a.root_epoch !== b.root_epoch) return a.root_epoch > b.root_epoch ? a : b;",
      },
    ],
    note:
      "seed keeps the lower epoch, the only backfill anchor (CORD-02 §8); moving it forward costs a member their own history.",
  },
  {
    id: "list-merge-current-tie-highest-bytes",
    group: "A3-recovery",
    rows: ["REL-01.list-snapshot-merge-order"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find:
          "  if (a.root_epoch !== b.root_epoch) return a.root_epoch > b.root_epoch ? a : b;\n  const selected = compareSnapshot(a, b) <= 0 ? a : b;",
        replace:
          "  if (a.root_epoch !== b.root_epoch) return a.root_epoch > b.root_epoch ? a : b;\n  const selected = compareSnapshot(a, b) >= 0 ? a : b;",
      },
    ],
    note:
      "An epoch tie breaks on the lowest canonical bytes of the whole snapshot (CORD-02 §8); the highest makes devices disagree with every other client.",
  },
  {
    id: "list-merge-seed-tie-highest-bytes",
    group: "A3-recovery",
    rows: ["REL-01.list-snapshot-merge-order"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find:
          "  if (a.root_epoch !== b.root_epoch) return a.root_epoch < b.root_epoch ? a : b;\n  const selected = compareSnapshot(a, b) <= 0 ? a : b;",
        replace:
          "  if (a.root_epoch !== b.root_epoch) return a.root_epoch < b.root_epoch ? a : b;\n  const selected = compareSnapshot(a, b) >= 0 ? a : b;",
      },
    ],
    note:
      "An epoch tie of seeds breaks on the lowest canonical bytes (CORD-02 §8); the highest makes devices disagree about the backfill anchor.",
  },
  {
    id: "list-covered-entry-written",
    group: "A3-recovery",
    rows: ["REL-01.list-tombstone-wins-omit-entry"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "  return removed === undefined || added > removed;",
        replace: "  return removed === undefined || added >= removed;",
      },
    ],
    note:
      "An entry whose added_at does not exceed removed_at is omitted (CORD-02 §8); treating a tie as live keeps the retired entry, and its keys, on the wire.",
  },
  {
    id: "list-tombstone-keeps-older-removal",
    group: "A3-recovery",
    rows: ["REL-01.list-liveness-newest-wins"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "        removed_at: Math.max(prev.removed_at, t.removed_at),",
        replace: "        removed_at: Math.min(prev.removed_at, t.removed_at),",
      },
    ],
    note:
      "One tombstone per Community keeps the later removed_at (CORD-02 §8); keeping the earlier one lets an older add outrank the leave.",
  },
  {
    id: "list-rejoin-never-resurrects",
    group: "A3-recovery",
    rows: ["REL-01.list-liveness-newest-wins"],
    sites: [
      {
        file: "helpers/community-list.ts",
        find: "  return removed === undefined || added > removed;",
        replace: "  return removed === undefined;",
      },
    ],
    note:
      "The newest of added_at and removed_at wins, so a re-join resurrects a membership (CORD-02 §8); a tombstone that always wins makes leaving permanent for the member too.",
  },
  {
    id: "list-count-ties-resolve-smaller",
    group: "A3-recovery",
    rows: ["REL-01.list-count-governs-newest-larger-wins"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: "      } else if (version.created_at === age) count = Math.max(count, version.document.frags);",
        replace: "      } else if (version.created_at === age) count = Math.min(count, version.document.frags);",
      },
    ],
    note:
      "At equal age the larger frags wins (CORD-02 §8); the smaller pushes every fragment past it out of range and live memberships go dormant.",
  },
  {
    id: "list-count-oldest-governs",
    group: "A3-recovery",
    rows: ["REL-01.list-count-governs-newest-larger-wins"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: "      if (version.created_at > age) {",
        replace: "      if (version.created_at < age) {",
      },
    ],
    note:
      "The count in the newest fragment seen governs (CORD-02 §8); letting an older declaration win ignores a repack.",
  },
  {
    id: "list-scoped-write-needs-complete-list",
    group: "A3-recovery",
    rows: ["REL-01.list-scoped-write-one-fragment"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "      const indexes = new Set<number>();",
        replace: "      if (!this.fragments.complete) return;\n      const indexes = new Set<number>();",
      },
    ],
    note:
      "A scoped write needs only the fragment holding the membership (CORD-02 §8); requiring the complete List lets one stranded fragment block every join and leave.",
  },
  {
    id: "list-event-overflow-ignored",
    group: "A3-recovery",
    rows: ["REL-01.list-event-ceiling"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    return bytes > COMMUNITY_LIST_EVENT_MAX_BYTES && (!previous || bytes >= eventSize(previous));",
        replace: "    return false;",
      },
    ],
    note:
      "A fragment whose encoded event would exceed 65,536 bytes needs a repack that starts a new fragment (CORD-02 §8); never detecting the overflow publishes an event relays refuse.",
  },
  {
    id: "list-event-pack-and-verify-removed",
    group: "A3-recovery",
    rows: ["REL-01.list-event-ceiling"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: "    target: number = 56 * 1024,",
        replace: "    target: number = 1e9,",
      },
      {
        file: "client/community-list-sync.ts",
        find:
          '        if (eventSize(event) > COMMUNITY_LIST_EVENT_MAX_BYTES) {\n          throw new Error("Community List fragment exceeds event ceiling");\n        }',
        replace: "",
      },
    ],
    note:
      "The fully encoded event is packed under the ceiling and verified before publishing (CORD-02 §8); with neither the target nor the check a repack writes one oversized fragment.",
  },
  {
    id: "list-repack-sheds-unknown-fields",
    group: "A3-recovery",
    rows: ["REL-01.list-no-shed-for-ceiling"],
    sites: [
      {
        file: "client/community-list-fragments.ts",
        find: '          entries: "entry" in record ? [...base.entries, record.entry] : base.entries,',
        replace:
          '          entries: "entry" in record\n            ? [...base.entries, {\n              community_id: record.entry.community_id,\n              current: record.entry.current,\n              seed: record.entry.seed,\n              added_at: record.entry.added_at,\n            }]\n            : base.entries,',
      },
    ],
    note:
      "A client never sheds unknown fields to fit the ceiling, it starts a new fragment (CORD-02 §8); trimming entries to their known fields destroys keys a newer client wrote.",
  },
  {
    id: "list-shrink-exemption-removed",
    group: "A3-recovery",
    rows: ["REL-01.list-shrink-exempt"],
    sites: [
      {
        file: "client/community-list-sync.ts",
        find: "    return bytes > COMMUNITY_LIST_EVENT_MAX_BYTES && (!previous || bytes >= eventSize(previous));",
        replace: "    return bytes > COMMUNITY_LIST_EVENT_MAX_BYTES;",
      },
    ],
    note:
      "A write that strictly shrinks an oversized fragment is exempt from the ceiling (CORD-02 §8); without the exemption a member already over the ceiling cannot leave in place.",
  },
  // A5 (plan 06-09): pins, CORD-04 §7. Sweep group A5; each entry names the guard its note describes.
  {
    id: "pin-projection-ignores-local-edits",
    group: "A5",
    rows: ["PIN-01.apply-newest-edit"],
    sites: [
      {
        file: "helpers/pin-projection.ts",
        find: "const applied = newestValidEdit(verified.rumor, [bundled, local].filter((e) => e !== undefined), {",
        replace:
          "const applied = newestValidEdit(verified.rumor, [bundled, local && undefined].filter((e) => e !== undefined), {",
      },
    ],
    note:
      "A reader applies the newest author-valid Edit it knows, bundled or local (CORD-04 §7 Edits); choosing from the bundled Edit alone leaves a newer local Edit unapplied and the pin unmarked.",
  },
  {
    id: "pin-projection-ignores-bundled-edit",
    group: "A5",
    rows: ["PIN-10.fresh-post-rotation-reader"],
    sites: [
      {
        file: "helpers/pin-projection.ts",
        find: "const applied = newestValidEdit(verified.rumor, [bundled, local].filter((e) => e !== undefined), {",
        replace: "const applied = newestValidEdit(verified.rumor, [local].filter((e) => e !== undefined), {",
      },
    ],
    note:
      "A fresh reader holds none of the Chat plane, so the Edit bundled in the entry is the only Edit it can know (CORD-04 §7 Edits); ignoring the bundle shows such a reader the original text under a proof that presents it as current.",
  },
  {
    id: "pin-edit-chooser-takes-oldest",
    group: "A5",
    rows: ["PIN-01.apply-newest-edit", "PIN-01.never-older-edit"],
    sites: [
      {
        file: "helpers/edit.ts",
        find: "if (best === undefined || ms > bestMs || (ms === bestMs && id < best.id)) {",
        replace: "if (best === undefined || ms < bestMs || (ms === bestMs && id < best.id)) {",
      },
    ],
    note:
      "newestValidEdit orders Edits by full millisecond time, newest first (CORD-02 §4); preferring the lowest time shows and bundles the oldest Edit and lets an older local Edit replace the newer bundled one.",
  },
  {
    id: "pin-edit-deletions-ignored",
    group: "A5",
    rows: ["PIN-01.deleted-edit-ignored", "PIN-01.duplicate-entries-newest-bundle", "PIN-04.never-bundle-deleted-edit"],
    sites: [
      {
        file: "helpers/edit.ts",
        find:
          "if (options.deletions && isAuthorDeleted({ id, pubkey: candidate.pubkey }, options.deletions)) continue;",
        replace:
          "if (false && options.deletions && isAuthorDeleted({ id, pubkey: candidate.pubkey }, options.deletions)) continue;",
      },
    ],
    note:
      "An Edit its own author deleted is never chosen (library rule D-31, self-erasure outranks curation, CORD-04 §7); skipping the deletion check shows, bundles and prefers a retracted Edit.",
  },
  {
    id: "pin-deletion-matches-any-author",
    group: "A5",
    rows: ["PIN-02.hide-self-deleted", "PIN-01.deleted-edit-ignored"],
    sites: [
      {
        file: "helpers/author-deletion.ts",
        find: "if (!d || d.kind !== 5 || d.pubkey !== target.pubkey || !Array.isArray(d.tags)) continue;",
        replace: "if (!d || d.kind !== 5 || !Array.isArray(d.tags)) continue;",
      },
    ],
    note:
      "Only the proven author's own deletion unpins a message or retracts an Edit (CORD-04 §7 Interaction with deletion); accepting a delete by any pubkey lets another member erase a pin.",
  },
  {
    id: "pin-self-deletion-never-hides",
    group: "A5",
    rows: ["PIN-02.hide-self-deleted"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "  return isAuthorDeleted(pin.rumor, rumors);\n}",
        replace: "  return false && isAuthorDeleted(pin.rumor, rumors);\n}",
      },
    ],
    note:
      "A reader holding the author's delete hides the pinned entry immediately (CORD-04 §7 Interaction with deletion); never recognising the deletion leaves the deleted message pinned until an edition removes it.",
  },
  {
    id: "pin-collapse-last-copy-wins",
    group: "A5",
    rows: ["PIN-01.duplicate-entries-newest-bundle", "PIN-04.duplicate-entries-never-regress"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "      ...(wins ? { entry, pin } : { entry: kept.entry, pin: kept.pin }),",
        replace: "      ...(wins || true ? { entry, pin } : { entry: kept.entry, pin: kept.pin }),",
      },
    ],
    note:
      "A message listed more than once resolves to the copy whose bundled Edit is newest (library rule D-32); letting the last copy win shows and republishes an older bundled Edit.",
  },
  {
    id: "pin-collapse-stops-at-invalid-entry",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    const pin = verify(entry, channelId);\n    if (!pin) continue;",
        replace: "    const pin = verify(entry, channelId);\n    if (!pin) break;",
      },
    ],
    note:
      "An entry that fails verification is dropped alone and the rest of the list folds normally (CORD-04 §7 proof bundle); stopping at the first invalid entry hides every entry after it.",
  },
  {
    id: "pin-model-ignores-edits",
    group: "A5",
    rows: ["PIN-09.reactive-pins", "PIN-01.apply-newest-edit"],
    sites: [
      {
        file: "models/pins.ts",
        find: "store.timeline([{ kinds: [5, EDIT_KIND] }], { batchWindow: false }),\n      list,",
        replace: "store.timeline([{ kinds: [5, EDIT_KIND].slice(0, 1) }], { batchWindow: false }),\n      list,",
      },
    ],
    note:
      "pins$ re-emits when an Edit arrives; a model that watches deletions only never refreshes the text a pin shows.",
  },
  {
    id: "pin-projection-shows-banned",
    group: "A5",
    rows: ["REL-01.pin-moderation-suppression"],
    sites: [
      {
        file: "helpers/pin-projection.ts",
        find: "    if (inputs.isBanned?.(verified.rumor.pubkey) && !inputs.showBanned) continue;",
        replace: "    if (false && inputs.isBanned?.(verified.rumor.pubkey) && !inputs.showBanned) continue;",
      },
    ],
    note:
      "A pin whose proven author is banned is hidden by default (CORD-04 §7 moderation suppression); skipping the projection check lists the banned author's pin in every reader.",
  },
  {
    id: "pin-model-show-banned-dropped",
    group: "A5",
    rows: ["REL-01.pin-moderation-suppression"],
    sites: [
      {
        file: "models/pins.ts",
        find: "            showBanned: options.showBanned,",
        replace: "            showBanned: options.showBanned && false,",
      },
    ],
    note:
      "showBanned must reach the projection; a model that drops it hides a banned author's pin from the reader who opted in to see it.",
  },
  {
    id: "pin-model-ignores-bans",
    group: "A5",
    rows: ["REL-01.pin-moderation-suppression"],
    sites: [
      {
        file: "models/pins.ts",
        find: "            isBanned: (pubkey) => bans.has(pubkey),",
        replace: "            isBanned: (pubkey) => bans.has(pubkey) && false,",
      },
    ],
    note:
      "The pins model hides a banned author's pin and restores it on unban from the live ban set; a model that never consults the set keeps the banned author's pin listed.",
  },
  {
    id: "pin-reader-ignores-bans-oneshot",
    group: "A5",
    rows: ["REL-01.pin-moderation-suppression"],
    sites: [
      {
        file: "client/pins.ts",
        find: "      isBanned: (pubkey) => state.banlist.has(pubkey),",
        replace: "      isBanned: (pubkey) => state.banlist.has(pubkey) && false,",
      },
    ],
    note:
      "The one-shot pins() applies the same suppression as pins$; a read that ignores the Banlist lists a banned author's pin although the reactive reader hides it.",
  },
  {
    id: "pin-model-no-expiry-boundary",
    group: "A5",
    rows: ["DEC-01.expired-hidden-reader-side"],
    sites: [
      {
        file: "models/pins.ts",
        find: "            delay: upcoming.length\n",
        replace: "            delay: upcoming.length && false\n",
      },
    ],
    note:
      "An expiring pin disappears at its expiry without polling or new traffic (CORD-08 §3, DEC-01); without the boundary timer the model keeps showing it until something else re-emits.",
  },
  {
    id: "pin-projection-shows-expired",
    group: "A5",
    rows: ["DEC-01.expired-hidden-reader-side", "PIN-01.never-superseded-text"],
    sites: [
      {
        file: "helpers/pin-projection.ts",
        find: "if (expired && !inputs.showExpired) continue;",
        replace: "if (false && expired && !inputs.showExpired) continue;",
      },
    ],
    note:
      "An expired pin is hidden by default and exposed only under showExpired (DEC-01); never hiding it shows expired words as current.",
  },
  {
    id: "pin-expired-edit-ignored-for-expiry",
    group: "A5",
    rows: ["PIN-01.never-superseded-text"],
    sites: [
      {
        file: "helpers/pin-projection.ts",
        find: "      (isRumorExpired(verified.rumor, now) || (applied && isRumorExpired(applied, now)));",
        replace: "      (isRumorExpired(verified.rumor, now));",
      },
    ],
    note:
      "When the newest known Edit is expired the whole pin is expired, so older text is never presented as current (library rule D-11); judging only the original shows the original or an older Edit instead.",
  },
  {
    id: "pin-expiry-counts-as-omission",
    group: "A5",
    rows: ["DEC-01.no-publication-on-expiry"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    if (isSelfDeleted(pin, input.rumors)) {\n      omitted.add(id);",
        replace:
          "    if (isSelfDeleted(pin, input.rumors) || (pin.expiresAt !== undefined && pin.expiresAt <= Math.floor(Date.now() / 1000))) {\n      omitted.add(id);",
      },
    ],
    note:
      "Expiry is reader-side only and never changes what an upkeep rewrite carries (CORD-08 §3, DEC-01); treating an expired entry as omitted publishes an edition because of expiry.",
  },
  {
    id: "pin-first-write-absence-not-proved",
    group: "A5",
    rows: ["DEC-02.first-pin-after-proven-absence"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "  if (\n    input.displayHeads?.has(input.eid) ||",
        replace: "  if (\n    false &&\n    (input.displayHeads?.has(input.eid) ||",
      },
      {
        file: "helpers/pin-upkeep.ts",
        find: "    input.retained(input.eid)\n  ) {",
        replace: "    input.retained(input.eid))\n  ) {",
      },
    ],
    note:
      "The first Pin List is written only after proven absence (CORD-04 §1, §7): no display head, pending chain evidence or retained edition that could still verify; dropping that check lets a client write version 1 over a list it has not synced.",
  },
  {
    id: "pin-first-write-ignores-sync-phase",
    group: "A5",
    rows: ["DEC-02.first-pin-after-proven-absence"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: '  if (input.phase !== "live") return { ready: false, reason: "not-synced" };',
        replace: '  if (input.phase !== "live" && false) return { ready: false, reason: "not-synced" };',
      },
    ],
    note:
      "Proven absence needs a live community whose Control reads completed; planning a first write before that treats an unsynced fold as an empty one.",
  },
  {
    id: "pin-unverifiable-editions-block-first-write",
    group: "A5",
    rows: ["DEC-02.first-pin-after-proven-absence"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find:
          '    if (edition.author === owner) return true;\n    const tag = edition.rumor.tags.find((t) => t[0] === "vac");\n    if (tag?.length !== 4) return false;',
        replace:
          '    if (edition.author === owner) return true;\n    const tag = edition.rumor.tags.find((t) => t[0] === "vac");\n    if (tag?.length !== 4) return true;',
      },
    ],
    note:
      "An edition that can never verify is no evidence the list exists (D-33); counting it as one lets an injected edition block the first pin forever.",
  },
  {
    id: "pin-standing-rejected-edition-blocks-first-write",
    group: "A5",
    rows: ["DEC-02.first-pin-after-proven-absence"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    return !vacVerifier(state, PERM.PIN_MESSAGES)(edition.author, [eid, version, hash]);",
        replace: "    return false && !vacVerifier(state, PERM.PIN_MESSAGES)(edition.author, [eid, version, hash]);",
      },
    ],
    note:
      "An edition whose author current standing rejects (banned or demoted) blocks nothing, and the new head chains over it (D-34); treating it as live evidence freezes a channel's pins after its curator is banned.",
  },
  {
    id: "pin-setpins-head-unguarded",
    group: "A5",
    rows: ["DEC-02.setpins-head-guard"],
    sites: [
      {
        file: "client/pins.ts",
        find: "      expectedHead: readiness.head?.hash ?? null,",
        replace: "      expectedHead: undefined,",
      },
    ],
    note:
      "A head that moves while setPins signs is never overwritten (CORD-04 §1, §7 replace-entire); without the expected head the stale list replaces the newer one.",
  },
  {
    id: "pin-duty-key-drops-head",
    group: "A5",
    rows: ["PIN-03.replay-rearms", "PIN-10.replayed-heads", "PIN-10.collision-re-heal"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find: "      key: `pin-upkeep:${channelId}:${headHash}`,",
        replace: "      key: `pin-upkeep:${channelId}`,",
      },
    ],
    note:
      "One head publishes at most once and a new or replayed head re-arms upkeep (CORD-04 §7 Interaction with deletion); a duty key without the head hash answers quiet for a sibling or replayed head and the obligation never re-arms.",
  },
  {
    id: "pin-rate-limit-never-defers",
    group: "A5",
    rows: ["PIN-03.no-storm"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find: "    if (stamps.length < this.rateLimit.max) return 0;",
        replace: "    if (stamps.length < this.rateLimit.max || true) return 0;",
      },
    ],
    note:
      "Upkeep is bounded so a hostile holder replaying heads cannot cause a publication storm; never deferring past the per-channel limit removes the bound.",
  },
  {
    id: "pin-upkeep-opt-out-ignored",
    group: "A5",
    rows: ["PIN-03.opt-out"],
    sites: [
      {
        file: "client/pins.ts",
        find: "    if (!host.upkeep) return;",
        replace: "    if (!host.upkeep && false) return;",
      },
    ],
    note:
      "pinUpkeep false on a community or the client publishes no automatic Pin List edition; building the maintainer regardless publishes one.",
  },
  {
    id: "pin-pinner-waits-witness-delay",
    group: "A5",
    rows: ["PIN-04.coalesced", "PIN-03.self-delete-omission"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find: "    const witnessDelayMs = own || rotating ? 0 :",
        replace: "    const witnessDelayMs = (own && false) || rotating ? 0 :",
      },
    ],
    note:
      "The pinner acts at once and every other holder waits a bounded random delay (CORD-04 §7 Interaction with deletion, Edits); treating the pinner as a witness delays its own omission and refresh.",
  },
  {
    id: "pin-refresh-attaches-unproven-edit",
    group: "A5",
    rows: ["PIN-04.no-other-form"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    if (proof) return { ...entry, edit: proof };",
        replace: "    if (proof || true) return { ...entry, edit: proof };",
      },
    ],
    note:
      "A refresh replaces only the entry's edit bundle and only with a verified proof of the Edit (CORD-04 §7 Edits: corrected text MUST NOT be republished in any other form); attaching a missing proof drops the existing bundle.",
  },
  {
    id: "pin-refresh-regresses-to-older-edit",
    group: "A5",
    rows: ["PIN-04.never-regress"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "      pin.edit &&\n      newestValidEdit(pin.rumor, [pin.edit, candidate]",
        replace: "      pin.edit && false &&\n      newestValidEdit(pin.rumor, [pin.edit, candidate]",
      },
    ],
    note:
      "A refresh never attaches an Edit that is not strictly newer than the bundled one (CORD-04 §7 Edits: a republish with an older Edit silently reverts the entry); dropping the comparison bundles older text.",
  },
  {
    id: "pin-refresh-ignores-expired-newest-edit",
    group: "A5",
    rows: ["PIN-04.never-regress"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "  if (!current || (input.now !== undefined && isRumorExpired(current, input.now))) return fallback;",
        replace:
          "  if (!current || (input.now !== undefined && false && isRumorExpired(current, input.now))) return fallback;",
      },
    ],
    note:
      "When the newest Edit is expired nothing is bundled, so neither expired nor superseded text is published as current (library rule D-11); skipping the check bundles an older unexpired Edit.",
  },
  {
    id: "pin-upkeep-keeps-retracted-edit-bundle",
    group: "A5",
    rows: ["PIN-04.never-bundle-deleted-edit"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "  const fallback = retracted ? withoutEdit(entry) : undefined;",
        replace: "  const fallback = retracted && false ? withoutEdit(entry) : undefined;",
      },
    ],
    note:
      "Automatic upkeep replaces or removes a bundled Edit its author deleted (library rule D-31); keeping it republishes a retracted Edit's proof.",
  },
  {
    id: "pin-setpins-republishes-retracted-edit",
    group: "A5",
    rows: ["PIN-04.never-bundle-deleted-edit"],
    sites: [
      {
        file: "client/pins.ts",
        find: "        pin.edit !== undefined && isAuthorDeleted(pin.edit, rumors) ? withoutEdit(entry) : entry",
        replace:
          "        pin.edit !== undefined && isAuthorDeleted(pin.edit, rumors) && false ? withoutEdit(entry) : entry",
      },
    ],
    note:
      "setPins publishes an entry whose bundled Edit its author deleted without that bundle (library rule D-31); publishing the entry as given republishes the retracted Edit.",
  },
  {
    id: "pin-edit-seals-trust-embedded-id",
    group: "A5",
    rows: ["PIN-05.seal-from-retained-wraps"],
    sites: [
      {
        file: "client/pin-edit-seals.ts",
        find:
          "      id = getEventHash(rumor);\n    } catch {\n      return; // Malformed relay input is skipped, never thrown.",
        replace:
          "      id = rumor.id;\n    } catch {\n      return; // Malformed relay input is skipped, never thrown.",
      },
    ],
    note:
      "Edit seals are indexed by the recomputed rumor id, never an embedded one (CORD-04 §7 proof bundle step 5); trusting the embedded id lets a forged id bind an Edit to the wrong seal.",
  },
  {
    id: "pin-edit-seals-never-noted",
    group: "A5",
    rows: ["PIN-05.seal-from-retained-wraps", "PIN-04.refresh-newest-provable"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find: "    if (!this.disposed) this.seals.note(info, decoded, this.host.duties().clock.now() / 1000);",
        replace:
          "    if (false && !this.disposed) this.seals.note(info, decoded, this.host.duties().clock.now() / 1000);",
      },
    ],
    note:
      "The seal an Edit proof needs is recorded at the route funnel and rebuilt by sync after a restart (CORD-04 §7 Edits); never recording it leaves nothing to prove an Edit with.",
  },
  {
    id: "pin-edit-seals-evict-by-arrival",
    group: "A5",
    rows: ["PIN-05.newest-seal-retained"],
    sites: [
      {
        file: "client/pin-edit-seals.ts",
        find: "    if (victim) this.drop(channelId, victim.id);\n  }",
        replace:
          "    const first = records.keys().next().value;\n    if (victim && first !== undefined) this.drop(channelId, first);\n  }",
      },
    ],
    note:
      "Over the per-channel cap the oldest Edit by rumor order goes, not the first to arrive; evicting by arrival drops the newest provable Edit of a busy channel.",
  },
  {
    id: "pin-edit-seals-evict-newest-of-original",
    group: "A5",
    rows: ["PIN-05.newest-seal-retained"],
    sites: [
      {
        file: "client/pin-edit-seals.ts",
        find:
          "if (!victim || (victimIsNewest && !isNewest) || (victimIsNewest === isNewest && isOlder(record, victim))) {",
        replace: "if (!victim || (victimIsNewest === isNewest && isOlder(record, victim))) {",
      },
    ],
    note:
      "A superseded Edit is evicted before the newest Edit of its message, so the newest provable Edit survives; pure rumor-order eviction drops the oldest Edit even when it is the only one of its message.",
  },
  {
    id: "pin-missing-epoch-key-reads-empty",
    group: "A5",
    rows: ["PIN-06.unavailable-old-epoch", "PIN-07.unreadable-never-rebuilt"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "      if (!key) return { available: false };",
        replace: "      if (!key) return { available: true, entries: [] };",
      },
    ],
    note:
      "A list sealed under an epoch key the reader never held is unavailable, not an empty list (CORD-04 §7); reading it as empty invites a writer to rebuild the list from nothing.",
  },
  {
    id: "pin-write-readiness-ignores-availability",
    group: "A5",
    rows: ["PIN-07.no-write-from-unreadable-list"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    return head.vsk === VSK.PINS && input.listAvailable",
        replace: "    return head.vsk === VSK.PINS",
      },
    ],
    note:
      "A writer MUST NOT build an edition from a list it could not read (CORD-04 §7); ignoring availability lets an unreadable head be replaced by a list built from its empty view.",
  },
  {
    id: "pin-rewrite-over-ceiling-published",
    group: "A5",
    rows: ["PIN-06.over-cap-terminal"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          '  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) {\n    throw new Error("Pin List exceeds content ceiling");',
        replace:
          '  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES * 1_000) {\n    throw new Error("Pin List exceeds content ceiling");',
      },
    ],
    note:
      "A rewrite over the 32,768-byte content ceiling is reported once and publishes nothing (CORD-04 §7 Limits); without the encoder ceiling an over-cap edition is published, which readers then treat as an empty list.",
  },
  {
    id: "pin-sealed-head-reformed-public",
    group: "A5",
    rows: ["PIN-07.no-public-reform-by-automation", "PIN-07.no-mechanical-conversion"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: '  if (!input.channelPrivate && input.headForm.form === "sealed") {',
        replace: "  if (false) {",
      },
    ],
    note:
      "On a private to public conversion the list MUST NOT be mechanically re-formed (CORD-04 §7); without the block a sealed head on a public channel is rewritten as a public list and republishes private-era pins to everyone.",
  },
  {
    id: "pin-duty-eligible-ignores-write-authority",
    group: "A5",
    rows: ["PIN-08.stops-on-authority-loss", "PIN-10.demotion"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find:
          '      !this.disposed && this.host.phase() === "live" && this.host.canWrite() &&\n      this.host.state().channels.some',
        replace: '      !this.disposed && this.host.phase() === "live" &&\n      this.host.state().channels.some',
      },
    ],
    note:
      "Pin upkeep stops when the holder is demoted (CORD-04 §5, §7); an armed duty that ignores write authority publishes after the demotion.",
  },
  {
    id: "pin-publication-ignores-authority-loss",
    group: "A5",
    rows: ["PIN-08.stops-on-authority-loss", "PIN-10.demotion"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find:
          "        await this.host.publishPinList(channelId, content, headHash, rewrite.stage, () => context.assertAlive());",
        replace: "        await this.host.publishPinList(channelId, content, headHash, rewrite.stage, () => {});",
      },
    ],
    note:
      "A duty already publishing re-checks that it is still alive before the edition goes out; a no-op check publishes after a mid-publication demotion, disposal or dissolution.",
  },
  {
    id: "pin-duty-for-deleted-channel",
    group: "A5",
    rows: ["PIN-10.deleted-channels"],
    sites: [
      {
        file: "client/pin-maintainer.ts",
        find:
          "      this.host.state().channels.some((value) => value.channel_id === channelId) &&\n      this.host.headHash(channelId) === headHash;",
        replace: "      this.host.headHash(channelId) === headHash;",
      },
      {
        file: "client/pin-maintainer.ts",
        find: "    const plan = channel\n      ? planPinUpkeep({",
        replace: "    const plan = true\n      ? planPinUpkeep({",
      },
      {
        file: "client/pin-maintainer.ts",
        find: "        channelPrivate: channel.private,",
        replace: "        channelPrivate: channel?.private ?? false,",
      },
    ],
    note:
      "A channel deleted while upkeep is armed is not maintained; ignoring the folded channel list keeps a duty alive for a channel that no longer exists.",
  },
  {
    id: "pin-dissolved-self-scrub-not-retained",
    group: "A5",
    rows: ["PIN-08.dissolved-self-scrub-only", "PIN-10.post-dissolution"],
    sites: [
      {
        file: "client/community.ts",
        find: "    } else if (this.sealed && !await this.pinning.isHistoricalSelfDelete(info, decoded.rumor)) return;",
        replace: "    } else if (this.sealed) return;",
      },
    ],
    note:
      "After Dissolution only an author's own deletion of a pinned message is retained locally (CORD-02 §9, CORD-04 §7); dropping the exemption leaves the scrub unretained and the pin visible.",
  },
  {
    id: "pin-dissolved-scrub-accepts-other-authors",
    group: "A5",
    rows: ["PIN-08.dissolved-self-scrub-only"],
    sites: [
      {
        file: "client/pins.ts",
        find:
          "      pinned ??= this.pinnedBy(info.channelId, rumor.pubkey);\n      if (!pinned.has(tag[1])) return false;",
        replace:
          "      pinned ??= this.pinnedBy(info.channelId, rumor.pubkey);\n      if (!pinned.has(tag[1]) && false) return false;",
      },
    ],
    note:
      "After Dissolution a deletion of another author's pinned message is still refused (CORD-02 §9); accepting any missing target lets a dissolved community be rewritten by a non-author.",
  },
  {
    id: "pin-proof-seal-kind-unchecked",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "    if (seal.kind !== 20013 || !verifyWrappedEvent(seal)) return undefined;",
        replace: "    if (!verifyWrappedEvent(seal)) return undefined;",
      },
    ],
    note:
      "Verifier step 1 requires seal.kind 20013 (CORD-04 §7 proof bundle); accepting any signed kind lets a plaintext seal serve as a pin proof.",
  },
  {
    id: "pin-proof-signature-unchecked",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "    if (seal.kind !== 20013 || !verifyWrappedEvent(seal)) return undefined;",
        replace: "    if (seal.kind !== 20013) return undefined;",
      },
    ],
    note:
      "Verifier step 1 verifies the seal's signature, which makes the seal's pubkey the proven author; skipping it lets anyone attribute words to any pubkey.",
  },
  {
    id: "pin-proof-mac-unchecked",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          "    if (!equalBytes(hmac(sha256, keys.subarray(44), concatBytes(nonce, ciphertext)), mac)) return undefined;",
        replace:
          "    if (false && !equalBytes(hmac(sha256, keys.subarray(44), concatBytes(nonce, ciphertext)), mac)) return undefined;",
      },
    ],
    note:
      "Verifier step 2 checks the payload's MAC with the disclosed hmac key; skipping it lets forged keys that merely decrypt pass, defeating the second key a chosen-plaintext forgery must match.",
  },
  {
    id: "pin-proof-author-mismatch-accepted",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "      rumor.pubkey !== seal.pubkey || !kinds.includes(rumor.kind) ||",
        replace: "      !kinds.includes(rumor.kind) ||",
      },
    ],
    note:
      "Step 4 requires the rumor's pubkey to equal the seal's (NIP-59's impersonation check), because renderers display rumor fields; skipping it displays words under an author who never sealed them.",
  },
  {
    id: "pin-proof-kind-unchecked",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "      rumor.pubkey !== seal.pubkey || !kinds.includes(rumor.kind) ||",
        replace: "      rumor.pubkey !== seal.pubkey || (false && !kinds.includes(rumor.kind)) ||",
      },
    ],
    note: "Step 4 requires kind 9 or 1111 for an entry; accepting any kind pins non-message rumors.",
  },
  {
    id: "pin-proof-channel-binding-unchecked",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped", "REL-01.pin-edit-bundle-verified"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: '      rumor.tags.find((t) => t[0] === "channel")?.[1] !== channelId\n    ) return undefined;',
        replace:
          '      false && rumor.tags.find((t) => t[0] === "channel")?.[1] !== channelId\n    ) return undefined;',
      },
    ],
    note:
      "Step 4 requires the channel tag to equal this list's Channel, absence failing, so a private Channel's keyholder cannot pin its messages into a public list with proof; skipping it discloses them Community-wide.",
  },
  {
    id: "pin-edit-proof-channel-binding-unchecked",
    group: "A5",
    rows: ["REL-01.pin-edit-bundle-verified"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: '      rumor.tags.find((t) => t[0] === "channel")?.[1] !== channelId\n    ) return undefined;',
        replace:
          '      (!kinds.includes(3302) && rumor.tags.find((t) => t[0] === "channel")?.[1] !== channelId)\n    ) return undefined;',
      },
    ],
    note:
      "The Edit bundle keeps the channel binding unchanged, so an Edit sealed in another Channel is refused exactly as a foreign message is; skipping it for Edits opens the door the entry path closes.",
  },
  {
    id: "pin-proof-embedded-id-trusted",
    group: "A5",
    rows: ["REL-01.pin-invalid-entry-dropped"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "    return { ...rumor, id: getEventHash(rumor) };",
        replace: "    return { ...rumor, id: rumor.id ?? getEventHash(rumor) };",
      },
    ],
    note:
      "Step 5 recomputes the rumor id from the decrypted bytes and never trusts an embedded id; trusting it lets a forged id choose an entry's identity for deduplication and deletion matching.",
  },
  {
    id: "pin-edit-author-mismatch-accepted",
    group: "A5",
    rows: ["REL-01.pin-edit-bundle-verified"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          '  const edit = opened && opened.pubkey === rumor.pubkey && opened.tags.find((t) => t[0] === "e")?.[1] === rumor.id',
        replace: '  const edit = opened && opened.tags.find((t) => t[0] === "e")?.[1] === rumor.id',
      },
    ],
    note:
      "The Edit's proven author MUST equal the original's, since nobody else may revise another member's words; accepting any author lets another member rewrite a pinned message.",
  },
  {
    id: "pin-edit-target-unchecked",
    group: "A5",
    rows: ["REL-01.pin-edit-bundle-verified"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          '  const edit = opened && opened.pubkey === rumor.pubkey && opened.tags.find((t) => t[0] === "e")?.[1] === rumor.id',
        replace: "  const edit = opened && opened.pubkey === rumor.pubkey",
      },
    ],
    note:
      "The Edit's e tag MUST name the original's recomputed rumor id; accepting any Edit of the same author attaches a correction of a different message.",
  },
  {
    id: "pin-edit-kind-not-substituted",
    group: "A5",
    rows: ["REL-01.pin-edit-bundle-verified"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "  const opened = entry.edit && openProof(entry.edit, channelId, [3302]);",
        replace: "  const opened = entry.edit && openProof(entry.edit, channelId, [9, 1111, 3302]);",
      },
    ],
    note:
      "An Edit bundle substitutes kind 3302 for 9 and 1111 in step 4; accepting message kinds lets a second message stand in as the correction.",
  },
  {
    id: "pin-wrap-hint-validated",
    group: "A5",
    rows: ["REL-01.pin-wrap-hint-untrusted"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "  const rumor = openProof(entry, channelId, [9, 1111]);",
        replace:
          "  const rumor = entry.wrap !== undefined && !/^[0-9a-f]{64}$/.test(entry.wrap) ? undefined : openProof(entry, channelId, [9, 1111]);",
      },
    ],
    note:
      "The wrap hint is untrusted and never relied on (CORD-04 §7); making an entry's validity depend on the hint lets a malformed or forged hint drop an otherwise proven pin.",
  },
  {
    id: "pin-collapse-identity-includes-wrap",
    group: "A5",
    rows: ["REL-01.pin-wrap-hint-untrusted"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    const kept = collapsed.get(pin.rumor.id);",
        replace: "    const kept = collapsed.get(`${pin.rumor.id}:${entry.wrap}`);",
      },
      {
        file: "helpers/pin-upkeep.ts",
        find: "      collapsed.set(pin.rumor.id, { entry, pin, retracted });",
        replace: "      collapsed.set(`${pin.rumor.id}:${entry.wrap}`, { entry, pin, retracted });",
      },
      {
        file: "helpers/pin-upkeep.ts",
        find: "    collapsed.set(pin.rumor.id, {\n      ...(wins",
        replace: "    collapsed.set(`${pin.rumor.id}:${entry.wrap}`, {\n      ...(wins",
      },
    ],
    note:
      "An entry's identity is its recomputed rumor id, not its locator hint; keying deduplication on the hint shows one message twice under two hints.",
  },
  {
    id: "pin-byte-cap-unenforced",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          "  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
        replace:
          "  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES * 1_000) return { available: true, entries: [] };",
      },
    ],
    note:
      "A reader treats an edition over 32,768 content bytes as an empty list (CORD-04 §7 Limits); without the cap an oversized list opens.",
  },
  {
    id: "pin-byte-cap-counts-characters",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          "  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
        replace: "  if (content.length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
      },
    ],
    note:
      "The byte cap is judged on the exact carried bytes, not characters; counting characters lets multi-byte content past the cap.",
  },
  {
    id: "pin-byte-cap-exclusive",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          "  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
        replace:
          "  if (new TextEncoder().encode(content).length >= PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
      },
    ],
    note: "The limit is 32,768 bytes inclusive; an exclusive comparison empties a list that is exactly at the cap.",
  },
  {
    id: "pin-byte-cap-skips-sealed-form",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "helpers/pins.ts",
        find:
          "  if (new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
        replace:
          "  if (!content.includes('\"sealed\"') && new TextEncoder().encode(content).length > PIN_LIST_MAX_BYTES) return { available: true, entries: [] };",
      },
    ],
    note:
      "The byte cap is judged on the carried content of both forms by every Control Plane reader, key or not; skipping the sealed form lets a keyless reader report an oversized sealed list as merely unavailable.",
  },
  {
    id: "pin-entry-cap-unenforced",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "body.entries.length > PIN_LIST_MAX_ENTRIES) {",
        replace: "body.entries.length > PIN_LIST_MAX_ENTRIES * 100) {",
      },
    ],
    note: "The entry cap is 25 for whoever can open the form; without it an over-count list opens.",
  },
  {
    id: "pin-entry-cap-exclusive",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "helpers/pins.ts",
        find: "body.entries.length > PIN_LIST_MAX_ENTRIES) {",
        replace: "body.entries.length >= PIN_LIST_MAX_ENTRIES) {",
      },
    ],
    note: "The limit is 25 entries inclusive; an exclusive comparison empties a full list.",
  },
  {
    id: "pin-oversize-edition-unavailable",
    group: "A5",
    rows: ["REL-01.pin-violating-edition-empty-list"],
    sites: [
      {
        file: "client/pins.ts",
        find:
          "    if (!head || verified?.suspended.has(eid) || head.vsk !== VSK.PINS) return { available: false };\n    return readPinList(",
        replace:
          "    if (!head || verified?.suspended.has(eid) || head.vsk !== VSK.PINS || head.edition.rumor.content.length > 32_768) return { available: false };\n    return readPinList(",
      },
    ],
    note:
      "A violating edition still folds and chains and its content reads as an empty list, not as an unavailable one (CORD-04 §7 Limits); treating oversize content as unreadable blocks the next writer and hides the difference between empty and unreadable.",
  },
  {
    id: "pin-writer-ignores-channel-form",
    group: "A5",
    rows: ["REL-01.pin-writer-form-follows-channel-type"],
    sites: [
      {
        file: "client/pins.ts",
        find: "encodePinList(collapsed, privateKey),",
        replace: "encodePinList(collapsed, privateKey && undefined),",
      },
    ],
    note:
      "A writer MUST use the form matching the Channel's folded type (CORD-04 §7); writing every list in the public form publishes a private Channel's pins in plaintext.",
  },
  {
    id: "exp-purge-wall-clock",
    group: "A4",
    rows: ["EXP-01.bounded-sweep"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find:
          "    // CORD-08 \u00a73: judged at the engine's duty clock, in Unix seconds.\n    const now = host.duties().clock.now() / 1000;",
        replace:
          "    // CORD-08 \u00a73: judged at the engine's duty clock, in Unix seconds.\n    const now = Date.now() / 1000;",
      },
    ],
    note:
      "A sweep is judged on the engine's duty clock (CORD-08 \u00a73); reading the wall clock directly makes a purge blind to the clock the engine and its tests control.",
  },
  {
    id: "exp-purge-failure-unreported",
    group: "A4",
    rows: ["EXP-01.bounded-sweep"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find:
          '        host.diagnostics.report({ stage: "expiration-purge", key: ids[i], error: entry.error });\n        continue;',
        replace: "        continue;",
      },
    ],
    note:
      "A channel store that cannot be opened is reported as expiration-purge with its channel id; swallowing the error hides a purge that silently skipped a channel (CORD-08 \u00a73).",
  },
  {
    id: "exp-purge-failure-aborts",
    group: "A4",
    rows: ["EXP-01.bounded-sweep"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "error: entry.error });\n        continue;",
        replace: "error: entry.error });\n        break;",
      },
    ],
    note:
      "One store that fails to open must not stop the sweep of the other channels (CORD-08 \u00a73); breaking out of the loop leaves every later channel unpurged.",
  },
  {
    id: "exp-purge-sweep-error-unreported",
    group: "A4",
    rows: ["EXP-01.bounded-sweep"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: '        host.diagnostics.report({ stage: "expiration-purge", key: ids[i], error });',
        replace: "        void error;",
      },
    ],
    note:
      "A channel store whose sweep throws is reported as expiration-purge with its channel id (CORD-08 \u00a73); dropping the report hides a purge that silently left expired rows behind.",
  },
  {
    id: "exp-purge-runs-after-dispose",
    group: "A4",
    rows: ["EXP-01.bounded-sweep"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    if (this.host.disposed()) return Promise.resolve(0);",
        replace: "    if (false && this.host.disposed()) return Promise.resolve(0);",
      },
    ],
    note:
      "A purge after dispose does nothing and opens no store (CORD-08 \u00a73, FND-01); without the guard a disposed engine re-creates stores through the app's factory.",
  },
  {
    id: "exp-timeline-shows-expired",
    group: "A4",
    rows: ["EXP-02.never-displayed"],
    sites: [
      {
        file: "models/chat.ts",
        find: "!currentBans.has(rumor.pubkey) && !isRumorExpired(rumor) &&",
        replace: "!currentBans.has(rumor.pubkey) && !(isRumorExpired(rumor) && false) &&",
      },
    ],
    note:
      "The chat timeline model hides a rumor whose signed expiry passed (CORD-08 \u00a73 MUST NOT display); removing the check shows expired messages.",
  },
  {
    id: "exp-timeline-no-clock-tick",
    group: "A4",
    rows: ["EXP-02.never-displayed"],
    sites: [
      {
        file: "models/chat.ts",
        find: "concat(of(0), interval(1000))",
        replace: "concat(of(0), interval(2_147_483_647))",
      },
    ],
    note:
      "A message stored before its expiry passed must still disappear without new traffic (CORD-08 \u00a73); the one-second re-check is what hides it, and a clock that never ticks keeps it displayed.",
  },
  {
    id: "exp-open-sweep-skipped",
    group: "A4",
    rows: ["EXP-02.never-displayed", "EXP-02.never-retained"],
    sites: [
      {
        file: "client/community.ts",
        find:
          '      if (planeKey.startsWith("channel:")) this.expiry.hydrate(planeKey.slice("channel:".length), store);',
        replace:
          '      if (false && planeKey.startsWith("channel:")) this.expiry.hydrate(planeKey.slice("channel:".length), store);',
      },
    ],
    note:
      "An expired rumor cached by an earlier session is deleted when its channel store opens (CORD-08 \u00a73); without the open-time sweep it stays on disk and in the display.",
  },
  {
    id: "exp-open-sweep-after-dispose",
    group: "A4",
    rows: ["EXP-02.never-retained"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    if (host.disposed()) return;\n    const now = host.duties().clock.now() / 1000;",
        replace: "    if (false && host.disposed()) return;\n    const now = host.duties().clock.now() / 1000;",
      },
    ],
    note:
      "The open-time sweep never starts once the engine is disposed (CORD-08 \u00a73); without the guard a late store open sweeps after teardown.",
  },
  {
    id: "exp-retain-gate-removed",
    group: "A4",
    rows: ["EXP-02.never-retained"],
    sites: [
      {
        file: "client/channel-input.ts",
        find: "  if (isRumorExpired(rumor)) return;\n  accepted?.();",
        replace: "  accepted?.();",
      },
    ],
    note:
      "Retention judges the signed expiry before storing or noting anything for a rumor (CORD-08 \u00a73 MUST refuse at ingest); without the gate an expired Edit still reaches the store and its seal is noted.",
  },
  {
    id: "exp-ingest-accepts-expired",
    group: "A4",
    rows: ["EXP-02.never-retained", "EXP-05.forged-outer-revive"],
    sites: [
      {
        file: "client/receive.ts",
        find: '    if (info.type === "channel" && isRumorExpired(decoded.rumor)) return null;\n    return decoded;',
        replace: "    return decoded;",
      },
      {
        file: "client/receive.ts",
        find:
          '        return decoded && !(info.type === "channel" && isRumorExpired(decoded.rumor)) ? structuredClone(decoded) : null;',
        replace: "        return decoded ? structuredClone(decoded) : null;",
      },
      {
        file: "client/channel-input.ts",
        find: "  if (isRumorExpired(rumor)) return;\n  accepted?.();",
        replace: "  accepted?.();",
      },
    ],
    note:
      "The receive boundary and the retention step each refuse a Chat rumor whose signed expiry passed (CORD-08 \u00a73); removing every library gate leaves only the upstream store's own check between an expired message and the display.",
  },
  {
    id: "exp-schedule-default-on",
    group: "A4",
    rows: ["EXP-03.opt-in-owned"],
    sites: [
      {
        file: "client/community.ts",
        find: "        forgetExpired: (now) => this.pinning.forgetExpiredInputs(now),\n      });",
        replace:
          "        forgetExpired: (now) => this.pinning.forgetExpiredInputs(now),\n      });\n      this.expiry.schedule();",
      },
    ],
    note:
      "Periodic purge is opt-in and off by default (CORD-08 \u00a73, D-09); arming a schedule when the engine is built turns it on for every consumer.",
  },
  {
    id: "exp-schedule-disposer-noop",
    group: "A4",
    rows: ["EXP-03.opt-in-owned"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "      this.activeSchedule = 0;\n      host.duties().reevaluate();",
        replace: "      host.duties().reevaluate();",
      },
    ],
    note:
      "The disposer returned by schedulePurge stops the schedule (D-09); without clearing the active schedule the next tick stays eligible.",
  },
  {
    id: "exp-schedule-ignores-replacement",
    group: "A4",
    rows: ["EXP-03.opt-in-owned"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "        eligible: () => this.activeSchedule === id && !host.disposed(),",
        replace: "        eligible: () => !host.disposed(),",
      },
    ],
    note:
      "A second schedulePurge replaces the first (D-09); ticks that ignore the active schedule id keep the replaced schedule running beside the new one.",
  },
  {
    id: "exp-schedule-no-live-resweep",
    group: "A4",
    rows: ["EXP-03.opt-in-owned"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    this.sweepNow?.();",
        replace: "    void 0;",
      },
    ],
    note:
      "A schedule armed before sync folded any channel sweeps again once the engine is live (D-12); without that a first sweep that saw no channels leaves the backlog until the next interval.",
  },
  {
    id: "exp-schedule-never-rearms",
    group: "A4",
    rows: ["EXP-03.opt-in-owned", "EXP-03.bounded"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "          if (context.alive()) arm(interval);",
        replace: "          if (context.alive() && false) arm(interval);",
      },
    ],
    note:
      "A schedule is a chain of one-shot duties and each sweep arms the next tick, including after a failed sweep (D-09); dropping the re-arm ends the periodic purge after the first sweep.",
  },
  {
    id: "exp-interval-unvalidated",
    group: "A4",
    rows: ["EXP-03.bounded"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "  if (!Number.isInteger(value) || value < MIN_PURGE_INTERVAL_MS || value > MAX_PURGE_INTERVAL_MS) {",
        replace: "  if (false) {",
      },
    ],
    note:
      "The interval is validated before anything is armed (D-11); accepting any number allows a busy loop or an overflowing timer.",
  },
  {
    id: "exp-interval-type-unchecked",
    group: "A4",
    rows: ["EXP-03.bounded"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: '  if (typeof value !== "number") throw new TypeError("purge interval must be a number");',
        replace: '  if (false) throw new TypeError("purge interval must be a number");',
      },
    ],
    note:
      "A non-number interval is a TypeError, distinct from an out-of-range number (D-11); folding both into the range check changes the contract a JS caller relies on.",
  },
  {
    id: "exp-schedule-overlaps",
    group: "A4",
    rows: ["EXP-03.bounded"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    this.running ??= this.sweep().finally(() => {",
        replace: "    this.running = this.sweep().finally(() => {",
      },
    ],
    note:
      "A purge while one runs shares it (D-10); starting a new sweep beside the running one lets two sweeps overlap.",
  },
  {
    id: "exp-schedule-arms-before-sweep",
    group: "A4",
    rows: ["EXP-03.bounded"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "            if (fresh) await this.running;",
        replace: "            arm(interval);\n            if (fresh) await this.running;",
      },
    ],
    note:
      "The next tick is armed only after a sweep ends (D-10); arming it first lets a slow sweep overlap the next tick.",
  },
  {
    id: "exp-schedule-error-unreported",
    group: "A4",
    rows: ["EXP-03.bounded"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find:
          '            host.diagnostics.report({ stage: "expiration-purge", error });\n          }\n          if (context.alive()) arm(interval);',
        replace: "            void error;\n          }\n          if (context.alive()) arm(interval);",
      },
    ],
    note:
      "A failed scheduled sweep is reported as expiration-purge instead of thrown from the timer (D-09); swallowing it hides a purge that keeps failing.",
  },
  {
    id: "exp-client-schedule-misses-later-joined",
    group: "A4",
    rows: ["EXP-03.client-fan-out"],
    sites: [
      {
        file: "client/client.ts",
        find: "    this.purgeSchedules.attach(community);\n    this.emitCommunities();",
        replace: "    this.emitCommunities();",
      },
    ],
    note:
      "client.schedulePurge reaches communities joined or rebuilt later (D-20); without attaching a new engine to the active schedule it is never purged.",
  },
  {
    id: "exp-client-schedule-misses-current",
    group: "A4",
    rows: ["EXP-03.client-fan-out"],
    sites: [
      {
        file: "client/client.ts",
        find: "    return this.purgeSchedules.set(options, this.communities.values());",
        replace: "    return this.purgeSchedules.set(options, []);",
      },
    ],
    note:
      "client.schedulePurge reaches every community that is already running (D-20); passing no targets leaves them unpurged until they are rebuilt.",
  },
  {
    id: "exp-client-disposer-noop",
    group: "A4",
    rows: ["EXP-03.client-fan-out"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "      if (this.latest === mine) this.clear();",
        replace: "      if (false) this.clear();",
      },
    ],
    note:
      "The client disposer stops every community's schedule (D-20); a disposer that does nothing leaves them all running.",
  },
  {
    id: "exp-client-stale-disposer-clears",
    group: "A4",
    rows: ["EXP-03.client-fan-out"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "      if (this.latest === mine) this.clear();",
        replace: "      if (true) this.clear();",
      },
    ],
    note:
      "An earlier disposer does nothing once a later schedulePurge replaced it (D-20); letting it clear the active schedule stops a schedule its caller never meant to stop.",
  },
  {
    id: "exp-client-throws-after-dispose-removed",
    group: "A4",
    rows: ["EXP-03.client-fan-out"],
    sites: [
      {
        file: "client/client.ts",
        find:
          "    if (this.disposed) throw new ConcordClientDisposedError();\n    return this.purgeSchedules.set(options, this.communities.values());",
        replace: "    return this.purgeSchedules.set(options, this.communities.values());",
      },
    ],
    note:
      "schedulePurge throws ConcordClientDisposedError after dispose (D-20); arming a schedule on a disposed client leaks timers nobody can stop.",
  },
  {
    id: "exp-purge-trusts-outer-tag",
    group: "A4",
    rows: ["EXP-04.signed-tag-only", "EXP-05.forged-outer-revive"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "if (!decoded || !isRumorExpired(decoded.rumor, now)) continue;",
        replace: "if (!decoded || !isRumorExpired({ kind: wrap.kind, tags: wrap.tags }, now)) continue;",
      },
    ],
    note:
      "Wrap cleanup judges the signed rumor alone, never the outer tag (CORD-08 \u00a72); reading the wrap's tag lets a relay-doctored tag keep an expired message or drop a live one.",
  },
  {
    id: "exp-addwrap-no-fallback",
    group: "A4",
    rows: ["EXP-04.signed-tag-only", "EXP-05.forged-outer-hide"],
    sites: [
      {
        file: "client/receive.ts",
        find: "return outer && outer <= unixNow() && verifyReceiveEnvelope(wire) ? wire : null;",
        replace: "return null;",
      },
    ],
    note:
      "A doctored past outer tag must not decide whether a live, authenticated rumor is retained (CORD-08 \u00a72); without the fallback the store's own outer-tag rule hides the message.",
  },
  {
    id: "exp-addwrap-fallback-all-planes",
    group: "A4",
    rows: ["EXP-04.signed-tag-only"],
    sites: [
      {
        file: "client/receive.ts",
        find: 'if (stored || (info !== undefined && info.type !== "channel")) return stored;',
        replace: "if (stored) return stored;",
      },
    ],
    note:
      "The outer-tag fallback covers Chat only (CORD-08 \u00a72); extending it to a known non-channel plane lets a control edition or rekey under a past outer tag through, which a Refounding could not recover.",
  },
  {
    id: "exp-strict-tag-rule-lenient",
    group: "A4",
    rows: ["EXP-04.signed-tag-only"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "if (!tag || tag.length !== 2 || !/^(0|[1-9][0-9]*)$/.test(tag[1])) return undefined;",
        replace: "if (!tag || tag.length < 2 || !/^[0-9]+$/.test(tag[1])) return undefined;",
      },
    ],
    note:
      "Expiry is judged by the library's strict tag rule (D-21: exactly two elements, canonical decimal); a lenient parse expires or keeps rumors the spec's tag shape does not define.",
  },
  {
    id: "exp-private-channel-addwrap-plain",
    group: "A4",
    rows: ["EXP-05.forged-outer-hide"],
    sites: [
      {
        file: "client/private-channel.ts",
        find: "const canonical = await Promise.resolve(addWrap(this.opts.eventStore, wire, info));",
        replace: "const canonical = await Promise.resolve(this.opts.eventStore.add(structuredClone(wire)));",
      },
    ],
    note:
      "A private channel stores a wrap through the shared fallback (D-17); adding it to the store directly lets a forged past outer tag hide a live private message.",
  },
  {
    id: "exp-community-addwrap-plain",
    group: "A4",
    rows: ["EXP-05.forged-outer-hide"],
    sites: [
      {
        file: "client/community.ts",
        find: "const canonical = await Promise.resolve(addWrap(this.eventStore, wire, info));",
        replace: "const canonical = await Promise.resolve(this.eventStore.add(structuredClone(wire)));",
      },
    ],
    note:
      "A community stores a wrap through the shared fallback (D-17); adding it to the store directly lets a forged past outer tag hide a live public message.",
  },
  {
    id: "exp-stamp-skipped",
    group: "A4",
    rows: ["EXP-05.stamp-durable"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "    !ephemeral && seconds && rumor.kind !== 5 && rumor.kind !== TIMER_NOTICE_KIND &&",
        replace: "    false && !ephemeral && seconds && rumor.kind !== 5 && rumor.kind !== TIMER_NOTICE_KIND &&",
      },
    ],
    note:
      "While the timer is set every durable Chat rumor carries the expiration tag (CORD-08 \u00a72 MUST); skipping the stamp sends messages that never expire.",
  },
  {
    id: "exp-outer-wrap-unstamped",
    group: "A4",
    rows: ["EXP-05.stamp-durable"],
    sites: [
      {
        file: "helpers/keys.ts",
        find: '    expiration: target.plane === "channel" ? rumorExpiration(stamped) : undefined,',
        replace: "    expiration: undefined,",
      },
    ],
    note:
      "The outer wrap carries the same expiration tag as the rumor (CORD-08 \u00a72 MUST); omitting it leaves relays holding the ciphertext forever.",
  },
  {
    id: "exp-stamp-from-wrong-base",
    group: "A4",
    rows: ["EXP-05.stamp-durable"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "    const expiration = createdAt + seconds;",
        replace: "    const expiration = createdAt + seconds + 1;",
      },
    ],
    note:
      "The tag is created_at plus the timer (CORD-08 \u00a72); any other base or offset changes when every message disappears.",
  },
  {
    id: "exp-stamp-keeps-caller-tag",
    group: "A4",
    rows: ["EXP-05.exempt-unstamped"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: '  const tags = rumor.tags.filter((tag) => tag[0] !== "expiration");',
        replace: "  const tags = [...rumor.tags];",
      },
    ],
    note:
      "The stamp replaces any caller-supplied expiration tag and exempt kinds end with none (CORD-08 \u00a72); keeping the caller's tag lets a draft pick its own lifetime or smuggle one onto a deletion.",
  },
  {
    id: "exp-stamp-ephemeral-flag",
    group: "A4",
    rows: ["EXP-05.exempt-unstamped"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "!ephemeral && seconds &&",
        replace: "seconds &&",
      },
    ],
    note:
      "Ephemeral sends carry no expiration (CORD-08 \u00a72); ignoring the flag stamps typing and presence traffic that no layer asks to store.",
  },
  {
    id: "exp-stamp-deletes",
    group: "A4",
    rows: ["EXP-05.exempt-unstamped"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "!ephemeral && seconds && rumor.kind !== 5 && rumor.kind !== TIMER_NOTICE_KIND &&",
        replace: "!ephemeral && seconds && rumor.kind !== TIMER_NOTICE_KIND &&",
      },
    ],
    note:
      "Deletes (kind 5) MUST NOT carry the expiration tag (CORD-08 \u00a72); an expiring delete would let the message it erased come back.",
  },
  {
    id: "exp-stamp-timer-notices",
    group: "A4",
    rows: ["EXP-05.exempt-unstamped"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "!ephemeral && seconds && rumor.kind !== 5 && rumor.kind !== TIMER_NOTICE_KIND &&",
        replace: "!ephemeral && seconds && rumor.kind !== 5 &&",
      },
    ],
    note:
      "Timer notices (kind 1740) MUST NOT carry the expiration tag (CORD-08 \u00a72); the policy must not erase its own notice.",
  },
  {
    id: "exp-stamp-ephemeral-kinds",
    group: "A4",
    rows: ["EXP-05.exempt-unstamped"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: "    !(rumor.kind >= 20000 && rumor.kind < 30000)\n  ) {",
        replace: "    true\n  ) {",
      },
    ],
    note:
      "Ephemeral kinds (20000-29999) carry nothing (CORD-08 \u00a72); stamping them adds a lifetime to traffic that is never stored.",
  },
  {
    id: "exp-stamp-non-chat-planes",
    group: "A4",
    rows: ["EXP-05.exempt-unstamped"],
    sites: [
      {
        file: "helpers/keys.ts",
        find: '  const ready = target.plane === "channel"\n    ? stampMessageExpiration',
        replace: "  const ready = true\n    ? stampMessageExpiration",
      },
      {
        file: "helpers/keys.ts",
        find: '    expiration: target.plane === "channel" ? rumorExpiration(stamped) : undefined,',
        replace: "    expiration: rumorExpiration(stamped),",
      },
    ],
    note:
      "The timer governs Chat planes only (CORD-08 \u00a71-2); stamping control or guestbook documents would let an expiring edition eat the chain out from under the fold.",
  },
  {
    id: "exp-tombstones-expire",
    group: "A4",
    rows: ["EXP-05.tombstones"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find:
          "  if (rumor.kind === 5 || rumor.kind === TIMER_NOTICE_KIND || (rumor.kind >= 20000 && rumor.kind < 30000)) {",
        replace: "  if (rumor.kind === TIMER_NOTICE_KIND || (rumor.kind >= 20000 && rumor.kind < 30000)) {",
      },
    ],
    note:
      "A retained deletion never expires, whatever tag it carries (CORD-08 \u00a72); judging a kind 5 by its tag lets a purge erase the tombstone that keeps its target dead.",
  },
  {
    id: "exp-purge-applies-current-timer",
    group: "A4",
    rows: ["EXP-05.non-retroactive"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    if (!isRumorExpired(rumor, now)) continue;\n    await store.remove(rumor);",
        replace:
          "    if (!isRumorExpired(rumor, now) && !(rumor.kind === 9 && rumor.created_at + 60 <= now)) continue;\n    await store.remove(rumor);",
      },
    ],
    note:
      "A timer change reaches only later sends (CORD-08 \u00a72); a purge that also expires messages by the current timer, modelled here by a fixed 60 seconds, reaches back into history.",
  },
  {
    id: "exp-community-timer-unread",
    group: "A4",
    rows: ["EXP-05.non-retroactive", "REL-01.exp-malformed-timer-off"],
    sites: [
      {
        file: "client/community.ts",
        find: "      messageExpiration: this.state$.value.metadata?.message_expiration,",
        replace: "      messageExpiration: undefined,",
      },
    ],
    note: "A send reads the folded timer (CORD-08 \u00a71-2); ignoring it sends every message without a lifetime.",
  },
  {
    id: "exp-purge-skips-chat-messages",
    group: "A4",
    rows: ["EXP-06.purge-pinned"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    if (!isRumorExpired(rumor, now)) continue;\n    await store.remove(rumor);",
        replace: "    if (!isRumorExpired(rumor, now) || rumor.kind === 9) continue;\n    await store.remove(rumor);",
      },
    ],
    note:
      "Purge removes an expired pinned message like any other (CORD-08 \u00a73, EXP-06); a purge that spares messages, modelled here by sparing kind 9, leaves the pinned text on disk.",
  },
  {
    id: "exp-pin-expiry-as-omission",
    group: "A4",
    rows: ["EXP-06.purge-pinned"],
    sites: [
      {
        file: "helpers/pin-upkeep.ts",
        find: "    if (isSelfDeleted(pin, input.rumors)) {\n      omitted.add(id);",
        replace:
          "    if (isSelfDeleted(pin, input.rumors) || (input.now !== undefined && isRumorExpired(pin.rumor, input.now))) {\n      omitted.add(id);",
      },
    ],
    note:
      "Expiry never schedules Pin List upkeep (DEC-01, D-02); treating an expired pin as omitted makes a purge publish a Control edition.",
  },
  {
    id: "exp-purge-skips-edits",
    group: "A4",
    rows: ["EXP-06.purge-wins"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    if (!isRumorExpired(rumor, now)) continue;\n    await store.remove(rumor);",
        replace:
          "    if (!isRumorExpired(rumor, now) || rumor.kind === 3302) continue;\n    await store.remove(rumor);",
      },
    ],
    note:
      "Purge removes an expired newest Edit even when a pin then shows older bundled text (D-19); a purge that spares Edits keeps the expired text on disk.",
  },
  {
    id: "exp-forget-expired-skipped",
    group: "A4",
    rows: ["EXP-06.purge-wins"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    host.forgetExpired(now);\n    const ids = host.channels()",
        replace: "    const ids = host.channels()",
      },
    ],
    note:
      "A purge drops every expired Edit's seal from memory by its signed expiry (CORD-08 \u00a73); without it the seal outlives the Edit, still decryptable.",
  },
  {
    id: "exp-seal-expiry-ignored",
    group: "A4",
    rows: ["EXP-06.purge-wins"],
    sites: [
      {
        file: "client/pin-edit-seals.ts",
        find: "  return record.expiresAt !== undefined && record.expiresAt <= now;",
        replace: "  return record.expiresAt !== undefined && record.expiresAt <= now && false;",
      },
    ],
    note:
      "A seal is judged by its signed Edit expiry at note, at proof and on forgetExpired (CORD-08 \u00a73); ignoring the expiry keeps expired Edit text in memory.",
  },
  {
    id: "exp-pin-ignores-expired-edit",
    group: "A4",
    rows: ["EXP-06.purge-wins"],
    sites: [
      {
        file: "helpers/pin-projection.ts",
        find: "(isRumorExpired(verified.rumor, now) || (applied && isRumorExpired(applied, now)));",
        replace: "(isRumorExpired(verified.rumor, now));",
      },
    ],
    note:
      "When the newest Edit is expired the whole pin is expired (D-11); looking only at the original lets the pin fall back to older text the author replaced.",
  },
  {
    id: "exp-timer-coerced",
    group: "A4",
    rows: ["REL-01.exp-malformed-timer-off"],
    sites: [
      {
        file: "helpers/expiration.ts",
        find: '  return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : 0;',
        replace: "  return Number(value) > 0 ? Math.floor(Number(value)) : 0;",
      },
    ],
    note:
      "A malformed message_expiration reads as off and a reader MUST NOT guess a default from garbage (CORD-08 \u00a71); coercing strings, booleans and fractions into a timer turns garbage into a lifetime.",
  },
  {
    id: "exp-notice-gate-removed",
    group: "A4",
    rows: ["REL-01.exp-notice-gated"],
    sites: [
      {
        file: "models/chat.ts",
        find: "(rumor.kind !== TIMER_NOTICE_KIND || authorized(rumor.pubkey))",
        replace: "(rumor.kind !== TIMER_NOTICE_KIND || true)",
      },
    ],
    note:
      "A timer notice is displayed only if its author holds MANAGE_METADATA (CORD-08 \u00a74); showing every notice lets anyone who can spell a tag announce a policy.",
  },
  {
    id: "exp-notice-authority-open",
    group: "A4",
    rows: ["REL-01.exp-notice-gated"],
    sites: [
      {
        file: "client/community.ts",
        find: "      this.state$.pipe(map((state) => refoundAuthority(state, PERM.MANAGE_METADATA))),\n    );",
        replace: "      this.state$.pipe(map((_state) => (_author: string) => true)),\n    );",
      },
    ],
    note:
      "The community feeds the chat timeline the fold's MANAGE_METADATA authority (CORD-08 \u00a74); an authority that approves every author shows a stranger's notice.",
  },
  {
    id: "exp-notice-fanout-removed",
    group: "A4",
    rows: ["REL-01.exp-timer-notice"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    for (const channel of host.channels()) {\n      if (channel.private &&",
        replace: "    for (const channel of host.channels().slice(0, 0)) {\n      if (channel.private &&",
      },
    ],
    note:
      "After a timer change the actor posts a notice into each channel (CORD-08 \u00a74 SHOULD); posting nowhere leaves the room without the line that explains its missing history.",
  },
  {
    id: "exp-notice-unheld-private-not-skipped",
    group: "A4",
    rows: ["REL-01.exp-timer-notice"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find:
          "      if (channel.private && !host.keys().material.channels.some((key) => key.id === channel.channel_id)) continue;",
        replace: "      if (false) continue;",
      },
    ],
    note:
      "Only channels whose key the actor holds get a notice (CORD-08 \u00a74); posting into a private channel whose key was given up throws and fails the timer change.",
  },
  {
    id: "exp-notice-timer-value",
    group: "A4",
    rows: ["REL-01.exp-timer-notice"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: '        tags: [["timer", String(seconds)]],',
        replace: '        tags: [["timer", "0"]],',
      },
    ],
    note: "The notice carries the new value in seconds (CORD-08 \u00a74); a fixed value announces the wrong policy.",
  },
  {
    id: "exp-purge-opened-stores-only",
    group: "A4",
    rows: ["EXP-01.every-folded-channel"],
    sites: [
      {
        file: "client/community.ts",
        find: "          const opened = openEach(ids, (id) => this.storeFor(`channel:${id}`, false));",
        replace:
          "          const opened = openEach(ids.filter((id) => this.stores.has(`channel:${id}`)), (id) => this.storeFor(`channel:${id}`, false));",
      },
    ],
    note:
      "Purge reaches the store of every folded channel, including persistent stores not opened this session (CORD-08 \u00a73 SHOULD); sweeping only open stores leaves the rest of the disk unpurged.",
  },
  {
    id: "exp-purge-skips-unheld-private",
    group: "A4",
    rows: ["EXP-01.private-and-held-epochs"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    const ids = host.channels().map((channel) => channel.channel_id);",
        replace:
          "    const ids = host.channels().filter((channel) => !channel.private || host.keys().material.channels.some((key) => key.id === channel.channel_id)).map((channel) => channel.channel_id);",
      },
    ],
    note:
      "Purge reaches private channels the user left (CORD-08 \u00a73 SHOULD); skipping channels whose key is no longer held leaves their stores unpurged.",
  },
  {
    id: "exp-purge-held-epochs-missed",
    group: "A4",
    rows: ["EXP-01.private-and-held-epochs"],
    sites: [
      {
        file: "client/expiration-purge.ts",
        find: "    for (const [pubkey, info] of deriveChannelKeys(keys.material, key).planes) {",
        replace: "    for (const [pubkey, info] of []) {",
      },
    ],
    note:
      "Purge reaches retained wraps under every held private epoch, including older ones after a restart (CORD-08 \u00a73 SHOULD); reading only the current planes misses them.",
  },
  {
    id: "exp-purge-options-exported-as-value",
    group: "A4",
    rows: ["EXP-03.options-type-only"],
    sites: [
      {
        file: "client/index.ts",
        find: 'export type { ConcordPurgeScheduleOptions } from "./expiration-purge.ts";',
        replace:
          'export type { ConcordPurgeScheduleOptions } from "./expiration-purge.ts";\nexport const ConcordPurgeScheduleOptions = undefined;',
      },
    ],
    note:
      "The schedulePurge options are a type only and the purge engine stays internal (D-09); a runtime export of the options name widens the client barrel beyond its pinned surface.",
  },
  {
    id: "forum-subject-tag-omitted",
    group: "A8",
    rows: ["FORUM-01.subject-wire", "DEC-03.send-thread-alias"],
    sites: [{
      file: "operations/channel.ts",
      find: '  return modifyPublicTags(setSingletonTag(["subject", title]));',
      replace: "  return modifyPublicTags();",
    }],
    note:
      "A titled post is a kind 9 message with a subject tag (CORD-03 §3); an includeSubject that writes no tag publishes every titled post as an untitled message.",
  },
  {
    id: "forum-subject-tag-appended",
    group: "A8",
    rows: ["FORUM-01.subject-wire"],
    sites: [{
      file: "operations/channel.ts",
      find: '  return modifyPublicTags(setSingletonTag(["subject", title]));',
      replace: '  return modifyPublicTags((tags) => [...tags, ["subject", title]]);',
    }],
    note:
      "A post carries exactly one subject tag (CORD-03 §3); appending instead of replacing leaves a second subject tag when the draft already has one.",
  },
  {
    id: "forum-subject-tag-trimmed",
    group: "A8",
    rows: ["FORUM-01.subject-wire"],
    sites: [{
      file: "operations/channel.ts",
      find: '  return modifyPublicTags(setSingletonTag(["subject", title]));',
      replace: '  return modifyPublicTags(setSingletonTag(["subject", title.trim()]));',
    }],
    note: "A non-blank title is written verbatim (CORD-03 §3); trimming it changes the title the author chose.",
  },
  {
    id: "forum-blank-subject-tagged",
    group: "A8",
    rows: ["FORUM-01.subject-wire", "DEC-03.send-thread-alias"],
    sites: [{
      file: "client/messaging.ts",
      find:
        '    const subject = typeof options.subject === "string" && options.subject.trim() !== "" ? options.subject : undefined;',
      replace: '    const subject = typeof options.subject === "string" ? options.subject : undefined;',
    }],
    note:
      "A blank or whitespace-only title publishes no subject tag (D-22, CORD-03 §3); testing for a string only publishes an empty subject tag, so an empty title no longer yields an untitled message.",
  },
  {
    id: "forum-send-thread-title-dropped",
    group: "A8",
    rows: ["DEC-03.send-thread-alias"],
    sites: [{
      file: "client/messaging.ts",
      find: "    return this.sendMessage(channelId, body, { subject: title });",
      replace: "    return this.sendMessage(channelId, body, {});",
    }],
    note:
      "sendThread is an alias that publishes a titled kind 9 post (DEC-03, CORD-03 §3); dropping the title publishes an untitled message.",
  },
  {
    id: "forum-subject-cap-unchecked",
    group: "A8",
    rows: ["FORUM-01.subject-cap"],
    sites: [{ file: "helpers/caps.ts", find: "  if (bytes > SUBJECT_MAX_BYTES) {", replace: "  if (false) {" }],
    note: "The subject MUST NOT exceed 256 bytes of UTF-8 (CORD-03 §3); never throwing accepts any length.",
  },
  {
    id: "forum-subject-cap-off-by-one",
    group: "A8",
    rows: ["FORUM-01.subject-cap"],
    sites: [{
      file: "helpers/caps.ts",
      find: "  if (bytes > SUBJECT_MAX_BYTES) {",
      replace: "  if (bytes >= SUBJECT_MAX_BYTES) {",
    }],
    note: "The cap is 256 bytes inclusive (CORD-03 §3); rejecting at 256 refuses a title the spec allows.",
  },
  {
    id: "forum-subject-cap-counts-characters",
    group: "A8",
    rows: ["FORUM-01.subject-cap"],
    sites: [{
      file: "helpers/caps.ts",
      find: "  const bytes = utf8ByteLength(subject);",
      replace: "  const bytes = subject.length;",
    }],
    note:
      "The cap counts UTF-8 bytes, not UTF-16 units (CORD-03 §3); counting characters lets multibyte titles past the cap.",
  },
  {
    id: "forum-subject-cap-not-asserted-on-send",
    group: "A8",
    rows: ["FORUM-01.subject-cap"],
    sites: [{
      file: "client/messaging.ts",
      find: "    if (subject !== undefined) assertSubject(subject);",
      replace: "",
    }],
    note: "sendMessage must refuse an over-cap title (CORD-03 §3); never asserting it publishes an over-cap subject.",
  },
  {
    id: "forum-subject-cap-after-upload",
    group: "A8",
    rows: ["FORUM-01.subject-cap"],
    sites: [{
      file: "client/messaging.ts",
      find: "    if (subject !== undefined) assertSubject(subject);",
      replace: "",
    }, {
      file: "client/messaging.ts",
      find: "    let factory = ChatMessageFactory.create(content, { emojis });",
      replace:
        "    if (subject !== undefined) assertSubject(subject);\n    let factory = ChatMessageFactory.create(content, { emojis });",
    }],
    note:
      "An over-cap title is rejected before anything is uploaded or signed (D-03); checking it after the uploads leaves orphaned blobs.",
  },
  {
    id: "forum-display-not-truncated",
    group: "A8",
    rows: ["FORUM-02.display-truncation"],
    sites: [{
      file: "helpers/forum.ts",
      find: "  if (bytes.length <= limit) return subject;",
      replace: "  return subject;",
    }],
    note:
      "A receiver truncates an over-long subject for display (CORD-03 §3); returning it whole shows the unbounded title.",
  },
  {
    id: "forum-display-splits-characters",
    group: "A8",
    rows: ["FORUM-02.display-truncation"],
    sites: [{
      file: "helpers/forum.ts",
      find: "  while (end > 0 && (bytes[end] & 0xc0) === 0x80) end--;",
      replace: "",
    }],
    note:
      "The display cut lands on a code-point boundary (D-04); without the walk back over continuation bytes a multibyte character is split.",
  },
  {
    id: "forum-overlong-subject-dropped",
    group: "A8",
    rows: ["FORUM-02.display-truncation"],
    sites: [{
      file: "client/community.ts",
      find: "      if (!checkChatBinding(decoded.rumor.tags, info.channelId!, epoch)) return;",
      replace:
        '      if (!checkChatBinding(decoded.rumor.tags, info.channelId!, epoch)) return;\n      if (new TextEncoder().encode(decoded.rumor.tags.find((t) => t[0] === "subject")?.[1] ?? "").length > 256) return;',
    }],
    note:
      "A receiver MUST NOT drop a message because its subject is over-long (CORD-03 §3); a route that drops such a post loses the message.",
  },
  {
    id: "forum-kind-11-title-fallback-removed",
    group: "A8",
    rows: ["FORUM-05.kind-11-readable"],
    sites: [{
      file: "helpers/forum.ts",
      find: '?? (rumor.kind === 11 ? firstTag(rumor.tags, "title") : undefined)',
      replace: "?? undefined",
    }],
    note: "Legacy kind 11 thread roots keep their NIP-7D titles (FORUM-05); without the fallback their titles vanish.",
  },
  {
    id: "forum-kind-11-dropped-on-receive",
    group: "A8",
    rows: ["FORUM-05.kind-11-readable"],
    sites: [{
      file: "client/community.ts",
      find: "      if (!checkChatBinding(decoded.rumor.tags, info.channelId!, epoch)) return;",
      replace:
        "      if (!checkChatBinding(decoded.rumor.tags, info.channelId!, epoch) || decoded.rumor.kind === 11) return;",
    }],
    note: "Retained kind 11 thread roots stay readable (FORUM-05); a route that drops kind 11 makes history disappear.",
  },
  {
    id: "forum-view-unknown-presented",
    group: "A8",
    rows: ["FORUM-03.view-typed"],
    sites: [{
      file: "helpers/forum.ts",
      find: '  return channel?.view === "forum" ? "forum" : "chat";',
      replace: '  return (typeof channel?.view === "string" ? channel.view : "chat") as ChannelViewMode;',
    }],
    note:
      "An unknown view value MUST render as chat (CORD-03 §2); passing the raw value through presents an unknown view as itself.",
  },
  {
    id: "forum-view-default-forum",
    group: "A8",
    rows: ["FORUM-03.view-typed"],
    sites: [{
      file: "helpers/forum.ts",
      find: '  return channel?.view === "forum" ? "forum" : "chat";',
      replace: '  return channel?.view === "chat" ? "chat" : "forum";',
    }],
    note:
      "Chat is the default when the view is absent (CORD-03 §2); defaulting to forum presents every plain channel as a forum.",
  },
  {
    id: "forum-fold-rejects-unknown-view",
    group: "A8",
    rows: ["FORUM-03.view-typed", "FORUM-03.view-preserved"],
    sites: [{
      file: "helpers/control.ts",
      find: "  const declaredKeys = Object.keys(CHANNEL_METADATA_FOLD_RULES);",
      replace:
        '  if (parsed.view !== undefined && parsed.view !== "chat" && parsed.view !== "forum") return undefined;\n  const declaredKeys = Object.keys(CHANNEL_METADATA_FOLD_RULES);',
    }],
    note:
      "A client MUST NOT reject an edition for an unknown view (CORD-03 §2); a fold that discards such an edition loses the channel.",
  },
  {
    id: "forum-fold-strips-view",
    group: "A8",
    rows: ["FORUM-03.view-preserved"],
    sites: [{
      file: "helpers/control.ts",
      find: "    ([key]) => !CHANNEL_KEY_STRIPPED_FIELDS.includes(key) && !declaredKeys.includes(key),",
      replace:
        '    ([key]) => !CHANNEL_KEY_STRIPPED_FIELDS.includes(key) && !declaredKeys.includes(key) && key !== "view",',
    }],
    note:
      "The view field is carried through the fold so later editions preserve it (CORD-03 §2); stripping it reverts a forum to chat on the next edition.",
  },
  {
    id: "forum-delete-channel-drops-view",
    group: "A8",
    rows: ["FORUM-03.view-preserved"],
    sites: [{
      file: "client/admin.ts",
      find: "    const { channel_id: _channel_id, ...rest } = ch;",
      replace: "    const { channel_id: _channel_id, view: _view, ...rest } = ch as typeof ch & { view?: unknown };",
    }],
    note:
      "A client MUST preserve view on every edition it publishes (CORD-03 §2); a deletion edition that omits it drops the field.",
  },
  {
    id: "forum-create-view-not-written",
    group: "A8",
    rows: ["FORUM-03.create-view"],
    sites: [{
      file: "client/admin.ts",
      find: '    if (options.view === "forum") content.view = "forum";',
      replace: "",
    }],
    note:
      "createChannel writes view forum for a forum channel (CORD-03 §2); omitting it creates every forum as a chat channel.",
  },
  {
    id: "forum-create-view-chat-written",
    group: "A8",
    rows: ["FORUM-03.create-view"],
    sites: [{
      file: "client/admin.ts",
      find: '    if (options.view === "forum") content.view = "forum";',
      replace: "    if (options.view !== undefined) content.view = options.view;",
    }],
    note:
      "Chat is the default and is never written (CORD-03 §2); writing the explicit chat value puts a redundant field on the wire.",
  },
  {
    id: "forum-create-view-unvalidated",
    group: "A8",
    rows: ["FORUM-03.create-view"],
    sites: [{
      file: "client/admin.ts",
      find: '    if (options.view !== undefined && options.view !== "chat" && options.view !== "forum") {',
      replace: "    if (false) {",
    }],
    note:
      "createChannel rejects any view other than chat or forum with a TypeError (D-23); skipping the check publishes arbitrary view values.",
  },
  {
    id: "forum-create-view-validated-after-mint",
    group: "A8",
    rows: ["FORUM-03.create-view"],
    sites: [{
      file: "client/admin.ts",
      find: '    if (options.view !== undefined && options.view !== "chat" && options.view !== "forum") {',
      replace: "    if (false) {",
    }, {
      file: "client/admin.ts",
      find: "    if (isPrivate) await this.opts.mintChannelKey(channelId, name);",
      replace:
        '    if (isPrivate) await this.opts.mintChannelKey(channelId, name);\n    if (options.view !== undefined && options.view !== "chat" && options.view !== "forum") {\n      throw new TypeError(\'channel view must be "chat" or "forum"\');\n    }',
    }],
    note:
      "The view is validated before a private key is minted (D-23); validating after the mint leaves an orphaned key behind a rejected channel.",
  },
  {
    id: "forum-channel-views-always-chat",
    group: "A8",
    rows: ["FORUM-03.create-view", "FORUM-03.channels-reemit"],
    sites: [{
      file: "client/channel-view.ts",
      find: "    view: channelViewMode(channel),",
      replace: '    view: "chat",',
    }],
    note: "channels$ presents each channel's view (CORD-03 §2); presenting every channel as chat hides forums.",
  },
  {
    id: "forum-channels-reemit-never",
    group: "A8",
    rows: ["FORUM-03.channels-reemit"],
    sites: [{ file: "client/channel-view.ts", find: "  if (a === b) return true;", replace: "  return true;" }],
    note:
      "channels$ re-emits when a channel changes (D-06); treating every pair as equal suppresses every re-emission.",
  },
  {
    id: "forum-channels-reemit-always",
    group: "A8",
    rows: ["FORUM-03.channels-reemit"],
    sites: [{ file: "client/channel-view.ts", find: "  if (a === b) return true;", replace: "  return false;" }],
    note:
      "channels$ stays quiet when nothing about the channels changed (D-06); treating every pair as different re-emits on every control fold.",
  },
  {
    id: "forum-channels-reemit-name-only",
    group: "A8",
    rows: ["FORUM-03.channels-reemit"],
    sites: [{
      file: "client/channel-view.ts",
      find: "    if (canonicalJson(a[i]) !== canonicalJson(b[i])) return false;",
      replace: "    if (a[i]?.name !== b[i]?.name) return false;",
    }],
    note:
      "channels$ re-emits when a channel's view changes (D-06); comparing only the name leaves the view change unseen.",
  },
  {
    id: "forum-edit-requires-k",
    group: "A8",
    rows: ["FORUM-04.receiver-ignores-k"],
    sites: [{
      file: "helpers/edit.ts",
      find: "      options.isBanned?.(candidate.pubkey)\n    ) continue;",
      replace:
        '      options.isBanned?.(candidate.pubkey) || candidate.tags.find((t) => t[0] === "k")?.[1] !== "9"\n    ) continue;',
    }],
    note:
      "A receiver never requires the k tag of an Edit (CORD-03 §3); requiring a k naming kind 9 ignores edits with no k, a wrong k and legacy kind 11 roots.",
  },
  {
    id: "forum-edit-k-tag-omitted",
    group: "A8",
    rows: ["FORUM-04.edit-k-tag"],
    sites: [{
      file: "operations/edit.ts",
      find: "  return Number.isSafeInteger(kind) && kind! >= 0",
      replace: "  return false",
    }],
    note:
      "An Edit names the kind of its target in a k tag when known (CORD-03 §3); never adding it leaves every Edit without k.",
  },
  {
    id: "forum-reply-root-not-inherited",
    group: "A8",
    rows: ["FORUM-05.reply-root-inheritance"],
    sites: [{
      file: "client/messaging.ts",
      find: "CommentFactory.create(parent, body)",
      replace: "CommentFactory.create(parent.kind === 1111 ? { ...parent, kind: 9 } : parent, body)",
    }],
    note:
      "A reply inherits its parent's uppercase root tags (CORD-03 §3); presenting a reply parent as a plain kind 9 message roots every deeper reply at its immediate parent instead of the thread root.",
  },
  {
    id: "forum-export-subject-max-bytes-hidden",
    group: "A8",
    rows: ["FORUM-06.subject-exports"],
    sites: [{
      file: "helpers/index.ts",
      find: 'export * from "./caps.ts";',
      replace: 'export * from "./caps.ts";\nexport const SUBJECT_MAX_BYTES = undefined;',
    }],
    note:
      "SUBJECT_MAX_BYTES is a public runtime export of the helpers barrel (FORUM-06); shadowing it at the barrel removes it from the public surface.",
  },
  {
    id: "forum-export-assert-subject-hidden",
    group: "A8",
    rows: ["FORUM-06.subject-exports"],
    sites: [{
      file: "helpers/index.ts",
      find: 'export * from "./caps.ts";',
      replace: 'export * from "./caps.ts";\nexport const assertSubject = undefined;',
    }],
    note:
      "assertSubject is a public runtime export of the helpers barrel (FORUM-06); shadowing it at the barrel removes it from the public surface.",
  },
  {
    id: "forum-export-get-subject-hidden",
    group: "A8",
    rows: ["FORUM-06.subject-exports"],
    sites: [{
      file: "helpers/index.ts",
      find: 'export * from "./forum.ts";',
      replace: 'export * from "./forum.ts";\nexport const getSubject = undefined;',
    }],
    note:
      "getSubject is a public runtime export of the helpers barrel (FORUM-06); shadowing it at the barrel removes it from the public surface.",
  },
  {
    id: "forum-export-display-subject-hidden",
    group: "A8",
    rows: ["FORUM-06.subject-exports"],
    sites: [{
      file: "helpers/index.ts",
      find: 'export * from "./forum.ts";',
      replace: 'export * from "./forum.ts";\nexport const displaySubject = undefined;',
    }],
    note:
      "displaySubject is a public runtime export of the helpers barrel (FORUM-06); shadowing it at the barrel removes it from the public surface.",
  },
  {
    id: "forum-export-include-subject-hidden",
    group: "A8",
    rows: ["FORUM-06.subject-exports"],
    sites: [{
      file: "operations/index.ts",
      find: 'export * from "./channel.ts";',
      replace: 'export * from "./channel.ts";\nexport const includeSubject = undefined;',
    }],
    note:
      "includeSubject is a public runtime export of the operations barrel (FORUM-06); shadowing it at the barrel removes it from the public surface.",
  },
  {
    id: "forum-export-channel-view-mode-hidden",
    group: "A8",
    rows: ["FORUM-06.view-exports"],
    sites: [{
      file: "helpers/index.ts",
      find: 'export * from "./forum.ts";',
      replace: 'export * from "./forum.ts";\nexport const channelViewMode = undefined;',
    }],
    note:
      "channelViewMode is a public runtime export of the helpers barrel (FORUM-06); shadowing it at the barrel removes it from the public surface.",
  },
  {
    id: "forum-binding-channel-tag-omitted",
    group: "A8",
    rows: ["REL-01.forum-binding-commit"],
    sites: [{
      file: "operations/channel.ts",
      find:
        '  return modifyPublicTags(setSingletonTag(["channel", channelId]), setSingletonTag(["epoch", String(epoch)]));',
      replace: '  return modifyPublicTags(setSingletonTag(["epoch", String(epoch)]));',
    }],
    note:
      "Each message commits the channel_id inside the signed rumor (CORD-03 §3); omitting the channel tag lets a wrap be replayed into another Channel.",
  },
  {
    id: "forum-binding-epoch-tag-omitted",
    group: "A8",
    rows: ["REL-01.forum-binding-commit"],
    sites: [{
      file: "operations/channel.ts",
      find:
        '  return modifyPublicTags(setSingletonTag(["channel", channelId]), setSingletonTag(["epoch", String(epoch)]));',
      replace: '  return modifyPublicTags(setSingletonTag(["channel", channelId]));',
    }],
    note:
      "Each message commits the epoch inside the signed rumor (CORD-03 §3); omitting the epoch tag lets a message be replayed across an epoch.",
  },
  {
    id: "forum-binding-check-always-true",
    group: "A8",
    rows: ["REL-01.forum-binding-drop"],
    sites: [{
      file: "helpers/chat.ts",
      find: "  return ch === channelId && ep === String(epoch);",
      replace: "  return true;",
    }],
    note:
      "A receiver drops a rumor whose channel or epoch binding does not match (CORD-03 §3); accepting every binding removes the anti-replay check.",
  },
  {
    id: "forum-binding-channel-ignored",
    group: "A8",
    rows: ["REL-01.forum-binding-drop"],
    sites: [{
      file: "helpers/chat.ts",
      find: "  return ch === channelId && ep === String(epoch);",
      replace: "  return ep === String(epoch);",
    }],
    note:
      "The channel tag must strict-equal the Channel whose key opened the wrap (CORD-03 §3); ignoring it admits a message re-wrapped into another Channel.",
  },
  {
    id: "forum-binding-epoch-ignored",
    group: "A8",
    rows: ["REL-01.forum-binding-drop"],
    sites: [{
      file: "helpers/chat.ts",
      find: "  return ch === channelId && ep === String(epoch);",
      replace: "  return ch === channelId;",
    }],
    note:
      "The epoch tag must strict-equal the epoch whose key opened the wrap (CORD-03 §3); ignoring it admits a message replayed across an epoch.",
  },
  {
    id: "forum-binding-epoch-loose",
    group: "A8",
    rows: ["REL-01.forum-binding-drop"],
    sites: [{
      file: "helpers/chat.ts",
      find: "  return ch === channelId && ep === String(epoch);",
      replace: "  return ch === channelId && Number(ep) === epoch;",
    }],
    note:
      "The epoch comparison is strict-equal (CORD-03 §3); a numeric comparison accepts a padded or reformatted epoch tag.",
  },
  {
    id: "forum-community-route-skips-binding",
    group: "A8",
    rows: ["REL-01.forum-binding-drop"],
    sites: [{
      file: "client/community.ts",
      find: "      if (!checkChatBinding(decoded.rumor.tags, info.channelId!, epoch)) return;",
      replace: "      void checkChatBinding;",
    }],
    note:
      "The community route applies the binding check before retaining a channel rumor (CORD-03 §3); skipping it retains mismatched rumors.",
  },
  {
    id: "forum-private-route-skips-binding",
    group: "A8",
    rows: ["REL-01.forum-binding-drop"],
    sites: [{
      file: "client/private-channel.ts",
      find:
        "      if (!checkChatBinding(decoded.rumor.tags, this.channelId, info.epoch ?? this.channelKey.epoch)) return;",
      replace: "      void checkChatBinding;",
    }],
    note:
      "The private channel route applies the binding check before retaining a rumor (CORD-03 §3); skipping it retains mismatched rumors.",
  },
  {
    id: "ban-fold-bit-unchecked",
    group: "A9",
    rows: ["REL-01.ban-signer-holds-ban"],
    sites: [{
      file: "helpers/control.ts",
      find: "      case VSK.BANLIST:\n        return hasPerm(s.permissions, PERM.BAN);",
      replace: "      case VSK.BANLIST:\n        return true;",
    }],
    note:
      "A Banlist edition is honored only if its signer holds BAN (CORD-04 §4); accepting any ranked signer lets a member without the bit ban.",
  },
  {
    id: "ban-fold-rank-not-strict",
    group: "A9",
    rows: ["REL-01.ban-strict-outrank"],
    sites: [{
      file: "helpers/control.ts",
      find:
        "if (target !== owner && (s.isOwner || (ready && s.position < standing(target).position))) banlist.add(target);",
      replace:
        "if (target !== owner && (s.isOwner || (ready && s.position <= standing(target).position))) banlist.add(target);",
    }],
    note:
      "The signer must strictly outrank the target (CORD-04 §3, equal cannot act on equal); a non-strict comparison lets a peer ban a peer.",
  },
  {
    id: "ban-fold-rank-unchecked",
    group: "A9",
    rows: ["REL-01.ban-strict-outrank"],
    sites: [{
      file: "helpers/control.ts",
      find:
        "if (target !== owner && (s.isOwner || (ready && s.position < standing(target).position))) banlist.add(target);",
      replace: "if (target !== owner && (s.isOwner || ready)) banlist.add(target);",
    }],
    note:
      "The signer must strictly outrank the target (CORD-04 §3); dropping the rank comparison lets a junior ban a senior.",
  },
  {
    id: "ban-fold-owner-bannable",
    group: "A9",
    rows: ["REL-01.ban-owner-unbannable"],
    sites: [{
      file: "helpers/control.ts",
      find:
        "if (target !== owner && (s.isOwner || (ready && s.position < standing(target).position))) banlist.add(target);",
      replace: "if ((s.isOwner || (ready && s.position < standing(target).position))) banlist.add(target);",
    }],
    note:
      "The owner is supreme and unremovable (CORD-04 §2); without the owner exception the owner's own list bans the owner.",
  },
  {
    id: "ban-guestbook-owner-removable",
    group: "A9",
    rows: ["REL-01.ban-owner-unbannable"],
    sites: [{
      file: "helpers/guestbook.ts",
      find: "    if (resolveStanding(banned).isOwner) continue;\n    members.delete(banned);",
      replace: "    members.delete(banned);",
    }],
    note:
      "Defense in depth behind the fold: a Banlist set that carries the owner key never removes the owner from the member set (CORD-04 §2).",
  },
  {
    id: "ban-authority-actions-not-dropped",
    group: "A9",
    rows: ["REL-01.ban-drops-authority-actions"],
    sites: [{
      file: "helpers/control.ts",
      find: "    if (banlist.has(c.edition.author) || !c.pins.some((p) => historical.has(p))) return false;",
      replace: "    if (!c.pins.some((p) => historical.has(p))) return false;",
    }],
    note:
      "An edition signed by a banned npub is dropped (CORD-04 §4); skipping the ban exclusion keeps the edition in the fold.",
  },
  {
    id: "ban-timeline-keeps-banned",
    group: "A9",
    rows: ["REL-01.ban-drops-chat-events"],
    sites: [{
      file: "models/chat.ts",
      find: "          !currentBans.has(rumor.pubkey) && !isRumorExpired(rumor) &&",
      replace: "          !isRumorExpired(rumor) &&",
    }],
    note:
      "The ban-aware channel timeline drops every rumor of a banned author (CORD-04 §4); without the filter their messages, reactions and edits reach every fold.",
  },
  {
    id: "ban-edit-by-banned-kept",
    group: "A9",
    rows: ["REL-01.ban-drops-chat-events"],
    sites: [{
      file: "helpers/edit.ts",
      find: "options.isBanned?.(candidate.pubkey)",
      replace: "false",
    }],
    note:
      "An Edit signed by a banned author is ignored (CORD-04 §4); skipping the ban test lets the banned author's text replace a message.",
  },
  {
    id: "ban-guestbook-banned-counted",
    group: "A9",
    rows: ["REL-01.ban-member-vanishes"],
    sites: [{
      file: "helpers/guestbook.ts",
      find: "    if (banlist.has(d.author) && !resolveStanding(d.author).isOwner) continue;",
      replace: "    void resolveStanding;",
    }],
    note:
      "A banned author's Guestbook entries contribute no membership effects (CORD-04 §4); counting them lets a banned npub join.",
  },
  {
    id: "ban-observed-banned-kept",
    group: "A9",
    rows: ["REL-01.ban-member-vanishes"],
    sites: [{
      file: "helpers/guestbook.ts",
      find: "    if (resolveStanding(banned).isOwner) continue;\n    members.delete(banned);",
      replace: "    if (resolveStanding(banned).isOwner) continue;",
    }],
    note:
      "A banned npub vanishes entirely (CORD-04 §4): observed activity does not keep a banned author in the member set.",
  },
  {
    id: "ban-head-lowest-version",
    group: "A9",
    rows: ["REL-01.ban-head-replaces-list"],
    sites: [{
      file: "helpers/control.ts",
      find: "  return [...byVersion.keys()].sort((a, b) => b - a).map((version) => byVersion.get(version)!);",
      replace: "  return [...byVersion.keys()].sort((a, b) => a - b).map((version) => byVersion.get(version)!);",
    }],
    note:
      "The fold takes the highest version and refuses to downgrade (CORD-04 §1); taking the lowest brings back a lifted ban and the whole stale list.",
  },
  {
    id: "ban-tie-higher-rumor-id",
    group: "A9",
    rows: ["REL-01.ban-same-version-converges"],
    sites: [{
      file: "helpers/control.ts",
      find: "    if (!w || e.rumorId < w.rumorId) byVersion.set(e.version, e);",
      replace: "    if (!w || e.rumorId > w.rumorId) byVersion.set(e.version, e);",
    }],
    note:
      "Two authorized editions at the same version converge on the lower rumor id (CORD-04 §1); the higher id would pick a different head than other clients.",
  },
  {
    id: "ban-coordinate-unchecked",
    group: "A9",
    rows: ["REL-01.ban-derived-coordinate"],
    sites: [{
      file: "helpers/control.ts",
      find: "        if (edition.eid !== banlistLocator(cid) || !Array.isArray(body) || !body.every(isKey)) continue;",
      replace: "        if (!Array.isArray(body) || !body.every(isKey)) continue;",
    }],
    note:
      "The Banlist lives at one coordinate derived from the community id (CORD-04 §4); folding a list at any other coordinate lets a forged entity shadow the real one.",
  },
  {
    id: "ban-targets-not-lowercased",
    group: "A9",
    rows: ["REL-01.ban-wire-lowercase-hex"],
    sites: [{
      file: "helpers/banlist.ts",
      find: "      const key = member.toLowerCase();",
      replace: "      const key = member;",
    }],
    note:
      "A Banlist edition carries lowercase hex keys (CORD-04 §4); writing the targets as given publishes mixed-case keys that never match an author.",
  },
  {
    id: "ban-validation-skipped",
    group: "A9",
    rows: ["BAN-01.validated-first"],
    sites: [{
      file: "client/banlist.ts",
      find: "      if (failures.length) throw new BanMembersError(failures);",
      replace: "      if (false && failures.length) throw new BanMembersError(failures);",
    }],
    note:
      "banMembers checks every target before anything is published and rejects with BanMembersError listing each refusal; skipping the rejection publishes a ban for targets the writer cannot ban.",
  },
  {
    id: "ban-writes-not-serialized",
    group: "A9",
    rows: ["BAN-02.serialized"],
    sites: [{
      file: "client/banlist.ts",
      find: "    const run = this.tail.then(async () => {",
      replace: "    const run = Promise.resolve().then(async () => {",
    }],
    note:
      "Every local Banlist write waits for the previous one on a single promise tail so each builds on the head the last write produced; starting each at once makes parallel bans overwrite each other.",
  },
  {
    id: "ban-intent-older-replaces-newer",
    group: "A9",
    rows: ["BAN-03.no-revive-unban"],
    sites: [{
      file: "client/banlist.ts",
      find: "    if (prior && prior.seq > seq) return;",
      replace: "    if (false && prior && prior.seq > seq) return;",
    }],
    note:
      "The last local intent per member wins by call order; letting an earlier queued ban that completes later replace a later unban revives the ban.",
  },
  {
    id: "ban-unban-lost-own-not-republished",
    group: "A9",
    rows: ["BAN-02.last-intent-wins", "BAN-05.restart"],
    sites: [{
      file: "client/banlist.ts",
      find: "        const force = !inHead && this.stillListed(key, eid);",
      replace: "        const force = false;",
    }],
    note:
      "An unban of a member the head omits republishes the head unchanged when this client's own newest edition still adds the member, so a restart cannot revive the ban; never forcing it leaves the restart candidate alive.",
  },
  {
    id: "ban-publish-not-acknowledged",
    group: "A9",
    rows: ["BAN-05.rejected-ack"],
    sites: [{
      file: "client/banlist.ts",
      find: "        await host.publishEdition(VSK.BANLIST, eid, content, BANLIST_PUBLICATION_STAGE, {",
      replace: "        await host.publishEdition(VSK.BANLIST, eid, content, false, {",
    }],
    note:
      "Every Banlist write waits for a relay acknowledgment and rejects with RequiredPublishError when none accepts it; publishing without the required stage treats an unacknowledged edition as sent.",
  },
  {
    id: "ban-write-carries-unvouched",
    group: "A9",
    rows: ["BAN-05.mixed-rank-write"],
    sites: [{
      file: "helpers/banlist.ts",
      find: '  if (unvouched.length) return { kind: "blocked", members: unvouched, reason: "unvouched-entries" };',
      replace:
        '  if (false && unvouched.length) return { kind: "blocked", members: unvouched, reason: "unvouched-entries" };',
    }],
    note:
      "A Banlist write never carries a ban the writer does not strictly outrank; carrying it re-signs the entry under a rank the fold drops.",
  },
  {
    id: "ban-write-lifts-unvouched",
    group: "A9",
    rows: ["BAN-05.mixed-rank-write"],
    sites: [{
      file: "helpers/banlist.ts",
      find: '  if (refused.length) return { kind: "blocked", members: refused, reason: "not-outranked" };',
      replace: '  if (false && refused.length) return { kind: "blocked", members: refused, reason: "not-outranked" };',
    }],
    note:
      "A Banlist write never lifts a ban the writer does not strictly outrank; lifting it lets a junior unban a senior's ban.",
  },
  {
    id: "ban-export-rate-limit-error-hidden",
    group: "A9",
    rows: ["BAN-01.exports"],
    sites: [{
      file: "client/index.ts",
      find: "  BanlistHeadChangedError,\n  BanlistRateLimitError,\n  BanlistWriteBlockedError,",
      replace: "  BanlistHeadChangedError,\n  BanlistWriteBlockedError,",
    }],
    note: "BanlistRateLimitError is a public runtime export of the client barrel (BAN-01); dropping it hides it.",
  },
  {
    id: "ban-export-members-error-hidden",
    group: "A9",
    rows: ["BAN-01.exports"],
    sites: [{
      file: "client/index.ts",
      find: "  BanlistWriteBlockedError,\n  BanMembersError,\n",
      replace: "  BanlistWriteBlockedError,\n",
    }],
    note: "BanMembersError is a public runtime export of the client barrel (BAN-01); dropping it hides it.",
  },
  {
    id: "ban-export-write-blocked-error-hidden",
    group: "A9",
    rows: ["BAN-01.exports"],
    sites: [{
      file: "client/index.ts",
      find: "  BanlistRateLimitError,\n  BanlistWriteBlockedError,\n  BanMembersError,",
      replace: "  BanlistRateLimitError,\n  BanMembersError,",
    }],
    note: "BanlistWriteBlockedError is a public runtime export of the client barrel (BAN-01); dropping it hides it.",
  },
  {
    id: "ban-export-head-changed-error-hidden",
    group: "A9",
    rows: ["BAN-01.exports"],
    sites: [{
      file: "client/index.ts",
      find: "export {\n  BanlistHeadChangedError,\n  BanlistRateLimitError,",
      replace: "export {\n  BanlistRateLimitError,",
    }],
    note: "BanlistHeadChangedError is a public runtime export of the client barrel (BAN-01); dropping it hides it.",
  },
  {
    id: "ban-export-reheal-error-hidden",
    group: "A9",
    rows: ["BAN-04.exports"],
    sites: [{
      file: "client/index.ts",
      find: 'export { BanlistReHealError } from "./banlist-reheal.ts";',
      replace: "export const BanlistReHealError = undefined;",
    }],
    note: "BanlistReHealError is a public runtime export of the client barrel (BAN-04); shadowing it hides it.",
  },
  {
    id: "ban-heal-seeds-despite-unban",
    group: "A9",
    rows: ["BAN-03.no-revive-unban"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: '          if (input.intents.get(member)?.action === "unban" || candidates.has(member)) continue; // D-12',
      replace: "          if (candidates.has(member)) continue; // D-12",
    }],
    note:
      "A later local unban cancels a ban seeded from retained history (D-12); seeding it anyway heals a member the user just unbanned.",
  },
  {
    id: "ban-unban-intent-not-recorded",
    group: "A9",
    rows: ["BAN-03.no-revive-unban"],
    sites: [{
      file: "client/banlist.ts",
      find: '    this.record(key, "unban", seq, undefined);',
      replace: "    // the unban intent is not recorded at the call",
    }],
    note:
      "The unban intent is recorded when the call is made, before anything can fail, so even a refused or rate-limited unban stops this session from healing the member (D-12).",
  },
  {
    id: "ban-heal-publishes-over-later-unban",
    group: "A9",
    rows: ["BAN-03.no-revive-unban"],
    sites: [{
      file: "client/banlist.ts",
      find:
        '        if ((intent?.seq ?? 0) !== seqs.get(member) || intent?.action === "unban") throw new IntentMoved();',
      replace: "        if (false) throw new IntentMoved();",
    }],
    note:
      "A heal queued or waiting on the signer is abandoned when a later ban or unban call of its member lands (D-12); never abandoning it publishes the stale heal.",
  },
  {
    id: "ban-heal-revives-removed-ban",
    group: "A9",
    rows: ["BAN-03.no-revive-removal"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: "      if (removed) continue;",
      replace: "      if (false && removed) continue;",
    }],
    note:
      "A ban that appeared on the head chain and was later removed by anyone is never revived (BAN-03); skipping the removal check heals a deliberate unban.",
  },
  {
    id: "ban-heal-seeds-foreign-edition",
    group: "A9",
    rows: ["BAN-03.own-bans-only", "BAN-05.other-holders"],
    sites: [{
      file: "helpers/banlist.ts",
      find: "rumor.kind !== CONTROL_KIND || record.author !== self || !Array.isArray(rumor.tags)",
      replace: "rumor.kind !== CONTROL_KIND || !Array.isArray(rumor.tags)",
    }],
    note:
      "Only editions this account sealed seed a heal (D-14); counting another BAN holder's edition re-applies a ban this client did not write.",
  },
  {
    id: "ban-heal-drops-unlisted-head-entries",
    group: "A9",
    rows: ["BAN-03.own-bans-only"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: "    const content = headContent.filter((entry) => entry.toLowerCase() !== ownerKey);",
      replace:
        "    const content = headContent.filter((entry) => entry.toLowerCase() !== ownerKey && input.effective.has(entry.toLowerCase()));",
    }],
    note:
      "A heal is built from the verified head content and never removes an entry other than the owner key (D-19); building from the effective set drops a ban the healer cannot vouch for.",
  },
  {
    id: "ban-heal-authority-loss-unchecked",
    group: "A9",
    rows: ["BAN-04.stops-on-authority-loss"],
    sites: [
      {
        file: "client/banlist-reheal.ts",
        find: 'this.host.phase() === "live" && this.host.canWrite() && !this.host.refounding()',
        replace: 'this.host.phase() === "live" && !this.host.refounding()',
      },
      {
        file: "client/banlist-reheal.ts",
        find: "        members.every((member) => this.canBan(member)),",
        replace: "        true,",
      },
      {
        file: "helpers/banlist-reheal.ts",
        find: "input.exhausted?.has(member) || !input.canBan(member)) continue;",
        replace: "input.exhausted?.has(member)) continue;",
      },
      {
        file: "helpers/banlist-reheal.ts",
        find: '    if (unvouched.length) return { kind: "blocked", members: unvouched };',
        replace: '    if (false && unvouched.length) return { kind: "blocked", members: unvouched };',
      },
      {
        file: "client/banlist.ts",
        find: '      if (unvouched.length) throw new BanlistWriteBlockedError(unvouched, "unvouched-entries");',
        replace:
          '      if (false && unvouched.length) throw new BanlistWriteBlockedError(unvouched, "unvouched-entries");',
      },
    ],
    note:
      "A heal stops on demotion and on losing rank over the target (D-15): the eligibility check, the live check, the planner's rank test and both vouch checks all enforce it, so all are disabled together.",
  },
  {
    id: "ban-heal-runs-during-refounding",
    group: "A9",
    rows: ["BAN-04.stops-on-lifecycle"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find: 'this.host.phase() === "live" && this.host.canWrite() && !this.host.refounding()',
      replace: 'this.host.phase() === "live" && this.host.canWrite()',
    }],
    note:
      "No heal runs while a Refounding this client started is in flight (D-15); dropping the check lets a heal race the rotation.",
  },
  {
    id: "ban-heal-survives-dissolution",
    group: "A9",
    rows: ["BAN-04.stops-on-lifecycle"],
    sites: [
      {
        file: "client/community.ts",
        find: '    this.duties.suspend("dissolved");\n',
        replace: "",
      },
      {
        file: "client/banlist-reheal.ts",
        find: 'this.host.phase() === "live" && this.host.canWrite() && !this.host.refounding()',
        replace: 'this.host.phase() === "live" && !this.host.refounding()',
      },
      {
        file: "client/banlist.ts",
        find: '      guard();\n      if (host.state().dissolved) throw new Error("community dissolved");',
        replace: "      guard();",
      },
    ],
    note:
      "A heal stops on dissolution (D-15): sealing the community suspends the duty scope, the re-healer's writability check stops it, and the writer refuses a dissolved community; all three are disabled together.",
  },
  {
    id: "ban-heal-survives-dispose",
    group: "A9",
    rows: ["BAN-04.stops-on-lifecycle"],
    sites: [
      {
        file: "client/community.ts",
        find: "    this.duties.dispose();\n",
        replace: "",
      },
      {
        file: "client/banlist-reheal.ts",
        find:
          '    return !this.disposed && this.host.phase() === "live" && this.host.canWrite() && !this.host.refounding();',
        replace: '    return this.host.phase() === "live" && !this.host.refounding();',
      },
    ],
    note:
      "A heal stops on dispose() (D-15): disposing the community disposes the duty scope, the re-healer drops its armed duty and its writability check fails; all three are disabled together.",
  },
  {
    id: "ban-ledger-kept-across-refounding",
    group: "A9",
    rows: ["BAN-04.stops-on-lifecycle"],
    sites: [{
      file: "client/banlist.ts",
      find: "      this.entries.clear();",
      replace: "      // the old epoch's intents are kept",
    }],
    note:
      "A Refounding adoption clears this session's old-epoch intents (D-15) so an old-epoch edition never seeds a heal across it.",
  },
  {
    id: "ban-heal-never-gives-up",
    group: "A9",
    rows: ["BAN-04.typed-non-convergence"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find: "export const BANLIST_REHEAL_MAX_PUBLICATIONS = 3;",
      replace: "export const BANLIST_REHEAL_MAX_PUBLICATIONS = 1_000_000;",
    }],
    note:
      "After three heal publications for one ban the member is given up on and non-convergence is reported (D-15); an unreachable bound never gives up.",
  },
  {
    id: "ban-non-convergence-reported-repeatedly",
    group: "A9",
    rows: ["BAN-04.typed-non-convergence"],
    sites: [
      {
        file: "client/banlist-reheal.ts",
        find: "    if (this.reported.has(once)) return;",
        replace: "    if (false && this.reported.has(once)) return;",
      },
      {
        file: "client/banlist-reheal.ts",
        find: "      exhausted: this.exhausted(),",
        replace: "      exhausted: new Set<string>(),",
      },
    ],
    note:
      "A member given up on is reported once and never planned again (D-15): the report is deduplicated and the planner skips exhausted members; both are disabled together.",
  },
  {
    id: "ban-pinner-edition-kept-after-ban",
    group: "A9",
    rows: ["DEC-04.fallback-no-republish"],
    sites: [
      {
        file: "helpers/control.ts",
        find: "    if (banlist.has(c.edition.author) || !c.pins.some((p) => historical.has(p))) return false;",
        replace: "    if (!c.pins.some((p) => historical.has(p))) return false;",
      },
      {
        file: "client/banlist.ts",
        find: "        if (host.state().grants.get(target)?.length) await host.stripRoles(target);",
        replace: "        if (false && host.state().grants.get(target)?.length) await host.stripRoles(target);",
      },
    ],
    note:
      "Banning a pinner makes readers fall back to the last valid Pin List (D-16): the ban excludes the pinner's editions and the paired Grant strip removes their rank, so both are disabled together and the banned edition stays the head.",
  },
  {
    id: "ban-heal-attempts-cut-to-one",
    group: "A9",
    rows: ["BAN-04.bounded-owned"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find: "      maxAttempts: 3,",
      replace: "      maxAttempts: 1,",
    }],
    note:
      "A heal duty has three attempts with backoff before duty-exhausted is reported (D-13); one attempt gives up on the first rejected acknowledgment.",
  },
  {
    id: "ban-heal-deferrals-unbounded",
    group: "A9",
    rows: ["BAN-04.bounded-owned"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find: "export const BANLIST_REHEAL_MAX_DEFERRALS = 5;",
      replace: "export const BANLIST_REHEAL_MAX_DEFERRALS = 1_000_000;",
    }],
    note:
      "A full rate window defers a heal at most five times in a row before rate-limited is reported (D-11); an unreachable bound re-arms the heal forever.",
  },
  {
    id: "ban-heal-deferral-count-kept",
    group: "A9",
    rows: ["BAN-04.bounded-owned"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find: "      this.deferred.delete(key);",
      replace: "      // the deferral count is kept",
    }],
    note: "The deferral bound restarts after a successful heal (D-11); keeping the count shortens every later spell.",
  },
  {
    id: "ban-heal-stale-signer-publishes",
    group: "A9",
    rows: ["BAN-04.bounded-owned"],
    sites: [{
      file: "client/banlist.ts",
      find: "        expectedHead,\n        check: guard,\n",
      replace: "",
    }],
    note:
      "A heal re-checks its duty and intent guard and the head it was planned from after the signer returns, so a completion that arrives after supersession never publishes; the heal passes neither check.",
  },
  {
    id: "ban-heal-ignores-rate-window",
    group: "A9",
    rows: ["BAN-04.bounded-owned"],
    sites: [{
      file: "client/banlist.ts",
      find: "    if (load < max) return 0;",
      replace: "    return 0;",
    }],
    note:
      "A full Banlist rate window defers the heal to the next free slot instead of rejecting it (D-11); reporting no wait ever publishes into a full window.",
  },
  {
    id: "ban-restart-candidates-dropped",
    group: "A9",
    rows: ["BAN-05.restart"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: '      if (additions.predecessor === "found" || additions.predecessor === "first") {',
      replace: "      if (false) {",
    }],
    note:
      "A restarted engine seeds a heal from the additions of its newest own Banlist edition (D-21); without the seed a lost ban stays lost after a restart.",
  },
  {
    id: "ban-retained-heal-immediate",
    group: "A9",
    rows: ["BAN-05.restart"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find:
        "export const BANLIST_REHEAL_RETAINED_DELAY_MS: { min: number; max: number } = { min: 5_000, max: 30_000 };",
      replace: "export const BANLIST_REHEAL_RETAINED_DELAY_MS: { min: number; max: number } = { min: 0, max: 0 };",
    }],
    note:
      "A heal sourced only from retained history waits out a window so another device of the account heals first (D-21); healing at once publishes before that window.",
  },
  {
    id: "ban-heal-not-keyed-to-head",
    group: "A9",
    rows: ["BAN-05.devices"],
    sites: [
      {
        file: "client/banlist-reheal.ts",
        find: "        this.live() && this.host.epoch() === epoch && this.read().head?.hash === headHash &&\n",
        replace: "        this.live() && this.host.epoch() === epoch &&\n",
      },
      {
        file: "client/banlist-reheal.ts",
        find: '    if (plan.kind !== "heal" || current.headHash !== headHash) {',
        replace: '    if (plan.kind !== "heal") {',
      },
      {
        file: "client/banlist.ts",
        find: "      if (head?.hash !== expectedHead) throw new HeadMoved();",
        replace: "      void HeadMoved;",
      },
      {
        file: "helpers/banlist-reheal.ts",
        find: "if (input.effective.has(member) || input.exhausted?.has(member) || !input.canBan(member)) continue;",
        replace: "if (input.exhausted?.has(member) || !input.canBan(member)) continue;",
      },
    ],
    note:
      "Two engines of one account publish at most one heal between them (D-14, D-21): a heal is keyed to the verified head it was planned on, planned again when it fires and refused when the head moved; with all of that disabled the second device heals again.",
  },
  {
    id: "ban-heal-ignores-epoch-address",
    group: "A9",
    rows: ["BAN-05.refounding-scope"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: "const ownRef = newest && input.current(newest) ? refOf(newest, head.eid) : undefined;",
      replace: "const ownRef = newest ? refOf(newest, head.eid) : undefined;",
    }],
    note:
      "An own edition that is no longer at the current epoch's Control address seeds nothing (D-15); seeding it re-applies a ban lost before a Refounding.",
  },
  {
    id: "ban-heal-readds-present-members",
    group: "A9",
    rows: ["BAN-05.mixed-rank-heal"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: "    for (const member of members) if (!headSet.has(member)) content.push(member);",
      replace: "    for (const member of members) content.push(member);",
    }],
    note:
      "A member the head content already lists but the fold dropped by rank is healed with the content unchanged (D-19); appending it again republishes a duplicate entry.",
  },
  {
    id: "ban-heal-blocked-plan-skipped",
    group: "A9",
    rows: ["BAN-05.mixed-rank-heal"],
    sites: [{
      file: "helpers/banlist-reheal.ts",
      find: '    if (unvouched.length) return { kind: "blocked", members: unvouched };',
      replace: '    if (false && unvouched.length) return { kind: "blocked", members: unvouched };',
    }],
    note:
      "A heal that would carry an entry the healer cannot vouch for is blocked and reported once (D-19); planning it anyway re-signs a senior's ban under a junior's rank.",
  },
  {
    id: "ban-writer-chains-over-rejected-edition",
    group: "A9",
    rows: ["DEC-04.writer-replaces-reverted-head"],
    sites: [
      {
        file: "client/pins.ts",
        find: "      chainOver: readiness.head ? undefined : this.host.rejectedEditionBase(eid),",
        replace: "      chainOver: this.host.rejectedEditionBase(eid),",
      },
      {
        file: "client/admin.ts",
        find: "    const prior = latest ?? guard.chainOver;",
        replace: "    const prior = guard.chainOver ?? latest;",
      },
    ],
    note:
      "The next authorized writer replaces the reverted Pin List head and chains over a banned edition only when no eligible head exists (D-16); preferring the rejected edition cites the banned edition's hash.",
  },
  {
    id: "ban-self-delete-ignored-by-upkeep",
    group: "A9",
    rows: ["DEC-04.banned-self-delete"],
    sites: [{
      file: "client/pins.ts",
      find:
        "      channelInputs: (id) => host.channelStore(id).timeline([{ kinds: [5, EDIT_KIND] }], { batchWindow: false }),",
      replace:
        "      channelInputs: (id) =>\n        host.channelStore(id).timeline([{ kinds: [5, EDIT_KIND] }], { batchWindow: false }).pipe(\n          map((rumors) => rumors.filter((rumor) => !host.state().banlist.has(rumor.pubkey))),\n        ),",
    }],
    note:
      "A banned author's own deletion of a pinned message is still upkept (D-16, self-erasure outranks curation); reading deletions through the ban filter loses it.",
  },
  {
    id: "ban-rate-limit-disabled",
    group: "A9",
    rows: ["BAN-02.rate-limited"],
    sites: [{
      file: "client/banlist.ts",
      find: "    if (load < max) return;",
      replace: "    return;",
    }],
    note:
      "At most ten Banlist editions per minute per community (CORD-04 §4); a window check that never rejects lets a client flood the Control Plane.",
  },
  {
    id: "ban-heal-never-planned",
    group: "A9",
    rows: ["BAN-03.reheal-lost-sibling", "BAN-05.concurrent-writers"],
    sites: [{
      file: "client/banlist-reheal.ts",
      find: '    if (plan.kind !== "heal") return;',
      replace: "    if (true) return;",
    }],
    note:
      "A ban displaced by a concurrent sibling is re-applied on top of the winning head (CORD-04 §4 re-heal); never arming the heal leaves the list short a ban.",
  },
  {
    id: "ban-shared-refounding-skipped",
    group: "A9",
    rows: ["BAN-01.shared-refounding"],
    sites: [{
      file: "client/banlist.ts",
      find: "      if (!options.refound) return { banned: targets };",
      replace: "      if (true) return { banned: targets };",
    }],
    note:
      "banMembers with refound runs one shared Refounding that excludes every target after the ban (CORD-04 §6); skipping it leaves the targets holding the root.",
  },
];

/** Rows the user approved to pass without a guard mutation. Empty: only the user may approve one. */
export const MUTATION_EXEMPTIONS: readonly MutationExemption[] = [];

const EXPORTS_TEST = "__tests__/index.test.ts";

const occurrences = (text: string, needle: string): number => needle === "" ? 0 : text.split(needle).length - 1;

/**
 * Returns one message per structural problem: a duplicate mutation id; a row that is unknown, not covered or in no sweep
 * group; a mutation with no sites; a site path that is absolute, contains `..`, sits under `__tests__/` or does not
 * exist; a `find` that is empty, equals its `replace` or does not occur exactly once (sites apply in order within a
 * file); a barrel mutation that lists a row not pinned by `__tests__/index.test.ts`; and an exemption without a
 * reason or an approval, for an unknown row, or for a row that is also mapped.
 */
export function manifestProblems(
  mutations: readonly GuardMutation[],
  exemptions: readonly MutationExemption[],
  ledger: readonly LedgerEntry[],
  read: (file: string) => string | undefined,
): string[] {
  const problems: string[] = [];
  const ids = new Set<string>();
  const mapped = new Set<string>();
  for (const mutation of mutations) {
    const label = mutation.id;
    if (ids.has(mutation.id)) problems.push(`${label}: duplicate mutation id`);
    ids.add(mutation.id);

    for (const id of mutation.rows) {
      mapped.add(id);
      const entry = ledger.find((candidate) => candidate.id === id);
      if (!entry) problems.push(`${label}: unknown ledger row ${id}`);
      else if (entry.status !== "covered") problems.push(`${label}: ${id} is not a covered row`);
      else if (sweepGroupOf(entry) === undefined) problems.push(`${label}: ${id} belongs to no sweep group`);
    }

    if (mutation.sites.length === 0) problems.push(`${label}: no sites`);
    const texts = new Map<string, string>();
    let barrel = false;
    for (const site of mutation.sites) {
      const segments = site.file.split("/");
      if (site.file.startsWith("/") || segments.includes("..")) {
        problems.push(`${label}: ${site.file} escapes src/`);
        continue;
      }
      if (segments.includes("__tests__")) {
        problems.push(`${label}: ${site.file} is a test file`);
        continue;
      }
      if (site.file === "index.ts" || site.file.endsWith("/index.ts")) barrel = true;
      const text = texts.get(site.file) ?? read(site.file);
      if (text === undefined) {
        problems.push(`${label}: ${site.file} does not exist`);
        continue;
      }
      if (site.find === site.replace) {
        problems.push(`${label}: ${site.file} find equals replace`);
        continue;
      }
      const count = occurrences(text, site.find);
      if (count !== 1) {
        problems.push(
          `${label}: find occurs ${count} times in ${site.file} (expected 1): ${JSON.stringify(site.find)}`,
        );
        continue;
      }
      texts.set(site.file, text.replace(site.find, () => site.replace));
    }

    if (barrel) {
      for (const id of mutation.rows) {
        const entry = ledger.find((candidate) => candidate.id === id);
        if (entry && !entry.tests.some((test) => test.file === EXPORTS_TEST)) {
          problems.push(`${label}: barrel mutation lists ${id}, which cites no test in ${EXPORTS_TEST}`);
        }
      }
    }
  }

  const exempt = new Set<string>();
  for (const exemption of exemptions) {
    const label = `exemption ${exemption.row}`;
    if (exempt.has(exemption.row)) problems.push(`${label}: duplicate exemption`);
    exempt.add(exemption.row);
    if (!ledger.some((entry) => entry.id === exemption.row)) problems.push(`${label}: unknown ledger row`);
    if (!exemption.reason.trim()) problems.push(`${label}: no reason`);
    if (!exemption.approval.trim()) problems.push(`${label}: no recorded user approval`);
    if (mapped.has(exemption.row)) problems.push(`${label}: the row is also mapped by a mutation`);
  }
  return problems;
}

/** The covered MUST rows of `group` that no mutation lists and no exemption names. */
export function unmappedRows(
  group: SweepGroup,
  mutations: readonly GuardMutation[],
  exemptions: readonly MutationExemption[],
  ledger: readonly LedgerEntry[] = CONFORMANCE_LEDGER,
): string[] {
  const named = new Set<string>([...mutations.flatMap((mutation) => mutation.rows), ...exemptions.map((e) => e.row)]);
  return ledger
    .filter((entry) =>
      entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === group && !named.has(entry.id)
    )
    .map((entry) => entry.id);
}

/** Lowercase hex SHA-256 of the mutation's sites; it changes whenever any site changes. */
export async function mutationDigest(mutation: GuardMutation): Promise<string> {
  const bytes = new TextEncoder().encode(JSON.stringify(mutation.sites));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
