// REL-01 mutation-sweep runner (D-04, D-10). For every guard mutation in conformance-mutations.ts it disables the guard
// inside a scratch `git clone --local` copy of this repository, runs the cited tests of every row the mutation lists and
// judges each row by its own cited testcases failing with an assertion. It is deliberately not a `*.test.ts` file, so
// `deno task test` never runs it; importing it needs no permissions (all side effects sit under `import.meta.main`),
// which is how conformance-sweep.test.ts reaches the pure helpers.
//
// Sweep (from the project root; write access only to the scratch clones and .artifacts):
//   deno run --allow-read --allow-write=<scratch>,.artifacts --allow-run=deno,git src/__tests__/conformance-sweep.ts \
//     --clone <scratch>/c1 [--clone <scratch>/c2 ...] (--group <SweepGroup> | --ids <id,id>) \
//     --out .artifacts/ledger-sweep-<name>.json [--timeout-ms <n>] [--no-confirm]
// Coverage gate (read-only; exits 0 only when every covered MUST row of the group has a current, confirmed `killed`
// verdict; exempt rows always count as missing):
//   deno run --allow-read src/__tests__/conformance-sweep.ts --check <SweepGroup> <results.json>...
// Verdict printer (read-only; prints CONFORMANCE_VERDICTS entries for the group, exits non-zero when --check would):
//   deno run --allow-read src/__tests__/conformance-sweep.ts --verdicts <SweepGroup> <results.json>...
//
// Safety (D-10): the runner mutates only the `--clone` directories. It refuses (a stderr line starting with `refusing:`,
// exit 2, nothing written) a clone that is the project tree or inside it, is not the top level of a git work tree, has no
// local `origin`, is dirty, whose conformance-mutations.ts differs from the running module's, that lacks node_modules,
// or in which a mutated file is not tracked. Every mutated file is restored with `git checkout -- <file>`, its SHA-256 is
// compared with the original and `git status --porcelain` must be empty; any mismatch stops the whole sweep. The only
// git subcommands it runs are rev-parse, remote, status, ls-files and `checkout -- <file>`.
//
// Verdicts: a row is `killed` only when one of its own cited testcases fails with an assertion (an AssertionError) and a
// confirmation re-run kills it again (otherwise `flaky`); a failing sanitizer on the cited describe is `leak`; no
// matching testcase, a module-link, syntax or type error or any non-assertion failure is `invalid`; a cited testcase
// that only passes is `survived`; a mutant that exceeds the timeout is `timeout`. A row whose cited tests include
// `__tests__/index.test.ts` can be killed only by an assertion in that file. Mutant runs use `--no-check` because
// mutants often trip `noUnusedLocals`; the real gates never do. Exemptions are never approved by this runner or by an
// executor: only the user can approve one (see MUTATION_EXEMPTIONS), and an exempt row still counts as missing.

/// <reference lib="deno.ns" />
// Test-only: `deno.json` sets `lib` to ES2022+DOM without `deno.ns`, so library source cannot reach for Deno APIs. This
// runner lives under `__tests__/` and drives `deno` and `git`, so it opts into the Deno namespace here (see
// index.cord-citations.test.ts) rather than widening `lib` for all of `src/`.

import { dirname, fromFileUrl, join, resolve, SEPARATOR } from "@std/path";

import { CONFORMANCE_LEDGER, type LedgerEntry, type LedgerTestRef } from "./conformance-ledger.ts";
import {
  GUARD_MUTATIONS,
  type GuardMutation,
  manifestProblems,
  MUTATION_EXEMPTIONS,
  mutationDigest,
  type MutationExemption,
  type MutationSite,
  SWEEP_GROUPS,
  type SweepGroup,
  sweepGroupOf,
} from "./conformance-mutations.ts";

/** How one row fared under one mutation. */
export type Verdict = "killed" | "survived" | "leak" | "invalid" | "timeout" | "flaky";

/** One testcase of a JUnit report. */
export interface JunitCase {
  /** `<top-level describe> > <it>` (nested describes add segments), unescaped. */
  name: string;
  /** The failure text (message and body) when the testcase failed. */
  failure?: string;
  /** The test file the case was run from, relative to `src/`; set by the runner, absent in raw reports. */
  file?: string;
}

/** The verdict of one row and the testcase (or describe) that decided it. */
export interface RowOutcome {
  verdict: Verdict;
  /** The failing testcase name; empty when no testcase decided the verdict. */
  failing: string;
}

/** One judged row of one mutation in a results file. */
export interface SweepRow {
  row: string;
  verdict: Verdict;
  failing: string;
}

/** One mutation's result in a results file. */
export interface SweepMutationResult {
  id: string;
  group: SweepGroup;
  /** `mutationDigest` of the mutation when it ran. */
  digest: string;
  sites: readonly MutationSite[];
  note: string;
  durationMs: number;
  rows: SweepRow[];
}

/** The JSON file a sweep writes with `--out`. */
export interface SweepResults {
  runner: string;
  startedAt: string;
  finishedAt: string;
  /** The 40-character commit id every scratch clone was at. */
  cloneHead: string;
  /** Whether killed rows were confirmed by a second run; unconfirmed kills never count. */
  confirmed: boolean;
  groups: readonly string[];
  ids: readonly string[];
  results: SweepMutationResult[];
}

/** The newest usable verdict of a row. */
export interface CurrentVerdict {
  row: string;
  verdict: Verdict;
  mutation: string;
  digest: string;
  failing: string;
  sweptAt: string;
  finishedAt: string;
}

/** A `CONFORMANCE_VERDICTS` entry. */
export interface VerdictEntry {
  row: string;
  verdict: "killed";
  mutation: string;
  digest: string;
  failing: string;
  sweptAt: string;
}

const escapeRegex = (text: string): string => text.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");

/**
 * Returns the new text of every site file of `mutation`, each site's single `find` replaced (sites apply in order, so a
 * later site in the same file sees the earlier edit). `texts` maps `src/`-relative paths to their current text and is not
 * modified. Throws when a file has no text or a `find` occurs zero or several times.
 */
export function applyMutation(
  texts: Readonly<Record<string, string>>,
  mutation: GuardMutation,
): Record<string, string> {
  const out = new Map<string, string>();
  for (const site of mutation.sites) {
    const current = out.get(site.file) ?? (Object.hasOwn(texts, site.file) ? texts[site.file] : undefined);
    if (current === undefined) throw new Error(`${mutation.id}: no text for ${site.file}`);
    const count = site.find === "" ? 0 : current.split(site.find).length - 1;
    if (count !== 1) {
      throw new Error(`${mutation.id}: find occurs ${count} times in ${site.file} (expected 1): ${site.find}`);
    }
    out.set(site.file, current.replace(site.find, () => site.replace));
  }
  return Object.fromEntries(out);
}

/**
 * The name of the top-level `describe` (or top-level `it` / `Deno.test`) that holds the static test named `name`, which
 * is what `--filter` can select; `undefined` when the file does not declare `name`. A top-level declaration returns
 * `name` itself.
 */
export function enclosingDescribe(fileText: string, name: string): string | undefined {
  const quoted = escapeRegex(JSON.stringify(name));
  const declaration = new RegExp(`(?<![\\w.$])(?:it|describe|Deno\\.test)\\(${quoted}`).exec(fileText);
  if (!declaration) return undefined;
  const at = declaration.index;
  if (at === 0 || fileText[at - 1] === "\n") return name;
  let found: string | undefined;
  for (const top of fileText.matchAll(/^(?:describe|it|Deno\.test)\(("(?:[^"\\\n]|\\.)*")/gm)) {
    if (top.index >= at) break;
    found = JSON.parse(top[1]) as string;
  }
  return found;
}

/** A `deno test --filter` argument that matches exactly the given top-level test names. */
export function filterArg(names: readonly string[]): string {
  return `/^(?:${names.map(escapeRegex).join("|")})$/`;
}

const unescapeXml = (text: string): string =>
  text.replace(/&(lt|gt|quot|apos|amp|#\d+|#x[0-9a-fA-F]+);/g, (_match, entity: string) => {
    switch (entity) {
      case "lt":
        return "<";
      case "gt":
        return ">";
      case "quot":
        return '"';
      case "apos":
        return "'";
      case "amp":
        return "&";
      default:
        return String.fromCodePoint(entity[1] === "x" ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10));
    }
  });

const attribute = (tag: string, key: string): string | undefined => {
  const match = new RegExp(`\\b${key}="([^"]*)"`).exec(tag);
  return match ? unescapeXml(match[1]) : undefined;
};

/** Reads the testcases of a `deno test --reporter=junit` report; names and failure text are unescaped. */
export function parseJunit(xml: string): JunitCase[] {
  const cases: JunitCase[] = [];
  for (const match of xml.matchAll(/<testcase\b([^>]*?)(?:\/>|>([\s\S]*?)<\/testcase>)/g)) {
    const name = attribute(match[1], "name");
    if (name === undefined) continue;
    const failure = /<(?:failure|error)\b([^>]*?)(?:\/>|>([\s\S]*?)<\/(?:failure|error)>)/.exec(match[2] ?? "");
    if (!failure) {
      cases.push({ name });
      continue;
    }
    const message = attribute(failure[1], "message") ?? "";
    const body = unescapeXml(failure[2] ?? "").trim();
    cases.push({ name, failure: [message, body].filter((part) => part !== "").join("\n") || "failed" });
  }
  return cases;
}

type FailureKind = "assertion" | "leak" | "derived" | "other";

function failureKind(failure: string): FailureKind {
  const lines = failure.split("\n").map((line) => line.trim()).filter((line) => line !== "");
  // A BDD describe reports "N test step(s) failed" when one of its steps failed; the step carries the real failure.
  if (lines.every((line) => /^\d+ test steps? failed\.?$/.test(line))) return "derived";
  if (/Leaks detected|Test case is leaking|leaking async ops|leaking \d+ resources?/.test(failure)) return "leak";
  if (/\bAssertionError\b/.test(failure)) return "assertion";
  // Module-link, syntax, type and plain thrown errors are not proof that the guard was exercised.
  return "other";
}

const EXPORTS_TEST = "__tests__/index.test.ts";

const segments = (testcase: JunitCase): string[] => testcase.name.split(" > ");

/**
 * Whether a junit name cites `name`: one of its ` > ` segments, or (for a test whose own name contains ` > `, which the
 * split above would cut apart) the whole name, a trailing part after a describe, or a leading part before its steps.
 */
const namesCase = (testcase: JunitCase, name: string): boolean =>
  segments(testcase).includes(name) || testcase.name === name || testcase.name.startsWith(`${name} > `) ||
  testcase.name.endsWith(` > ${name}`) || testcase.name.includes(` > ${name} > `);

const matchesRef = (testcase: JunitCase, ref: LedgerTestRef): boolean =>
  (testcase.file === undefined || testcase.file === ref.file) && namesCase(testcase, ref.name);

/**
 * Whether a recorded `failing` testcase name is still one of the row's cited tests, by the rule `rowVerdict` judges kills
 * with: a row citing `__tests__/index.test.ts` counts only those citations. An empty name never matches, so a verdict
 * whose cited test was re-pointed or dropped after its sweep no longer vouches for the row. The match is by name only,
 * unlike `matchesRef`, because a recorded verdict carries no file (see conformance-sweep.verdicts.test.ts).
 */
export function failingIsCited(failing: string, citedRefs: readonly LedgerTestRef[]): boolean {
  const pinned = citedRefs.filter((ref) => ref.file === EXPORTS_TEST);
  const refs = pinned.length > 0 ? pinned : citedRefs;
  return failing !== "" && refs.some((ref) => namesCase({ name: failing }, ref.name));
}

/**
 * Judges one row from the testcases of a mutant run and the tests the row cites. `killed`: a case matching a cited name
 * (any segment, so a describe citation covers its steps) fails with an assertion; `leak`: only the sanitizer failed the
 * cited describe; `invalid`: no matching case, or the failure is a module-link, syntax, type or other non-assertion
 * error; `survived`: every matching case passed. A row citing `__tests__/index.test.ts` is judged by that file's cases
 * alone.
 */
export function rowVerdict(cases: readonly JunitCase[], citedRefs: readonly LedgerTestRef[]): RowOutcome {
  const pinned = citedRefs.filter((ref) => ref.file === EXPORTS_TEST);
  const refs = pinned.length > 0 ? pinned : citedRefs;
  const own = cases.filter((testcase) => refs.some((ref) => matchesRef(testcase, ref)));
  if (own.length === 0) return { verdict: "invalid", failing: "" };

  const failing = own.filter((testcase) => testcase.failure !== undefined);
  const killer = failing.find((testcase) => failureKind(testcase.failure!) === "assertion");
  if (killer) return { verdict: "killed", failing: killer.name };

  const describes = new Set(own.map((testcase) => segments(testcase)[0]));
  const leaked = cases.find((testcase) =>
    testcase.failure !== undefined && !testcase.name.includes(" > ") && describes.has(testcase.name) &&
    refs.some((ref) => testcase.file === undefined || testcase.file === ref.file) &&
    failureKind(testcase.failure) === "leak"
  );
  if (leaked) return { verdict: "leak", failing: leaked.name };
  if (failing.some((testcase) => failureKind(testcase.failure!) === "leak")) {
    return { verdict: "leak", failing: failing[0].name };
  }
  if (failing.length > 0) return { verdict: "invalid", failing: failing[0].name };
  return { verdict: "survived", failing: "" };
}

/**
 * The newest usable verdict of every row. A result counts only when its mutation still exists, still lists the row and
 * has the digest `digests` holds for it now, and a kill counts only from a confirmed sweep. Per (row, mutation) the
 * newest result wins; a row's verdict is then its newest kill when any current mutation killed it, else its newest
 * other verdict.
 */
export function currentVerdicts(
  results: readonly SweepResults[],
  mutations: readonly GuardMutation[],
  digests: Readonly<Record<string, string>>,
): Map<string, CurrentVerdict> {
  const newest = new Map<string, CurrentVerdict>();
  for (const file of results) {
    for (const result of file.results) {
      const mutation = mutations.find((candidate) => candidate.id === result.id);
      if (!mutation || digests[result.id] !== result.digest) continue;
      for (const row of result.rows) {
        if (!mutation.rows.includes(row.row)) continue;
        if (row.verdict === "killed" && !file.confirmed) continue;
        const key = `${row.row}\u0000${result.id}`;
        const previous = newest.get(key);
        if (previous && previous.finishedAt > file.finishedAt) continue;
        newest.set(key, {
          row: row.row,
          verdict: row.verdict,
          mutation: result.id,
          digest: result.digest,
          failing: row.failing,
          sweptAt: file.cloneHead,
          finishedAt: file.finishedAt,
        });
      }
    }
  }
  const best = new Map<string, CurrentVerdict>();
  for (const candidate of newest.values()) {
    const held = best.get(candidate.row);
    const better = !held ||
      (candidate.verdict === "killed" && held.verdict !== "killed") ||
      ((candidate.verdict === "killed") === (held.verdict === "killed") && candidate.finishedAt > held.finishedAt);
    if (better) best.set(candidate.row, candidate);
  }
  return best;
}

const requiredRows = (group: SweepGroup, ledger: readonly LedgerEntry[]): string[] =>
  ledger
    .filter((entry) => entry.status === "covered" && entry.level === "MUST" && sweepGroupOf(entry) === group)
    .map((entry) => entry.id);

/**
 * Which covered MUST rows of `group` lack a current confirmed kill: `missing` has no usable verdict (every exempt row is
 * reported here, so an exemption never passes), `notKilled` has one that is not `killed`. Both follow ledger order.
 */
export function groupCoverage(
  group: SweepGroup,
  results: readonly SweepResults[],
  ledger: readonly LedgerEntry[],
  mutations: readonly GuardMutation[],
  exemptions: readonly MutationExemption[],
  digests: Readonly<Record<string, string>>,
): { missing: string[]; notKilled: string[] } {
  const exempt = new Set(exemptions.map((exemption) => exemption.row));
  const current = currentVerdicts(results, mutations, digests);
  const missing: string[] = [];
  const notKilled: string[] = [];
  for (const id of requiredRows(group, ledger)) {
    const verdict = current.get(id);
    if (exempt.has(id) || !verdict) missing.push(id);
    else if (verdict.verdict !== "killed") notKilled.push(id);
  }
  return { missing, notKilled };
}

/** The `CONFORMANCE_VERDICTS` entries for every covered MUST row of `group` with a current confirmed kill, by row id. */
export function verdictEntries(
  group: SweepGroup,
  results: readonly SweepResults[],
  ledger: readonly LedgerEntry[],
  mutations: readonly GuardMutation[],
  exemptions: readonly MutationExemption[],
  digests: Readonly<Record<string, string>>,
): VerdictEntry[] {
  const exempt = new Set(exemptions.map((exemption) => exemption.row));
  const current = currentVerdicts(results, mutations, digests);
  const entries: VerdictEntry[] = [];
  for (const id of requiredRows(group, ledger)) {
    const verdict = current.get(id);
    if (exempt.has(id) || !verdict || verdict.verdict !== "killed") continue;
    entries.push({
      row: id,
      verdict: "killed",
      mutation: verdict.mutation,
      digest: verdict.digest,
      failing: verdict.failing,
      sweptAt: verdict.sweptAt,
    });
  }
  return entries.sort((a, b) => a.row < b.row ? -1 : a.row > b.row ? 1 : 0);
}

// ---------------------------------------------------------------------------------------------------------------------
// Command line (side effects only below, and only under `import.meta.main`)
// ---------------------------------------------------------------------------------------------------------------------

type CliArgs =
  | {
    mode: "sweep";
    clones: string[];
    groups: SweepGroup[];
    ids: string[];
    out: string;
    timeoutMs: number;
    confirm: boolean;
  }
  | { mode: "check" | "verdicts"; group: SweepGroup; files: string[] };

const isGroup = (value: string | undefined): value is SweepGroup => SWEEP_GROUPS.some((group) => group === value);

function parseArgs(args: readonly string[]): CliArgs | string {
  if (args[0] === "--check" || args[0] === "--verdicts") {
    const group = args[1];
    if (!isGroup(group)) return `${args[0]} needs a sweep group (${SWEEP_GROUPS.join(", ")})`;
    const files = args.slice(2);
    if (files.length === 0) return `${args[0]} needs at least one results file`;
    const flag = files.find((file) => file.startsWith("--"));
    if (flag) return `unexpected argument ${flag}`;
    return { mode: args[0] === "--check" ? "check" : "verdicts", group, files };
  }
  const parsed = {
    mode: "sweep" as const,
    clones: [] as string[],
    groups: [] as SweepGroup[],
    ids: [] as string[],
    out: "",
    timeoutMs: 300_000,
    confirm: true,
  };
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    if (flag === "--no-confirm") {
      parsed.confirm = false;
      continue;
    }
    if (flag !== "--clone" && flag !== "--group" && flag !== "--ids" && flag !== "--out" && flag !== "--timeout-ms") {
      return `unknown argument ${flag}`;
    }
    const value = args[++i];
    if (value === undefined || value.startsWith("--")) return `${flag} needs a value`;
    if (flag === "--clone") parsed.clones.push(value);
    else if (flag === "--group") {
      if (!isGroup(value)) return `--group must be one of ${SWEEP_GROUPS.join(", ")}`;
      parsed.groups.push(value);
    } else if (flag === "--ids") parsed.ids.push(...value.split(",").map((id) => id.trim()).filter((id) => id !== ""));
    else if (flag === "--out") parsed.out = value;
    else {
      const ms = Number(value);
      if (!Number.isSafeInteger(ms) || ms <= 0) return "--timeout-ms must be a positive integer";
      parsed.timeoutMs = ms;
    }
  }
  if (parsed.clones.length === 0) return "at least one --clone is required";
  if (parsed.groups.length === 0 && parsed.ids.length === 0) return "--group or --ids is required";
  if (parsed.out === "") return "--out is required";
  return parsed;
}

const encoder = new TextEncoder();
function writeLine(stream: { writeSync(data: Uint8Array): number }, line: string): void {
  try {
    stream.writeSync(encoder.encode(`${line}\n`));
  } catch (error) {
    // A reader that closed early (for example `| head`) must not turn a finished report into a crash.
    if (!(error instanceof Deno.errors.BrokenPipe)) throw error;
  }
}
const writeOut = (line: string): void => writeLine(Deno.stdout, line);
const writeErr = (line: string): void => writeLine(Deno.stderr, line);

/** The directory that holds this module's `src/`, two levels above `src/__tests__/`. */
const projectRoot = (): string => resolve(dirname(fromFileUrl(import.meta.url)), "..", "..");

const isInside = (parent: string, child: string): boolean => child === parent || child.startsWith(parent + SEPARATOR);

async function sha256(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(text));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

const GIT_SUBCOMMANDS: ReadonlySet<string> = new Set(["rev-parse", "remote", "status", "ls-files", "checkout"]);

interface Finished {
  code: number;
  stdout: string;
  stderr: string;
}

/** Runs one of the five permitted git subcommands in `clone` (argv array, no shell). */
async function git(clone: string, args: readonly string[]): Promise<Finished> {
  const [subcommand] = args;
  if (!GIT_SUBCOMMANDS.has(subcommand)) throw new Error(`git ${subcommand} is not permitted`);
  if (subcommand === "checkout" && !(args.length === 3 && args[1] === "--" && !args[2].startsWith("-"))) {
    throw new Error("only `git checkout -- <file>` is permitted");
  }
  const output = await new Deno.Command("git", {
    args: ["-C", clone, ...args],
    stdin: "null",
    stdout: "piped",
    stderr: "piped",
  }).output();
  const decoder = new TextDecoder();
  return { code: output.code, stdout: decoder.decode(output.stdout), stderr: decoder.decode(output.stderr) };
}

/** Child processes currently running, killed by the signal handlers so every restore runs. */
const activeChildren = new Set<Deno.ChildProcess>();
let aborted = false;

interface Ran extends Finished {
  timedOut: boolean;
}

async function runDeno(clone: string, args: readonly string[], timeoutMs: number): Promise<Ran> {
  const child = new Deno.Command("deno", {
    args: [...args],
    cwd: clone,
    stdin: "null",
    stdout: "piped",
    stderr: "piped",
  })
    .spawn();
  activeChildren.add(child);
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    killChild(child);
  }, timeoutMs);
  try {
    const output = await child.output();
    const decoder = new TextDecoder();
    return {
      code: output.code,
      stdout: decoder.decode(output.stdout),
      stderr: decoder.decode(output.stderr),
      timedOut,
    };
  } finally {
    clearTimeout(timer);
    activeChildren.delete(child);
  }
}

function killChild(child: Deno.ChildProcess): void {
  try {
    child.kill("SIGKILL");
  } catch {
    // The child already exited, so there is nothing left to stop.
  }
}

function readText(path: string): string | undefined {
  try {
    return Deno.readTextFileSync(path);
  } catch {
    return undefined;
  }
}

class RestoreError extends Error {}

interface CitedPlan {
  /** Per test file (relative to `src/`), the top-level describe names to run. */
  files: Map<string, Set<string>>;
  /** Ids of rows with a cited test the file does not declare. */
  unresolved: Set<string>;
}

function planFor(clone: string, rows: readonly LedgerEntry[]): CitedPlan {
  const files = new Map<string, Set<string>>();
  const unresolved = new Set<string>();
  const texts = new Map<string, string | undefined>();
  for (const row of rows) {
    for (const test of row.tests) {
      if (!texts.has(test.file)) texts.set(test.file, readText(join(clone, "src", test.file)));
      const text = texts.get(test.file);
      const describe = text === undefined ? undefined : enclosingDescribe(text, test.name);
      if (describe === undefined) {
        unresolved.add(row.id);
        continue;
      }
      if (!files.has(test.file)) files.set(test.file, new Set());
      files.get(test.file)!.add(describe);
    }
  }
  return { files, unresolved };
}

/** Runs the planned describes, one `deno test` per file so every case is tagged with its file. */
async function runCited(
  clone: string,
  plan: CitedPlan,
  timeoutMs: number,
): Promise<{ cases: JunitCase[]; timedOut: boolean }> {
  const cases: JunitCase[] = [];
  for (const [file, describes] of plan.files) {
    if (aborted) return { cases, timedOut: false };
    const ran = await runDeno(clone, [
      "test",
      "--no-check",
      "--allow-read=src,e2e",
      "--allow-env=DEBUG,TERM",
      "--reporter=junit",
      "--filter",
      filterArg([...describes]),
      `src/${file}`,
    ], timeoutMs);
    if (ran.timedOut) return { cases, timedOut: true };
    for (const testcase of parseJunit(ran.stdout)) cases.push({ ...testcase, file });
  }
  return { cases, timedOut: false };
}

function cloneFile(clone: string, file: string): string {
  const path = resolve(clone, "src", file);
  if (!isInside(join(clone, "src"), path) || path === join(clone, "src")) {
    throw new Error(`refusing to touch ${path}: outside ${join(clone, "src")}`);
  }
  return path;
}

async function restoreFiles(
  clone: string,
  files: readonly string[],
  originals: ReadonlyMap<string, string>,
): Promise<string | undefined> {
  const problems: string[] = [];
  for (const file of files) {
    const restored = await git(clone, ["checkout", "--", `src/${file}`]);
    if (restored.code !== 0) problems.push(`git checkout failed for src/${file}: ${restored.stderr.trim()}`);
    const text = readText(cloneFile(clone, file));
    if (text === undefined || await sha256(text) !== originals.get(file)) {
      problems.push(`src/${file} differs after restore`);
    }
  }
  const status = await git(clone, ["status", "--porcelain"]);
  if (status.code !== 0 || status.stdout.trim() !== "") problems.push(`${clone} is not clean: ${status.stdout.trim()}`);
  return problems.length > 0 ? problems.join("; ") : undefined;
}

async function runMutation(
  clone: string,
  mutation: GuardMutation,
  rows: readonly LedgerEntry[],
  timeoutMs: number,
): Promise<SweepMutationResult> {
  const started = Date.now();
  const files = [...new Set(mutation.sites.map((site) => site.file))];
  const texts: Record<string, string> = {};
  const hashes = new Map<string, string>();
  for (const file of files) {
    texts[file] = await Deno.readTextFile(cloneFile(clone, file));
    hashes.set(file, await sha256(texts[file]));
  }
  const plan = planFor(clone, rows);
  let failure: unknown;
  let ran: { cases: JunitCase[]; timedOut: boolean } | undefined;
  try {
    const mutated = applyMutation(texts, mutation);
    for (const [file, text] of Object.entries(mutated)) await Deno.writeTextFile(cloneFile(clone, file), text);
    ran = await runCited(clone, plan, timeoutMs);
  } catch (error) {
    failure = error;
  }
  const problem = await restoreFiles(clone, files, hashes);
  if (problem) throw new RestoreError(`${mutation.id}: ${problem}`);
  if (failure !== undefined) throw failure;
  const result = ran!;
  return {
    id: mutation.id,
    group: mutation.group,
    digest: await mutationDigest(mutation),
    sites: mutation.sites,
    note: mutation.note,
    durationMs: Date.now() - started,
    rows: rows.map((row): SweepRow => {
      if (result.timedOut) return { row: row.id, verdict: "timeout", failing: "" };
      if (plan.unresolved.has(row.id)) return { row: row.id, verdict: "invalid", failing: "" };
      return { row: row.id, ...rowVerdict(result.cases, row.tests) };
    }),
  };
}

/** Runs `work` for every item with one worker per clone; stops handing out items after the first failure. */
async function runPool<T, R>(
  clones: readonly string[],
  items: readonly T[],
  work: (clone: string, item: T) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let next = 0;
  let failure: unknown;
  await Promise.all(clones.map(async (clone) => {
    while (failure === undefined && !aborted) {
      const index = next++;
      if (index >= items.length) return;
      try {
        results[index] = await work(clone, items[index]);
      } catch (error) {
        failure ??= error;
      }
    }
  }));
  if (failure !== undefined) throw failure;
  return results;
}

/** Why `dir` may not be mutated, or `undefined` when it is a usable scratch clone. */
async function refusalFor(dir: string, selected: readonly GuardMutation[]): Promise<string | undefined> {
  const root = await Deno.realPath(projectRoot());
  let real: string;
  try {
    real = await Deno.realPath(dir);
  } catch {
    return `${dir} cannot be resolved`;
  }
  if (isInside(root, real)) return `${dir} is the project tree or inside it`;
  if (isInside(real, root)) return `${dir} contains the project tree`;
  const top = await git(real, ["rev-parse", "--show-toplevel"]);
  if (top.code !== 0) return `${dir} is not a git work tree`;
  if (await Deno.realPath(top.stdout.trim()) !== real) return `${dir} is not the top level of its git work tree`;
  const origin = await git(real, ["remote", "get-url", "origin"]);
  if (origin.code !== 0) return `${dir} has no origin, so it is not a local clone`;
  try {
    if (!(await Deno.stat(origin.stdout.trim())).isDirectory) throw new Error("not a directory");
  } catch {
    return `${dir} origin ${origin.stdout.trim()} is not a local directory`;
  }
  const status = await git(real, ["status", "--porcelain"]);
  if (status.code !== 0 || status.stdout.trim() !== "") return `${dir} is not clean`;
  const manifest = join(real, "src", "__tests__", "conformance-mutations.ts");
  if (readText(manifest) !== readText(join(dirname(fromFileUrl(import.meta.url)), "conformance-mutations.ts"))) {
    return `${dir} has a different conformance-mutations.ts than the running runner`;
  }
  try {
    if (!(await Deno.stat(join(real, "node_modules"))).isDirectory) throw new Error("not a directory");
  } catch {
    return `${dir} has no node_modules (run \`deno install\` there)`;
  }
  for (const file of new Set(selected.flatMap((mutation) => mutation.sites.map((site) => site.file)))) {
    const tracked = await git(real, ["ls-files", "--error-unmatch", `src/${file}`]);
    if (tracked.code !== 0) return `${dir}: src/${file} is not tracked`;
  }
  return undefined;
}

async function sweep(args: Extract<CliArgs, { mode: "sweep" }>): Promise<number> {
  const startedAt = new Date().toISOString();
  const refuse = (reason: string): number => {
    writeErr(`refusing: ${reason}`);
    return 2;
  };

  const known = new Map(GUARD_MUTATIONS.map((mutation) => [mutation.id, mutation]));
  for (const id of args.ids) if (!known.has(id)) return refuse(`unknown mutation id ${id}`);
  const selected = GUARD_MUTATIONS.filter((mutation) =>
    args.ids.includes(mutation.id) || args.groups.includes(mutation.group)
  );
  if (selected.length === 0) return refuse("no mutation is selected");

  const clones: string[] = [];
  for (const dir of args.clones) {
    const reason = await refusalFor(dir, selected);
    if (reason) return refuse(reason);
    clones.push(await Deno.realPath(dir));
  }
  if (new Set(clones).size !== clones.length) return refuse("the same clone is listed twice");
  const heads = await Promise.all(clones.map(async (clone) => (await git(clone, ["rev-parse", "HEAD"])).stdout.trim()));
  if (new Set(heads).size !== 1 || !/^[0-9a-f]{40}$/.test(heads[0])) return refuse("the clones are not at one commit");

  const problems = manifestProblems(
    GUARD_MUTATIONS,
    MUTATION_EXEMPTIONS,
    CONFORMANCE_LEDGER,
    (file) => readText(join(clones[0], "src", file)),
  );
  if (problems.length > 0) return refuse(`the manifest has problems: ${problems.join("; ")}`);

  const out = resolve(args.out);
  const artifacts = join(await Deno.realPath(projectRoot()), ".artifacts");
  const insideProject = isInside(await Deno.realPath(projectRoot()), resolve(out));
  if (insideProject && !isInside(artifacts, out)) return refuse(`--out ${args.out} must be under .artifacts/`);
  if (clones.some((clone) => isInside(clone, out))) return refuse(`--out ${args.out} is inside a clone`);
  await Deno.mkdir(dirname(out), { recursive: true });

  const rowsOf = (mutation: GuardMutation): LedgerEntry[] =>
    mutation.rows.map((id) => CONFORMANCE_LEDGER.find((entry) => entry.id === id)!);

  // Baseline: every cited testcase must exist and pass unmutated.
  const baselineRows = [...new Map(selected.flatMap(rowsOf).map((row) => [row.id, row])).values()];
  const baselinePlan = planFor(clones[0], baselineRows);
  const baseline = await runCited(clones[0], baselinePlan, args.timeoutMs * 3);
  const baselineProblems: string[] = [];
  if (baseline.timedOut) baselineProblems.push("the baseline run timed out");
  for (const row of baselineRows) {
    if (baselinePlan.unresolved.has(row.id)) baselineProblems.push(`${row.id}: a cited test is not declared`);
    for (const ref of row.tests) {
      if (!baseline.cases.some((testcase) => matchesRef(testcase, ref))) {
        baselineProblems.push(`${row.id}: no testcase ran for "${ref.name}" in ${ref.file}`);
      }
    }
  }
  for (const testcase of baseline.cases) {
    if (testcase.failure !== undefined) baselineProblems.push(`failing: ${testcase.file} :: ${testcase.name}`);
  }
  if (baselineProblems.length > 0) {
    writeErr(`baseline failed:\n  ${[...new Set(baselineProblems)].join("\n  ")}`);
    return 1;
  }

  writeOut(`baseline ok: ${baselineRows.length} rows, ${selected.length} mutations, ${clones.length} clones`);
  const results = await runPool(clones, selected, async (clone, mutation) => {
    const result = await runMutation(clone, mutation, rowsOf(mutation), args.timeoutMs);
    writeOut(`ran ${mutation.id} in ${result.durationMs} ms`);
    return result;
  });
  if (aborted) return 130;

  if (args.confirm) {
    const killers = results.filter((result) => result.rows.some((row) => row.verdict === "killed"));
    const reruns = await runPool(clones, killers, async (clone, result) => {
      const mutation = known.get(result.id)!;
      return await runMutation(clone, mutation, rowsOf(mutation), args.timeoutMs);
    });
    if (aborted) return 130;
    for (const [index, result] of killers.entries()) {
      for (const row of result.rows) {
        if (row.verdict !== "killed") continue;
        const again = reruns[index].rows.find((candidate) => candidate.row === row.row);
        if (again?.verdict !== "killed") row.verdict = "flaky";
      }
    }
  }

  const file: SweepResults = {
    runner: "conformance-sweep.ts",
    startedAt,
    finishedAt: new Date().toISOString(),
    cloneHead: heads[0],
    confirmed: args.confirm,
    groups: args.groups,
    ids: args.ids,
    results,
  };
  await Deno.writeTextFile(out, `${JSON.stringify(file, null, 2)}\n`);

  const counts = new Map<string, number>();
  for (const result of results) {
    for (const row of result.rows) {
      writeOut(`${row.verdict} ${row.row} ${result.id}`);
      counts.set(row.verdict, (counts.get(row.verdict) ?? 0) + 1);
    }
  }
  writeOut([...counts].map(([verdict, count]) => `${verdict}: ${count}`).join(", "));
  writeOut(`wrote ${out}`);
  return 0;
}

async function readResults(files: readonly string[]): Promise<SweepResults[] | string> {
  const loaded: SweepResults[] = [];
  for (const file of files) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(await Deno.readTextFile(file));
    } catch (error) {
      return `cannot read ${file}: ${error instanceof Error ? error.message : String(error)}`;
    }
    const candidate = parsed as Partial<SweepResults> | null;
    if (
      !candidate || !Array.isArray(candidate.results) || typeof candidate.finishedAt !== "string" ||
      typeof candidate.cloneHead !== "string"
    ) return `${file} is not a sweep results file`;
    loaded.push({ ...candidate, confirmed: candidate.confirmed === true } as SweepResults);
  }
  return loaded;
}

async function report(args: Extract<CliArgs, { mode: "check" | "verdicts" }>): Promise<number> {
  const results = await readResults(args.files);
  if (typeof results === "string") {
    writeErr(results);
    return 1;
  }
  const digests: Record<string, string> = {};
  for (const mutation of GUARD_MUTATIONS) digests[mutation.id] = await mutationDigest(mutation);

  const coverage = groupCoverage(
    args.group,
    results,
    CONFORMANCE_LEDGER,
    GUARD_MUTATIONS,
    MUTATION_EXEMPTIONS,
    digests,
  );
  const required = requiredRows(args.group, CONFORMANCE_LEDGER).length;
  const ok = coverage.missing.length === 0 && coverage.notKilled.length === 0;
  const current = currentVerdicts(results, GUARD_MUTATIONS, digests);
  const summary = [
    `${args.group}: ${
      required - coverage.missing.length - coverage.notKilled.length
    }/${required} covered MUST rows killed`,
    ...coverage.missing.map((id) => `missing ${id}`),
    ...coverage.notKilled.map((id) => `not killed ${id} (${current.get(id)?.verdict})`),
  ];

  if (args.mode === "check") {
    for (const line of summary) writeOut(line);
    return ok ? 0 : 1;
  }
  for (
    const entry of verdictEntries(
      args.group,
      results,
      CONFORMANCE_LEDGER,
      GUARD_MUTATIONS,
      MUTATION_EXEMPTIONS,
      digests,
    )
  ) {
    writeOut(
      `  { row: ${JSON.stringify(entry.row)}, verdict: "killed", mutation: ${JSON.stringify(entry.mutation)}, digest: ${
        JSON.stringify(entry.digest)
      }, failing: ${JSON.stringify(entry.failing)}, sweptAt: ${JSON.stringify(entry.sweptAt)} },`,
    );
  }
  if (!ok) { for (const line of summary) writeErr(line); }
  return ok ? 0 : 1;
}

async function main(argv: readonly string[]): Promise<number> {
  const args = parseArgs(argv);
  if (typeof args === "string") {
    writeErr(`error: ${args}`);
    return 64;
  }
  if (args.mode !== "sweep") return await report(args);

  const onSignal = (): void => {
    aborted = true;
    for (const child of activeChildren) killChild(child);
  };
  Deno.addSignalListener("SIGINT", onSignal);
  Deno.addSignalListener("SIGTERM", onSignal);
  try {
    return await sweep(args);
  } catch (error) {
    writeErr(
      `${error instanceof RestoreError ? "RESTORE FAILED" : "error"}: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    return 1;
  } finally {
    Deno.removeSignalListener("SIGINT", onSignal);
    Deno.removeSignalListener("SIGTERM", onSignal);
  }
}

if (import.meta.main) Deno.exit(await main(Deno.args));
