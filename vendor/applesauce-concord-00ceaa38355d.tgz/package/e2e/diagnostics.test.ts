import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { stub } from "@std/testing/mock";
import { type Debugger, EventStore } from "applesauce-core";
import { castUser } from "applesauce-core/casts";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import "applesauce-common/casts";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";

import { ConcordClient } from "../src/client/client.ts";
import { type ConcordInviteLink, ConcordInviteManager } from "../src/client/invite-manager.ts";
import { memoryStorage } from "../src/client/storage.ts";
import { COMMUNITY_LIST_FRAGMENT_KIND } from "../src/helpers/community-list-wire.ts";
import { type ConcordDiagnostic, DiagnosticsSink } from "../src/client/diagnostics.ts";
import { RequiredPublishError } from "../src/client/revocation.ts";
import { buildInviteLink, INVITE_BUNDLE_KIND, newInviteToken } from "../src/helpers/invite-bundle.ts";
import { INVITE_LIST_KIND } from "../src/helpers/invite-list.ts";
import { type FakeRelayPool, fakeRelayPool } from "../src/client/__tests__/test-utils.ts";

/** A callable stand-in for a `debug` logger that records every call's arguments. */
function fakeLogger(): { log: Debugger; calls: unknown[][] } {
  const calls: unknown[][] = [];
  const fn = (...args: unknown[]) => {
    calls.push(args);
  };
  const log = Object.assign(fn, { extend: () => log }) as unknown as Debugger;
  return { log, calls };
}

describe("DiagnosticsSink (FND-04, D-07)", () => {
  it("report logs, emits and forwards a typed diagnostic", () => {
    const { log, calls } = fakeLogger();
    const forwarded: ConcordDiagnostic[] = [];
    const sink = new DiagnosticsSink(log, (d) => forwarded.push(d), { communityId: "aa".repeat(32) });
    const seen: ConcordDiagnostic[] = [];
    sink.diagnostics$.subscribe((d) => seen.push(d));

    const error = new Error("boom");
    sink.report({ stage: "mirror-write", error });
    sink.report({ stage: "plane-publish", plane: "control", error, communityId: "bb".repeat(32) });

    expect(calls.length).toBe(2);
    expect(calls[0][0]).toContain("%s");
    expect(calls[0].slice(1)).toEqual(["mirror-write", "boom"]);
    expect(seen.length).toBe(2);
    expect(seen[0]).toEqual({ stage: "mirror-write", error, communityId: "aa".repeat(32) });
    // An explicit communityId is never overridden by the default.
    expect(seen[1].communityId).toBe("bb".repeat(32));
    expect(seen[1].stage === "plane-publish" && seen[1].plane).toBe("control");
    expect(forwarded).toEqual(seen);
  });

  it("emit forwards without logging", () => {
    const { log, calls } = fakeLogger();
    const forwarded: ConcordDiagnostic[] = [];
    const sink = new DiagnosticsSink(log, (d) => forwarded.push(d));
    const seen: ConcordDiagnostic[] = [];
    sink.diagnostics$.subscribe((d) => seen.push(d));

    sink.emit({ stage: "invite-refresh", error: "nope", communityId: "cc".repeat(32) });

    expect(calls.length).toBe(0);
    expect(seen.length).toBe(1);
    expect(forwarded.length).toBe(1);
    // A throwing consumer callback never breaks the library path (T-01-18).
    const throwing = new DiagnosticsSink(log, () => {
      throw new Error("consumer bug");
    });
    expect(() => throwing.emit({ stage: "mirror-read", error: "x" })).not.toThrow();
  });

  it("complete ends diagnostics$", () => {
    const { log } = fakeLogger();
    const sink = new DiagnosticsSink(log);
    let completed = false;
    sink.diagnostics$.subscribe({ complete: () => (completed = true) });

    sink.complete();

    expect(completed).toBe(true);
    expect(() => sink.report({ stage: "mirror-read", error: new Error("late") })).not.toThrow();
    expect(() => sink.emit({ stage: "mirror-read", error: new Error("late") })).not.toThrow();
  });
});

const settle = () => new Promise((r) => setTimeout(r, 200));

/**
 * Serializes everything a diagnostic carries, so a secret anywhere in it shows up: every own property (enumerable or
 * not) of every nested object, array and error, which reaches an error's message, stack, `cause`, `errors` and a
 * `RequiredPublishError`'s `responses` with each response's `message` and transport `error`. Bytes print as hex, the
 * form a token or key takes in diagnostics.
 */
function serializeDeep(value: unknown, seen: Set<unknown> = new Set()): string {
  if (value === null || (typeof value !== "object" && typeof value !== "function")) return String(value);
  if (value instanceof Uint8Array) return bytesToHex(value);
  if (seen.has(value)) return "[cycle]";
  seen.add(value);
  const parts = value instanceof Error ? [value.name, value.message, value.stack ?? ""] : [];
  for (const key of Object.getOwnPropertyNames(value)) {
    parts.push(`${key}=${serializeDeep((value as Record<string, unknown>)[key], seen)}`);
  }
  return parts.join("|");
}

/** A started client over a fake pool, with every diagnostic it emits collected. */
async function running(options: { online?: boolean } = {}) {
  const signer = new PrivateKeySigner(generateSecretKey());
  const fake: FakeRelayPool = fakeRelayPool({ online: options.online });
  const store = new EventStore();
  const client = new ConcordClient({
    signer,
    pool: fake.pool,
    eventStore: store,
    storage: memoryStorage(),
    relays: ["wss://fake"],
    watchDirectInvites: false,
  });
  const diagnostics: ConcordDiagnostic[] = [];
  client.diagnostics$.subscribe((d) => diagnostics.push(d));
  await client.start();
  return {
    client,
    fake,
    diagnostics,
    async teardown() {
      await settle();
      client.stop();
      client.dispose();
      store.dispose();
      await settle();
    },
  };
}

const controlRumor = { kind: 3308, content: "{}", tags: [] as string[][] };

describe("background diagnostics through client and community (FND-04, D-07, D-08)", () => {
  it("client diagnostics$ reports a failed community list save with its stage", async () => {
    const { client, fake, diagnostics, teardown } = await running();
    try {
      fake.setPublishOutcome((event) =>
        event.kind === COMMUNITY_LIST_FRAGMENT_KIND
          ? [{ ok: false, from: "wss://fake", message: "blocked" }]
          : undefined
      );
      await client.createNewCommunity("Saves", "", ["wss://fake"]);
      await settle();
      const saves = diagnostics.filter((d) => d.stage === "community-list-save");
      expect(saves.length).toBeGreaterThan(0);
      expect(saves[0].error).toBeInstanceOf(Error);
    } finally {
      await teardown();
    }
  });

  it("community diagnostics$ reports a failed plane publish with its plane", async () => {
    const { client, fake, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Planes", "", ["wss://fake"]);
      const seen: ConcordDiagnostic[] = [];
      community.diagnostics$.subscribe((d) => seen.push(d));
      fake.setPublishOutcome((event) => event.kind === 1059 ? new Error("socket closed") : undefined);
      await community.publishToPlane({ plane: "control" }, controlRumor, { plaintext: true });
      await settle();
      const failure = seen.find((d) => d.stage === "plane-publish");
      expect(failure?.stage === "plane-publish" && failure.plane).toBe("control");
      expect(failure?.communityId).toBe(community.communityId);
      expect((failure?.error as Error).message).toBe("socket closed");
    } finally {
      await teardown();
    }
  });

  it("community diagnostics$ reports a plane publish that no relay accepted (D-22)", async () => {
    const { client, fake, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Refused", "", ["wss://fake"]);
      const seen: ConcordDiagnostic[] = [];
      community.diagnostics$.subscribe((d) => seen.push(d));
      // Non-vacuity: an accepted publish reports nothing.
      await community.publishToPlane({ plane: "control" }, controlRumor, { plaintext: true });
      await settle();
      expect(seen.filter((d) => d.stage === "plane-publish")).toHaveLength(0);

      // A real RelayPool resolves refusals, timeouts and closed sockets as `ok: false` responses; it does not reject.
      const refused = [{ ok: false, from: "wss://fake", message: "blocked" }];
      fake.setPublishOutcome((event) => event.kind === 1059 ? refused : undefined);
      await community.publishToPlane({ plane: "control" }, controlRumor, { plaintext: true });
      await settle();
      const failures = seen.filter((d) => d.stage === "plane-publish");
      expect(failures).toHaveLength(1);
      expect(failures[0].stage === "plane-publish" && failures[0].plane).toBe("control");
      expect(failures[0].communityId).toBe(community.communityId);
      expect(failures[0].error).toBeInstanceOf(RequiredPublishError);
      expect((failures[0].error as RequiredPublishError).stage).toBe("plane-publish");
      expect((failures[0].error as RequiredPublishError).responses).toEqual(refused);
    } finally {
      await teardown();
    }
  });

  it("background invite bundle and Invite List publishes that no relay accepted are reported (D-22)", async () => {
    const { client, fake, diagnostics, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Unacked", "", ["wss://fake"]);
      fake.setPublishOutcome((event) =>
        event.kind === INVITE_BUNDLE_KIND || event.kind === INVITE_LIST_KIND
          ? [{ ok: false, from: "wss://fake", message: "blocked" }]
          : undefined
      );
      const before = diagnostics.length;
      const link = await community.createInvite({ base: "https://x.io" });
      await settle();
      const seen = diagnostics.slice(before);
      const bundle = seen.filter((d) => d.stage === "invite-bundle-publish");
      expect(bundle).toHaveLength(1);
      expect(bundle[0].key).toBe(link.signerPubkey);
      expect((bundle[0].error as RequiredPublishError).stage).toBe("invite-bundle-publish");
      const list = seen.filter((d) => d.stage === "invite-list-publish");
      expect(list).toHaveLength(1);
      expect(list[0].error).toBeInstanceOf(RequiredPublishError);
      // The walk reaches each error's relay responses: the refusal message is there, the token is not.
      expect(serializeDeep(bundle[0])).toContain("blocked");
      for (const diagnostic of seen) {
        expect(serializeDeep(diagnostic).includes(link.token)).toBe(false);
      }
    } finally {
      await teardown();
    }
  });

  it("the token-leak walk finds a secret in an error's responses, transport errors and cause", () => {
    // Non-vacuity: each placement below is missed by `String(error)`, which keeps only the name and message.
    const token = bytesToHex(generateSecretKey());
    const placements = [
      new RequiredPublishError("invite-bundle-publish", [{ ok: false, from: "wss://fake", message: token }]),
      new RequiredPublishError("invite-bundle-publish", [{ ok: false, from: "wss://fake", error: new Error(token) }]),
      new RequiredPublishError("invite-bundle-publish", [], { cause: new Error(token) }),
      new RequiredPublishError("invite-bundle-publish", [], { cause: { event: { content: token } } }),
      new RequiredPublishError("invite-bundle-publish", [], { cause: { token: hexToBytes(token) } }),
    ];
    for (const error of placements) {
      const diagnostic: ConcordDiagnostic = { stage: "invite-bundle-publish", key: "aa".repeat(32), error };
      expect(JSON.stringify({ ...diagnostic, error: String(diagnostic.error) }).includes(token)).toBe(false);
      expect(serializeDeep(diagnostic).includes(token)).toBe(true);
    }
    const clean: ConcordDiagnostic = {
      stage: "invite-bundle-publish",
      error: new RequiredPublishError("invite-bundle-publish", [{ ok: false, from: "wss://fake", message: "blocked" }]),
    };
    expect(serializeDeep(clean).includes(token)).toBe(false);
  });

  // Both failure branches of every awaited or fire-and-forget publish that reports its own stage: the pool rejects
  // (reported raw), or it resolves with no accepting relay (reported as that stage's RequiredPublishError).
  const refusal = [{ ok: false, from: "wss://fake", message: "blocked" }];
  const failWith = (kind: number, outcome: "reject" | "refuse") => (event: NostrEvent) =>
    event.kind !== kind ? undefined : outcome === "reject" ? new Error("socket closed") : refusal;
  const expectStageFailures = (
    seen: ConcordDiagnostic[],
    stage: ConcordDiagnostic["stage"],
    outcome: "reject" | "refuse",
  ): ConcordDiagnostic[] => {
    const failures = seen.filter((d) => d.stage === stage);
    expect(failures.length).toBeGreaterThan(0);
    for (const failure of failures) {
      if (outcome === "reject") {
        expect((failure.error as Error).message).toBe("socket closed");
      } else {
        expect(failure.error).toBeInstanceOf(RequiredPublishError);
        expect((failure.error as RequiredPublishError).stage).toBe(stage);
        expect((failure.error as RequiredPublishError).responses).toEqual(refusal);
      }
    }
    return failures;
  };

  /** Rotates a private channel with every gift wrap failing as `outcome` says. */
  const rekeyCase = async (outcome: "reject" | "refuse") => {
    const { client, fake, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Rekey", "", ["wss://fake"]);
      const channelId = await community.createChannel("secret", { private: true });
      await settle();
      const seen: ConcordDiagnostic[] = [];
      community.diagnostics$.subscribe((d) => seen.push(d));
      fake.setPublishOutcome(failWith(1059, outcome));
      await community.rotateChannel(channelId, { keep: [] });
      await settle();
      const failures = expectStageFailures(seen, "channel-rekey-publish", outcome);
      for (const failure of failures) expect(failure.key).toBe(channelId);
    } finally {
      await teardown();
    }
  };

  /** Grants a private channel with the Direct Invite wrap failing as `outcome` says. */
  const grantCase = async (outcome: "reject" | "refuse") => {
    const { client, fake, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Grant", "", ["wss://fake"]);
      const channelId = await community.createChannel("granted", { private: true });
      await settle();
      const seen: ConcordDiagnostic[] = [];
      community.diagnostics$.subscribe((d) => seen.push(d));
      fake.setPublishOutcome(failWith(1059, outcome));
      await community.grantChannelAccess(channelId, getPublicKey(generateSecretKey()));
      await settle();
      expect(expectStageFailures(seen, "channel-grant-publish", outcome)).toHaveLength(1);
    } finally {
      await teardown();
    }
  };

  /** Re-posts a minted invite bundle with the re-post failing as `outcome` says. */
  const refreshCase = async (outcome: "reject" | "refuse") => {
    const { client, fake, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Refresh", "", ["wss://fake"]);
      const link = await community.createInvite({ base: "https://x.io" });
      await settle();
      const seen: ConcordDiagnostic[] = [];
      community.diagnostics$.subscribe((d) => seen.push(d));
      fake.setPublishOutcome(failWith(INVITE_BUNDLE_KIND, outcome));
      await community.refreshInviteBundles([link]);
      await settle();
      const failures = expectStageFailures(seen, "invite-bundle-refresh-publish", outcome);
      expect(failures).toHaveLength(1);
      expect(failures[0].key).toBe(link.signerPubkey);
      expect(seen.filter((d) => d.stage === "invite-bundle-refresh-skipped")).toHaveLength(0);
      for (const diagnostic of seen) expect(serializeDeep(diagnostic).includes(link.token)).toBe(false);
    } finally {
      await teardown();
    }
  };

  it("a channel rekey wrap the pool rejects is reported as channel-rekey-publish", () => rekeyCase("reject"));
  it("a channel rekey wrap the pool refuses is reported as channel-rekey-publish", () => rekeyCase("refuse"));
  it("a channel grant the pool rejects is reported as channel-grant-publish", () => grantCase("reject"));
  it("a channel grant the pool refuses is reported as channel-grant-publish", () => grantCase("refuse"));
  it("a bundle re-post the pool rejects is reported as invite-bundle-refresh-publish", () => refreshCase("reject"));
  it("a bundle re-post the pool refuses is reported as invite-bundle-refresh-publish", () => refreshCase("refuse"));

  it("client diagnostics$ forwards community diagnostics with their community id", async () => {
    const { client, fake, diagnostics, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Forward", "", ["wss://fake"]);
      fake.setPublishOutcome((event) => event.kind === 1059 ? new Error("socket closed") : undefined);
      const before = diagnostics.length;
      await community.publishToPlane({ plane: "control" }, controlRumor, { plaintext: true });
      await settle();
      const forwarded = diagnostics.slice(before).filter((d) => d.stage === "plane-publish");
      expect(forwarded.length).toBe(1);
      expect(forwarded[0].communityId).toBe(community.communityId);
    } finally {
      await teardown();
    }
  });

  it("an incomplete start read reports community-list-read", async () => {
    const { diagnostics, teardown } = await running({ online: false });
    try {
      const reads = diagnostics.filter((d) => d.stage === "community-list-read");
      expect(reads.length).toBe(1);
      expect(reads[0].error).toBeInstanceOf(Error);
    } finally {
      await teardown();
    }
  });

  it("an offline save reports community-list-write-blocked once", async () => {
    const { client, diagnostics, teardown } = await running({ online: false });
    try {
      await client.createNewCommunity("Offline", "", ["wss://fake"]);
      await client.saveCommunityList();
      await client.saveCommunityList();
      await settle();
      expect(diagnostics.filter((d) => d.stage === "community-list-write-blocked").length).toBe(1);
      expect(diagnostics.filter((d) => d.stage === "community-list-save").length).toBe(0);
    } finally {
      await teardown();
    }
  });

  it("diagnostics never carry invite tokens", async () => {
    const { client, teardown } = await running();
    try {
      const community = await client.createNewCommunity("Tokens", "", ["wss://fake"]);
      const seen: ConcordDiagnostic[] = [];
      community.diagnostics$.subscribe((d) => seen.push(d));
      const token = bytesToHex(generateSecretKey());
      const signerSk = bytesToHex(generateSecretKey());
      const link: ConcordInviteLink = {
        token,
        signerSk,
        signerPubkey: getPublicKey(hexToBytes(signerSk)),
        communityId: community.communityId,
        url: "concord://unused",
        channels: ["ff".repeat(32)],
        createdAt: 1,
        revoked: false,
      };
      await community.refreshInviteBundles([link]);
      const skipped = seen.filter((d) => d.stage === "invite-bundle-refresh-skipped");
      expect(skipped.length).toBe(1);
      expect(skipped[0].key).toBe(link.signerPubkey);
      for (const diagnostic of seen) {
        const serialized = serializeDeep(diagnostic);
        expect(serialized.includes(token)).toBe(false);
        expect(serialized.includes(signerSk)).toBe(false);
      }
    } finally {
      await teardown();
    }
  });

  it("diagnostics$ completes on dispose, not on stop", async () => {
    const { client, teardown } = await running();
    let clientCompleted = false;
    let communityCompleted = false;
    try {
      const community = await client.createNewCommunity("Complete", "", ["wss://fake"]);
      client.diagnostics$.subscribe({ complete: () => (clientCompleted = true) });
      community.diagnostics$.subscribe({ complete: () => (communityCompleted = true) });
      client.stop();
      expect(clientCompleted).toBe(false);
      expect(communityCompleted).toBe(true);
      client.dispose();
      expect(clientCompleted).toBe(true);
    } finally {
      await teardown();
    }
  });

  it("no background failure is printed to the console", async () => {
    const warn = stub(console, "warn");
    const { client, fake, teardown } = await running();
    try {
      fake.setPublishOutcome((event) => new Error(`rejected ${event.kind}`));
      const community = await client.createNewCommunity("Quiet", "", ["wss://fake"]);
      await community.publishToPlane({ plane: "control" }, controlRumor, { plaintext: true });
      await settle();
      expect(warn.calls.length).toBe(0);
    } finally {
      warn.restore();
      await teardown();
    }
  });
});

/** A started invite manager over a fake pool whose Invite List publishes can be refused or rejected. */
async function inviteManager() {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const fake = fakeRelayPool();
  const store = new EventStore();
  const diagnostics: ConcordDiagnostic[] = [];
  const invites = new ConcordInviteManager({
    signer,
    pool: fake.pool,
    eventStore: store,
    relays: ["wss://fake"],
    getCommunity: () => undefined,
    onDiagnostic: (diagnostic) => diagnostics.push(diagnostic),
  });
  const user = castUser(pubkey, store);
  await invites.start(user);
  let attempts = 0;
  let outcome: "accept" | "refuse" | "reject" = "accept";
  fake.setPublishOutcome((event) => {
    if (event.kind !== INVITE_LIST_KIND) return undefined;
    attempts++;
    if (outcome === "refuse") return [{ ok: false, from: "wss://fake", message: "blocked" }];
    if (outcome === "reject") return new Error("socket closed");
    return undefined;
  });
  const linkSk = generateSecretKey();
  const token = newInviteToken();
  const link: ConcordInviteLink = {
    token: bytesToHex(token),
    signerSk: bytesToHex(linkSk),
    signerPubkey: getPublicKey(linkSk),
    communityId: "ab".repeat(32),
    url: buildInviteLink("https://app.example", getPublicKey(linkSk), token, ["wss://fake"]),
    createdAt: 1,
    revoked: false,
  };
  return {
    invites,
    user,
    link,
    diagnostics,
    setOutcome(next: "accept" | "refuse" | "reject") {
      outcome = next;
    },
    attempts: () => attempts,
    /** The Invite Lists a relay accepted, in publish order. */
    accepted: () => fake.published.filter((event) => event.kind === INVITE_LIST_KIND),
    async open(event: NostrEvent): Promise<{ entries: { token: string }[]; tombstones: { token: string }[] }> {
      return JSON.parse(await signer.nip44!.decrypt(pubkey, event.content));
    },
    async teardown() {
      await settle();
      invites.dispose();
      store.dispose();
    },
  };
}

describe("Invite List saves that no relay accepted (D-23)", () => {
  it("the next save republishes an Invite List that no relay accepted, tombstones included", async () => {
    const h = await inviteManager();
    try {
      h.setOutcome("refuse");
      await h.invites.record(h.link);
      await settle();
      expect(h.attempts()).toBe(1);
      expect(h.diagnostics.filter((d) => d.stage === "invite-list-publish")).toHaveLength(1);
      expect(h.invites.dirty$.value).toBe(true);
      expect(h.accepted()).toHaveLength(0);
      // Nothing is retried on its own: the next attempt waits for a save.
      await settle();
      expect(h.attempts()).toBe(1);

      h.setOutcome("accept");
      await h.invites.save();
      await settle();
      expect(h.attempts()).toBe(2);
      expect(h.accepted()).toHaveLength(1);
      expect((await h.open(h.accepted()[0])).entries.map((entry) => entry.token)).toEqual([h.link.token]);
      expect(h.invites.dirty$.value).toBe(false);
      // Non-vacuity: once a relay accepted the list, an unchanged save publishes nothing.
      await h.invites.save();
      await settle();
      expect(h.attempts()).toBe(2);

      h.setOutcome("refuse");
      await h.invites.tombstone(h.link);
      await settle();
      expect(h.attempts()).toBe(3);
      expect(h.diagnostics.filter((d) => d.stage === "invite-list-publish")).toHaveLength(2);
      expect(h.invites.dirty$.value).toBe(true);

      h.setOutcome("accept");
      await h.invites.save();
      await settle();
      expect(h.attempts()).toBe(4);
      expect(h.accepted()).toHaveLength(2);
      const republished = await h.open(h.accepted()[1]);
      expect(republished.tombstones.map((tombstone) => tombstone.token)).toEqual([h.link.token]);
      expect(h.invites.dirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("a save after stop and start republishes an Invite List whose publish the pool rejected", async () => {
    const h = await inviteManager();
    try {
      h.setOutcome("reject");
      await h.invites.record(h.link);
      await settle();
      const failures = h.diagnostics.filter((d) => d.stage === "invite-list-publish");
      expect(failures).toHaveLength(1);
      expect((failures[0].error as Error).message).toBe("socket closed");

      // The unaccepted copy is still the newest list in the store; reading it back must not count as published.
      h.invites.stop();
      await h.invites.start(h.user);
      expect(h.invites.get(h.link.token)?.token).toBe(h.link.token);
      expect(h.invites.dirty$.value).toBe(true);

      h.setOutcome("accept");
      await h.invites.save();
      await settle();
      expect(h.attempts()).toBe(2);
      expect(h.accepted()).toHaveLength(1);
      expect((await h.open(h.accepted()[0])).entries.map((entry) => entry.token)).toEqual([h.link.token]);
    } finally {
      await h.teardown();
    }
  });
});
