// Phase 4 community-level expiration tests (CORD-08 §2 and §3): forged outer tags first, then purge reach and cache
// hydration in later plans. A wrap's `expiration` tag is a relay hint; only the signed rumor's tag decides expiry.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { firstValueFrom } from "rxjs";
import { AsyncRumorStore, EventStore, RumorStore } from "applesauce-core";
import { ChatMessageFactory } from "applesauce-common/factories";
import { getEventHash, type NostrEvent, type Rumor } from "applesauce-core/helpers/event";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";

import { channelGroupKey } from "../src/helpers/crypto.ts";
import {
  channelEpochOf,
  type ConcordKeys,
  deriveConcordKeys,
  planeKeyFor,
  rollForwardChannel,
} from "../src/helpers/keys.ts";
import type { ChannelKey, ChannelMetadata } from "../src/types.ts";
import { heldChannelPlanes } from "../src/client/expiration-purge.ts";
import { decodeWrap } from "../src/helpers/gift-wrap.ts";
import { isAuthorDeleted } from "../src/helpers/author-deletion.ts";
import { FakeTime } from "@std/testing/time";
import { bindToChannel } from "../src/operations/channel.ts";
import { sealRumor, toRumor, wrapSeal } from "../src/operations/gift-wrap.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import { rumorExpiration } from "../src/helpers/expiration.ts";
import { ConcordCommunity, type ConcordCommunityOptions } from "../src/client/community.ts";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import { type DutyReport, DutyScope } from "../src/client/lifecycle.ts";
import { type ConcordStoreFactory, memoryStorage } from "../src/client/storage.ts";
import {
  type AsyncMemoryDatabase,
  asyncMemoryDatabase,
  type FakeRelayPool,
  fakeRelayPool,
  ManualClock,
} from "../src/client/__tests__/test-utils.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));

/** An owner's community on a fake pool, started with its genesis published and settled. */
async function ownerCommunity(options: Partial<ConcordCommunityOptions> = {}): Promise<{
  community: ConcordCommunity;
  net: FakeRelayPool;
  store: EventStore;
  signer: PrivateKeySigner;
  pubkey: string;
  generalId: string;
}> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const net = fakeRelayPool();
  const genesis = await createLegacyCommunity({ ownerPubkey: pubkey, name: "Test", relays: ["wss://fake"] });
  const store = new EventStore();
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material: genesis.material,
    signer,
    pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    ...options,
  });
  await community.start();
  for (const rumor of genesis.controlRumors) {
    await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
  }
  for (const rumor of genesis.guestbookRumors) await community.publishToPlane({ plane: "guestbook" }, rumor, {});
  await settle();
  return { community, net, store, signer, pubkey, generalId: genesis.generalChannelId };
}

/**
 * A Chat wrap sealed by the signer for the channel plane, with an optional signed rumor expiration and an optional
 * outer wrap expiration set independently of it (the forgery).
 */
async function forgedWrap(
  community: ConcordCommunity,
  signer: ISigner,
  channelId: string,
  text: string,
  opts: { rumorExpiration?: number; outerExpiration?: number; kind?: number; tags?: string[][] },
): Promise<NostrEvent> {
  const keys = (community as unknown as { keys: ConcordKeys }).keys;
  const key = planeKeyFor(keys, { plane: "channel", channelId });
  const epoch = channelEpochOf(keys, channelId);
  const now = Math.floor(Date.now() / 1000);
  const createdAt = opts.rumorExpiration !== undefined ? opts.rumorExpiration - 600 : now;
  const template = await bindToChannel(channelId, epoch)({
    kind: opts.kind ?? 9,
    content: text,
    tags: [
      ...(opts.tags ?? []),
      ...(opts.rumorExpiration !== undefined ? [["expiration", String(opts.rumorExpiration)]] : []),
    ],
    created_at: createdAt,
  });
  const rumor = await toRumor(signer)(template);
  const seal = await sealRumor(key.convKey, signer)(rumor);
  return wrapSeal(key.sk, key.convKey, { expiration: opts.outerExpiration })(seal);
}

async function finish(community: ConcordCommunity, store: EventStore): Promise<void> {
  community.dispose();
  store.dispose();
  await settle();
}

describe("forged outer expiration tags (CORD-08 §2, D-06)", () => {
  it("a live rumor under a forged past outer tag is retained and displayed", async () => {
    const { community, store, signer, generalId } = await ownerCommunity();
    try {
      const wrap = await forgedWrap(community, signer, generalId, "still alive", { outerExpiration: 1 });
      await (community as unknown as { onWrap(e: NostrEvent): Promise<void> }).onWrap(wrap);
      await settle();

      // Non-vacuity: with the store's own add result trusted again (the addWrap helper reverted) the upstream store
      // refuses the wrap for its past outer tag and both assertions below fail.
      const stored = await community.channelStore(generalId).getTimeline([{ kinds: [9] }]);
      expect(stored.map((r) => r.content)).toContain("still alive");
      const shown = await firstValueFrom(community.channelTimeline(generalId, [{ kinds: [9] }]));
      expect(shown.map((r) => r.content)).toContain("still alive");
    } finally {
      await finish(community, store);
    }
  });

  it("an expired rumor under an absent or future outer tag is refused at ingest", async () => {
    const { community, store, signer, generalId } = await ownerCommunity();
    try {
      const past = Math.floor(Date.now() / 1000) - 60;
      const future = Math.floor(Date.now() / 1000) + 3600;
      const absent = await forgedWrap(community, signer, generalId, "expired, no outer tag", {
        rumorExpiration: past,
      });
      const hinted = await forgedWrap(community, signer, generalId, "expired, future outer tag", {
        rumorExpiration: past,
        outerExpiration: future,
      });
      const onWrap = (community as unknown as { onWrap(e: NostrEvent): Promise<void> }).onWrap.bind(community);
      await onWrap(absent);
      await onWrap(hinted);
      await settle();

      const stored = await community.channelStore(generalId).getTimeline([{ kinds: [9] }]);
      const contents = stored.map((r) => r.content);
      expect(contents).not.toContain("expired, no outer tag");
      expect(contents).not.toContain("expired, future outer tag");
    } finally {
      await finish(community, store);
    }
  });

  it("a control edition under a past outer tag stays refused, so a Refounding still recovers every head seal", async () => {
    const { community, store, pubkey } = await ownerCommunity({ pinUpkeep: false });
    try {
      const engine = community as unknown as { onWrap(e: NostrEvent): Promise<void>; keys: ConcordKeys };
      // Capture the owner's own metadata edition without its local echo, then rewrap its plaintext seal (signatures
      // survive a rewrap) under a past outer tag, as any holder of the control plane key can.
      let captured: NostrEvent | undefined;
      engine.onWrap = async (event) => {
        captured = event;
      };
      try {
        await community.editMetadata({ name: "Renamed" });
      } finally {
        Reflect.deleteProperty(community, "onWrap");
      }
      const key = planeKeyFor(engine.keys, { plane: "control" });
      const seal = decodeWrap(captured!, key.convKey)!.seal!;
      await engine.onWrap(await wrapSeal(key.sk, key.convKey, { expiration: 1 })(seal));
      await settle();

      // Non-vacuity: with the outer-tag fallback on every plane, the edition folds into state while its wrap is never
      // stored, and refound() throws "original control seal unavailable".
      expect(community.state$.value.metadata?.name).toBe("Test");
      await community.refound({ keep: [pubkey] });
    } finally {
      await finish(community, store);
    }
  });
});

/** A `ConcordStoreFactory` that persists every channel plane in a shared in-memory async database. */
interface PersistentStores {
  /** The factory to hand to a community; each `channel:` key gets an `AsyncRumorStore` over one database per key. */
  factory: ConcordStoreFactory;
  /** The database behind a channel's persistent store, created on first use. */
  database(channelId: string): AsyncMemoryDatabase;
  /** Every plane key the factory has been asked for, in order. */
  requested: string[];
  /** Channel ids whose database reads reject while listed, as a failing disk does. */
  failing: Set<string>;
}

function persistentStores(): PersistentStores {
  const databases = new Map<string, AsyncMemoryDatabase>();
  const requested: string[] = [];
  const failing = new Set<string>();
  const database = (channelId: string): AsyncMemoryDatabase => {
    let db = databases.get(channelId);
    if (!db) {
      db = asyncMemoryDatabase();
      databases.set(channelId, db);
    }
    return db;
  };
  const factory: ConcordStoreFactory = (_communityId, planeKey) => {
    requested.push(planeKey);
    if (!planeKey.startsWith("channel:")) return new RumorStore();
    const channelId = planeKey.slice("channel:".length);
    const db = database(channelId);
    const reads = {
      ...db,
      getTimeline: (filters: Parameters<AsyncMemoryDatabase["getTimeline"]>[0]) =>
        failing.has(channelId) ? Promise.reject(new Error("disk read failed")) : db.getTimeline(filters),
    };
    return new AsyncRumorStore({ database: reads });
  };
  return { factory, database, requested, failing };
}

/** Swap the community's private duty scope for one on `clock`, as the pin and list tests do. */
function useDutyClock(community: ConcordCommunity, clock: ManualClock): void {
  const internals = community as unknown as {
    duties: DutyScope;
    diagnostics: { reportDuty(report: DutyReport): void };
  };
  internals.duties.dispose();
  internals.duties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report) });
}

/** A duty clock set to `seconds` Unix seconds. */
const clockAt = (seconds: number): ManualClock => new ManualClock({ now: seconds * 1000 });

const nowSeconds = (): number => Math.floor(Date.now() / 1000);

/**
 * Dispose `first` and start a new engine over the same material, signer, pool, store factory and EventStore, as an app
 * restart does. `serve` picks which published wraps the pool still serves: every one, or only those outside the chat
 * planes (so the rebuilt engine folds the channels without ever receiving their messages).
 */
async function restarted(
  first: { community: ConcordCommunity; net: FakeRelayPool; signer: ISigner; pubkey: string },
  options: { storeFactory: ConcordStoreFactory; eventStore: EventStore; serve: "all" | "non-channel" },
): Promise<ConcordCommunity> {
  const material = first.community.material;
  const planes = (first.community as unknown as { keys: ConcordKeys }).keys.planes;
  const served = first.net.published.filter((wrap) =>
    options.serve === "all" || planes.get(wrap.pubkey)?.type !== "channel"
  );
  first.community.dispose();
  first.net.setEvents(served);
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material,
    signer: first.signer,
    pubkey: first.pubkey,
    pool: first.net.pool,
    eventStore: options.eventStore,
    relays: ["wss://fake"],
    storeFactory: options.storeFactory,
    pinUpkeep: false,
  });
  await community.start();
  await settle();
  return community;
}

/** A kind-9 rumor bound to a channel, as an earlier session would have persisted it. */
async function persistedRumor(
  pubkey: string,
  channelId: string,
  epoch: number,
  text: string,
  created: number,
  expiration?: number,
): Promise<Rumor> {
  const template = await bindToChannel(channelId, epoch, created * 1000)({
    kind: 9,
    content: text,
    tags: expiration !== undefined ? [["expiration", String(expiration)]] : [],
    created_at: created,
  });
  const rumor = { ...template, pubkey };
  return { ...rumor, id: getEventHash(rumor) } as Rumor;
}

/** Send a chat message and return the rumor id. */
const say = (community: ConcordCommunity, channelId: string, text: string): Promise<string> =>
  community.sendEvent(channelId, ChatMessageFactory.create(text));

/** Contents of the kind-9 rumors a channel store retains. */
async function contentsOf(community: ConcordCommunity, channelId: string): Promise<string[]> {
  const rumors = await community.channelStore(channelId).getTimeline([{ kinds: [9] }]);
  return rumors.map((r) => r.content);
}

/** Run `body` with `Date.now` moved `ms` ahead, so the default clock and the duty clock both see a later time. */
async function withTimeAhead<T>(ms: number, body: () => Promise<T>): Promise<T> {
  const real = Date.now;
  Date.now = () => real() + ms;
  try {
    return await body();
  } finally {
    Date.now = real;
  }
}

describe("purge reach (EXP-01, CORD-08 §3)", () => {
  it("purge sweeps a persistent channel store never opened this session", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = new EventStore();
    const community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "non-channel" });
    try {
      const { generalId, pubkey } = first;
      const db = stores.database(generalId);
      const expired = await persistedRumor(
        pubkey,
        generalId,
        1,
        "expired earlier",
        nowSeconds() - 600,
        nowSeconds() - 60,
      );
      const live = await persistedRumor(pubkey, generalId, 1, "still live", nowSeconds() - 5);
      db.mem.add(expired);
      db.mem.add(live);
      stores.requested.length = 0;
      // Precondition: this engine has not opened the channel's store (the rows came from "an earlier session").
      expect(stores.requested).not.toContain(`channel:${generalId}`);

      // Non-vacuity: a purge that walks only stores already opened this session leaves the expired row in place.
      const removed = await community.purgeExpiredMessages();
      expect(removed).toBeGreaterThanOrEqual(1);
      expect(db.mem.hasEvent(expired.id)).toBe(false);
      expect(db.mem.hasEvent(live.id)).toBe(true);
    } finally {
      community.dispose();
      eventStore.dispose();
      first.store.dispose();
      await settle();
    }
  });

  it("purge judges expiry on the injected duty clock (D-07)", async () => {
    const stores = persistentStores();
    const { community, store, generalId } = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    try {
      await community.setMessageExpiration(60);
      await settle();
      const id = await say(community, generalId, "short lived");
      const [rumor] = await community.channelStore(generalId).getTimeline([{ ids: [id] }]);
      const expiry = rumorExpiration(rumor)!;
      expect(expiry).toBeGreaterThan(nowSeconds());

      useDutyClock(community, clockAt(nowSeconds()));
      expect(await community.purgeExpiredMessages()).toBe(0);
      expect(await contentsOf(community, generalId)).toContain("short lived");

      // Non-vacuity: a purge reading `Date.now` directly sees the real time (before the expiry) and removes nothing.
      useDutyClock(community, clockAt(expiry + 120));
      expect(await community.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
      expect(await contentsOf(community, generalId)).not.toContain("short lived");
    } finally {
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("purge sweeps the store of a private channel the user left (D-18)", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = first.store;
    let community: ConcordCommunity | undefined;
    try {
      await first.community.setMessageExpiration(60);
      await settle();
      const id = await first.community.createChannel("secret", { private: true });
      await settle();
      await say(first.community, id, "left behind");
      await settle();
      await first.community.leaveChannel(id);
      const db = stores.database(id);
      // Precondition: the message was persisted before leaving, so the store the left channel keeps holds it.
      expect((await db.getTimeline({ kinds: [9] })).map((r) => r.content)).toContain("left behind");
      const expiry = rumorExpiration((await db.getTimeline({ kinds: [9] }))[0])!;

      community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "all" });
      useDutyClock(community, clockAt(expiry + 120));
      // Non-vacuity: a purge that skips channels whose key is no longer held leaves this row in the database.
      expect(await community.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
      expect((await db.getTimeline({ kinds: [9] })).map((r) => r.content)).not.toContain("left behind");
    } finally {
      community?.dispose();
      first.community.dispose();
      eventStore.dispose();
      await settle();
    }
  });

  it("purge removes expired wraps under an older private epoch after a restart (D-02, D-18)", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = first.store;
    let community: ConcordCommunity | undefined;
    try {
      await first.community.setMessageExpiration(60);
      await settle();
      const id = await first.community.createChannel("rotating", { private: true });
      await settle();
      const planes = (first.community as unknown as { keys: ConcordKeys }).keys.planes;
      const sent = await say(first.community, id, "epoch one message");
      await settle();
      const oldWrap = first.net.published.filter((wrap) => {
        const info = planes.get(wrap.pubkey);
        return info?.type === "channel" && info.channelId === id;
      }).at(-1)!;
      expect(oldWrap).toBeDefined();
      const [rumor] = await first.community.channelStore(id).getTimeline([{ ids: [sent] }]);
      const expiry = rumorExpiration(rumor)!;

      await first.community.rotateChannel(id, { keep: [first.pubkey] });
      await settle();

      community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "all" });
      // Precondition: a fresh derive holds only the current private epoch, while the shared EventStore keeps the wrap.
      const fresh = (community as unknown as { keys: ConcordKeys }).keys.planes;
      expect(fresh.has(oldWrap.pubkey)).toBe(false);
      expect(eventStore.hasEvent(oldWrap.id)).toBe(true);

      useDutyClock(community, clockAt(expiry + 120));
      // Non-vacuity: decrypting only with `keys.planes` cannot read the epoch-1 wrap, so it stays in the EventStore.
      await community.purgeExpiredMessages();
      expect(eventStore.hasEvent(oldWrap.id)).toBe(false);
    } finally {
      community?.dispose();
      first.community.dispose();
      eventStore.dispose();
      await settle();
    }
  });

  it("purge never opens a deleted channel's store (D-03)", async () => {
    const stores = persistentStores();
    const { community, store } = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    try {
      const id = await community.createChannel("gone");
      await community.deleteChannel(id);
      await settle();
      stores.requested.length = 0;
      await community.purgeExpiredMessages();
      // Non-vacuity: sweeping every channel ever created (not just folded non-deleted ones) requests this key.
      expect(stores.requested).not.toContain(`channel:${id}`);
    } finally {
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("a failing channel store is reported as expiration-purge and the sweep continues", async () => {
    const stores = persistentStores();
    const { community, store, generalId, pubkey } = await ownerCommunity({
      storeFactory: stores.factory,
      pinUpkeep: false,
    });
    const reports: ConcordDiagnostic[] = [];
    const sub = community.diagnostics$.subscribe((report) => reports.push(report));
    try {
      const sideId = await community.createChannel("side");
      await settle();
      const expired = await persistedRumor(pubkey, sideId, 1, "expired side", nowSeconds() - 600, nowSeconds() - 60);
      stores.database(sideId).mem.add(expired);
      // Open the failing channel's store before reads start failing, then make its disk fail.
      community.channelStore(generalId);
      // Its open-time sweep reads the disk at once; let it finish so the failure below is the purge's own read.
      await settle();
      stores.failing.add(generalId);

      // A purge that lets one failing store reject the whole sweep never reaches the other channel.
      const removed = await community.purgeExpiredMessages().catch(() => -1);
      stores.failing.delete(generalId);
      expect(removed).toBeGreaterThanOrEqual(1);
      expect(stores.database(sideId).mem.hasEvent(expired.id)).toBe(false);
      const failures = reports.filter((r) => (r.stage as string) === "expiration-purge");
      expect(failures.some((r) => (r as { key?: string }).key === generalId)).toBe(true);
    } finally {
      sub.unsubscribe();
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("a store factory that throws for one channel is reported with its id and the other channels are still swept", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const sideId = await first.community.createChannel("side");
    await settle();
    let broken = "";
    const factory: ConcordStoreFactory = (communityId, planeKey) => {
      if (planeKey === `channel:${broken}`) throw new Error("store factory failed");
      return stores.factory(communityId, planeKey);
    };
    const eventStore = new EventStore();
    const community = await restarted(first, { storeFactory: factory, eventStore, serve: "non-channel" });
    const reports: ConcordDiagnostic[] = [];
    const sub = community.diagnostics$.subscribe((report) => reports.push(report));
    try {
      const { generalId, pubkey } = first;
      const folded = community.state$.value.channels.map((channel) => channel.channel_id);
      expect(folded).toEqual(expect.arrayContaining([generalId, sideId]));
      // Channel ids are random, so the fold order of these two is too. The factory fails for the one that folds first, so
      // the other is always the one a sweep that stops at the failure would miss.
      const [brokenId, sweptId] = folded.filter((id) => id === generalId || id === sideId);
      const expired = await persistedRumor(
        pubkey,
        sweptId,
        1,
        "expired survivor",
        nowSeconds() - 600,
        nowSeconds() - 60,
      );
      stores.database(sweptId).mem.add(expired);
      broken = brokenId;

      // Non-vacuity: opening every store in one call lets the throw for the first channel skip the sweep of the second.
      const removed = await community.purgeExpiredMessages();
      expect(removed).toBeGreaterThanOrEqual(1);
      expect(stores.database(sweptId).mem.hasEvent(expired.id)).toBe(false);
      const failures = reports.filter((r) => (r.stage as string) === "expiration-purge");
      expect(failures.some((r) => (r as { key?: string }).key === brokenId)).toBe(true);
    } finally {
      sub.unsubscribe();
      community.dispose();
      eventStore.dispose();
      first.store.dispose();
      await settle();
    }
  });

  it("purge removes retained wraps by the signed rumor alone, whatever the outer tag says (D-06)", async () => {
    const { community, store, signer, generalId } = await ownerCommunity();
    try {
      const past = nowSeconds() - 60;
      const hour = nowSeconds() + 3600;
      const noTag = await forgedWrap(community, signer, generalId, "expired, no outer tag", { rumorExpiration: past });
      const hinted = await forgedWrap(community, signer, generalId, "expired, hour-ahead outer tag", {
        rumorExpiration: past,
        outerExpiration: hour,
      });
      const live = await forgedWrap(community, signer, generalId, "live, untagged", {});
      // The wraps go straight into the shared EventStore, as a wrap cache retained from an earlier session would be.
      for (const wrap of [noTag, hinted, live]) expect(store.add(structuredClone(wrap))).not.toBeNull();

      // Non-vacuity: a purge that trusted the outer tag (or skipped wraps without one) would keep the first two.
      await community.purgeExpiredMessages();
      expect(store.hasEvent(noTag.id)).toBe(false);
      expect(store.hasEvent(hinted.id)).toBe(false);
      expect(store.hasEvent(live.id)).toBe(true);
    } finally {
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("timer changes are not retroactive: only messages stamped under a timer expire (CORD-08 §2)", async () => {
    const { community, store, generalId } = await ownerCommunity();
    try {
      await say(community, generalId, "M1 no timer");
      await community.setMessageExpiration(60);
      await settle();
      await say(community, generalId, "M2 under a timer");
      await community.setMessageExpiration(0);
      await settle();
      await say(community, generalId, "M3 timer cleared");
      await settle();

      // Non-vacuity: judging by the folded timer value instead of each message's own tag would expire M1 and M3 too.
      await withTimeAhead(120_000, () => community.purgeExpiredMessages());
      const contents = await contentsOf(community, generalId);
      expect(contents).toContain("M1 no timer");
      expect(contents).not.toContain("M2 under a timer");
      expect(contents).toContain("M3 timer cleared");
      const notices = await community.channelStore(generalId).getTimeline([{ kinds: [1740] }]);
      expect(notices.length).toBeGreaterThanOrEqual(2);
    } finally {
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("purge after dispose resolves 0 and opens no store", async () => {
    const stores = persistentStores();
    const { community, store } = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    try {
      community.dispose();
      stores.requested.length = 0;
      // Non-vacuity: without the disposed guard a sweep re-creates stores through the factory after teardown.
      expect(await community.purgeExpiredMessages()).toBe(0);
      expect(stores.requested).toEqual([]);
    } finally {
      store.dispose();
      await settle();
    }
  });

  it("the wrap sweep plane map reaches every held private epoch from material alone (D-18)", async () => {
    const owner = bytesToHex(generateSecretKey()).slice(0, 64);
    const genesis = await createLegacyCommunity({ ownerPubkey: owner, name: "Held", relays: ["wss://fake"] });
    const channel: ChannelKey = {
      id: bytesToHex(generateSecretKey()),
      key: bytesToHex(generateSecretKey()),
      epoch: 1,
      name: "secret",
    };
    const rolled = rollForwardChannel(channel, bytesToHex(generateSecretKey()), 2);
    const material = { ...genesis.material, channels: [rolled] };
    const listing = [{ channel_id: channel.id, name: "secret", private: true }] as unknown as ChannelMetadata[];
    // What a restart does: a fresh derive holds only the current private epoch in `keys.planes`.
    const keys = deriveConcordKeys(material, listing);
    const pk = (key: string, epoch: number) => channelGroupKey(hexToBytes(key), hexToBytes(channel.id), epoch).pk;
    expect(keys.planes.has(pk(channel.key, 1))).toBe(false);

    const planes = heldChannelPlanes(keys, new Set([channel.id]));
    // Non-vacuity: reading `keys.planes` alone misses epoch 1, which is where an old private wrap lives.
    expect(planes.has(pk(channel.key, 1))).toBe(true);
    expect(planes.has(pk(rolled.key, 2))).toBe(true);
    expect([...planes.values()].every((info) => info.type === "channel" && info.channelId === channel.id)).toBe(true);
    expect(planes.size).toBe(2);
    expect(heldChannelPlanes(keys, new Set()).size).toBe(0);
  });
});

/** Any rumor bound to a channel, as an earlier session would have persisted it. */
async function persistedOf(
  pubkey: string,
  channelId: string,
  epoch: number,
  created: number,
  template: { kind: number; content: string; tags: string[][] },
): Promise<Rumor> {
  const bound = await bindToChannel(channelId, epoch, created * 1000)({ ...template, created_at: created });
  const rumor = { ...bound, pubkey };
  return { ...rumor, id: getEventHash(rumor) } as Rumor;
}

/** Tears down a restarted community with its stores, as the other persistent-store tests do. */
async function closeAll(
  community: ConcordCommunity | undefined,
  first: { community: ConcordCommunity; store: EventStore },
  eventStore: EventStore,
): Promise<void> {
  community?.dispose();
  first.community.dispose();
  eventStore.dispose();
  first.store.dispose();
  await settle();
}

describe("cache hydration (EXP-02, CORD-08 §3)", () => {
  it("an expired cached rumor is never displayed and is removed from the database when its store opens", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = new EventStore();
    const community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "non-channel" });
    try {
      const { generalId, pubkey } = first;
      const db = stores.database(generalId);
      const expired = await persistedRumor(
        pubkey,
        generalId,
        1,
        "expired earlier",
        nowSeconds() - 600,
        nowSeconds() - 60,
      );
      const live = await persistedRumor(pubkey, generalId, 1, "still live", nowSeconds() - 5);
      db.mem.add(expired);
      db.mem.add(live);
      stores.requested.length = 0;
      // Precondition: this engine has not opened the channel's store yet (the rows came from "an earlier session").
      expect(stores.requested).not.toContain(`channel:${generalId}`);

      const emissions: string[][] = [];
      const sub = community.channelTimeline(generalId, [{ kinds: [9] }]).subscribe((rumors) =>
        emissions.push(rumors.map((r) => r.id))
      );
      await settle();
      sub.unsubscribe();

      expect(emissions.length).toBeGreaterThan(0);
      expect(emissions.every((ids) => !ids.includes(expired.id))).toBe(true);
      expect(emissions.at(-1)).toContain(live.id);
      // Non-vacuity: without the open-time sweep the expired row stays in the database.
      expect(db.mem.hasEvent(expired.id)).toBe(false);
      expect(db.mem.hasEvent(live.id)).toBe(true);
    } finally {
      await closeAll(community, first, eventStore);
    }
  });

  it("live cached rumors and timer notices survive the open-time sweep", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = new EventStore();
    const community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "non-channel" });
    try {
      const { generalId, pubkey } = first;
      const db = stores.database(generalId);
      const live = await persistedRumor(
        pubkey,
        generalId,
        1,
        "live with a future tag",
        nowSeconds() - 5,
        nowSeconds() + 600,
      );
      const plain = await persistedRumor(pubkey, generalId, 1, "no expiration at all", nowSeconds() - 4);
      const notice = await persistedOf(pubkey, generalId, 1, nowSeconds() - 3, {
        kind: 1740,
        content: "",
        tags: [["timer", String(nowSeconds() - 100)]],
      });
      for (const rumor of [live, plain, notice]) db.mem.add(rumor);

      community.channelStore(generalId);
      await settle();

      expect(db.mem.hasEvent(live.id)).toBe(true);
      expect(db.mem.hasEvent(plain.id)).toBe(true);
      expect(db.mem.hasEvent(notice.id)).toBe(true);
    } finally {
      await closeAll(community, first, eventStore);
    }
  });

  it("a private channel's cached expired rumor is removed when its engine opens the store", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = first.store;
    let community: ConcordCommunity | undefined;
    try {
      const id = await first.community.createChannel("secret", { private: true });
      await settle();
      const db = stores.database(id);
      const expired = await persistedRumor(
        first.pubkey,
        id,
        1,
        "expired private",
        nowSeconds() - 600,
        nowSeconds() - 60,
      );
      db.mem.add(expired);

      community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "all" });
      await settle();

      // Non-vacuity: without the open-time sweep the private engine opens the store and leaves the row on disk.
      expect(db.mem.hasEvent(expired.id)).toBe(false);
    } finally {
      community?.dispose();
      first.community.dispose();
      eventStore.dispose();
      await settle();
    }
  });

  it("purge counts rows the open-time sweep removed", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = new EventStore();
    const community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "non-channel" });
    try {
      const { generalId, pubkey } = first;
      const db = stores.database(generalId);
      const expired = await persistedRumor(
        pubkey,
        generalId,
        1,
        "expired earlier",
        nowSeconds() - 600,
        nowSeconds() - 60,
      );
      db.mem.add(expired);

      // Non-vacuity: if purge stopped awaiting a pending open-time sweep, this count would be 0.
      expect(await community.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
      expect(db.mem.hasEvent(expired.id)).toBe(false);
    } finally {
      await closeAll(community, first, eventStore);
    }
  });

  it("the open-time sweep runs once per store and never after dispose", async () => {
    const inner = persistentStores();
    // Counts the expiry sweep's full-timeline reads. The observed-authors fold reads the same filter when a store joins
    // it, so a read counts as a sweep only when it comes from the expiration module.
    const sweeps = new Map<string, number>();
    const factory: ConcordStoreFactory = (communityId, planeKey) => {
      const store = inner.factory(communityId, planeKey);
      if (!planeKey.startsWith("channel:")) return store;
      const original = store.getTimeline.bind(store);
      store.getTimeline = ((filters: Parameters<typeof original>[0]) => {
        if (JSON.stringify(filters) === "[{}]" && new Error().stack?.includes("expiration-purge.ts")) {
          sweeps.set(planeKey, (sweeps.get(planeKey) ?? 0) + 1);
        }
        return original(filters);
      }) as typeof store.getTimeline;
      return store;
    };
    const { community, store } = await ownerCommunity({ storeFactory: factory, pinUpkeep: false });
    try {
      sweeps.clear();
      const fresh = "ab".repeat(32);
      community.channelStore(fresh);
      community.channelStore(fresh);
      await settle();
      // Non-vacuity: without the open-time sweep there is no read; if it ran per call there would be two.
      expect(sweeps.get(`channel:${fresh}`)).toBe(1);

      community.dispose();
      const late = "cd".repeat(32);
      community.channelStore(late);
      await settle();
      expect(sweeps.get(`channel:${late}`) ?? 0).toBe(0);
    } finally {
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("a failing open-time sweep is reported as expiration-purge with the channel id and never thrown", async () => {
    const inner = persistentStores();
    // Only the sweep's own read fails: the observed-authors fold reads the same store and would otherwise error too.
    const factory: ConcordStoreFactory = (communityId, planeKey) => {
      const store = inner.factory(communityId, planeKey);
      if (!planeKey.startsWith("channel:")) return store;
      const original = store.getTimeline.bind(store);
      store.getTimeline =
        ((filters: Parameters<typeof original>[0]) =>
          new Error().stack?.includes("expiration-purge.ts")
            ? Promise.reject(new Error("disk read failed"))
            : original(filters)) as typeof store.getTimeline;
      return store;
    };
    const { community, store } = await ownerCommunity({ storeFactory: factory, pinUpkeep: false });
    const reports: ConcordDiagnostic[] = [];
    const sub = community.diagnostics$.subscribe((report) => reports.push(report));
    try {
      const opened = "ef".repeat(32);
      community.channelStore(opened);
      await settle();
      const failures = reports.filter((r) => (r.stage as string) === "expiration-purge");
      expect(failures.map((r) => (r as { key?: string }).key)).toEqual([opened]);
    } finally {
      sub.unsubscribe();
      community.dispose();
      store.dispose();
      await settle();
    }
  });

  it("retained deletion tombstones survive purge and hydration and a purged target is never resurrected (D-15)", async () => {
    const stores = persistentStores();
    const first = await ownerCommunity({ storeFactory: stores.factory, pinUpkeep: false });
    const eventStore = new EventStore();
    let community: ConcordCommunity | undefined;
    try {
      const { community: owner, generalId, pubkey } = first;
      const db = stores.database(generalId);
      await owner.setMessageExpiration(60);
      await settle();
      const targetId = await say(owner, generalId, "target T");
      const [target] = await owner.channelStore(generalId).getTimeline([{ ids: [targetId] }]);
      const expiry = rumorExpiration(target)!;
      await owner.deleteMessage(generalId, target);
      await owner.setMessageExpiration(0);
      await settle();
      const keptId = await say(owner, generalId, "message U, no timer");
      const [kept] = await owner.channelStore(generalId).getTimeline([{ ids: [keptId] }]);
      expect(rumorExpiration(kept)).toBeUndefined();
      await owner.deleteMessage(generalId, kept);
      await settle();
      const forged = await persistedOf(pubkey, generalId, 1, nowSeconds() - 10, {
        kind: 5,
        content: "",
        tags: [["e", keptId], ["k", "9"], ["expiration", "1"]],
      });
      db.mem.add(forged);
      const tombstones = async (): Promise<number> => (await db.getTimeline({ kinds: [5] })).length;
      expect(await tombstones()).toBe(3);

      useDutyClock(owner, clockAt(expiry + 120));
      expect(await owner.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
      expect(db.mem.hasEvent(targetId)).toBe(false);
      expect(await tombstones()).toBe(3);

      // Reopen the store in a rebuilt engine: the open-time sweep must keep every deletion request.
      const keys = (owner as unknown as { keys: ConcordKeys }).keys;
      const targetWrap = first.net.published.find((wrap) => {
        const plane = keys.planes.get(wrap.pubkey);
        return plane?.type === "channel" && decodeWrap(structuredClone(wrap), plane.convKey)?.rumor.id === targetId;
      })!;
      expect(targetWrap).toBeDefined();

      community = await restarted(first, { storeFactory: stores.factory, eventStore, serve: "non-channel" });
      community.channelStore(generalId);
      await settle();
      expect(await tombstones()).toBe(3);
      expect(db.mem.hasEvent(keptId)).toBe(true);

      // Re-deliver the purged target's wrap after its expiry: the receive boundary refuses it.
      const time = new FakeTime(expiry * 1000 + 120_000);
      try {
        await (community as unknown as { onWrap(e: NostrEvent): Promise<void> }).onWrap(structuredClone(targetWrap));
      } finally {
        time.restore();
      }
      await settle();
      expect(db.mem.hasEvent(targetId)).toBe(false);
      expect(isAuthorDeleted(kept, await db.getTimeline({ kinds: [5] }))).toBe(true);
    } finally {
      await closeAll(community, first, eventStore);
    }
  });
});

describe("the timer and its notices (CORD-08 §1, §4)", () => {
  it("a malformed message_expiration in the folded metadata reads as off, so a send carries no expiration (CORD-08 §1)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    const expirationTags = (tags: string[][]) => tags.filter((tag) => tag[0] === "expiration");
    const sendAndRead = async (text: string) => {
      const id = await say(community, generalId, text);
      const [rumor] = await community.channelStore(generalId).getTimeline([{ ids: [id] }]);
      return { rumor, wrap: net.published.at(-1)! };
    };
    try {
      // Non-vacuity: a valid timer in the same metadata stamps the rumor and its outer wrap.
      await community.editMetadata({ message_expiration: 60 });
      await settle();
      const stamped = await sendAndRead("under a valid timer");
      expect(expirationTags(stamped.rumor.tags)).toEqual([["expiration", String(stamped.rumor.created_at + 60)]]);
      expect(expirationTags(stamped.wrap.tags)).toEqual(expirationTags(stamped.rumor.tags));

      for (const garbage of ["60", true, 1.5, -60, [60], {}]) {
        await community.editMetadata({ message_expiration: garbage as unknown as number });
        await settle();
        // The fold keeps what the editor wrote; only the reader decides that it means off.
        expect(community.state$.value.metadata?.message_expiration).toEqual(garbage);
        const sent = await sendAndRead("under a malformed timer");
        expect({ garbage, rumor: expirationTags(sent.rumor.tags), wrap: expirationTags(sent.wrap.tags) }).toEqual({
          garbage,
          rumor: [],
          wrap: [],
        });
      }
    } finally {
      await finish(community, store);
    }
  });

  it("setMessageExpiration posts one timer notice into each channel whose key the actor holds (CORD-08 §4)", async () => {
    const { community, store, generalId } = await ownerCommunity({ pinUpkeep: false });
    try {
      const publicId = await community.createChannel("lounge");
      const heldId = await community.createChannel("held", { private: true });
      const leftId = await community.createChannel("left", { private: true });
      await settle();
      await community.leaveChannel(leftId);
      await settle();

      // Non-vacuity of the skip: posting into the channel whose key was given up would throw, so it must resolve.
      const outcome = await community.setMessageExpiration(60).then(() => "resolved", (error) => String(error));
      expect(outcome).toBe("resolved");
      await settle();

      for (const id of [generalId, publicId, heldId]) {
        const notices = await community.channelStore(id).getTimeline([{ kinds: [1740] }]);
        expect(notices).toHaveLength(1);
        const tags = notices[0].tags;
        expect(tags).toContainEqual(["channel", id]);
        expect(tags.some((tag) => tag[0] === "epoch")).toBe(true);
        expect(tags.filter((tag) => tag[0] === "timer")).toEqual([["timer", "60"]]);
        // The notice documents the policy and must not be erased by it.
        expect(tags.filter((tag) => tag[0] === "expiration")).toEqual([]);
      }

      // Turning the timer off announces "0" in the same channels.
      await community.setMessageExpiration(0);
      await settle();
      for (const id of [generalId, publicId, heldId]) {
        const notices = await community.channelStore(id).getTimeline([{ kinds: [1740] }]);
        expect(notices.flatMap((notice) => notice.tags.filter((tag) => tag[0] === "timer")).map((tag) => tag[1]).sort())
          .toEqual(["0", "60"]);
      }
    } finally {
      await finish(community, store);
    }
  });

  it("a timer notice is displayed only when its author holds MANAGE_METADATA in the fold (CORD-08 §4)", async () => {
    const { community, store, pubkey, generalId } = await ownerCommunity();
    try {
      await community.setMessageExpiration(60);
      await settle();
      const stranger = new PrivateKeySigner(generateSecretKey());
      const forged = await forgedWrap(community, stranger, generalId, "", {
        kind: 1740,
        tags: [["timer", "0"]],
      });
      await (community as unknown as { onWrap(e: NostrEvent): Promise<void> }).onWrap(forged);
      await settle();

      // Precondition: both notices are retained, so only the display gate separates them.
      const retained = await community.channelStore(generalId).getTimeline([{ kinds: [1740] }]);
      expect(retained.map((notice) => notice.pubkey).sort()).toEqual([pubkey, await stranger.getPublicKey()].sort());
      const shown = await firstValueFrom(community.channelTimeline(generalId, [{ kinds: [1740] }]));
      expect(shown.map((notice) => notice.pubkey)).toEqual([pubkey]);
    } finally {
      await finish(community, store);
    }
  });
});
