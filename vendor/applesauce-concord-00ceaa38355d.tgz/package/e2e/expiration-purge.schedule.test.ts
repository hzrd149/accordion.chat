// CORD-08 §3 opt-in periodic purge on owned duties (D-09..D-12, D-20, D-21): off by default, validated before anything is
// armed, one sweep at once then one per interval, never two at once, stopped by every lifecycle edge, reported on
// diagnostics$ when it fails and, on the client, applied to every current, later-joined and rebuilt community.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { AsyncRumorStore, EventStore, RumorStore } from "applesauce-core";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";

import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import type { ConcordKeys } from "../src/helpers/keys.ts";
import { ConcordCommunity, type ConcordCommunityOptions } from "../src/client/community.ts";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import { CommunityExpiration, type CommunityExpirationHost } from "../src/client/expiration-purge.ts";
import { type DutyReport, DutyScope } from "../src/client/lifecycle.ts";
import { type ConcordRumorStore, type ConcordStoreFactory, memoryStorage } from "../src/client/storage.ts";
import { ConcordClientDisposedError } from "../src/client/community-list-sync.ts";
import {
  type AsyncMemoryDatabase,
  asyncMemoryDatabase,
  deferred,
  type FakeRelayPool,
  fakeRelayPool,
  ManualClock,
} from "../src/client/__tests__/test-utils.ts";
import { harness, settle as settleLong, until, vault } from "../src/client/__tests__/community-list-client-fixtures.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));
const SLOT = "expiration-purge";
const nowSeconds = (): number => Math.floor(Date.now() / 1000);

/** Persistent channel stores whose reads a test can hold, fail or count, as a slow or failing disk would. */
interface HookedStores {
  factory: ConcordStoreFactory;
  database(channelId: string): AsyncMemoryDatabase;
  /** Reads of each channel store so far. */
  reads: Map<string, number>;
  /** Runs before every channel store read; a returned rejection fails that read, a pending promise holds it. */
  hook?: (channelId: string) => Promise<void> | void;
}

function hookedStores(): HookedStores {
  const databases = new Map<string, AsyncMemoryDatabase>();
  const state: HookedStores = {
    reads: new Map(),
    database(channelId) {
      let db = databases.get(channelId);
      if (!db) databases.set(channelId, db = asyncMemoryDatabase());
      return db;
    },
    factory: (_communityId, planeKey) => {
      if (!planeKey.startsWith("channel:")) return new RumorStore();
      const channelId = planeKey.slice("channel:".length);
      const db = state.database(channelId);
      return new AsyncRumorStore({
        database: {
          ...db,
          getTimeline: async (filters: Parameters<AsyncMemoryDatabase["getTimeline"]>[0]) => {
            state.reads.set(channelId, (state.reads.get(channelId) ?? 0) + 1);
            await state.hook?.(channelId);
            return db.getTimeline(filters);
          },
        },
      });
    },
  };
  return state;
}

/** An owner's community on a fake pool, started with its genesis published and settled. */
async function ownerCommunity(options: Partial<ConcordCommunityOptions> = {}): Promise<{
  community: ConcordCommunity;
  net: FakeRelayPool;
  store: EventStore;
  signer: PrivateKeySigner;
  pubkey: string;
  generalId: string;
}> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const net = fakeRelayPool();
  const genesis = await createLegacyCommunity({ ownerPubkey: pubkey, name: "Test", relays: ["wss://fake"] });
  const store = new EventStore();
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material: genesis.material,
    signer,
    pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    pinUpkeep: false,
    ...options,
  });
  await community.start();
  for (const rumor of genesis.controlRumors) {
    await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
  }
  for (const rumor of genesis.guestbookRumors) await community.publishToPlane({ plane: "guestbook" }, rumor, {});
  await settle();
  return { community, net, store, signer, pubkey, generalId: genesis.generalChannelId };
}

interface Internals {
  duties: DutyScope;
  diagnostics: { reportDuty(report: DutyReport): void };
  expiry: { purge(): Promise<number> };
}

/** Swap the community's private duty scope for one on a fresh ManualClock set to the real time. */
function useDutyClock(community: ConcordCommunity): { clock: ManualClock; duties: DutyScope } {
  const internals = community as unknown as Internals;
  const clock = new ManualClock({ now: Date.now() });
  internals.duties.dispose();
  const duties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report) });
  internals.duties = duties;
  return { clock, duties };
}

/** Counts every internal purge call and fails the ones `fail` names, delegating the rest to the real purge. */
function watchPurge(community: ConcordCommunity, fail?: (call: number) => Error | undefined): { calls: number } {
  const expiry = (community as unknown as Internals).expiry;
  const original = expiry.purge.bind(expiry);
  const state = { calls: 0 };
  expiry.purge = () => {
    state.calls++;
    const error = fail?.(state.calls);
    return error ? Promise.reject(error) : original();
  };
  return state;
}

/** An expired kind-9 row an earlier session persisted. */
function expiredRow(pubkey: string, channelId: string, text: string): Rumor {
  const rumor = {
    kind: 9,
    pubkey,
    content: text,
    created_at: nowSeconds() - 600,
    tags: [["expiration", String(nowSeconds() - 60)], ["h", channelId]],
  };
  return { ...rumor, id: getEventHash(rumor) } as Rumor;
}

/** Fire what is due on the manual clock, then let the released sweep finish. */
async function advance(clock: ManualClock, duties: DutyScope, ms: number): Promise<void> {
  clock.tick(ms);
  await duties.idle();
  await new Promise((r) => setTimeout(r, 20));
  await duties.idle();
}

async function finish(community: ConcordCommunity, store: EventStore): Promise<void> {
  community.dispose();
  store.dispose();
  await settle();
}

describe("community.schedulePurge (EXP-03, D-09..D-12)", () => {
  it("no purge is scheduled by default", async () => {
    const { community, store } = await ownerCommunity();
    try {
      // The engine as built and started arms nothing: a schedule armed at construction or start would have run its first
      // sweep by now and left its next tick pending, before the manual clock below replaces the scope.
      expect((community as unknown as Internals).duties.slotPending(SLOT)).toBe(false);
      const { clock, duties } = useDutyClock(community);
      const purge = watchPurge(community);
      await advance(clock, duties, 3_600_000);
      expect(duties.slotPending(SLOT)).toBe(false);
      expect(purge.calls).toBe(0);
    } finally {
      await finish(community, store);
    }
  });

  it("schedulePurge rejects an invalid interval before arming anything", async () => {
    const { community, store } = await ownerCommunity();
    try {
      const { duties } = useDutyClock(community);
      const before = duties.pending;
      for (const bad of [0, 59_999, 60_000.5, NaN, Infinity, -1, 2_147_483_648]) {
        expect(() => community.schedulePurge({ intervalMs: bad })).toThrow(RangeError);
      }
      expect(() => community.schedulePurge({ intervalMs: "60000" as unknown as number })).toThrow(TypeError);
      expect(duties.pending).toBe(before);
      expect(duties.slotPending(SLOT)).toBe(false);

      for (const good of [undefined, {}, { intervalMs: 60_000 }, { intervalMs: 2_147_483_647 }]) {
        const stop = community.schedulePurge(good);
        expect(typeof stop).toBe("function");
        stop();
      }
      expect(duties.slotPending(SLOT)).toBe(false);
    } finally {
      await finish(community, store);
    }
  });

  it("schedulePurge sweeps at once, then once per interval", async () => {
    const stores = hookedStores();
    const { community, store, pubkey, generalId } = await ownerCommunity({ storeFactory: stores.factory });
    try {
      community.channelStore(generalId);
      await settle();
      const { clock, duties } = useDutyClock(community);
      const purge = watchPurge(community);
      const expired = expiredRow(pubkey, generalId, "gone soon");
      stores.database(generalId).mem.add(expired);

      const stop = community.schedulePurge({ intervalMs: 60_000 });
      // Nothing runs until the duty clock fires the zero-delay first tick.
      expect(purge.calls).toBe(0);
      await advance(clock, duties, 0);
      expect(purge.calls).toBe(1);
      expect(stores.database(generalId).mem.hasEvent(expired.id)).toBe(false);

      await advance(clock, duties, 59_999);
      expect(purge.calls).toBe(1);
      await advance(clock, duties, 1);
      expect(purge.calls).toBe(2);
      await advance(clock, duties, 60_000);
      expect(purge.calls).toBe(3);
      stop();
      expect(duties.pending).toBe(0);
    } finally {
      await finish(community, store);
    }
  });

  it("a schedule armed before the engine is live sweeps again once sync reaches live", async () => {
    const stores = hookedStores();
    const first = await ownerCommunity({ storeFactory: stores.factory });
    // Serve only the non-channel wraps, so nothing but a purge opens the channel store of the rebuilt engine.
    const planes = (first.community as unknown as { keys: ConcordKeys }).keys.planes;
    first.net.setEvents(first.net.published.filter((wrap) => planes.get(wrap.pubkey)?.type !== "channel"));
    first.community.dispose();
    const expired = expiredRow(first.pubkey, first.generalId, "left over");
    stores.database(first.generalId).mem.add(expired);
    const store = new EventStore();
    const community = new ConcordCommunity({
      storage: memoryStorage(),
      material: first.community.material,
      signer: first.signer,
      pubkey: first.pubkey,
      pool: first.net.pool,
      eventStore: store,
      relays: ["wss://fake"],
      storeFactory: stores.factory,
      pinUpkeep: false,
    });
    try {
      const { clock, duties } = useDutyClock(community);
      const purge = watchPurge(community);
      community.schedulePurge({ intervalMs: 60_000 });
      await advance(clock, duties, 0);
      expect(purge.calls).toBe(1);
      // The first sweep ran before sync folded any channel, so the row is still on disk.
      expect(stores.database(first.generalId).mem.hasEvent(expired.id)).toBe(true);

      await community.start();
      await settle();
      // Non-vacuity: without a sweep on reaching live the row stays until the next interval.
      await advance(clock, duties, 0);
      expect(purge.calls).toBe(2);
      expect(stores.database(first.generalId).mem.hasEvent(expired.id)).toBe(false);
      await advance(clock, duties, 59_999);
      expect(purge.calls).toBe(2);
      await advance(clock, duties, 1);
      expect(purge.calls).toBe(3);
    } finally {
      await finish(community, store);
      first.store.dispose();
    }
  });

  it("a scheduled sweep never overlaps another sweep", async () => {
    const stores = hookedStores();
    const { community, store, generalId } = await ownerCommunity({ storeFactory: stores.factory });
    try {
      community.channelStore(generalId);
      await settle();
      const { clock, duties } = useDutyClock(community);
      const purge = watchPurge(community);
      const held = deferred<void>();
      stores.hook = () => held.promise;
      stores.reads.clear();

      const stop = community.schedulePurge({ intervalMs: 60_000 });
      clock.tick(0);
      await new Promise((r) => setTimeout(r, 50));
      expect(stores.reads.get(generalId)).toBe(1);
      expect(purge.calls).toBe(1);

      // Non-vacuity: a tick armed before the sweep ended would call the purge a second time here.
      clock.tick(60_000 * 5);
      await new Promise((r) => setTimeout(r, 50));
      expect(stores.reads.get(generalId)).toBe(1);
      expect(purge.calls).toBe(1);
      const manual = community.purgeExpiredMessages();
      await new Promise((r) => setTimeout(r, 50));
      expect(stores.reads.get(generalId)).toBe(1);

      stores.hook = undefined;
      held.resolve();
      await manual;
      await duties.idle();
      expect(duties.slotPending(SLOT)).toBe(true);
      const readsAfter = stores.reads.get(generalId)!;
      await advance(clock, duties, 60_000);
      expect(stores.reads.get(generalId)).toBeGreaterThan(readsAfter);
      stop();
    } finally {
      await finish(community, store);
    }
  });

  it("a fresh sweep waiting on a running sweep starts none once its schedule stopped meanwhile", async () => {
    const stops: Array<[string, (stop: () => void, expiry: CommunityExpiration, duties: DutyScope) => void]> = [
      ["the disposer", (stop) => stop()],
      // The replacement is stopped at once, so only the waiting fresh tick of the first schedule could still sweep.
      ["a replacing schedule", (_stop, expiry) => expiry.schedule({ intervalMs: 600_000 })()],
      ["dissolution", (_stop, _expiry, duties) => duties.suspend("dissolved")],
    ];
    const results: Array<{ label: string; reads: number; pending: number }> = [];
    for (const [label, stopWith] of stops) {
      const clock = new ManualClock({ now: Date.now() });
      const duties = new DutyScope({ clock });
      const held = deferred<void>();
      let reads = 0;
      const blocked = {
        getTimeline: async () => {
          reads++;
          await held.promise;
          return [];
        },
        remove: async () => {},
      } as unknown as ConcordRumorStore;
      const host = {
        disposed: () => duties.disposed,
        channels: () => [{ channel_id: "a" }],
        channelStores: (ids: readonly string[]) => ids.map(() => ({ store: blocked })),
        keys: () => ({ planes: new Map(), material: { channels: [] } }),
        eventStore: { getTimeline: async () => [] },
        duties: () => duties,
        diagnostics: { report: () => {} },
        forgetExpired: () => {},
      } as unknown as CommunityExpirationHost;
      const expiry = new CommunityExpiration(host);
      const stop = expiry.schedule({ intervalMs: 60_000 });
      clock.tick(0);
      await new Promise((r) => setTimeout(r, 10));
      expect(reads).toBe(1);
      // The engine reaches live while the first sweep is held: the fresh tick fires and waits on that sweep.
      expiry.live();
      clock.tick(0);
      await new Promise((r) => setTimeout(r, 10));
      stopWith(stop, expiry, duties);
      held.resolve();
      await duties.idle();
      await new Promise((r) => setTimeout(r, 10));
      results.push({ label, reads, pending: duties.pending });
      duties.dispose();
    }
    // Non-vacuity: without the re-check after the wait, each stopped schedule sweeps the store a second time.
    expect(results).toEqual(stops.map(([label]) => ({ label, reads: 1, pending: 0 })));
  });

  it("the disposer stops the schedule and a second schedule replaces the first", async () => {
    const { community, store } = await ownerCommunity();
    try {
      const { clock, duties } = useDutyClock(community);
      const purge = watchPurge(community);

      const first = community.schedulePurge({ intervalMs: 60_000 });
      const second = community.schedulePurge({ intervalMs: 120_000 });
      await advance(clock, duties, 0);
      expect(purge.calls).toBe(1);

      // The replaced schedule's disposer does nothing: the second schedule keeps running.
      first();
      expect(duties.slotPending(SLOT)).toBe(true);
      await advance(clock, duties, 60_000);
      expect(purge.calls).toBe(1);
      await advance(clock, duties, 60_000);
      expect(purge.calls).toBe(2);

      second();
      expect(duties.slotPending(SLOT)).toBe(false);
      expect(duties.pending).toBe(0);
      await advance(clock, duties, 1_000_000);
      expect(purge.calls).toBe(2);
    } finally {
      await finish(community, store);
    }
  });

  it("dispose and dissolution stop the schedule", async () => {
    const owner = await ownerCommunity();
    const other = await ownerCommunity();
    try {
      const a = useDutyClock(owner.community);
      const purge = watchPurge(owner.community);
      owner.community.schedulePurge({ intervalMs: 60_000 });
      await advance(a.clock, a.duties, 0);
      expect(purge.calls).toBe(1);

      await owner.community.dissolve();
      await settle();
      expect(a.duties.slotPending(SLOT)).toBe(false);
      await advance(a.clock, a.duties, 600_000);
      expect(purge.calls).toBe(1);
      // Dissolution refuses a new schedule, while a manual purge still works.
      owner.community.schedulePurge();
      await advance(a.clock, a.duties, 600_000);
      expect(a.duties.slotPending(SLOT)).toBe(false);
      expect(purge.calls).toBe(1);
      expect(typeof await owner.community.purgeExpiredMessages()).toBe("number");

      const b = useDutyClock(other.community);
      const otherPurge = watchPurge(other.community);
      other.community.schedulePurge({ intervalMs: 60_000 });
      await advance(b.clock, b.duties, 0);
      expect(otherPurge.calls).toBe(1);
      other.community.dispose();
      expect(b.duties.pending).toBe(0);
      // Unlike the client's, a community call after dispose arms nothing and returns a disposer that does nothing.
      const stop = other.community.schedulePurge();
      expect(b.duties.pending).toBe(0);
      expect(() => stop()).not.toThrow();
      await advance(b.clock, b.duties, 600_000);
      expect(otherPurge.calls).toBe(1);
    } finally {
      await finish(owner.community, owner.store);
      await finish(other.community, other.store);
    }
  });

  it("a failed scheduled sweep is reported as expiration-purge and the next tick retries", async () => {
    const stores = hookedStores();
    const { community, store, generalId } = await ownerCommunity({ storeFactory: stores.factory });
    const seen: ConcordDiagnostic[] = [];
    const subscription = community.diagnostics$.subscribe((d) => seen.push(d));
    try {
      community.channelStore(generalId);
      await settle();
      const { clock, duties } = useDutyClock(community);
      const purge = watchPurge(community, (call) => (call === 2 ? new Error("purge blew up") : undefined));

      // A store whose read rejects: reported with its channel id, never thrown from the timer.
      let failOnce = true;
      stores.hook = () => {
        if (!failOnce) return;
        failOnce = false;
        return Promise.reject(new Error("disk read failed"));
      };
      const stop = community.schedulePurge({ intervalMs: 60_000 });
      await advance(clock, duties, 0);
      const storeFailure = seen.find((d) => d.stage === "expiration-purge" && d.key === generalId);
      expect(storeFailure).toBeDefined();
      expect((storeFailure!.error as Error).message).toBe("disk read failed");

      // The internal purge itself rejects: also reported as expiration-purge, and the schedule keeps going.
      await advance(clock, duties, 60_000);
      expect(purge.calls).toBe(2);
      expect(seen.some((d) => d.stage === "expiration-purge" && (d.error as Error).message === "purge blew up")).toBe(
        true,
      );
      await advance(clock, duties, 60_000);
      expect(purge.calls).toBe(3);
      expect(duties.slotPending(SLOT)).toBe(true);
      stop();
    } finally {
      subscription.unsubscribe();
      await finish(community, store);
    }
  });
});

describe("client.schedulePurge (EXP-03, D-09, D-20)", () => {
  const slotOf = (community: ConcordCommunity | undefined): boolean =>
    community !== undefined && (community as unknown as Internals).duties.slotPending(SLOT);

  it("client.schedulePurge reaches current and later-joined communities and survives stop and start", async () => {
    const { signer, material, events, storage } = await vault();
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await client.start();
      await settleLong();
      const first = client.getCommunity(material.community_id);
      expect(first).toBeDefined();
      expect(slotOf(first)).toBe(false);

      // An invalid interval throws before any community is touched.
      expect(() => client.schedulePurge({ intervalMs: 5 })).toThrow(RangeError);
      expect(slotOf(first)).toBe(false);

      client.schedulePurge({ intervalMs: 60_000 });
      await until(() => slotOf(first));

      const created = await client.createNewCommunity("B", "joined", ["wss://fake"]);
      await until(() => slotOf(created));

      client.stop();
      await client.start();
      await settleLong();
      const rebuiltFirst = client.getCommunity(material.community_id);
      const rebuiltCreated = client.getCommunity(created.communityId);
      expect(rebuiltFirst).toBeDefined();
      expect(rebuiltFirst).not.toBe(first);
      await until(() => slotOf(rebuiltFirst));
      if (rebuiltCreated) await until(() => slotOf(rebuiltCreated));
    } finally {
      await h.teardown();
    }
  });

  it("the client disposer stops every community's schedule and schedulePurge throws after dispose", async () => {
    const { signer, material, events, storage } = await vault();
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await client.start();
      await settleLong();
      const first = client.getCommunity(material.community_id);
      const created = await client.createNewCommunity("B", "joined", ["wss://fake"]);
      await settleLong();

      const first1 = client.schedulePurge({ intervalMs: 60_000 });
      await until(() => slotOf(first) && slotOf(created));
      // A second call replaces the first; the earlier disposer then does nothing.
      const second = client.schedulePurge({ intervalMs: 120_000 });
      await until(() => slotOf(first) && slotOf(created));
      first1();
      expect(slotOf(first) && slotOf(created)).toBe(true);

      second();
      await until(() => !slotOf(first) && !slotOf(created));

      // Once stopped, a community joined later gets no schedule.
      const later = await client.createNewCommunity("C", "later", ["wss://fake"]);
      await settleLong();
      expect(slotOf(later)).toBe(false);

      client.dispose();
      expect(() => client.schedulePurge()).toThrow(ConcordClientDisposedError);
    } finally {
      await h.teardown();
    }
  });
});
