import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { EventStore } from "applesauce-core";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import "applesauce-common/casts";
import { bytesToHex } from "@noble/hashes/utils.js";

import { ConcordClient } from "../src/client/client.ts";
import type { ConcordDirectInvite } from "../src/casts/direct-invite.ts";
import { memoryStorage } from "../src/client/storage.ts";
import { buildInviteBundle } from "../src/helpers/invite-bundle.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import { fakeRelayPool } from "../src/client/__tests__/test-utils.ts";
import type { ChannelKey } from "../src/types.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));

describe("Direct Invites for a community not joined yet", () => {
  it("applies the invite's channel keys once the community is joined", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const fake = fakeRelayPool();
    const store = new EventStore();
    const client = new ConcordClient({
      signer,
      pool: fake.pool,
      eventStore: store,
      storage: memoryStorage(),
      relays: ["wss://fake"],
    });
    const owner = getPublicKey(generateSecretKey());
    const genesis = await createLegacyCommunity({ ownerPubkey: owner, name: "Later", relays: ["wss://fake"] });
    const cid = genesis.material.community_id;
    const key: ChannelKey = {
      id: bytesToHex(generateSecretKey()),
      key: bytesToHex(generateSecretKey()),
      epoch: 0,
      name: "secret",
    };
    // A decoded Direct Invite as the watcher emits it: only the fields the client reads.
    const invite = {
      id: "dd".repeat(32),
      expired: () => false,
      bundle: { ...buildInviteBundle(genesis.material), channels: [key] },
    } as unknown as ConcordDirectInvite;
    try {
      await client.start();
      await settle(); // let the watcher seed from the store before the invite arrives
      const watcher = client.directInviteWatcher$.value!;
      expect(watcher).toBeDefined();
      watcher.invites$.next([invite]);
      expect(client.getCommunity(cid)).toBeUndefined();

      const community = await client.joinByBundle(buildInviteBundle(genesis.material)).catch(() =>
        client.getCommunity(cid)
      );
      expect(community?.material.channels.some((channel) => channel.id === key.id)).toBe(true);
      await settle();
    } finally {
      client.stop();
      client.dispose();
      store.dispose();
      await settle();
    }
  });
});
