// Community List offline-write gate (LIST-01, LIST-02). A failed or skipped relay read is
// never evidence of an empty list (CORD-02 §8: a short read means incomplete), so a client
// that starts offline must not publish a fresh `frags: 1` fragment 0 over a fragmented vault.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { spy } from "@std/testing/mock";
import { concat, EMPTY, firstValueFrom, from, type Observable, of, race, Subject, throwError, timer } from "rxjs";
import { filter } from "rxjs";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";
import { EventStore } from "applesauce-core";
import "applesauce-common/casts";
import type { RelayPool } from "applesauce-relay";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import { finalizeEvent, type NostrEvent } from "applesauce-core/helpers/event";

import { ConcordClient } from "../src/client/client.ts";
import {
  CommunityListUnknownError,
  ConcordClientDisposedError,
  ConcordClientNotStartedError,
} from "../src/client/community-list-sync.ts";
import type { InviteBundle } from "../src/types.ts";
import type { JoinMaterial } from "../src/types.ts";
import { type ConcordStorage, memoryStorage } from "../src/client/storage.ts";
import { fakeRelayPool, Gate, gatedSigner, ManualClock } from "../src/client/__tests__/test-utils.ts";
import { type DutyReport, DutyScope } from "../src/client/lifecycle.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  decodeCommunityListFragment,
  encodeCommunityListFragment,
} from "../src/helpers/community-list-wire.ts";
import {
  COMMUNITY_LIST_KIND,
  isCommunityLive,
  mergeCommunities,
  parseCommunityList,
} from "../src/helpers/community-list.ts";
import { foldMembers, JOIN_VERB, LEAVE_VERB } from "../src/helpers/guestbook.ts";
import { rumorMs } from "../src/helpers/stream.ts";
import { ConcordCommunity } from "../src/client/community.ts";
import { buildInviteBundle, buildInviteLink, newInviteToken } from "../src/helpers/invite-bundle.ts";
import { InviteBundleFactory } from "../src/factories/invite-bundle.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));
const settleFlush = () => new Promise((r) => setTimeout(r, 700));

const listPublishes = (published: NostrEvent[]) => published.filter((e) => e.kind === COMMUNITY_LIST_FRAGMENT_KIND);

/** The vault: community A on a device whose relays hold two old fragments (`frags: 2`). */
async function vault(options: { relayVault?: boolean } = {}) {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const a = (await createLegacyCommunity({ ownerPubkey: pubkey, name: "A", relays: ["wss://fake"] })).material;
  const material = { ...a, held_roots: a.held_roots ?? [] };
  const entries = mergeCommunities([], [{
    community_id: material.community_id,
    seed: material,
    current: material,
    added_at: 1,
  }]);
  const old = Math.floor(Date.now() / 1000) - 1000;
  const frag = async (index: number, doc: unknown) =>
    signer.signEvent({
      kind: COMMUNITY_LIST_FRAGMENT_KIND,
      created_at: old,
      tags: [["d", String(index)]],
      content: await signer.nip44!.encrypt(pubkey, encodeCommunityListFragment(doc as never)),
    });
  const events = options.relayVault === false ? [] : [
    await frag(0, { frags: 2, entries, tombstones: [] }),
    await frag(1, { frags: 2, entries: [], tombstones: [] }),
  ];
  const storage = memoryStorage();
  await storage.setItem(pubkey, JSON.stringify({ entries, tombstones: [] }));
  return { signer, pubkey, material, entries, old, events, storage };
}

/** Everything a test builds, torn down in one place (background community.start() leaks intervals otherwise). */
function harness() {
  const clients: ConcordClient[] = [];
  const stores: EventStore[] = [];
  return {
    client(
      signer: ISigner,
      pool: RelayPool,
      storage: ConcordStorage,
      extra: Partial<ConstructorParameters<typeof ConcordClient>[0]> = {},
    ): ConcordClient {
      const store = new EventStore();
      stores.push(store);
      const client = new ConcordClient({
        signer,
        pool,
        eventStore: store,
        storage,
        relays: ["wss://fake"],
        watchDirectInvites: false,
        ...extra,
      });
      clients.push(client);
      return client;
    },
    async teardown() {
      await settle();
      for (const client of clients) {
        client.stop();
        client.dispose();
      }
      for (const store of stores) store.dispose();
      await settle();
    },
  };
}

/** Resolve with the first kind-33302 publish, or undefined after the guard elapses. */
function firstListPublish(published$: Observable<NostrEvent>, ms = 4000): Promise<NostrEvent | undefined> {
  return firstValueFrom(
    race(published$.pipe(filter((e) => e.kind === COMMUNITY_LIST_FRAGMENT_KIND)), timer(ms)),
  ).then((value) => (typeof value === "number" ? undefined : value));
}

async function fragmentOf(signer: PrivateKeySigner, event: NostrEvent) {
  const pubkey = await signer.getPublicKey();
  return decodeCommunityListFragment(await signer.nip44!.decrypt(pubkey, event.content));
}

const statusOf = (client: ConcordClient) => firstValueFrom(client.communityListStatus$);

const dTag = (event: NostrEvent) => event.tags.find((t) => t[0] === "d")?.[1];

describe("Community List offline-write gate (LIST-01, LIST-02)", () => {
  it("a client restarted offline never publishes a fresh fragment 0 over a fragmented vault", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const { pool, published } = fakeRelayPool({ online: false, events });
    const h = harness();
    try {
      const client = h.client(signer, pool, storage);
      await client.start();
      await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(listPublishes(published)).toHaveLength(0);
      const mirror = parseCommunityList((await storage.getItem(pubkey))!);
      expect(mirror.entries).toHaveLength(2);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
    } finally {
      await h.teardown();
    }
  });

  it("auto-save on an offline start publishes nothing and keeps the change pending", async () => {
    const { signer, events, storage } = await vault();
    const { pool, published } = fakeRelayPool({ online: false, events });
    const h = harness();
    try {
      const client = h.client(signer, pool, storage, { autoSaveCommunityList: true });
      await client.start();
      await settleFlush();
      expect(listPublishes(published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
    } finally {
      await h.teardown();
    }
  });

  it("a liveness-skipped relay cohort reads as unknown, not empty", async () => {
    const { signer, events, storage } = await vault();
    const { pool, published } = fakeRelayPool({ events, filterRelays: () => [] });
    const h = harness();
    try {
      const client = h.client(signer, pool, storage);
      await client.start();
      await client.createNewCommunity("B", "joined with every relay skipped", ["wss://fake"]);
      await settle();
      expect(listPublishes(published)).toHaveLength(0);
      expect((await statusOf(client)).knowledge).toBe("unknown");
    } finally {
      await h.teardown();
    }
  });

  it("a completed empty read still publishes the first fragment", async () => {
    const { signer, storage: _storage } = await vault({ relayVault: false });
    const { pool, published } = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(signer, pool, memoryStorage());
      await client.start();
      await client.createNewCommunity("First", "", ["wss://fake"]);
      await settle();
      const lists = listPublishes(published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      expect((await fragmentOf(signer, lists[0])).frags).toBe(1);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("the next start releases a pending write with the governing fragment count", async () => {
    const { signer, old, events, storage, material } = await vault();
    const net = fakeRelayPool({ online: false, events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await client.start();
      const created = await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      client.stop();
      net.setOnline(true);
      const first = firstListPublish(net.published$);
      await client.start();
      expect(await first).toBeDefined();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      expect(lists[0].created_at).toBeGreaterThan(old);
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      const ids = doc.entries.map((e) => e.community_id);
      expect(ids).toContain(material.community_id);
      expect(ids).toContain(created.communityId);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("a blocked offline save does not loop the auto-save pipeline", async () => {
    const { signer, events, storage } = await vault();
    const { pool } = fakeRelayPool({ online: false, events });
    const h = harness();
    const client = h.client(signer, pool, storage, { autoSaveCommunityList: true });
    const save = spy(client, "saveCommunityList");
    try {
      await client.start();
      await new Promise((r) => setTimeout(r, 1500));
      expect(save.calls.length).toBeLessThanOrEqual(2);
    } finally {
      save.restore();
      await h.teardown();
    }
  });

  it("a pending write survives a process restart and is published once by the next client", async () => {
    const { signer, old, events, storage, material } = await vault();
    const net = fakeRelayPool({ online: false, events });
    const h = harness();
    try {
      const first = h.client(signer, net.pool, storage, { autoUnlock: true });
      await first.start();
      const created = await first.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      first.stop();
      first.dispose();

      net.setOnline(true);
      const second = h.client(signer, net.pool, storage, { autoUnlock: true });
      const published = firstListPublish(net.published$);
      await second.start();
      expect(await published).toBeDefined();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      expect(lists[0].created_at).toBeGreaterThan(old);
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      const ids = doc.entries.map((e) => e.community_id);
      expect(ids).toContain(material.community_id);
      expect(ids).toContain(created.communityId);
      expect(await statusOf(second)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("a completed read that returned fragments never reports confirmed-empty", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const net = fakeRelayPool({ events });
    const h = harness();
    try {
      // A slow remote signer: fragment ingest awaits getPublicKey, so it lags the read's completion.
      const slow = Object.assign(Object.create(signer), {
        getPublicKey: () => new Promise<string>((resolve) => setTimeout(() => resolve(pubkey), 50)),
      }) as PrivateKeySigner;
      const client = h.client(slow, net.pool, storage);
      const seen: string[] = [];
      const sub = client.communityListStatus$.subscribe((status) => seen.push(status.knowledge));
      await client.start();
      await settle();
      sub.unsubscribe();
      expect(seen).not.toContain("confirmed-empty");
      expect((await statusOf(client)).knowledge).toBe("partial"); // held but locked (autoUnlock is off)
    } finally {
      await h.teardown();
    }
  });

  it("a join held over a locked Community List is published once the fragments are unlocked (WR-01)", async () => {
    const { signer, old, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage); // autoUnlock off: the relay vault stays locked
      await client.start();
      const created = await client.createNewCommunity("B", "joined over a locked list", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "partial", pending: true });

      await client.unlockCommunityListFragments();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      expect(lists[0].created_at).toBeGreaterThan(old);
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      expect(doc.entries.map((e) => e.community_id)).toContain(material.community_id);
      expect(doc.entries.map((e) => e.community_id)).toContain(created.communityId);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("a save retired by a newer change is not reported as a failure (IN-09)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const net = fakeRelayPool({ events: [] });
    // A slow remote signer: every list encryption waits until the test releases it.
    const waiting: Array<() => void> = [];
    const slow = Object.assign(Object.create(signer), {
      nip44: {
        encrypt: async (pubkey: string, text: string) => {
          await new Promise<void>((resolve) => waiting.push(resolve));
          return signer.nip44!.encrypt(pubkey, text);
        },
        decrypt: (pubkey: string, text: string) => signer.nip44!.decrypt(pubkey, text),
      },
    }) as PrivateKeySigner;
    const until = async (ready: () => boolean) => {
      for (let i = 0; i < 100 && !ready(); i++) await new Promise((r) => setTimeout(r, 20));
      expect(ready()).toBe(true);
    };
    const h = harness();
    try {
      const client = h.client(slow, net.pool, memoryStorage());
      await client.start();
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      const first = client.createNewCommunity("A", "its save is retired", ["wss://fake"]);
      await until(() => waiting.length === 1);
      const second = client.createNewCommunity("B", "retires the first save", ["wss://fake"]);
      const a = await first; // released by the retirement, not by its signer
      waiting[0](); // the retired save resumes, finds it is no longer current and frees the fragment writer
      await until(() => waiting.length === 2);
      waiting[1]();
      const b = await second;
      await settle();
      expect(diagnostics.filter((d) => d.stage === "community-list-save")).toHaveLength(0);
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = await fragmentOf(signer, lists[0]);
      expect(idsOf(doc)).toEqual(expect.arrayContaining([a.communityId, b.communityId]));
    } finally {
      await h.teardown();
    }
  });

  it("a restarted client whose mirror matches the relay copy publishes nothing", async () => {
    const { signer, events, storage } = await vault();
    const net = fakeRelayPool({ online: true, events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await client.start();
      await settleFlush();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });
});

interface DutyInternals {
  listDuties: DutyScope;
  diagnostics: { reportDuty(report: DutyReport): void };
}

/** Replace the constructor-created scope with a ManualClock-driven one before `start()` (the real-time hydration wait is unaffected). */
function injectClock(client: ConcordClient, clock: ManualClock): DutyInternals {
  const internals = client as unknown as DutyInternals;
  internals.listDuties.dispose();
  internals.listDuties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report) });
  return internals;
}

/** Advance the manual clock, then let the released duty attempt and the loader's real timers finish. */
async function advance(internals: DutyInternals, clock: ManualClock, ms: number): Promise<void> {
  clock.tick(ms);
  await internals.listDuties.idle();
  await settle();
  await internals.listDuties.idle();
}

const idsOf = (doc: { entries: Array<{ community_id: string }> }) => doc.entries.map((e) => e.community_id);

/** A fresh membership owned by `pubkey`, in join-material form. */
async function membership(pubkey: string, name: string): Promise<JoinMaterial> {
  const material = (await createLegacyCommunity({ ownerPubkey: pubkey, name, relays: ["wss://fake"] })).material;
  return { ...material, held_roots: material.held_roots ?? [] };
}

/** Community List entries for `materials`, in order, with increasing `added_at`. */
const entriesOf = (materials: JoinMaterial[]) =>
  mergeCommunities(
    [],
    materials.map((m, index) => ({ community_id: m.community_id, seed: m, current: m, added_at: index + 1 })),
  );

/** Poll `ready` in real time (at most 2 s). */
async function until(ready: () => boolean): Promise<void> {
  for (let i = 0; i < 100 && !ready(); i++) await new Promise((r) => setTimeout(r, 20));
  expect(ready()).toBe(true);
}

/** `promise`'s outcome, or `"pending"` when it has not settled within `ms`: a bounded wait, so a hang is an assertion. */
async function within<T>(promise: Promise<T>, ms: number): Promise<T | "pending"> {
  let timer = 0;
  const pending = new Promise<"pending">((resolve) => (timer = setTimeout(() => resolve("pending"), ms)));
  const outcome = await Promise.race([promise, pending]);
  clearTimeout(timer);
  return outcome;
}

/** A remote signer whose next `count` getPublicKey calls fail, as while a bunker reconnects. */
function flakySigner(signer: PrivateKeySigner): { signer: PrivateKeySigner; failNext: (count: number) => void } {
  let failures = 0;
  const flaky = Object.assign(Object.create(signer), {
    getPublicKey: () => {
      if (failures <= 0) return signer.getPublicKey();
      failures--;
      return Promise.reject(new Error("bunker reconnecting"));
    },
  }) as PrivateKeySigner;
  return { signer: flaky, failNext: (count) => (failures = count) };
}

/** One self-encrypted fragment at `index`, signed at `created_at`. */
async function fragment(signer: PrivateKeySigner, index: number, doc: unknown, created_at: number) {
  const pubkey = await signer.getPublicKey();
  return signer.signEvent({
    kind: COMMUNITY_LIST_FRAGMENT_KIND,
    created_at,
    tags: [["d", String(index)]],
    content: await signer.nip44!.encrypt(pubkey, encodeCommunityListFragment(doc as never)),
  });
}

describe("Community List pending-write retry (LIST-01, D-15, D-24, D-26)", () => {
  it("a pending write is released automatically once a relay completes the read", async () => {
    const { signer, events, storage, material } = await vault();
    const net = fakeRelayPool({ online: false, events });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      const created = await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
      expect(internals.listDuties.pending).toBe(1);

      net.setOnline(true);
      await advance(internals, clock, 6_000);

      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      expect(idsOf(doc)).toContain(material.community_id);
      expect(idsOf(doc)).toContain(created.communityId);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("an exhausted list-read retry reports once and waits for a new key", async () => {
    const { signer, events, storage } = await vault();
    const net = fakeRelayPool({ events });
    let listReads = 0;
    net.setRequest((filters) => {
      if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
      listReads++;
      return throwError(() => new Error("relay down"));
    });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await client.start();
      expect(internals.listDuties.pending).toBe(1);

      // First fire about 5.5 s, then backoffs of about 5.5 s and 10.5 s (ManualClock random 0.5).
      await advance(internals, clock, 6_000);
      await advance(internals, clock, 6_000);
      await advance(internals, clock, 11_000);

      const exhausted = diagnostics.filter((d) => d.stage === "duty-exhausted");
      expect(exhausted).toHaveLength(1);
      expect(exhausted[0].stage === "duty-exhausted" && exhausted[0].duty).toBe("community-list-read");
      expect(internals.listDuties.pending).toBe(0);

      const readsAtExhaustion = listReads;
      await advance(internals, clock, 120_000);
      expect(listReads).toBe(readsAtExhaustion);
      expect(diagnostics.filter((d) => d.stage === "duty-exhausted")).toHaveLength(1);
    } finally {
      await h.teardown();
    }
  });

  it("a held write after an exhausted list-read retry arms a fresh retry", async () => {
    const { signer, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    net.setRequest((filters) =>
      filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))
        ? throwError(() => new Error("relay down"))
        : EMPTY
    );
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      await advance(internals, clock, 6_000);
      await advance(internals, clock, 6_000);
      await advance(internals, clock, 11_000);
      expect(internals.listDuties.pending).toBe(0); // exhausted

      const created = await client.createNewCommunity("B", "joined after the retry went quiet", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(internals.listDuties.pending).toBe(1);

      net.setRequest();
      await advance(internals, clock, 6_000);
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      expect(idsOf(doc)).toContain(material.community_id);
      expect(idsOf(doc)).toContain(created.communityId);
    } finally {
      await h.teardown();
    }
  });

  it("a held save that no relay accepts is retried by the list-read duty", async () => {
    const { signer, events, storage, material } = await vault();
    const net = fakeRelayPool({ online: false, events });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      const created = await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(internals.listDuties.pending).toBe(1);

      net.setOnline(true);
      let refusals = 0;
      net.setPublishOutcome((event) =>
        event.kind === COMMUNITY_LIST_FRAGMENT_KIND && refusals++ === 0
          ? [{ ok: false, from: "wss://fake", message: "busy" }]
          : undefined
      );
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await advance(internals, clock, 6_000);
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(internals.listDuties.pending).toBe(1); // the failed release is retried, not settled
      // WR-03: a publish failure is a save failure, reported once under its own stage, never as a read failure.
      expect(diagnostics.map((d) => d.stage)).toEqual(["community-list-save"]);

      await advance(internals, clock, 6_000);
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = await fragmentOf(signer, lists[0]);
      expect(idsOf(doc)).toContain(material.community_id);
      expect(idsOf(doc)).toContain(created.communityId);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("a held save the signer declines is reported once and never re-prompted (WR-03)", async () => {
    const { signer, events, storage } = await vault();
    const net = fakeRelayPool({ online: false, events });
    let decline = false, encrypts = 0;
    const declining = Object.assign(Object.create(signer), {
      nip44: {
        encrypt: (pubkey: string, text: string) => {
          if (!decline) return signer.nip44!.encrypt(pubkey, text);
          encrypts++;
          return Promise.reject(new Error("user declined"));
        },
        decrypt: (pubkey: string, text: string) => signer.nip44!.decrypt(pubkey, text),
      },
    }) as PrivateKeySigner;
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(declining, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(internals.listDuties.pending).toBe(1);

      decline = true;
      net.setOnline(true);
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await advance(internals, clock, 6_000);
      expect(encrypts).toBe(1);
      expect(diagnostics.map((d) => d.stage)).toEqual(["community-list-save"]);
      expect(internals.listDuties.pending).toBe(0); // settled: a declined prompt is not retried

      await advance(internals, clock, 60_000);
      expect(encrypts).toBe(1);
      expect(diagnostics).toHaveLength(1);
      expect(listPublishes(net.published)).toHaveLength(0);
    } finally {
      await h.teardown();
    }
  });

  for (
    const [label, refusal] of [
      ["a declined relay AUTH prompt", {
        message: "auth-required: user declined",
        error: Object.assign(new Error("user declined"), { name: "AuthHandlerError" }),
      }],
      ["a blocked: refusal", { message: "blocked: pubkey is banned" }],
      ["a restricted: refusal", { message: "restricted: members only" }],
      ["an invalid: refusal", { message: "invalid: kind not accepted" }],
    ] as const
  ) {
    it(`a held save refused by ${label} is reported once and never retried (WR-01)`, async () => {
      const { signer, events, storage } = await vault();
      const net = fakeRelayPool({ online: false, events });
      const clock = new ManualClock();
      const h = harness();
      try {
        const client = h.client(signer, net.pool, storage, { autoUnlock: true });
        const internals = injectClock(client, clock);
        await client.start();
        await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
        await settle();
        expect(internals.listDuties.pending).toBe(1);

        let attempts = 0;
        net.setPublishOutcome((event) => {
          if (event.kind !== COMMUNITY_LIST_FRAGMENT_KIND) return undefined;
          attempts++;
          return [{ ok: false, from: "wss://fake", ...refusal }];
        });
        net.setOnline(true);
        const diagnostics: ConcordDiagnostic[] = [];
        client.diagnostics$.subscribe((d) => diagnostics.push(d));
        await advance(internals, clock, 6_000);
        expect(attempts).toBe(1);
        expect(diagnostics.map((d) => d.stage)).toEqual(["community-list-save"]);
        expect(internals.listDuties.pending).toBe(0); // settled: a permanent refusal is not retried

        await advance(internals, clock, 60_000);
        expect(attempts).toBe(1);
        expect(diagnostics).toHaveLength(1);
      } finally {
        await h.teardown();
      }
    });
  }

  it("the held-save retry publishes the state current at fire time, not at scheduling time", async () => {
    const { signer, pubkey, old: _old, events, storage, material } = await vault();
    const net = fakeRelayPool({ online: false, events });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      const b = await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(internals.listDuties.pending).toBe(1);
      // A second offline change coalesces into the already armed retry.
      const c = await client.createNewCommunity("C", "also joined while offline", ["wss://fake"]);
      await settle();
      expect(internals.listDuties.pending).toBe(1);
      expect(listPublishes(net.published)).toHaveLength(0);

      // A newer remote fragment 0 lands before the retry fires.
      const d = (await createLegacyCommunity({ ownerPubkey: pubkey, name: "D", relays: ["wss://fake"] })).material;
      const entry = (m: JoinMaterial, added_at: number) => ({
        community_id: m.community_id,
        seed: { ...m, held_roots: m.held_roots ?? [] },
        current: { ...m, held_roots: m.held_roots ?? [] },
        added_at,
      });
      const newer = await signer.signEvent({
        kind: COMMUNITY_LIST_FRAGMENT_KIND,
        created_at: Math.floor(Date.now() / 1000) - 10,
        tags: [["d", "0"]],
        content: await signer.nip44!.encrypt(
          pubkey,
          encodeCommunityListFragment(
            { frags: 2, entries: mergeCommunities([], [entry(material, 1), entry(d, 2)]), tombstones: [] } as never,
          ),
        ),
      });
      net.setEvents([newer, events[1]]);
      net.setOnline(true);
      await advance(internals, clock, 6_000);

      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      for (const id of [material.community_id, b.communityId, c.communityId, d.community_id]) {
        expect(idsOf(doc)).toContain(id);
      }
      expect(lists[0].created_at).toBeGreaterThan(newer.created_at);
    } finally {
      await h.teardown();
    }
  });

  it("a read whose fragments fail to ingest stays incomplete and never publishes frags: 1 (CR-02)", async () => {
    const { signer, events, storage } = await vault();
    const net = fakeRelayPool({ events });
    // A reconnecting remote signer: getPublicKey fails for both ingests and both hydrations of the read's fragments.
    let armed = false, failures = 0;
    net.setRequest((filters) => {
      if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
      armed = true;
      return from(events);
    });
    const flaky = Object.assign(Object.create(signer), {
      getPublicKey: () =>
        armed && failures++ < 4 ? Promise.reject(new Error("bunker reconnecting")) : signer.getPublicKey(),
    }) as PrivateKeySigner;
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage);
      const internals = injectClock(client, clock);
      const seen: string[] = [];
      const sub = client.communityListStatus$.subscribe((status) => seen.push(status.knowledge));
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await client.start();
      await settle();
      expect(failures).toBeGreaterThanOrEqual(2);
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(seen).not.toContain("confirmed-empty");
      expect(diagnostics.some((d) => d.stage === "community-list-read")).toBe(true);
      expect(internals.listDuties.pending).toBe(1); // the read is retried, not settled

      await advance(internals, clock, 6_000);
      sub.unsubscribe();
      expect(seen).not.toContain("confirmed-empty");
      expect((await statusOf(client)).knowledge).toBe("partial"); // ingested on retry; locked (autoUnlock off)
      expect(listPublishes(net.published)).toHaveLength(0);
    } finally {
      await h.teardown();
    }
  });

  it("a released held save that finds the relay copy already matching clears pending", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const net = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, memoryStorage());
      // A write refused before any read leaves the sync pending; the local document it would publish is empty. The
      // client's public view rejects every write before start() (D-30, 01-REVIEW-GAPS-3 CR-01), so refuse one on the
      // sync itself.
      const sync = (client as unknown as { listSync: ConcordClient["communityListSync"] }).listSync;
      await expect(sync.write({ entries: [], tombstones: [] }, [])).rejects.toThrow(CommunityListUnknownError);
      expect((await statusOf(client)).pending).toBe(true);
      await client.start();
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "confirmed-empty", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("a restart whose read fails to ingest never publishes over a newer, larger declaration (CR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    // Another device's repack staging copy: newer, and declaring a larger count over both memberships.
    const d1 = await fragment(signer, 1, { frags: 2, entries: entriesOf([material, b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [d0] });
    let armed = false, failures = 0;
    const flaky = Object.assign(Object.create(signer), {
      getPublicKey: () =>
        armed && failures++ < 3 ? Promise.reject(new Error("bunker reconnecting")) : signer.getPublicKey(),
    }) as PrivateKeySigner;
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      // A join the relay refuses leaves a membership the relay copy lacks.
      net.setPublishOutcome((event) =>
        event.kind === COMMUNITY_LIST_FRAGMENT_KIND ? [{ ok: false, from: "wss://fake", message: "busy" }] : undefined
      );
      const c = await client.createNewCommunity("C", "joined, then refused", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      client.stop();
      net.setPublishOutcome(() => undefined);

      // Lifecycle 2: the remote signer fails every ingest of the read, so the newer declaration is never seen.
      net.setRequest((filters) => {
        if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
        armed = true;
        return from([d0, d1]);
      });
      await client.start();
      await settle();
      expect(failures).toBeGreaterThanOrEqual(2);
      expect(listPublishes(net.published)).toHaveLength(0);
      expect((await statusOf(client)).knowledge).toBe("unknown"); // fragments held from lifecycle 1 are not evidence
      expect(internals.listDuties.pending).toBe(1);

      await advance(internals, clock, 6_000);
      await client.unlockCommunityListFragments();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists.length).toBeGreaterThan(0);
      const docs = await Promise.all(lists.map((event) => fragmentOf(signer, event)));
      for (const doc of docs) expect(doc.frags).toBe(2); // fragment 1, which carries B, stays visible
      const ids = docs.flatMap(idsOf);
      for (const id of [material.community_id, c.communityId]) expect(ids).toContain(id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("an offline restart holds a join until a completed read, so a newer remote membership survives (CR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [d0] });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      client.stop();

      net.setOnline(false);
      await client.start();
      const c = await client.createNewCommunity("C", "joined while offline", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
      expect(internals.listDuties.pending).toBe(1);

      // Another device adds B to fragment 0 while this one is offline.
      const b = await membership(pubkey, "B");
      const newer = await fragment(
        signer,
        0,
        { frags: 1, entries: entriesOf([material, b]), tombstones: [] },
        Math.floor(Date.now() / 1000) - 10,
      );
      net.setEvents([newer]);
      net.setOnline(true);
      await advance(internals, clock, 6_000);

      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      expect(lists[0].created_at).toBeGreaterThan(newer.created_at);
      const doc = await fragmentOf(signer, lists[0]);
      for (const id of [material.community_id, b.community_id, c.communityId]) expect(idsOf(doc)).toContain(id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("a read that began before the retry duty's re-read never records, so a newer remote membership survives (CR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const c = await membership(pubkey, "C");
    // C is a local-only join the relay copy lacks, so a completed read releases a save.
    await storage.setItem(pubkey, JSON.stringify({ entries: entriesOf([material, c]), tombstones: [] }));
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    // Another device's newer fragment 0 that reaches this client outside start()'s read.
    const e2 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material, b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    const reads: Subject<NostrEvent>[] = [];
    net.setRequest((filters) => {
      if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
      if (filters.some((f) => f.until !== undefined)) return EMPTY; // the loader's next page: nothing older
      const read = new Subject<NostrEvent>();
      reads.push(read);
      return concat(of(e1), read); // serves e1, then stays open until the test completes it
    });
    const { signer: flaky, failNext } = flakySigner(signer);
    const store = new EventStore();
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage, { autoUnlock: true, eventStore: store });
      const internals = injectClock(client, clock);
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      const started = client.start();
      await until(() => reads.length === 1);
      await settle();

      // D-31: e2 arrives while start()'s read is open, so that read step ingests it before it may record; the
      // remote signer fails one ingest, so start()'s read is not evidence and the retry's read records later.
      failNext(1);
      store.add(e2);
      reads[0].complete();
      await started;
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect((await statusOf(client)).knowledge).toBe("unknown");
      expect(diagnostics.some((d) => d.stage === "community-list-read")).toBe(true);
      expect(internals.listDuties.pending).toBe(1);
      clock.tick(6_000);
      await until(() => reads.length === 2);
      reads[1].complete();
      await internals.listDuties.idle();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(lists[0].created_at).toBeGreaterThan(e2.created_at);
      const doc = await fragmentOf(signer, lists[0]);
      for (const id of [material.community_id, b.community_id, c.community_id]) expect(idsOf(doc)).toContain(id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("a fragment that failed to ingest is received again before a re-read records, so its count survives (CR-02)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    // Arrives from elsewhere (another relay's live subscription or a shared store); the relay read never returns it.
    const e2 = await fragment(signer, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    const { signer: flaky, failNext } = flakySigner(signer);
    const store = new EventStore();
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage, { autoUnlock: true, eventStore: store });
      const internals = injectClock(client, clock);
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

      failNext(1);
      store.add(e2);
      await until(() => diagnostics.some((d) => d.stage === "fragment-reconcile"));
      expect((await statusOf(client)).knowledge).toBe("unknown");
      const d = await client.createNewCommunity("D", "held while the list is unknown", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });

      await advance(internals, clock, 6_000);
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists.length).toBeGreaterThan(0);
      const docs = await Promise.all(lists.map((event) => fragmentOf(signer, event)));
      for (const doc of docs) expect(doc.frags).toBe(2); // fragment 1, which carries B, stays visible
      const ids = docs.flatMap(idsOf);
      for (const id of [material.community_id, d.communityId]) expect(ids).toContain(id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("a publish whose own fragment then fails to ingest arms a re-read that restores the evidence (IN-02)", async () => {
    const { signer, material, old, storage } = await vault({ relayVault: false });
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [d0] });
    const { signer: flaky, failNext } = flakySigner(signer);
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      // The relay accepts the fragment, then the remote signer drops before the client ingests its own copy.
      net.setPublishOutcome((event) => {
        if (event.kind === COMMUNITY_LIST_FRAGMENT_KIND) failNext(1);
        return undefined;
      });
      const c = await client.createNewCommunity("C", "published, then not ingested", ["wss://fake"]);
      await settle();
      net.setPublishOutcome(() => undefined);
      expect(listPublishes(net.published)).toHaveLength(1);
      expect((await statusOf(client)).knowledge).toBe("unknown");
      expect(internals.listDuties.pending).toBe(1); // a re-read is armed instead of waiting for a restart

      net.setEvents([...listPublishes(net.published)]);
      await advance(internals, clock, 6_000);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      expect(listPublishes(net.published)).toHaveLength(1);
      const doc = await fragmentOf(signer, listPublishes(net.published)[0]);
      for (const id of [material.community_id, c.communityId]) expect(idsOf(doc)).toContain(id);
    } finally {
      await h.teardown();
    }
  });

  it("a pending write from a previous process is released by the retry once a relay answers", async () => {
    const { signer, events, storage, material } = await vault();
    const net = fakeRelayPool({ online: false, events });
    const clock = new ManualClock();
    const h = harness();
    try {
      const first = h.client(signer, net.pool, storage, { autoUnlock: true });
      await first.start();
      const created = await first.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      first.stop();
      first.dispose();
      expect(listPublishes(net.published)).toHaveLength(0);

      // A second process: its in-memory pending flag was never set, so only the derived check can release it.
      const second = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(second, clock);
      await second.start();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(internals.listDuties.pending).toBe(1);

      net.setOnline(true);
      await advance(internals, clock, 6_000);

      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      const doc = await fragmentOf(signer, lists[0]);
      expect(doc.frags).toBe(2);
      expect(idsOf(doc)).toContain(material.community_id);
      expect(idsOf(doc)).toContain(created.communityId);
      expect(await statusOf(second)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });
});

describe("Community List mutations require a started client (D-30)", () => {
  /** Every membership change rejects with nothing applied, mirrored or published. */
  async function expectRejected(client: ConcordClient, storage: ConcordStorage, pubkey: string, cid: string) {
    const mirror = await storage.getItem(pubkey);
    await expect(client.createNewCommunity("B", "not started", ["wss://fake"])).rejects.toThrow(
      ConcordClientNotStartedError,
    );
    await expect(client.joinByBundle({} as InviteBundle)).rejects.toThrow(ConcordClientNotStartedError);
    await expect(client.joinByLink("https://example.invalid/invite#x")).rejects.toThrow(ConcordClientNotStartedError);
    await expect(client.leave(cid)).rejects.toThrow(ConcordClientNotStartedError);
    await settle();
    expect(await storage.getItem(pubkey)).toBe(mirror);
    expect((await statusOf(client)).pending).toBe(false);
  }

  it("the client's communityListSync view leaves read evidence to the client (IN-01)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool().pool, memoryStorage());
      // @ts-expect-error only the client may record a completed read
      expect(client.communityListSync.markReadComplete).toBeDefined();
      // @ts-expect-error only the client may begin a read
      expect(client.communityListSync.beginRead).toBeDefined();
      // @ts-expect-error only the client may withdraw read evidence
      expect(client.communityListSync.clearReadEvidence).toBeDefined();
      // At run time they throw, as do abandon() and restore(), which only the client's lane may call (WR-06).
      const view = client.communityListSync as unknown as {
        markReadComplete(token: number): boolean;
        abandon(): void;
        restore(events: NostrEvent[]): Promise<unknown>;
      };
      expect(() => view.markReadComplete(0)).toThrow("standalone-only");
      expect(() => view.abandon()).toThrow("standalone-only");
      expect(() => view.restore([])).toThrow("standalone-only");
      expect(client.communityListSync.status).toEqual({ knowledge: "unknown", pending: false });
    } finally {
      await h.teardown();
    }
  });

  it("rejects joins, leaves and creates before start()", async () => {
    const { signer, pubkey, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await expectRejected(client, storage, pubkey, material.community_id);
      expect(net.published).toHaveLength(0);
    } finally {
      await h.teardown();
    }
  });

  it("rejects joins, leaves and creates after stop() and after dispose()", async () => {
    const { signer, pubkey, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await client.start();
      await settle();
      client.stop();
      const published = listPublishes(net.published).length;
      await expectRejected(client, storage, pubkey, material.community_id);
      client.dispose();
      await expectRejected(client, storage, pubkey, material.community_id);
      expect(listPublishes(net.published)).toHaveLength(published);
    } finally {
      await h.teardown();
    }
  });

  it("start() after dispose() rejects and every membership change stays rejected (D-32)", async () => {
    const { signer, pubkey, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await client.start();
      await settle();
      const mirror = await storage.getItem(pubkey);
      const published = listPublishes(net.published).length;
      client.dispose();

      await expect(client.start()).rejects.toThrow(ConcordClientDisposedError);
      await expect(client.leave(material.community_id)).rejects.toThrow(ConcordClientDisposedError);
      await expect(client.leave(material.community_id)).rejects.toThrow(ConcordClientNotStartedError);
      await expect(client.createNewCommunity("B", "disposed", ["wss://fake"])).rejects.toThrow(
        ConcordClientDisposedError,
      );
      await expect(client.joinByBundle({} as InviteBundle)).rejects.toThrow(ConcordClientDisposedError);
      await expect(client.joinByLink("https://example.invalid/invite#x")).rejects.toThrow(ConcordClientDisposedError);
      await expect(client.unlockCommunityListFragments()).rejects.toThrow(ConcordClientDisposedError);
      await settle();

      expect(await storage.getItem(pubkey)).toBe(mirror);
      expect(listPublishes(net.published)).toHaveLength(published);
      expect((await statusOf(client)).pending).toBe(false);
      expect(client.phase$.value).toBe("idle");
    } finally {
      await h.teardown();
    }
  });

  it("never arms a Community List read for a stopped client, so a later unlock still releases a held save (WR-01)", async () => {
    const { signer, material, old, storage } = await vault({ relayVault: false });
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [d0] });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage); // autoUnlock off
      const internals = injectClock(client, clock) as DutyInternals & {
        listLane?: { requestRead(renew?: boolean): void };
      };
      await client.start();
      await client.unlockCommunityListFragments();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      // A join the relay refuses leaves a membership the relay copy lacks.
      net.setPublishOutcome((event) =>
        event.kind === COMMUNITY_LIST_FRAGMENT_KIND ? [{ ok: false, from: "wss://fake", message: "busy" }] : undefined
      );
      const c = await client.createNewCommunity("C", "joined, then refused", ["wss://fake"]);
      await settle();
      const stopped = internals.listLane!;
      client.stop();
      net.setPublishOutcome(() => undefined);

      // A late held-write or hydration failure from the stopped lifecycle asks for a read: nothing may be armed.
      stopped.requestRead(true);
      expect(internals.listDuties.pending).toBe(0);

      // Another device's newer fragment 0 is locked after the restart, so start()'s release holds.
      const newer = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old + 10);
      net.setEvents([newer]);
      await client.start();
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect((await statusOf(client)).knowledge).toBe("partial");
      stopped.requestRead(true); // a superseded lifecycle still arms nothing
      expect(internals.listDuties.pending).toBe(0);

      await client.unlockCommunityListFragments();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = await fragmentOf(signer, lists[0]);
      for (const id of [material.community_id, c.communityId]) expect(idsOf(doc)).toContain(id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
    }
  });
});

describe("Community List lane regressions (D-31, REVIEW-FOCUSED-2)", () => {
  /** Serve `events` to kind-33302 reads (nothing older on the loader's next page) and nothing to other kinds. */
  const serveFragments =
    (serve: () => Observable<NostrEvent>) => (filters: Array<{ kinds?: number[]; until?: number }>) => {
      if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
      if (filters.some((f) => f.until !== undefined)) return EMPTY;
      return serve();
    };

  it("a read that resumes after stop() never hides a stored fragment from the next start, so no frags: 1 is published over frags: 2 (CR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const c = await membership(pubkey, "C");
    // C is a local-only join the relay copy lacks, so a completed read releases a save.
    await storage.setItem(pubkey, JSON.stringify({ entries: entriesOf([material, c]), tombstones: [] }));
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    // Another device's newer, larger declaration; it reaches the shared store while this client is stopped.
    const x = await fragment(signer, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    const reads: Subject<NostrEvent>[] = [];
    net.setRequest(serveFragments(() => {
      const read = new Subject<NostrEvent>();
      reads.push(read);
      return concat(of(e1), read); // serves e1, then stays open until the test completes it
    }));
    let stalling = false;
    const gate = new Gate<[], string>();
    const gated = gatedSigner(signer, { getPublicKey: gate, getPublicKeyWhen: () => stalling });
    const store = new EventStore();
    store.add(e1);
    const h = harness();
    try {
      const client = h.client(gated, net.pool, storage, { eventStore: store, autoUnlock: true });
      const started = client.start();
      await until(() => reads.length === 1);
      await until(() => client.communityListSync.fragments.get(0)?.id === e1.id);

      stalling = true; // the remote signer stops answering while start()'s read ingests e1
      reads[0].complete();
      await gate.next();
      client.stop();
      store.add(x);
      stalling = false;
      for (const call of gate.calls) call.release();
      await started;
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);

      net.setRequest(serveFragments(() => of(e1)));
      await client.start();
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists.length).toBeGreaterThan(0);
      const docs = await Promise.all(lists.map((event) => fragmentOf(signer, event)));
      for (const doc of docs) expect(doc.frags).toBe(2); // never frags: 1, which would hide B
      const zero = lists.filter((event) => dTag(event) === "0");
      expect(zero).toHaveLength(1);
      expect(idsOf(await fragmentOf(signer, zero[0]))).toEqual(
        expect.arrayContaining([material.community_id, c.community_id]),
      );
      expect(store.getReplaceable(COMMUNITY_LIST_FRAGMENT_KIND, pubkey, "1")?.id).toBe(x.id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("with auto-save on, a fragment that keeps failing to ingest exhausts the read retry once and then stays quiet (CR-02)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const d1 = await fragment(signer, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [d0] });
    let listReads = 0;
    net.setRequest(serveFragments(() => {
      listReads++;
      return of(d0);
    }));
    const { signer: flaky, failNext } = flakySigner(signer);
    let keyCalls = 0;
    const counted = Object.assign(Object.create(flaky), {
      getPublicKey: () => {
        keyCalls++;
        return flaky.getPublicKey();
      },
    }) as PrivateKeySigner;
    const store = new EventStore();
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(counted, net.pool, storage, {
        autoUnlock: true,
        autoSaveCommunityList: true,
        eventStore: store,
      });
      const internals = injectClock(client, clock);
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

      failNext(1);
      store.add(d1);
      await until(() => diagnostics.some((d) => d.stage === "fragment-reconcile"));
      expect((await statusOf(client)).knowledge).toBe("unknown");
      const d = await client.createNewCommunity("D", "held while a fragment keeps failing", ["wss://fake"]);
      failNext(1e6); // the bunker stays down
      await settleFlush();
      expect(listPublishes(net.published)).toHaveLength(0);

      const exhausted = () => diagnostics.filter((diagnostic) => diagnostic.stage === "duty-exhausted");
      const round = async () => {
        await advance(internals, clock, 11_000);
        await settleFlush();
      };
      for (let i = 0; i < 6 && exhausted().length === 0; i++) await round();
      expect(exhausted()).toHaveLength(1);
      const readsAtExhaustion = listReads;
      const callsAtExhaustion = keyCalls;
      for (let i = 0; i < 4; i++) await round();

      expect(exhausted()).toHaveLength(1);
      const [report] = exhausted();
      expect(report.stage === "duty-exhausted" && report.duty).toBe("community-list-read");
      expect(report.key).toMatch(/^community-list-read:\d+:\d+:/);
      for (const id of [material.community_id, b.community_id, d.communityId]) expect(report.key).not.toContain(id);
      expect(listReads).toBe(readsAtExhaustion);
      expect(keyCalls).toBe(callsAtExhaustion);
      expect(internals.listDuties.pending).toBe(0);
      expect(listPublishes(net.published)).toHaveLength(0);
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("a failed unlock that withdraws the read evidence re-arms the read, so the held join is published (WR-01)", async () => {
    const { signer, material, old, storage } = await vault({ relayVault: false });
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [d0] });
    const { signer: flaky, failNext } = flakySigner(signer);
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage); // autoUnlock off: d=0 stays locked
      const internals = injectClock(client, clock);
      await client.start();
      const c = await client.createNewCommunity("C", "held over the locked list", ["wss://fake"]);
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "partial", pending: true });
      expect(internals.listDuties.pending).toBe(0); // an unlock, not a read, resolves a locked list

      failNext(1);
      await expect(client.unlockCommunityListFragments()).rejects.toThrow("bunker reconnecting");
      expect((await statusOf(client)).knowledge).toBe("unknown");
      expect(internals.listDuties.pending).toBe(1);
      await client.unlockCommunityListFragments();
      await settle();

      await advance(internals, clock, 6_000);
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = await fragmentOf(signer, lists[0]);
      for (const id of [material.community_id, c.communityId]) expect(idsOf(doc)).toContain(id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("a membership change made while start()'s read is still open waits for that read instead of superseding it (IN-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const c = await membership(pubkey, "C");
    const d0 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [d0] });
    const reads: Subject<NostrEvent>[] = [];
    net.setRequest(serveFragments(() => {
      const read = new Subject<NostrEvent>();
      reads.push(read);
      return concat(of(d0), read);
    }));
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      const started = client.start();
      await until(() => reads.length === 1);
      await settle();

      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settle();
      clock.tick(6_000);
      await internals.listDuties.idle();
      await settle();
      expect(reads).toHaveLength(1);
      expect(listPublishes(net.published)).toHaveLength(0);

      reads[0].complete();
      const joined = await joining;
      await started;
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(idsOf(await fragmentOf(signer, lists[0]))).toEqual(
        expect.arrayContaining([material.community_id, joined.communityId]),
      );
      expect(reads).toHaveLength(1);
      expect(diagnostics.filter((d) => d.stage === "community-list-read")).toHaveLength(0);
    } finally {
      await h.teardown();
    }
  });

  it("communityListDirty$ returns to false after a held save across three fragments is released", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const members = [await membership(pubkey, "A"), await membership(pubkey, "X"), await membership(pubkey, "Y")];
    const entries = entriesOf(members);
    const old = Math.floor(Date.now() / 1000) - 1000;
    const events = await Promise.all(
      entries.map((entry, index) => fragment(signer, index, { frags: 3, entries: [entry], tombstones: [] }, old)),
    );
    const storage = memoryStorage();
    await storage.setItem(pubkey, JSON.stringify({ entries, tombstones: [] }));
    const net = fakeRelayPool({ online: false, events });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      for (const member of members) await client.leave(member.community_id);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });

      net.setOnline(true);
      await advance(internals, clock, 6_000);
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists.map(dTag).sort()).toEqual(["0", "1", "2"]);
      const docs = await Promise.all(lists.map((event) => fragmentOf(signer, event)));
      for (const doc of docs) expect(doc.frags).toBe(3);
      expect(docs.flatMap((doc) => doc.tombstones.map((t) => t.community_id)).sort()).toEqual(
        members.map((member) => member.community_id).sort(),
      );
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("communityListDirty$ returns to false after an online createNewCommunity", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const net = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, memoryStorage());
      await client.start();
      await settle();
      expect((await statusOf(client)).knowledge).toBe("confirmed-empty");
      await client.createNewCommunity("B", "created online", ["wss://fake"]);
      await settleFlush();
      expect(listPublishes(net.published)).toHaveLength(1);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("an explicit saveCommunityList() after an exhausted read retry arms a fresh retry", async () => {
    const { signer, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    net.setRequest((filters) =>
      filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))
        ? throwError(() => new Error("relay down"))
        : EMPTY
    );
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      const created = await client.createNewCommunity("B", "held until a relay answers", ["wss://fake"]);
      await settle();
      await advance(internals, clock, 6_000);
      await advance(internals, clock, 6_000);
      await advance(internals, clock, 11_000);
      expect(internals.listDuties.pending).toBe(0); // exhausted
      expect(listPublishes(net.published)).toHaveLength(0);

      net.setRequest();
      await client.saveCommunityList();
      expect(internals.listDuties.pending).toBe(1);
      await advance(internals, clock, 6_000);
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = await fragmentOf(signer, lists[0]);
      expect(idsOf(doc)).toContain(material.community_id);
      expect(idsOf(doc)).toContain(created.communityId);
    } finally {
      await h.teardown();
    }
  });
});

/** Kind-33302 reads fail until the test answers them again with `net.setRequest()`. */
const listReadsFail = (filters: { kinds?: number[] }[]) =>
  filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))
    ? throwError(() => new Error("relay down"))
    : EMPTY;

/** Let the started client's list-read retry run out (about 5.5 s, then backoffs of 5.5 s and 10.5 s). */
async function exhaust(internals: DutyInternals, clock: ManualClock): Promise<void> {
  await advance(internals, clock, 6_000);
  await advance(internals, clock, 6_000);
  await advance(internals, clock, 11_000);
  expect(internals.listDuties.pending).toBe(0);
}

describe("Community List model-found regressions (D-31)", () => {
  it("an explicit saveCommunityList() with nothing to publish still renews an exhausted read (model seed 13)", async () => {
    const { signer, events, storage } = await vault();
    const net = fakeRelayPool({ events });
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const internals = injectClock(client, clock);
      await client.start();
      await settle();
      await client.saveCommunityList(); // the relay copy is now the published one: a later save has nothing to publish
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      client.stop();
      net.setRequest(listReadsFail);
      await client.start();
      await exhaust(internals, clock);
      expect((await statusOf(client)).knowledge).toBe("unknown");

      net.setRequest();
      const published = listPublishes(net.published).length;
      await client.saveCommunityList();
      expect(listPublishes(net.published)).toHaveLength(published);
      expect(internals.listDuties.pending).toBe(1);
      await advance(internals, clock, 6_000);
      expect((await statusOf(client)).knowledge).toBe("complete");
    } finally {
      await h.teardown();
    }
  });

  it("an app call that changes nothing still renews an exhausted read while the list is unknown (model seed 15)", async () => {
    for (const call of ["join", "start", "unlock", "leave"] as const) {
      const { signer, events, storage, material } = await vault();
      const net = fakeRelayPool({ events });
      net.setRequest(listReadsFail);
      const clock = new ManualClock();
      const h = harness();
      try {
        const client = h.client(signer, net.pool, storage, { autoUnlock: true });
        const internals = injectClock(client, clock);
        await client.start();
        await exhaust(internals, clock);
        net.setRequest();
        // Each call leaves the document as it was: a join of a held community, a repeated start, an unlock of the
        // already decrypted fragments, a leave of an unknown community.
        if (call === "join") await client.joinByBundle(buildInviteBundle(material, { name: "A" }));
        else if (call === "start") await client.start();
        else if (call === "unlock") await client.unlockCommunityListFragments();
        else await client.leave("0".repeat(64));
        expect({ call, pending: internals.listDuties.pending }).toEqual({ call, pending: 1 });
        await advance(internals, clock, 6_000);
        expect({ call, status: await statusOf(client) }).toEqual({
          call,
          status: { knowledge: "complete", pending: false },
        });
      } finally {
        await h.teardown();
      }
    }
  });

  it("another device's fragment arriving after an exhausted read renews it (model seed 84)", async () => {
    const { signer, pubkey, events, storage, material, old } = await vault();
    const b = await membership(pubkey, "B");
    const net = fakeRelayPool({ events });
    net.setRequest(listReadsFail);
    const store = new EventStore();
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { eventStore: store });
      const internals = injectClock(client, clock);
      await client.start();
      await exhaust(internals, clock);

      net.setRequest();
      store.add(await fragment(signer, 0, { frags: 2, entries: entriesOf([material, b]), tombstones: [] }, old + 10));
      await settle();
      expect(internals.listDuties.pending).toBe(1);
      await advance(internals, clock, 6_000);
      expect((await statusOf(client)).knowledge).not.toBe("unknown");
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("a start() that fails leaves the client stopped, so membership changes reject and the next start() reads (model seed 386)", async () => {
    const { signer, events, storage, material } = await vault();
    const net = fakeRelayPool({ events });
    let listReads = 0;
    net.setRequest((filters) => {
      if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
      if (filters.some((f) => f.until !== undefined)) return EMPTY;
      listReads++;
      return from(events);
    });
    const { signer: flaky, failNext } = flakySigner(signer);
    const h = harness();
    try {
      const client = h.client(flaky, net.pool, storage, { autoUnlock: true });
      failNext(1);
      await expect(client.start()).rejects.toThrow("bunker reconnecting");
      expect(client.phase$.value).toBe("idle");
      await expect(client.leave(material.community_id)).rejects.toBeInstanceOf(ConcordClientNotStartedError);
      expect(listReads).toBe(0);

      await client.start();
      await settle();
      expect(listReads).toBeGreaterThan(0);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      expect(client.getCommunity(material.community_id)).toBeDefined();
    } finally {
      await h.teardown();
    }
  });
});

describe("Community List gap regressions (01-REVIEW-GAPS)", () => {
  const otherThanList = (published: NostrEvent[]) => published.filter((e) => e.kind !== COMMUNITY_LIST_FRAGMENT_KIND);

  /**
   * CR-01: the join's save is queued behind an unlock parked on the signer, then another device's newer, larger
   * declaration (`d=1 frags: 2 [B]`) reaches the client's store before the signer answers.
   */
  async function saveQueuedBehindParkedUnlock(h: ReturnType<typeof harness>, store: EventStore, autoUnlock: boolean) {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const c = await membership(pubkey, "C");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const x = await fragment(signer, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    let park = false; // one-shot: parks exactly the next getPublicKey call once set
    const gate = new Gate<[], string>();
    const gated = gatedSigner(signer, {
      getPublicKey: gate,
      getPublicKeyWhen: () => (park ? (park = false, true) : false),
    });
    const client = h.client(gated, net.pool, storage, { eventStore: store, autoUnlock });
    await client.start();
    await settle();
    await client.unlockCommunityListFragments();
    await settle();
    expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

    park = true;
    const unlocking = client.unlockCommunityListFragments(); // the busy lane step
    const parked = await gate.next();
    const before = otherThanList(net.published).length;
    const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" }));
    await until(() => otherThanList(net.published).length > before); // the join's guestbook wrap
    await settle(); // the join's save is now queued behind the parked unlock
    store.add(x);
    parked.release();
    await unlocking;
    await joining;
    await settleFlush();
    return { signer, pubkey, material, b, c, x, net, client };
  }

  it("a save queued behind a parked unlock ingests the fragment that arrived while it waited and holds instead of publishing frags: 1 over frags: 2 (CR-01)", async () => {
    const store = new EventStore();
    const h = harness();
    try {
      const { signer, pubkey, material, c, x, net, client } = await saveQueuedBehindParkedUnlock(h, store, false);
      const lists = listPublishes(net.published);
      for (const doc of await Promise.all(lists.map((event) => fragmentOf(signer, event)))) {
        expect(doc.frags).not.toBe(1); // a frags: 1 fragment 0 would hide B
      }
      expect(lists).toHaveLength(0); // held behind the locked, larger declaration
      expect(await statusOf(client)).toEqual({ knowledge: "partial", pending: true });

      await client.unlockCommunityListFragments();
      await settleFlush();
      const zero = listPublishes(net.published).filter((event) => dTag(event) === "0");
      expect(zero).toHaveLength(1);
      const doc = await fragmentOf(signer, zero[0]);
      expect(doc.frags).toBe(2);
      expect(idsOf(doc)).toEqual(expect.arrayContaining([material.community_id, c.community_id]));
      expect(store.getReplaceable(COMMUNITY_LIST_FRAGMENT_KIND, pubkey, "1")?.id).toBe(x.id);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("with autoUnlock on, a save queued behind a parked unlock publishes under the arrived fragment's larger count, never frags: 1 (CR-01)", async () => {
    const store = new EventStore();
    const h = harness();
    try {
      const { signer, pubkey, material, b, c, x, net, client } = await saveQueuedBehindParkedUnlock(h, store, true);
      const lists = listPublishes(net.published);
      const docs = await Promise.all(lists.map((event) => fragmentOf(signer, event)));
      for (const doc of docs) expect(doc.frags).toBe(2); // never frags: 1, which would hide B
      const zero = lists.filter((event) => dTag(event) === "0");
      expect(zero).toHaveLength(1);
      expect(idsOf(await fragmentOf(signer, zero[0]))).toEqual(
        expect.arrayContaining([material.community_id, c.community_id]),
      );
      expect(store.getReplaceable(COMMUNITY_LIST_FRAGMENT_KIND, pubkey, "1")?.id).toBe(x.id);
      expect(client.getCommunity(b.community_id)).toBeDefined();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("a save retired by another device's fragment is retried, so the held join is published while relays answer (WR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const c = await membership(pubkey, "C");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    // A stale leftover (a staging copy), older than e1 and outside the governing count.
    const x = await fragment(signer, 3, { frags: 4, entries: [], tombstones: [] }, old - 50);
    const net = fakeRelayPool({ events: [e1] });
    // Only the Community List save encrypts with the user's key, so this parks the join's save in signing.
    const encrypt = new Gate<[pubkey: string, text: string], string>();
    let park = false;
    const parking = Object.assign(Object.create(signer), {
      nip44: {
        encrypt: encrypt.wrap(
          (target, text) => Promise.resolve(signer.nip44!.encrypt(target, text)),
          () => (park ? (park = false, true) : false),
        ),
        decrypt: (target: string, text: string) => signer.nip44!.decrypt(target, text),
      },
    }) as PrivateKeySigner;
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(parking, net.pool, storage, { eventStore: store }); // autoUnlock off
      const diagnostics: ConcordDiagnostic[] = [];
      client.diagnostics$.subscribe((d) => diagnostics.push(d));
      await client.start();
      await client.unlockCommunityListFragments();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

      park = true;
      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      const parked = await encrypt.next();
      store.add(x); // another device's fragment retires the in-flight save
      await joining;
      parked.release();
      await settleFlush();

      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(dTag(lists[0])).toBe("0");
      expect(idsOf(await fragmentOf(signer, lists[0]))).toEqual(
        expect.arrayContaining([material.community_id, c.community_id]),
      );
      expect(lists[0].created_at).toBeGreaterThan(e1.created_at);
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });
      expect(client.communityListDirty$.value).toBe(false);
      expect((client as unknown as DutyInternals).listDuties.pending).toBe(0);
      expect((client as unknown as { heldSaveDue(): boolean }).heldSaveDue()).toBe(false);
      expect(diagnostics.filter((d) => d.stage === "community-list-save")).toHaveLength(0);
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("with auto-save on, a save deferred by a locked kind-13302 list flags dirty once, does not loop, and runs after the unlock (WR-02)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const a = await membership(pubkey, "A");
    const c = await membership(pubkey, "C");
    const content = await signer.nip44!.encrypt(pubkey, JSON.stringify({ entries: entriesOf([a]), tombstones: [] }));
    const legacy = await signer.signEvent({ kind: COMMUNITY_LIST_KIND, content, tags: [], created_at: 1 });
    const net = fakeRelayPool({ events: [] }); // both list reads complete empty
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, memoryStorage(), { eventStore: store, autoSaveCommunityList: true });
      await client.start();
      await settle();
      expect((await statusOf(client)).knowledge).toBe("confirmed-empty");
      store.add(legacy); // another device's legacy list; it stays locked (autoUnlock off)
      let dirtyTrue = 0;
      client.communityListDirty$.subscribe((dirty) => dirty && dirtyTrue++);
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settle();

      await new Promise((r) => setTimeout(r, 500));
      const early = dirtyTrue;
      await new Promise((r) => setTimeout(r, 1_500));
      expect(dirtyTrue).toBe(early); // a looping deferral re-flags dirty every 200 ms
      expect(dirtyTrue).toBeLessThanOrEqual(2);
      expect(listPublishes(net.published)).toHaveLength(0);

      const cast = await firstValueFrom(client.communityList$.pipe(filter((cast) => cast?.id === legacy.id)));
      await cast!.unlock(signer);
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1); // the deferral was replayed, not stranded
      expect(idsOf(await fragmentOf(signer, lists[0]))).toEqual(
        expect.arrayContaining([a.community_id, c.community_id]),
      );
    } finally {
      await h.teardown();
      store.dispose();
    }
  });
});

describe("Resumable joins (D-34)", () => {
  /** A guestbook Join or a genesis edition reaches the relay as one NIP-59 gift wrap. */
  const GIFT_WRAP_KIND = 1059;
  const wraps = (published: NostrEvent[]) => published.filter((e) => e.kind === GIFT_WRAP_KIND).length;

  /** A signer whose `signEvent` rejects while `failing` is set, except for Community List fragments: the join's
   *  guestbook seal or a genesis edition fails while the Community List save still signs. */
  function sealFailing(signer: PrivateKeySigner): { signer: PrivateKeySigner; fail: (on: boolean) => void } {
    let failing = false;
    const wrapped = Object.assign(Object.create(signer), {
      signEvent: (draft: Parameters<PrivateKeySigner["signEvent"]>[0]) =>
        failing && draft.kind !== COMMUNITY_LIST_FRAGMENT_KIND
          ? Promise.reject(new Error("signer declined"))
          : signer.signEvent(draft),
    }) as PrivateKeySigner;
    return { signer: wrapped, fail: (on) => (failing = on) };
  }

  /** A remote signer that, while holding, parks every `signEvent` except a Community List fragment's; the test resolves
   *  or rejects each parked call, and `releaseAll` lets everything still parked sign. */
  function holdingSigner(inner: PrivateKeySigner) {
    const parked: Array<{ kind: number; resolve: () => void; reject: (error: unknown) => void }> = [];
    let holding = false;
    const signer = Object.assign(Object.create(inner), {
      signEvent: (draft: Parameters<PrivateKeySigner["signEvent"]>[0]) => {
        if (!holding || draft.kind === COMMUNITY_LIST_FRAGMENT_KIND) return inner.signEvent(draft);
        return new Promise((resolve, reject) => {
          parked.push({ kind: draft.kind, resolve: () => void inner.signEvent(draft).then(resolve, reject), reject });
        });
      },
    }) as PrivateKeySigner;
    return {
      signer,
      parked,
      hold: (on: boolean) => (holding = on),
      releaseAll: () => {
        holding = false;
        for (const call of parked.splice(0)) call.resolve();
      },
    };
  }

  /** The client's document and engines. */
  type Internals = {
    list: { community_id: string }[];
    tombstones: { community_id: string }[];
    communities: Map<string, unknown>;
  };
  const internals = (client: ConcordClient) => client as unknown as Internals;
  const mirrorIds = async (storage: ConcordStorage, pubkey: string) =>
    parseCommunityList((await storage.getItem(pubkey)) ?? undefined).entries.map((e) => e.community_id);
  const publishedIds = async (signer: PrivateKeySigner, published: NostrEvent[]) => {
    const ids = new Set<string>();
    for (const event of listPublishes(published)) {
      for (const entry of (await fragmentOf(signer, event)).entries) ids.add(entry.community_id);
    }
    return ids;
  };
  /** How many kind-33302 publishes carry `cid`. */
  const carrying = async (signer: PrivateKeySigner, published: NostrEvent[], cid: string) => {
    let count = 0;
    for (const event of listPublishes(published)) if (idsOf(await fragmentOf(signer, event)).includes(cid)) count++;
    return count;
  };

  it("a join rejected after it recorded the membership keeps it saved, and a retried join publishes exactly one Join and resolves (D-34, model seed 40)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const { signer, fail } = sealFailing(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage);
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "confirmed-empty", pending: false });

      fail(true);
      const error = await client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      expect((error as Error)?.message).toBe("signer declined"); // the original error
      await settleFlush();
      const engine = client.getCommunity(c.community_id);
      expect(engine).toBeDefined();
      expect(internals(client).list.map((e) => e.community_id)).toContain(c.community_id);
      expect(internals(client).tombstones.map((t) => t.community_id)).not.toContain(c.community_id);
      expect(await mirrorIds(storage, pubkey)).toContain(c.community_id);
      expect(await publishedIds(real, net.published)).toEqual(new Set([c.community_id])); // saved anyway
      expect(client.communityListDirty$.value).toBe(false);
      expect((await statusOf(client)).pending).toBe(false);
      expect(wraps(net.published)).toBe(0); // the Join never reached the relay

      fail(false);
      const lists = listPublishes(net.published).length;
      const retried = await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();
      expect(retried).toBe(engine);
      expect(retried).toBe(client.getCommunity(c.community_id));
      expect(wraps(net.published)).toBe(1); // the missing Join, once
      expect(listPublishes(net.published)).toHaveLength(lists); // the relay copy already carries C
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("a createNewCommunity() rejected after it recorded the membership keeps it saved (D-34, model seed 40)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const { signer, fail } = sealFailing(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage);
      await client.start();
      await settle();

      fail(true);
      const error = await client.createNewCommunity("B", "", ["wss://fake"]).then(() => undefined, (e) => e);
      expect((error as Error)?.message).toBe("signer declined");
      await settleFlush();
      expect(internals(client).communities.size).toBe(1);
      const [cid] = internals(client).communities.keys();
      expect(await mirrorIds(storage, pubkey)).toEqual([cid]);
      expect(await publishedIds(real, net.published)).toEqual(new Set([cid]));
      expect(client.communityListDirty$.value).toBe(false);
      // No retry: a second createNewCommunity() founds another community (D-36).
    } finally {
      await h.teardown();
    }
  });

  it("a rejected join keeps an unrelated held change pending and holds its own membership with it (D-34, model seed 40)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const a = await membership(pubkey, "A");
    const c = await membership(pubkey, "C");
    const { signer, fail } = sealFailing(real);
    const net = fakeRelayPool({ events: [] });
    net.setRequest(listReadsFail); // offline: the join of A is held
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage);
      await client.start();
      await client.joinByBundle(buildInviteBundle(a, { name: "A" }));
      await settle();
      expect(client.communityListDirty$.value).toBe(true);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });

      fail(true);
      await expect(client.joinByBundle(buildInviteBundle(c, { name: "C" }))).rejects.toThrow("signer declined");
      await settle();
      expect(client.getCommunity(a.community_id)).toBeDefined();
      expect(client.getCommunity(c.community_id)).toBeDefined();
      expect((await mirrorIds(storage, pubkey)).sort()).toEqual([a.community_id, c.community_id].sort());
      expect(client.communityListDirty$.value).toBe(true);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
      expect(listPublishes(net.published)).toHaveLength(0);
    } finally {
      await h.teardown();
    }
  });

  it("with auto-save on, a join rejected after its list was published stays joined, and a retry publishes exactly one Join (D-34, 01-REVIEW-GAPS-2 CR-01)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage, { autoSaveCommunityList: true });
      await client.start();
      await settle();

      held.hold(true);
      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      await until(() => held.parked.length > 0 && listPublishes(net.published).length > 0);
      expect(await carrying(real, net.published, c.community_id)).toBe(1); // the debounced save carried C
      for (const call of held.parked.splice(0)) call.reject(new Error("signer declined"));
      held.hold(false);
      expect(((await joining) as Error)?.message).toBe("signer declined");
      await settleFlush();
      expect(client.getCommunity(c.community_id)).toBeDefined();
      expect(await mirrorIds(storage, pubkey)).toContain(c.community_id);

      const before = wraps(net.published);
      const retried = await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();
      expect(retried).toBe(client.getCommunity(c.community_id));
      expect(wraps(net.published) - before).toBe(1); // the missing Join
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      held.releaseAll();
      await h.teardown();
    }
  });

  it("a join interrupted by stop() is restored joined by the next start(), and a retry publishes exactly one Join (D-34, 01-REVIEW-GAPS-2 CR-01)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage); // auto-save off
      await client.start();
      await settle();

      held.hold(true);
      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      await until(() => held.parked.length > 0);
      client.stop();
      held.releaseAll(); // the seal signs, but the engine was disposed during publication
      expect(await joining).toBeInstanceOf(Error);
      expect(await mirrorIds(storage, pubkey)).toContain(c.community_id);

      await client.start();
      await settleFlush();
      expect(client.getCommunity(c.community_id)).toBeDefined();
      expect(await carrying(real, net.published, c.community_id)).toBe(1); // the held save, published once

      const before = wraps(net.published);
      const retried = await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();
      expect(retried).toBe(client.getCommunity(c.community_id));
      expect(wraps(net.published) - before).toBe(1); // the missing Join
    } finally {
      held.releaseAll();
      await h.teardown();
    }
  });

  it("concurrent joins of one community share one engine, and a declined Join leaves the other call's Join and the saved membership (D-34, 01-REVIEW-GAPS-2 WR-02)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage);
      await client.start();
      await settle();

      held.hold(true);
      const first = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      await until(() => held.parked.length > 0);
      const second = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then((engine) => engine, (e) => e);
      await settle();
      held.parked.shift()!.reject(new Error("signer declined")); // the first call's Join
      held.releaseAll();
      expect(((await first) as Error)?.message).toBe("signer declined");
      const engine = await second;
      await settleFlush();
      expect(client.getCommunity(c.community_id)).toBeDefined(); // the resolved call left the client joined
      expect(engine).toBe(client.getCommunity(c.community_id));
      expect(internals(client).communities.size).toBe(1);
      expect(await mirrorIds(storage, pubkey)).toContain(c.community_id);
      expect(await carrying(real, net.published, c.community_id)).toBeGreaterThan(0);
      expect(wraps(net.published)).toBe(1); // the second call's Join
    } finally {
      held.releaseAll();
      await h.teardown();
    }
  });

  it("a join rejected while its list fragment awaits the relay's OK stays joined, and its fragment stands (D-34, 01-REVIEW-GAPS-2 CR-02)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    // The relay stores a kind-33302 fragment at once, but its OK is late while `holdOks` is set.
    const relayPublish = net.pool.publish.bind(net.pool) as unknown as (
      relays: string[],
      event: NostrEvent,
      options?: unknown,
    ) => Promise<unknown>;
    const oks: Array<() => void> = [];
    let holdOks = false;
    const releaseOks = () => {
      holdOks = false;
      for (const ok of oks.splice(0)) ok();
    };
    (net.pool as unknown as { publish: typeof relayPublish }).publish = (relays, event, options) => {
      const result = relayPublish(relays, event, options);
      if (!holdOks || event.kind !== COMMUNITY_LIST_FRAGMENT_KIND) return result;
      return new Promise((resolve) => oks.push(() => resolve(result)));
    };
    const storage = memoryStorage();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage, { autoSaveCommunityList: true });
      await client.start();
      await settle();

      held.hold(true);
      holdOks = true;
      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      await until(() => held.parked.length > 0 && oks.length > 0);
      held.parked.shift()!.reject(new Error("signer declined"));
      await settle();
      expect(client.getCommunity(c.community_id)).toBeDefined(); // a fragment carrying C is already on the relay

      releaseOks();
      held.releaseAll();
      expect(((await joining) as Error)?.message).toBe("signer declined");
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists.length).toBeGreaterThan(0);
      expect(await carrying(real, net.published, c.community_id)).toBe(lists.length);
      expect(await mirrorIds(storage, pubkey)).toContain(c.community_id);
      expect(client.communityListDirty$.value).toBe(false);

      await client.unlockCommunityListFragments();
      await settle();
      expect(client.getCommunity(c.community_id)).toBeDefined();
      const before = wraps(net.published);
      const retried = await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();
      expect(retried).toBe(client.getCommunity(c.community_id));
      expect(wraps(net.published) - before).toBe(1); // the missing Join
    } finally {
      releaseOks();
      held.releaseAll();
      await h.teardown();
    }
  });

  it("a join rejected while a kind-13302 list is reconciled stays joined and is published once (D-34, 01-REVIEW-GAPS-2 WR-01)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const a = await membership(pubkey, "A");
    const c = await membership(pubkey, "C");
    // Another device's legacy list holding A.
    const content = await real.nip44!.encrypt(pubkey, JSON.stringify({ entries: entriesOf([a]), tombstones: [] }));
    const legacy = await real.signEvent({ kind: COMMUNITY_LIST_KIND, content, tags: [], created_at: 1 });
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage, { eventStore: store }); // autoUnlock off
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "confirmed-empty", pending: false });
      store.add(legacy); // locked until the app unlocks it

      held.hold(true);
      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      await until(() => held.parked.length > 0);
      const cast = await firstValueFrom(client.communityList$.pipe(filter((list) => list?.id === legacy.id)));
      await cast!.unlock(real); // the app reconciles the legacy list while the Join is pending
      await settle();
      const before = listPublishes(net.published).length;
      held.parked.shift()!.reject(new Error("signer declined"));
      held.releaseAll();
      expect(((await joining) as Error)?.message).toBe("signer declined");
      await settleFlush();
      expect(client.getCommunity(a.community_id)).toBeDefined();
      expect(client.getCommunity(c.community_id)).toBeDefined();
      const after = listPublishes(net.published).slice(before);
      expect(after).toHaveLength(1);
      expect(idsOf(await fragmentOf(real, after[0]))).toEqual(
        expect.arrayContaining([a.community_id, c.community_id]),
      );
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      held.releaseAll();
      await h.teardown();
      store.dispose();
    }
  });

  it("a join rejected while the list is unknown holds its membership and publishes it once a relay answers (D-34, 01-REVIEW-GAPS-2 WR-03)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const { signer, fail } = sealFailing(real);
    const net = fakeRelayPool({ events: [] });
    net.setRequest(listReadsFail);
    const storage = memoryStorage();
    const clock = new ManualClock();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoSaveCommunityList: true });
      const duties = injectClock(client, clock);
      await client.start();
      await settle();

      fail(true);
      const error = await client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => undefined, (e) => e);
      expect((error as Error)?.message).toBe("signer declined");
      await settleFlush();
      expect(client.getCommunity(c.community_id)).toBeDefined();
      expect(await mirrorIds(storage, pubkey)).toContain(c.community_id);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
      expect(client.communityListDirty$.value).toBe(true);
      expect(listPublishes(net.published)).toHaveLength(0);

      fail(false);
      net.setRequest(); // relays answer again
      await advance(duties, clock, 6_000);
      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      expect(idsOf(await fragmentOf(real, lists[0]))).toContain(c.community_id);
      expect((await statusOf(client)).pending).toBe(false);
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  /** Every guestbook motion any engine of this test publishes, with whether its publication resolved. */
  function recordMotions() {
    const motions: { verb: string; ms: number; ok: boolean; rumor: Rumor }[] = [];
    const original = ConcordCommunity.prototype.publishToPlane;
    ConcordCommunity.prototype.publishToPlane = async function (target, rumor, opts) {
      if (target.plane !== "guestbook") return original.call(this, target, rumor, opts);
      const record = { verb: rumor.content.trim(), ms: rumorMs(rumor as Rumor), ok: false, rumor: rumor as Rumor };
      motions.push(record);
      const id = await original.call(this, target, rumor, opts);
      record.ok = true;
      return id;
    };
    return { motions, restore: () => (ConcordCommunity.prototype.publishToPlane = original) };
  }
  type Rumor = Parameters<typeof rumorMs>[0] & { content: string };

  /**
   * Answer the parked guestbook prompts until both calls settle: a remote signer answering the newest prompt first, or
   * an in-order signer answering everything parked in one tick.
   */
  async function answer(
    held: ReturnType<typeof holdingSigner>,
    order: "newest-first" | "in-order",
    done: () => boolean,
  ) {
    for (let i = 0; i < 200 && !done(); i++) {
      await new Promise((r) => setTimeout(r, 20));
      if (order === "newest-first") held.parked.pop()?.resolve();
      else for (const call of held.parked.splice(0)) call.resolve();
    }
    expect(done()).toBe(true);
  }

  /** One end state everywhere: the newest published motion, other members' fold, the engine, the document, the mirror
   *  and the newest published list all say `joined` (CORD-02 §5, §8). */
  async function expectAgreed(
    client: ConcordClient,
    context: { real: PrivateKeySigner; storage: ConcordStorage; net: ReturnType<typeof fakeRelayPool> },
    motions: { verb: string; ms: number; ok: boolean; rumor: Rumor }[],
    cid: string,
    joined: boolean,
  ) {
    const pubkey = await context.real.getPublicKey();
    const published = motions.filter((m) => m.ok).sort((x, y) => x.ms - y.ms || (x.rumor.id < y.rumor.id ? 1 : -1));
    expect(published.at(-1)?.verb).toBe(joined ? JOIN_VERB : LEAVE_VERB);
    const decoded = published.map((m) => ({ rumor: m.rumor, author: pubkey, ms: m.ms }));
    // deno-lint-ignore no-explicit-any -- the fold reads only rumor, author and ms; every author is a plain member
    expect(foldMembers(decoded as any, new Map(), new Set(), () => ({ isOwner: false }) as any).has(pubkey)).toBe(
      joined,
    );
    expect(client.getCommunity(cid) !== undefined).toBe(joined);
    expect(isCommunityLive(internals(client).list as never, internals(client).tombstones as never, cid)).toBe(joined);
    const mirror = parseCommunityList((await context.storage.getItem(pubkey)) ?? undefined);
    expect(isCommunityLive(mirror.entries, mirror.tombstones, cid)).toBe(joined);
    const newest = listPublishes(context.net.published).at(-1)!;
    const doc = await fragmentOf(context.real, newest);
    expect(isCommunityLive(doc.entries, doc.tombstones, cid)).toBe(joined);
  }

  /** J10: race a second call of the opposite intent against `first`, answer the prompts in `answering` order, and expect
   *  the motions in call order and every view to agree. */
  async function expectCallOrder(first: "leave" | "join", answering: "newest-first" | "in-order") {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const recorder = recordMotions();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage);
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" })); // a complete join
      await settleFlush();

      held.hold(true);
      let settled = 0;
      const join = () =>
        client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(
          (engine) => (settled++, { engine }),
          (error: Error) => (settled++, { error }),
        );
      const leave = () => client.leave(c.community_id).then(() => (settled++, "ok"), (e: Error) => (settled++, e));
      const firstCall = first === "leave" ? leave() : join();
      await until(() => held.parked.length === 1); // the first motion's seal waits on the signer
      await new Promise((r) => setTimeout(r, 10)); // the second call comes a few ms later
      const secondCall = first === "leave" ? join() : leave();
      await answer(held, answering, () => settled === 2);
      held.releaseAll();
      const [joined, left] = first === "leave"
        ? [await secondCall, await firstCall] as const
        : [await firstCall, await secondCall] as const;
      await settleFlush();

      expect(left).toBe("ok");
      expect("engine" in (joined as object)).toBe(true); // the join resolved
      const verbs = recorder.motions.filter((m) => m.ok).sort((x, y) => x.ms - y.ms).map((m) => m.verb);
      expect(verbs.slice(1)).toEqual(first === "leave" ? [LEAVE_VERB, JOIN_VERB] : [JOIN_VERB, LEAVE_VERB]);
      await expectAgreed(client, { real, storage, net }, recorder.motions, c.community_id, first === "leave");
      if (first === "leave") expect((joined as { engine: unknown }).engine).toBe(client.getCommunity(c.community_id));
    } finally {
      held.releaseAll();
      recorder.restore();
      await h.teardown();
    }
  }

  it("a join called while a leave is publishing, the newest prompt answered first: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)", () =>
    expectCallOrder("leave", "newest-first"));

  it("a join called while a leave is publishing, both prompts answered in one tick: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)", () =>
    expectCallOrder("leave", "in-order"));

  it("a leave called while a repeated join is publishing, the newest prompt answered first: the motions and the list take effect in call order and agree (D-34, 01-REVIEW-GAPS-3 CR-02)", () =>
    expectCallOrder("join", "newest-first"));

  it("after a join raced a leave, a later leave() and a later join still publish their motion and agree (D-34, 01-REVIEW-GAPS-3 CR-02)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const storage = memoryStorage();
    const recorder = recordMotions();
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, storage);
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      held.hold(true);
      let settled = 0;
      const leaving = client.leave(c.community_id).finally(() => settled++);
      await until(() => held.parked.length === 1);
      await new Promise((r) => setTimeout(r, 10));
      const joining = client.joinByBundle(buildInviteBundle(c, { name: "C" })).finally(() => settled++);
      await answer(held, "newest-first", () => settled === 2);
      held.releaseAll();
      await Promise.allSettled([leaving, joining]);
      await settleFlush();

      const before = wraps(net.published);
      await client.leave(c.community_id); // the app repairs: leave again
      await settleFlush();
      expect(wraps(net.published)).toBe(before + 1); // a Leave was published
      await expectAgreed(client, { real, storage, net }, recorder.motions, c.community_id, false);

      await client.joinByBundle(buildInviteBundle(c, { name: "C" })); // and joins again
      await settleFlush();
      expect(wraps(net.published)).toBe(before + 2);
      await expectAgreed(client, { real, storage, net }, recorder.motions, c.community_id, true);
    } finally {
      held.releaseAll();
      recorder.restore();
      await h.teardown();
    }
  });
  /** A storage whose next write of the user's mirror waits for the test (a slow disk or a busy IndexedDB). */
  function slowMirror(storage: ConcordStorage, pubkey: string) {
    const gate = new Gate<[key: string, value: string], void>();
    let park = false;
    const parkedSet = gate.wrap((key, value) => storage.setItem(key, value));
    const slow: ConcordStorage = {
      getItem: (key) => storage.getItem(key),
      setItem: (
        key,
        value,
      ) => (park && key === pubkey ? (park = false, parkedSet(key, value)) : storage.setItem(key, value)),
      removeItem: (key) => storage.removeItem(key),
    };
    return { storage: slow, gate, parkNext: () => (park = true) };
  }

  it("after a Leave prompt that is never answered, stop() and start() let the same community's join and leave run (D-30, D-34, 01-REVIEW-GAPS-4 CR-02)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, memoryStorage());
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      held.hold(true);
      const leaving = client.leave(c.community_id).catch(() => {});
      await until(() => held.parked.length === 1); // the user dismissed the Leave prompt; it never settles
      held.hold(false);

      client.stop();
      await client.start();
      await settle();
      const join = await within(
        client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => "ok", (error: unknown) => error),
        3000,
      );
      const leave = await within(client.leave(c.community_id).then(() => "ok", (error: unknown) => error), 3000);
      held.releaseAll();
      await leaving;
      await settleFlush();

      expect(join).toBe("ok");
      expect(leave).toBe("ok");
      expect(client.getCommunity(c.community_id)).toBeUndefined();
      expect(isCommunityLive(internals(client).list as never, internals(client).tombstones as never, c.community_id))
        .toBe(false);
    } finally {
      held.releaseAll();
      await h.teardown();
    }
  });

  it("a join queued behind a Leave prompt that is never answered rejects with ConcordClientDisposedError as soon as dispose() runs (D-32, D-34, 01-REVIEW-GAPS-4 CR-02)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, memoryStorage());
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      held.hold(true);
      const leaving = client.leave(c.community_id).catch(() => {});
      await until(() => held.parked.length === 1);
      held.hold(false);
      const join = client.joinByBundle(buildInviteBundle(c, { name: "C" })).then(() => "ok", (error: unknown) => error);
      client.stop();
      client.dispose();
      const outcome = await within(join, 1000);
      held.releaseAll();
      await leaving;

      expect(outcome).toBeInstanceOf(ConcordClientDisposedError);
    } finally {
      held.releaseAll();
      await h.teardown();
    }
  });

  it("a leave() called before stop() and queued behind a slow join rejects with ConcordClientNotStartedError and publishes nothing after the restart (D-30, D-34, 01-REVIEW-GAPS-4 CR-02)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, memoryStorage());
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      held.hold(true);
      const rejoin = client.joinByBundle(buildInviteBundle(c, { name: "C" })).catch(() => {});
      await until(() => held.parked.length === 1); // the repeated Join waits on the signer
      held.hold(false);
      const leaving = client.leave(c.community_id).then(() => "ok", (error: unknown) => error);
      client.stop(); // the app pauses: nothing called before this may take effect afterwards (D-30)
      await client.start();
      await settle();
      const before = wraps(net.published);
      const listsBefore = listPublishes(net.published).length;
      held.releaseAll(); // the old Join prompt is answered
      const outcome = await within(leaving, 3000);
      await rejoin;
      await settleFlush();

      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
      expect(wraps(net.published)).toBe(before); // no Leave in the next lifecycle
      expect(internals(client).tombstones.some((t) => t.community_id === c.community_id)).toBe(false);
      expect(await carrying(real, listPublishes(net.published).slice(listsBefore), c.community_id)).toBe(0);
      expect(client.getCommunity(c.community_id)).toBeDefined();
    } finally {
      held.releaseAll();
      await h.teardown();
    }
  });

  /** A1/A2: a join or leave whose list mutation waits behind a slow mirror write when stop() and start() run. */
  async function expectMutationRefusedAcrossRestart(call: "join" | "leave") {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const d = await membership(pubkey, "D");
    const e = await membership(pubkey, "E");
    const net = fakeRelayPool({ events: [] });
    const slow = slowMirror(memoryStorage(), pubkey);
    const h = harness();
    try {
      const client = h.client(real, net.pool, slow.storage);
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      slow.parkNext();
      const joinD = client.joinByBundle(buildInviteBundle(d, { name: "D" })).then(
        () => "ok",
        (error: unknown) => error,
      );
      const parked = await slow.gate.next(); // D's mirror write is slow, so the document lane waits on it
      const before = wraps(net.published);
      const second = call === "join"
        ? client.joinByBundle(buildInviteBundle(e, { name: "E" }))
        : client.leave(c.community_id);
      const outcome = second.then(() => "ok", (error: unknown) => error);
      if (call === "leave") await until(() => wraps(net.published) === before + 1); // the Leave went out in lifecycle 1
      await settle(); // its list mutation now waits behind D's
      client.stop();
      const restarting = client.start();
      parked.release();
      await restarting;
      const first = await within(joinD, 3000);
      const result = await within(outcome, 3000);
      await settleFlush();

      expect(result).toBeInstanceOf(ConcordClientNotStartedError);
      // D was recorded in lifecycle 1, so the next lifecycle's held save publishes it; D's own call saves nothing.
      expect(first).toBeInstanceOf(ConcordClientNotStartedError);
      if (call === "join") {
        expect(client.getCommunity(e.community_id)).toBeUndefined();
        expect(internals(client).list.some((entry) => entry.community_id === e.community_id)).toBe(false);
        expect(await mirrorIds(slow.storage, pubkey)).not.toContain(e.community_id);
        expect(await carrying(real, net.published, e.community_id)).toBe(0);
      } else {
        expect(internals(client).tombstones.some((t) => t.community_id === c.community_id)).toBe(false);
        expect(client.getCommunity(c.community_id)).toBeDefined();
      }
    } finally {
      await h.teardown();
    }
  }

  it("a join whose list mutation waits behind a slow mirror write when stop() and start() run rejects with ConcordClientNotStartedError and records nothing in the next lifecycle (D-30, D-34, 01-REVIEW-GAPS-4 audit)", () =>
    expectMutationRefusedAcrossRestart("join"));

  it("a leave whose list mutation waits behind a slow mirror write when stop() and start() run rejects with ConcordClientNotStartedError and tombstones nothing in the next lifecycle (D-30, D-34, 01-REVIEW-GAPS-4 audit)", () =>
    expectMutationRefusedAcrossRestart("leave"));

  it("a leave whose own mirror write spans stop() and start() rejects with ConcordClientNotStartedError and the next lifecycle saves its tombstone (D-30, D-34, 01-REVIEW-GAPS-4 audit, 01-REVIEW-GAPS-5 WR-03)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const net = fakeRelayPool({ events: [] });
    const slow = slowMirror(memoryStorage(), pubkey);
    const h = harness();
    try {
      const client = h.client(real, net.pool, slow.storage);
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      slow.parkNext();
      const leaving = client.leave(c.community_id).then(() => "ok", (error: unknown) => error);
      const parked = await slow.gate.next(); // the Leave went out and the tombstone is recorded; its mirror write waits
      client.stop();
      const restarting = client.start();
      parked.release();
      await restarting;
      const outcome = await within(leaving, 3000);
      await settleFlush();

      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
      // The tombstone was recorded in lifecycle 1, so it stays (D-34) and lifecycle 2 saves it everywhere.
      expect(client.getCommunity(c.community_id)).toBeUndefined();
      const cid = c.community_id;
      expect(isCommunityLive(internals(client).list as never, internals(client).tombstones as never, cid)).toBe(false);
      const mirror = parseCommunityList((await slow.storage.getItem(pubkey)) ?? undefined);
      expect(mirror.tombstones.map((t) => t.community_id)).toContain(cid);
      expect(isCommunityLive(mirror.entries, mirror.tombstones, cid)).toBe(false);
      const newest = await fragmentOf(real, listPublishes(net.published).at(-1)!);
      expect(newest.tombstones.map((t) => t.community_id)).toContain(cid);
      expect(isCommunityLive(newest.entries, newest.tombstones, cid)).toBe(false);
      expect(client.communityListDirty$.value).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("a joinByLink() whose bundle fetch spans stop() and start() rejects with ConcordClientNotStartedError and joins nothing (D-30, 01-REVIEW-GAPS-4 audit)", async () => {
    const owner = new PrivateKeySigner(generateSecretKey());
    const c = await membership(await owner.getPublicKey(), "C");
    const token = newInviteToken();
    const linkSk = generateSecretKey();
    const bundle = buildInviteBundle(c, { name: "C", creator_npub: await owner.getPublicKey() });
    const bundleEvent = finalizeEvent(await InviteBundleFactory.create(bundle, token), linkSk) as NostrEvent;
    const link = buildInviteLink("https://app.example", getPublicKey(linkSk), token, ["wss://fake"]);
    const net = fakeRelayPool({ events: [bundleEvent] });
    const h = harness();
    try {
      const client = h.client(new PrivateKeySigner(generateSecretKey()), net.pool, memoryStorage());
      await client.start();
      await settle();
      const joining = client.joinByLink(link).then(() => "ok", (error: unknown) => error);
      client.stop(); // while the bundle is being fetched
      await client.start();
      await settle();
      const outcome = await within(joining, 3000);
      await settleFlush();

      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
      expect(client.getCommunity(c.community_id)).toBeUndefined();
      expect(internals(client).list.some((entry) => entry.community_id === c.community_id)).toBe(false);
      expect(wraps(net.published)).toBe(0);
    } finally {
      await h.teardown();
    }
  });

  it("a createNewCommunity() whose genesis spans stop() and start() rejects with ConcordClientNotStartedError and creates nothing (D-30, 01-REVIEW-GAPS-4 audit)", async () => {
    const net = fakeRelayPool({ events: [] });
    const h = harness();
    try {
      const client = h.client(new PrivateKeySigner(generateSecretKey()), net.pool, memoryStorage());
      await client.start();
      await settle();
      const creating = client.createNewCommunity("N", "", []).then(() => "ok", (error: unknown) => error);
      client.stop(); // while the genesis is being built
      await client.start();
      await settle();
      const outcome = await within(creating, 3000);
      await settleFlush();

      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
      expect(internals(client).list).toHaveLength(0);
      expect(internals(client).communities.size).toBe(0);
      expect(wraps(net.published)).toBe(0);
    } finally {
      await h.teardown();
    }
  });

  it("a joinByLink() whose bundle fetch spans stop() and start() rejects with ConcordClientNotStartedError at once, even behind a next-lifecycle leave of that community that never settles (D-30, 01-REVIEW-GAPS-5 WR-01)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const c = await membership(pubkey, "C");
    const token = newInviteToken();
    const linkSk = generateSecretKey();
    const bundle = buildInviteBundle(c, { name: "C", creator_npub: pubkey });
    const bundleEvent = finalizeEvent(await InviteBundleFactory.create(bundle, token), linkSk) as NostrEvent;
    const link = buildInviteLink("https://app.example", getPublicKey(linkSk), token, ["wss://fake"]);
    const held = holdingSigner(real);
    const net = fakeRelayPool({ events: [] });
    let releaseFetch!: () => void;
    const fetchGate = new Promise<void>((resolve) => (releaseFetch = resolve));
    let fetches = 0;
    net.setRequest((filters) =>
      filters.some((f) => f.kinds?.includes(33301)) ? (fetches++, from(fetchGate.then(() => bundleEvent))) : EMPTY
    );
    const h = harness();
    try {
      const client = h.client(held.signer, net.pool, memoryStorage());
      await client.start();
      await settle();
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();

      const joining = client.joinByLink(link).then(() => "ok", (error: unknown) => error);
      await until(() => fetches === 1); // lifecycle 1: the bundle fetch is in flight
      client.stop();
      await client.start();
      await settle();
      // Lifecycle 2: the user's leave() of C waits on a Leave prompt that is never answered.
      held.hold(true);
      const leaving = client.leave(c.community_id).catch(() => {});
      await until(() => held.parked.length === 1);
      held.hold(false);
      releaseFetch(); // the lifecycle-1 fetch resolves now
      const outcome = await within(joining, 1000);
      held.releaseAll();
      await leaving;
      await settleFlush();

      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
    } finally {
      releaseFetch();
      held.releaseAll();
      await h.teardown();
    }
  });
});

describe("Community List sync API on the lane (D-35)", () => {
  it("receive() on the client's view of a fragment that becomes the newest declaration can be unlocked and does not block later saves (WR-03)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    // Fetched by the app elsewhere: a newer declaration that no relay of the client serves.
    const supplied = await fragment(
      signer,
      0,
      { frags: 1, entries: entriesOf([material, b]), tombstones: [] },
      old + 10,
    );
    const net = fakeRelayPool({ events: [e1] });
    const h = harness();
    const store = new EventStore();
    try {
      const client = h.client(signer, net.pool, storage, { eventStore: store }); // autoUnlock off
      const before = await client.communityListSync.receive(supplied, false); // before start(): no lane yet
      expect(before).toBe(false);
      expect(store.hasEvent(supplied.id)).toBe(true);
      await client.start();
      await settle();
      await client.unlockCommunityListFragments();
      await settle();
      expect(client.memberships().entries.map((e) => e.community_id)).toContain(b.community_id);
      // A second supplied copy, newer still, received through the lane while the client runs.
      const newer = await fragment(
        signer,
        0,
        { frags: 1, entries: entriesOf([material, b]), tombstones: [] },
        old + 20,
      );
      expect(await client.communityListSync.receive(newer, false)).toBe(false);
      expect(store.hasEvent(newer.id)).toBe(true);
      expect(client.memberships().locked).toBe(true);
      await client.unlockCommunityListFragments();
      await settle();
      expect(client.memberships().locked).toBe(false);
      await client.leave(b.community_id);
      await settle();
      const documents = await Promise.all(listPublishes(net.published).map((event) => fragmentOf(signer, event)));
      expect(documents.some((doc) => doc.tombstones.some((t) => t.community_id === b.community_id))).toBe(true);
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  /** The memberships a reader of `events` sees: the newest copy per index, under the newest declaration's count
   *  (CORD-02 §8). */
  async function liveIds(signer: PrivateKeySigner, events: NostrEvent[]): Promise<string[]> {
    const newest = new Map<string, NostrEvent>();
    for (const event of events) {
      const prior = newest.get(dTag(event)!);
      if (
        !prior || event.created_at > prior.created_at || (event.created_at === prior.created_at && event.id < prior.id)
      ) {
        newest.set(dTag(event)!, event);
      }
    }
    const held = await Promise.all(
      [...newest.values()].map(async (event) => ({ event, doc: await fragmentOf(signer, event) })),
    );
    const governing = held.reduce((best, next) => (next.event.created_at > best.event.created_at ? next : best));
    const ids = new Set<string>();
    for (const { event, doc } of held) {
      if (Number(dTag(event)) < governing.doc.frags) { for (const id of idsOf(doc)) ids.add(id); }
    }
    return [...ids];
  }

  /** Whether a NIP-44 plaintext the signer is asked to encrypt is a Community List fragment carrying `cid`. */
  function carries(text: string, cid: string): boolean {
    try {
      return idsOf(decodeCommunityListFragment(text)).includes(cid);
    } catch {
      return false; // not a Community List fragment
    }
  }

  /**
   * 01-REVIEW-GAPS-2 CR-03: the app's `write()` or `repack()` is called while an unlock is parked on the signer and
   * another device's newer, larger declaration (`d=1 frags: 2 [B]`) sits in the store, not yet ingested.
   */
  async function appCallBehindParkedStep(
    h: ReturnType<typeof harness>,
    store: EventStore,
    call: (client: ConcordClient, members: { a: JoinMaterial; c: JoinMaterial }) => Promise<void>,
  ) {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const c = await membership(pubkey, "C");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const x = await fragment(signer, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    let park = false; // one-shot: parks exactly the next getPublicKey call once set
    const gate = new Gate<[], string>();
    const gated = gatedSigner(signer, {
      getPublicKey: gate,
      getPublicKeyWhen: () => (park ? (park = false, true) : false),
    });
    const client = h.client(gated, net.pool, storage, { eventStore: store }); // autoUnlock off
    await client.start();
    await settle();
    await client.unlockCommunityListFragments();
    await settle();
    expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

    park = true;
    const unlocking = client.unlockCommunityListFragments(); // the busy lane step
    await gate.next();
    store.add(x); // its ingest step waits behind the parked unlock
    await settle();
    const outcome = call(client, { a: material, c }).then(() => "ok" as const, (error: unknown) => error);
    for (const parked of gate.calls) parked.release();
    await unlocking;
    const result = await outcome;
    await settleFlush();
    return { signer, material, b, e1, x, net, client, outcome: result };
  }

  it("client.communityListSync.repack() queued behind a parked lane step ingests the arrived fragment first and never erases its membership (D-35, 01-REVIEW-GAPS-2 CR-03)", async () => {
    const store = new EventStore();
    const h = harness();
    try {
      const { signer, material, b, e1, x, net, client, outcome } = await appCallBehindParkedStep(
        h,
        store,
        (client) => client.communityListSync.repack(client.communityListSync.fragments.document),
      );
      // X is newer and still locked, so the repack is refused; one that unlocked X first may succeed, keeping B.
      if (outcome !== "ok") expect(outcome).toBeInstanceOf(CommunityListUnknownError);
      const lists = listPublishes(net.published);
      const newer = lists.filter((event) => event.created_at > x.created_at);
      if (outcome !== "ok") expect(newer).toHaveLength(0);
      for (const event of newer) expect((await fragmentOf(signer, event)).frags).not.toBe(1); // would hide B
      expect(await liveIds(signer, [e1, x, ...lists])).toEqual(
        expect.arrayContaining([material.community_id, b.community_id]),
      );

      await client.unlockCommunityListFragments();
      await settleFlush();
      expect(client.communityListSync.fragments.count).toBe(2);
      expect(idsOf(client.communityListSync.fragments.document)).toEqual(
        expect.arrayContaining([material.community_id, b.community_id]),
      );
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  it("client.communityListSync.write() queued behind a parked lane step never publishes frags: 1 over the arrived frags: 2 (D-35, 01-REVIEW-GAPS-2 CR-03)", async () => {
    const store = new EventStore();
    const h = harness();
    try {
      const { signer, material, b, e1, x, net, client, outcome } = await appCallBehindParkedStep(
        h,
        store,
        (client, { a, c }) =>
          client.communityListSync.write({ entries: entriesOf([a, c]), tombstones: [] }, [c.community_id]),
      );
      // X is newer and still locked, so the write is refused; one that unlocked X first may succeed, keeping B.
      if (outcome !== "ok") expect(outcome).toBeInstanceOf(CommunityListUnknownError);
      const lists = listPublishes(net.published);
      for (const event of lists.filter((event) => event.created_at > x.created_at)) {
        expect((await fragmentOf(signer, event)).frags).not.toBe(1); // would hide B
      }
      expect(await liveIds(signer, [e1, x, ...lists])).toEqual(
        expect.arrayContaining([material.community_id, b.community_id]),
      );

      await client.unlockCommunityListFragments();
      await settleFlush();
      expect(client.communityListSync.fragments.count).toBe(2);
      expect(idsOf(client.communityListSync.fragments.document)).toContain(b.community_id);
    } finally {
      await h.teardown();
      store.dispose();
    }
  });

  /**
   * 01-REVIEW-GAPS-3 CR-01: the app's call is queued on lane 1 behind a parked unlock; stop() and start() open lane 2,
   * whose read completes; lane 2 is then busy on its own parked unlock while another device's newer, larger declaration
   * (`d=1 frags: 2 [B]`) lands in the store; only then does lane 1's parked step finish.
   */
  async function appCallAcrossRestart(
    h: ReturnType<typeof harness>,
    store: EventStore,
    call: (client: ConcordClient, members: { a: JoinMaterial; c: JoinMaterial }) => Promise<void>,
  ) {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const c = await membership(pubkey, "C");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const x = await fragment(signer, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    let park = false; // one-shot: parks exactly the next getPublicKey call once set
    const gate = new Gate<[], string>();
    const gated = gatedSigner(signer, {
      getPublicKey: gate,
      getPublicKeyWhen: () => (park ? (park = false, true) : false),
    });
    const client = h.client(gated, net.pool, storage, { eventStore: store }); // autoUnlock off
    await client.start();
    await settle();
    await client.unlockCommunityListFragments();
    await settle();
    expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

    park = true;
    const unlocking1 = client.unlockCommunityListFragments().catch(() => {}); // lane 1 is busy
    const parked1 = await gate.next();
    const outcome = call(client, { a: material, c }).then(() => "ok" as const, (error: unknown) => error);
    client.stop();
    await client.start();
    await settle();
    expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false }); // lane 2 holds evidence
    park = true;
    const unlocking2 = client.unlockCommunityListFragments().catch(() => {}); // lane 2 is busy
    const parked2 = await gate.next();
    store.add(x); // its ingest waits behind lane 2's parked unlock
    await settle();
    parked1.release(); // lane 1's step finishes; the queued app call never ran on it
    const result = await outcome;
    const lists = listPublishes(net.published);
    parked2.release();
    await unlocking1;
    await unlocking2;
    await settleFlush();
    return { signer, material, b, e1, x, lists, client, outcome: result };
  }

  /** F1/F2: the queued call rejects, publishes nothing newer than X that declares `frags: 1`, and B stays live. */
  async function expectQueuedCallRefused(mode: "repack" | "write") {
    const store = new EventStore();
    const h = harness();
    try {
      const { signer, material, b, e1, x, lists, client, outcome } = await appCallAcrossRestart(
        h,
        store,
        mode === "repack"
          ? (client) => client.communityListSync.repack(client.communityListSync.fragments.document)
          : (client, { a, c }) =>
            client.communityListSync.write({ entries: entriesOf([a, c]), tombstones: [] }, [c.community_id]),
      );
      for (const event of lists.filter((event) => event.created_at > x.created_at)) {
        expect((await fragmentOf(signer, event)).frags).not.toBe(1); // would hide B
      }
      expect(await liveIds(signer, [e1, x, ...lists])).toEqual(
        expect.arrayContaining([material.community_id, b.community_id]),
      );
      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);

      await client.unlockCommunityListFragments();
      await settleFlush();
      expect(client.communityListSync.fragments.count).toBe(2);
      expect(idsOf(client.communityListSync.fragments.document)).toContain(b.community_id);
    } finally {
      await h.teardown();
      store.dispose();
    }
  }

  it("client.communityListSync.repack() queued on a lane that stop() closed rejects with ConcordClientNotStartedError and never publishes after the restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)", () =>
    expectQueuedCallRefused("repack"));

  it("client.communityListSync.write() queued on a lane that stop() closed rejects with ConcordClientNotStartedError and never publishes after the restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)", () =>
    expectQueuedCallRefused("write"));

  it("client.communityListSync.write() called on a stopped client rejects with ConcordClientNotStartedError and never publishes after a restart (D-30, D-35, 01-REVIEW-GAPS-3 CR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const d = await membership(pubkey, "D");
    const e = await membership(pubkey, "E");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [e1] });
    // A remote signer whose next encrypt (a Community List fragment being written) waits for the test.
    const parked: Array<() => void> = [];
    let park = false;
    const gated = Object.assign(Object.create(signer), {
      nip44: {
        encrypt: (to: string, text: string) =>
          park
            ? (park = false,
              new Promise<string>((resolve, reject) => {
                parked.push(() => signer.nip44!.encrypt(to, text).then(resolve, reject));
              }))
            : signer.nip44!.encrypt(to, text),
        decrypt: (from: string, text: string) => signer.nip44!.decrypt(from, text),
      },
    }) as PrivateKeySigner;
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(gated, net.pool, storage, { eventStore: store });
      await client.start();
      await settle();
      await client.unlockCommunityListFragments();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

      park = true;
      const first = client.communityListSync.write({ entries: entriesOf([material, d]), tombstones: [] }, [
        d.community_id,
      ]).then(() => "ok", (error: unknown) => error);
      await until(() => parked.length === 1); // lane 1's app write is signing
      client.stop();
      const stopped = client.communityListSync.write({ entries: entriesOf([material, e]), tombstones: [] }, [
        e.community_id,
      ]).then(() => "ok", (error: unknown) => error);
      await client.start();
      await settle();
      for (const release of parked.splice(0)) release();
      await first;
      const outcome = await stopped;
      await settleFlush();

      let carried = 0;
      for (const event of listPublishes(net.published)) {
        if (idsOf(await fragmentOf(signer, event)).includes(e.community_id)) carried++;
      }
      expect(carried).toBe(0); // nothing called on the stopped client was published by the next lifecycle
      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
    } finally {
      for (const release of parked.splice(0)) release();
      await h.teardown();
      store.dispose();
    }
  });

  it("client.communityListSync.write() whose lane step started and waits on the sync behind a retired save rejects with ConcordClientNotStartedError and never prompts the signer or publishes in the next lifecycle (D-30, D-35, 01-REVIEW-GAPS-4 CR-01, 01-REVIEW-GAPS-5 CR-01)", async () => {
    const { signer: real, pubkey, material: a, old, storage } = await vault({ relayVault: false });
    const b = await membership(pubkey, "B");
    const c = await membership(pubkey, "C");
    const d = await membership(pubkey, "D");
    const e = await membership(pubkey, "E");
    const e1 = await fragment(real, 0, { frags: 1, entries: entriesOf([a]), tombstones: [] }, old);
    const x = await fragment(real, 1, { frags: 2, entries: entriesOf([b]), tombstones: [] }, old + 10);
    const net = fakeRelayPool({ events: [e1] });
    // A remote signer: the next self-encrypt (a Community List fragment) and the next unlock's getPublicKey can wait for
    // the test.
    const encrypts: Array<() => void> = [];
    const keys: Array<() => void> = [];
    let parkEncrypt = false;
    let parkUnlock = false;
    let lifecycle2 = false;
    let lifecycle2PromptsForC = 0; // only the rejected write carries C: the client's document never holds it
    const signer = Object.assign(Object.create(real), {
      getPublicKey: () => {
        if (!parkUnlock || !(new Error().stack ?? "").includes("unlockBody")) return real.getPublicKey();
        parkUnlock = false;
        return new Promise<string>((resolve) => keys.push(() => resolve(pubkey)));
      },
      signEvent: (draft: Parameters<PrivateKeySigner["signEvent"]>[0]) => real.signEvent(draft),
      nip44: {
        encrypt: (to: string, text: string) =>
          lifecycle2 && carries(text, c.community_id)
            ? (lifecycle2PromptsForC++, real.nip44!.encrypt(to, text))
            : parkEncrypt && to === pubkey
            ? (parkEncrypt = false,
              new Promise<string>((resolve, reject) =>
                encrypts.push(() => real.nip44!.encrypt(to, text).then(resolve, reject))
              ))
            : real.nip44!.encrypt(to, text),
        decrypt: (from: string, text: string) => real.nip44!.decrypt(from, text),
      },
    }) as PrivateKeySigner;
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { eventStore: store, autoUnlock: false });
      const residue: unknown[] = [];
      client.diagnostics$.subscribe((diagnostic) => {
        if (diagnostic.stage === "community-list-residue") residue.push(diagnostic);
      });
      await client.start();
      await settle();
      await client.unlockCommunityListFragments();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false });

      // Lifecycle 1: joining D saves the list, and that save's fragment encrypt waits on the signer (S1).
      parkEncrypt = true;
      const joinD = client.joinByBundle(buildInviteBundle(d, { name: "D" })).catch(() => {});
      await until(() => encrypts.length === 1);
      // The app's write queues on lane 1 behind S1.
      const write = client.communityListSync.write({ entries: entriesOf([a, c]), tombstones: [] }, [c.community_id])
        .then(() => "ok" as const, (error: unknown) => error);
      // Joining E changes the document, which retires S1 and releases lane 1: the write's step starts, and its sync
      // write waits on the sync's serial tail behind S1's write, which is still signing.
      const joinE = client.joinByBundle(buildInviteBundle(e, { name: "E" })).catch(() => {});
      await settle();

      client.stop();
      lifecycle2 = true;
      await client.start();
      await settle();
      expect(await statusOf(client)).toEqual({ knowledge: "complete", pending: false }); // lane 2 holds evidence
      // Lane 2 is busy on an unlock while another device's newer, larger declaration lands: lane 2 has not ingested it.
      parkUnlock = true;
      const unlocking = client.unlockCommunityListFragments().catch(() => {});
      store.add(x);
      await until(() => keys.length === 1);
      const before = listPublishes(net.published).length;

      // S1's encrypt is answered: S1 is refused (its lane closed), then the write's sync task runs.
      for (const release of encrypts.splice(0)) release();
      const outcome = await within(write, 3000);
      await settle();
      const lists = listPublishes(net.published).slice(before);
      for (const release of keys.splice(0)) release();
      await unlocking;
      await joinD;
      await joinE;
      await settleFlush();

      for (const event of lists.filter((event) => event.created_at > x.created_at)) {
        expect((await fragmentOf(real, event)).frags).not.toBe(1); // would hide B
      }
      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
      expect(lifecycle2PromptsForC).toBe(0); // the rejected write never asks the signer in lifecycle 2

      // LIST-05: lane 1's close abandons the sync's serial tail, so lifecycle 2's own held save no longer waits behind
      // S1's unanswered prompt: it publishes `frags: 1` (dated now) before the other device's older-dated `x` lands.
      // On the relays that save outranks `x`, so B, held only in `x` at index 1, is dormant: an older-dated declaration
      // that arrives late. The end state over every publication must keep B as reported residue, never drop it.
      const relayState = () => [e1, x, ...listPublishes(net.published)];
      const own = listPublishes(net.published).slice(0, before).filter((event) => event.created_at > x.created_at);
      expect(own.length).toBeGreaterThan(0);
      expect(await liveIds(real, relayState())).not.toContain(b.community_id);
      expect(client.memberships().locked).toBe(false);
      expect(client.communityListSync.fragments.dormantResidue).toEqual([1]);
      expect(residue.length).toBeGreaterThan(0);
      // The next explicit save repairs it: the repack merges the dormant copy before emptying it (D-19, D-20).
      const published = listPublishes(net.published).length;
      await client.saveCommunityList();
      for (let i = 0; i < 400 && (await liveIds(real, relayState())).includes(b.community_id) === false; i++) {
        await new Promise((r) => setTimeout(r, 25));
      }
      expect(listPublishes(net.published).length).toBeGreaterThan(published);
      expect(await liveIds(real, relayState())).toContain(b.community_id);
      expect(idsOf(client.communityListSync.fragments.document)).toContain(b.community_id);
      expect(client.communityListSync.fragments.residue).toBe(false);
      // D-22: the client adopts its own repair, so B is a membership again without an unlock or a restart.
      await until(() => idsOf(client.memberships()).includes(b.community_id));
    } finally {
      for (const release of [...encrypts.splice(0), ...keys.splice(0)]) release();
      await h.teardown();
      store.dispose();
    }
  });

  it("client.communityListSync.write() queued behind a lane step that never settles rejects with ConcordClientNotStartedError as soon as stop() runs (D-30, D-35, 01-REVIEW-GAPS-4 CR-01)", async () => {
    const { signer, pubkey, material, old, storage } = await vault({ relayVault: false });
    const c = await membership(pubkey, "C");
    const e1 = await fragment(signer, 0, { frags: 1, entries: entriesOf([material]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [e1] });
    let park = false; // one-shot: parks exactly the next getPublicKey call once set
    const gate = new Gate<[], string>();
    const gated = gatedSigner(signer, {
      getPublicKey: gate,
      getPublicKeyWhen: () => (park ? (park = false, true) : false),
    });
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(gated, net.pool, storage, { eventStore: store }); // autoUnlock off
      await client.start();
      await settle();
      await client.unlockCommunityListFragments();
      await settle();

      park = true;
      const unlocking = client.unlockCommunityListFragments().catch(() => {}); // a prompt the user never answers
      await gate.next();
      const write = client.communityListSync.write({ entries: entriesOf([material, c]), tombstones: [] }, [
        c.community_id,
      ]).then(() => "ok" as const, (error: unknown) => error);
      await settle();
      client.stop();
      const outcome = await within(write, 1000);
      for (const call of gate.calls) call.release();
      await unlocking;
      await settleFlush();

      expect(outcome).toBeInstanceOf(ConcordClientNotStartedError);
      expect(
        await (async () => {
          let carried = 0;
          for (const event of listPublishes(net.published)) {
            if (idsOf(await fragmentOf(signer, event)).includes(c.community_id)) carried++;
          }
          return carried;
        })(),
      ).toBe(0);
    } finally {
      for (const call of gate.calls) call.release();
      await h.teardown();
      store.dispose();
    }
  });

  /**
   * 01-REVIEW-GAPS-5 CR-01: an app `write()` or `repack()` whose sync task waits on the serial tail behind a retired save
   * S1 is rejected by `stop()`. When S1 is answered after `start()`, the rejected call's task must not prompt the signer:
   * a dismissed prompt would never settle and would hold the serial tail, so lifecycle 2's joins would never save.
   */
  async function expectNoPromptInNextLifecycle(call: "write" | "repack") {
    const { signer: real, pubkey, material: a, old, storage } = await vault({ relayVault: false });
    const c = await membership(pubkey, "C");
    const d = await membership(pubkey, "D");
    const e = await membership(pubkey, "E");
    const f = await membership(pubkey, "F");
    const e1 = await fragment(real, 0, { frags: 1, entries: entriesOf([a]), tombstones: [] }, old);
    const net = fakeRelayPool({ events: [e1] });
    const encrypts: Array<() => void> = [];
    let parkEncrypt = false;
    let lifecycle2 = false;
    let lifecycle2PromptsForC = 0; // only the rejected write carries C: the client's document never holds it
    const dismissed: Array<() => void> = [];
    const signer = Object.assign(Object.create(real), {
      getPublicKey: () => real.getPublicKey(),
      signEvent: (draft: Parameters<PrivateKeySigner["signEvent"]>[0]) => real.signEvent(draft),
      nip44: {
        encrypt: (to: string, text: string) => {
          if (lifecycle2 && carries(text, c.community_id)) {
            lifecycle2PromptsForC++;
            // The user dismisses this unexpected prompt, so it never settles until the test's cleanup.
            return new Promise<string>((resolve, reject) =>
              dismissed.push(() => real.nip44!.encrypt(to, text).then(resolve, reject))
            );
          }
          return parkEncrypt && to === pubkey
            ? (parkEncrypt = false,
              new Promise<string>((resolve, reject) =>
                encrypts.push(() => real.nip44!.encrypt(to, text).then(resolve, reject))
              ))
            : real.nip44!.encrypt(to, text);
        },
        decrypt: (from: string, text: string) => real.nip44!.decrypt(from, text),
      },
    }) as PrivateKeySigner;
    const store = new EventStore();
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { eventStore: store, autoUnlock: false });
      await client.start();
      await settle();
      await client.unlockCommunityListFragments();
      await settle();

      // Lifecycle 1: joining D saves the list, and that save's fragment encrypt waits on the signer (S1).
      parkEncrypt = true;
      const joinD = client.joinByBundle(buildInviteBundle(d, { name: "D" })).then(() => "settled", () => "settled");
      await until(() => encrypts.length === 1);
      const document = { entries: entriesOf([a, c]), tombstones: [] };
      const write = (call === "write"
        ? client.communityListSync.write(document, [c.community_id])
        : client.communityListSync.repack(document)).then(() =>
          "ok" as const, (error: unknown) => error);
      // Joining E retires S1: the call's step starts, and its sync task waits on the serial tail behind S1.
      const joinE = client.joinByBundle(buildInviteBundle(e, { name: "E" })).then(() => "settled", () => "settled");
      await settle();

      client.stop();
      const rejected = await within(write, 500);
      lifecycle2 = true;
      await client.start();
      await settle();
      // S1's encrypt is answered: S1 is refused, then the rejected call's sync task gets its turn in lifecycle 2.
      for (const release of encrypts.splice(0)) release();
      await settle();
      const prompts = lifecycle2PromptsForC;

      const before = listPublishes(net.published).length;
      const joined = await within(
        client.joinByBundle(buildInviteBundle(f, { name: "F" })).then(() => "ok", (error: unknown) => error),
        3000,
      );
      await settleFlush();
      let carryingF = 0;
      for (const event of listPublishes(net.published).slice(before)) {
        if (idsOf(await fragmentOf(real, event)).includes(f.community_id)) carryingF++;
      }

      expect(rejected).toBeInstanceOf(ConcordClientNotStartedError);
      expect(prompts).toBe(0);
      expect(joined).toBe("ok");
      expect(carryingF).toBeGreaterThan(0);
      expect(await within(joinD, 500)).toBe("settled");
      expect(await within(joinE, 500)).toBe("settled");
    } finally {
      for (const release of [...encrypts.splice(0), ...dismissed.splice(0)]) release();
      await settleFlush();
      await h.teardown();
      store.dispose();
    }
  }

  it("client.communityListSync.write() that stop() rejected while it waited on the sync behind a retired save never prompts the signer in the next lifecycle, whose joins still save (D-30, D-35, 01-REVIEW-GAPS-5 CR-01)", () =>
    expectNoPromptInNextLifecycle("write"));

  it("client.communityListSync.repack() that stop() rejected while it waited on the sync behind a retired save never prompts the signer in the next lifecycle, whose joins still save (D-30, D-35, 01-REVIEW-GAPS-5 CR-01)", () =>
    expectNoPromptInNextLifecycle("repack"));
});
