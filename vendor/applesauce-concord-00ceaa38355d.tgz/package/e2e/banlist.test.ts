// CORD-04 §§4, 6 batch bans and the Banlist writer: validation first, one edition per call, a serial queue, a rate
// limit, required acknowledgment and the mixed-rank refusal (D-09..D-12, D-19, D-20).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { stub } from "@std/testing/mock";
import { hexToBytes } from "@noble/hashes/utils.js";
import { getEventHash } from "applesauce-core/helpers/event";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";

import { editionAdditions } from "../src/helpers/edition-lineage.ts";
import { banlistLocator, grantLocator } from "../src/helpers/crypto.ts";
import { computeEditionHash } from "../src/helpers/editions.ts";
import { newestOwnBanlistEdition, parseBanlist } from "../src/helpers/banlist.ts";
import { type CommunityState, type DecodedEvent, PERM, VSK } from "../src/types.ts";
import {
  BanlistHeadChangedError,
  BanlistRateLimitError,
  BanlistWriteBlockedError,
  BanlistWriter,
  BanMembersError,
} from "../src/client/banlist.ts";
import type { ConcordCommunity } from "../src/client/community.ts";
import type { RefoundingResult } from "../src/client/refounding.ts";
import { RequiredPublishError } from "../src/client/revocation.ts";
import {
  banlistEditions,
  banlistHead,
  controlEditionLog,
  disposeAll,
  grantEditions,
  injectBanlist,
  memberEngine,
  ownerEngine,
  randomMember,
  retainedControl,
  settle,
  staffMember,
  useDutyClock,
  writerOf,
} from "../src/client/__tests__/banlist-fixtures.ts";

const BAN_STAFF = PERM.BAN | PERM.MANAGE_ROLES;

/** The Banlist coordinate of a community. */
const banlistEid = (community: ConcordCommunity): string => banlistLocator(hexToBytes(community.communityId));

/** The rejection of a promise, or undefined when it resolved. */
async function rejection(promise: Promise<unknown>): Promise<unknown> {
  return await promise.then(() => undefined, (error) => error);
}

describe("batch bans (BAN-01, D-09)", () => {
  it("banMembers publishes one Banlist edition, strips each role holder and returns the banned members", async () => {
    const owner = await ownerEngine();
    try {
      const holder = await staffMember(owner.community, { position: 4, permissions: PERM.PIN_MESSAGES });
      const roleless = randomMember();
      const stripsBefore = grantEditions(owner.community, owner.net, holder.pubkey).length;

      const result = await owner.community.banMembers([holder.pubkey, roleless.toUpperCase()]);
      await settle();

      expect(result).toEqual({ banned: [holder.pubkey, roleless] });
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(1);
      expect(JSON.parse(editions[0].content)).toEqual([holder.pubkey, roleless]);
      const strips = grantEditions(owner.community, owner.net, holder.pubkey).slice(stripsBefore);
      expect(strips).toHaveLength(1);
      expect(JSON.parse(strips[0].content)).toEqual({ member: holder.pubkey, role_ids: [] });
      expect(grantEditions(owner.community, owner.net, roleless)).toHaveLength(0);
      // CORD-04 §6: the Banlist edition is published first, the Grant strip alongside.
      const log = controlEditionLog(owner.community, owner.net);
      const holderGrant = grantLocator(hexToBytes(owner.community.communityId), holder.pubkey);
      const banAt = log.findIndex((edition) => edition.vsk === VSK.BANLIST);
      const stripAt = log.findIndex((edition) =>
        edition.vsk === VSK.GRANT && edition.eid === holderGrant && edition.content.includes('"role_ids":[]')
      );
      expect(banAt).toBeGreaterThan(-1);
      expect(stripAt).toBeGreaterThan(banAt);
      const state = owner.community.state$.value;
      expect(state.banlist.has(holder.pubkey)).toBe(true);
      expect(state.banlist.has(roleless)).toBe(true);
      expect(state.grants.get(holder.pubkey)).toEqual([]);
    } finally {
      await disposeAll(owner);
    }
  });

  it("banMembers validates every target first and publishes nothing when any fails (D-09)", async () => {
    const owner = await ownerEngine();
    const senior = await staffMember(owner.community, { position: 2, permissions: BAN_STAFF });
    const junior = await staffMember(owner.community, { position: 5, permissions: BAN_STAFF });
    const engine = await memberEngine(owner, junior);
    try {
      const valid = randomMember();
      const error = await rejection(
        engine.community.banMembers([valid, owner.pubkey, "not-a-key", senior.pubkey]),
      );
      expect(error).toBeInstanceOf(BanMembersError);
      const failures = (error as BanMembersError).failures;
      expect(failures).toHaveLength(3);
      expect(failures).toEqual(expect.arrayContaining([
        { member: owner.pubkey, reason: "owner" },
        { member: "not-a-key", reason: "invalid-key" },
        { member: senior.pubkey, reason: "not-outranked" },
      ]));
      // The valid target is not published either: one failure refuses the whole batch.
      expect(engine.net.published).toHaveLength(0);
      expect(engine.community.state$.value.banlist.size).toBe(0);
    } finally {
      await disposeAll(owner, engine);
    }
  });

  it("banMembers with refound runs one shared Refounding that excludes every target", async () => {
    const owner = await ownerEngine();
    const first = randomMember();
    const second = randomMember();
    const fake: RefoundingResult = {
      rotationId: "r".repeat(8),
      epoch: 2,
      warnings: [],
      evidence: [],
      commonRelays: [],
    };
    // The writer reaches the Refounding through the community at call time, so a stub on the instance is honored.
    const refound = stub(owner.community, "refound", () => Promise.resolve(fake));
    try {
      const result = await owner.community.banMembers([first, second], { refound: true });
      expect(refound.calls).toHaveLength(1);
      const options = refound.calls[0].args[0];
      expect(options.exclude).toEqual([first, second]);
      const expectedKeep = [...owner.community.state$.value.members].filter((m) => m !== first && m !== second);
      expect(new Set(options.keep)).toEqual(new Set(expectedKeep));
      expect(options.keep).not.toContain(first);
      expect(result.banned).toEqual([first, second]);
      expect(result.refounding).toBe(fake);
      // One Banlist edition carries both targets; the Refounding is not a second ban.
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(1);
      expect(JSON.parse(editions[0].content)).toEqual([first, second]);
    } finally {
      refound.restore();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a stored, unfinished Refounding resumes its own signed request, so without the check the call would
  // ban the target, then report a Refounding that delivered the new root to the very member it was meant to exclude.
  it("banMembers with refound refuses when a stored Refounding would still deliver the root to a target", async () => {
    const owner = await ownerEngine();
    const exposed = getPublicKey(generateSecretKey()); // a curve point, so the Refounding can wrap the root to it
    const covered = randomMember();
    const store = (owner.community as unknown as { pendingRefounding: { load(): Promise<unknown> } })
      .pendingRefounding;
    // A real record refound() can still finish: every relay refuses its root roll, so it stays stored as "prepared".
    owner.net.setPublishOutcome(() => [{ ok: false, from: "wss://fake", message: "blocked: test" }]);
    await expect(owner.community.refound({ keep: [owner.pubkey, exposed] })).rejects.toThrow(/majority/);
    owner.net.setPublishOutcome(() => undefined);
    const record = await store.load() as Record<string, unknown>;
    const refound = stub(owner.community, "refound", () => Promise.reject(new Error("must not run")));
    try {
      const error = await rejection(owner.community.banMembers([exposed, covered], { refound: true }));
      expect(error).toBeInstanceOf(BanMembersError);
      expect((error as BanMembersError).failures).toEqual([{ member: exposed, reason: "refounding-pending" }]);
      expect((error as Error).message).toContain("finish it with refound()");
      expect(refound.calls).toHaveLength(0);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);

      // A stored record that does not name its recipients refuses every target; no stored record lets the call run.
      const unknown = stub(store, "load", () => Promise.resolve({ ...record, preparation: undefined }));
      const all = await rejection(owner.community.banMembers([covered], { refound: true }));
      expect((all as BanMembersError).failures).toEqual([{ member: covered, reason: "refounding-pending" }]);
      unknown.restore();
      const none = stub(store, "load", () => Promise.resolve(null));
      await expect(owner.community.banMembers([covered], { refound: true })).rejects.toThrow("must not run");
      none.restore();
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);
    } finally {
      refound.restore();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a stored Refounding that refound() refuses (blocked, or from another epoch) was treated as resumable,
  // so the call either told the caller to finish it with refound(), which cannot work, or published the ban and then
  // failed the Refounding every time.
  it("banMembers with refound refuses every target while a stored Refounding cannot be finished", async () => {
    const owner = await ownerEngine();
    const [first, second] = [randomMember(), randomMember()];
    const store = (owner.community as unknown as { pendingRefounding: { load(): Promise<unknown> } })
      .pendingRefounding;
    const epoch = owner.community.material.root_epoch;
    const refound = stub(owner.community, "refound", () => Promise.reject(new Error("must not run")));
    const plan = (next: number) => ({ newEpoch: next, next: { material: { root_epoch: next } } });
    const records = [
      { blocked: "stale-preparation", priorEpoch: epoch, plan: plan(epoch + 1) },
      { priorEpoch: epoch + 5, plan: plan(epoch + 6) },
    ];
    try {
      for (const record of records) {
        const load = stub(store, "load", () => Promise.resolve(record));
        try {
          const error = await rejection(owner.community.banMembers([first, second], { refound: true }));
          expect(error).toBeInstanceOf(BanMembersError);
          expect((error as BanMembersError).failures).toEqual([
            { member: first, reason: "refounding-blocked" },
            { member: second, reason: "refounding-blocked" },
          ]);
          expect((error as Error).message).toContain("discardPendingRefounding()");
          expect((error as Error).message).toContain("refound: false");
        } finally {
          load.restore();
        }
      }
      expect(refound.calls).toHaveLength(0);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);
    } finally {
      refound.restore();
      await disposeAll(owner);
    }
  });

  it("a failed shared Refounding leaves the Banlist edition published", async () => {
    const owner = await ownerEngine();
    const target = randomMember();
    const refound = stub(owner.community, "refound", () => Promise.reject(new Error("refounding failed")));
    try {
      await expect(owner.community.banMembers([target], { refound: true })).rejects.toThrow("refounding failed");
      await settle();
      expect(owner.community.state$.value.banlist.has(target)).toBe(true);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);
    } finally {
      refound.restore();
      await disposeAll(owner);
    }
  });

  it("ban() is banMembers for one member and keeps its outrank error", async () => {
    const owner = await ownerEngine();
    const junior = await staffMember(owner.community, { position: 5, permissions: BAN_STAFF });
    const engine = await memberEngine(owner, junior);
    try {
      const error = await rejection(engine.community.ban(owner.pubkey));
      expect(error).toBeInstanceOf(BanMembersError);
      expect((error as Error).message).toMatch(/outrank|BAN/);
      expect(engine.net.published).toHaveLength(0);
      const target = randomMember();
      await expect(engine.community.ban(target)).resolves.toBeUndefined();
      await settle();
      expect(engine.community.state$.value.banlist.has(target)).toBe(true);
      const editions = banlistEditions(engine.community, engine.net);
      expect(editions).toHaveLength(1);
      expect(JSON.parse(editions[0].content)).toEqual([target]);
    } finally {
      await disposeAll(owner, engine);
    }
  });

  it("a batch too large for one Banlist edition rejects before anything is published", async () => {
    const owner = await ownerEngine();
    try {
      const before = owner.net.published.length;
      // Research assumption A5: one Banlist edition is bounded by the 65,535-byte envelope; a thousand keys exceed it.
      const members = Array.from({ length: 1_000 }, () => randomMember());
      await expect(owner.community.banMembers(members)).rejects.toThrow();
      await settle();
      expect(owner.net.published).toHaveLength(before);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);
      expect(owner.community.state$.value.banlist.size).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });
});

describe("serialized and rate-limited Banlist writes (BAN-02, D-10, D-11, D-12)", () => {
  // Non-vacuity: before the queue both calls read the empty head and published a version 1 edition, so one ban was
  // lost; with the queue the second call builds on the first one's edition.
  it("parallel ban calls chain into consecutive editions and keep every ban (D-10)", async () => {
    const owner = await ownerEngine();
    try {
      const first = randomMember();
      const second = randomMember();
      await Promise.all([owner.community.ban(first), owner.community.ban(second)]);
      await settle();
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions.map((edition) => edition.version)).toEqual([1, 2]);
      expect(editions[1].prevHash).toBe(
        computeEditionHash({
          vsk: VSK.BANLIST,
          eid: banlistEid(owner.community),
          version: 1,
          content: editions[0].content,
        }),
      );
      const state = owner.community.state$.value;
      expect(state.banlist.has(first)).toBe(true);
      expect(state.banlist.has(second)).toBe(true);
    } finally {
      await disposeAll(owner);
    }
  });

  it("a ban and an unban in flight together leave the member unbanned (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const member = randomMember();
      await Promise.all([owner.community.ban(member), owner.community.unban(member)]);
      await settle();
      expect(owner.community.state$.value.banlist.has(member)).toBe(false);
      expect(writerOf(owner.community).intents().get(member)?.action).toBe("unban");
    } finally {
      await disposeAll(owner);
    }
  });

  it("the eleventh Banlist edition within a minute rejects with BanlistRateLimitError and passes after the window (D-11)", async () => {
    const owner = await ownerEngine();
    try {
      const { clock } = useDutyClock(owner.community);
      for (let i = 0; i < 10; i++) await owner.community.ban(randomMember());
      const error = await rejection(owner.community.ban(randomMember()));
      expect(error).toBeInstanceOf(BanlistRateLimitError);
      const limited = error as BanlistRateLimitError;
      expect(limited.limit).toBe(10);
      expect(limited.windowMs).toBe(60_000);
      expect(limited.retryAfterMs).toBeGreaterThan(0);
      expect(limited.retryAfterMs).toBeLessThanOrEqual(60_000);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(10);
      clock.tick(60_000);
      await owner.community.ban(randomMember());
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(11);
    } finally {
      await disposeAll(owner);
    }
  });

  it("queued writes count toward the rate limit when they are enqueued (D-11)", async () => {
    const owner = await ownerEngine();
    try {
      useDutyClock(owner.community);
      const results = await Promise.allSettled(
        Array.from({ length: 11 }, () => owner.community.ban(randomMember())),
      );
      expect(results.slice(0, 10).every((result) => result.status === "fulfilled")).toBe(true);
      expect(results[10].status).toBe("rejected");
      expect((results[10] as PromiseRejectedResult).reason).toBeInstanceOf(BanlistRateLimitError);
      await settle();
      expect(banlistEditions(owner.community, owner.net).map((edition) => edition.version)).toEqual([
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
      ]);
    } finally {
      await disposeAll(owner);
    }
  });

  it("unban of a member absent from the head publishes nothing and records the cancel (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const member = randomMember();
      await owner.community.unban(member);
      await settle();
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);
      const intent = writerOf(owner.community).intents().get(member);
      expect(intent?.action).toBe("unban");
      expect(intent?.edition).toBeUndefined();
    } finally {
      await disposeAll(owner);
    }
  });

  it("unban of a lost own ban republishes the head unchanged so the ban cannot be revived (D-12, D-21)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      // The re-heal must not act on real timers: one firing inside the injection's settle window makes its own edition
      // the head, and the injection then never sees the sibling as the head and keeps grinding nonces.
      useDutyClock(owner.community);
      const lost = randomMember();
      const winner = randomMember();
      await owner.community.ban(lost);
      await settle();
      const own = banlistEditions(owner.community, owner.net)[0];
      // A sibling admin's edition at the same version beats the owner's; its content omits the owner's ban.
      const sibling = await injectBanlist(owner.community, staff, {
        content: JSON.stringify([winner]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      expect(banlistHead(owner.community)?.hash).toBe(sibling.hash);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);

      await owner.community.unban(lost);
      await settle();

      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(2);
      expect(editions[1].version).toBe(2);
      expect(editions[1].prevHash).toBe(sibling.hash);
      expect(editions[1].content).toBe(JSON.stringify([winner]));
      const eid = banlistEid(owner.community);
      const newest = newestOwnBanlistEdition(retainedControl(owner.community), eid, owner.pubkey);
      expect(newest?.rumor.tags.find((tag) => tag[0] === "ev")?.[1]).toBe("2");
      expect(editionAdditions(newest!, retainedControl(owner.community), parseBanlist).added).toEqual([]);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);
    } finally {
      await disposeAll(owner);
    }
  });
});

describe("acknowledged and rank-safe Banlist writes (D-13, D-19, D-20)", () => {
  /** The owner bans a senior (position 3, never stripped) and `extra`; a junior (position 5) engine reads that. */
  async function seniorBanSetup(extra: string[] = []) {
    const owner = await ownerEngine();
    const mid = await staffMember(owner.community, { position: 3, permissions: PERM.PIN_MESSAGES });
    const junior = await staffMember(owner.community, { position: 5, permissions: BAN_STAFF });
    await owner.community.admin.publishEdition(
      VSK.BANLIST,
      banlistEid(owner.community),
      JSON.stringify([mid.pubkey, ...extra]),
    );
    await settle();
    const engine = await memberEngine(owner, junior);
    expect(engine.community.state$.value.banlist.has(mid.pubkey)).toBe(true);
    return { owner, mid, engine };
  }

  it("a rejected acknowledgment rejects with RequiredPublishError and changes no local state (D-20)", async () => {
    const owner = await ownerEngine();
    try {
      useDutyClock(owner.community);
      const target = randomMember();
      owner.net.setPublishOutcome(() => [{ ok: false, from: "wss://fake", message: "blocked" }]);
      const error = await rejection(owner.community.banMembers([target]));
      owner.net.setPublishOutcome();
      expect(error).toBeInstanceOf(RequiredPublishError);
      expect((error as RequiredPublishError).stage).toBe("banlist publication");
      await settle();
      expect(owner.community.state$.value.banlist.has(target)).toBe(false);
      expect(writerOf(owner.community).intents().size).toBe(0);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);
      // The refused attempt used neither a version nor a slot of the rate window: ten bans still pass.
      for (let i = 0; i < 10; i++) await owner.community.ban(randomMember());
      expect(banlistEditions(owner.community, owner.net).map((edition) => edition.version)).toEqual([
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
      ]);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: the second head change used to surface as a plain Error, so callers could only tell "retry" apart from
  // other failures by matching its message.
  it("a head that changes again after one re-plan rejects with BanlistHeadChangedError and publishes nothing", async () => {
    const owner = await ownerEngine();
    const moving = stub(
      owner.community.admin,
      "publishEdition",
      (_vsk, _eid, _content, _required, guard) => Promise.reject(guard?.headChanged?.() ?? new Error("no guard")),
    );
    try {
      const error = await rejection(owner.community.ban(randomMember()));
      expect(error).toBeInstanceOf(BanlistHeadChangedError);
      expect(moving.calls).toHaveLength(2);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);
    } finally {
      moving.restore();
      await disposeAll(owner);
    }
  });

  it("a junior writer refuses to carry a senior's ban it cannot vouch for (D-19)", async () => {
    const { owner, mid, engine } = await seniorBanSetup();
    try {
      const target = randomMember();
      const error = await rejection(engine.community.ban(target));
      expect(error).toBeInstanceOf(BanlistWriteBlockedError);
      expect((error as BanlistWriteBlockedError).reason).toBe("unvouched-entries");
      expect((error as BanlistWriteBlockedError).members).toEqual([mid.pubkey]);
      expect(engine.net.published).toHaveLength(0);
      const state = engine.community.state$.value;
      expect(state.banlist.has(mid.pubkey)).toBe(true);
      expect(state.banlist.has(target)).toBe(false);
    } finally {
      await disposeAll(owner, engine);
    }
  });

  it("unban refuses when the remaining list carries an entry the writer cannot vouch for (D-19)", async () => {
    const lifted = randomMember();
    const { owner, mid, engine } = await seniorBanSetup([lifted]);
    try {
      expect(engine.community.state$.value.banlist.has(lifted)).toBe(true);
      const error = await rejection(engine.community.unban(lifted));
      expect(error).toBeInstanceOf(BanlistWriteBlockedError);
      expect((error as BanlistWriteBlockedError).reason).toBe("unvouched-entries");
      expect((error as BanlistWriteBlockedError).members).toEqual([mid.pubkey]);
      expect(engine.net.published).toHaveLength(0);
      expect(engine.community.state$.value.banlist.has(lifted)).toBe(true);
    } finally {
      await disposeAll(owner, engine);
    }
  });

  // Non-vacuity: the old unban checked only the BAN bit, so a junior with BAN published a list without the senior's
  // target and lifted that ban.
  it("a junior's unban of a ban it cannot vouch for is refused and publishes nothing, while the owner's unban succeeds (D-19)", async () => {
    const { owner, mid, engine } = await seniorBanSetup();
    try {
      const error = await rejection(engine.community.unban(mid.pubkey));
      expect(error).toBeInstanceOf(BanlistWriteBlockedError);
      expect((error as BanlistWriteBlockedError).reason).toBe("not-outranked");
      expect((error as BanlistWriteBlockedError).members).toEqual([mid.pubkey]);
      expect(banlistEditions(engine.community, engine.net)).toHaveLength(0);
      expect(engine.net.published).toHaveLength(0);
      expect(engine.community.state$.value.banlist.has(mid.pubkey)).toBe(true);

      await owner.community.unban(mid.pubkey);
      await settle();
      expect(owner.community.state$.value.banlist.has(mid.pubkey)).toBe(false);
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions.map((edition) => edition.version)).toEqual([1, 2]);
      expect(JSON.parse(editions[1].content)).toEqual([]);
    } finally {
      await disposeAll(owner, engine);
    }
  });

  it("recorded intents name the edition each ban or unban published (D-13)", async () => {
    const owner = await ownerEngine();
    try {
      const member = randomMember();
      const eid = banlistEid(owner.community);
      await owner.community.ban(member);
      await settle();
      const [first] = banlistEditions(owner.community, owner.net);
      const firstHash = computeEditionHash({ vsk: VSK.BANLIST, eid, version: 1, content: first.content });
      const banned = writerOf(owner.community).intents().get(member);
      expect(banned?.action).toBe("ban");
      expect(banned?.edition).toEqual({ eid, version: 1, hash: firstHash, prevHash: undefined });

      await owner.community.unban(member);
      await settle();
      const second = banlistEditions(owner.community, owner.net)[1];
      const secondHash = computeEditionHash({
        vsk: VSK.BANLIST,
        eid,
        version: 2,
        prevHash: firstHash,
        content: second.content,
      });
      const lifted = writerOf(owner.community).intents().get(member);
      expect(lifted?.action).toBe("unban");
      expect(lifted?.edition).toEqual({ eid, version: 2, hash: secondHash, prevHash: firstHash });
      expect(lifted!.seq).toBeGreaterThan(banned!.seq);
    } finally {
      await disposeAll(owner);
    }
  });
});

describe("the session intent ledger bound (D-12)", () => {
  /** A writer over an owner-only state with an empty Banlist head; push records into `retained` as Control history. */
  function ownerWriter() {
    const retained: DecodedEvent[] = [];
    const self = randomMember();
    const communityId = randomMember();
    const state = {
      material: { owner: self, community_id: communityId, root_epoch: 0 },
      grants: new Map(),
      roles: [],
      members: new Set(),
      banlist: new Set(),
      dissolved: false,
    } as unknown as CommunityState;
    const writer = new BanlistWriter({
      self,
      state: () => state,
      epoch: () => 0,
      now: () => 0,
      retained: () => retained,
      current: () => true,
      diagnostics: { report: () => {} },
      latestEdition: () => Promise.resolve(undefined),
      publishEdition: () => Promise.resolve(),
      stripRoles: () => Promise.resolve(),
      assertRefoundReady: () => {},
      pendingRefoundRecipients: () => Promise.resolve(undefined),
      refound: () => Promise.reject(new Error("unused")),
    });
    return { writer, self, retained, eid: banlistLocator(hexToBytes(communityId)) };
  }

  // Non-vacuity: the ledger used to evict strictly by age, so 512 newer intents dropped the oldest unban and the
  // retained-candidate path lost its D-12 cancel; bans are now evicted first.
  it("evicts ban intents before unban intents past 512 members", async () => {
    const { writer } = ownerWriter();
    const unbanned = Array.from({ length: 511 }, () => randomMember());
    for (const member of unbanned) await writer.unban(member);
    const banned = randomMember();
    await writer.ban(banned);
    const last = randomMember();
    await writer.unban(last);

    const intents = writer.intents();
    expect(intents.size).toBe(512);
    expect(intents.has(banned)).toBe(false);
    expect([...unbanned, last].every((member) => intents.get(member)?.action === "unban")).toBe(true);

    // With only unbans left, the oldest one goes first.
    await writer.unban(randomMember());
    expect(writer.intents().size).toBe(512);
    expect(writer.intents().has(unbanned[0])).toBe(false);
  });

  // Non-vacuity: an unban whose member this client's newest own edition still adds is the only thing stopping a restart
  // candidate from being healed in this session, so it must outlive any number of other unbans.
  it("never evicts an unban the newest own Banlist edition still needs", async () => {
    const { writer, self, retained, eid } = ownerWriter();
    const guarded = randomMember();
    retained.push({
      rumor: {
        kind: 3308,
        pubkey: self,
        created_at: 1,
        tags: [["vsk", String(VSK.BANLIST)], ["eid", eid]],
        content: JSON.stringify([guarded]),
        id: "a".repeat(64),
      },
      author: self,
      wrapId: "b".repeat(64),
      sealKind: 20014,
      ms: 1_000,
    });
    await writer.unban(guarded);
    for (let i = 0; i < 600; i++) await writer.unban(randomMember());
    const intents = writer.intents();
    expect(intents.get(guarded)?.action).toBe("unban");
    expect(intents.size).toBe(512);
  });
});
