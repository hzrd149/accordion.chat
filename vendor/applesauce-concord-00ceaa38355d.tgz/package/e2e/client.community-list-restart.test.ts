// Community List restart recovery (LIST-03): the authenticated fragments a client held survive a process restart in the
// ConcordStorage seam, come back verified and locked before any relay read, and never count as read evidence (D-04).
// Two clients on one `memoryStorage()` model the restart.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { throwError } from "rxjs";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { EventStore } from "applesauce-core";
import type { ConcordClient } from "../src/client/client.ts";
import type { ConcordCommunityListSync } from "../src/client/community-list-sync.ts";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import { type ConcordStorage, memoryStorage } from "../src/client/storage.ts";
import { CommunityListFragmentStore } from "../src/client/community-list-store.ts";
import { COMMUNITY_LIST_REPAIR_RETRY } from "../src/client/community-list-read.ts";
import { canonicalJson } from "../src/helpers/community-list.ts";
import { buildInviteBundle } from "../src/helpers/invite-bundle.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  decodeCommunityListFragment,
  encodeCommunityListFragment,
} from "../src/helpers/community-list-wire.ts";
import type { CommunityListCommunity } from "../src/types.ts";
import { fakeRelayPool, Gate, gatedSigner, ManualClock } from "../src/client/__tests__/test-utils.ts";
import {
  advance,
  dTag,
  entriesOf,
  fragmentOf,
  harness,
  injectClock,
  listPublishes,
  membership,
  settle,
  statusOf,
  until,
  vault,
  within,
} from "../src/client/__tests__/community-list-client-fixtures.ts";
import { recordRepack, signFragment, winners } from "../src/client/__tests__/community-list-prefix.ts";

const recordKey = (pubkey: string): string => `concord:list-fragments:${pubkey}`;

/** The stored record of `pubkey`, once it exists (the writer is asynchronous). */
async function storedRecord(storage: ConcordStorage, pubkey: string): Promise<string> {
  let raw: string | null = null;
  await until(() => {
    void storage.getItem(recordKey(pubkey)).then((value) => (raw = value));
    return raw !== null;
  });
  return raw!;
}

/** Wait until the stored record names `count` fragments, then return it. */
async function recordWith(storage: ConcordStorage, pubkey: string, fragments: number) {
  let record: { count?: number; fragments: NostrEvent[] } | undefined;
  await until(() => {
    void storage.getItem(recordKey(pubkey)).then((value) => {
      record = value === null ? undefined : JSON.parse(value);
    });
    return record?.fragments.length === fragments;
  });
  return record!;
}

const lists = (store: EventStore): NostrEvent[] => store.getTimeline([{ kinds: [COMMUNITY_LIST_FRAGMENT_KIND] }]);

/** The client's own sync, whose public view hides `locked`. */
const syncOf = (client: ConcordClient): ConcordCommunityListSync =>
  (client as unknown as { listSync: ConcordCommunityListSync }).listSync;

/** Collect the diagnostics of one stage from a client that has not started yet. */
function collect(client: ConcordClient, stage: ConcordDiagnostic["stage"]): ConcordDiagnostic[] {
  const found: ConcordDiagnostic[] = [];
  client.diagnostics$.subscribe((diagnostic) => {
    if (diagnostic.stage === stage) found.push(diagnostic);
  });
  return found;
}

describe("Community List restart recovery (LIST-03)", () => {
  it("a restarted client restores its stored fragments before any relay answers and unlocks them on request (LIST-03)", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const h = harness();
    try {
      const first = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await first.start();
      await settle();
      expect((await recordWith(storage, pubkey, 2)).count).toBe(2);
      first.dispose();

      // The restart: a new client and event store on the same storage, with the relay failing every read.
      const net = fakeRelayPool({ events: [] });
      let heldAtFirstRead: string[] | undefined;
      net.setRequest((filters) => {
        if (heldAtFirstRead === undefined && filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) {
          heldAtFirstRead = lists(h.stores[1]).map((event) => event.id);
        }
        return throwError(() => new Error("offline"));
      });
      const second = h.client(signer, net.pool, storage, { autoUnlock: false });
      await second.start();
      await settle();
      expect(heldAtFirstRead?.sort()).toEqual(events.map((event) => event.id).sort());
      expect(lists(h.stores[1]).map((event) => event.id).sort()).toEqual(events.map((event) => event.id).sort());
      expect((await statusOf(second)).knowledge).toBe("unknown");
      expect(second.communityListSync.fragments.indexes).toEqual([]);
      expect(syncOf(second).locked).toBe(true);
      await second.unlockCommunityListFragments();
      expect(second.communityListSync.fragments.indexes).toEqual([0, 1]);
      expect(second.communityListSync.fragments.count).toBe(2);
      expect(syncOf(second).locked).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("restored fragments are not read evidence: an offline restart still holds a join (D-04)", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const h = harness();
    try {
      const first = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await first.start();
      await settle();
      await recordWith(storage, pubkey, 2);
      first.dispose();

      const net = fakeRelayPool({ online: false, events: [] });
      const second = h.client(signer, net.pool, storage, { autoUnlock: true });
      await second.start();
      await second.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(await statusOf(second)).toEqual({ knowledge: "unknown", pending: true });
    } finally {
      await h.teardown();
    }
  });

  it("after a restart, an empty completed read never reports confirmed-empty or publishes frags: 1 over the restored vault (T-01-06)", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const h = harness();
    try {
      const first = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await first.start();
      await settle();
      await recordWith(storage, pubkey, 2);
      first.dispose();

      // The relay now completes the read with nothing: on this device the restored vault outranks that emptiness.
      const net = fakeRelayPool({ events: [] });
      const second = h.client(signer, net.pool, storage, { autoUnlock: true });
      await second.start();
      await settle();
      expect((await statusOf(second)).knowledge).not.toBe("confirmed-empty");
      await second.createNewCommunity("B", "joined after the restart", ["wss://fake"]);
      await settle();
      const published = listPublishes(net.published);
      expect(published.length).toBeGreaterThan(0);
      for (const event of published) {
        expect(["0", "1"]).toContain(dTag(event));
        expect((await fragmentOf(signer, event)).frags).toBe(2);
      }
    } finally {
      await h.teardown();
    }
  });

  it("a corrupt or forged stored record is dropped with a fragment-restore diagnostic and start() still resolves (D-03)", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const h = harness();
    try {
      await storage.setItem(recordKey(pubkey), "{not json");
      const broken = h.client(signer, fakeRelayPool({ online: false, events: [] }).pool, storage);
      const brokenDiagnostics = collect(broken, "fragment-restore");
      await broken.start();
      await settle();
      expect(brokenDiagnostics).toHaveLength(1);
      expect(lists(h.stores[0])).toHaveLength(0);
      broken.dispose();

      const [zero, one] = events;
      const forged = { ...one, content: one.content.slice(0, -1) + (one.content.endsWith("A") ? "B" : "A") };
      await storage.setItem(recordKey(pubkey), JSON.stringify({ version: 1, pubkey, fragments: [zero, forged, one] }));
      const mixed = h.client(signer, fakeRelayPool({ online: false, events: [] }).pool, storage);
      const mixedDiagnostics = collect(mixed, "fragment-restore");
      await mixed.start();
      await settle();
      expect(mixedDiagnostics).toHaveLength(1);
      expect(lists(h.stores[1]).map((event) => event.id).sort()).toEqual([zero.id, one.id].sort());
    } finally {
      await h.teardown();
    }
  });

  it("a record that cannot be read at start is kept, never replaced by what the relays served, and restored by the next start (WR-02)", async () => {
    const { signer, pubkey, events, storage: base } = await vault();
    await new CommunityListFragmentStore(base).save(pubkey, { events });
    const original = await base.getItem(recordKey(pubkey));
    let failReads = true;
    const storage: ConcordStorage = {
      getItem: (key) =>
        failReads && key === recordKey(pubkey) ? Promise.reject(new Error("database is locked")) : base.getItem(key),
      setItem: (key, value) => base.setItem(key, value),
      removeItem: (key) => base.removeItem(key),
    };
    const h = harness();
    try {
      // The relays serve only fragment 0: fragment 1 survives only in the stored record.
      const client = h.client(signer, fakeRelayPool({ events: [events[0]] }).pool, storage, { autoUnlock: true });
      const restore = collect(client, "fragment-restore");
      await client.start();
      await settle();
      expect(restore).toHaveLength(1);
      expect(await base.getItem(recordKey(pubkey))).toBe(original);
      client.stop();
      failReads = false;
      await client.start();
      await settle();
      expect(lists(h.stores[0]).map((event) => event.id).sort()).toEqual(events.map((event) => event.id).sort());
      expect(client.communityListSync.fragments.indexes).toEqual([0, 1]);
    } finally {
      await h.teardown();
    }
  });

  it("a leave still reaches the relays while the fragment record cannot be stored, and the failure is reported once (WR-03)", async () => {
    const { signer, pubkey, events, storage: base, material } = await vault();
    const storage: ConcordStorage = {
      getItem: (key) => base.getItem(key),
      setItem: (key, value) =>
        key === recordKey(pubkey) ? Promise.reject(new Error("quota exceeded")) : base.setItem(key, value),
      removeItem: (key) => base.removeItem(key),
    };
    const h = harness();
    try {
      const net = fakeRelayPool({ events });
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const persist = collect(client, "fragment-persist");
      await client.start();
      await settle();
      await client.leave(material.community_id);
      await settle();
      const documents = await Promise.all(listPublishes(net.published).map((event) => fragmentOf(signer, event)));
      expect(documents.some((doc) => doc.tombstones.some((t) => t.community_id === material.community_id))).toBe(true);
      expect(client.memberships().entries).toHaveLength(0);
      expect(persist).toHaveLength(1);
      expect(await base.getItem(recordKey(pubkey))).toBeNull();
    } finally {
      await h.teardown();
    }
  });

  it("a write of the fragment record that never settles holds a leave only for a bounded time, reported once (IN-02)", async () => {
    const { signer, pubkey, events, storage: base, material } = await vault();
    let hang = false;
    const parked: Array<() => void> = [];
    const storage: ConcordStorage = {
      getItem: (key) => base.getItem(key),
      setItem: async (key, value) => {
        if (hang && key === recordKey(pubkey)) await new Promise<void>((resolve) => parked.push(resolve));
        await base.setItem(key, value);
      },
      removeItem: (key) => base.removeItem(key),
    };
    const h = harness();
    try {
      const net = fakeRelayPool({ events });
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      const clock = new ManualClock();
      const internals = injectClock(client, clock);
      const persist = collect(client, "fragment-persist");
      await client.start();
      await settle();
      hang = true;
      let left = false;
      const leaving = client.leave(material.community_id).then(() => (left = true));
      // The tombstone is published, then the save waits for the record of it, which never comes.
      await until(() => listPublishes(net.published).length > 0 && parked.length > 0);
      await settle();
      expect(left).toBe(false);
      expect(persist).toHaveLength(0);
      await advance(internals, clock, 10_000); // the bound runs on the client's duty clock
      await until(() => left);
      await leaving;
      expect(persist).toHaveLength(1);
      const documents = await Promise.all(listPublishes(net.published).map((event) => fragmentOf(signer, event)));
      expect(documents.some((doc) => doc.tombstones.some((t) => t.community_id === material.community_id))).toBe(true);
    } finally {
      hang = false;
      for (const release of parked.splice(0)) release();
      await h.teardown();
    }
  });

  it("the stored record holds only signed ciphertext events, never membership plaintext (LIST-03)", async () => {
    const { signer, pubkey, events, storage, material } = await vault();
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await client.start();
      await settle();
      expect(client.communityListSync.fragments.document.entries).toHaveLength(1); // decrypted in memory
      await recordWith(storage, pubkey, 2);
      const text = await storedRecord(storage, pubkey);
      const record = JSON.parse(text) as { fragments: NostrEvent[] };
      expect(record.fragments.map((event) => event.id).sort()).toEqual(events.map((event) => event.id).sort());
      for (const event of record.fragments) {
        expect(typeof event.sig).toBe("string");
        const relayCopy = events.find((candidate) => candidate.id === event.id)!;
        expect(event.content).toBe(relayCopy.content); // the ciphertext exactly as the relay served it
      }
      for (const plaintext of [material.community_id, material.community_root, "community_id", "community_root"]) {
        expect(text).not.toContain(plaintext);
      }
    } finally {
      await h.teardown();
    }
  });

  it("a stored advisory count never decides the fragment count of a write (D-20)", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const h = harness();
    try {
      // A record whose count claims 1 over events that declare frags 2.
      await storage.setItem(recordKey(pubkey), JSON.stringify({ version: 1, pubkey, count: 1, fragments: events }));
      const net = fakeRelayPool({ events: [] });
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await client.start();
      await client.createNewCommunity("B", "joined after the restart", ["wss://fake"]);
      await settle();
      const published = listPublishes(net.published);
      expect(published.length).toBeGreaterThan(0);
      for (const event of published) expect((await fragmentOf(signer, event)).frags).toBe(2);
      expect(client.communityListSync.fragments.count).toBe(2);
    } finally {
      await h.teardown();
    }
  });
});

/** A membership's key material as the wire canonicalizes it (empty optional fields are dropped), so copies compare equal. */
function material(entry: CommunityListCommunity): string {
  const [decoded] =
    decodeCommunityListFragment(encodeCommunityListFragment({ frags: 1, entries: [entry], tombstones: [] }))
      .entries;
  return canonicalJson(decoded.current);
}

/** The tombstoned community of {@link repairVault}. */
const Z = "ff".repeat(32);

/**
 * Eight real memberships of `signer`'s user, each carrying about 8 KB of unknown data so the vault spans two
 * fragments: `d0` (dated ahead, so a repack must outrank it) holds the even positions, `d1` the odd ones plus a
 * tombstone for {@link Z}.
 */
async function repairVault(signer: PrivateKeySigner, pubkey: string, frags: number = 2) {
  const materials = await Promise.all(Array.from({ length: 8 }, (_, i) => membership(pubkey, `room ${i + 1}`)));
  const all = entriesOf(materials).map((entry) => ({ ...entry, future: "x".repeat(8000) }));
  const now = Math.floor(Date.now() / 1000);
  const old = [
    await signFragment(signer, 0, { frags, entries: all.filter((_, i) => i % 2 === 0), tombstones: [] }, now + 100),
    await signFragment(
      signer,
      1,
      { frags, entries: all.filter((_, i) => i % 2 === 1), tombstones: [{ community_id: Z, removed_at: 5 }] },
      now,
    ),
  ];
  return { all, old, now };
}

/** What a relay holding `events` would give a fresh reader: the governing count, memberships, duplicates and residue. */
async function judge(signer: PrivateKeySigner, events: NostrEvent[]) {
  const held = await Promise.all(
    winners(listPublishes(events)).map(async (event) => ({
      event,
      index: Number(dTag(event)),
      doc: await fragmentOf(signer, event),
    })),
  );
  const newest =
    [...held].sort((a, b) => b.event.created_at - a.event.created_at || (a.event.id < b.event.id ? -1 : 1))[0];
  const count = newest.doc.frags;
  const inRange = held.filter((fragment) => fragment.index < count);
  const ids = inRange.flatMap((f) => [...f.doc.entries, ...f.doc.tombstones].map((item) => item.community_id));
  return {
    count,
    live: new Map(inRange.flatMap((f) => f.doc.entries).map((e) => [e.community_id, material(e)])),
    tombstones: new Set(inRange.flatMap((f) => f.doc.tombstones).map((t) => t.community_id)),
    duplicates: ids.length - new Set(ids).size,
    dormant: held.filter((f) => f.index >= count && (f.doc.entries.length > 0 || f.doc.tombstones.length > 0)).length,
    holes: Array.from({ length: count }, (_, i) => i).filter((i) => !inRange.some((f) => f.index === i)),
  };
}

/** Assert a relay state holds all of `all`, the tombstone and no residue. */
async function expectClean(signer: PrivateKeySigner, events: NostrEvent[], all: CommunityListCommunity[]) {
  const state = await judge(signer, events);
  for (const entry of all) expect(state.live.get(entry.community_id)).toBe(material(entry));
  expect(state.live.size).toBe(all.length);
  expect(state.tombstones.has(Z)).toBe(true);
  expect(state.duplicates).toBe(0);
  expect(state.dormant).toBe(0);
  expect(state.holes).toEqual([]);
}

/** A client over `relay` with the record seeded from `relay`'s winners, a manual clock and auto-save as given. */
async function restarted(
  h: ReturnType<typeof harness>,
  signer: ISigner,
  pubkey: string,
  relay: NostrEvent[],
  options: { autoSave: boolean; autoUnlock?: boolean; storage?: ConcordStorage } = { autoSave: true },
) {
  const storage = options.storage ?? memoryStorage();
  await new CommunityListFragmentStore(storage).save(pubkey, { events: winners(relay) });
  const net = fakeRelayPool({ events: relay });
  const client = h.client(signer, net.pool, storage, {
    autoUnlock: options.autoUnlock ?? true,
    autoSaveCommunityList: options.autoSave,
  });
  const clock = new ManualClock();
  const internals = injectClock(client, clock);
  return { client, net, clock, internals, storage };
}

describe("interrupted repack recovery across restarts (LIST-04, LIST-05, LIST-08)", () => {
  it("a client restarted after every acknowledged repack prefix keeps every membership, key and tombstone and repairs the List once with auto-save on (LIST-04, LIST-08)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { all, old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    expect(published.length).toBeGreaterThan(4);
    for (let k = 0; k <= published.length; k++) {
      const relay = [...old, ...published.slice(0, k)];
      const h = harness();
      try {
        const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay);
        await client.start();
        await settle();
        await advance(internals, clock, 10_000);
        const afterRepair = listPublishes(net.published).length;
        await advance(internals, clock, 60_000); // nothing arms or republishes once the List is clean
        expect(listPublishes(net.published)).toHaveLength(afterRepair);
        const memberships = client.memberships();
        expect(memberships.knowledge).toBe("complete");
        expect(memberships.locked).toBe(false);
        expect(memberships.entries.map((e) => e.community_id).sort()).toEqual(all.map((e) => e.community_id).sort());
        for (const entry of all) {
          const live = memberships.entries.find((e) => e.community_id === entry.community_id);
          expect(live && material(live)).toBe(material(entry)); // no lost key material
        }
        expect(memberships.tombstones.map((t) => t.community_id)).toContain(Z); // no revived tombstone
        const mine = listPublishes(net.published);
        // At most one repair's worth: a repack from a deeper prefix starts at a higher count, so it empties two more.
        expect(mine.length).toBeLessThanOrEqual(published.length + 2);
        if (k === 0 || k === published.length) expect(mine).toHaveLength(0);
        await expectClean(signer, [...relay, ...mine], all);
        expect(client.communityListSync.fragments.residue).toBe(false);
      } finally {
        await h.teardown();
      }
    }
  });

  it("a repack refused by the relay after its first acknowledgment is repaired by the restarted client from its stored record (LIST-04, D-08)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { all, old } = await repairVault(signer, pubkey);
    const h = harness();
    try {
      const storage = memoryStorage();
      const first = await restarted(h, signer, pubkey, old, { autoSave: false, storage });
      let accepted = 0;
      first.net.setPublishOutcome(() => (accepted++ < 1 ? undefined : new Error("relay went away")));
      await first.client.start();
      await settle();
      await expect(first.client.communityListSync.repack({ entries: [], tombstones: [] })).rejects.toThrow();
      const acknowledged = listPublishes(first.net.published);
      expect(acknowledged).toHaveLength(1);
      await recordWith(storage, pubkey, 3);
      first.client.dispose();

      const relay = [...old, ...acknowledged];
      const second = await restarted(h, signer, pubkey, relay, { autoSave: true, storage });
      await second.client.start();
      await settle();
      await advance(second.internals, second.clock, 10_000);
      await advance(second.internals, second.clock, 10_000);
      expect(second.client.memberships().knowledge).toBe("complete");
      await expectClean(signer, [...relay, ...listPublishes(second.net.published)], all);
    } finally {
      await h.teardown();
    }
  });

  it("with auto-save off, a restart reports interrupted-repack residue once and the next saveCommunityList() repairs it (D-19)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { all, old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)]; // one dormant staging copy
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay, { autoSave: false });
      const residue = collect(client, "community-list-residue");
      await client.start();
      await settle();
      await advance(internals, clock, 60_000);
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(residue).toHaveLength(1);

      await client.saveCommunityList();
      await advance(internals, clock, 10_000);
      await advance(internals, clock, 10_000);
      expect(residue).toHaveLength(1);
      expect(listPublishes(net.published).length).toBeGreaterThan(0);
      await expectClean(signer, [...relay, ...listPublishes(net.published)], all);
    } finally {
      await h.teardown();
    }
  });

  it("after its own repair, memberships() and memberships$ hold the membership it brought back into range, with no unlock or restart (D-22)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const [a, b] = entriesOf([await membership(pubkey, "A"), await membership(pubkey, "B")]);
    const now = Math.floor(Date.now() / 1000);
    // A newer declaration of one fragment leaves B, held only at index 1, dormant: residue the repair merges back.
    const relay = [
      await signFragment(signer, 1, { frags: 2, entries: [b], tombstones: [] }, now),
      await signFragment(signer, 0, { frags: 1, entries: [a], tombstones: [] }, now + 100),
    ];
    for (const autoSave of [true, false]) {
      const h = harness();
      try {
        const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay, { autoSave });
        const seen: string[][] = [];
        client.memberships$.subscribe((value) => seen.push(value.entries.map((e) => e.community_id)));
        await client.start();
        await settle();
        if (!autoSave) {
          expect(client.communityListSync.fragments.dormantResidue).toEqual([1]);
          expect(client.memberships().entries.map((e) => e.community_id)).toEqual([a.community_id]);
          await client.saveCommunityList(); // D-19: without auto-save the explicit save asks for the repair
        }
        await advance(internals, clock, 10_000);
        await advance(internals, clock, 10_000);
        const state = await judge(signer, [...relay, ...listPublishes(net.published)]);
        expect(state.live.has(b.community_id)).toBe(true);
        expect(state.dormant).toBe(0);
        expect(client.communityListSync.fragments.residue).toBe(false);
        const live = [a.community_id, b.community_id].sort();
        expect(client.memberships().entries.map((e) => e.community_id).sort()).toEqual(live);
        expect(seen.at(-1)?.sort()).toEqual(live);
        // WR-01: the relays hold exactly what was adopted, so nothing is left unpublished in either auto-save mode.
        expect(client.communityListDirty$.value).toBe(false);
        const repaired = listPublishes(net.published).length;
        await advance(internals, clock, 60_000); // the adoption arms no further save or repair
        expect(listPublishes(net.published)).toHaveLength(repaired);
      } finally {
        await h.teardown();
      }
    }
  });

  it("a repair whose relay acknowledgments keep failing retries within its budget, reports exhaustion once and then stays quiet (LIST-05)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)];
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay);
      const exhausted = collect(client, "duty-exhausted");
      let attempts = 0;
      net.setPublishOutcome(() => (attempts++, new Error("relay down")));
      await client.start();
      await settle();
      for (const ms of [3_500, 7_000, 12_000, 60_000, 60_000]) await advance(internals, clock, ms);
      expect(attempts).toBe(COMMUNITY_LIST_REPAIR_RETRY.maxAttempts);
      expect(exhausted.filter((d) => d.stage === "duty-exhausted" && d.duty === "community-list-repair")).toHaveLength(
        1,
      );
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(internals.listDuties.pending).toBe(0);
    } finally {
      await h.teardown();
    }
  });

  it("a repair waiting on a signer prompt nobody answers publishes nothing after stop(), and the next start() saves a join at once (LIST-05)", async () => {
    const real = new PrivateKeySigner(generateSecretKey());
    const pubkey = await real.getPublicKey();
    const { old } = await repairVault(real, pubkey);
    const published = await recordRepack(real, old);
    const relay = [...old, ...published.slice(0, 1)];
    const gate = new Gate<Parameters<PrivateKeySigner["signEvent"]>, NostrEvent>();
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(
        h,
        gatedSigner(real, { signEvent: gate }),
        pubkey,
        relay,
      );
      await client.start();
      await settle();
      clock.tick(3_500); // the repair's first signEvent waits on a prompt nobody answers
      const parked = await gate.next();
      client.stop();
      await settle();
      expect(internals.listDuties.pending).toBe(0);

      void (async () => { // every later prompt is answered
        for (;;) (await gate.next()).release();
      })();
      await client.start();
      await settle();
      const before = listPublishes(net.published).length;
      const x = await membership(pubkey, "X");
      const joined = client.joinByBundle(buildInviteBundle(x, { name: "X" })).catch(() => {});
      for (let i = 0; i < 150 && listPublishes(net.published).length === before; i++) {
        await new Promise((r) => setTimeout(r, 20));
      }
      const after = listPublishes(net.published).length;
      expect(after).toBeGreaterThan(before); // published within the 3 s polling bound
      parked.release(); // the old lifecycle's prompt is answered late
      await settle();
      await within(joined, 3_000);
      expect(listPublishes(net.published)).toHaveLength(after);
    } finally {
      await h.teardown();
    }
  });

  it("a repair interrupted by another device's fragment restarts from a fresh merge and keeps that device's membership (D-06)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { all, old, now } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)];
    const f = (await entriesOf([await membership(pubkey, "F")]))[0];
    const other = await signFragment(
      signer,
      0,
      { frags: 2, entries: [...all.filter((_, i) => i % 2 === 0), f], tombstones: [] },
      now + 200,
    );
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay);
      let arrived = false;
      net.setPublishOutcome(() => {
        if (!arrived) { // between the repair's first and second publication
          arrived = true;
          h.stores[0].add(other);
        }
        return undefined;
      });
      await client.start();
      await settle();
      for (const ms of [3_500, 7_000, 7_000, 7_000]) await advance(internals, clock, ms);
      expect(arrived).toBe(true);
      expect(client.memberships().entries.map((e) => e.community_id)).toContain(f.community_id);
      await expectClean(signer, [...relay, other, ...listPublishes(net.published)], [...all, f]);
    } finally {
      await h.teardown();
    }
  });

  it("a repair whose fragment record cannot be stored halts before its next publication and succeeds on a later attempt (D-08)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { all, old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)];
    const inner = memoryStorage();
    let failing = false;
    const storage: ConcordStorage = {
      getItem: (key) => inner.getItem(key),
      removeItem: (key) => inner.removeItem(key),
      setItem: (key, value) =>
        failing && key.startsWith("concord:list-fragments:")
          ? Promise.reject(new Error("quota exceeded"))
          : inner.setItem(key, value),
    };
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay, { autoSave: true, storage });
      const persist = collect(client, "fragment-persist");
      await client.start();
      await settle();
      failing = true;
      await advance(internals, clock, 3_500); // the first attempt publishes one fragment, then halts
      expect(listPublishes(net.published)).toHaveLength(1);
      expect(persist).toHaveLength(1);
      failing = false;
      await advance(internals, clock, 7_000);
      await advance(internals, clock, 12_000);
      expect(persist).toHaveLength(1);
      await expectClean(signer, [...relay, ...listPublishes(net.published)], all);
    } finally {
      await h.teardown();
    }
  });

  it("a repair over a fragment record that could not be read is reported once and not retried in that lifecycle (IN-01)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)];
    const inner = memoryStorage();
    const storage: ConcordStorage = {
      getItem: (key) =>
        key === recordKey(pubkey) ? Promise.reject(new Error("database is locked")) : inner.getItem(key),
      setItem: (key, value) => inner.setItem(key, value),
      removeItem: (key) => inner.removeItem(key),
    };
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay, { autoSave: true, storage });
      const repair = collect(client, "community-list-repair");
      const exhausted = collect(client, "duty-exhausted");
      const persist = collect(client, "fragment-persist");
      await client.start();
      await settle();
      for (const ms of [3_500, 7_000, 12_000, 60_000, 60_000]) await advance(internals, clock, ms);
      expect(repair).toHaveLength(1);
      expect((repair[0].error as Error).name).toBe("FragmentRecordUnreadableError");
      expect(exhausted).toHaveLength(0);
      expect(persist).toHaveLength(1);
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(internals.listDuties.pending).toBe(0);
    } finally {
      await h.teardown();
    }
  });

  it("a repair waiting on a slow fragment record publishes nothing after stop() (CR-01, D-30)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)];
    const inner = memoryStorage();
    let gating = false;
    const parked: Array<() => void> = [];
    const storage: ConcordStorage = {
      getItem: (key) => inner.getItem(key),
      removeItem: (key) => inner.removeItem(key),
      setItem: async (key, value) => {
        if (gating && key.startsWith("concord:list-fragments:")) await new Promise<void>((r) => parked.push(r));
        await inner.setItem(key, value);
      },
    };
    const h = harness();
    try {
      const { client, net, clock } = await restarted(h, signer, pubkey, relay, { autoSave: true, storage });
      await client.start();
      await settle();
      gating = true;
      clock.tick(3_500); // the repair publishes its first staging copy, then waits on the record of it
      await until(() => listPublishes(net.published).length === 1 && parked.length > 0);
      client.stop();
      gating = false;
      for (const release of parked.splice(0)) release();
      await settle();
      expect(listPublishes(net.published)).toHaveLength(1);
    } finally {
      for (const release of parked.splice(0)) release();
      await h.teardown();
    }
  });

  it("a locked dormant fragment blocks the repair until it is unlocked, so an unread copy is never overwritten (D-05, LIST-08)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { all, old } = await repairVault(signer, pubkey);
    const published = await recordRepack(signer, old);
    const relay = [...old, ...published.slice(0, 1)];
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, relay, {
        autoSave: true,
        autoUnlock: false,
      });
      await client.start();
      await settle();
      await advance(internals, clock, 60_000);
      expect(listPublishes(net.published)).toHaveLength(0);
      expect(client.memberships().locked).toBe(true);

      await client.unlockCommunityListFragments();
      expect(client.memberships().locked).toBe(false);
      await advance(internals, clock, 10_000);
      await advance(internals, clock, 10_000);
      await expectClean(signer, [...relay, ...listPublishes(net.published)], all);
    } finally {
      await h.teardown();
    }
  });

  it("a restart from a partial read with missing declared fragments never writes the missing indexes (D-05)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const { old } = await repairVault(signer, pubkey, 3); // declares frags 3, index 2 is missing
    const h = harness();
    try {
      const { client, net, clock, internals } = await restarted(h, signer, pubkey, old);
      await client.start();
      await settle();
      await advance(internals, clock, 60_000);
      expect(client.memberships().knowledge).toBe("partial");
      const x = await membership(pubkey, "X");
      await client.joinByBundle(buildInviteBundle(x, { name: "X" })).catch(() => {});
      await settle();
      await advance(internals, clock, 60_000);
      const mine = listPublishes(net.published);
      expect(mine.length).toBeGreaterThan(0);
      for (const event of mine) expect(["0", "1"]).toContain(dTag(event));
      expect(client.memberships().knowledge).toBe("partial");
    } finally {
      await h.teardown();
    }
  });
});
