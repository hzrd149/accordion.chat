// Stage-labelled required publication (FND-04, D-09). A publication that needs a relay
// acknowledgment must name the step that failed, not masquerade as an invite revocation.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { assertSpyCalls, spy } from "@std/testing/mock";
import { EventStore, RumorStore } from "applesauce-core";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import "applesauce-common/casts";
import { hexToBytes } from "@noble/hashes/utils.js";

import { ConcordClient } from "../src/client/client.ts";
import { ConcordCommunityAdmin } from "../src/client/admin.ts";
import { memoryStorage } from "../src/client/storage.ts";
import { InviteRevocationPublishError, RequiredPublishError } from "../src/client/revocation.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import { banlistLocator } from "../src/helpers/crypto.ts";
import { deriveConcordKeys, wrapForTarget } from "../src/helpers/keys.ts";
import { decodeWrap } from "../src/helpers/gift-wrap.ts";
import { foldControl } from "../src/helpers/control.ts";
import { VSK } from "../src/types.ts";
import type { CommunityState, DecodedEvent, RumorTemplate } from "../src/types.ts";
import { fakeRelayPool } from "../src/client/__tests__/test-utils.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));

/** A started client with one created community; the fake pool accepts everything until told otherwise. */
async function running() {
  const signer = new PrivateKeySigner(generateSecretKey());
  const fake = fakeRelayPool();
  const store = new EventStore();
  const client = new ConcordClient({
    signer,
    pool: fake.pool,
    eventStore: store,
    storage: memoryStorage(),
    relays: ["wss://fake"],
    watchDirectInvites: false,
  });
  await client.start();
  const community = await client.createNewCommunity("Stages", "", ["wss://fake"]);
  return {
    fake,
    community,
    async teardown() {
      await settle();
      client.stop();
      client.dispose();
      store.dispose();
      await settle();
    },
  };
}

const controlRumor = { kind: 3308, content: "{}", tags: [] as string[][] };

describe("stage-labelled required publication (FND-04, D-09)", () => {
  it("a pin-stage required publish failure is labelled with its own stage", async () => {
    const { fake, community, teardown } = await running();
    try {
      fake.setPublishOutcome((event) =>
        event.kind === 1059 ? [{ ok: false, from: "wss://fake", message: "blocked" }] : undefined
      );
      const error = await community.publishToPlane({ plane: "control" }, controlRumor, {
        plaintext: true,
        requiredAckStage: "pin list publication",
      }).then(() => undefined, (e) => e);
      expect(error).toBeInstanceOf(RequiredPublishError);
      expect(error).not.toBeInstanceOf(InviteRevocationPublishError);
      expect(error.stage).toBe("pin list publication");
      expect(error.message).toBe("pin list publication failed: no relay accepted the publication");
      expect(error.message).not.toMatch(/invite/i);
      expect(error.responses).toEqual([{ ok: false, from: "wss://fake", message: "blocked" }]);
    } finally {
      await teardown();
    }
  });

  it("a thrown required publish keeps its stage and cause", async () => {
    const { fake, community, teardown } = await running();
    try {
      const cause = new Error("socket closed");
      fake.setPublishOutcome((event) => event.kind === 1059 ? cause : undefined);
      const error = await community.publishToPlane({ plane: "control" }, controlRumor, {
        plaintext: true,
        requiredAckStage: "banlist publication",
      }).then(() => undefined, (e) => e);
      expect(error).toBeInstanceOf(RequiredPublishError);
      expect(error).not.toBeInstanceOf(InviteRevocationPublishError);
      expect(error.stage).toBe("banlist publication");
      expect(error.cause).toBe(cause);
      expect(error.responses).toEqual([]);
    } finally {
      await teardown();
    }
  });

  it("admin required editions pass their stage to publishRequired", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const owner = await signer.getPublicKey();
    const link = "22".repeat(32);
    const genesis = await createLegacyCommunity({ ownerPubkey: owner, name: "Test", relays: ["wss://fake"] });
    const store = new RumorStore();
    let state: CommunityState = foldControl([], genesis.material);
    const keys = deriveConcordKeys(state.material, []);
    const history: DecodedEvent[] = [];
    const record = async (rumor: RumorTemplate): Promise<string> => {
      const { wrap } = await wrapForTarget(keys, { plane: "control" }, signer, rumor, { plaintext: true });
      const decoded = decodeWrap(wrap, keys.control.convKey)!;
      history.push(decoded);
      store.add(decoded.rumor);
      state = foldControl(history, state.material, state.controlVerification);
      return decoded.rumor.id;
    };
    const publishRequired = spy((rumor: RumorTemplate, _check?: () => void, _stage?: string) => record(rumor));
    const admin = new ConcordCommunityAdmin({
      community: {} as ConstructorParameters<typeof ConcordCommunityAdmin>[0]["community"],
      store,
      state: () => state,
      pubkey: owner,
      publish: record,
      publishRequired,
      mintChannelKey: () => {},
    });
    try {
      await admin.registerInviteLink(link);
      await admin.publishEdition(
        VSK.BANLIST,
        banlistLocator(hexToBytes(genesis.material.community_id)),
        "[]",
        "banlist publication",
      );
      assertSpyCalls(publishRequired, 1);
      expect(publishRequired.calls[0].args[2]).toBe("banlist publication");

      await admin.unregisterInviteLink(link);
      assertSpyCalls(publishRequired, 2);
      expect(publishRequired.calls[1].args[2]).toBe("invite registry unregister");
    } finally {
      store.dispose();
    }
  });

  it("invite revocation failures keep their legacy error class and message", async () => {
    const error = new InviteRevocationPublishError("member bundle publication", [], { cause: new Error("x") });
    expect(error).toBeInstanceOf(RequiredPublishError);
    expect(error).toBeInstanceOf(AggregateError);
    expect(error.name).toBe("InviteRevocationPublishError");
    expect(error.stage).toBe("member bundle publication");
    expect(error.message).toBe("member bundle publication failed: no relay accepted the revocation");

    const { fake, community, teardown } = await running();
    try {
      fake.setPublishOutcome((event) =>
        event.kind === 1059 ? [{ ok: false, from: "wss://fake", message: "blocked" }] : undefined
      );
      const failure = await community.publishToPlane({ plane: "control" }, controlRumor, {
        plaintext: true,
        requiredAckStage: "invite registry unregister",
      }).then(() => undefined, (e) => e);
      expect(failure).toBeInstanceOf(InviteRevocationPublishError);
      expect(failure.name).toBe("InviteRevocationPublishError");
      expect(failure.message).toBe("invite registry unregister failed: no relay accepted the revocation");
    } finally {
      await teardown();
    }
  });
});
