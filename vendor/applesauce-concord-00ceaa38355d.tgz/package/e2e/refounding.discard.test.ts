// CORD-06 §3 stored Refoundings that refound() refuses: discardPendingRefounding() removes only a record refound() would
// refuse (blocked, from another epoch, or prepared against a since-changed state) and keeps one it can still finish;
// banMembers({ refound: true }) refuses with refounding-blocked in every such case (D-24). A stored Refounding whose
// other recipients were not given in sorted order still resumes.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";

import { JoinLeaveFactory } from "../src/factories/guestbook.ts";
import { PERM } from "../src/types.ts";
import { BanMembersError } from "../src/client/banlist.ts";
import type { ConcordCommunity } from "../src/client/community.ts";
import { memoryStorage, type PendingRefoundingStore } from "../src/client/storage.ts";
import {
  banlistEditions,
  diagnosticsOf,
  disposeAll,
  type OwnerEngine,
  ownerEngine,
  randomMember,
  settle,
} from "../src/client/__tests__/banlist-fixtures.ts";

/** The engine's stored-Refounding slot, through the private `pendingRefounding` field. */
const pendingOf = (community: ConcordCommunity): PendingRefoundingStore =>
  (community as unknown as { pendingRefounding: PendingRefoundingStore }).pendingRefounding;

/** Leave a real "prepared" record behind: every relay refuses the root roll, so refound() aborts after saving it. */
async function strandRefounding(owner: OwnerEngine, keep: string[] = [owner.pubkey]): Promise<void> {
  owner.net.setPublishOutcome(() => [{ ok: false, from: "wss://fake", message: "blocked: test" }]);
  try {
    await expect(owner.community.refound({ keep })).rejects.toThrow(/majority/);
  } finally {
    owner.net.setPublishOutcome(() => undefined);
  }
  expect((await pendingOf(owner.community).load())?.stage).toBe("prepared");
}

/** Change the folded Control state the stored preparation was bound to. */
async function changeControlState(owner: OwnerEngine): Promise<void> {
  await owner.community.admin.createRole("moved-on", 5, PERM.PIN_MESSAGES);
  await settle();
}

describe("discardPendingRefounding (D-24, CORD-06 §3)", () => {
  it("removes a record prepared against a since-changed state, reports it, and refound() works again", async () => {
    const owner = await ownerEngine();
    const diagnostics = diagnosticsOf(owner.community);
    try {
      await strandRefounding(owner);
      const stored = await pendingOf(owner.community).load();
      await changeControlState(owner);
      await expect(owner.community.refound({ keep: [owner.pubkey] })).rejects.toThrow(/pending operation blocked/);

      expect(await owner.community.discardPendingRefounding()).toBe(true);
      expect(await pendingOf(owner.community).load()).toBeNull();
      const discarded = diagnostics.seen.filter((d) => d.stage === "refounding-discarded");
      expect(discarded).toHaveLength(1);
      expect(discarded[0]).toMatchObject({ reason: "preparation-changed", key: stored!.rotationId });

      const epoch = owner.community.material.root_epoch;
      await owner.community.refound({ keep: [owner.pubkey] });
      expect(owner.community.material.root_epoch).toBe(epoch + 1);
    } finally {
      diagnostics.stop();
      await disposeAll(owner);
    }
  });

  it("removes a record marked blocked, and refound() works again", async () => {
    const owner = await ownerEngine();
    const diagnostics = diagnosticsOf(owner.community);
    try {
      await strandRefounding(owner);
      const store = pendingOf(owner.community);
      await store.save({ ...(await store.load())!, blocked: "stale-preparation" });
      await expect(owner.community.refound({ keep: [owner.pubkey] })).rejects.toThrow(/pending operation blocked/);

      expect(await owner.community.discardPendingRefounding()).toBe(true);
      expect(await store.load()).toBeNull();
      expect(diagnostics.seen.filter((d) => d.stage === "refounding-discarded")).toMatchObject([{ reason: "blocked" }]);

      const epoch = owner.community.material.root_epoch;
      await owner.community.refound({ keep: [owner.pubkey] });
      expect(owner.community.material.root_epoch).toBe(epoch + 1);
    } finally {
      diagnostics.stop();
      await disposeAll(owner);
    }
  });

  it("removes a record left from another epoch, and refound() works again", async () => {
    const storage = memoryStorage();
    const owner = await ownerEngine({ storage });
    const diagnostics = diagnosticsOf(owner.community);
    try {
      await strandRefounding(owner);
      // Set the stranded record aside while two other Refoundings move the community two epochs on, then restore it.
      const key = pendingOf(owner.community).key;
      const ciphertext = await storage.getItem(key);
      await storage.removeItem(key);
      await owner.community.refound({ keep: [owner.pubkey] });
      await owner.community.refound({ keep: [owner.pubkey] });
      await storage.setItem(key, ciphertext!);
      await expect(owner.community.refound({ keep: [owner.pubkey] })).rejects.toThrow(/epoch does not match/);

      expect(await owner.community.discardPendingRefounding()).toBe(true);
      expect(await storage.getItem(key)).toBeNull();
      expect(diagnostics.seen.filter((d) => d.stage === "refounding-discarded")).toMatchObject([
        { reason: "other-epoch" },
      ]);

      const epoch = owner.community.material.root_epoch;
      await owner.community.refound({ keep: [owner.pubkey] });
      expect(owner.community.material.root_epoch).toBe(epoch + 1);
    } finally {
      diagnostics.stop();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a discard that removed every stored record would drop signed work refound() could still finish.
  it("keeps a record refound() can still finish and returns false; refound() then resumes it", async () => {
    const owner = await ownerEngine();
    const diagnostics = diagnosticsOf(owner.community);
    try {
      expect(await owner.community.discardPendingRefounding()).toBe(false);
      await strandRefounding(owner);
      const stored = await pendingOf(owner.community).load();

      expect(await owner.community.discardPendingRefounding()).toBe(false);
      expect((await pendingOf(owner.community).load())?.rotationId).toBe(stored!.rotationId);
      expect(diagnostics.seen.filter((d) => d.stage === "refounding-discarded")).toHaveLength(0);

      const result = await owner.community.refound({ keep: [owner.pubkey] });
      expect(result.rotationId).toBe(stored!.rotationId);
      expect(await pendingOf(owner.community).load()).toBeNull();
    } finally {
      diagnostics.stop();
      await disposeAll(owner);
    }
  });
});

describe("banMembers with refound and a stored Refounding refound() refuses (D-24)", () => {
  // Non-vacuity: before D-24 a record whose preparation no longer matched was reported as refounding-pending, whose
  // advice (finish it with refound()) cannot work because refound() refuses the record.
  it("refuses with refounding-blocked when the stored preparation no longer matches, and publishes nothing", async () => {
    const owner = await ownerEngine();
    const target = randomMember();
    try {
      await strandRefounding(owner);
      await changeControlState(owner);
      const published = owner.net.published.length;

      const error = await owner.community.banMembers([target], { refound: true }).then(() => undefined, (e) => e);
      expect(error).toBeInstanceOf(BanMembersError);
      expect((error as BanMembersError).failures).toEqual([{ member: target, reason: "refounding-blocked" }]);
      expect((error as Error).message).toContain("discardPendingRefounding()");
      expect(owner.net.published.length).toBe(published);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);

      // Following the advice clears the way: the ban and its shared Refounding then go through.
      expect(await owner.community.discardPendingRefounding()).toBe(true);
      const result = await owner.community.banMembers([target], { refound: true });
      expect(result.banned).toEqual([target]);
      expect(result.refounding).toBeDefined();
    } finally {
      await disposeAll(owner);
    }
  });
});

/** Two fresh curve-point members, larger key first, so a keep list in this order is not sorted. */
function unsortedPair(): [string, string] {
  const [a, b] = [getPublicKey(generateSecretKey()), getPublicKey(generateSecretKey())].sort();
  return [b, a];
}

/** Admit `members` to the guestbook with self-signed Joins, in the given order. */
async function join(community: ConcordCommunity, members: string[]): Promise<void> {
  const template = await JoinLeaveFactory.create("join");
  members.forEach((pubkey, i) => {
    const tags = [...template.tags.filter((t) => t[0] !== "ms"), ["ms", String(i)]];
    const rumor: Rumor = { kind: template.kind, pubkey, content: template.content, tags, created_at: 1 + i, id: "" };
    rumor.id = getEventHash(rumor);
    community.guestbookStore.add(rumor);
  });
  await settle();
}

describe("resuming a stored Refounding whose other recipients were not sorted (CORD-06 §3)", () => {
  // Non-vacuity: the resume rebuilt its recipients from the sorted request, so the preparation fingerprint never matched
  // and every retry was refused as "pending operation blocked".
  it("refound({ keep: [b, a] }) with b > a resumes and completes after an interruption", async () => {
    const owner = await ownerEngine();
    try {
      const keep = unsortedPair();
      await strandRefounding(owner, keep);
      const stored = await pendingOf(owner.community).load();
      const others = stored!.preparation!.recipients.map((r) => r.pubkey).filter((pk) => pk !== owner.pubkey);
      expect(others).toEqual(keep);

      const epoch = owner.community.material.root_epoch;
      const result = await owner.community.refound({ keep });
      expect(result.rotationId).toBe(stored!.rotationId);
      expect(owner.community.material.root_epoch).toBe(epoch + 1);
      expect(await pendingOf(owner.community).load()).toBeNull();
    } finally {
      await disposeAll(owner);
    }
  });

  it("an interrupted banMembers({ refound: true }) keeping two or more members resumes with refound()", async () => {
    const owner = await ownerEngine();
    try {
      const kept = unsortedPair();
      const target = getPublicKey(generateSecretKey());
      // The guestbook fold lists the newest Join first, so joining the smaller key first leaves the keep list unsorted.
      await join(owner.community, [target, ...[...kept].reverse()]);
      // Refuse only the root roll, so the ban publishes and the shared Refounding stops after saving its record.
      const rekey = (owner.community as unknown as { keys: { nextBaseRekey: { key: { pk: string } } } }).keys
        .nextBaseRekey.key.pk;
      owner.net.setPublishOutcome((event) =>
        event.pubkey === rekey ? [{ ok: false, from: "wss://fake", message: "blocked: test" }] : undefined
      );
      await expect(owner.community.banMembers([target], { refound: true })).rejects.toThrow(/majority/);
      owner.net.setPublishOutcome(() => undefined);
      expect(owner.community.state$.value.banlist.has(target)).toBe(true);
      const stored = await pendingOf(owner.community).load();
      const others = stored!.preparation!.recipients.map((r) => r.pubkey).filter((pk) => pk !== owner.pubkey);
      expect(new Set(others)).toEqual(new Set(kept));
      expect(others).not.toEqual([...others].sort());

      const epoch = owner.community.material.root_epoch;
      const result = await owner.community.refound({ keep: [] });
      expect(result.rotationId).toBe(stored!.rotationId);
      expect(owner.community.material.root_epoch).toBe(epoch + 1);
      expect(await pendingOf(owner.community).load()).toBeNull();
    } finally {
      await disposeAll(owner);
    }
  });
});
