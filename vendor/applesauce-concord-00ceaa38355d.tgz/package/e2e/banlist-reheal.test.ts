// CORD-04 §4 Banlist re-heal end to end: a ban this client published that a concurrent sibling edition displaced is
// re-applied on top of the winning verified head, on bounded, cancellable duties owned by the community DutyScope
// (D-11..D-15, D-19). Every delay is driven by a ManualClock; nothing waits on real duty timers.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { stub } from "@std/testing/mock";
import { getEventHash, type NostrEvent } from "applesauce-core/helpers/event";
import type { ISigner, PrivateKeySigner } from "applesauce-signers";

import { PERM } from "../src/types.ts";
import { BanlistRateLimitError } from "../src/client/banlist.ts";
import { BanlistReHealError } from "../src/client/banlist-reheal.ts";
import type { ConcordCommunity } from "../src/client/community.ts";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import { RequiredPublishError } from "../src/client/revocation.ts";
import {
  banlistEditions,
  banlistHead,
  diagnosticsOf,
  disposeAll,
  dutiesSettled,
  injectBanlist,
  lostBan,
  memberEngine,
  ownerEngine,
  randomMember,
  relayInto,
  restartEngine,
  settle as settleNet,
  staffMember,
  useDutyClock,
  writerOf,
} from "../src/client/__tests__/banlist-fixtures.ts";
import { Gate, gatedSigner, type ManualClock } from "../src/client/__tests__/test-utils.ts";

const BAN_STAFF = PERM.BAN | PERM.MANAGE_ROLES;
const SLOT = "banlist-reheal";

/** A session-sourced heal waits the middle of the 0-2_000 ms window on the ManualClock (random 0.5). */
const SESSION_DELAY_MS = 1_000;

/** Advance the duty clock and let the duties it fires finish. */
async function advance(community: ConcordCommunity, clock: ManualClock, ms: number): Promise<void> {
  clock.tick(ms);
  await dutiesSettled(community);
}

/** The rejection of a promise, or undefined when it resolved. */
async function rejection(promise: Promise<unknown>): Promise<unknown> {
  return await promise.then(() => undefined, (error) => error);
}

/** The diagnostics of one stage. */
function ofStage(seen: ConcordDiagnostic[], stage: ConcordDiagnostic["stage"]): ConcordDiagnostic[] {
  return seen.filter((diagnostic) => diagnostic.stage === stage);
}

type SignArgs = Parameters<ISigner["signEvent"]>;
type SignResult = Awaited<ReturnType<ISigner["signEvent"]>>;

/** A signer around `inner` that parks `signEvent` and `nip44.encrypt` on gates only while the test switches them on. */
function parkable(inner: PrivateKeySigner) {
  const sign = new Gate<SignArgs, SignResult>();
  const encrypt = new Gate<[pubkey: string, text: string], string>();
  const parking = { sign: false, encrypt: false };
  const gated = gatedSigner(inner, { signEvent: sign, encrypt });
  const signer = {
    getPublicKey: () => Promise.resolve(inner.getPublicKey()),
    signEvent: (
      draft: SignArgs[0],
    ) => (parking.sign ? gated.signEvent(draft) : Promise.resolve(inner.signEvent(draft))),
    nip44: {
      encrypt: (pubkey: string, text: string) =>
        parking.encrypt ? gated.nip44!.encrypt(pubkey, text) : Promise.resolve(inner.nip44!.encrypt(pubkey, text)),
      decrypt: (pubkey: string, text: string) => Promise.resolve(inner.nip44!.decrypt(pubkey, text)),
    },
  } as ISigner;
  return { signer, sign, encrypt, parking };
}

describe("ban re-heal (BAN-03, BAN-04, D-11..D-15)", () => {
  // Non-vacuity: without the re-healer the owner's lost ban stays lost, so the second edition never appears and the
  // folded Banlist keeps only the sibling's member.
  it("a ban lost to a concurrent sibling is re-applied once on the winning head (BAN-03)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost, winner, sibling } = await lostBan(owner, staff);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);
      expect(duties.slotPending(SLOT)).toBe(true);

      await advance(owner.community, clock, SESSION_DELAY_MS - 1);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);
      await advance(owner.community, clock, 1);

      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(2);
      expect(editions[1].version).toBe(2);
      expect(editions[1].prevHash).toBe(sibling.hash);
      expect(editions[1].content).toBe(JSON.stringify([winner, lost]));
      const state = owner.community.state$.value;
      expect(state.banlist.has(lost)).toBe(true);
      expect(state.banlist.has(winner)).toBe(true);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: without the intent ledger as a re-heal input, the sibling folded while the ban awaited its
  // acknowledgment plans `none` (no intent yet) and nothing re-plans once the intent is recorded, so the ban stays lost.
  it("a ban lost to a sibling that arrives while its acknowledgment is pending is re-applied (BAN-03)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock } = useDutyClock(owner.community);
      const pool = owner.net.pool as unknown as { publish(relays: string[], event: NostrEvent): Promise<unknown> };
      const original = pool.publish.bind(pool);
      let release!: () => void;
      const gate = new Promise<void>((resolve) => release = resolve);
      let parked = false;
      pool.publish = async (relays, event) => {
        const result = await original(relays, event);
        if (!parked) {
          parked = true;
          await gate;
        }
        return result;
      };
      const member = randomMember();
      const banning = owner.community.ban(member);
      await settle(owner.community);
      expect(parked).toBe(true);
      const own = banlistEditions(owner.community, owner.net)[0];
      const winner = randomMember();
      const sibling = await injectBanlist(owner.community, staff, {
        content: JSON.stringify([winner]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      release();
      await banning;
      await settle(owner.community);
      expect(owner.community.state$.value.banlist.has(member)).toBe(false);

      await advance(owner.community, clock, 120_000);
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(2);
      expect(editions[1].prevHash).toBe(sibling.hash);
      expect(editions[1].content).toBe(JSON.stringify([winner, member]));
      expect(owner.community.state$.value.banlist.has(member)).toBe(true);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a healer that re-requested on every fold, or one keyed by anything but the head hash, would publish
  // a third edition when the settled head is folded again.
  it("a replayed head publishes no second heal", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock } = useDutyClock(owner.community);
      await lostBan(owner, staff);
      await advance(owner.community, clock, SESSION_DELAY_MS);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(2);

      await relayInto(owner.net, owner.community, 0);
      await advance(owner.community, clock, 120_000);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(2);
      expect(owner.community.state$.value.banlist.size).toBe(2);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a heal that trusted the plan made when it was armed would publish the unbanned member again; the
  // fire-time re-plan sees the unban intent and drops it.
  it("a later unban is never revived by a waiting heal (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost, winner } = await lostBan(owner, staff);
      expect(duties.slotPending(SLOT)).toBe(true);

      await owner.community.unban(lost);
      await settle(owner.community);
      await advance(owner.community, clock, 120_000);

      const healing = banlistEditions(owner.community, owner.net).slice(1);
      // The unban republishes the head unchanged (05-03); no edition after the first may list the lost member.
      expect(healing.length).toBeGreaterThan(0);
      expect(healing.every((edition) => !(JSON.parse(edition.content) as string[]).includes(lost))).toBe(true);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);
      expect(duties.slotPending(SLOT)).toBe(false);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: an unban that recorded its intent only after a successful publish would leave the earlier ban intent
  // in place when the relay refuses it, and the waiting heal would then re-ban the member the admin tried to unban.
  it("a refused unban never lets a waiting heal revive the ban (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost } = await lostBan(owner, staff);
      owner.net.setPublishOutcome(() => [{ ok: false, from: "wss://fake", message: "blocked" }]);
      expect(await rejection(owner.community.unban(lost))).toBeInstanceOf(RequiredPublishError);
      owner.net.setPublishOutcome();
      expect(writerOf(owner.community).intents().get(lost)?.action).toBe("unban");

      await advance(owner.community, clock, 120_000);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: the same gap through the rate window: an unban rejected with BanlistRateLimitError kept the ban
  // intent, so the deferred heal re-banned the member once the window freed.
  it("a rate-limited unban never lets a deferred heal revive the ban (D-11, D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost } = await lostBan(owner, staff);
      for (let i = 0; i < 9; i++) await owner.community.ban(randomMember());
      expect(await rejection(owner.community.unban(lost))).toBeInstanceOf(BanlistRateLimitError);
      expect(writerOf(owner.community).intents().get(lost)?.action).toBe("unban");

      await advance(owner.community, clock, 120_000);
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(10);
      expect(editions.slice(1).some((edition) => (JSON.parse(edition.content) as string[]).includes(lost))).toBe(false);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: the heal checked the intent ledger only when it was planned, so a heal already queued behind another
  // write re-banned the member after the unban was called, and the unban then had to lift the ban again.
  it("an unban called while a heal waits in the write queue cancels that heal (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost, winner } = await lostBan(owner, staff);
      const parked = parkNextPublishThenRefuse(owner.net);
      const banning = rejection(owner.community.ban(randomMember()));
      await settleNet();
      expect(parked.parked()).toBe(true);
      clock.tick(3_000);
      await settleNet();

      const unbanning = rejection(owner.community.unban(lost));
      expect(writerOf(owner.community).intents().get(lost)?.action).toBe("unban");
      parked.release();
      expect(await banning).toBeInstanceOf(RequiredPublishError);
      expect(await unbanning).toBeUndefined();
      await advance(owner.community, clock, 120_000);

      const editions = banlistEditions(owner.community, owner.net);
      expect(editions.slice(1).some((edition) => (JSON.parse(edition.content) as string[]).includes(lost))).toBe(false);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: the same queued heal with the window full: the unban is rate-limited, so before the fix the queued heal
  // published the ban and nothing lifted it again; the member stayed banned for good.
  it("a rate-limited unban cancels a heal already waiting in the write queue (D-11, D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost } = await lostBan(owner, staff);
      for (let i = 0; i < 7; i++) await owner.community.ban(randomMember());
      await settleNet();
      const before = banlistEditions(owner.community, owner.net).length;
      const parked = parkNextPublishThenRefuse(owner.net);
      const banning = rejection(owner.community.ban(randomMember()));
      await settleNet();
      expect(parked.parked()).toBe(true);
      clock.tick(3_000);
      await settleNet();

      expect(await rejection(owner.community.unban(lost))).toBeInstanceOf(BanlistRateLimitError);
      expect(writerOf(owner.community).intents().get(lost)?.action).toBe("unban");
      parked.release();
      expect(await banning).toBeInstanceOf(RequiredPublishError);
      await advance(owner.community, clock, 120_000);

      const editions = banlistEditions(owner.community, owner.net);
      expect(editions.slice(before).some((edition) => (JSON.parse(edition.content) as string[]).includes(lost)))
        .toBe(false);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: the unban's re-plan coalesces into the running heal it cancels, and a rate-limited unban changes no
  // state, so without the fresh re-plan the other member of the cancelled heal would wait for an unrelated change.
  it("a heal cancelled by an unban of one member still re-applies the other lost members (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const [unbanned, kept] = [randomMember(), randomMember()];
      await owner.community.banMembers([unbanned, kept]);
      await settleNet();
      const own = banlistEditions(owner.community, owner.net)[0];
      await injectBanlist(owner.community, staff, {
        content: JSON.stringify([randomMember()]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      for (let i = 0; i < 7; i++) await owner.community.ban(randomMember());
      await settleNet();
      const before = banlistEditions(owner.community, owner.net).length;
      const parked = parkNextPublishThenRefuse(owner.net);
      const banning = rejection(owner.community.ban(randomMember()));
      await settleNet();
      clock.tick(3_000);
      await settleNet();

      expect(await rejection(owner.community.unban(unbanned))).toBeInstanceOf(BanlistRateLimitError);
      parked.release();
      expect(await banning).toBeInstanceOf(RequiredPublishError);
      await dutiesSettled(owner.community);
      await advance(owner.community, clock, 120_000);

      const heals = banlistEditions(owner.community, owner.net).slice(before);
      expect(heals).toHaveLength(1);
      expect(JSON.parse(heals[0].content)).toContain(kept);
      expect(JSON.parse(heals[0].content)).not.toContain(unbanned);
      expect(owner.community.state$.value.banlist.has(kept)).toBe(true);
      expect(owner.community.state$.value.banlist.has(unbanned)).toBe(false);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a heal whose signer answers after the unban was called used to send the ban, because only the duty's
  // head and authority were re-checked after signing.
  it("an unban called while a heal waits on the signer cancels that heal (D-12)", async () => {
    const parkedSigner = { current: undefined as ReturnType<typeof parkable> | undefined };
    const owner = await ownerEngine({}, (inner) => (parkedSigner.current = parkable(inner)).signer);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const gates = parkedSigner.current!;
      const { lost, winner } = await lostBan(owner, staff);

      gates.parking.sign = true;
      clock.tick(SESSION_DELAY_MS);
      const call = await gates.sign.next();
      const unbanning = rejection(owner.community.unban(lost));
      expect(writerOf(owner.community).intents().get(lost)?.action).toBe("unban");
      gates.parking.sign = false;
      call.release();
      expect(await unbanning).toBeUndefined();
      await advance(owner.community, clock, 120_000);

      const editions = banlistEditions(owner.community, owner.net);
      expect(editions.slice(1).some((edition) => (JSON.parse(edition.content) as string[]).includes(lost))).toBe(false);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: without the per-member call-order guard, a ban queued before the unban would record its intent after
  // the unban's and win, so the member would be healed back after the unban lifted it.
  it("a ban that completes after a later unban was called never overrides it (D-12)", async () => {
    const owner = await ownerEngine();
    try {
      const member = randomMember();
      // Every intent the ledger shows for the member, in order: the ban's late acknowledgment must never show up as one.
      const shown: Array<string | undefined> = [];
      const watching = writerOf(owner.community).intents$.subscribe(() => {
        shown.push(writerOf(owner.community).intents().get(member)?.action);
      });
      const banning = owner.community.ban(member);
      const unbanning = owner.community.unban(member);
      expect(writerOf(owner.community).intents().get(member)?.action).toBe("unban");
      await Promise.all([banning, unbanning]);
      watching.unsubscribe();
      expect(shown).not.toContain("ban");
      expect(shown).toContain("unban");
      await settle(owner.community);
      const intent = writerOf(owner.community).intents().get(member);
      expect(intent?.action).toBe("unban");
      expect(intent?.edition?.version).toBe(2);
      expect(owner.community.state$.value.banlist.has(member)).toBe(false);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: without the duty's attempt bound a refusing relay would be retried forever; without the report the
  // app would never learn the heal gave up.
  it("a rejected heal acknowledgment retries with backoff, then reports duty-exhausted", async () => {
    const owner = await ownerEngine();
    const reports = diagnosticsOf(owner.community);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock } = useDutyClock(owner.community);
      const { sibling } = await lostBan(owner, staff);
      let attempts = 0;
      owner.net.setPublishOutcome(() => {
        attempts++;
        return [{ ok: false, from: "wss://fake", message: "blocked" }];
      });

      await advance(owner.community, clock, SESSION_DELAY_MS);
      expect(attempts).toBe(1);
      await advance(owner.community, clock, 999);
      expect(attempts).toBe(1);
      await advance(owner.community, clock, 1);
      expect(attempts).toBe(2);
      await advance(owner.community, clock, 1_999);
      expect(attempts).toBe(2);
      await advance(owner.community, clock, 1);
      expect(attempts).toBe(3);

      const exhausted = ofStage(reports.seen, "duty-exhausted");
      expect(exhausted).toHaveLength(1);
      expect(exhausted[0]).toMatchObject({
        stage: "duty-exhausted",
        duty: SLOT,
        key: `banlist-reheal:${sibling.hash}`,
      });
      owner.net.setPublishOutcome();
      await advance(owner.community, clock, 120_000);
      expect(attempts).toBe(3);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);
      expect(ofStage(reports.seen, "duty-exhausted")).toHaveLength(1);
    } finally {
      reports.stop();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: with no per-ban publication cap a staff member who beats every heal would keep the owner healing
  // forever; the cap stops it at three and the typed report says why.
  it("three heal publications without convergence report BanlistReHealError non-convergence once (D-15)", async () => {
    const owner = await ownerEngine();
    const reports = diagnosticsOf(owner.community);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock } = useDutyClock(owner.community);
      const { lost, winner } = await lostBan(owner, staff);

      for (let round = 1; round <= 3; round++) {
        await advance(owner.community, clock, SESSION_DELAY_MS);
        const editions = banlistEditions(owner.community, owner.net);
        expect(editions).toHaveLength(round + 1);
        const heal = editions[round];
        expect(JSON.parse(heal.content)).toContain(lost);
        // The staff member's edition at the same version wins the tiebreak against this heal.
        await injectBanlist(owner.community, staff, {
          content: JSON.stringify([winner, randomMember()]),
          version: heal.version,
          prevHash: heal.prevHash,
          beat: getEventHash(heal.rumor),
        });
        expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
      }
      await advance(owner.community, clock, SESSION_DELAY_MS);
      await advance(owner.community, clock, 120_000);

      expect(banlistEditions(owner.community, owner.net)).toHaveLength(4);
      const given = ofStage(reports.seen, "banlist-reheal");
      expect(given).toHaveLength(1);
      expect(given[0].error).toBeInstanceOf(BanlistReHealError);
      const error = given[0].error as BanlistReHealError;
      expect(error.reason).toBe("non-convergence");
      expect(error.members).toEqual([lost]);
    } finally {
      reports.stop();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a heal armed for a healer that lost BAN would publish with authority it no longer has; the duty
  // stops at the demotion and nothing is published after ticking.
  it("demotion while a heal waits cancels it (D-15)", async () => {
    const owner = await ownerEngine();
    const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
    const healer = await memberEngine(owner, staff);
    try {
      const { clock, duties } = useDutyClock(healer.community);
      const lost = randomMember();
      await healer.community.ban(lost);
      await dutiesSettled(healer.community);
      const own = banlistEditions(healer.community, healer.net)[0];
      await injectBanlist(healer.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([randomMember()]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      expect(healer.community.state$.value.banlist.has(lost)).toBe(false);
      expect(duties.slotPending(SLOT)).toBe(true);

      const from = owner.net.published.length;
      await owner.community.admin.grantRoles(staff.pubkey, []);
      await relayInto(owner.net, healer.community, from);
      await dutiesSettled(healer.community);
      expect(healer.community.canDo(PERM.BAN)).toBe(false);
      expect(duties.slotPending(SLOT)).toBe(false);
      expect(duties.pending).toBe(0);

      await advance(healer.community, clock, 120_000);
      expect(banlistEditions(healer.community, healer.net)).toHaveLength(1);
    } finally {
      await disposeAll(owner, healer);
    }
  });

  // Non-vacuity: a heal checked only for the BAN bit would ban a member who now outranks the healer; the strict-rank
  // check stops it when the target is promoted above the healer.
  it("losing rank over the target stops the heal (D-15)", async () => {
    const owner = await ownerEngine();
    const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
    const healer = await memberEngine(owner, staff);
    try {
      const { clock, duties } = useDutyClock(healer.community);
      const target = randomMember();
      await healer.community.ban(target);
      await dutiesSettled(healer.community);
      const own = banlistEditions(healer.community, healer.net)[0];
      await injectBanlist(healer.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([randomMember()]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      expect(duties.slotPending(SLOT)).toBe(true);

      const from = owner.net.published.length;
      const senior = await owner.community.admin.createRole("senior", 2, PERM.PIN_MESSAGES);
      await owner.community.admin.grantRoles(target, [senior]);
      await relayInto(owner.net, healer.community, from);
      await dutiesSettled(healer.community);
      expect(duties.slotPending(SLOT)).toBe(false);

      await advance(healer.community, clock, 120_000);
      expect(banlistEditions(healer.community, healer.net)).toHaveLength(1);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner, healer);
    }
  });

  // Non-vacuity: a heal left armed after dissolution or disposal would publish into a dead community; both leave the
  // slot empty and nothing is published after ticking.
  it("dissolution and dispose cancel a waiting heal (D-15)", async () => {
    for (const ending of ["dissolve", "dispose"] as const) {
      const owner = await ownerEngine();
      try {
        const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
        const { clock, duties } = useDutyClock(owner.community);
        await lostBan(owner, staff);
        expect(duties.slotPending(SLOT)).toBe(true);

        if (ending === "dissolve") await owner.community.dissolve();
        else owner.community.dispose();
        await settle(owner.community);
        expect(duties.slotPending(SLOT)).toBe(false);
        const published = owner.net.published.length;
        await advance(owner.community, clock, 120_000);
        expect(owner.net.published).toHaveLength(published);
        expect(duties.pending).toBe(0);
      } finally {
        await disposeAll(owner);
      }
    }
  });

  // Non-vacuity: a heal that survived the adoption would re-apply a ban against the old epoch's Banlist; adoption
  // empties the slot and forgets this session's intents.
  it("a Refounding adoption cancels the heal and clears this session's intents (D-15)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      await lostBan(owner, staff);
      expect(duties.slotPending(SLOT)).toBe(true);
      expect(writerOf(owner.community).intents().size).toBe(1);
      const epoch = owner.community.material.root_epoch;

      await owner.community.refound({ keep: [owner.pubkey] });
      await dutiesSettled(owner.community);

      expect(owner.community.material.root_epoch).toBeGreaterThan(epoch);
      expect(duties.slotPending(SLOT)).toBe(false);
      expect(writerOf(owner.community).intents().size).toBe(0);
      const published = owner.net.published.length;
      await advance(owner.community, clock, 120_000);
      expect(owner.net.published).toHaveLength(published);
      expect(duties.pending).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a ban whose acknowledgment lands after a Refounding was adopted recorded its old-epoch edition into the
  // cleared ledger, so a session heal could later cross the Refounding; the writer now drops intents across an epoch.
  it("a ban acknowledged after a Refounding adoption records no intent in the new epoch (D-15)", async () => {
    const owner = await ownerEngine();
    try {
      useDutyClock(owner.community);
      const pool = owner.net.pool as unknown as { publish(relays: string[], event: NostrEvent): Promise<unknown> };
      const original = pool.publish.bind(pool);
      let release!: () => void;
      const gate = new Promise<void>((resolve) => release = resolve);
      let parked = false;
      pool.publish = async (relays, event) => {
        const result = await original(relays, event);
        if (!parked) {
          parked = true;
          await gate;
        }
        return result;
      };
      const member = randomMember();
      const banning = rejection(owner.community.ban(member));
      await settle(owner.community);
      expect(parked).toBe(true);
      const epoch = owner.community.material.root_epoch;
      await owner.community.refound({ keep: [owner.pubkey] });
      await settle(owner.community);
      expect(owner.community.material.root_epoch).toBeGreaterThan(epoch);

      release();
      expect(await banning).toBeUndefined();
      await settle(owner.community);
      expect(writerOf(owner.community).intents().size).toBe(0);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: the re-healer cleared the whole ledger when it first noticed the new epoch, which is only after this
  // client's own Refounding settles, so a ban or unban made at the new epoch between adoption and completion was wiped.
  it("intents recorded at the new epoch while this client's Refounding completes survive it (D-12, D-15)", async () => {
    const owner = await ownerEngine();
    try {
      useDutyClock(owner.community);
      const [banned, unbanned] = [randomMember(), randomMember()];
      await owner.community.ban(unbanned);
      await settle(owner.community);
      const epoch = owner.community.material.root_epoch;
      const pool = owner.net.pool as unknown as { publish(relays: string[], event: NostrEvent): Promise<unknown> };
      const original = pool.publish.bind(pool);
      let release!: () => void;
      const gate = new Promise<void>((resolve) => release = resolve);
      let parked = false;
      pool.publish = async (relays, event) => {
        if (!parked && owner.community.material.root_epoch > epoch) {
          parked = true;
          await gate;
        }
        return await original(relays, event);
      };
      const refounding = rejection(owner.community.refound({ keep: [owner.pubkey] }));
      for (let i = 0; i < 50 && !parked; i++) await settleNet();
      expect(parked).toBe(true);
      expect(owner.community.material.root_epoch).toBeGreaterThan(epoch);

      await owner.community.ban(banned);
      await owner.community.unban(unbanned);
      expect(writerOf(owner.community).intents().get(banned)?.action).toBe("ban");
      release();
      expect(await refounding).toBeUndefined();
      await settle(owner.community);

      const intents = writerOf(owner.community).intents();
      expect(intents.get(banned)?.action).toBe("ban");
      expect(intents.get(unbanned)?.action).toBe("unban");
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: without the in-flight counter the heal would publish a Banlist edition while a Refounding is being
  // prepared; with it no duty is armed until the Refounding fails and the heal then resumes.
  it("no heal runs while a Refounding is in flight, and a failed Refounding lets it resume", async () => {
    const parked = { current: undefined as ReturnType<typeof parkable> | undefined };
    const owner = await ownerEngine({}, (inner) => (parked.current = parkable(inner)).signer);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const gates = parked.current!;
      const member = randomMember();
      await owner.community.ban(member);
      await settle(owner.community);
      const own = banlistEditions(owner.community, owner.net)[0];

      gates.parking.encrypt = true;
      const refounding = rejection(owner.community.refound({ keep: [owner.pubkey, staff.pubkey] }));
      const call = await gates.encrypt.next();
      const sibling = await injectBanlist(owner.community, staff, {
        content: JSON.stringify([randomMember()]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      expect(owner.community.state$.value.banlist.has(member)).toBe(false);
      expect(duties.slotPending(SLOT)).toBe(false);

      const published = owner.net.published.length;
      await advance(owner.community, clock, 120_000);
      expect(owner.net.published).toHaveLength(published);
      expect(duties.slotPending(SLOT)).toBe(false);

      gates.parking.encrypt = false;
      call.fail(new Error("signer refused"));
      expect(await refounding).toBeInstanceOf(Error);
      await dutiesSettled(owner.community);
      expect(duties.slotPending(SLOT)).toBe(true);

      await advance(owner.community, clock, SESSION_DELAY_MS);
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(2);
      expect(editions[1].prevHash).toBe(sibling.hash);
      expect(JSON.parse(editions[1].content)).toContain(member);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: a heal that rejected on a full window would surface BanlistRateLimitError or drop the ban; it is
  // deferred to the first free slot instead and nothing is published before that.
  it("a heal waits for the Banlist rate-limit window instead of rejecting (D-11)", async () => {
    const owner = await ownerEngine();
    const reports = diagnosticsOf(owner.community);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const members = Array.from({ length: 10 }, () => randomMember());
      for (const member of members.slice(0, 9)) await owner.community.ban(member);
      const head = banlistHead(owner.community)!;
      await owner.community.ban(members[9]);
      await settle(owner.community);
      const own = banlistEditions(owner.community, owner.net)[9];
      const winner = randomMember();
      await injectBanlist(owner.community, staff, {
        content: JSON.stringify([...members.slice(0, 9), winner]),
        version: 10,
        prevHash: head.hash,
        beat: getEventHash(own.rumor),
      });
      expect(owner.community.state$.value.banlist.has(members[9])).toBe(false);
      expect(duties.slotPending(SLOT)).toBe(true);

      await advance(owner.community, clock, 59_999);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(10);
      await advance(owner.community, clock, 1);

      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(11);
      expect(editions[10].version).toBe(11);
      expect(JSON.parse(editions[10].content)).toEqual([...members.slice(0, 9), winner, members[9]]);
      expect(reports.seen.some((diagnostic) => diagnostic.error instanceof BanlistRateLimitError)).toBe(false);
      expect(ofStage(reports.seen, "duty-exhausted")).toHaveLength(0);
    } finally {
      reports.stop();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: each deferral used to request a fresh duty key with a fresh budget, so a window that never frees kept
  // the heal re-arming forever with no report; the per-ban deferral bound gives up and reports rate-limited once.
  it("a heal the rate window keeps deferring gives up after a bound and reports rate-limited once (D-11)", async () => {
    const owner = await ownerEngine();
    const reports = diagnosticsOf(owner.community);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost } = await lostBan(owner, staff);
      const full = stub(
        writerOf(owner.community) as unknown as { rateLimitDelay(): number },
        "rateLimitDelay",
        () => 60_000,
      );
      try {
        for (let minute = 0; minute < 10; minute++) await advance(owner.community, clock, 60_000);
      } finally {
        full.restore();
      }
      expect(duties.pending).toBe(0);
      const limited = ofStage(reports.seen, "banlist-reheal");
      expect(limited).toHaveLength(1);
      expect((limited[0].error as BanlistReHealError).reason).toBe("rate-limited");
      expect((limited[0].error as BanlistReHealError).members).toEqual([lost]);

      await advance(owner.community, clock, 120_000);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);
      expect(ofStage(reports.seen, "banlist-reheal")).toHaveLength(1);
    } finally {
      reports.stop();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: deferrals used to add up over the whole life of a ban intent, so two short full-window spells around a
  // successful heal gave the ban up as rate-limited although neither spell lasted five waits.
  it("the deferral bound restarts after a successful heal (D-11)", async () => {
    const owner = await ownerEngine();
    const reports = diagnosticsOf(owner.community);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock, duties } = useDutyClock(owner.community);
      const { lost, winner } = await lostBan(owner, staff);
      const writer = writerOf(owner.community) as unknown as { rateLimitDelay(): number };
      const deferThrice = async () => {
        const full = stub(writer, "rateLimitDelay", () => 60_000);
        try {
          await advance(owner.community, clock, SESSION_DELAY_MS);
          await advance(owner.community, clock, 60_000);
          await advance(owner.community, clock, 60_000);
        } finally {
          full.restore();
        }
        await advance(owner.community, clock, 60_000);
      };

      await deferThrice();
      const heal = banlistEditions(owner.community, owner.net)[1];
      expect(JSON.parse(heal.content)).toContain(lost);
      await injectBanlist(owner.community, staff, {
        content: JSON.stringify([winner, randomMember()]),
        version: heal.version,
        prevHash: heal.prevHash,
        beat: getEventHash(heal.rumor),
      });
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);

      await deferThrice();
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(3);
      expect(JSON.parse(editions[2].content)).toContain(lost);
      expect(ofStage(reports.seen, "banlist-reheal")).toHaveLength(0);
      expect(duties.pending).toBe(0);
    } finally {
      reports.stop();
      await disposeAll(owner);
    }
  });

  // Non-vacuity: without the expected-head guard a signer that answers after a newer sibling took over would publish
  // content planned for the old head, lifting the sibling's newer entries.
  it("a stale signer completion after supersession never publishes a heal", async () => {
    const parked = { current: undefined as ReturnType<typeof parkable> | undefined };
    const owner = await ownerEngine({}, (inner) => (parked.current = parkable(inner)).signer);
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { clock } = useDutyClock(owner.community);
      const gates = parked.current!;
      const { lost, winner, sibling } = await lostBan(owner, staff);

      gates.parking.sign = true;
      clock.tick(SESSION_DELAY_MS);
      const call = await gates.sign.next();
      const newer = await injectBanlist(owner.community, staff, {
        content: JSON.stringify([winner, randomMember()]),
        version: 2,
        prevHash: sibling.hash,
      });
      expect(banlistHead(owner.community)?.hash).toBe(newer.hash);

      gates.parking.sign = false;
      call.release();
      await dutiesSettled(owner.community);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(1);

      await advance(owner.community, clock, SESSION_DELAY_MS);
      const editions = banlistEditions(owner.community, owner.net);
      expect(editions).toHaveLength(2);
      expect(editions[1].version).toBe(3);
      expect(editions[1].prevHash).toBe(newer.hash);
      expect(JSON.parse(editions[1].content)).toContain(lost);
    } finally {
      await disposeAll(owner);
    }
  });
});

/** The heal editions (version 2 and later) an engine published through `net`. */
function healsOf(community: ConcordCommunity, net: Parameters<typeof banlistEditions>[1]) {
  return banlistEditions(community, net).filter((edition) => edition.version > 1);
}

describe("ban re-heal across restarts, devices and ranks (BAN-05, D-14, D-15, D-19, D-21)", () => {
  // Non-vacuity: without the retained-history seed (newest own edition, D-21) a restarted engine has no session
  // intent, so the lost ban would never come back; with it exactly one heal appears after the retained window.
  it("a restarted engine heals a lost newest own ban once (D-21)", async () => {
    const owner = await ownerEngine();
    let restarted: Awaited<ReturnType<typeof restartEngine>> | undefined;
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      useDutyClock(owner.community);
      const { lost, winner, sibling } = await lostBan(owner, staff);
      owner.community.dispose();

      restarted = await restartEngine(owner, owner.community.material, [sibling.wrap]);
      expect(restarted.engine.state$.value.banlist.has(lost)).toBe(false);
      expect(restarted.duties.slotPending(SLOT)).toBe(true);
      expect(writerOf(restarted.engine).intents().size).toBe(0);

      // A heal sourced only from retained history waits out its window (at least 5 s): another device usually heals first.
      await advance(restarted.engine, restarted.clock, 4_999);
      expect(banlistEditions(restarted.engine, restarted.net)).toHaveLength(0);
      await advance(restarted.engine, restarted.clock, 30_000);
      const heals = banlistEditions(restarted.engine, restarted.net);
      expect(heals).toHaveLength(1);
      expect(heals[0].version).toBe(2);
      expect(heals[0].prevHash).toBe(sibling.hash);
      expect(heals[0].content).toBe(JSON.stringify([winner, lost]));
      expect(restarted.engine.state$.value.banlist.has(lost)).toBe(true);

      await advance(restarted.engine, restarted.clock, 60_000);
      expect(banlistEditions(restarted.engine, restarted.net)).toHaveLength(1);
    } finally {
      await disposeAll(owner, ...(restarted ? [{ community: restarted.engine, store: restarted.store }] : []));
    }
  });

  // Non-vacuity: if the unban did not republish the head unchanged, the owner's newest own edition would still add the
  // member and the restarted engine would revive the ban the user cancelled.
  it("a restarted engine never revives a ban its later own unban cancelled (D-21)", async () => {
    const owner = await ownerEngine();
    let restarted: Awaited<ReturnType<typeof restartEngine>> | undefined;
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      useDutyClock(owner.community);
      const { lost, winner, sibling } = await lostBan(owner, staff);
      await owner.community.unban(lost);
      await dutiesSettled(owner.community);
      expect(banlistEditions(owner.community, owner.net).length).toBeGreaterThan(1);
      owner.community.dispose();

      restarted = await restartEngine(owner, owner.community.material, [sibling.wrap]);
      expect(restarted.engine.state$.value.banlist.has(lost)).toBe(false);
      expect(restarted.engine.state$.value.banlist.has(winner)).toBe(true);
      await advance(restarted.engine, restarted.clock, 60_000);
      expect(banlistEditions(restarted.engine, restarted.net)).toHaveLength(0);
      expect(restarted.engine.state$.value.banlist.has(lost)).toBe(false);
      expect(restarted.duties.pending).toBe(0);
    } finally {
      await disposeAll(owner, ...(restarted ? [{ community: restarted.engine, store: restarted.store }] : []));
    }
  });

  // Non-vacuity: without the head-keyed eligibility and the fire-time re-plan the second device would also publish its
  // retained-sourced heal after the first device's heal arrived, giving two heal editions.
  it("two engines with one signer publish at most one heal between them", async () => {
    const owner = await ownerEngine();
    let second: Awaited<ReturnType<typeof restartEngine>> | undefined;
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const first = useDutyClock(owner.community);
      const { lost, sibling } = await lostBan(owner, staff);
      second = await restartEngine(owner, owner.community.material, [sibling.wrap]);
      expect(second.duties.slotPending(SLOT)).toBe(true);

      const from = owner.net.published.length;
      await advance(owner.community, first.clock, SESSION_DELAY_MS);
      expect(healsOf(owner.community, owner.net)).toHaveLength(1);
      await relayInto(owner.net, second.engine, from);
      await dutiesSettled(second.engine);
      expect(second.engine.state$.value.banlist.has(lost)).toBe(true);

      await advance(second.engine, second.clock, 30_000);
      await advance(owner.community, first.clock, 60_000);
      await advance(second.engine, second.clock, 60_000);
      expect(healsOf(owner.community, owner.net).length + healsOf(second.engine, second.net).length).toBe(1);
      expect(second.duties.pending).toBe(0);
    } finally {
      await disposeAll(owner, ...(second ? [{ community: second.engine, store: second.store }] : []));
    }
  });

  // Non-vacuity: if retained candidates ignored the seal author (D-14), the holder would take the owner's displaced
  // edition, the newest record in its history, for its own and re-apply the ban the owner wrote.
  it("another BAN holder never re-applies a ban it did not write (D-14)", async () => {
    const owner = await ownerEngine();
    let holder: Awaited<ReturnType<typeof restartEngine>> | undefined;
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const rival = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const lost = randomMember();
      const winner = randomMember();
      // The sibling wins the tie; the owner's displaced edition is written a second later so it is the newest record.
      const sibling = await injectBanlist(owner.community, rival, { content: JSON.stringify([winner]), version: 1 });
      await new Promise((resolve) => setTimeout(resolve, 1_100));
      const displaced = await injectBanlist(owner.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([lost]),
        version: 1,
        lose: sibling.rumorId,
      });

      // The staff member's engine starts over the whole history, so it plans with the displaced edition retained.
      holder = await restartEngine({ net: owner.net, ...staff }, owner.community.material, [
        sibling.wrap,
        displaced.wrap,
      ]);
      expect(banlistHead(holder.engine)?.hash).toBe(sibling.hash);
      expect(holder.engine.state$.value.banlist.has(winner)).toBe(true);
      expect(holder.engine.state$.value.banlist.has(lost)).toBe(false);
      expect(holder.engine.canDo(PERM.BAN)).toBe(true);

      await advance(holder.engine, holder.clock, 60_000);
      expect(banlistEditions(holder.engine, holder.net)).toHaveLength(0);
      expect(holder.engine.state$.value.banlist.has(lost)).toBe(false);
      expect(holder.duties.pending).toBe(0);
    } finally {
      await disposeAll(owner, ...(holder ? [{ community: holder.engine, store: holder.store }] : []));
    }
  });

  // Non-vacuity: without the owner's re-apply a junior sibling's tie win would silently drop the owner's ban; the
  // heal puts it back on the winner and both entries are honored.
  it("a senior re-applies its ban when a junior's sibling wins the tie (mixed rank)", async () => {
    const owner = await ownerEngine();
    try {
      const junior = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const mid = await staffMember(owner.community, { position: 3, permissions: PERM.PIN_MESSAGES });
      const { clock } = useDutyClock(owner.community);
      const { lost, winner, sibling } = await lostBan(owner, junior, mid.pubkey);
      expect(owner.community.state$.value.banlist.has(mid.pubkey)).toBe(false);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);

      await advance(owner.community, clock, SESSION_DELAY_MS);
      const heals = healsOf(owner.community, owner.net);
      expect(heals).toHaveLength(1);
      expect(heals[0].prevHash).toBe(sibling.hash);
      expect(heals[0].content).toBe(JSON.stringify([winner, lost]));
      expect(owner.community.state$.value.banlist.has(mid.pubkey)).toBe(true);
      expect(owner.community.state$.value.banlist.has(winner)).toBe(true);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: if the planner only looked at members missing from the head content, the senior would leave a head
  // that carries its ban but is dropped by rank; the unvouched guard is what lets it re-sign the content unchanged.
  it("a senior re-signs a junior head that carried its ban without vouching for it, content unchanged (mixed rank)", async () => {
    const owner = await ownerEngine();
    try {
      const junior = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const mid = await staffMember(owner.community, { position: 3, permissions: PERM.PIN_MESSAGES });
      const { clock } = useDutyClock(owner.community);
      const by = randomMember();
      const base = await injectBanlist(owner.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([mid.pubkey]),
        version: 1,
      });
      expect(owner.community.state$.value.banlist.has(mid.pubkey)).toBe(true);
      const carried = await injectBanlist(owner.community, junior, {
        content: JSON.stringify([mid.pubkey, by]),
        version: 2,
        prevHash: base.hash,
      });
      expect(banlistHead(owner.community)?.hash).toBe(carried.hash);
      expect(owner.community.state$.value.banlist.has(by)).toBe(true);
      expect(owner.community.state$.value.banlist.has(mid.pubkey)).toBe(false);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(0);

      await advance(owner.community, clock, 30_000);
      const heals = banlistEditions(owner.community, owner.net);
      expect(heals).toHaveLength(1);
      expect(heals[0].version).toBe(3);
      expect(heals[0].prevHash).toBe(carried.hash);
      expect(heals[0].content).toBe(JSON.stringify([mid.pubkey, by]));
      expect(owner.community.state$.value.banlist.has(mid.pubkey)).toBe(true);
      expect(owner.community.state$.value.banlist.has(by)).toBe(true);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: without the unvouched guard the junior would publish [MID, BY] and the fold would drop MID again
  // under the junior's rank (silently lifting the senior's ban); the guard publishes nothing and reports once.
  it("a junior whose lost ban sits under a senior's head is blocked and reports BanlistReHealError (mixed rank)", async () => {
    const owner = await ownerEngine();
    const junior = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
    const mid = await staffMember(owner.community, { position: 3, permissions: PERM.PIN_MESSAGES });
    const healer = await memberEngine(owner, junior);
    const reports = diagnosticsOf(healer.community);
    try {
      const { clock, duties } = useDutyClock(healer.community);
      const by = randomMember();
      await healer.community.ban(by);
      await dutiesSettled(healer.community);
      const own = banlistEditions(healer.community, healer.net)[0];
      await injectBanlist(healer.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([mid.pubkey]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      expect(healer.community.state$.value.banlist.has(by)).toBe(false);
      expect(healer.community.state$.value.banlist.has(mid.pubkey)).toBe(true);

      await advance(healer.community, clock, 120_000);
      expect(banlistEditions(healer.community, healer.net)).toHaveLength(1);
      expect(duties.slotPending(SLOT)).toBe(false);
      const blocked = ofStage(reports.seen, "banlist-reheal");
      expect(blocked).toHaveLength(1);
      expect(blocked[0].error).toBeInstanceOf(BanlistReHealError);
      const error = blocked[0].error as BanlistReHealError;
      expect(error.reason).toBe("blocked");
      expect(error.members).toEqual([mid.pubkey]);
    } finally {
      reports.stop();
      await disposeAll(owner, healer);
    }
  });

  // Non-vacuity: the forced republish that keeps a restart from reviving the lost ban went through the full D-19 check,
  // so unbanning a member who is not banned rejected with an error about the senior's entry instead of resolving.
  it("unbanning a member only a junior's lost own ban still lists resolves and reports unban-not-durable (D-19)", async () => {
    const owner = await ownerEngine();
    const junior = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
    const mid = await staffMember(owner.community, { position: 3, permissions: PERM.PIN_MESSAGES });
    const healer = await memberEngine(owner, junior);
    const reports = diagnosticsOf(healer.community);
    try {
      const { clock } = useDutyClock(healer.community);
      const by = randomMember();
      await healer.community.ban(by);
      await dutiesSettled(healer.community);
      const own = banlistEditions(healer.community, healer.net)[0];
      const head = await injectBanlist(healer.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([mid.pubkey]),
        version: 1,
        beat: getEventHash(own.rumor),
      });

      await expect(healer.community.unban(by)).resolves.toBeUndefined();
      await dutiesSettled(healer.community);
      expect(banlistEditions(healer.community, healer.net)).toHaveLength(1);
      expect(writerOf(healer.community).intents().get(by)?.action).toBe("unban");
      const durable = ofStage(reports.seen, "banlist-reheal").filter((diagnostic) =>
        (diagnostic.error as BanlistReHealError).reason === "unban-not-durable"
      );
      expect(durable).toHaveLength(1);
      expect(durable[0].key).toBe(head.hash);
      expect((durable[0].error as BanlistReHealError).members).toEqual([by]);

      await advance(healer.community, clock, 120_000);
      expect(banlistEditions(healer.community, healer.net)).toHaveLength(1);
      expect(healer.community.state$.value.banlist.has(by)).toBe(false);
    } finally {
      reports.stop();
      await disposeAll(owner, healer);
    }
  });

  // Non-vacuity: without the current-epoch scope the unban found the old epoch's own edition and spent a rate slot and
  // an edition republishing a list no restart could ever heal from (D-15).
  it("unban after a Refounding never republishes for an own edition from the old epoch (D-15)", async () => {
    const owner = await ownerEngine();
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      useDutyClock(owner.community);
      const { lost } = await lostBan(owner, staff);
      const epoch = owner.community.material.root_epoch;
      await owner.community.refound({ keep: [owner.pubkey] });
      await dutiesSettled(owner.community);
      expect(owner.community.material.root_epoch).toBeGreaterThan(epoch);
      const before = banlistEditions(owner.community, owner.net).length;

      await owner.community.unban(lost);
      await dutiesSettled(owner.community);
      expect(banlistEditions(owner.community, owner.net)).toHaveLength(before);
      expect(owner.community.state$.value.banlist.has(lost)).toBe(false);
    } finally {
      await disposeAll(owner);
    }
  });

  // Non-vacuity: with only the Banlist head and the effective set in the re-heal signature, a promotion changes neither,
  // so the blocked heal stays dormant until some unrelated Banlist change; the authority fingerprint re-plans it.
  it("a blocked heal is re-planned and published once the healer gains rank over the carried entry", async () => {
    const owner = await ownerEngine();
    const junior = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
    const mid = await staffMember(owner.community, { position: 3, permissions: PERM.PIN_MESSAGES });
    const healer = await memberEngine(owner, junior);
    try {
      const { clock } = useDutyClock(healer.community);
      const by = randomMember();
      await healer.community.ban(by);
      await dutiesSettled(healer.community);
      const own = banlistEditions(healer.community, healer.net)[0];
      const head = await injectBanlist(healer.community, { signer: owner.signer, pubkey: owner.pubkey }, {
        content: JSON.stringify([mid.pubkey]),
        version: 1,
        beat: getEventHash(own.rumor),
      });
      await advance(healer.community, clock, 120_000);
      expect(banlistEditions(healer.community, healer.net)).toHaveLength(1);

      const from = owner.net.published.length;
      const senior = await owner.community.admin.createRole("senior", 2, BAN_STAFF);
      await owner.community.admin.grantRoles(junior.pubkey, [junior.roleId, senior]);
      await relayInto(owner.net, healer.community, from);
      await dutiesSettled(healer.community);
      expect(banlistHead(healer.community)?.hash).toBe(head.hash);

      await advance(healer.community, clock, 120_000);
      const editions = banlistEditions(healer.community, healer.net);
      expect(editions).toHaveLength(2);
      expect(editions[1].prevHash).toBe(head.hash);
      expect(editions[1].content).toBe(JSON.stringify([mid.pubkey, by]));
      expect(healer.community.state$.value.banlist.has(by)).toBe(true);
      expect(healer.community.state$.value.banlist.has(mid.pubkey)).toBe(true);
    } finally {
      await disposeAll(owner, healer);
    }
  });

  // Non-vacuity: without the current-epoch check on the newest own edition the restarted engine would find the old
  // epoch's edition in its history and re-apply a ban the Refounding did not carry.
  it("a ban lost before a Refounding is not re-applied after a restart into the new epoch (D-15)", async () => {
    const owner = await ownerEngine();
    let restarted: Awaited<ReturnType<typeof restartEngine>> | undefined;
    try {
      const staff = await staffMember(owner.community, { position: 4, permissions: BAN_STAFF });
      const { duties } = useDutyClock(owner.community);
      const { lost, sibling } = await lostBan(owner, staff);
      expect(duties.slotPending(SLOT)).toBe(true);
      const epoch = owner.community.material.root_epoch;
      await owner.community.refound({ keep: [owner.pubkey] });
      await dutiesSettled(owner.community);
      expect(owner.community.material.root_epoch).toBeGreaterThan(epoch);
      owner.community.dispose();

      restarted = await restartEngine(owner, owner.community.material, [sibling.wrap]);
      expect(restarted.engine.material.root_epoch).toBeGreaterThan(epoch);
      expect(restarted.engine.state$.value.banlist.has(lost)).toBe(false);
      await advance(restarted.engine, restarted.clock, 60_000);
      expect(banlistEditions(restarted.engine, restarted.net)).toHaveLength(0);
      expect(restarted.engine.state$.value.banlist.has(lost)).toBe(false);
      expect(restarted.duties.pending).toBe(0);
    } finally {
      await disposeAll(owner, ...(restarted ? [{ community: restarted.engine, store: restarted.store }] : []));
    }
  });
});

/** Let the fake pool and folds settle without waiting on duties. */
function settle(community: ConcordCommunity): Promise<void> {
  return dutiesSettled(community);
}

/**
 * Park the next publication on `net` until `release()`, then refuse it, so the write holds the Banlist queue without
 * moving the head. Later publications go through unchanged.
 */
function parkNextPublishThenRefuse(net: Parameters<typeof banlistEditions>[1]) {
  const pool = net.pool as unknown as { publish(relays: string[], event: NostrEvent): Promise<unknown> };
  const original = pool.publish.bind(pool);
  let release!: () => void;
  const gate = new Promise<void>((resolve) => release = resolve);
  let parked = false;
  pool.publish = async (relays, event) => {
    if (parked) return await original(relays, event);
    parked = true;
    await gate;
    pool.publish = original;
    return [{ ok: false, from: "wss://fake", message: "blocked" }];
  };
  return { parked: () => parked, release: () => release() };
}
