// Owned duty lifecycle wiring (FND-01, FND-05). Stop, dispose, dissolution and demotion must cancel
// every library-owned timer and retry, and a signer, storage or relay completion that arrives after
// stop or a document change must never publish or overwrite newer state.

/// <reference lib="deno.ns" />
// Test-only: the WR-03 completeness check reads the client source, so it opts into the Deno namespace (see
// index.cord-citations.test.ts).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { spy } from "@std/testing/mock";
import { BehaviorSubject, EMPTY, firstValueFrom, Subject, throwError } from "rxjs";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { EventStore } from "applesauce-core";
import "applesauce-common/casts";
import type { NostrEvent } from "applesauce-core/helpers/event";

import { ConcordClient } from "../src/client/client.ts";
import { ConcordClientDisposedError } from "../src/client/community-list-sync.ts";
import { ConcordCommunity } from "../src/client/community.ts";
import { type ConcordStorage, memoryStorage } from "../src/client/storage.ts";
import { type DutyReport, DutyScope } from "../src/client/lifecycle.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import { COMMUNITY_LIST_KIND } from "../src/helpers/community-list.ts";
import { INVITE_LIST_KIND } from "../src/helpers/invite-list.ts";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import {
  COMMUNITY_LIST_FRAGMENT_KIND,
  decodeCommunityListFragment,
  encodeCommunityListFragment,
} from "../src/helpers/community-list-wire.ts";
import { fakeRelayPool, Gate, gatedSigner, gatedStorage, ManualClock } from "../src/client/__tests__/test-utils.ts";
import type { ISigner } from "applesauce-signers";
import type { InviteBundle, JoinMaterial } from "../src/types.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));

const listPublishes = (published: NostrEvent[]) => published.filter((e) => e.kind === COMMUNITY_LIST_FRAGMENT_KIND);

interface ClientDuties {
  listDuties: DutyScope;
  diagnostics: { reportDuty(report: DutyReport): void };
}

/** Swap the constructor-created scope for a ManualClock-driven one before `start()`. */
function injectClock(client: ConcordClient, clock: ManualClock): ClientDuties {
  const internals = client as unknown as ClientDuties;
  internals.listDuties.dispose();
  internals.listDuties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report) });
  return internals;
}

/** Client and store, built together and torn down in one place. */
function build(
  signer: ISigner,
  pool: ConstructorParameters<typeof ConcordClient>[0]["pool"],
  storage: ConcordStorage = memoryStorage(),
) {
  const store = new EventStore();
  const client = new ConcordClient({
    signer,
    pool,
    eventStore: store,
    storage,
    relays: ["wss://fake"],
    watchDirectInvites: false,
  });
  return { client, store };
}

async function legacyMaterial(pubkey: string, name: string): Promise<JoinMaterial> {
  return (await createLegacyCommunity({ ownerPubkey: pubkey, name, relays: ["wss://fake"] })).material;
}

type SignArgs = Parameters<ISigner["signEvent"]>;
type SignResult = Awaited<ReturnType<ISigner["signEvent"]>>;

/** Parks only Community List fragment drafts; every other signature passes straight through. */
class ListDraftGate extends Gate<SignArgs, SignResult> {
  override wrap(
    inner: (...args: SignArgs) => Promise<SignResult>,
    match: (...args: SignArgs) => boolean = (draft) => draft.kind === COMMUNITY_LIST_FRAGMENT_KIND,
  ): (...args: SignArgs) => Promise<SignResult> {
    return super.wrap(inner, match);
  }
}

interface CommunityInternals {
  duties: DutyScope;
  sealCommunity(): void;
  rewireState(): void;
}

describe("owned duty lifecycle (FND-01, FND-05)", () => {
  it("dissolution suspends community publication duties with zero pending timers", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const { pool } = fakeRelayPool();
    const { client, store } = build(signer, pool);
    try {
      await client.start();
      const created = await client.createNewCommunity("Doomed", "", ["wss://fake"]);
      await settle();
      const internals = created as unknown as CommunityInternals;
      expect(internals.duties.request({ key: "publish-later", stage: "test", delayMs: 60_000, run: () => {} })).toBe(
        "armed",
      );
      expect(internals.duties.pending).toBe(1);

      internals.sealCommunity();

      expect(internals.duties.pending).toBe(0);
      expect(internals.duties.suspendedReason).toBe("dissolved");
      expect(internals.duties.request({ key: "publish-again", stage: "test", run: () => {} })).toBe("refused");
      expect(
        internals.duties.request({
          key: "local-cleanup",
          stage: "test",
          publishes: false,
          delayMs: 60_000,
          run: () => {},
        }),
      ).toBe("armed");

      client.stop();
      expect(internals.duties.disposed).toBe(true);
      expect(internals.duties.pending).toBe(0);
    } finally {
      client.dispose();
      store.dispose();
    }
  });

  it("community dispose cancels armed duties with zero pending timers", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const store = new EventStore();
    const community = new ConcordCommunity({
      material: await legacyMaterial(pubkey, "Disposable"),
      signer,
      pubkey,
      pool: fakeRelayPool().pool,
      eventStore: store,
    });
    try {
      const duties = (community as unknown as CommunityInternals).duties;
      duties.request({ key: "publish-later", stage: "test", delayMs: 60_000, run: () => {} });
      duties.request({ key: "cleanup-later", stage: "test", publishes: false, delayMs: 60_000, run: () => {} });
      expect(duties.pending).toBe(2);

      community.dispose();

      expect(duties.disposed).toBe(true);
      expect(duties.pending).toBe(0);
    } finally {
      community.dispose();
      store.dispose();
    }
  });

  it("a folded state change reevaluates duty eligibility", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const store = new EventStore();
    const community = new ConcordCommunity({
      material: await legacyMaterial(pubkey, "Demotable"),
      signer,
      pubkey,
      pool: fakeRelayPool().pool,
      eventStore: store,
    });
    const internals = community as unknown as CommunityInternals;
    const reevaluate = spy(internals.duties, "reevaluate");
    try {
      let authorised = true;
      let ran = false;
      internals.duties.request({
        key: "authority-bound",
        stage: "test",
        delayMs: 60_000,
        eligible: () => authorised,
        run: () => {
          ran = true;
        },
      });
      expect(internals.duties.pending).toBe(1);

      authorised = false; // demotion
      internals.rewireState();
      await settle();

      expect(reevaluate.calls.length).toBeGreaterThan(0);
      expect(internals.duties.pending).toBe(0);
      expect(ran).toBe(false);
    } finally {
      reevaluate.restore();
      community.dispose();
      store.dispose();
    }
  });

  it("client stop cancels the list-read retry and dispose is terminal", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const net = fakeRelayPool();
    let listReads = 0;
    net.setRequest((filters) => {
      if (!filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) return EMPTY;
      listReads++;
      return throwError(() => new Error("relay down"));
    });
    const clock = new ManualClock();
    const { client, store } = build(signer, net.pool);
    const internals = injectClock(client, clock);
    try {
      await client.start();
      expect(internals.listDuties.pending).toBe(1);

      client.stop();
      expect(internals.listDuties.pending).toBe(0);
      expect(internals.listDuties.disposed).toBe(false);

      client.dispose();
      expect(internals.listDuties.disposed).toBe(true);
      expect(internals.listDuties.pending).toBe(0);

      // D-32: dispose is terminal, so start() rejects and nothing is armed, read or retried afterwards.
      const readsAfterDispose = listReads;
      await expect(client.start()).rejects.toThrow(ConcordClientDisposedError);
      expect(client.phase$.value).toBe("idle");
      await settle();
      clock.tick(120_000);
      await internals.listDuties.idle();
      await settle();
      expect(listReads).toBe(readsAfterDispose);
      expect(internals.listDuties.pending).toBe(0);
    } finally {
      client.stop();
      await settle();
      client.dispose();
      store.dispose();
    }
  });

  it("a stale list read completing after stop never updates status or publishes", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const net = fakeRelayPool({ online: false });
    const clock = new ManualClock();
    const { client, store } = build(signer, net.pool);
    const internals = injectClock(client, clock);
    try {
      await client.start();
      await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settle();
      expect(internals.listDuties.pending).toBe(1);

      const hanging = new Subject<NostrEvent>();
      net.setOnline(true);
      net.setRequest(() => hanging);
      clock.tick(6_000);
      await settle();

      client.stop();
      await settle();

      const fragment = await signer.signEvent({
        kind: COMMUNITY_LIST_FRAGMENT_KIND,
        created_at: Math.floor(Date.now() / 1000) - 100,
        tags: [["d", "0"]],
        content: await signer.nip44!.encrypt(
          pubkey,
          encodeCommunityListFragment({ frags: 1, entries: [], tombstones: [] } as never),
        ),
      });
      hanging.next(fragment);
      hanging.complete();
      await internals.listDuties.idle();
      await settle();

      expect(listPublishes(net.published)).toHaveLength(0);
      expect(client.communityListSync.status.knowledge).toBe("unknown");
      expect(internals.listDuties.pending).toBe(0);
    } finally {
      client.stop();
      client.dispose();
      store.dispose();
    }
  });

  for (const teardown of ["stop", "dispose"] as const) {
    it(`${teardown}() during start() never publishes the held Community List save afterwards`, async () => {
      const signer = new PrivateKeySigner(generateSecretKey());
      const pubkey = await signer.getPublicKey();
      const a = await legacyMaterial(pubkey, "A");
      const material = { ...a, held_roots: a.held_roots ?? [] };
      const storage = memoryStorage();
      // A join recorded only in the mirror: once the empty relay read completes, start() would release it.
      await storage.setItem(
        pubkey,
        JSON.stringify({
          entries: [{ community_id: material.community_id, seed: material, current: material, added_at: 1 }],
          tombstones: [],
        }),
      );
      const net = fakeRelayPool();
      const inviteRead = new Subject<NostrEvent>();
      let inviteReads = 0;
      net.setRequest((filters) => {
        if (!filters.some((f) => f.kinds?.includes(INVITE_LIST_KIND))) return EMPTY;
        inviteReads++;
        return inviteRead;
      });
      const { client, store } = build(signer, net.pool, storage);
      try {
        const starting = client.start();
        for (let i = 0; i < 200 && inviteReads === 0; i++) await new Promise((r) => setTimeout(r, 10));
        expect(inviteReads).toBe(1); // start() is parked in `invites.start()`, after the completed list read
        client[teardown]();
        inviteRead.complete();
        await starting;
        await settle();
        expect(listPublishes(net.published)).toHaveLength(0);
      } finally {
        client.stop();
        client.dispose();
        store.dispose();
      }
    });
  }

  it("stop() during the kind-13302 read cancels the kind-33302 read start() would issue next", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const net = fakeRelayPool();
    let legacyReads = 0;
    let fragmentReads = 0;
    net.setRequest((filters) => {
      if (filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_KIND))) {
        legacyReads++;
        return new Subject<NostrEvent>();
      }
      if (filters.some((f) => f.kinds?.includes(COMMUNITY_LIST_FRAGMENT_KIND))) fragmentReads++;
      return EMPTY;
    });
    const clock = new ManualClock();
    const { client, store } = build(signer, net.pool);
    const internals = injectClock(client, clock);
    const diagnostics: ConcordDiagnostic[] = [];
    client.diagnostics$.subscribe((diagnostic) => diagnostics.push(diagnostic));
    try {
      const starting = client.start();
      for (let i = 0; i < 200 && legacyReads === 0; i++) await new Promise((r) => setTimeout(r, 10));
      expect(legacyReads).toBe(1);
      client.stop();
      await starting;
      await settle();
      expect(fragmentReads).toBe(0);
      expect(diagnostics.filter((d) => d.stage === "community-list-read")).toHaveLength(0);
      expect(internals.listDuties.pending).toBe(0);
      expect(client.communityListSync.status.knowledge).toBe("unknown");
    } finally {
      client.stop();
      client.dispose();
      store.dispose();
    }
  });

  it("a stale signer completion after a document change never publishes", async () => {
    const inner = new PrivateKeySigner(generateSecretKey());
    const pubkey = await inner.getPublicKey();
    const parked = new ListDraftGate();
    const gated = gatedSigner(inner, { signEvent: parked });
    const net = fakeRelayPool({ events: [] });
    const { client, store } = build(gated, net.pool);
    try {
      await client.start();
      const creating = client.createNewCommunity("B", "", ["wss://fake"]);
      const first = await parked.next();
      const cid = client.communities$.value[0].material.community_id;

      // The sync serializes writes, so the retired first signature must finish before the second one is requested.
      const revision = () => (client as unknown as { communityListRevision: number }).communityListRevision;
      const before = revision();
      const leaving = client.leave(cid);
      for (let i = 0; i < 200 && revision() === before; i++) await new Promise((r) => setTimeout(r, 10));
      expect(revision()).toBeGreaterThan(before); // the leave retired the first draft
      first.release();
      const second = await parked.next();
      second.release();
      await Promise.all([creating, leaving]);
      await settle();

      const lists = listPublishes(net.published);
      expect(lists).toHaveLength(1);
      const doc = decodeCommunityListFragment(await inner.nip44!.decrypt(pubkey, lists[0].content));
      expect(doc.tombstones.some((t) => t.community_id === cid)).toBe(true);
      expect(doc.entries.some((e) => e.community_id === cid)).toBe(false);
    } finally {
      client.stop();
      client.dispose();
      store.dispose();
    }
  });

  it("a stale storage completion after stop restores the unchanged document", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const inner = memoryStorage();
    const gate = new Gate<[key: string, value: string], void>();
    const storage = gatedStorage(inner, { setItem: gate });
    const store = new EventStore();
    const client = new ConcordClient({ signer, pool: fakeRelayPool().pool, eventStore: store, storage });
    try {
      Object.defineProperty(client, "pubkey", { value: pubkey });
      const first = await legacyMaterial(pubkey, "First");
      const second = await legacyMaterial(pubkey, "Second");
      const entries = [first, second].map((material, added_at) => ({
        community_id: material.community_id,
        seed: material,
        current: material,
        added_at,
      }));
      (client as unknown as { list: typeof entries }).list = entries;
      const engines = (client as unknown as { communities: Map<string, ConcordCommunity> }).communities;
      for (const material of [first, second]) {
        engines.set(
          material.community_id,
          new ConcordCommunity({ material, signer, pubkey, pool: fakeRelayPool().pool, eventStore: store }),
        );
      }
      const persist = (client as unknown as {
        persistMaterialChange(changed: JoinMaterial, source: ConcordCommunity): Promise<void>;
      }).persistMaterialChange(
        { ...first, root_epoch: first.root_epoch + 1 },
        engines.get(first.community_id)!,
      );

      const staged = await gate.next();
      client.stop();
      staged.release();
      const restore = await gate.next();
      restore.release();
      await persist;

      const durable = JSON.parse((await inner.getItem(pubkey))!) as { entries: Array<{ current: JoinMaterial }> };
      expect(durable.entries.map((e) => e.current.root_epoch)).toEqual([first.root_epoch, second.root_epoch]);
    } finally {
      client.dispose();
      store.dispose();
    }
  });
});

describe("ConcordClient after dispose() (D-32, 01-REVIEW-GAPS WR-03)", () => {
  /** Public member names of the `ConcordClient` class body: methods and getters, `$`-suffixed names included. */
  function publicClientMembers(): Set<string> {
    const source = Deno.readTextFileSync(new URL("../src/client/client.ts", import.meta.url));
    const start = source.indexOf("export class ConcordClient ");
    const end = source.indexOf("\n}\n", start);
    const names = new Set<string>();
    for (const line of source.slice(start, end).split("\n")) {
      if (line.startsWith("  private ")) continue;
      const match = /^ {2}(?:async |get )?([A-Za-z_$][A-Za-z0-9_$]*)\(/.exec(line);
      if (match && match[1] !== "constructor") names.add(match[1]);
    }
    return names;
  }

  it("every public ConcordClient method after dispose() rejects with ConcordClientDisposedError or starts no work (WR-03)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const net = fakeRelayPool();
    let requests = 0;
    net.setRequest(() => {
      requests++;
      return EMPTY;
    });
    const store = new EventStore();
    const extra = new BehaviorSubject<string[]>([]);
    const client = new ConcordClient({
      signer,
      pool: net.pool,
      eventStore: store,
      storage: memoryStorage(),
      relays: ["wss://fake"],
      watchDirectInvites: false,
      extraRelays: extra,
    });
    const internals = client as unknown as ClientDuties;
    try {
      await client.start();
      await settle();
      client.dispose();
      expect(extra.observed).toBe(false);
      const requestsBefore = requests;
      const publishedBefore = net.published.length;

      const disposed = ConcordClientDisposedError;
      const table: Record<string, () => Promise<unknown> | void> = {
        start: () => expect(client.start()).rejects.toThrow(disposed),
        createNewCommunity: () =>
          expect(client.createNewCommunity("B", "disposed", ["wss://fake"])).rejects.toThrow(disposed),
        joinByLink: () => expect(client.joinByLink("https://example.invalid/invite#x")).rejects.toThrow(disposed),
        joinByBundle: () => expect(client.joinByBundle({} as InviteBundle)).rejects.toThrow(disposed),
        leave: () => expect(client.leave("00".repeat(32))).rejects.toThrow(disposed),
        unlockCommunityListFragments: () => expect(client.unlockCommunityListFragments()).rejects.toThrow(disposed),
        startDirectInviteWatcher: () => expect(() => client.startDirectInviteWatcher()).toThrow(disposed),
        schedulePurge: () => expect(() => client.schedulePurge()).toThrow(disposed),
        stop: () => expect(() => client.stop()).not.toThrow(),
        dispose: () => expect(() => client.dispose()).not.toThrow(),
        saveCommunityList: async () => expect(await client.saveCommunityList()).toBeUndefined(),
        getCommunity: () => expect(client.getCommunity("00".repeat(32))).toBeUndefined(),
        directInviteWatcher: () => expect(client.directInviteWatcher).toBeUndefined(),
        pubkey: () => expect(typeof client.pubkey).toBe("string"),
        communityList$: async () => void await firstValueFrom(client.communityList$),
        communityListStatus$: async () => void await firstValueFrom(client.communityListStatus$),
        inviteList$: async () => void await firstValueFrom(client.inviteList$),
        memberships$: async () => void await firstValueFrom(client.memberships$),
        memberships: () => expect(client.memberships().entries).toEqual([]), // a pure read: starts no work
      };
      for (const [member, row] of Object.entries(table)) {
        try {
          await row();
        } catch (error) {
          if (error instanceof Error) error.message = `${member}() after dispose(): ${error.message}`;
          throw error;
        }
      }
      await settle();

      expect(extra.observed).toBe(false);
      expect(client.directInviteWatcher$.value).toBeUndefined();
      expect(requests).toBe(requestsBefore);
      expect(net.published).toHaveLength(publishedBefore);
      expect(internals.listDuties.pending).toBe(0);
      expect(client.phase$.value).toBe("idle");

      // Completeness: a public member added to client.ts without a row here fails loudly.
      const scanned = publicClientMembers();
      for (
        const anchor of ["start", "startDirectInviteWatcher", "communityList$", "communityListStatus$", "inviteList$"]
      ) {
        expect(scanned.has(anchor), `the client.ts scan missed ${anchor}`).toBe(true);
      }
      const keys = new Set(Object.keys(table));
      const missing = [...scanned].filter((name) => !keys.has(name));
      const extraRows = [...keys].filter((name) => !scanned.has(name));
      expect({ missing, extra: extraRows }, `missing rows: ${missing.join(", ")}; extra rows: ${extraRows.join(", ")}`)
        .toEqual({ missing: [], extra: [] });
    } finally {
      client.stop(); // also disposes a watcher a failing row may have started
      await settle();
      client.dispose();
      store.dispose();
    }
  });
});
