// CORD-03 §3 forum posts end to end on a community over a fake relay pool: a titled post is a kind 9 with one
// `subject` tag (D-01), the 256-byte cap rejects before anything is uploaded or signed (D-03), inbound titles display
// truncated without dropping the message (D-04), `sendThread` is a deprecated alias that emits a titled kind 9
// (D-02), and kind 11 history already retained stays readable with reply roots intact (D-08). D-18 covers the
// options-object overload of `sendMessage` and D-22 the blank-title rule.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { EventStore } from "applesauce-core";
import { ChatMessageFactory, ForumThreadFactory } from "applesauce-common/factories";
import { getEventHash, kinds, type NostrEvent, type Rumor } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { firstValueFrom } from "rxjs";

import { MULTIBYTE_ASTRAL_CHAR, tagValues, utf8Bytes } from "../src/__tests__/cord-wire-fixtures.ts";
import { newestValidEdit } from "../src/helpers/edit.ts";
import { displaySubject, getSubject } from "../src/helpers/forum.ts";
import { EditFactory } from "../src/factories/edit.ts";
import { decodeWrap } from "../src/helpers/gift-wrap.ts";
import { type ConcordKeys, type PlaneInfo, wrapForTarget } from "../src/helpers/keys.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import { bindToChannel } from "../src/operations/channel.ts";
import { ConcordCommunity } from "../src/client/community.ts";
import { type ConcordUploader, memoryStorage } from "../src/client/storage.ts";
import type { ChannelView } from "../src/client/community.ts";
import { VSK } from "../src/types.ts";
import { type FakeRelayPool, fakeRelayPool } from "../src/client/__tests__/test-utils.ts";

// The control fold + sync are debounced/async; let them run before asserting.
const settle = () => new Promise((r) => setTimeout(r, 200));

interface Fixture {
  community: ConcordCommunity;
  store: EventStore;
  net: FakeRelayPool;
  channelId: string;
  uploads: number;
}

/** An owner community over a fake pool with its genesis published, plus a counting uploader. */
async function setup(): Promise<Fixture> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const net = fakeRelayPool();
  const genesis = await createLegacyCommunity({ ownerPubkey: pubkey, name: "Test", relays: ["wss://fake"] });
  const store = new EventStore();
  const fixture = { store, net, uploads: 0 } as Fixture;
  const uploader: ConcordUploader = {
    upload: async () => {
      fixture.uploads++;
      return { url: "https://example.test/blob" };
    },
  };
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material: genesis.material,
    signer,
    pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    uploader,
  });
  await community.start();
  for (const rumor of genesis.controlRumors) {
    await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
  }
  for (const rumor of genesis.guestbookRumors) await community.publishToPlane({ plane: "guestbook" }, rumor, {});
  await settle();
  fixture.community = community;
  fixture.channelId = community.state$.value.channels.find((c) => c.name === "general")!.channel_id;
  return fixture;
}

/** Run `body` on a fresh fixture and always tear it down. */
async function withFixture(body: (fixture: Fixture) => Promise<void>): Promise<void> {
  const fixture = await setup();
  try {
    await body(fixture);
  } finally {
    fixture.community.dispose();
    fixture.store.dispose();
  }
}

/** The channel rumors this community published so far, decoded from the wraps on the fake pool. */
function publishedChannelRumors(fixture: Fixture): Rumor[] {
  const keys = (fixture.community as unknown as { keys: { planes: Map<string, PlaneInfo> } }).keys;
  const out: Rumor[] = [];
  for (const wrap of fixture.net.published) {
    const info = keys.planes.get(wrap.pubkey);
    if (info?.type !== "channel" || info.channelId !== fixture.channelId) continue;
    const decoded = decodeWrap(structuredClone(wrap), info.convKey);
    if (decoded) out.push(decoded.rumor);
  }
  return out;
}

/** A retained channel rumor of `kind` with `content`, read through the ban-aware timeline. */
async function rumorWithContent(fixture: Fixture, kind: number, content: string): Promise<Rumor> {
  const timeline = await firstValueFrom(fixture.community.channelTimeline(fixture.channelId, [{ kinds: [kind] }]));
  const found = timeline.find((rumor) => rumor.content === content);
  // An assertion, not a thrown Error, so a retained-message regression fails as a test assertion.
  expect(found, `no kind ${kind} rumor with content ${JSON.stringify(content)}`).toBeDefined();
  return found!;
}

describe("titled forum posts (FORUM-01, FORUM-02, DEC-03)", () => {
  it("sendMessage with a subject publishes kind 9 with one subject tag and the channel binding (CORD-03 §3)", async () => {
    await withFixture(async (f) => {
      await f.community.sendMessage(f.channelId, "post body", { subject: "Release plan" });
      await settle();

      const post = await rumorWithContent(f, kinds.ChatMessage, "post body");
      expect(post.kind).toBe(9);
      expect(tagValues(post.tags, "subject")).toEqual(["Release plan"]);
      expect(tagValues(post.tags, "channel")).toEqual([f.channelId]);
      expect(tagValues(post.tags, "epoch")).toEqual([String(f.community.material.root_epoch)]);
      expect(post.tags.filter((t) => t[0] === "ms")).toHaveLength(1);
      expect(post.kind).not.toBe(11);
    });
  });

  it("sendMessage takes an options object as its third argument and keeps the positional reply parent (D-18)", async () => {
    await withFixture(async (f) => {
      await f.community.sendMessage(f.channelId, "root message");
      await settle();
      const root = await rumorWithContent(f, kinds.ChatMessage, "root message");

      // Positional form with the options object as the sixth argument.
      await f.community.sendMessage(
        f.channelId,
        "reply post",
        { id: root.id, author: root.pubkey },
        undefined,
        undefined,
        {
          subject: "Re: root",
        },
      );
      await settle();
      const reply = await rumorWithContent(f, kinds.ChatMessage, "reply post");
      expect(tagValues(reply.tags, "q")).toContain(root.id);
      expect(tagValues(reply.tags, "subject")).toEqual(["Re: root"]);

      // Options object as the third argument carries no reply parent.
      await f.community.sendMessage(f.channelId, "options post", { subject: "Options" });
      await settle();
      const titled = await rumorWithContent(f, kinds.ChatMessage, "options post");
      expect(tagValues(titled.tags, "subject")).toEqual(["Options"]);
      expect(tagValues(titled.tags, "q")).toEqual([]);

      // An options object may carry only the upload-progress reporter; no subject tag appears.
      await f.community.sendMessage(f.channelId, "plain", { onUploadProgress: () => {} });
      await settle();
      const plain = await rumorWithContent(f, kinds.ChatMessage, "plain");
      expect(tagValues(plain.tags, "subject")).toEqual([]);
    });
  });

  // Non-vacuity: the old detection treated any object without a string `author` as options, so a rumor-like reply
  // parent, positional files and a title on the reply object were all dropped without an error.
  it("ambiguous sendMessage third arguments reject with TypeError before any upload or publish", async () => {
    await withFixture(async (f) => {
      const before = f.net.published.length;
      const send = f.community.sendMessage.bind(f.community) as (...args: unknown[]) => Promise<void>;
      const id = "a".repeat(64);
      const author = "b".repeat(64);
      const files = [new Blob(["file"])];
      for (
        const args of [
          [{ id, pubkey: author }],
          [{ id, author: 7 }],
          [{ author }],
          [{ id, author, subject: "Lost title" }],
          [{ subject: "Title" }, files],
          [{ subject: "Title" }, undefined, []],
          [{ subject: "Title" }, undefined, undefined, { subject: "Other" }],
          ["not a reply"],
        ]
      ) {
        await expect(send(f.channelId, "ambiguous", ...args)).rejects.toBeInstanceOf(TypeError);
      }
      expect(f.uploads).toBe(0);
      expect(f.net.published.length).toBe(before);

      // A null third argument still means no reply parent.
      await send(f.channelId, "null reply", null);
      await settle();
      const plain = await rumorWithContent(f, kinds.ChatMessage, "null reply");
      expect(tagValues(plain.tags, "q")).toEqual([]);
    });
  });

  it("an over-cap subject rejects with RangeError before any upload or publish (D-03)", async () => {
    await withFixture(async (f) => {
      const before = f.net.published.length;
      const overCap = "a".repeat(257);
      await expect(
        f.community.sendMessage(f.channelId, "body", undefined, [new Blob(["file"])], undefined, { subject: overCap }),
      ).rejects.toBeInstanceOf(RangeError);
      await expect(f.community.sendThread(f.channelId, overCap, "body")).rejects.toBeInstanceOf(RangeError);
      expect(f.uploads).toBe(0);
      expect(f.net.published.length).toBe(before);

      // Exactly 256 bytes of astral characters is accepted, counting bytes and not code units.
      const exact = MULTIBYTE_ASTRAL_CHAR.repeat(64);
      expect(utf8Bytes(exact)).toBe(256);
      await f.community.sendMessage(f.channelId, "exact", { subject: exact });
      await settle();
      const post = await rumorWithContent(f, kinds.ChatMessage, "exact");
      expect(tagValues(post.tags, "subject")).toEqual([exact]);
      expect(publishedChannelRumors(f).some((rumor) => rumor.content === "exact")).toBe(true);
    });
  });

  it("an empty or whitespace-only subject publishes no subject tag (D-22)", async () => {
    await withFixture(async (f) => {
      await f.community.sendMessage(f.channelId, "empty subject", { subject: "" });
      await f.community.sendMessage(f.channelId, "blank subject", { subject: "   \t " });
      await settle();
      for (const content of ["empty subject", "blank subject"]) {
        const rumor = await rumorWithContent(f, kinds.ChatMessage, content);
        expect(rumor.tags.some((t) => t[0] === "subject")).toBe(false);
      }

      // A non-blank title is published verbatim, never trimmed.
      await f.community.sendMessage(f.channelId, "padded", { subject: "  Padded  " });
      await settle();
      const padded = await rumorWithContent(f, kinds.ChatMessage, "padded");
      expect(tagValues(padded.tags, "subject")).toEqual(["  Padded  "]);
    });
  });

  it("sendThread publishes a titled kind 9 and never a kind 11 (DEC-03, D-02)", async () => {
    await withFixture(async (f) => {
      await f.community.sendThread(f.channelId, "Thread title", "thread body");
      await settle();

      const post = await rumorWithContent(f, kinds.ChatMessage, "thread body");
      expect(tagValues(post.tags, "subject")).toEqual(["Thread title"]);
      expect(tagValues(post.tags, "channel")).toEqual([f.channelId]);

      const all = publishedChannelRumors(f);
      expect(all.some((rumor) => rumor.kind === 11)).toBe(false);
      const retained = await firstValueFrom(f.community.channelTimeline(f.channelId, [{ kinds: [11] }]));
      expect(retained).toEqual([]);
    });
  });

  it("sendThread with an empty title publishes an untitled kind 9 (D-22)", async () => {
    await withFixture(async (f) => {
      await f.community.sendThread(f.channelId, "", "untitled body");
      await settle();
      const post = await rumorWithContent(f, kinds.ChatMessage, "untitled body");
      expect(post.kind).toBe(9);
      expect(post.tags.some((t) => t[0] === "subject")).toBe(false);
    });
  });

  it("a received post with an overlong subject is kept and displays truncated on a code-point boundary (FORUM-02, D-04)", async () => {
    await withFixture(async (f) => {
      const foreign = new PrivateKeySigner(generateSecretKey());
      const overlong = MULTIBYTE_ASTRAL_CHAR.repeat(75); // 300 bytes
      expect(utf8Bytes(overlong)).toBe(300);

      const keys = (f.community as unknown as { keys: ConcordKeys }).keys;
      const epoch = f.community.material.root_epoch;
      const draft = await ChatMessageFactory.create("foreign post");
      draft.tags.push(["subject", overlong]);
      const rumor = await bindToChannel(f.channelId, epoch)(draft);
      const { wrap } = await wrapForTarget(keys, { plane: "channel", channelId: f.channelId }, foreign, rumor, {});
      await (f.community as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(wrap);
      await settle();

      // The message is kept; only the display is shortened.
      const kept = await rumorWithContent(f, kinds.ChatMessage, "foreign post");
      expect(getSubject(kept)).toBe(overlong);
      const shown = displaySubject(getSubject(kept) ?? "");
      expect(utf8Bytes(shown)).toBeLessThanOrEqual(256);
      expect(shown).toBe(MULTIBYTE_ASTRAL_CHAR.repeat(64));
      expect(shown.includes("�")).toBe(false);
    });
  });

  it("a reply to a titled post roots at the kind 9 post (CORD-03 §3)", async () => {
    await withFixture(async (f) => {
      await f.community.sendMessage(f.channelId, "titled root", { subject: "Topic" });
      await settle();
      const post = await rumorWithContent(f, kinds.ChatMessage, "titled root");

      await f.community.replyToThread(f.channelId, post, "answer");
      await settle();
      const reply = await rumorWithContent(f, kinds.Comment, "answer");
      expect(tagValues(reply.tags, "K")).toEqual(["9"]);
      expect(tagValues(reply.tags, "E")).toEqual([post.id]);
      expect(getEventHash(post)).toBe(post.id);
    });
  });
});

describe("legacy kind 11 history (FORUM-05, D-08)", () => {
  it("a retained kind 11 thread root stays readable in channelTimeline", async () => {
    await withFixture(async (f) => {
      await f.community.sendEvent(f.channelId, ForumThreadFactory.create("Legacy title", "legacy body"));
      await settle();
      const legacy = await rumorWithContent(f, 11, "legacy body");
      const originalId = legacy.id;

      await f.community.sendThread(f.channelId, "New title", "new body");
      await settle();

      const timeline = await firstValueFrom(f.community.channelTimeline(f.channelId, [{ kinds: [11] }]));
      expect(timeline.map((rumor) => rumor.id)).toEqual([originalId]);
      expect(tagValues(timeline[0].tags, "title")).toEqual(["Legacy title"]);
      expect(getSubject(timeline[0])).toBe("Legacy title");
    });
  });

  it("replies to a kind 11 root carry K=11 and a depth-2 reply inherits that root", async () => {
    await withFixture(async (f) => {
      await f.community.sendEvent(f.channelId, ForumThreadFactory.create("Legacy title", "legacy root"));
      await settle();
      const root = await rumorWithContent(f, 11, "legacy root");

      await f.community.replyToThread(f.channelId, root, "first reply");
      await settle();
      const reply1 = await rumorWithContent(f, kinds.Comment, "first reply");
      expect(tagValues(reply1.tags, "K")).toEqual(["11"]);
      expect(tagValues(reply1.tags, "E")).toEqual([root.id]);

      await f.community.replyToThread(f.channelId, reply1, "second reply");
      await settle();
      const reply2 = await rumorWithContent(f, kinds.Comment, "second reply");
      const tagArray = (rumor: Rumor, name: string) => rumor.tags.find((t) => t[0] === name);
      expect(tagArray(reply2, "E")).toEqual(tagArray(reply1, "E"));
      expect(tagArray(reply2, "K")).toEqual(tagArray(reply1, "K"));
      expect(tagArray(reply2, "P")).toEqual(tagArray(reply1, "P"));
      expect(tagValues(reply2.tags, "e")).toEqual([reply1.id]);
    });
  });
});

/** Every Channel edition content this community published for `channelId`, decoded from the control wraps. */
function publishedChannelEditions(fixture: Fixture, channelId: string): Record<string, unknown>[] {
  const keys = (fixture.community as unknown as { keys: { planes: Map<string, PlaneInfo> } }).keys;
  const out: Record<string, unknown>[] = [];
  for (const wrap of fixture.net.published) {
    const info = keys.planes.get(wrap.pubkey);
    if (info?.type !== "control") continue;
    const decoded = decodeWrap(structuredClone(wrap), info.convKey);
    if (!decoded) continue;
    const { rumor } = decoded;
    if (!tagValues(rumor.tags, "vsk").includes(String(VSK.CHANNEL))) continue;
    if (!tagValues(rumor.tags, "eid").includes(channelId)) continue;
    out.push(JSON.parse(rumor.content) as Record<string, unknown>);
  }
  return out;
}

/** Collect every `channels$` emission until the returned `stop` is called. */
function collectChannels(fixture: Fixture): { seen: ChannelView[][]; stop(): void } {
  const seen: ChannelView[][] = [];
  const sub = fixture.community.channels$.subscribe((channels) => seen.push(channels));
  return { seen, stop: () => sub.unsubscribe() };
}

describe("channel view mode (FORUM-03, D-05, D-06, D-23)", () => {
  it("createChannel with view forum writes view forum and channels$ presents it (D-23)", async () => {
    await withFixture(async (f) => {
      const id = await f.community.createChannel("forum room", { view: "forum" });
      await settle();
      const editions = publishedChannelEditions(f, id);
      expect(editions).toHaveLength(1);
      expect(editions[0].view).toBe("forum");
      const channels = await firstValueFrom(f.community.channels$);
      expect(channels.find((c) => c.channel_id === id)?.view).toBe("forum");
    });
  });

  it("createChannel without a view writes no view field and channels$ presents chat", async () => {
    await withFixture(async (f) => {
      const plain = await f.community.createChannel("plain room");
      const explicit = await f.community.createChannel("explicit chat", { view: "chat" });
      await settle();
      for (const id of [plain, explicit]) {
        const editions = publishedChannelEditions(f, id);
        expect(editions).toHaveLength(1);
        expect("view" in editions[0]).toBe(false);
      }
      const channels = await firstValueFrom(f.community.channels$);
      expect(channels.find((c) => c.channel_id === plain)?.view).toBe("chat");
      expect(channels.find((c) => c.channel_id === explicit)?.view).toBe("chat");
    });
  });

  it("createChannel rejects an unknown view before minting a key", async () => {
    await withFixture(async (f) => {
      const keysBefore = Object.keys(f.community.material.channels ?? {}).length;
      const before = f.net.published.length;
      await expect(f.community.createChannel("x", { view: "kanban" as never, private: true })).rejects.toBeInstanceOf(
        TypeError,
      );
      await expect(f.community.createChannel("y", { view: 7 as never })).rejects.toBeInstanceOf(TypeError);
      expect(Object.keys(f.community.material.channels ?? {}).length).toBe(keysBefore);
      expect(f.net.published.length).toBe(before);
    });
  });

  it("an unknown view value presents as chat and survives deleteChannel unchanged (D-05)", async () => {
    await withFixture(async (f) => {
      const cases: [string, unknown][] = [["kanban room", "kanban"], ["numeric room", 7]];
      for (const [name, view] of cases) {
        const id = await f.community.createChannel(name);
        await settle();
        await f.community.admin.publishEdition(VSK.CHANNEL, id, JSON.stringify({ name, private: false, view }));
        await settle();

        const folded = f.community.state$.value.channels.find((c) => c.channel_id === id);
        expect(folded?.view).toEqual(view);
        const shown = (await firstValueFrom(f.community.channels$)).find((c) => c.channel_id === id);
        expect(shown?.view).toBe("chat");

        await f.community.deleteChannel(id);
        await settle();
        const editions = publishedChannelEditions(f, id);
        const tombstone = editions.at(-1)!;
        expect(tombstone.deleted).toBe(true);
        expect(tombstone.view).toEqual(view);
      }
    });
  });

  it("channels$ re-emits when a channel is renamed (D-06)", async () => {
    await withFixture(async (f) => {
      const id = await f.community.createChannel("before");
      await settle();
      const { seen, stop } = collectChannels(f);
      try {
        const count = seen.length;
        await f.community.admin.publishEdition(VSK.CHANNEL, id, JSON.stringify({ name: "after", private: false }));
        await settle();
        expect(seen.length).toBeGreaterThan(count);
        expect(seen.at(-1)!.find((c) => c.channel_id === id)?.name).toBe("after");
      } finally {
        stop();
      }
    });
  });

  it("channels$ re-emits when a channel's view changes (D-06)", async () => {
    await withFixture(async (f) => {
      const id = await f.community.createChannel("flip");
      await settle();
      const { seen, stop } = collectChannels(f);
      try {
        expect(seen.at(-1)!.find((c) => c.channel_id === id)?.view).toBe("chat");
        const count = seen.length;
        await f.community.admin.publishEdition(
          VSK.CHANNEL,
          id,
          JSON.stringify({ name: "flip", private: false, view: "forum" }),
        );
        await settle();
        expect(seen.length).toBeGreaterThan(count);
        expect(seen.at(-1)!.find((c) => c.channel_id === id)?.view).toBe("forum");
      } finally {
        stop();
      }
    });
  });

  it("channels$ stays quiet when an unrelated control edition folds", async () => {
    await withFixture(async (f) => {
      await f.community.createChannel("steady");
      await settle();
      const { seen, stop } = collectChannels(f);
      try {
        const count = seen.length;
        await f.community.editMetadata({ name: "Renamed community" });
        await settle();
        expect(f.community.state$.value.metadata?.name).toBe("Renamed community");
        expect(seen.length).toBe(count);
      } finally {
        stop();
      }
    });
  });
});

/** The Edit rumors this community published so far, with the `k` tag values each carries. */
function publishedEdits(fixture: Fixture): { rumor: Rumor; k: string[] }[] {
  return publishedChannelRumors(fixture)
    .filter((rumor) => rumor.kind === 3302)
    .map((rumor) => ({ rumor, k: tagValues(rumor.tags, "k") }));
}

describe("edit target kinds (FORUM-04, D-07)", () => {
  it("editMessage with a rumor target carries k=9 for a message and k=1111 for a reply", async () => {
    await withFixture(async (f) => {
      await f.community.sendMessage(f.channelId, "a message");
      await settle();
      const message = await rumorWithContent(f, kinds.ChatMessage, "a message");
      await f.community.replyToThread(f.channelId, message, "a reply");
      await settle();
      const reply = await rumorWithContent(f, kinds.Comment, "a reply");

      await f.community.editMessage(f.channelId, message, "edited message");
      await f.community.editMessage(f.channelId, reply, "edited reply");
      await settle();

      const edits = publishedEdits(f);
      expect(edits.find((e) => e.rumor.content === "edited message")?.k).toEqual(["9"]);
      expect(edits.find((e) => e.rumor.content === "edited reply")?.k).toEqual(["1111"]);
      expect(tagValues(edits[0].rumor.tags, "e")).toEqual([message.id]);
    });
  });

  it("editMessage with a bare id looks the kind up in the channel store and omits k when the target is unknown", async () => {
    await withFixture(async (f) => {
      await f.community.sendMessage(f.channelId, "retained");
      await settle();
      const retained = await rumorWithContent(f, kinds.ChatMessage, "retained");

      await f.community.editMessage(f.channelId, retained.id, "by id");
      const unknownId = "ab".repeat(32);
      await f.community.editMessage(f.channelId, unknownId, "unknown target");
      await settle();

      const edits = publishedEdits(f);
      expect(edits.find((e) => e.rumor.content === "by id")?.k).toEqual(["9"]);
      const unknown = edits.find((e) => e.rumor.content === "unknown target")!;
      expect(unknown.k).toEqual([]);
      expect(tagValues(unknown.rumor.tags, "e")).toEqual([unknownId]);
    });
  });

  it("editMessage of a legacy kind 11 root carries k=11 (D-07)", async () => {
    await withFixture(async (f) => {
      await f.community.sendEvent(f.channelId, ForumThreadFactory.create("Legacy title", "legacy root"));
      await settle();
      const root = await rumorWithContent(f, 11, "legacy root");

      await f.community.editMessage(f.channelId, root, "edited by rumor");
      await f.community.editMessage(f.channelId, root.id, "edited by id");
      await settle();

      const edits = publishedEdits(f);
      expect(edits.find((e) => e.rumor.content === "edited by rumor")?.k).toEqual(["11"]);
      expect(edits.find((e) => e.rumor.content === "edited by id")?.k).toEqual(["11"]);
    });
  });

  it("an Edit with no k, a wrong k or k=11 still applies to its target", async () => {
    await withFixture(async (f) => {
      // Receivers never require k: every variant below is chosen, whatever the original's kind is. Each variant edits
      // its own fresh original, so the choice never depends on ordering between edits.
      let n = 0;
      for (const legacyRoot of [false, true]) {
        for (const k of [undefined, "1111", "11", "9", "not-a-number"]) {
          const body = `original ${n++}`;
          if (legacyRoot) await f.community.sendEvent(f.channelId, ForumThreadFactory.create("Legacy title", body));
          else await f.community.sendMessage(f.channelId, body);
          await settle();
          const original = await rumorWithContent(f, legacyRoot ? 11 : kinds.ChatMessage, body);

          const content = `edited ${body} k=${k}`;
          const template = await EditFactory.create(original.id, content);
          if (k !== undefined) template.tags.push(["k", k]);
          await f.community.sendEvent(f.channelId, template);
          await settle();

          const edits = await f.community.channelStore(f.channelId).getTimeline([{ kinds: [3302] }]);
          const chosen = newestValidEdit(original, edits, { channelId: f.channelId });
          expect(chosen?.content).toBe(content);
        }
      }
    });
  });
});

describe("channel and epoch binding (CORD-03 §3)", () => {
  it("a received rumor whose channel or epoch tag does not strict-equal its plane is dropped (CORD-03 §3)", async () => {
    await withFixture(async (f) => {
      const foreign = new PrivateKeySigner(generateSecretKey());
      const keys = (f.community as unknown as { keys: ConcordKeys }).keys;
      const epoch = f.community.material.root_epoch;
      const otherChannel = "ab".repeat(32);
      const offer = async (content: string, tags: (tags: string[][]) => string[][]): Promise<void> => {
        const bound = await bindToChannel(f.channelId, epoch)(await ChatMessageFactory.create(content));
        const rumor = { ...bound, tags: tags(bound.tags) };
        const { wrap } = await wrapForTarget(keys, { plane: "channel", channelId: f.channelId }, foreign, rumor, {});
        await (f.community as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(wrap);
      };
      const swap = (name: string, value: string | undefined) => (tags: string[][]): string[][] =>
        tags.filter((tag) => tag[0] !== name).concat(value === undefined ? [] : [[name, value]]);

      // The bound rumor is the control: the wrap is genuine, so only the binding can explain a drop.
      await offer("bound to this channel and epoch", (tags) => tags);
      await offer("names another channel", swap("channel", otherChannel));
      await offer("names the next epoch", swap("epoch", String(epoch + 1)));
      await offer("pads the epoch", swap("epoch", `0${epoch}`));
      await offer("has no channel tag", swap("channel", undefined));
      await offer("has no epoch tag", swap("epoch", undefined));
      await settle();

      const kept = await f.community.channelStore(f.channelId).getTimeline([{ kinds: [kinds.ChatMessage] }]);
      expect(kept.map((rumor) => rumor.content)).toEqual(["bound to this channel and epoch"]);
    });
  });
});
