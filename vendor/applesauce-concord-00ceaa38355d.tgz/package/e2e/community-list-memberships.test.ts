// The aggregate Community List read surface (LIST-07, D-13): `memberships$` and `memberships()` report the live
// memberships, tombstones, how much of the relay copy backs them, whether a held fragment is still locked and whether
// a save is held. They add no write API (D-14).

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { firstValueFrom } from "rxjs";
import { filter } from "rxjs";
import { PrivateKeySigner } from "applesauce-signers";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { buildInviteBundle } from "../src/helpers/invite-bundle.ts";
import { COMMUNITY_LIST_KIND } from "../src/helpers/community-list.ts";
import { COMMUNITY_LIST_FRAGMENT_KIND } from "../src/helpers/community-list-wire.ts";
import { fakeRelayPool } from "../src/client/__tests__/test-utils.ts";
import { memoryStorage } from "../src/client/storage.ts";
import type { ConcordMemberships } from "../src/client/community-list-memberships.ts";
import {
  entriesOf,
  fragment,
  fragmentOf,
  harness,
  idsOf,
  listPublishes,
  membership,
  settle,
  settleFlush,
  statusOf,
  until,
  vault,
} from "../src/client/__tests__/community-list-client-fixtures.ts";

describe("ConcordClient memberships (LIST-07, D-13)", () => {
  it("memberships() before start() is empty and unknown, and memberships$ emits that value (D-13)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool().pool, memoryStorage());
      const empty: ConcordMemberships = {
        entries: [],
        tombstones: [],
        knowledge: "unknown",
        locked: false,
        pending: false,
      };
      expect(client.memberships()).toEqual(empty);
      const seen: ConcordMemberships[] = [];
      const subscription = client.memberships$.subscribe((value) => seen.push(value));
      expect(seen).toEqual([empty]);
      subscription.unsubscribe();
    } finally {
      await h.teardown();
    }
  });

  it("memberships$ completes on dispose(), and a later subscription gets the current value, then completes (IN-03)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool().pool, memoryStorage());
      let completed = false;
      const seen: ConcordMemberships[] = [];
      client.memberships$.subscribe({ next: (value) => seen.push(value), complete: () => (completed = true) });
      expect(seen).toHaveLength(1);
      client.dispose();
      expect(completed).toBe(true);
      const late: Array<ConcordMemberships | "complete"> = [];
      client.memberships$.subscribe({ next: (value) => late.push(value), complete: () => late.push("complete") });
      expect(late).toEqual([client.memberships(), "complete"]);
    } finally {
      await h.teardown();
    }
  });

  it("memberships() reports live entries, tombstones, knowledge and pending matching communityListStatus$ (D-13)", async () => {
    const { signer, material, events, storage } = await vault();
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await client.start();
      await settle();
      const status = await statusOf(client);
      const memberships = client.memberships();
      expect(idsOf(memberships)).toEqual([material.community_id]);
      expect(memberships.tombstones).toEqual([]);
      expect(memberships.knowledge).toBe(status.knowledge);
      expect(memberships.pending).toBe(status.pending);
      expect(memberships.locked).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("memberships$ emits again on a join, a leave and another device's fragment (D-13)", async () => {
    const { signer, pubkey, material, events, storage } = await vault();
    const other = await membership(pubkey, "Other");
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await client.start();
      await settle();
      const seen: ConcordMemberships[] = [];
      const subscription = client.memberships$.subscribe((value) => seen.push(value));
      const latest = (): ConcordMemberships => seen[seen.length - 1];
      expect(idsOf(latest())).toEqual([material.community_id]);

      const created = await client.createNewCommunity("B", "joined", ["wss://fake"]);
      await settle();
      expect(idsOf(latest())).toContain(created.communityId);
      expect(idsOf(latest())).toContain(material.community_id);

      await client.leave(created.communityId);
      await settle();
      expect(idsOf(latest())).not.toContain(created.communityId);
      expect(latest().tombstones.map((tombstone) => tombstone.community_id)).toContain(created.communityId);

      // Another device's newer fragment 0 adds a membership; autoUnlock decrypts it and the document adopts it.
      h.stores[0].add(
        await fragment(
          signer,
          0,
          { frags: 2, entries: entriesOf([material, other]), tombstones: [] },
          Math.floor(Date.now() / 1000) + 60, // newer than the fragment this client published for the join
        ),
      );
      await until(() => idsOf(latest()).includes(other.community_id));
      expect(latest().locked).toBe(false);
      subscription.unsubscribe();
    } finally {
      await h.teardown();
    }
  });

  it("memberships().locked stays true while a held fragment is undecrypted and turns false after unlockCommunityListFragments() (D-13)", async () => {
    const { signer, events, storage } = await vault();
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: false });
      const seen: boolean[] = [];
      client.memberships$.subscribe((value) => seen.push(value.locked));
      await client.start();
      await settle();
      expect(client.memberships().locked).toBe(true);
      expect(seen[seen.length - 1]).toBe(true);
      await client.unlockCommunityListFragments();
      expect(client.memberships().locked).toBe(false);
      expect(seen[seen.length - 1]).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("memberships() returns copies, so changing them never changes the client's list (D-13)", async () => {
    const { signer, material, events, storage } = await vault();
    const h = harness();
    try {
      const client = h.client(signer, fakeRelayPool({ events }).pool, storage, { autoUnlock: true });
      await client.start();
      await settle();
      const first = client.memberships();
      const before = JSON.stringify(first);
      expect(first.entries).toHaveLength(1);
      (first.entries as unknown as Array<{ community_id: string }>)[0].community_id = "tampered";
      (first.entries as unknown[]).push({ community_id: "extra" });
      (first.tombstones as unknown[]).push({ community_id: "ghost", left_at: 1 });
      const second = client.memberships();
      expect(JSON.stringify(second)).toBe(before);
      expect(idsOf(second)).toEqual([material.community_id]);
      expect(second.entries[0]).not.toBe(first.entries[0]);
    } finally {
      await h.teardown();
    }
  });

  it("an offline start reports unknown knowledge and a pending join through memberships() (D-13)", async () => {
    const { signer, storage } = await vault({ relayVault: false });
    const h = harness();
    try {
      const net = fakeRelayPool({ online: false, events: [] });
      const client = h.client(signer, net.pool, storage, { autoUnlock: true });
      await client.start();
      const created = await client.createNewCommunity("B", "joined while offline", ["wss://fake"]);
      await settleFlush();
      const memberships = client.memberships();
      expect(idsOf(memberships)).toContain(created.communityId);
      expect(memberships.knowledge).toBe("unknown");
      expect(memberships.pending).toBe(true);
      expect(await statusOf(client)).toEqual({ knowledge: "unknown", pending: true });
    } finally {
      await h.teardown();
    }
  });
});

describe("legacy Community List surfaces (D-14, D-15)", () => {
  it("the client publishes only kind-33302 fragments, never a kind-13302 list (D-15)", async () => {
    const { signer, pubkey, events, storage } = await vault();
    const joined = await membership(pubkey, "Joined");
    const net = fakeRelayPool({ events });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, storage, { autoUnlock: true, autoSaveCommunityList: true });
      await client.start();
      await settle();
      const created = await client.createNewCommunity("B", "created", ["wss://fake"]);
      await client.joinByBundle(buildInviteBundle(joined, { name: "Joined" }));
      await settleFlush();
      await client.leave(created.communityId);
      await client.saveCommunityList();
      await settleFlush();
      const lists = net.published.filter((event) =>
        event.kind === COMMUNITY_LIST_FRAGMENT_KIND || event.kind === COMMUNITY_LIST_KIND
      );
      expect(lists.length).toBeGreaterThan(0);
      expect(lists.every((event) => event.kind === COMMUNITY_LIST_FRAGMENT_KIND)).toBe(true);
      expect(net.published.some((event) => event.kind === COMMUNITY_LIST_KIND)).toBe(false);
    } finally {
      await h.teardown();
    }
  });

  it("a legacy kind-13302 list is still read and imported through communityList$ (D-15)", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const a = await membership(pubkey, "A");
    const content = await signer.nip44!.encrypt(pubkey, JSON.stringify({ entries: entriesOf([a]), tombstones: [] }));
    const legacy = await signer.signEvent({ kind: COMMUNITY_LIST_KIND, content, tags: [], created_at: 1 });
    const net = fakeRelayPool({ events: [legacy] });
    const h = harness();
    try {
      const client = h.client(signer, net.pool, memoryStorage(), { autoUnlock: true });
      await client.start();
      await settle();
      const cast = await firstValueFrom(client.communityList$.pipe(filter((cast) => cast?.id === legacy.id)));
      expect(cast?.unlocked).toBe(true);
      expect(idsOf(client.memberships())).toEqual([a.community_id]);

      const c = await membership(pubkey, "C");
      await client.joinByBundle(buildInviteBundle(c, { name: "C" }));
      await settleFlush();
      const lists = listPublishes(net.published);
      expect(lists.length).toBeGreaterThan(0);
      expect(idsOf(await fragmentOf(signer, lists[lists.length - 1]))).toEqual(
        expect.arrayContaining([a.community_id, c.community_id]),
      );
      expect(net.published.some((event) => event.kind === COMMUNITY_LIST_KIND)).toBe(false);
    } finally {
      await h.teardown();
    }
  });
});
