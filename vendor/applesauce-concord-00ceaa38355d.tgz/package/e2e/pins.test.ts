/// <reference lib="esnext.disposable" />
// Pin display end to end on a community over a fake relay pool: Edits, author self-deletion, expiry and the bounded
// verification cache (CORD-04 §7, CORD-08). Fixtures here are reused by the pin upkeep tests.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { EventStore } from "applesauce-core";
import { ChatMessageFactory } from "applesauce-common/factories";
import { getEventHash, type NostrEvent, type Rumor } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { unixNow } from "applesauce-core/helpers/time";
import { type ISigner, PrivateKeySigner } from "applesauce-signers";
import { FakeTime } from "@std/testing/time";
import { stub } from "@std/testing/mock";
import type { Subscription } from "rxjs";

import { banlistLocator, channelGroupKey, grantLocator, pinsLocator } from "../src/helpers/crypto.ts";
import { decodeWrap } from "../src/helpers/gift-wrap.ts";
import { type ConcordKeys, type PlaneInfo, wrapForTarget } from "../src/helpers/keys.ts";
import { computeEditionHash } from "../src/helpers/editions.ts";
import { classifyEditionLineage } from "../src/helpers/edition-lineage.ts";
import { sealRumor } from "../src/operations/gift-wrap.ts";
import {
  createPinProof,
  encodePinList,
  type PinEntry,
  readPinList,
  type VerifiedPin,
  verifyPinEntry,
} from "../src/helpers/pins.ts";
import { newestValidEdit } from "../src/helpers/edit.ts";
import { rumorExpiration } from "../src/helpers/expiration.ts";
import { EditionFactory } from "../src/factories/control.ts";
import { createLegacyCommunity } from "../src/helpers/__tests__/test-utils.ts";
import { PERM, VSK } from "../src/types.ts";
import { ConcordCommunity, type ConcordCommunityOptions } from "../src/client/community.ts";
import {
  CommunityPins,
  type CommunityPinsHost,
  PinListNotReadyError,
  PinVerificationCache,
} from "../src/client/pins.ts";
import type { ConcordDiagnostic } from "../src/client/diagnostics.ts";
import { DutyScope } from "../src/client/lifecycle.ts";
import { ConcordClient } from "../src/client/client.ts";
import { memoryStorage } from "../src/client/storage.ts";
import { type FakeRelayPool, fakeRelayPool, Gate, ManualClock } from "../src/client/__tests__/test-utils.ts";

const settle = () => new Promise((r) => setTimeout(r, 200));

/** An owner's community on a fake pool, started with its genesis published and settled. */
export async function ownerCommunity(
  wrapSigner: (signer: PrivateKeySigner) => ISigner = (s) => s,
  options: Partial<ConcordCommunityOptions> = {},
): Promise<{
  community: ConcordCommunity;
  net: FakeRelayPool;
  store: EventStore;
  signer: PrivateKeySigner;
  pubkey: string;
  generalId: string;
}> {
  const signer = new PrivateKeySigner(generateSecretKey());
  const pubkey = await signer.getPublicKey();
  const net = fakeRelayPool();
  const genesis = await createLegacyCommunity({ ownerPubkey: pubkey, name: "Test", relays: ["wss://fake"] });
  const store = new EventStore();
  const community = new ConcordCommunity({
    storage: memoryStorage(),
    material: genesis.material,
    signer: wrapSigner(signer),
    pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    ...options,
  });
  await community.start();
  for (const rumor of genesis.controlRumors) {
    await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
  }
  for (const rumor of genesis.guestbookRumors) await community.publishToPlane({ plane: "guestbook" }, rumor, {});
  await settle();
  return { community, net, store, signer, pubkey, generalId: genesis.generalChannelId };
}

/** The plane descriptor a published wrap addresses, read through the engine's private keys. */
function planeOf(community: ConcordCommunity, wrap: NostrEvent): PlaneInfo | undefined {
  const keys = (community as unknown as { keys: { planes: Map<string, PlaneInfo> } }).keys;
  return keys.planes.get(wrap.pubkey);
}

/** A disclosure proof for a message the community published, recovered from its wrap. */
export function proofFor(
  community: ConcordCommunity,
  net: FakeRelayPool,
  channelId: string,
  rumorId: string,
): PinEntry {
  for (const wrap of net.published) {
    const info = planeOf(community, wrap);
    if (info?.type !== "channel" || info.channelId !== channelId) continue;
    const decoded = decodeWrap(structuredClone(wrap), info.convKey);
    if (decoded?.seal && getEventHash(decoded.rumor) === rumorId) return createPinProof(decoded.seal, info.convKey);
  }
  throw new Error("no published wrap carries that message");
}

/** The newest retained rumor of a kind in a channel store. */
export async function newestOfKind(community: ConcordCommunity, channelId: string, kind: number): Promise<Rumor> {
  const timeline = await community.channelStore(channelId).getTimeline([{ kinds: [kind] }]);
  const newest = timeline[0];
  if (!newest) throw new Error(`no kind ${kind} rumor in the channel`);
  return newest;
}

/** The retained Edit rumor with the given content; Edits sent within one second have no reliable send order. */
async function editByContent(community: ConcordCommunity, channelId: string, content: string): Promise<Rumor> {
  const timeline = await community.channelStore(channelId).getTimeline([{ kinds: [3302] }]);
  const found = timeline.find((rumor) => rumor.content === content);
  if (!found) throw new Error(`no Edit with content ${content}`);
  return found;
}

/** The Pin List edition rumors for a channel this community has published so far, oldest first. */
export function pinEditionRumors(community: ConcordCommunity, net: FakeRelayPool, channelId: string): Rumor[] {
  const eid = pinsLocator(hexToBytes(community.communityId), channelId);
  const editions: Rumor[] = [];
  for (const wrap of net.published) {
    const info = planeOf(community, wrap);
    if (info?.type !== "control") continue;
    const rumor = decodeWrap(structuredClone(wrap), info.convKey)?.rumor;
    const tag = (name: string) => rumor?.tags.find((t) => t[0] === name)?.[1];
    if (rumor?.kind === 3308 && tag("vsk") === String(VSK.PINS) && tag("eid")?.toLowerCase() === eid) {
      editions.push(rumor);
    }
  }
  return editions;
}

/** How many Pin List editions for a channel this community has published so far. */
export function pinEditions(community: ConcordCommunity, net: FakeRelayPool, channelId: string): number {
  return pinEditionRumors(community, net, channelId).length;
}

/** Send a message and return its rumor id. */
function say(community: ConcordCommunity, channelId: string, text: string): Promise<string> {
  return community.sendEvent(channelId, ChatMessageFactory.create(text));
}

/** Latest emission of a pins$ subscription, kept in step as the test acts. */
function watch(
  community: ConcordCommunity,
  channelId: string,
  options?: { showExpired?: boolean; showBanned?: boolean },
) {
  const seen: VerifiedPin[][] = [];
  const sub: Subscription = community.pins$(channelId, options).subscribe((pins) => seen.push(pins));
  return { seen, sub };
}

async function finish(community: ConcordCommunity, store: EventStore, sub?: Subscription): Promise<void> {
  sub?.unsubscribe();
  community.dispose();
  store.dispose();
  await settle();
}

/**
 * A message edited twice with a Pin List entry per Edit. Edits sent within one second have no reliable send order, so
 * the newer one is ranked by the library's own chooser rather than by when it was sent.
 */
async function twiceEdited(
  community: ConcordCommunity,
  net: FakeRelayPool,
  channelId: string,
): Promise<{ id: string; newer: Rumor; older: Rumor; withNewer: PinEntry; withOlder: PinEntry }> {
  const id = await say(community, channelId, "original text");
  await community.editMessage(channelId, id, "edit one");
  await community.editMessage(channelId, id, "edit two");
  await settle();
  const original = (await community.channelStore(channelId).getTimeline([{ kinds: [9] }])).find((r) => r.id === id)!;
  const drafted = [
    await editByContent(community, channelId, "edit one"),
    await editByContent(community, channelId, "edit two"),
  ];
  const newest = newestValidEdit(original, drafted, { channelId })!;
  const newer = drafted.find((rumor) => getEventHash(rumor) === newest.id)!;
  const older = drafted.find((rumor) => rumor !== newer)!;
  const base = proofFor(community, net, channelId, id);
  const copy = (edit: Rumor): PinEntry => ({ ...base, edit: proofFor(community, net, channelId, getEventHash(edit)) });
  return { id, newer, older, withNewer: copy(newer), withOlder: copy(older) };
}

describe("ConcordCommunity pins$", () => {
  it("pins$ shows the newest local Edit of a pinned message as edited text", async () => {
    // Upkeep is off so the Pin List is not refreshed: this test is about the local projection of an unbundled Edit.
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "first draft");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await settle();
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.[0].text).toBe("first draft");
      expect(watching.seen.at(-1)?.[0].edited).toBe(false);
      await community.editMessage(generalId, id, "second draft");
      await settle();
      const pin = watching.seen.at(-1)![0];
      expect(pin.text).toBe("second draft");
      expect(pin.edited).toBe(true);
      expect(pin.behind).toBe(true);
      // The republishable bundle is still the original proof, never the unproven local Edit.
      expect(pin.entry.edit).toBeUndefined();
    } finally {
      await finish(community, store, sub);
    }
  });

  it("pins$ hides a pin as soon as its author deletes the message, before any new Pin List edition", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "regrettable");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await settle();
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)).toHaveLength(1);
      const editions = pinEditions(community, net, generalId);
      expect(editions).toBeGreaterThan(1);
      // Count the editions published at the moment the projection first hides the pin.
      let editionsWhenHidden: number | undefined;
      const hiding = community.pins$(generalId).subscribe((pins) => {
        if (pins.length === 0) editionsWhenHidden ??= pinEditions(community, net, generalId);
      });
      const original = await newestOfKind(community, generalId, 9);
      await community.deleteMessage(generalId, original);
      await settle();
      hiding.unsubscribe();
      expect(watching.seen.at(-1)).toEqual([]);
      expect(await community.pins(generalId)).toEqual([]);
      expect(editionsWhenHidden).toBe(editions);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("pinning a message that carries an expiration tag is accepted and pins$ exposes expiresAt", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      await community.setMessageExpiration(3600);
      await settle();
      const id = await say(community, generalId, "disappearing");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await settle();
      const watching = watch(community, generalId);
      sub = watching.sub;
      const pin = watching.seen.at(-1)![0];
      expect(pin.text).toBe("disappearing");
      const expiresAt = pin.expiresAt!;
      expect(expiresAt).toBeGreaterThan(Date.now() / 1000);
      // created_at has whole-second resolution, so the expiry may round up past the fractional clock.
      expect(expiresAt).toBeLessThanOrEqual(Math.ceil(Date.now() / 1000) + 3600);
    } finally {
      await finish(community, store, sub);
    }
  });

  // Non-vacuity: return the cached VerifiedPin itself from PinVerificationCache.verify. The mutated rumor and entry of
  // the first read then reach the second read and its pristine-value assertions fail.
  it("pins() hands out objects an app may mutate without changing later reads (WR-04)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      const id = await say(community, generalId, "pristine");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await settle();
      const [first] = await community.pins(generalId);
      expect(first.text).toBe("pristine");
      first.rumor.content = "annotated by the app";
      first.rumor.tags.push(["t", "app"]);
      first.entry.wrap = "app hint";
      const [second] = await community.pins(generalId);
      expect(second.rumor.content).toBe("pristine");
      expect(second.text).toBe("pristine");
      expect(second.rumor.tags.some((tag) => tag[0] === "t")).toBe(false);
      expect(second.entry.wrap).toBeUndefined();
    } finally {
      await finish(community, store);
    }
  });

  it("pins() applies the same rules as pins$", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "plain");
      const other = await say(community, generalId, "other");
      await community.setPins(generalId, [
        proofFor(community, net, generalId, id),
        proofFor(community, net, generalId, other),
      ]);
      await community.editMessage(generalId, id, "plain, edited");
      await settle();
      const watching = watch(community, generalId);
      sub = watching.sub;
      const first = watching.seen.at(-1)!;
      const now = await community.pins(generalId);
      const view = (pins: VerifiedPin[]) =>
        pins.map((p) => [p.rumor.id, p.edit?.id, p.text, p.edited, p.behind, p.expiresAt]);
      expect(view(now)).toEqual(view(first));
      expect(now.map((p) => p.text).sort()).toEqual(["other", "plain, edited"]);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("pins$ never shows an Edit its author deleted and falls back to the original text (D-31)", async () => {
    // Non-vacuity: drop `deletions` from the projection and the retracted Edit text stays visible.
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "original");
      await community.editMessage(generalId, id, "bundled edit");
      await settle();
      const bundled = await newestOfKind(community, generalId, 3302);
      await community.setPins(generalId, [{
        ...proofFor(community, net, generalId, id),
        edit: proofFor(community, net, generalId, getEventHash(bundled)),
      }]);
      await settle();
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)![0].text).toBe("bundled edit");
      expect(watching.seen.at(-1)![0].behind).toBe(false);
      await community.deleteMessage(generalId, bundled);
      await settle();
      const afterDelete = watching.seen.at(-1)![0];
      expect(afterDelete.text).toBe("original");
      expect(afterDelete.edited).toBe(false);
      expect(afterDelete.behind).toBe(true);
      // A later local Edit is shown until its author deletes it too.
      await community.editMessage(generalId, id, "second edit");
      await settle();
      expect(watching.seen.at(-1)![0].text).toBe("second edit");
      const second = await editByContent(community, generalId, "second edit");
      await community.deleteMessage(generalId, second);
      await settle();
      expect(watching.seen.at(-1)![0].text).toBe("original");
      expect(watching.seen.at(-1)![0].edited).toBe(false);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("pins$ shows a message another client listed twice once, from the copy with the newest bundled Edit (D-32)", async () => {
    // Non-vacuity: let the last copy win, as the old Map did, and pins$ shows the older bundled Edit (CR-01).
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    let sub: Subscription | undefined;
    try {
      const { newer, withNewer, withOlder } = await twiceEdited(community, net, generalId);
      const otherId = await say(community, generalId, "other");
      const other = proofFor(community, net, generalId, otherId);
      // Another client publishes the list directly, bypassing setPins.
      await community.admin.publishEdition(
        VSK.PINS,
        pinsLocator(hexToBytes(community.communityId), generalId),
        encodePinList([withNewer, other, withOlder]),
      );
      await settle();
      const watching = watch(community, generalId);
      sub = watching.sub;
      const pins = watching.seen.at(-1)!;
      expect(pins).toHaveLength(2);
      expect(pins[0].text).toBe(newer.content);
      expect(pins[0].behind).toBe(false);
      expect(verifyPinEntry(pins[0].entry, generalId)?.edit?.id).toBe(getEventHash(newer));
      expect(pins[1].text).toBe("other");
    } finally {
      await finish(community, store, sub);
    }
  });
});

describe("PinVerificationCache", () => {
  it("the pin verification cache verifies an entry once per channel and stays bounded", () => {
    const calls: string[] = [];
    const cache = new PinVerificationCache(2, (entry, channelId) => {
      calls.push(`${channelId}:${entry.keys}`);
      return undefined;
    });
    const entry = (n: number) => ({ keys: String(n), seal: {} }) as unknown as PinEntry;
    cache.verify(entry(1), "a");
    cache.verify(entry(1), "a");
    expect(calls).toHaveLength(1);
    cache.verify(entry(1), "b");
    expect(calls).toHaveLength(2);
    // Two newer keys push entry 1 for channel "a" out of the two-entry bound.
    cache.verify(entry(2), "a");
    cache.verify(entry(1), "a");
    expect(calls).toHaveLength(4);
    cache.clear();
    cache.verify(entry(1), "a");
    expect(calls).toHaveLength(5);
  });

  // Non-vacuity: return the cached VerifiedPin itself from PinVerificationCache.verify (no clone). The caller's
  // mutation then reaches the second result and the pristine-value assertions fail.
  it("a caller mutating a cached verification never changes a later result (WR-04)", () => {
    const verified = {
      rumor: { id: "aa", pubkey: "bb", kind: 9, content: "original", tags: [["channel", "c"]], created_at: 1 },
      entry: { keys: "1", seal: { id: "cc" } },
      edited: false,
      behind: false,
      text: "original",
    } as unknown as VerifiedPin;
    const cache = new PinVerificationCache(4, () => verified);
    const entry = { keys: "1", seal: { id: "cc" } } as unknown as PinEntry;
    const first = cache.verify(entry, "c")!;
    first.rumor.content = "mutated";
    first.rumor.tags.push(["t", "annotated"]);
    first.entry.wrap = "hint";
    first.entry.seal.id = "dd";
    first.text = "mutated";
    const second = cache.verify(entry, "c")!;
    expect(second.rumor.content).toBe("original");
    expect(second.rumor.tags).toEqual([["channel", "c"]]);
    expect(second.entry.wrap).toBeUndefined();
    expect(second.entry.seal.id).toBe("cc");
    expect(second.text).toBe("original");
    // The verifier's own object is not retained by reference either.
    verified.rumor.content = "changed by the verifier";
    expect(cache.verify(entry, "c")!.rumor.content).toBe("original");
  });
});

/** The rejection of a promise, or undefined when it resolved. */
async function rejection(promise: Promise<unknown>): Promise<unknown> {
  try {
    await promise;
  } catch (error) {
    return error;
  }
  return undefined;
}

/**
 * Publish a hand-built Channel edition (version 1, public unless `isPrivate`) for a fresh id and let the fold see it.
 * No channel key is minted, so a private one is a channel whose key this engine does not hold.
 */
async function addFreshChannel(community: ConcordCommunity, isPrivate = false): Promise<string> {
  const id = bytesToHex(generateSecretKey());
  const rumor = await EditionFactory.create({
    vsk: VSK.CHANNEL,
    eid: id,
    version: 1,
    content: JSON.stringify({ name: "fresh", private: isPrivate }),
  });
  await community.publishToPlane({ plane: "control" }, rumor, { plaintext: true });
  await settle();
  return id;
}

/**
 * Deliver a version 1 Pin List edition for `eid` sealed by a fresh non-owner key, as a member who can wrap to the
 * Control Plane could. Returns the forger's pubkey.
 */
async function injectForeignPinEdition(
  community: ConcordCommunity,
  eid: string,
  tags: string[][] | ((author: string) => string[][]),
): Promise<string> {
  const forger = new PrivateKeySigner(generateSecretKey());
  const author = await forger.getPublicKey();
  const rumor = await EditionFactory.create({ vsk: VSK.PINS, eid, version: 1, content: encodePinList([]) });
  rumor.tags.push(...(typeof tags === "function" ? tags(author) : tags));
  const keys = (community as unknown as { keys: ConcordKeys }).keys;
  const { wrap } = await wrapForTarget(keys, { plane: "control" }, forger, rumor, { plaintext: true });
  await (community as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(wrap);
  await settle();
  return author;
}

/**
 * A fresh channel whose only Pin List edition is version 1 by a curator the owner granted a `PIN_MESSAGES` Role, with
 * a correct `vac` citation, as when the curator created the channel or pinned first. The edition is the head.
 */
async function curatedChannel(community: ConcordCommunity): Promise<{
  id: string;
  eid: string;
  curator: string;
  roleId: string;
  curatorHash: string;
}> {
  const id = await addFreshChannel(community);
  const cid = hexToBytes(community.communityId);
  const eid = pinsLocator(cid, id);
  const signer = new PrivateKeySigner(generateSecretKey());
  const curator = await signer.getPublicKey();
  const roleId = await community.admin.createRole("curator", 2, PERM.PIN_MESSAGES);
  await community.admin.grantRoles(curator, [roleId]);
  await settle();
  const grantEid = grantLocator(cid, curator);
  const grant = community.state$.value.controlVerification!.heads.get(grantEid)!;
  const content = encodePinList([]);
  const rumor = await EditionFactory.create({
    vsk: VSK.PINS,
    eid,
    version: 1,
    content,
    vac: [grantEid, String(grant.version), grant.hash],
  });
  const keys = (community as unknown as { keys: ConcordKeys }).keys;
  const { wrap } = await wrapForTarget(keys, { plane: "control" }, signer, rumor, { plaintext: true });
  await (community as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(wrap);
  await settle();
  expect(community.state$.value.controlVerification!.heads.get(eid)?.edition.author).toBe(curator);
  return { id, eid, curator, roleId, curatorHash: computeEditionHash({ vsk: VSK.PINS, eid, version: 1, content }) };
}

/**
 * The owner rewrites a channel whose only Pin List edition is a curator's, after banning or demoting that curator.
 */
async function writeOverRemovedCurator(removal: "ban" | "demotion"): Promise<void> {
  // Non-vacuity: before D-34 the curator's well-formed citation kept blocking every writer, the owner included,
  // with unverified-edition (review iteration 3, WR-01).
  const { community, net, store } = await ownerCommunity();
  let sub: Subscription | undefined;
  try {
    const { id, eid, curator, roleId, curatorHash } = await curatedChannel(community);
    if (removal === "ban") {
      await community.admin.publishEdition(
        VSK.BANLIST,
        banlistLocator(hexToBytes(community.communityId)),
        JSON.stringify([curator]),
      );
    } else {
      await community.admin.grantRoles(curator, []);
    }
    await settle();
    expect(community.state$.value.controlVerification!.heads.has(eid)).toBe(false);
    const messageId = await say(community, id, "rewritten by the owner");
    await community.setPins(id, [proofFor(community, net, id, messageId)]);
    await settle();
    const editions = pinEditionRumors(community, net, id);
    expect(editions).toHaveLength(1);
    // CORD-04 §1: the version climbs past the rejected edition and chains to it, so it cannot tie with it.
    expect(editions[0].tags.find((t) => t[0] === "ev")?.[1]).toBe("2");
    expect(editions[0].tags.find((t) => t[0] === "ep")?.[1]).toBe(curatorHash);
    const head = community.state$.value.controlVerification!.heads.get(eid)!;
    expect(head.edition.author).toBe(community.material.owner);
    const watching = watch(community, id);
    sub = watching.sub;
    expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["rewritten by the owner"]);
    if (removal === "demotion") {
      // Restoring the curator never brings the curator's stale list back over the owner's.
      await community.admin.grantRoles(curator, [roleId]);
      await settle();
      expect(community.state$.value.controlVerification!.heads.get(eid)?.hash).toBe(head.hash);
    }
  } finally {
    await finish(community, store, sub);
  }
}

/**
 * An app republishes `pins()` entries after the author deleted the pinned message's bundled Edit; the published list
 * must carry the entry without that Edit's proof (D-31). Upkeep is off so only `setPins` can strip it.
 */
async function republishRetracted(isPrivate: boolean): Promise<void> {
  // Non-vacuity: encode the kept copy as given and the head still carries the retracted Edit's seal and keys.
  const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
  try {
    const id = isPrivate ? await community.createChannel("members", { private: true }) : generalId;
    await settle();
    const messageId = await say(community, id, "original words");
    await community.editMessage(id, messageId, "retracted words");
    await settle();
    const bundled = await newestOfKind(community, id, 3302);
    const base = proofFor(community, net, id, messageId);
    const editProof = proofFor(community, net, id, getEventHash(bundled));
    await community.setPins(id, [{ ...base, edit: editProof }]);
    await settle();
    await community.deleteMessage(id, bundled);
    await settle();
    const pins = await community.pins(id);
    expect(pins[0].behind).toBe(true);
    expect(pins[0].entry.edit).toBeDefined();
    await community.setPins(id, pins.map((pin) => pin.entry));
    await settle();
    const list = community.pinList(id);
    if (!list.available) throw new Error("the republished Pin List is not readable");
    expect(list.entries).toHaveLength(1);
    expect(list.entries[0].edit).toBeUndefined();
    expect(list.entries[0].seal).toEqual(base.seal);
    expect(list.entries[0].keys).toBe(base.keys);
    const head = pinEditionRumors(community, net, id).at(-1)!;
    expect(head.content).not.toContain(editProof.seal.id);
    if (isPrivate) expect(JSON.parse(head.content).sealed).toBeDefined();
    expect((await community.pins(id))[0].text).toBe("original words");
  } finally {
    await finish(community, store);
  }
}

describe("ConcordCommunity setPins bootstrap", () => {
  it("setPins drops a bundled Edit its author deleted instead of republishing it (D-31)", async () => {
    await republishRetracted(false);
  });

  it("setPins drops a bundled Edit its author deleted from a private channel's sealed list (D-31)", async () => {
    await republishRetracted(true);
  });

  it("setPins rejects with PinListNotReadyError not-synced before the community sync is live", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const pubkey = await signer.getPublicKey();
    const net = fakeRelayPool();
    const genesis = await createLegacyCommunity({ ownerPubkey: pubkey, name: "Test", relays: ["wss://fake"] });
    const store = new EventStore();
    const community = new ConcordCommunity({
      storage: memoryStorage(),
      material: genesis.material,
      signer,
      pubkey,
      pool: net.pool,
      eventStore: store,
      relays: ["wss://fake"],
    });
    try {
      const error = await rejection(community.setPins(genesis.generalChannelId, []));
      expect(error).toBeInstanceOf(PinListNotReadyError);
      expect((error as PinListNotReadyError).reason).toBe("not-synced");
      expect((error as PinListNotReadyError).channelId).toBe(genesis.generalChannelId);
      expect(net.published).toHaveLength(0);
    } finally {
      await finish(community, store);
    }
  });

  it("setPins publishes Pin List version 1 for a live channel with no head", async () => {
    const { community, net, store } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await addFreshChannel(community);
      expect(pinEditions(community, net, id)).toBe(0);
      const messageId = await say(community, id, "first pin ever");
      await community.setPins(id, [proofFor(community, net, id, messageId)]);
      await settle();
      const editions = pinEditionRumors(community, net, id);
      expect(editions).toHaveLength(1);
      expect(editions[0].tags.find((t) => t[0] === "ev")?.[1]).toBe("1");
      expect(editions[0].tags.some((t) => t[0] === "ep")).toBe(false);
      const watching = watch(community, id);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["first pin ever"]);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("setPins publishes Pin List version 1 over retained editions that can never verify (D-33)", async () => {
    // Non-vacuity: before D-33 any retained edition naming the coordinate blocked the first pin with not-synced forever.
    const { community, net, store } = await ownerCommunity();
    try {
      const id = await addFreshChannel(community);
      const eid = pinsLocator(hexToBytes(community.communityId), id);
      // A member injects bogus Pin List editions: one with no `vac` citation, one citing the Pin List coordinate itself
      // (which files Grant-citation evidence under that coordinate).
      await injectForeignPinEdition(community, eid, []);
      await injectForeignPinEdition(community, eid, [["vac", eid, "1", "cd".repeat(32)]]);
      expect(community.state$.value.controlVerification!.heads.has(eid)).toBe(false);
      const messageId = await say(community, id, "first pin despite forgeries");
      await community.setPins(id, [proofFor(community, net, id, messageId)]);
      await settle();
      const editions = pinEditionRumors(community, net, id);
      expect(editions).toHaveLength(1);
      expect(editions[0].tags.find((t) => t[0] === "ev")?.[1]).toBe("1");
    } finally {
      await finish(community, store);
    }
  });

  it("setPins rejects with unverified-edition while live when a retained edition may still verify (D-33)", async () => {
    const { community, net, store } = await ownerCommunity();
    try {
      const id = await addFreshChannel(community);
      const eid = pinsLocator(hexToBytes(community.communityId), id);
      // A well-formed citation of the author's own Grant that has not synced: it may verify later, so writing a fresh
      // version 1 over it could fork the chain (CORD-04 §1).
      await injectForeignPinEdition(community, eid, (author) => [[
        "vac",
        grantLocator(hexToBytes(community.communityId), author),
        "1",
        "cd".repeat(32),
      ]]);
      expect(community.phase$.value).toBe("live");
      const before = pinEditions(community, net, id);
      const error = await rejection(community.setPins(id, []));
      expect(error).toBeInstanceOf(PinListNotReadyError);
      expect((error as PinListNotReadyError).reason).toBe("unverified-edition");
      expect((error as PinListNotReadyError).message).toContain("unverified");
      expect(pinEditions(community, net, id)).toBe(before);
    } finally {
      await finish(community, store);
    }
  });

  it("setPins writes over a banned curator's Pin List, chained at the next version (D-34)", async () => {
    await writeOverRemovedCurator("ban");
  });

  it("setPins writes over a demoted curator's Pin List, chained at the next version, and keeps it on re-promotion (D-34)", async () => {
    await writeOverRemovedCurator("demotion");
  });

  it("setPins publishes a message listed twice once, keeping the copy with the newest bundled Edit (D-32)", async () => {
    // Non-vacuity: encode the entries as given and the head carries three entries, the older bundle among them.
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    try {
      const { newer, older, withNewer, withOlder } = await twiceEdited(community, net, generalId);
      const otherId = await say(community, generalId, "other");
      const other = proofFor(community, net, generalId, otherId);
      await community.setPins(generalId, [withOlder, other, withNewer]);
      await settle();
      const headEntries = (): PinEntry[] =>
        (JSON.parse(pinEditionRumors(community, net, generalId).at(-1)!.content) as { entries: PinEntry[] }).entries;
      const first = headEntries();
      expect(first).toHaveLength(2);
      expect(verifyPinEntry(first[0], generalId)?.edit?.id).toBe(getEventHash(newer));
      expect(first[0].seal).toEqual(withNewer.seal);
      expect(first[1].seal.id).toBe(other.seal.id);
      // An Edit its author deleted never counts as newest, so the surviving bundle is kept.
      await community.deleteMessage(generalId, newer);
      await settle();
      await community.setPins(generalId, [withNewer, withOlder]);
      await settle();
      const second = headEntries();
      expect(second).toHaveLength(1);
      expect(verifyPinEntry(second[0], generalId)?.edit?.id).toBe(getEventHash(older));
    } finally {
      await finish(community, store);
    }
  });

  it("setPins refuses an unreadable private Pin List and never rebuilds it from empty", async () => {
    const a = await ownerCommunity();
    let engine: ConcordCommunity | undefined;
    const storeB = new EventStore();
    try {
      const id = await a.community.createChannel("secret", { private: true });
      await settle();
      expect(pinEditions(a.community, a.net, id)).toBe(1);
      const netB = fakeRelayPool({ events: [...a.net.published] });
      const material = a.community.material;
      engine = new ConcordCommunity({
        storage: memoryStorage(),
        material: { ...material, channels: material.channels.filter((key) => key.id !== id) },
        signer: a.signer,
        pubkey: a.pubkey,
        pool: netB.pool,
        eventStore: storeB,
        relays: ["wss://fake"],
      });
      await engine.start();
      await settle();
      expect(engine.state$.value.channels.some((channel) => channel.channel_id === id)).toBe(true);
      const error = await rejection(engine.setPins(id, []));
      expect(error).toBeInstanceOf(PinListNotReadyError);
      expect((error as PinListNotReadyError).reason).toBe("unreadable");
      expect(netB.published).toHaveLength(0);
    } finally {
      engine?.dispose();
      storeB.dispose();
      await finish(a.community, a.store);
    }
  });

  it("setPins rejects with unreadable for a private channel with no Pin List whose key is not held", async () => {
    // Non-vacuity: without the guard the key lookup throws a plain Error instead of the typed rejection.
    const { community, net, store } = await ownerCommunity();
    try {
      const id = await addFreshChannel(community, true);
      expect(community.state$.value.channels.find((channel) => channel.channel_id === id)?.private).toBe(true);
      expect(community.material.channels.some((key) => key.id === id)).toBe(false);
      const before = net.published.length;
      const error = await rejection(community.setPins(id, []));
      expect(error).toBeInstanceOf(PinListNotReadyError);
      expect((error as PinListNotReadyError).reason).toBe("unreadable");
      expect(net.published).toHaveLength(before);
    } finally {
      await finish(community, store);
    }
  });

  it("setPins rejects with reason changed when the head moves while signing", async () => {
    const gate = new Gate<[draft: Parameters<ISigner["signEvent"]>[0]], Awaited<ReturnType<ISigner["signEvent"]>>>();
    let parking = false;
    const { community, net, store, generalId } = await ownerCommunity((signer) =>
      ({
        getPublicKey: () => signer.getPublicKey(),
        signEvent: gate.wrap((draft) => Promise.resolve(signer.signEvent(draft)), () => parking),
        nip44: signer.nip44,
      }) as ISigner
    );
    try {
      const id = await say(community, generalId, "contended");
      const proof = proofFor(community, net, generalId, id);
      const before = pinEditionRumors(community, net, generalId);
      const head = community.state$.value.controlVerification!.heads.get(
        pinsLocator(hexToBytes(community.communityId), generalId),
      )!;
      parking = true;
      const parked = gate.next();
      const call = rejection(community.setPins(generalId, [proof]));
      const sealing = await parked;
      parking = false;
      // A competing writer lands the next version while setPins' seal signature is outstanding.
      const rival = await EditionFactory.create({
        vsk: VSK.PINS,
        eid: head.eid,
        version: head.version + 1,
        prevHash: head.hash,
        content: encodePinList([]),
      });
      await community.publishToPlane({ plane: "control" }, rival, { plaintext: true });
      await settle();
      expect(computeEditionHash({
        vsk: VSK.PINS,
        eid: head.eid,
        version: head.version + 1,
        prevHash: head.hash,
        content: encodePinList([]),
      })).toBe(community.state$.value.controlVerification!.heads.get(head.eid)!.hash);
      sealing.release();
      const error = await call;
      expect(error).toBeInstanceOf(PinListNotReadyError);
      expect((error as PinListNotReadyError).reason).toBe("changed");
      // Only the rival's edition was published; setPins' own edition never left the engine.
      expect(pinEditionRumors(community, net, generalId)).toHaveLength(before.length + 1);
    } finally {
      await finish(community, store);
    }
  });

  it("setPins replaces an existing private list at the next version in the channel's form", async () => {
    const { community, net, store } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await community.createChannel("members", { private: true });
      await settle();
      const messageId = await say(community, id, "members only");
      await community.setPins(id, [proofFor(community, net, id, messageId)]);
      await settle();
      const editions = pinEditionRumors(community, net, id);
      expect(editions.map((rumor) => rumor.tags.find((t) => t[0] === "ev")?.[1])).toEqual(["1", "2"]);
      expect(editions[1].content).not.toContain("members only");
      const watching = watch(community, id);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["members only"]);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("seedChannel publishes an empty Pin List only for a PIN_MESSAGES holder", async () => {
    const published: Array<{ vsk: number; eid: string; content: string }> = [];
    const stub = (allowed: boolean): CommunityPins =>
      new CommunityPins({
        communityId: () => "cd".repeat(32),
        canPin: () => allowed,
        privateChannelKey: () => ({ epoch: 0, convKey: new Uint8Array(32).fill(7) }),
        publishEdition: (vsk: number, eid: string, content: string) => {
          published.push({ vsk, eid, content });
          return Promise.resolve();
        },
      } as unknown as CommunityPinsHost);
    await stub(false).seedChannel("ab".repeat(32), false);
    expect(published).toHaveLength(0);
    await stub(true).seedChannel("ab".repeat(32), false);
    expect(published).toHaveLength(1);
    expect(published[0].vsk).toBe(VSK.PINS);
    expect(published[0].content).toBe(encodePinList([]));
    await stub(true).seedChannel("ef".repeat(32), true);
    expect(published).toHaveLength(2);
    expect(published[1].content).not.toBe(encodePinList([]));

    const { community, net, store } = await ownerCommunity();
    try {
      expect(community.canDo(PERM.PIN_MESSAGES)).toBe(true);
      const id = await community.createChannel("plain");
      await settle();
      expect(pinEditions(community, net, id)).toBe(1);
    } finally {
      await finish(community, store);
    }
  });
});

/** Wait until no duty attempt is running on a community, then let the echo of its publication settle. */
async function dutiesSettled(community: ConcordCommunity): Promise<void> {
  await settle();
  await (community as unknown as { duties: DutyScope }).duties.idle();
  await settle();
}

describe("ConcordCommunity setPins own-pin record", () => {
  /** A proven pin of a message another member wrote in `channelId`, so only the record can make it this client's pin. */
  async function foreignPin(channelId: string, content: string): Promise<PinEntry> {
    const foreign = new PrivateKeySigner(generateSecretKey());
    const base = {
      pubkey: await foreign.getPublicKey(),
      id: "",
      kind: 9,
      content,
      tags: [["channel", channelId], ["epoch", "0"]],
      created_at: Math.floor(Date.now() / 1000),
    };
    const rumor: Rumor = { ...base, id: getEventHash(base) };
    const key = new Uint8Array(32).fill(5);
    return createPinProof(await sealRumor(key, foreign)(rumor), key) as PinEntry;
  }

  // Non-vacuity: in CommunityPins.setPins pass only the newly added ids to a replacing notePinned (the old behavior).
  // The second call then leaves the record as {b}, so the count of 2 fails.
  it("a later setPins keeps this client's earlier pins on record and forgets unpinned ones (WR-03)", async () => {
    const { community, store, generalId } = await ownerCommunity();
    const recorded = () =>
      (community as unknown as { pinning: { maintainer: { pinnedCount(id: string): number } } }).pinning.maintainer
        .pinnedCount(generalId);
    try {
      const a = await foreignPin(generalId, "a");
      const b = await foreignPin(generalId, "b");
      await community.setPins(generalId, [a]);
      await dutiesSettled(community);
      expect(recorded()).toBe(1);
      await community.setPins(generalId, [a, b]);
      await dutiesSettled(community);
      expect(recorded()).toBe(2);
      await community.setPins(generalId, [b]);
      await dutiesSettled(community);
      expect(recorded()).toBe(1);
    } finally {
      await finish(community, store);
    }
  });
});

describe("ConcordCommunity pin omission upkeep", () => {
  it("the pinner's own self-deleted pin is omitted by one Pin List edition", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const keep = await say(community, generalId, "keeper");
      const doomed = await say(community, generalId, "doomed");
      await community.setPins(generalId, [
        proofFor(community, net, generalId, keep),
        proofFor(community, net, generalId, doomed),
      ]);
      await dutiesSettled(community);
      const before = pinEditionRumors(community, net, generalId);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text).sort()).toEqual(["doomed", "keeper"]);
      const original = (await community.channelStore(generalId).getTimeline([{ kinds: [9] }]))
        .find((rumor) => rumor.id === doomed)!;
      await community.deleteMessage(generalId, original);
      await dutiesSettled(community);
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["keeper"]);
      const after = pinEditionRumors(community, net, generalId);
      expect(after).toHaveLength(before.length + 1);
      const head = after.at(-1)!;
      const ids = (JSON.parse(head.content) as { entries: PinEntry[] }).entries.map((entry) => entry.seal.id);
      expect(ids).toHaveLength(1);
      expect(ids).toEqual([proofFor(community, net, generalId, keep).seal.id]);
      // The upkeep edition chains on the previous head and the same head never publishes twice.
      expect(head.tags.find((t) => t[0] === "ev")?.[1]).toBe(
        String(Number(before.at(-1)!.tags.find((t) => t[0] === "ev")![1]) + 1),
      );
      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(after.length);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("deleting an unpinned message publishes no Pin List edition", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      const pinned = await say(community, generalId, "pinned");
      const other = await say(community, generalId, "unpinned");
      await community.setPins(generalId, [proofFor(community, net, generalId, pinned)]);
      await dutiesSettled(community);
      const editions = pinEditions(community, net, generalId);
      const original = (await community.channelStore(generalId).getTimeline([{ kinds: [9] }]))
        .find((rumor) => rumor.id === other)!;
      await community.deleteMessage(generalId, original);
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect((await community.pins(generalId)).map((pin) => pin.text)).toEqual(["pinned"]);
    } finally {
      await finish(community, store);
    }
  });
});

describe("ConcordCommunity pin edit refresh", () => {
  it("an edited pinned message is refreshed with the newest Edit's proof bundle", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "first draft");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      const before = pinEditionRumors(community, net, generalId);
      const watching = watch(community, generalId);
      sub = watching.sub;
      await community.editMessage(generalId, id, "second draft");
      await dutiesSettled(community);
      const after = pinEditionRumors(community, net, generalId);
      expect(after).toHaveLength(before.length + 1);
      const edit = await newestOfKind(community, generalId, 3302);
      const entries = (JSON.parse(after.at(-1)!.content) as { entries: PinEntry[] }).entries;
      expect(entries).toHaveLength(1);
      // The entry carries the Edit's own proof bundle and nothing else changed about the original proof.
      expect(verifyPinEntry(entries[0], generalId)?.edit?.id).toBe(getEventHash(edit));
      expect(entries[0].seal).toEqual(proofFor(community, net, generalId, id).seal);
      const pin = watching.seen.at(-1)![0];
      expect(pin.text).toBe("second draft");
      expect(pin.edited).toBe(true);
      expect(pin.behind).toBe(false);
      // The refreshed head needs no further work: the same state publishes nothing more.
      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(after.length);
    } finally {
      await finish(community, store, sub);
    }
  });
});

describe("ConcordCommunity pin upkeep and deleted Edits", () => {
  const headEntries = (community: ConcordCommunity, net: FakeRelayPool, channelId: string): PinEntry[] =>
    (JSON.parse(pinEditionRumors(community, net, channelId).at(-1)!.content) as { entries: PinEntry[] }).entries;

  it("upkeep never bundles an Edit its author deleted before the message was pinned (D-31)", async () => {
    // Non-vacuity: drop `deletions` from refreshedEntry and the maintainer publishes the retracted Edit's proof (CR-02).
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "original text");
      await community.editMessage(generalId, id, "retracted text");
      await dutiesSettled(community);
      const retracted = await editByContent(community, generalId, "retracted text");
      await community.deleteMessage(generalId, retracted);
      await dutiesSettled(community);
      const before = pinEditions(community, net, generalId);
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
      const entries = headEntries(community, net, generalId);
      expect(entries).toHaveLength(1);
      expect("edit" in entries[0]).toBe(false);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)![0].text).toBe("original text");
      expect(watching.seen.at(-1)![0].edited).toBe(false);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("a bundled Edit its author deletes is replaced by the newest undeleted Edit's proof (D-31)", async () => {
    // Non-vacuity: keep the deleted bundled Edit as the never-regress baseline and no fallback is ever bundled.
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "original text");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      await community.editMessage(generalId, id, "first edit");
      await dutiesSettled(community);
      await community.editMessage(generalId, id, "second edit");
      await dutiesSettled(community);
      const drafted = [
        await editByContent(community, generalId, "first edit"),
        await editByContent(community, generalId, "second edit"),
      ];
      // The sub-second order of Edits sent within one second is not the order they were sent in, so rank them by the
      // library's own chooser instead of by send order.
      const original = (await community.channelStore(generalId).getTimeline([{ kinds: [9] }])).find((r) =>
        r.id === id
      )!;
      const newest = newestValidEdit(original, drafted, { channelId: generalId })!;
      const newer = drafted.find((rumor) => getEventHash(rumor) === newest.id)!;
      const older = drafted.find((rumor) => rumor !== newer)!;
      expect(verifyPinEntry(headEntries(community, net, generalId)[0], generalId)?.edit?.id).toBe(getEventHash(newer));
      const watching = watch(community, generalId);
      sub = watching.sub;
      const before = pinEditions(community, net, generalId);
      await community.deleteMessage(generalId, newer);
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
      const entries = headEntries(community, net, generalId);
      expect(entries).toHaveLength(1);
      // The fallback proof is rebuilt from the seal recovered from the retained wrap (PIN-05).
      expect(verifyPinEntry(entries[0], generalId)?.edit?.id).toBe(getEventHash(older));
      const pin = watching.seen.at(-1)![0];
      expect(pin.text).toBe(older.content);
      expect(pin.edited).toBe(true);
      expect(pin.behind).toBe(false);
      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("a bundled Edit its author deletes is removed from the Pin List when no undeleted Edit remains (D-31)", async () => {
    // Non-vacuity: return undefined instead of the stripped entry and the retracted bundle stays on the head.
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "original text");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      await community.editMessage(generalId, id, "only edit");
      await dutiesSettled(community);
      const only = await editByContent(community, generalId, "only edit");
      expect(verifyPinEntry(headEntries(community, net, generalId)[0], generalId)?.edit?.id).toBe(getEventHash(only));
      const watching = watch(community, generalId);
      sub = watching.sub;
      const before = pinEditions(community, net, generalId);
      await community.deleteMessage(generalId, only);
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
      const entries = headEntries(community, net, generalId);
      expect(entries).toHaveLength(1);
      expect("edit" in entries[0]).toBe(false);
      expect(entries[0].seal).toEqual(proofFor(community, net, generalId, id).seal);
      const pin = watching.seen.at(-1)![0];
      expect(pin.text).toBe("original text");
      expect(pin.edited).toBe(false);
      expect(pin.behind).toBe(false);
      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
    } finally {
      await finish(community, store, sub);
    }
  });
});

describe("ConcordCommunity pin edit refresh after restart and in private channels", () => {
  it("after a restart the Edit seal index is rebuilt by sync before live", async () => {
    // Engine A pins and edits with upkeep off, so the Pin List still carries the original proof only.
    const a = await ownerCommunity((s) => s, { pinUpkeep: false });
    let engine: ConcordCommunity | undefined;
    const storeB = new EventStore();
    try {
      const id = await say(a.community, a.generalId, "first draft");
      await a.community.setPins(a.generalId, [proofFor(a.community, a.net, a.generalId, id)]);
      await a.community.editMessage(a.generalId, id, "second draft");
      await settle();
      const published = [...a.net.published];
      const editions = pinEditions(a.community, a.net, a.generalId);
      a.community.dispose();
      const netB = fakeRelayPool({ events: published });
      engine = new ConcordCommunity({
        storage: memoryStorage(),
        material: a.community.material,
        signer: a.signer,
        pubkey: a.pubkey,
        pool: netB.pool,
        eventStore: storeB,
        relays: ["wss://fake"],
      });
      await engine.start();
      await dutiesSettled(engine);
      // One refresh edition, built from a seal that engine B recovered itself while syncing.
      const refreshed = pinEditionRumors(engine, netB, a.generalId);
      expect(refreshed).toHaveLength(1);
      const edit = await newestOfKind(engine, a.generalId, 3302);
      const entries = (JSON.parse(refreshed[0].content) as { entries: PinEntry[] }).entries;
      expect(verifyPinEntry(entries[0], a.generalId)?.edit?.id).toBe(getEventHash(edit));
      expect(editions).toBeGreaterThan(0);
    } finally {
      engine?.dispose();
      storeB.dispose();
      await finish(a.community, a.store);
    }
  });

  it("a private channel's pinned edit is refreshed after a restart from the channel engine's own sync", async () => {
    const a = await ownerCommunity((s) => s, { pinUpkeep: false });
    let engine: ConcordCommunity | undefined;
    const storeB = new EventStore();
    try {
      const id = await a.community.createChannel("members", { private: true });
      await settle();
      const messageId = await say(a.community, id, "members only");
      await a.community.setPins(id, [proofFor(a.community, a.net, id, messageId)]);
      await a.community.editMessage(id, messageId, "members only, corrected");
      await settle();
      const published = [...a.net.published];
      a.community.dispose();
      const netB = fakeRelayPool({ events: published });
      engine = new ConcordCommunity({
        storage: memoryStorage(),
        material: a.community.material,
        signer: a.signer,
        pubkey: a.pubkey,
        pool: netB.pool,
        eventStore: storeB,
        relays: ["wss://fake"],
      });
      await engine.start();
      await dutiesSettled(engine);
      const refreshed = pinEditionRumors(engine, netB, id);
      expect(refreshed).toHaveLength(1);
      expect(typeof (JSON.parse(refreshed[0].content) as { sealed?: unknown }).sealed).toBe("string");
      const list = (engine as unknown as { pinning: CommunityPins }).pinning.pinList(id);
      if (!list.available) throw new Error("the refreshed Pin List cannot be opened");
      const edit = await newestOfKind(engine, id, 3302);
      expect(verifyPinEntry(list.entries[0], id)?.edit?.id).toBe(getEventHash(edit));
    } finally {
      engine?.dispose();
      storeB.dispose();
      await finish(a.community, a.store);
    }
  });

  it("a private channel's pinned edit is refreshed under its sealed form", async () => {
    const { community, net, store } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await community.createChannel("members", { private: true });
      await settle();
      const messageId = await say(community, id, "members only");
      await community.setPins(id, [proofFor(community, net, id, messageId)]);
      await dutiesSettled(community);
      const before = pinEditionRumors(community, net, id);
      const watching = watch(community, id);
      sub = watching.sub;
      await community.editMessage(id, messageId, "members only, corrected");
      await dutiesSettled(community);
      const after = pinEditionRumors(community, net, id);
      expect(after).toHaveLength(before.length + 1);
      // The refreshed head is a sealed list at the channel's current epoch and never carries the text in the clear.
      const head = after.at(-1)!;
      expect(typeof (JSON.parse(head.content) as { sealed?: unknown }).sealed).toBe("string");
      expect(head.content).not.toContain("corrected");
      const pinning = (community as unknown as { pinning: CommunityPins }).pinning;
      const list = pinning.pinList(id);
      if (!list.available) throw new Error("the refreshed Pin List cannot be opened");
      const edit = await newestOfKind(community, id, 3302);
      expect(verifyPinEntry(list.entries[0], id)?.edit?.id).toBe(getEventHash(edit));
      const pin = watching.seen.at(-1)![0];
      expect(pin.text).toBe("members only, corrected");
      expect(pin.behind).toBe(false);
    } finally {
      await finish(community, store, sub);
    }
  });
});

/** A private channel with one pinned message, upkeep settled; returns the ids the rekey tests compare against. */
async function pinnedPrivate(
  community: ConcordCommunity,
  net: FakeRelayPool,
  text: string,
): Promise<{ id: string; messageId: string }> {
  const id = await community.createChannel("members", { private: true });
  await settle();
  const messageId = await say(community, id, text);
  await community.setPins(id, [proofFor(community, net, id, messageId)]);
  await dutiesSettled(community);
  return { id, messageId };
}

describe("ConcordCommunity private channel rekey refresh", () => {
  it("after a private channel rekey the rotator republishes its Pin List under the new key with byte-identical proof bundles", async () => {
    const { community, net, store, pubkey } = await ownerCommunity();
    try {
      const { id } = await pinnedPrivate(community, net, "members only");
      const before = pinEditionRumors(community, net, id);
      const pinning = (community as unknown as { pinning: CommunityPins }).pinning;
      const listBefore = pinning.pinList(id);
      if (!listBefore.available) throw new Error("the Pin List cannot be opened before the rekey");
      expect(JSON.parse(before.at(-1)!.content).epoch).toBe("1");
      // The rotation mark is made after the rekey wraps are out and before the key commit (epoch still 1).
      const marks: Array<{ channelId: string; epoch: number | undefined }> = [];
      const noteRotation = pinning.noteRotation.bind(pinning);
      pinning.noteRotation = (channelId: string) => {
        marks.push({ channelId, epoch: community.material.channels.find((key) => key.id === channelId)?.epoch });
        noteRotation(channelId);
      };
      await community.rotateChannel(id, { keep: [pubkey] });
      expect(marks).toEqual([{ channelId: id, epoch: 1 }]);
      await dutiesSettled(community);
      await dutiesSettled(community);
      const after = pinEditionRumors(community, net, id);
      // Exactly one reseal edition, chained on the previous head and sealed at the new epoch.
      expect(after).toHaveLength(before.length + 1);
      const head = after.at(-1)!;
      const body = JSON.parse(head.content) as { epoch: string; sealed: string };
      expect(body.epoch).toBe("2");
      expect(head.content).not.toContain("members only");
      const listAfter = pinning.pinList(id);
      if (!listAfter.available) throw new Error("the resealed Pin List cannot be opened");
      expect(listAfter.entries).toEqual(listBefore.entries);
      expect(listAfter.entries.map((entry) => entry.seal.content)).toEqual(
        listBefore.entries.map((entry) => entry.seal.content),
      );
      expect(listAfter.entries.map((entry) => entry.keys)).toEqual(listBefore.entries.map((entry) => entry.keys));
      // The same head never publishes twice.
      await dutiesSettled(community);
      expect(pinEditions(community, net, id)).toBe(after.length);
    } finally {
      await finish(community, store);
    }
  });

  it("a fresh reader holding only the new channel key reads the resealed pins", async () => {
    const a = await ownerCommunity();
    let reader: ConcordCommunity | undefined;
    const storeB = new EventStore();
    let sub: Subscription | undefined;
    try {
      const { id } = await pinnedPrivate(a.community, a.net, "members only");
      await a.community.rotateChannel(id, { keep: [a.pubkey] });
      await dutiesSettled(a.community);
      await dutiesSettled(a.community);
      const material = a.community.material;
      const current = material.channels.find((key) => key.id === id)!;
      expect(current.epoch).toBe(2);
      expect(current.held?.length).toBeGreaterThan(0);
      const { held: _held, ...bare } = current;
      const netB = fakeRelayPool({ events: [...a.net.published] });
      reader = new ConcordCommunity({
        storage: memoryStorage(),
        material: { ...material, channels: material.channels.map((key) => key.id === id ? bare : key) },
        signer: a.signer,
        pubkey: a.pubkey,
        pool: netB.pool,
        eventStore: storeB,
        relays: ["wss://fake"],
      });
      await reader.start();
      await dutiesSettled(reader);
      expect((reader.material.channels.find((key) => key.id === id)?.held ?? []).length).toBe(0);
      expect((await reader.pins(id)).map((pin) => pin.text)).toEqual(["members only"]);
      const watching = watch(reader, id);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["members only"]);
      // Reading is not writing: the reader republishes nothing for a list already at its key.
      expect(netB.published).toHaveLength(0);
    } finally {
      reader?.dispose();
      sub?.unsubscribe();
      storeB.dispose();
      await finish(a.community, a.store);
    }
  });
});

/** The channel's Pin List head as the community folded it, which must exist. */
function pinHead(community: ConcordCommunity, channelId: string) {
  const eid = pinsLocator(hexToBytes(community.communityId), channelId);
  const head = community.state$.value.controlVerification?.heads.get(eid);
  if (!head) throw new Error("no verified Pin List head");
  return head;
}

/** A fresh engine over the events a community published, with its own store; the caller disposes both. */
async function engineOver(
  source: { net: FakeRelayPool; signer: ISigner; pubkey: string },
  material: ConcordCommunity["material"],
  options: Partial<ConcordCommunityOptions> = {},
): Promise<{ engine: ConcordCommunity; net: FakeRelayPool; store: EventStore }> {
  const net = fakeRelayPool({ events: [...source.net.published] });
  const store = new EventStore();
  const engine = new ConcordCommunity({
    storage: memoryStorage(),
    material,
    signer: source.signer,
    pubkey: source.pubkey,
    pool: net.pool,
    eventStore: store,
    relays: ["wss://fake"],
    ...options,
  });
  await engine.start();
  await dutiesSettled(engine);
  return { engine, net, store };
}

describe("ConcordCommunity pin conversion, missing keys and rekey safety", () => {
  // Non-vacuity: in planPinUpkeep, replace the blocked private-era-list result for a sealed head on a public channel
  // with a public-form rewrite. A Pin List edition is then published and no private-era-list diagnostic is reported,
  // so the "no new edition" and "exactly one skipped" assertions fail.
  it("a private-to-public conversion never re-forms the sealed Pin List as public, even with upkeep due", async () => {
    const diagnostics: ConcordDiagnostic[] = [];
    const { community, net, store } = await ownerCommunity((s) => s, {
      onDiagnostic: (diagnostic) => diagnostics.push(diagnostic),
    });
    let sub: Subscription | undefined;
    try {
      const { id, messageId } = await pinnedPrivate(community, net, "secret era");
      expect(JSON.parse(pinHead(community, id).edition.rumor.content).sealed).toBeDefined();
      // A conversion edition flips the channel to public while the Pin List head stays sealed.
      const channelHead = community.state$.value.controlVerification!.heads.get(id)!;
      const conversion = await EditionFactory.create({
        vsk: VSK.CHANNEL,
        eid: id,
        version: channelHead.version + 1,
        prevHash: channelHead.hash,
        content: JSON.stringify({ ...JSON.parse(channelHead.edition.rumor.content), private: false }),
      });
      await community.publishToPlane({ plane: "control" }, conversion, { plaintext: true });
      await dutiesSettled(community);
      expect(community.state$.value.channels.find((channel) => channel.channel_id === id)?.private).toBe(false);
      const before = pinEditions(community, net, id);
      const watching = watch(community, id);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["secret era"]);
      // The owner deletes the pinned message: a sealed list on a public channel must not be re-formed as public.
      const original = (await community.channelStore(id).getTimeline([{ kinds: [9] }]))
        .find((rumor) => rumor.id === messageId)!;
      await community.deleteMessage(id, original);
      await dutiesSettled(community);
      await dutiesSettled(community);
      expect(pinEditions(community, net, id)).toBe(before);
      expect(pinHead(community, id).edition.rumor.content).toContain('"sealed"');
      const skipped = diagnostics.filter((d) => d.stage === "pin-upkeep-skipped");
      expect(skipped).toHaveLength(1);
      if (skipped[0].stage !== "pin-upkeep-skipped") throw new Error("unreachable");
      expect(skipped[0].reason).toBe("private-era-list");
      expect(skipped[0].key).toBe(id);
      // The local projection still hides the deleted pin.
      expect(watching.seen.at(-1)).toEqual([]);
      expect(await community.pins(id)).toEqual([]);
    } finally {
      await finish(community, store, sub);
    }
  });

  // Non-vacuity: in CommunityPins.pinList, treat a sealed list whose epoch key is not held as available with no entries
  // (the rebuild-from-empty bug). The assertion that the list is unavailable then fails.
  it("a holder lacking the old channel epoch key leaves the sealed Pin List unavailable and publishes nothing", async () => {
    // Upkeep is off for the rotator so the list stays sealed at the old epoch after the rekey.
    const a = await ownerCommunity((s) => s, { pinUpkeep: false });
    let holder: Awaited<ReturnType<typeof engineOver>> | undefined;
    let sub: Subscription | undefined;
    try {
      const { id } = await pinnedPrivate(a.community, a.net, "old era");
      await a.community.rotateChannel(id, { keep: [a.pubkey] });
      await dutiesSettled(a.community);
      expect(JSON.parse(pinHead(a.community, id).edition.rumor.content).epoch).toBe("1");
      const material = a.community.material;
      const current = material.channels.find((key) => key.id === id)!;
      expect(current.epoch).toBe(2);
      const { held: _held, ...bare } = current;
      holder = await engineOver(a, {
        ...material,
        channels: material.channels.map((key) => key.id === id ? bare : key),
      });
      const pinning = (holder.engine as unknown as { pinning: CommunityPins }).pinning;
      expect(pinning.pinList(id).available).toBe(false);
      const watching = watch(holder.engine, id);
      sub = watching.sub;
      expect(watching.seen.at(-1)).toEqual([]);
      await dutiesSettled(holder.engine);
      expect(await holder.engine.pins(id)).toEqual([]);
      // It also refuses a replacement, and publishes no Pin List edition of its own.
      expect(holder.net.published).toHaveLength(0);
    } finally {
      sub?.unsubscribe();
      holder?.engine.dispose();
      holder?.store.dispose();
      await finish(a.community, a.store);
    }
  });

  // Non-vacuity: in the maintainer's run, encode the reseal with the head's old epoch key instead of the
  // privateChannelKey snapshot (a stale form/key). The old-key reader can then read the list and the assertion that
  // the list is unavailable to it fails.
  it("a reader holding only the old channel key cannot read the resealed Pin List", async () => {
    const a = await ownerCommunity();
    let reader: Awaited<ReturnType<typeof engineOver>> | undefined;
    try {
      const { id } = await pinnedPrivate(a.community, a.net, "old era");
      const oldKey = a.community.material.channels.find((key) => key.id === id)!;
      expect(oldKey.epoch).toBe(1);
      const openWithOldKey = (content: string) =>
        readPinList(content, (epoch) => {
          return epoch === String(oldKey.epoch)
            ? channelGroupKey(hexToBytes(oldKey.key), hexToBytes(id), oldKey.epoch).convKey
            : undefined;
        });
      // Before the rekey the old key opens the list: the premise of the assertion below.
      expect(openWithOldKey(pinHead(a.community, id).edition.rumor.content).available).toBe(true);
      await a.community.rotateChannel(id, { keep: [a.pubkey] });
      await dutiesSettled(a.community);
      await dutiesSettled(a.community);
      const head = pinHead(a.community, id).edition.rumor.content;
      expect(JSON.parse(head).epoch).toBe("2");
      expect(openWithOldKey(head).available).toBe(false);
      // A stranger who only ever held the old key (never in the keep set) cannot read the resealed list either.
      const stranger = new PrivateKeySigner(generateSecretKey());
      reader = await engineOver(
        { net: a.net, signer: stranger, pubkey: await stranger.getPublicKey() },
        { ...a.community.material, channels: a.community.material.channels.map((key) => key.id === id ? oldKey : key) },
      );
      const pinning = (reader.engine as unknown as { pinning: CommunityPins }).pinning;
      expect(pinning.pinList(id).available).toBe(false);
      expect(await reader.engine.pins(id)).toEqual([]);
      expect(reader.net.published).toHaveLength(0);
    } finally {
      reader?.engine.dispose();
      reader?.store.dispose();
      await finish(a.community, a.store);
    }
  });
});

/**
 * The rumor id a Control sibling edition will publish under, given its nonce tag. A Control edition carries no `ms`
 * tag, so the envelope stamps it at wrap time with `unixNow()` (rounded seconds); the grind must predict that stamp,
 * not a floored one.
 */
function predictedSiblingId(
  sibling: { kind: number; content: string; tags: string[][] },
  pubkey: string,
  nonce: number,
): string {
  return getEventHash({
    kind: sibling.kind,
    content: sibling.content,
    tags: [...sibling.tags, ["nonce", String(nonce)]],
    created_at: unixNow(),
    pubkey,
  });
}

describe("ConcordCommunity pin regressions across heads and Refoundings", () => {
  it("the sibling grind predicts the published id at any millisecond (D-08)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      const keep = await say(community, generalId, "keeper");
      await community.setPins(generalId, [proofFor(community, net, generalId, keep)]);
      await dutiesSettled(community);
      const head = pinHead(community, generalId);
      const sibling = await EditionFactory.create({
        vsk: VSK.PINS,
        eid: head.eid,
        version: head.version,
        prevHash: head.edition.rumor.tags.find((tag) => tag[0] === "ep")?.[1],
        content: head.edition.rumor.content,
      });
      {
        // 700 ms into a second the envelope's wrap-time stamp rounds up while a floored prediction stays behind.
        using _clock = stub(Date, "now", () => 1_700_000_000_700);
        const predicted = predictedSiblingId(sibling, head.edition.rumor.pubkey, 0);
        const published = await community.publishToPlane({ plane: "control" }, {
          ...sibling,
          tags: [...sibling.tags, ["nonce", "0"]],
        }, { plaintext: true });
        expect(published).toBe(predicted);
      }
      await dutiesSettled(community);
    } finally {
      await finish(community, store);
    }
  });

  // Non-vacuity: drop the head hash from the duty key in PinMaintainer.evaluate (key `pin-upkeep:<channel>` only), so
  // the settled key answers quiet for the sibling head. No version N + 1 edition then appears and the test fails.
  it("an omission lost to a concurrent sibling edition is re-applied on the winning head", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const keep = await say(community, generalId, "keeper");
      const doomed = await say(community, generalId, "doomed");
      await community.setPins(generalId, [
        proofFor(community, net, generalId, keep),
        proofFor(community, net, generalId, doomed),
      ]);
      await dutiesSettled(community);
      const before = pinEditionRumors(community, net, generalId);
      const predecessor = before.at(-1)!;
      const original = (await community.channelStore(generalId).getTimeline([{ kinds: [9] }]))
        .find((rumor) => rumor.id === doomed)!;
      await community.deleteMessage(generalId, original);
      await dutiesSettled(community);
      const ownHead = pinHead(community, generalId);
      const omission = pinEditionRumors(community, net, generalId).at(-1)!;
      expect(pinEditionRumors(community, net, generalId)).toHaveLength(before.length + 1);
      expect(ownHead.version).toBe(before.length + 1);
      expect(ownHead.edition.rumor.id).toBe(getEventHash(omission));
      // A concurrent sibling at the same version and predecessor re-seats the deleted entry and wins the tiebreak
      // (equal version: lower rumor id). A publish re-stamps created_at, so the id is ground through a tag nonce.
      const ep = ownHead.edition.rumor.tags.find((tag) => tag[0] === "ep")?.[1];
      expect(ep).toBeDefined();
      const sibling = await EditionFactory.create({
        vsk: VSK.PINS,
        eid: ownHead.eid,
        version: ownHead.version,
        prevHash: ep,
        content: predecessor.content,
      });
      const target = ownHead.edition.rumor.id;
      const idFor = (n: number) => predictedSiblingId(sibling, ownHead.edition.rumor.pubkey, n);
      // The envelope stamps its own second at wrap time, so a nonce ground a moment earlier can still lose when the
      // rounded clock ticks over in between; a sibling that loses the tiebreak is harmless, so grind again until the
      // published id is lower.
      let winnerId = "";
      let nonce = 0;
      for (let attempt = 0; attempt < 8 && !(winnerId !== "" && winnerId < target); attempt++) {
        while (idFor(nonce) >= target) nonce++;
        winnerId = await community.publishToPlane({ plane: "control" }, {
          ...sibling,
          tags: [...sibling.tags, ["nonce", String(nonce)]],
        }, { plaintext: true });
        nonce++;
      }
      expect(winnerId < target).toBe(true);
      await dutiesSettled(community);
      await dutiesSettled(community);
      const winner = pinEditionRumors(community, net, generalId).find((rumor) => getEventHash(rumor) === winnerId);
      if (!winner) throw new Error("the sibling edition was not published");
      // The maintainer built version N + 1 on the winning head and omitted the entry again.
      const head = pinHead(community, generalId);
      expect(head.version).toBe(ownHead.version + 1);
      const headRumor = head.edition.rumor;
      expect(headRumor.tags.find((tag) => tag[0] === "ep")?.[1]).toBe(
        computeEditionHash({
          vsk: VSK.PINS,
          eid: ownHead.eid,
          version: ownHead.version,
          prevHash: ep,
          content: winner.content,
        }),
      );
      const entries = (JSON.parse(headRumor.content) as { entries: PinEntry[] }).entries;
      expect(entries.map((entry) => verifyPinEntry(entry, generalId)?.rumor.id)).toEqual([keep]);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["keeper"]);
      // The own omission was displaced by a sibling, not an ancestor of the head: a re-apply was due.
      const retained = (await community.controlStore.getTimeline([{ kinds: [3308] }])).map((rumor) => ({ rumor }));
      expect(classifyEditionLineage(ownHead, head, retained)).toEqual({ kind: "lost-sibling", depth: 1 });
    } finally {
      await finish(community, store, sub);
    }
  });

  // Non-vacuity: make CommunityPins.pins() drop pins whose original id is not in the channel store (requiring local
  // Chat history). The fresh reader's pins() becomes empty and the test fails.
  it("a fresh reader after a Refounding verifies public pins without old-epoch Chat keys", async () => {
    const a = await ownerCommunity();
    let reader: Awaited<ReturnType<typeof engineOver>> | undefined;
    let sub: Subscription | undefined;
    try {
      const messageId = await say(a.community, a.generalId, "survives refounding");
      await a.community.setPins(a.generalId, [proofFor(a.community, a.net, a.generalId, messageId)]);
      await dutiesSettled(a.community);
      await a.community.refound({ keep: [a.pubkey] });
      await dutiesSettled(a.community);
      expect(a.community.material.held_roots?.length).toBeGreaterThan(0);
      reader = await engineOver(a, { ...a.community.material, held_roots: [] });
      // The reader has no old-epoch Chat keys: its channel store never holds the pinned original.
      expect(await reader.engine.channelStore(a.generalId).getEvent(messageId)).toBeUndefined();
      expect((await reader.engine.pins(a.generalId)).map((pin) => pin.text)).toEqual(["survives refounding"]);
      const watching = watch(reader.engine, a.generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["survives refounding"]);
    } finally {
      sub?.unsubscribe();
      reader?.engine.dispose();
      reader?.store.dispose();
      await finish(a.community, a.store);
    }
  });
});

/** Whether a community built its automatic Pin List upkeep (the maintainer exists only when upkeep is on). */
function hasPinMaintainer(community: ConcordCommunity): boolean {
  const pinning = (community as unknown as { pinning: { maintainer?: unknown } }).pinning;
  return pinning.maintainer !== undefined;
}

describe("pinUpkeep opt-out (D-07)", () => {
  it("pinUpkeep false publishes no automatic Pin List edition", async () => {
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    let sub: Subscription | undefined;
    try {
      expect(hasPinMaintainer(community)).toBe(false);
      const keep = await say(community, generalId, "keeper");
      const doomed = await say(community, generalId, "doomed");
      await community.setPins(generalId, [
        proofFor(community, net, generalId, keep),
        proofFor(community, net, generalId, doomed),
      ]);
      await dutiesSettled(community);
      const editions = pinEditions(community, net, generalId);
      const watching = watch(community, generalId);
      sub = watching.sub;
      const original = (await community.channelStore(generalId).getTimeline([{ kinds: [9] }]))
        .find((rumor) => rumor.id === doomed)!;
      await community.deleteMessage(generalId, original);
      await dutiesSettled(community);
      await new Promise((resolve) => setTimeout(resolve, 100));
      // The pin is still hidden locally, but nothing was published on its behalf.
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["keeper"]);
      expect((await community.pins(generalId)).map((pin) => pin.text)).toEqual(["keeper"]);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect((community as unknown as { duties: DutyScope }).duties.pending).toBe(0);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("the client pinUpkeep option reaches every community engine", async () => {
    const outcomes: boolean[] = [];
    for (const pinUpkeep of [false, undefined]) {
      const signer = new PrivateKeySigner(generateSecretKey());
      const { pool } = fakeRelayPool();
      const store = new EventStore();
      const client = new ConcordClient({
        signer,
        pool,
        eventStore: store,
        storage: memoryStorage(),
        relays: ["wss://fake"],
        watchDirectInvites: false,
        pinUpkeep,
      });
      try {
        await client.start();
        const created = await client.createNewCommunity("Pins", "", ["wss://fake"]);
        await settle();
        outcomes.push(hasPinMaintainer(created));
        client.stop();
        expect((created as unknown as { duties: DutyScope }).duties.pending).toBe(0);
      } finally {
        client.dispose();
        store.dispose();
        await settle();
      }
    }
    // false reaches the engine; the default keeps upkeep on, so the first result is not a constant.
    expect(outcomes).toEqual([false, true]);
  });
});

/** Control-plane wraps published so far, by the plane their author key addresses. */
function controlWraps(community: ConcordCommunity, net: FakeRelayPool): number {
  return net.published.filter((wrap) => planeOf(community, wrap)?.type === "control").length;
}

describe("ConcordCommunity pins after dissolution", () => {
  // Non-vacuity: in ConcordCommunity.route, drop the `this.pinning.isHistoricalSelfDelete(...)` exemption from its
  // sealed check (`else if (this.sealed) return;`), so the scrub is still published but never retained locally; the
  // assertion that pins$ hides the pin then fails. The no-publication assertions are held by several independent guards
  // (duty suspension, canWrite, admin.assertWrite and the publishToPlane terminal guard), so no single-site mutation
  // flips them; they stay unweakened.
  it("after dissolution a self-deletion of a stored pinned message hides the pin and publishes no Pin List edition", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "scrub me");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["scrub me"]);
      const original = await newestOfKind(community, generalId, 9);
      await community.dissolve();
      await settle();
      expect(community.state$.value.dissolved).toBe(true);
      const editions = pinEditions(community, net, generalId);
      const control = controlWraps(community, net);
      await community.deleteMessage(generalId, original);
      await dutiesSettled(community);
      expect(watching.seen.at(-1)).toEqual([]);
      expect(await community.pins(generalId)).toEqual([]);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect(controlWraps(community, net)).toBe(control);
    } finally {
      await finish(community, store, sub);
    }
  });

  // Non-vacuity: in CommunityPins.isHistoricalSelfDelete, drop the verified-pinned-entry branch (Open Question 4) so a
  // target missing from the channel store is refused as before; deleteMessage then rejects with "community dissolved"
  // and the assertion that the deletion is accepted fails.
  it("after dissolution a self-deletion of a pinned message missing from the local store still hides the pin", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "gone from the store");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)).toHaveLength(1);
      const original = await newestOfKind(community, generalId, 9);
      await community.dissolve();
      await settle();
      await community.channelStore(generalId).remove(original);
      expect(await community.channelStore(generalId).getEvent(original.id)).toBeUndefined();
      const editions = pinEditions(community, net, generalId);
      const control = controlWraps(community, net);
      await community.deleteMessage(generalId, original);
      await dutiesSettled(community);
      expect(watching.seen.at(-1)).toEqual([]);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect(controlWraps(community, net)).toBe(control);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("after dissolution a deletion of another author's pinned message is still refused", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const foreign = new PrivateKeySigner(generateSecretKey());
      const base = {
        pubkey: await foreign.getPublicKey(),
        id: "",
        kind: 9,
        content: "someone else's words",
        tags: [["channel", generalId], ["epoch", "0"]],
        created_at: Math.floor(Date.now() / 1000),
      };
      const rumor: Rumor = { ...base, id: getEventHash(base) };
      const key = new Uint8Array(32).fill(5);
      await community.setPins(generalId, [createPinProof(await sealRumor(key, foreign)(rumor), key) as PinEntry]);
      await dutiesSettled(community);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["someone else's words"]);
      await community.dissolve();
      await settle();
      const published = net.published.length;
      const error = await rejection(community.deleteMessage(generalId, rumor));
      expect((error as Error)?.message).toContain("community dissolved");
      await dutiesSettled(community);
      expect(net.published).toHaveLength(published);
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["someone else's words"]);
    } finally {
      await finish(community, store, sub);
    }
  });
});

describe("ConcordCommunity pins and expiration purge (EXP-06)", () => {
  /** Runs `body` with the clock 120 s past `expiry` (Unix seconds); real time is back before anything settles. */
  async function pastExpiry<T>(expiry: number, body: () => Promise<T>): Promise<T> {
    const time = new FakeTime(expiry * 1000 + 120_000);
    try {
      return await body();
    } finally {
      time.restore();
    }
  }

  // Non-vacuity: a purge that skipped pinned messages leaves the expired message in the channel store, so the store
  // assertion fails; a purge that published an edition fails the unchanged edition count.
  it("purge removes an expired pinned message while the pin stays hidden and no Control edition is published (EXP-06)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      await community.setMessageExpiration(3600);
      await settle();
      const id = await say(community, generalId, "disappearing pin");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      const editions = pinEditions(community, net, generalId);
      const published = net.published.length;
      const original = await newestOfKind(community, generalId, 9);
      expect(original.id).toBe(id);
      expect((await community.pins(generalId)).map((pin) => pin.text)).toEqual(["disappearing pin"]);
      const expiry = rumorExpiration(original)!;
      expect(expiry).toBeGreaterThan(Date.now() / 1000);

      await pastExpiry(expiry, async () => {
        // Display-side hiding is already in force before any purge (D-11).
        expect(await community.pins(generalId)).toEqual([]);
        expect(await community.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
        const kept = await community.channelStore(generalId).getTimeline([{ kinds: [9] }]);
        expect(kept.some((rumor) => rumor.id === id)).toBe(false);
        // The Pin List entry carries the proof, so the pin stays hidden and still shows with showExpired.
        expect(await community.pins(generalId)).toEqual([]);
        const shown = await community.pins(generalId, { showExpired: true });
        expect(shown.map((pin) => pin.text)).toEqual(["disappearing pin"]);
        expect(shown[0].expiresAt).toBe(expiry);
      });

      // Expiry and purge publish nothing: no Pin List edition and no wrap of any kind.
      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect(net.published).toHaveLength(published);
    } finally {
      await finish(community, store);
    }
  });

  // Non-vacuity (D-19): a purge that kept expired Edits on disk leaves the Edit in the store and the first store
  // assertion fails. The older-text fallback is the accepted outcome when the Pin List entry bundles no Edit.
  it("purge removes an expired newest Edit even when a pin then shows older bundled text (D-19)", async () => {
    // Upkeep is off so the entry keeps bundling only the original, which is what makes older text the fallback.
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    try {
      const id = await say(community, generalId, "original text");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await settle();
      await community.setMessageExpiration(60);
      await settle();
      await community.editMessage(generalId, id, "short lived edit");
      await settle();
      const editions = pinEditions(community, net, generalId);
      const published = net.published.length;
      const edit = await newestOfKind(community, generalId, 3302);
      const expiry = rumorExpiration(edit)!;
      expect(expiry).toBeGreaterThan(Date.now() / 1000);
      expect((await community.pins(generalId)).map((pin) => pin.text)).toEqual(["short lived edit"]);
      expect((await community.pins(generalId))[0].entry.edit).toBeUndefined();

      await pastExpiry(expiry, async () => {
        // Before the purge the expired newest Edit hides the pin (D-11).
        expect(await community.pins(generalId)).toEqual([]);
        expect(await community.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
        // Purge wins: the expired Edit text is gone from the store and never kept on disk.
        const edits = await community.channelStore(generalId).getTimeline([{ kinds: [3302] }]);
        expect(edits.some((rumor) => rumor.content === "short lived edit")).toBe(false);
        // The original never expired, and the entry bundles only it, so the pin shows the older text again.
        const shown = await community.pins(generalId);
        expect(shown.map((pin) => pin.text)).toEqual(["original text"]);
        expect(shown[0].edited).toBe(false);
      });

      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect(net.published).toHaveLength(published);
    } finally {
      await finish(community, store);
    }
  });

  // Non-vacuity (D-19): with the bundle refreshed to the Edit, a projection that read the Edit from the channel store
  // alone would fall back to the original after the purge and show the pin; the bundled proof keeps it hidden.
  it("a pin whose bundled Edit was refreshed stays hidden after its expired Edit is purged (D-19)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      const id = await say(community, generalId, "original text");
      await community.setPins(generalId, [proofFor(community, net, generalId, id)]);
      await dutiesSettled(community);
      await community.setMessageExpiration(60);
      await settle();
      await community.editMessage(generalId, id, "short lived edit");
      await dutiesSettled(community);
      // Upkeep refreshed the entry's bundle to the Edit before time moves.
      const head = pinEditionRumors(community, net, generalId).at(-1)!;
      const entries = (JSON.parse(head.content) as { entries: PinEntry[] }).entries;
      const edit = await newestOfKind(community, generalId, 3302);
      expect(verifyPinEntry(entries[0], generalId)?.edit?.id).toBe(getEventHash(edit));
      const editions = pinEditions(community, net, generalId);
      const published = net.published.length;
      const expiry = rumorExpiration(edit)!;
      const seals = (community as unknown as { pinning: { maintainer: { seals: { size(id: string): number } } } })
        .pinning.maintainer.seals;
      expect(seals.size(generalId)).toBe(1);

      await pastExpiry(expiry, async () => {
        expect(await community.pins(generalId)).toEqual([]);
        expect(await community.purgeExpiredMessages()).toBeGreaterThanOrEqual(1);
        const edits = await community.channelStore(generalId).getTimeline([{ kinds: [3302] }]);
        expect(edits.some((rumor) => rumor.content === "short lived edit")).toBe(false);
        // Non-vacuity: a purge that left the in-memory index alone keeps the expired Edit's seal, still decryptable.
        expect(seals.size(generalId)).toBe(0);
        expect(await community.pins(generalId)).toEqual([]);
        const shown = await community.pins(generalId, { showExpired: true });
        expect(shown.map((pin) => pin.text)).toEqual(["short lived edit"]);
        expect(shown[0].expiresAt).toBe(expiry);
      });

      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(editions);
      expect(net.published).toHaveLength(published);
    } finally {
      await finish(community, store);
    }
  });

  // Non-vacuity: the default stores' own expiry timers remove the Edit row and its wrap before any purge runs, so a
  // purge that forgot only the seals of rows it found itself keeps the expired Edit's seal in memory.
  it("a purge drops an Edit's seal after the stores' own expiry timers removed its row and wrap (CORD-08 §3)", async () => {
    const { community, store, generalId } = await ownerCommunity();
    let time: FakeTime | undefined;
    try {
      const id = await say(community, generalId, "original text");
      await community.setMessageExpiration(60);
      await settle();
      // The fake clock is armed before the Edit is stored, so the stores arm their expiry timers on it.
      time = new FakeTime(Date.now());
      const editing = community.editMessage(generalId, id, "short lived edit");
      await time.tickAsync(200);
      await editing;
      await time.tickAsync(200);
      const edit = await newestOfKind(community, generalId, 3302);
      const seals = (community as unknown as { pinning: { maintainer: { seals: { size(id: string): number } } } })
        .pinning.maintainer.seals;
      expect(seals.size(generalId)).toBe(1);

      await time.tickAsync(rumorExpiration(edit)! * 1000 + 1_000 - Date.now());
      // The channel store removed the Edit row on its own timer, before any purge.
      expect(await community.channelStore(generalId).getTimeline([{ kinds: [3302] }])).toEqual([]);
      expect(seals.size(generalId)).toBe(1);
      await community.purgeExpiredMessages();
      expect(seals.size(generalId)).toBe(0);
    } finally {
      time?.restore();
      await finish(community, store);
    }
  });

  /** A short-lived Edit as sent, its decoded wrap as route receives it, and the engine's route and seal index. */
  async function decodedShortLivedEdit(community: ConcordCommunity, net: FakeRelayPool, generalId: string) {
    const id = await say(community, generalId, "original text");
    await community.setMessageExpiration(60);
    await settle();
    await community.editMessage(generalId, id, "short lived edit");
    await settle();
    const edit = await newestOfKind(community, generalId, 3302);
    const planes = (community as unknown as { keys: ConcordKeys }).keys.planes;
    let decoded: ReturnType<typeof decodeWrap> = null;
    let info: PlaneInfo | undefined;
    for (const wrap of net.published) {
      info = planes.get(wrap.pubkey);
      decoded = info?.type === "channel" ? decodeWrap(wrap, info.convKey) : null;
      if (decoded && getEventHash(decoded.rumor) === getEventHash(edit)) break;
    }
    if (!decoded || !info) throw new Error("no published wrap carries the Edit");
    const internals = community as unknown as {
      pinning: { maintainer: { seals: { size(id: string): number; clear(): void } } };
      route(info: PlaneInfo, decoded: NonNullable<ReturnType<typeof decodeWrap>>): Promise<void>;
    };
    const route = () => internals.route(info!, decoded!);
    return { edit, route, seals: internals.pinning.maintainer.seals };
  }

  // Non-vacuity: route noted the seal before retention judged expiry again, so an Edit that expired between decode and
  // retention kept its seal in memory with no stored row for any purge to reach.
  it("an Edit already expired when retention judges it is never noted as a seal (CORD-08 §3)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      const { edit, route, seals } = await decodedShortLivedEdit(community, net, generalId);

      await pastExpiry(rumorExpiration(edit)!, async () => {
        await community.purgeExpiredMessages();
        expect(seals.size(generalId)).toBe(0);
        // The same Edit, decoded while live, reaches route only after its expiry passed.
        await route();
        const edits = await community.channelStore(generalId).getTimeline([{ kinds: [3302] }]);
        expect(edits.some((rumor) => rumor.content === "short lived edit")).toBe(false);
        expect(seals.size(generalId)).toBe(0);
      });
    } finally {
      await finish(community, store);
    }
  });

  // Non-vacuity: the store rounds its clock, so in the last half-second before expiry it refuses an Edit the library
  // still judges live; a seal index pruned only through rows a purge finds keeps that seal with no row to find.
  it("the seal of an Edit the store refuses in its last half-second is dropped by the next purge (CORD-08 §3, D-21)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    try {
      const { edit, route, seals } = await decodedShortLivedEdit(community, net, generalId);
      const expiry = rumorExpiration(edit)!;
      await community.channelStore(generalId).remove(edit);
      seals.clear();

      let time = new FakeTime(expiry * 1000 - 400);
      try {
        await route();
        // The library judged the Edit live and noted its seal; the store, rounding to the second, refused the row.
        expect(seals.size(generalId)).toBe(1);
        expect(await community.channelStore(generalId).getTimeline([{ kinds: [3302] }])).toEqual([]);
      } finally {
        time.restore();
      }
      time = new FakeTime(expiry * 1000);
      try {
        await community.purgeExpiredMessages();
        expect(seals.size(generalId)).toBe(0);
      } finally {
        time.restore();
      }
    } finally {
      await finish(community, store);
    }
  });
});

/** Swap the community's private duty scope for one on a fresh ManualClock set to the real time. */
function useDutyClock(community: ConcordCommunity): { clock: ManualClock; duties: DutyScope } {
  const internals = community as unknown as {
    duties: DutyScope;
    diagnostics: { reportDuty(report: never): void };
  };
  const clock = new ManualClock({ now: Date.now() });
  internals.duties.dispose();
  const duties = new DutyScope({ clock, report: (report) => internals.diagnostics.reportDuty(report as never) });
  internals.duties = duties;
  return { clock, duties };
}

/** Deliver wraps through the community's receive path, as a relay serving them would. */
async function deliverWraps(community: ConcordCommunity, wraps: NostrEvent[]): Promise<void> {
  for (const wrap of wraps) {
    await (community as unknown as { onWrap(event: NostrEvent): Promise<void> }).onWrap(structuredClone(wrap));
  }
  await settle();
}

/**
 * The general channel's Pin List as the owner's version 1 `[first]`, then a version 2 `[first, second]` signed by a
 * curator holding `PIN_MESSAGES` (with a correct `vac`) that becomes the head, and then the owner banning the curator.
 */
async function bannedCurator(
  community: ConcordCommunity,
  net: FakeRelayPool,
  channelId: string,
): Promise<{ curator: string; baseHash: string; baseVersion: number; baseEditions: number }> {
  const first = await say(community, channelId, "first");
  const second = await say(community, channelId, "second");
  const entries = [proofFor(community, net, channelId, first), proofFor(community, net, channelId, second)];
  await community.setPins(channelId, [entries[0]]);
  await settle();
  const base = pinHead(community, channelId);
  const baseEditions = pinEditions(community, net, channelId);

  const cid = hexToBytes(community.communityId);
  const signer = new PrivateKeySigner(generateSecretKey());
  const curator = await signer.getPublicKey();
  const roleId = await community.admin.createRole("curator", 2, PERM.PIN_MESSAGES);
  await community.admin.grantRoles(curator, [roleId]);
  await settle();
  const grantEid = grantLocator(cid, curator);
  const grant = community.state$.value.controlVerification!.heads.get(grantEid)!;
  const rumor = await EditionFactory.create({
    vsk: VSK.PINS,
    eid: pinsLocator(cid, channelId),
    version: base.version + 1,
    prevHash: base.hash,
    content: encodePinList(entries),
    vac: [grantEid, String(grant.version), grant.hash],
  });
  const keys = (community as unknown as { keys: ConcordKeys }).keys;
  const { wrap } = await wrapForTarget(keys, { plane: "control" }, signer, rumor, { plaintext: true });
  await deliverWraps(community, [wrap]);
  expect(pinHead(community, channelId).edition.author).toBe(curator);

  await community.ban(curator);
  await settle();
  return { curator, baseHash: base.hash, baseVersion: base.version, baseEditions };
}

describe("banned pinners (DEC-04, D-16)", () => {
  // Non-vacuity: a collateral-revert republish (a witness or writer that restored the curator's list when the curator
  // was banned) would add a Pin List edition past the witness window, so the edition count would grow.
  it("banning a pinner who edited the Pin List falls back to the earlier list and publishes no Pin List edition (D-16)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const { clock, duties } = useDutyClock(community);
      const { curator, baseHash, baseEditions } = await bannedCurator(community, net, generalId);
      expect(curator).not.toBe(community.material.owner);

      const head = pinHead(community, generalId);
      expect(head.hash).toBe(baseHash);
      expect(head.edition.author).toBe(community.material.owner);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["first"]);

      // Past the witness window of a pinner list the owner did not write: still nothing is published.
      clock.tick(30_000);
      await dutiesSettled(community);
      clock.tick(60_000);
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(baseEditions);
      expect(pinHead(community, generalId).hash).toBe(baseHash);
      expect(duties.pending).toBe(0);
    } finally {
      await finish(community, store, sub);
    }
  });

  // Non-vacuity: if the writer chained over the banned edition although an eligible head exists (or ignored the
  // reverted head), the new edition would not cite the reverted head's hash and would not become the head.
  it("the next authorized writer replaces a reverted Pin List head after a pinner is banned (D-16)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    let sub: Subscription | undefined;
    try {
      const { baseHash, baseVersion, baseEditions } = await bannedCurator(community, net, generalId);
      const third = await say(community, generalId, "third");
      await community.setPins(generalId, [proofFor(community, net, generalId, third)]);
      await dutiesSettled(community);

      const editions = pinEditionRumors(community, net, generalId);
      expect(editions).toHaveLength(baseEditions + 1);
      const written = editions.at(-1)!;
      expect(written.tags.find((t) => t[0] === "ev")?.[1]).toBe(String(baseVersion + 1));
      expect(written.tags.find((t) => t[0] === "ep")?.[1]).toBe(baseHash);
      const head = pinHead(community, generalId);
      expect(head.edition.author).toBe(community.material.owner);
      expect(head.hash).not.toBe(baseHash);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["third"]);
    } finally {
      await finish(community, store, sub);
    }
  });

  // Non-vacuity: a ban filter in self-deletion would keep the banned author's message pinned and publish no omission
  // edition, so both the pins$ and the edition-count assertions fail.
  it("a banned author's own deletion of a pinned message still hides it and is upkept once (D-16)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    const memberSigner = new PrivateKeySigner(generateSecretKey());
    const member = await memberSigner.getPublicKey();
    const author = await engineOver({ net, signer: memberSigner, pubkey: member }, community.material, {
      pinUpkeep: false,
    });
    let sub: Subscription | undefined;
    try {
      const doomed = await say(author.engine, generalId, "doomed");
      const keep = await say(community, generalId, "keeper");
      await deliverWraps(community, author.net.published);
      await community.setPins(generalId, [
        proofFor(author.engine, author.net, generalId, doomed),
        proofFor(community, net, generalId, keep),
      ]);
      await dutiesSettled(community);
      const before = pinEditions(community, net, generalId);
      // D-19: a banned author's pin is hidden by default, so this reader opts in to see the pin the ban left on the list.
      const watching = watch(community, generalId, { showBanned: true });
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text).sort()).toEqual(["doomed", "keeper"]);

      await community.ban(member);
      await dutiesSettled(community);
      expect(community.state$.value.banlist.has(member)).toBe(true);
      expect(watching.seen.at(-1)?.map((pin) => pin.text).sort()).toEqual(["doomed", "keeper"]);
      expect((await community.pins(generalId)).map((pin) => pin.text)).toEqual(["keeper"]);

      const from = author.net.published.length;
      const original = (await author.engine.channelStore(generalId).getTimeline([{ kinds: [9] }]))
        .find((rumor) => rumor.id === doomed)!;
      await author.engine.deleteMessage(generalId, original);
      await settle();
      await deliverWraps(community, author.net.published.slice(from));
      await dutiesSettled(community);

      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["keeper"]);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
      (community as unknown as { duties: DutyScope }).duties.reevaluate();
      await dutiesSettled(community);
      expect(pinEditions(community, net, generalId)).toBe(before + 1);
    } finally {
      sub?.unsubscribe();
      await finish(author.engine, author.store);
      await finish(community, store);
    }
  });

  // Non-vacuity: a reader that ignored the ban would list the banned author's pin on the first default read; one that
  // ignored `showBanned` would hide it from the opt-in reader; one that did not follow the banlist would not restore
  // it on unban. pins() and pins$ are asserted separately.
  it("a banned author's pin is hidden from pins() and pins$, shown with showBanned, and restored on unban (CORD-04 §7)", async () => {
    const { community, net, store, generalId } = await ownerCommunity();
    const memberSigner = new PrivateKeySigner(generateSecretKey());
    const member = await memberSigner.getPublicKey();
    const author = await engineOver({ net, signer: memberSigner, pubkey: member }, community.material, {
      pinUpkeep: false,
    });
    let sub: Subscription | undefined;
    let optIn: Subscription | undefined;
    try {
      const doomed = await say(author.engine, generalId, "banned author");
      const keep = await say(community, generalId, "keeper");
      await deliverWraps(community, author.net.published);
      await community.setPins(generalId, [
        proofFor(author.engine, author.net, generalId, doomed),
        proofFor(community, net, generalId, keep),
      ]);
      await dutiesSettled(community);
      const before = pinEditions(community, net, generalId);
      const texts = (pins: VerifiedPin[] | undefined) => pins?.map((pin) => pin.text).sort();
      const watching = watch(community, generalId);
      sub = watching.sub;
      const optingIn = watch(community, generalId, { showBanned: true });
      optIn = optingIn.sub;
      expect(texts(watching.seen.at(-1))).toEqual(["banned author", "keeper"]);

      await community.ban(member);
      await dutiesSettled(community);
      expect(community.state$.value.banlist.has(member)).toBe(true);
      expect(texts(await community.pins(generalId))).toEqual(["keeper"]);
      expect(texts(await community.pins(generalId, { showBanned: false }))).toEqual(["keeper"]);
      expect(texts(await community.pins(generalId, { showBanned: true }))).toEqual(["banned author", "keeper"]);
      expect(texts(watching.seen.at(-1))).toEqual(["keeper"]);
      expect(texts(optingIn.seen.at(-1))).toEqual(["banned author", "keeper"]);
      // Reader-side only: the Pin List is not rewritten by the suppression.
      expect(pinEditions(community, net, generalId)).toBe(before);

      await community.unban(member);
      await dutiesSettled(community);
      expect(community.state$.value.banlist.has(member)).toBe(false);
      expect(texts(await community.pins(generalId))).toEqual(["banned author", "keeper"]);
      expect(texts(watching.seen.at(-1))).toEqual(["banned author", "keeper"]);
      expect(pinEditions(community, net, generalId)).toBe(before);
    } finally {
      optIn?.unsubscribe();
      sub?.unsubscribe();
      await finish(author.engine, author.store);
      await finish(community, store);
    }
  });
});

describe("ConcordCommunity Pin List limits and form (CORD-04 §7)", () => {
  it("an over-cap Pin List edition still folds and chains but reads as an empty list (CORD-04 §7 Limits)", async () => {
    // Non-vacuity: refuse a violating edition in the fold and the head stays at the pin's version and the later
    // assertions on the head and the empty list fail.
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    let sub: Subscription | undefined;
    try {
      const id = await say(community, generalId, "kept pin");
      const entry = proofFor(community, net, generalId, id);
      await community.setPins(generalId, [entry]);
      await settle();
      const first = pinHead(community, generalId);
      const watching = watch(community, generalId);
      sub = watching.sub;
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["kept pin"]);

      // The first violation carries 26 entries (over the entry cap); the second more than 32,768 content bytes.
      const violations = [
        JSON.stringify({ entries: Array(26).fill({}) }),
        JSON.stringify({ entries: [entry], pad: "x".repeat(33_000) }),
      ];
      let previous = first;
      for (const [index, content] of violations.entries()) {
        const edition = await EditionFactory.create({
          vsk: VSK.PINS,
          eid: first.eid,
          version: previous.version + 1,
          prevHash: previous.hash,
          content,
        });
        await community.publishToPlane({ plane: "control" }, edition, { plaintext: true });
        await dutiesSettled(community);
        const head = pinHead(community, generalId);
        // The violating edition folds and chains like any other: it is the head, linked to its predecessor.
        expect(head.version).toBe(first.version + 1 + index);
        expect(head.prevHash).toBe(previous.hash);
        expect(head.edition.rumor.content).toBe(content);
        // Every reader treats its content as an empty list, so the entry disappears without a refusal.
        expect(community.pinList(generalId)).toEqual({ available: true, entries: [] });
        expect(await community.pins(generalId)).toEqual([]);
        expect(watching.seen.at(-1)).toEqual([]);
        previous = head;
      }

      // A writer chains over the violating head at the next version, and the list is readable again.
      await community.setPins(generalId, [entry]);
      await dutiesSettled(community);
      const head = pinHead(community, generalId);
      expect(head.version).toBe(first.version + 3);
      expect(head.prevHash).toBe(previous.hash);
      expect(watching.seen.at(-1)?.map((pin) => pin.text)).toEqual(["kept pin"]);
    } finally {
      await finish(community, store, sub);
    }
  });

  it("setPins writes the plaintext form for a public channel and the sealed form for a private one (CORD-04 §7)", async () => {
    // Non-vacuity: encode every list in the plaintext form and the private channel's edition exposes its entries.
    const { community, net, store, generalId } = await ownerCommunity((s) => s, { pinUpkeep: false });
    try {
      const publicId = await say(community, generalId, "public words");
      await community.setPins(generalId, [proofFor(community, net, generalId, publicId)]);
      await settle();
      const publicBody = JSON.parse(pinEditionRumors(community, net, generalId).at(-1)!.content);
      expect(Array.isArray(publicBody.entries)).toBe(true);
      expect(publicBody.entries).toHaveLength(1);
      expect(publicBody.sealed).toBeUndefined();

      const privateChannel = await community.createChannel("members", { private: true });
      await settle();
      const privateId = await say(community, privateChannel, "members only words");
      await community.setPins(privateChannel, [proofFor(community, net, privateChannel, privateId)]);
      await settle();
      const privateBody = JSON.parse(pinEditionRumors(community, net, privateChannel).at(-1)!.content);
      expect(typeof privateBody.sealed).toBe("string");
      expect(privateBody.epoch).toMatch(/^(0|[1-9][0-9]*)$/);
      expect(privateBody.entries).toBeUndefined();
    } finally {
      await finish(community, store);
    }
  });
});
