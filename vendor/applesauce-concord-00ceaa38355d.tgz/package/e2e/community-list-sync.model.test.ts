// The D-31 proof: a seeded, model-based interleaving test. Each seed generates one run (plan 01-07's generator), the
// runner drives a real ConcordClient through it under fake time (plan 01-09's runner) and the trace is checked against
// the six D-31 invariants. Pass conditions come only from runner-recorded entries; the client's own status appears only
// in the printed cross-check (checker BLOCKER 1). A failing seed throws its shrunk, replayable trace.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import type { NostrEvent } from "applesauce-core/helpers/event";
import { type CommunityListFragment, decodeCommunityListFragment } from "../src/helpers/community-list-wire.ts";
import { COMMUNITY_LIST_READ_RETRY } from "../src/client/community-list-read.ts";
import {
  buildMemberPool,
  checkModelTrace,
  crossCheckModelTrace,
  formatModelFailure,
  generateRun,
  type ModelRun,
  type ModelTrace,
  type ModelViolation,
  shrinkOps,
} from "../src/client/__tests__/community-list-model-core.ts";
import { ModelHarnessError, modelUserSigner, runModel } from "../src/client/__tests__/community-list-model-runner.ts";

/** Seeds per auto-save mode. 100 is the floor; raise it only when the runtime leaves headroom under the 30 s target. */
const MODEL_SEEDS_PER_MODE = 100;
/** Ops per generated run (floor 10). */
const MODEL_STEPS = 12;
/** Memberships in the pool the runs join, leave and write from other devices. */
const MODEL_MEMBERS = 4;
/** Set to a failing seed to replay only that seed (in both auto-save modes). */
const REPLAY_SEED: number | undefined = undefined;

const pool = await buildMemberPool(MODEL_MEMBERS);
const seeds = REPLAY_SEED !== undefined
  ? [REPLAY_SEED]
  : Array.from({ length: MODEL_SEEDS_PER_MODE }, (_, index) => index + 1);

/** Self-check only: synthetic violations and notes added to a real check, never used by the seeded tests. */
interface SelfCheck {
  violations(trace: ModelTrace): ModelViolation[];
  notes?(trace: ModelTrace): string[];
}

/** Run and check one run; a harness failure is rethrown at once as "harness: did not settle ...". */
async function check(run: ModelRun, self?: SelfCheck): Promise<{ trace: ModelTrace; violations: ModelViolation[] }> {
  let trace: ModelTrace;
  try {
    trace = await runModel(run, { pool });
  } catch (error) {
    if (error instanceof ModelHarnessError) throw new Error(`harness: ${error.message}`);
    throw error;
  }
  const signer = modelUserSigner(run.seed);
  const pubkey = await signer.getPublicKey();
  const decrypt = async (event: NostrEvent): Promise<CommunityListFragment> =>
    decodeCommunityListFragment(await signer.nip44.decrypt(pubkey, event.content));
  const violations = await checkModelTrace(trace, {
    decrypt,
    budget: { maxAttempts: COMMUNITY_LIST_READ_RETRY.maxAttempts },
  });
  return { trace, violations: [...violations, ...(self?.violations(trace) ?? [])] };
}

/** Check one seed; on a violation, shrink the ops and throw the printable failure for the shrunk run. */
async function checkSeed(seed: number, autoSave: boolean, self?: SelfCheck): Promise<void> {
  const run = generateRun(seed, { steps: MODEL_STEPS, autoSave, members: MODEL_MEMBERS });
  const first = await check(run, self);
  if (first.violations.length === 0) return;
  const ops = await shrinkOps(
    run.ops,
    async (candidate) => (await check({ ...run, ops: candidate }, self)).violations.length > 0,
  );
  const shrunkRun: ModelRun = { ...run, ops };
  const shrunk = await check(shrunkRun, self);
  // Runs are deterministic, so the shrunk run fails again; report the original run if it ever does not.
  const [reported, { trace, violations }] = shrunk.violations.length > 0 ? [shrunkRun, shrunk] : [run, first];
  const notes = [...crossCheckModelTrace(trace), ...(self?.notes?.(trace) ?? [])]; // diagnostic output only
  throw new Error(formatModelFailure(reported, violations, trace.entries, notes));
}

describe("Community List model-based interleavings (D-31)", () => {
  it("seeded interleavings with auto-save off keep every Community List invariant (D-31)", async () => {
    for (const seed of seeds) await checkSeed(seed, false);
  });

  it("seeded interleavings with auto-save on keep every Community List invariant (D-31)", async () => {
    for (const seed of seeds) await checkSeed(seed, true);
  });

  it("a failing model run throws its shrunk trace with cross-check notes", async () => {
    const seed = 3;
    const self: SelfCheck = {
      violations: (trace) => [{ invariant: 1, seq: trace.entries.length, message: "synthetic self-check violation" }],
      notes: () => ["synthetic self-check note"],
    };
    const error = await checkSeed(seed, false, self).then(() => undefined, (e: unknown) => e);
    expect(error).toBeInstanceOf(Error);
    const message = (error as Error).message;
    expect(message).toContain(`Community List model failure (D-31), seed ${seed}`);
    expect(message).toContain(
      `Replay: set the replay constant in e2e/community-list-sync.model.test.ts`,
    );
    expect(message).toContain("invariant 1 at seq");
    expect(message).toContain("synthetic self-check violation");
    // An always-failing predicate shrinks the run to no ops at all.
    expect(message).toContain("ops (0):");
    expect(message).toContain("Cross-check (diagnostic only)");
    expect(message).toContain("synthetic self-check note");
  });
});
