import { type NostrEvent, verifyWrappedEvent } from "applesauce-core/helpers/event";
import { CONTROL_KIND } from "../helpers/control.ts";
import { decodeWrap, EPHEMERAL_GIFT_WRAP_KIND, GIFT_WRAP_KIND, PLAINTEXT_SEAL_KIND } from "../helpers/gift-wrap.ts";
import type { PlaneInfo } from "../helpers/keys.ts";
import type { DecodedEvent } from "../types.ts";

/** CORD-01 author binding: verify current wire bytes independently of SDK/store caches. */
export function verifyReceiveEnvelope(event: NostrEvent): boolean {
  try {
    if (event.kind !== GIFT_WRAP_KIND && event.kind !== EPHEMERAL_GIFT_WRAP_KIND) return false;
    return verifyWrappedEvent(structuredClone(event));
  } catch {
    return false;
  }
}

/** Authenticate both envelopes and enforce the CORD-04 §1 control wire format. */
export function decodeReceivedWrap(event: NostrEvent, info: PlaneInfo): DecodedEvent | null {
  try {
    // structuredClone strips symbol caches; decoding must also use the verified bytes.
    const wire = structuredClone(event);
    if (!verifyWrappedEvent(wire)) return null;
    const decoded = decodeWrap(wire, info.convKey);
    if (
      info.type === "control" &&
      (decoded?.sealKind !== PLAINTEXT_SEAL_KIND || decoded.rumor.kind !== CONTROL_KIND)
    ) return null;
    return decoded;
  } catch {
    return null;
  }
}

/** Reuse authenticated bytes within one receive operation, independently of SDK symbols. */
export function createReceiveDecoder(): (event: NostrEvent, info: PlaneInfo) => DecodedEvent | null {
  const cache = new Map<string, DecodedEvent | null>();
  return (event, info) => {
    try {
      const wire = structuredClone(event);
      // Include all signed fields and the plane capability, never just an event ID.
      const key = JSON.stringify([
        wire.id,
        wire.pubkey,
        wire.created_at,
        wire.kind,
        wire.tags,
        wire.content,
        wire.sig,
        info.type,
        info.channelId,
        info.epoch,
        Array.from(info.convKey),
      ]);
      if (cache.has(key)) {
        const decoded = cache.get(key)!;
        // Store consumers may attach metadata or mutate rumors; keep cached evidence private.
        return decoded && structuredClone(decoded);
      }
      const decoded = decodeReceivedWrap(wire, info);
      if (cache.size >= 256) cache.delete(cache.keys().next().value!);
      cache.set(key, decoded && structuredClone(decoded));
      return decoded;
    } catch {
      return null;
    }
  };
}
