// Pluggable persistence + media upload for ConcordClient.

import type { AsyncRumorStore, RumorStore } from "applesauce-core";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";
import type { ISigner } from "applesauce-signers";
import { mergeRelaySets } from "applesauce-core/helpers/relays";
import { getEventHash } from "applesauce-core/helpers/event";

import type { MediaAttachment } from "../helpers/imeta.ts";
import type { PendingRefoundingRecord, PendingRefoundingStage } from "./refounding.ts";
import { evaluateCommonRelayCoverage } from "./refounding.ts";
import { deriveConcordKeys } from "../helpers/keys.ts";
import { baseRekeyGroupKey, channelRekeyGroupKey, type GroupKey } from "../helpers/crypto.ts";
import { verifyOwner } from "../helpers/community.ts";
import { foldControl } from "../helpers/control.ts";
import { decodeReceivedWrap } from "./receive.ts";
import { ENCRYPTED_SEAL_KIND } from "../helpers/gift-wrap.ts";
import {
  base64ToBytes,
  checkContinuity,
  decodeBaseWrappedKey,
  decodeWrappedKey,
  findBlob,
  groupRotations,
  parseRekey,
  rekeyLocator,
  ROOT_SCOPE_HEX,
} from "../helpers/rekey.ts";
import type { JoinMaterial } from "../types.ts";

/** Progress for a batch of attachments sent with a chat message. */
export interface ConcordUploadProgress {
  /** Files in this send operation. */
  total: number;
  /** Files fully uploaded so far, so the file being worked on is `done + 1`. */
  done: number;
  /** Which half of the current file's trip is in progress. */
  phase: "encrypting" | "uploading";
}

/** Per-file options for one {@link ConcordUploader.upload} call. */
export interface ConcordUploadOptions {
  /** Called as the file changes phase, so a UI can tell local encryption apart
   *  from the network leg of the same file rather than showing one opaque wait. */
  onProgress?: (phase: ConcordUploadProgress["phase"]) => void;
}

/** A per-plane rumor store — either the in-memory {@link RumorStore} or an
 *  {@link AsyncRumorStore} backed by an async event database. */
export type ConcordRumorStore = RumorStore | AsyncRumorStore;

/** Creates the per-plane {@link ConcordRumorStore} for a community — the persistent
 *  cache seam. Return an {@link AsyncRumorStore} backed by an async event database to
 *  persist decrypted rumors across reloads; the default is a fresh in-memory
 *  {@link RumorStore}. */
export type ConcordStoreFactory = (communityId: string, planeKey: string) => ConcordRumorStore;

/** Async key/value storage for Concord membership/key material and sync cursors. */
export interface ConcordStorage {
  /** Resolves the stored value, or `null` when the key was never written. */
  getItem(key: string): Promise<string | null>;
  /** Writes `value`, replacing any existing entry for `key`. */
  setItem(key: string, value: string): Promise<void>;
  /** Drops the entry for `key`. Removing a key that is not present is not an error. */
  removeItem(key: string): Promise<void>;
}

/** An in-memory {@link ConcordStorage}. Not durable — real clients should pass one. */
export function memoryStorage(): ConcordStorage {
  const map = new Map<string, string>();
  return {
    getItem: async (k) => map.get(k) ?? null,
    setItem: async (k, v) => void map.set(k, v),
    removeItem: async (k) => void map.delete(k),
  };
}

interface SyncStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

/** The best default storage: wrapped `localStorage` if present, else memory. */
export function defaultStorage(): ConcordStorage {
  const ls = (globalThis as { localStorage?: SyncStorage }).localStorage;
  if (!ls) return memoryStorage();
  return {
    getItem: async (k) => ls.getItem(k),
    setItem: async (k, v) => void ls.setItem(k, v),
    removeItem: async (k) => void ls.removeItem(k),
  };
}

const BYTE_MARKER = "$concordBytes";

function encodePending(record: PendingRefoundingRecord): string {
  return JSON.stringify(
    record,
    (_key, value) => value instanceof Uint8Array ? { [BYTE_MARKER]: bytesToHex(value) } : value,
  );
}

function decodePending(value: string): unknown {
  return JSON.parse(value, (_key, item) => {
    if (
      item &&
      typeof item === "object" &&
      Object.keys(item).length === 1 &&
      typeof item[BYTE_MARKER] === "string" &&
      /^[0-9a-f]*$/i.test(item[BYTE_MARKER]) &&
      item[BYTE_MARKER].length % 2 === 0
    ) {
      return Uint8Array.from(item[BYTE_MARKER].match(/.{2}/g)?.map((byte: string) => Number.parseInt(byte, 16)) ?? []);
    }
    return item;
  });
}

function isPendingRecord(value: unknown, communityId: string): value is PendingRefoundingRecord {
  if (!value || typeof value !== "object") return false;
  const record = value as Partial<PendingRefoundingRecord>;
  return (
    record.version === 1 &&
    record.communityId === communityId &&
    Number.isSafeInteger(record.priorEpoch) &&
    record.priorEpoch! >= 0 && Number.isSafeInteger(record.plan?.newEpoch) &&
    typeof record.rotationId === "string" &&
    ["prepared", "root-confirmed", "mandatory-confirmed", "adopted", "snapshot-attempted"].includes(
      record.stage ?? "",
    ) &&
    !!record.plan &&
    record.plan.newEpoch === record.priorEpoch! + 1 &&
    record.plan.next?.material?.community_id === communityId &&
    record.plan.next?.material?.root_epoch === record.plan.newEpoch &&
    record.plan.rekeyWraps?.[0]?.id === record.rotationId &&
    Array.isArray(record.mandatoryEvidence) &&
    Array.isArray(record.commonRelays) &&
    Array.isArray(record.warnings)
  );
}

function sameGroup(actual: GroupKey, expected: GroupKey): boolean {
  return actual?.pk === expected.pk && actual.sk instanceof Uint8Array && actual.convKey instanceof Uint8Array &&
    bytesToHex(actual.sk) === bytesToHex(expected.sk) && bytesToHex(actual.convKey) === bytesToHex(expected.convKey);
}

/** Reopen original envelopes and reconstruct derived state, never serialized Map objects (CORD-06 §§1–3). */
async function authenticatePending(
  record: PendingRefoundingRecord,
  signer: ISigner,
  actor: string,
  assertCurrent?: () => void,
): Promise<PendingRefoundingRecord> {
  const invalid = () => {
    throw new Error("invalid pending refounding operation");
  };
  try {
    const plan = record.plan;
    const material = plan.next.material;
    if (!verifyOwner(material) || !Array.isArray(material.channels) || !Array.isArray(material.held_roots)) invalid();
    const prior = material.held_roots!.find((h) =>
      h.epoch === record.priorEpoch &&
      baseRekeyGroupKey(hexToBytes(h.key), hexToBytes(record.communityId), plan.newEpoch).pk === plan.rekeyKey.pk
    );
    if (!prior) invalid();
    const priorMaterial: JoinMaterial = { ...material, community_root: prior!.key, root_epoch: prior!.epoch };
    delete priorMaterial.control_pk;
    delete priorMaterial.control_root;
    if (prior!.control_pk !== undefined) priorMaterial.control_pk = prior!.control_pk;
    if (prior!.control_root !== undefined) priorMaterial.control_root = prior!.control_root;
    const priorKeys = deriveConcordKeys(priorMaterial, []);
    const rekeyKey = baseRekeyGroupKey(hexToBytes(prior!.key), hexToBytes(record.communityId), plan.newEpoch);
    if (!sameGroup(plan.rekeyKey, rekeyKey)) invalid();
    const initialNext = deriveConcordKeys(material, []);
    const historicalControl = !material.control_pk && !material.control_root && !record.preparation &&
      !plan.next.control.signing && sameGroup(plan.next.control as GroupKey, initialNext.control.signing!);
    if (
      plan.next.control.pk !== initialNext.control.pk ||
      bytesToHex(plan.next.control.convKey) !== bytesToHex(initialNext.control.convKey) ||
      !sameGroup(plan.next.guestbook, initialNext.guestbook) ||
      !sameGroup(plan.next.dissolved, initialNext.dissolved) ||
      !sameGroup(plan.next.nextBaseRekey.key, initialNext.nextBaseRekey.key) ||
      plan.next.nextBaseRekey.epoch !== initialNext.nextBaseRekey.epoch ||
      (!historicalControl && (!!plan.next.control.signing !== !!initialNext.control.signing)) ||
      (!historicalControl && initialNext.control.signing &&
        !sameGroup(plan.next.control.signing!, initialNext.control.signing))
    ) invalid();
    const ids = new Set<string>();
    const decode = (
      wrap: typeof plan.rekeyWraps[number],
      pk: string,
      convKey: Uint8Array,
      type: "control" | "guestbook" | "rekey",
    ) => {
      if (ids.has(wrap.id) || wrap.pubkey !== pk) return invalid();
      ids.add(wrap.id);
      const decoded = decodeReceivedWrap(wrap, { type, convKey });
      if (
        !decoded || decoded.rumor.pubkey !== decoded.author || decoded.rumor.id !== getEventHash(decoded.rumor) ||
        (type !== "control" && decoded.sealKind !== ENCRYPTED_SEAL_KIND)
      ) return invalid();
      return decoded;
    };
    const roots = plan.rekeyWraps.map((wrap) => decode(wrap, rekeyKey.pk, rekeyKey.convKey, "rekey"));
    const parsedRoots = roots.map((d) => parseRekey(d));
    if (parsedRoots.some((p) => !p || p.rotator !== actor || p.scopeIdHex !== ROOT_SCOPE_HEX)) invalid();
    const sets = groupRotations(parsedRoots.map((p) => p!));
    if (
      sets.length !== 1 || !sets[0].complete || roots.length !== sets[0].chunkCount ||
      sets[0].newEpoch !== BigInt(plan.newEpoch) ||
      !checkContinuity(sets[0], BigInt(record.priorEpoch), hexToBytes(prior!.key)).ok
    ) invalid();
    const recipientBlob = findBlob(sets[0], rekeyLocator(actor, actor, ROOT_SCOPE_HEX, BigInt(plan.newEpoch)));
    if (!recipientBlob) invalid();
    const plain = await signer.nip44!.decrypt(actor, recipientBlob!.wrapped);
    assertCurrent?.();
    const base = decodeBaseWrappedKey(base64ToBytes(plain), BigInt(plan.newEpoch), hexToBytes(record.communityId));
    if (
      bytesToHex(base.community_root) !== material.community_root ||
      (base.control_pk && bytesToHex(base.control_pk)) !== material.control_pk ||
      (base.control_root && bytesToHex(base.control_root)) !== material.control_root
    ) invalid();
    if (record.preparation) {
      const recipients = record.preparation.recipients;
      const request = JSON.parse(record.preparation.request) as {
        recipients: string[];
        excluded: string[];
        channels: Array<[string, string[]]>;
      };
      if (
        new Set(recipients.map((r) => r.pubkey)).size !== recipients.length ||
        recipients.length !== parsedRoots.flatMap((p) => p!.blobs).length ||
        JSON.stringify([...recipients.map((r) => r.pubkey)].sort()) !== JSON.stringify(request.recipients) ||
        JSON.stringify([...record.preparation.excluded].sort()) !== JSON.stringify(request.excluded) ||
        recipients.some((r) => record.preparation!.excluded.includes(r.pubkey)) ||
        !recipients.some((r) => r.pubkey === actor && r.staff) || !material.control_pk || !material.control_root
      ) invalid();
      for (const recipient of recipients) {
        const blob = findBlob(sets[0], rekeyLocator(actor, recipient.pubkey, ROOT_SCOPE_HEX, BigInt(plan.newEpoch)));
        if (!blob || typeof recipient.staff !== "boolean") invalid();
        const text = await signer.nip44!.decrypt(recipient.pubkey, blob!.wrapped);
        assertCurrent?.();
        const bytes = base64ToBytes(text);
        const delivered = decodeBaseWrappedKey(bytes, BigInt(plan.newEpoch), hexToBytes(record.communityId));
        if (
          bytes.length !== (recipient.staff ? 136 : 104) ||
          bytesToHex(delivered.community_root) !== material.community_root ||
          (delivered.control_pk && bytesToHex(delivered.control_pk)) !== material.control_pk ||
          (delivered.control_root && bytesToHex(delivered.control_root)) !==
            (recipient.staff ? material.control_root : undefined)
        ) invalid();
      }
    }
    const channelKeys = plan.channelRekeyKeys.map((key) => {
      const channel = priorMaterial.channels.find((c) =>
        channelRekeyGroupKey(hexToBytes(prior!.key), hexToBytes(c.id), c.epoch + 1).pk === key.pk
      );
      if (!channel) return invalid();
      const expected = channelRekeyGroupKey(hexToBytes(prior!.key), hexToBytes(channel.id), channel.epoch + 1);
      if (!sameGroup(key, expected)) return invalid();
      return { channel, key: expected };
    });
    const channelDecoded = plan.channelRekeyWraps.map((wrap) => {
      const match = channelKeys.find(({ key }) => key.pk === wrap.pubkey);
      if (!match) return invalid();
      return decode(wrap, match.key.pk, match.key.convKey, "rekey");
    });
    const parsedChannels = channelDecoded.map((d) => parseRekey(d));
    if (parsedChannels.some((p) => !p || p.rotator !== actor)) invalid();
    const channelSets = groupRotations(parsedChannels.map((p) => p!));
    if (
      channelSets.length !== channelKeys.length ||
      new Set(channelKeys.map((c) => c.channel.id)).size !== channelKeys.length
    ) invalid();
    if (
      record.preparation && JSON.stringify(record.preparation.channelIds.slice().sort()) !==
        JSON.stringify(channelKeys.map((c) => c.channel.id).sort())
    ) invalid();
    const originalChannelSecrets = new Map<string, string>();
    for (const set of channelSets) {
      const match = channelKeys.find(({ channel }) => channel.id === set.scopeIdHex);
      if (
        !match || !set.complete || set.newEpoch !== BigInt(match.channel.epoch + 1) ||
        !checkContinuity(set, BigInt(match.channel.epoch), hexToBytes(match.channel.key)).ok ||
        JSON.stringify(set.vac) !== JSON.stringify(sets[0].vac)
      ) invalid();
      const blob = findBlob(set, rekeyLocator(actor, actor, set.scopeIdHex, set.newEpoch));
      if (!blob) invalid();
      const text = await signer.nip44!.decrypt(actor, blob!.wrapped);
      assertCurrent?.();
      originalChannelSecrets.set(
        set.scopeIdHex,
        bytesToHex(decodeWrappedKey(base64ToBytes(text), hexToBytes(set.scopeIdHex), set.newEpoch)),
      );
      if (record.preparation) {
        const request = JSON.parse(record.preparation.request) as { channels: Array<[string, string[]]> };
        const membership = request.channels.find(([id]) => id === set.scopeIdHex)?.[1];
        if (!membership) invalid();
        const recipients = [...new Set([actor, ...membership!])].filter((pk) =>
          !record.preparation!.excluded.includes(pk)
        );
        if ([...set.chunks.values()].flatMap((chunk) => chunk.blobs).length !== recipients.length) invalid();
        for (const recipient of recipients) {
          const delivered = findBlob(set, rekeyLocator(actor, recipient, set.scopeIdHex, set.newEpoch));
          if (!delivered) invalid();
          const text = await signer.nip44!.decrypt(recipient, delivered!.wrapped);
          assertCurrent?.();
          if (
            bytesToHex(decodeWrappedKey(base64ToBytes(text), hexToBytes(set.scopeIdHex), set.newEpoch)) !==
              originalChannelSecrets.get(set.scopeIdHex)
          ) invalid();
        }
      }
    }
    const repairedIds = new Set<string>();
    for (const child of record.channelRepairs ?? []) {
      const predecessor = child.predecessor;
      if (
        repairedIds.has(predecessor.id) || !originalChannelSecrets.has(predecessor.id) ||
        !verifyOwner(child.winner) || child.winner.community_id !== record.communityId ||
        child.winner.root_epoch !== plan.newEpoch || child.winner.community_root >= material.community_root ||
        child.winner.prev_root !== prior!.key || !["prepared", "confirmed", "adopted"].includes(child.stage) ||
        child.next.id !== predecessor.id || child.next.epoch !== predecessor.epoch + 1 ||
        child.next.key !== originalChannelSecrets.get(predecessor.id) ||
        !child.winner.channels.some((c) =>
          c.id === predecessor.id && c.key === predecessor.key && c.epoch === predecessor.epoch
        ) ||
        !child.next.held?.some((h) => h.epoch === predecessor.epoch && h.key === predecessor.key)
      ) invalid();
      deriveConcordKeys(child.winner, []); // Validates the complete held control pair.
      repairedIds.add(predecessor.id);
      const expected = channelRekeyGroupKey(
        hexToBytes(child.winner.community_root),
        hexToBytes(predecessor.id),
        child.next.epoch,
      );
      if (!sameGroup(child.rekeyKey, expected)) invalid();
      const parsed = child.wraps.map((wrap) => parseRekey(decode(wrap, expected.pk, expected.convKey, "rekey")));
      if (!parsed.length || parsed.some((p) => !p || p.rotator !== actor || p.scopeIdHex !== predecessor.id)) invalid();
      const grouped = groupRotations(parsed.map((p) => p!));
      if (
        grouped.length !== 1 || !grouped[0].complete || grouped[0].chunkCount !== parsed.length ||
        grouped[0].newEpoch !== BigInt(child.next.epoch) ||
        !checkContinuity(grouped[0], BigInt(predecessor.epoch), hexToBytes(predecessor.key)).ok
      ) invalid();
      if (!record.preparation) invalid();
      const request = JSON.parse(record.preparation!.request) as { channels: Array<[string, string[]]> };
      const membership = request.channels.find(([id]) => id === predecessor.id)?.[1];
      if (!membership) invalid();
      const recipients = [...new Set([actor, ...membership!])].filter((pk) =>
        !record.preparation!.excluded.includes(pk)
      );
      if ([...grouped[0].chunks.values()].flatMap((chunk) => chunk.blobs).length !== recipients.length) invalid();
      for (const recipient of recipients) {
        const blob = findBlob(grouped[0], rekeyLocator(actor, recipient, predecessor.id, BigInt(child.next.epoch)));
        if (!blob) invalid();
        const text = await signer.nip44!.decrypt(recipient, blob!.wrapped);
        assertCurrent?.();
        if (
          bytesToHex(decodeWrappedKey(base64ToBytes(text), hexToBytes(predecessor.id), BigInt(child.next.epoch))) !==
            child.next.key
        ) invalid();
      }
      const evidenceIds = new Set<string>();
      const relays = mergeRelaySets(record.protocolRelays ?? []);
      for (const row of child.evidence) {
        if (
          !child.wraps.some((w) => w.id === row.artifact.id) || row.artifact.kind !== "channel-rekey" ||
          evidenceIds.has(row.artifact.id) || !Array.isArray(row.causes) ||
          new Set(row.relays.map((r) => r.relay)).size !== row.relays.length ||
          row.relays.some((r) =>
            !relays.includes(r.relay) || !["accepted", "rejected", "missing", "publish-failed"].includes(r.status)
          )
        ) invalid();
        evidenceIds.add(row.artifact.id);
        row.acceptedRelays = row.relays.filter((r) => r.status === "accepted").map((r) => r.relay);
      }
      const coverage = evaluateCommonRelayCoverage(
        child.wraps.map((wrap) => ({
          artifact: { id: wrap.id, kind: "channel-rekey" as const },
          responses: (child.evidence.find((row) => row.artifact.id === wrap.id)?.acceptedRelays ?? []).map((from) => ({
            from,
            ok: true,
          })),
        })),
        relays,
      );
      if (!coverage.accepted) child.stage = "prepared";
      child.rekeyKey = expected;
    }
    const control = plan.compactionWraps.map((wrap) =>
      decode(wrap, initialNext.control.pk, initialNext.control.convKey, "control")
    );
    const folded = foldControl(control, material);
    // Current authorization is rechecked by the owning community's verified fold.
    // A compacted old pin may need retained history unavailable to this standalone store.
    if (!folded.metadata) invalid();
    if (record.preparation) {
      const fingerprint = JSON.parse(record.preparation.fingerprint) as { originals: string[] };
      if (JSON.stringify(control.map((d) => JSON.stringify(d.seal)).sort()) !== JSON.stringify(fingerprint.originals)) {
        invalid();
      }
    }
    for (const wrap of plan.snapshotWraps) {
      const decoded = decode(wrap, initialNext.guestbook.pk, initialNext.guestbook.convKey, "guestbook");
      if (decoded.author !== actor) invalid();
    }
    const next = deriveConcordKeys(material, folded.channels, priorKeys);
    const mandatory = [
      ...plan.rekeyWraps.map((w) => ({ id: w.id, kind: "root-rekey" as const })),
      ...plan.channelRekeyWraps.map((w) => ({ id: w.id, kind: "channel-rekey" as const })),
      ...plan.compactionWraps.map((w) => ({ id: w.id, kind: "control-compaction" as const })),
    ];
    const recordedSets = record.mandatoryEvidence.map((e) => mergeRelaySets(e.relays.map((r) => r.relay)).sort());
    if (!record.protocolRelays && recordedSets.some((s) => JSON.stringify(s) !== JSON.stringify(recordedSets[0]))) {
      invalid();
    }
    const protocolRelays = record.protocolRelays ? mergeRelaySets(record.protocolRelays) : recordedSets[0];
    const seenEvidence = new Set<string>();
    for (const row of record.mandatoryEvidence) {
      if (
        !mandatory.some((a) => a.id === row.artifact.id && a.kind === row.artifact.kind) ||
        seenEvidence.has(row.artifact.id) || !Array.isArray(row.causes) ||
        row.relays.some((r) =>
          !protocolRelays?.includes(r.relay) ||
          !["accepted", "rejected", "missing", "publish-failed"].includes(r.status)
        ) ||
        new Set(row.relays.map((r) => r.relay)).size !== row.relays.length
      ) invalid();
      seenEvidence.add(row.artifact.id);
    }
    const coverage = (artifacts: typeof mandatory) =>
      evaluateCommonRelayCoverage(
        artifacts.map((artifact) => ({
          artifact,
          responses: (record.mandatoryEvidence.find((r) => r.artifact.id === artifact.id)?.relays ?? [])
            .filter((r) => r.status === "accepted").map((r) => ({ from: r.relay, ok: true })),
        })),
        protocolRelays ?? [],
      );
    const all = coverage(mandatory);
    const root = coverage(mandatory.filter((a) => a.kind === "root-rekey"));
    // Downgrade unsupported claims; promotion needs a successful durable stage write.
    const stage = !root.accepted
      ? "prepared"
      : !all.accepted && record.stage !== "prepared"
      ? "root-confirmed"
      : record.stage;
    return {
      ...record,
      ...(protocolRelays ? { protocolRelays } : {}),
      stage,
      commonRelays: all.commonRelays,
      mandatoryEvidence: record.mandatoryEvidence.map((e) => ({
        ...e,
        acceptedRelays: e.relays.filter((r) => r.status === "accepted").map((r) => r.relay),
      })),
      plan: { ...plan, next, rekeyKey, channelRekeyKeys: channelKeys.map((c) => c.key) },
    };
  } catch {
    assertCurrent?.();
    throw new Error("invalid pending refounding operation");
  }
}

/** Authenticated, self-encrypted durable storage for one pending Refounding. */
export class PendingRefoundingStore {
  /** The storage key in use — derived from a hash of `pubkey:communityId`, so two
   *  communities (or two accounts in one app) can never overwrite each other's
   *  pending Refounding, and the key itself discloses neither value. */
  readonly key: string;

  /**
   * Binds a store to one account-and-community pair. Nothing is read until {@link load}.
   *
   * @param storage Where the encrypted record lands.
   * @param signer Must support NIP-44: a pending Refounding carries the next epoch's
   *   key material, so the record is self-encrypted to `pubkey` rather than written
   *   in plaintext next to ordinary app state.
   * @param pubkey The record owner, and the NIP-44 conversation counterparty with itself.
   * @param communityId Bound into both the key and the record, so a record belonging to
   *   another community is rejected on load instead of being half-applied.
   * @param key Overrides the derived storage key; for tests and for apps that namespace storage themselves.
   */
  constructor(
    private readonly storage: ConcordStorage,
    private readonly signer: ISigner,
    private readonly pubkey: string,
    private readonly communityId: string,
    key?: string,
  ) {
    this.key = key ?? `concord:pending-refounding:v1:${bytesToHex(sha256(utf8ToBytes(`${pubkey}:${communityId}`)))}`;
  }

  /** Decrypts the stored record, or `null` when none is pending. Throws rather than
   *  returning a partial record if it fails validation for this community — a
   *  half-trusted Refounding is more dangerous than no resumption at all. */
  async load(assertCurrent?: () => void): Promise<PendingRefoundingRecord | null> {
    assertCurrent?.();
    const ciphertext = await this.storage.getItem(this.key);
    assertCurrent?.();
    if (ciphertext === null) return null;
    if (!this.signer.nip44) throw new Error("pending refounding protection requires NIP-44");
    const plaintext = await this.signer.nip44.decrypt(this.pubkey, ciphertext);
    assertCurrent?.();
    let record: unknown;
    try {
      record = decodePending(plaintext);
    } catch {
      throw new Error("invalid pending refounding record for community");
    }
    if (!isPendingRecord(record, this.communityId)) throw new Error("invalid pending refounding record for community");
    return await authenticatePending(record, this.signer, this.pubkey, assertCurrent);
  }

  /** Validates, then self-encrypts and writes the record. Validating on the way out as
   *  well as on the way in keeps a malformed record from ever reaching storage. */
  async save(record: PendingRefoundingRecord, assertCurrent?: () => void): Promise<void> {
    assertCurrent?.();
    if (!isPendingRecord(record, this.communityId)) throw new Error("invalid pending refounding record for community");
    if (!this.signer.nip44) throw new Error("pending refounding protection requires NIP-44");
    const ciphertext = await this.signer.nip44.encrypt(this.pubkey, encodePending(record));
    assertCurrent?.();
    await this.storage.setItem(this.key, ciphertext);
    try {
      assertCurrent?.();
    } catch (error) {
      // A generic storage write cannot be cancelled. Retain explicit blocked work,
      // never turn a saved stale ciphertext into fresh authorization (CORD-06 §3).
      await this.save({ ...record, blocked: "stale-preparation" });
      throw error;
    }
  }

  /** Advances the record to `stage`, optionally folding in newly gathered evidence, and
   *  returns what was persisted — callers continue from the stored value rather than
   *  from their own now-stale copy. */
  async updateStage(
    record: PendingRefoundingRecord,
    stage: PendingRefoundingStage,
    updates: Partial<Pick<PendingRefoundingRecord, "mandatoryEvidence" | "commonRelays" | "warnings">> = {},
    assertCurrent?: () => void,
  ): Promise<PendingRefoundingRecord> {
    const next = { ...record, ...updates, stage };
    await this.save(next, assertCurrent);
    return next;
  }

  /** Clears the pending record, once the Refounding has completed or been abandoned. */
  remove(): Promise<void> {
    return this.storage.removeItem(this.key);
  }

  /** Preserve a completed losing parent's original signed artifacts in protected
   * history before clearing its pending slot (CORD-06 §3).
   * @param record Immutable parent plus completed channel repair evidence.
   * @param assertCurrent Rechecks the owning engine after each storage/signing await.
   * @returns The historical key, which an explicitly keyed store can reopen.
   */
  async archive(record: PendingRefoundingRecord, assertCurrent?: () => void): Promise<string> {
    const key = `${this.key}:recovered:${record.rotationId}`;
    const history = new PendingRefoundingStore(this.storage, this.signer, this.pubkey, this.communityId, key);
    await history.save(record, assertCurrent);
    return key;
  }
}

/**
 * Encrypts and uploads chat/community media, returning the NIP-92 attachment
 * (url + per-file `encryption` + `originalSha256`) that rides in the message's
 * imeta tag / a community `BlobPointer`. Injected so the core client carries no
 * Blossom dependency; the app supplies a Blossom-backed implementation.
 */
export interface ConcordUploader {
  /** Encrypts and uploads one file for `communityId`, resolving the attachment
   *  descriptor the caller embeds. Implementations must not upload plaintext:
   *  the returned `encryption` material is what makes the blob readable. */
  upload(file: Blob, communityId: string, options?: ConcordUploadOptions): Promise<MediaAttachment>;
}

/** Which stream a cached rumor was decoded from. Chat is capped per channel; the
 *  other two planes are small enough to keep whole (see {@link MAX_CHANNEL_CACHE}). */
export type CachePlane = "control" | "guestbook" | "channel";

/** One decoded rumor held in the reload-surviving cache. */
export interface CachedEntry {
  /** The stream this rumor came from. */
  plane: CachePlane;
  /** Which channel, for `"channel"` entries only. */
  channelId?: string;
  /** The decoded rumor plus its verified author — never a raw kind-1059 wrap, so
   *  restoring the cache cannot reintroduce an unverified envelope. */
  decoded: import("../types.ts").DecodedEvent;
}

/** Cap cached chat per channel; control/guestbook are small and kept whole. */
export const MAX_CHANNEL_CACHE = 300;
