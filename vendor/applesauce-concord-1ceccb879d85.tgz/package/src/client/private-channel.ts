// ConcordPrivateChannel — the sub-community engine for ONE private channel.
//
// A private channel is keyed independently of the community_root (CORD-03) at its
// own epoch, so it syncs and rotates on its own lifecycle, lifted out of the
// community epoch walk. This mirrors ConcordCommunity's shape — derive keys →
// route decoded wraps into a RumorStore → epoch-atomic sync → live subscription →
// follow channel Rekeys — scoped to a single channel. It carries no fold logic:
// consumers read ban-aware `timeline()` inputs and retain `store` for diagnostics.

import type { Debugger, EventStore } from "applesauce-core";
import {
  BehaviorSubject,
  combineLatest,
  type Observable,
  of,
  ReplaySubject,
  shareReplay,
  type Subject,
  type Subscription,
  switchMap,
  takeUntil,
} from "rxjs";
import { hexToBytes } from "@noble/hashes/utils.js";
import type { NostrEvent, Rumor } from "applesauce-core/helpers/event";
import type { Filter } from "applesauce-core/helpers/filter";
import type { ISigner } from "applesauce-signers";
import type { RelayPool } from "applesauce-relay";
import { mergeRelaySets } from "applesauce-core/helpers/relays";

import { logger } from "../logger.ts";
import { connectedRelays$, StreamSigners } from "./auth.ts";
import { ExtraRelays, type ExtraRelaysOption } from "../helpers/relays.ts";
import {
  type ChannelKeys,
  type ChannelRekeyOutcome,
  deriveChannelKeys,
  type PlaneInfo,
  readChannelRekey,
} from "../helpers/keys.ts";
import { EPHEMERAL_GIFT_WRAP_KIND, GIFT_WRAP_KIND } from "../helpers/gift-wrap.ts";
import { createReceiveDecoder } from "./receive.ts";
import { checkChatBinding } from "../helpers/chat.ts";
import { retainChannelInput } from "./channel-input.ts";
import type {
  ChannelKey,
  ConcordPrivateChannelStatus,
  ConcordSyncPhase,
  DecodedEvent,
  JoinMaterial,
} from "../types.ts";
import type { ConcordRumorStore } from "./storage.ts";
import { syncAuthors } from "./sync.ts";
import { channelLiveAuthors, type ChannelSyncContext, syncChannelEpochs } from "./channel-sync.ts";
import { RotationCoordinator, type RotationDiagnostic } from "./rotation.ts";
import { ConcordChatTimelineModel } from "../models/chat.ts";

/** Options for a {@link ConcordPrivateChannel}, wired by {@link ConcordCommunity}. */
export interface ConcordPrivateChannelOptions {
  /** The channel's key material (independent secret + own epoch chain). */
  channelKey: ChannelKey;
  /** Accessor for the community's CURRENT material — its root/held_roots move on a
   *  Refounding and the channel-rekey address keys on them. */
  material: () => JoinMaterial;
  /** The user's signer, used for NIP-42 auth and for opening channel rekey blobs. */
  signer: ISigner;
  /** The logged-in user's hex pubkey — the identity rekey removal checks are made against. */
  pubkey: string;
  /** Relay pool this channel's own requests and subscriptions run on. */
  pool: RelayPool;
  /** Shared wrap-level store (dedup + NIP-77 local store). */
  eventStore: EventStore;
  /** The `channel:<id>` rumor store (owned by the community's store factory). */
  store: ConcordRumorStore;
  /** Current resolved community bans for {@link ConcordPrivateChannel.timeline}.
   * Community-managed engines receive the parent's current ban stream. A standalone
   * engine must supply and maintain this source to enforce bans; omission explicitly
   * uses an empty ban set and performs no author exclusion. */
  bans?: Observable<ReadonlySet<string>>;
  /** The channel's protocol relay set. Keeps its exact current meaning — never
   *  mutated, reassigned, or widened by `extraRelays` (D-14). */
  relays: string[];
  /** Additional transport-only relays threaded down from `ConcordClientOptions`
   *  (via the community), unioned into every request/subscription/publish/auth
   *  target this channel engine dials — but never written into any published
   *  content. Purely additive: with no extras configured, {@link ExtraRelays.merge}'s
   *  identity fast path returns `relays` completely unchanged (D-14); it never
   *  substitutes for `relays`. When extras ARE configured, the merged transport
   *  set is normalized and deduplicated (`mergeRelaySets`), which changes the
   *  shape of relay-target strings and `pool.status$` lookup keys for that
   *  configuration. */
  extraRelays?: ExtraRelaysOption;
  /** May `rotator` rotate this channel at all — holds `MANAGE_CHANNELS` (CORD-04).
   *  Gates adoption and validity. */
  isAuthorized: (rotator: string) => boolean;
  /** Current authority/evidence notifications retry retained rekeys without a
   * retransmission. Standalone callbacks must check current bans, unsuspended
   * permission support, strict removal rank and exact historical Grant pins.
   * Return snapshot-bound callbacks (for example via getters) so a decision's
   * callbacks remain coherent across asynchronous blob decryption. */
  authorityChanges?: Observable<unknown>;
  /** May `rotator` remove US from the channel — `MANAGE_CHANNELS` AND strictly
   *  outranks us (CORD-04). Gates only the removal outcome, so an under-ranked
   *  manager can't sever us. When omitted, any authorized rotator may remove us. */
  canRemoveSelf?: (rotator: string) => boolean;
  /** vac verification against the folded Roster (CORD-04 D-08/D-12): a
   *  non-owner rotation must cite its Grant, structurally resolving to
   *  `grantLocator` AND still holding `MANAGE_CHANNELS` in the CURRENT folded
   *  Roster; the owner is exempt. Gates candidacy entirely (both adopt and
   *  removed), independent of `isAuthorized`. */
  verifyVac?: (rotator: string, vac: [string, string, string] | undefined) => boolean;
  /** Called when the channel key rolls forward (a Rekey) so the community persists it. */
  onKeyChange?: (channelKey: ChannelKey) => void | Promise<void>;
  /** Internal two-phase parent boundary: persist first, then return the
   * synchronous parent-state commit that accompanies the channel commit. */
  prepareKeyChange?: (channelKey: ChannelKey) => Promise<() => void>;
  /** Called when a channel Rekey excludes us from the channel. */
  onRemoved?: (channelId: string) => void;
  /** A custom debug logger (defaults to the "applesauce:concord" namespace). */
  logger?: Debugger;
  /** Shared diagnostics sink, so a parent community can surface every channel's rotation
   *  decisions on one stream. When omitted the coordinator owns a private subject. */
  rotationDiagnostics?: Subject<RotationDiagnostic>;
}

/**
 * The sub-community engine for one private channel. A private channel is keyed
 * independently of the community root (CORD-03) at its own epoch, so it syncs and rotates
 * on its own lifecycle rather than inside the community epoch walk. Carries no fold logic:
 * consumers read {@link timeline} for ban-aware inputs and {@link store} for raw diagnostics.
 */
export class ConcordPrivateChannel {
  /** The channel's current epoch (bumps on each adopted Rekey). */
  readonly epoch$: BehaviorSubject<number>;
  /** The channel's sync-lifecycle phase (idle → syncing → live; removed/error). */
  readonly phase$: BehaviorSubject<ConcordSyncPhase> = new BehaviorSubject<ConcordSyncPhase>("idle");
  /** The last sync error message, or null. */
  readonly error$: BehaviorSubject<string | null> = new BehaviorSubject<string | null>(null);
  /** Whether any of the channel's relays (plus any configured `extraRelays`) has
   *  an open socket — derived from the merged transport set (D-07). Because this
   *  is an any-of check, an always-up app-local extra keeps this reporting
   *  connected even when every real channel relay is down; an accepted,
   *  documented consequence of routing status through the merged set, not a
   *  defect. */
  readonly connected$: Observable<boolean>;
  /** A flat snapshot of the channel's status, for UI to react to as one value. */
  readonly status$: Observable<ConcordPrivateChannelStatus>;

  /** The channel's debug logger — `options.logger` when threaded from the parent
   *  community, otherwise the `applesauce:concord` module base (D-01/D-02). */
  private readonly log: Debugger;
  /** The `:sync` sub-logger, derived ONCE in the constructor — handed to every
   *  {@link ChannelSyncContext} this instance builds. `syncContext()` runs once
   *  per `walk()` AND once per adopted rekey in `catchUpCurrent()`, so
   *  `.extend()`ing there would reallocate on every rotation. */
  private readonly syncLog: Debugger;
  /** The `:sync:decode` per-dropped-wrap logger (D-07), derived ONCE in the
   *  constructor — never re-`.extend()`d per wrap. */
  private readonly decodeLog: Debugger;
  private readonly opts: ConcordPrivateChannelOptions;
  private readonly timelineDisposed$ = new ReplaySubject<void>(1);
  private readonly bans: Observable<ReadonlySet<string>>;
  /** The per-engine transport-only extras holder (D-04) — merges into every
   *  network target this engine dials; `opts.relays` itself is never touched. */
  private readonly extras: ExtraRelays;
  /** This channel's own pubkey→signer holder (D-02/D-06) — constructed here,
   *  never shared with the parent community (T-15-01). */
  private readonly signers: StreamSigners;
  private channelKey: ChannelKey;
  private keys: ChannelKeys;
  /** Retained channel-rekey events, for the live rotation check. */
  private readonly rekeyEvents = new Map<string, DecodedEvent>();

  private liveSub?: Subscription;
  /** Reacts to every later `extraRelays` emission (D-08/D-09): re-opens the live
   *  subscription once one already exists, so a no-op emission before the
   *  channel has ever gone live cannot prematurely open its socket, and a real
   *  later change re-derives the merged set via `openLive()`'s own widened
   *  churn guard (Pitfall 4). */
  private extrasSub?: Subscription;
  private authoritySub?: Subscription;
  private authorityNotificationQueued = false;
  private liveAuthors = "";
  private rotation!: RotationCoordinator<ChannelKey>;
  private started = false;
  private disposed = false;

  /** Derives the channel's keys and builds its reactive surface; no network work happens
   *  until {@link start}. Self-cleaning: if any step throws, the extras subscription taken
   *  here is released rather than left attached to the app's source (WR-01). */
  constructor(options: ConcordPrivateChannelOptions) {
    this.log = options.logger ?? logger;
    this.syncLog = this.log.extend("sync");
    this.decodeLog = this.syncLog.extend("decode");
    this.opts = options;
    this.bans = (options.bans ?? of<ReadonlySet<string>>(new Set<string>())).pipe(
      takeUntil(this.timelineDisposed$),
    );
    // Seed extras before deriving status observables. If construction fails,
    // release this subscription only: the rest of the instance may be uninitialized.
    this.extras = new ExtraRelays(options.extraRelays);
    // Phase 17 RESID-01 mirrors the community boundary: per-relay AUTH failures
    // remain on the operation and structured `:auth` diagnostic paths. They
    // never enter fatal lifecycle UI state and therefore need no recovery latch.
    this.signers = new StreamSigners();
    try {
      this.channelKey = options.channelKey;
      this.keys = deriveChannelKeys(options.material(), options.channelKey);
      this.epoch$ = new BehaviorSubject<number>(options.channelKey.epoch);
      this.rotation = new RotationCoordinator({
        scopeId: options.channelKey.id,
        diagnostics: options.rotationDiagnostics,
        read: () => this.readRotation(),
        keyOf: (next) => hexToBytes(next.key),
        adopt: async (next) => {
          await this.adoptChannelKey(next);
          this.openLive();
          await this.catchUpCurrent();
        },
        remove: () => this.handleRemoved(),
        fetch: async () => {
          const events = await syncAuthors(
            { ...this.syncContext(), relays: mergeRelaySets(this.opts.relays) },
            this.keys.nextRekey.map((entry) => entry.key.pk),
          );
          await Promise.all(events.map((event) => this.onWrap(event)));
        },
        onFatal: (cause) => this.failRotation(cause),
      });

      // Re-derive reactively on every extras emission (D-08) rather than once
      // from a construction-time snapshot — no first-value-only operator here, so
      // a later change on an `extraRelays` Observable keeps taking effect (D-11).
      this.connected$ = this.extras.relays$.pipe(switchMap(() => connectedRelays$(this.opts.pool, this.transport())));
      this.status$ = combineLatest({
        phase: this.phase$,
        epoch: this.epoch$,
        connected: this.connected$,
        error: this.error$,
      }).pipe(shareReplay(1));

      this.extrasSub = this.extras.relays$.subscribe(() => {
        if (!this.disposed && this.liveSub) this.openLive();
      });
      this.authoritySub = options.authorityChanges?.subscribe(() => {
        if (this.disposed || this.phase$.value !== "live" || this.authorityNotificationQueued) return;
        this.authorityNotificationQueued = true;
        queueMicrotask(() => {
          this.authorityNotificationQueued = false;
          if (!this.disposed && this.phase$.value === "live") this.rotation.notify();
        });
      });
    } catch (err) {
      this.authoritySub?.unsubscribe();
      this.extrasSub?.unsubscribe();
      this.extras.dispose();
      throw err;
    }
  }

  /** The channel's stable id — unchanged across rekeys, unlike its key and epoch. */
  get channelId(): string {
    return this.channelKey.id;
  }

  /** The channel's raw diagnostic rumor store, including banned authors.
   * Use {@link timeline} for ban-aware inputs to rendering and effect folds. */
  get store(): ConcordRumorStore {
    return this.opts.store;
  }

  /** Ban-aware retained channel inputs using the supplied current bans source.
   * Standalone engines without `options.bans` exclude no authors. Include every
   * kind needed by downstream message/edit/reaction/delete folds.
   * @param filters Nostr filters, defaulting to every kind.
   */
  timeline(filters: Filter[] = [{}]): Observable<Rumor[]> {
    return this.store.model(ConcordChatTimelineModel, this.bans, filters).pipe(takeUntil(this.timelineDisposed$));
  }

  /** Walk the channel to its tip (message planes + forward Rekeys), then open live. */
  async start(): Promise<void> {
    if (this.started || this.disposed) return;
    this.started = true;
    this.log("starting channel sync walk");
    await this.walk();
  }

  /** Re-walk after the community root rotated: the channel-rekey address keys on
   *  the root, and a Refounding may bundle a channel Rekey sealed under the prior
   *  root (CORD-06 §3). Called by {@link ConcordCommunity} on adopt. */
  async refreshForCommunityEpoch(): Promise<void> {
    if (!this.started || this.disposed) return;
    await this.walk();
  }

  /** Tears down subscriptions and the rotation coordinator. The rumor store belongs to the
   *  community's store factory and deliberately outlives this engine. */
  dispose(): void {
    this.disposed = true;
    this.timelineDisposed$.next();
    this.timelineDisposed$.complete();
    this.liveSub?.unsubscribe();
    this.extrasSub?.unsubscribe();
    this.authoritySub?.unsubscribe();
    this.extras.dispose();
    this.rotation.dispose();
    // The store is owned by the community's store factory — not disposed here.
  }

  /** Syncs every known channel epoch to the tip, then opens live. Clears a prior error at
   *  the top so a re-walk after a community rotation does not inherit a stale failure. */
  private async walk(): Promise<void> {
    // Reset at the top of the method so a refreshForCommunityEpoch() re-walk
    // starts clean and does not retain a prior fatal lifecycle/sync failure.
    this.error$.next(null);
    this.phase$.next("syncing");
    try {
      const result = await syncChannelEpochs(this.syncContext(), this.channelKey);
      if (this.disposed) return;
      if (result.removed) {
        this.handleRemoved();
        return;
      }
      if (result.tipKey) {
        const rolled = result.tipKey.epoch !== this.channelKey.epoch;
        if (rolled) await this.adoptChannelKey(result.tipKey);
        else this.setChannelKey(result.tipKey);
        this.openLive();
      }
      this.phase$.next("live");
      this.rotation.notify();
      this.log("channel epoch walk complete tip_epoch=%d", this.channelKey.epoch);
    } catch (err) {
      if (this.disposed) return;
      this.error$.next(err instanceof Error ? err.message : String(err));
      this.phase$.next("error");
    }
  }

  /** Adopts a key without the persistence barrier — for a walk that merely re-derived the
   *  epoch it already held. Use {@link adoptChannelKey} when the epoch actually rolls. */
  private setChannelKey(next: ChannelKey): void {
    this.channelKey = next;
    this.keys = deriveChannelKeys(this.opts.material(), next);
    this.epoch$.next(next.epoch);
  }

  /** Adopts a rolled-forward key, persisting before anything public moves: a key that
   *  reached `epoch$` but not storage would be lost on reload, leaving unreadable history. */
  private async adoptChannelKey(next: ChannelKey): Promise<void> {
    const commitParent = this.opts.prepareKeyChange
      ? await this.opts.prepareKeyChange(next)
      : (await this.opts.onKeyChange?.(next), undefined);
    // No public channel signal is emitted before the persistence barrier. The
    // parent commit is synchronous, then the channel epoch is published from a
    // key set derived against that same committed parent material.
    this.channelKey = next;
    commitParent?.();
    this.keys = deriveChannelKeys(this.opts.material(), next);
    this.epoch$.next(next.epoch);
  }

  /** Feed a wrap into the channel directly (an optimistic echo of a rekey the
   *  community just published, so the rotator adopts without a relay round-trip). */
  ingest(event: NostrEvent): void {
    void this.onWrap(event).catch((cause) => this.failRotation(cause));
  }

  /** Entry point for one gift wrap: match it to a plane this channel holds a key for,
   *  decode it, and route it. A wrap from an unknown author is ignored, and one that fails
   *  to decode is logged rather than thrown — a single bad wrap must not stop the stream. */
  private async onWrap(event: NostrEvent): Promise<void> {
    const info = this.keys.planes.get(event.pubkey);
    if (!info) return;
    const decode = createReceiveDecoder();
    const wire = structuredClone(event);
    const incoming = decode(wire, info);
    if (!incoming) {
      this.decodeLog(
        "dropped wrap=%s plane=%s epoch=%d",
        wire.id.slice(0, 8),
        info.type,
        info.epoch ?? this.channelKey.epoch,
      );
      return;
    }
    const canonical = await Promise.resolve(this.opts.eventStore.add(wire));
    if (!canonical || canonical.pubkey !== wire.pubkey) return;
    const decoded = decode(canonical, info);
    if (decoded) {
      await this.route(info, decoded);
    } else {
      // Prefer the PLANE's own epoch (rekey planes address `epoch + 1`), falling
      // back to the enclosing channel's known epoch — RESEARCH Pitfall 3, and the
      // same rule `route()` below and the sync walk use, so a wrap dropped live
      // and the same wrap dropped during sync report the same `epoch=`.
      this.decodeLog(
        "dropped wrap=%s plane=%s epoch=%d",
        canonical.id.slice(0, 8),
        info.type,
        info.epoch ?? this.channelKey.epoch,
      );
    }
  }

  /** Sends a decoded rumor to its destination: chat into the store after the CORD-03 §3
   *  channel/epoch binding check, rekeys into the rotation coordinator. */
  private async route(info: PlaneInfo, decoded: DecodedEvent): Promise<void> {
    if (info.type === "channel") {
      // CORD-03 §3: drop any rumor whose channel/epoch binding doesn't match the
      // key that opened it.
      if (!checkChatBinding(decoded.rumor.tags, this.channelId, info.epoch ?? this.channelKey.epoch)) return;
      // `.add` is sync for an in-memory store and a Promise for an async-database-backed one;
      // state derives reactively from `insert$`, so fire-and-forget while surfacing errors.
      await retainChannelInput(this.opts.store, decoded.rumor);
    } else if (info.type === "rekey") {
      this.rekeyEvents.set(decoded.wrapId, decoded);
      this.rotation.notify();
    }
  }

  /** The merged transport target for this channel: `opts.relays` unioned with
   *  the current extras snapshot (D-04) — the ONLY merge point in the class.
   *  `opts.relays` itself keeps its exact protocol meaning untouched; this is
   *  for network targets only (pool subscription/request/publish, auth), never
   *  for anything written into signed or published content. */
  private transport(): string[] {
    return this.extras.merge(this.opts.relays);
  }

  /** Builds the context each sync pass runs against, snapshotting the community material
   *  and the merged transport set at call time. */
  private syncContext(): ChannelSyncContext {
    return {
      pool: this.opts.pool,
      signers: this.signers,
      eventStore: this.opts.eventStore,
      signer: this.opts.signer,
      self: this.opts.pubkey,
      relays: this.transport(),
      material: this.opts.material(),
      isAuthorized: this.opts.isAuthorized,
      canRemoveSelf: this.opts.canRemoveSelf,
      verifyVac: this.opts.verifyVac,
      route: (info, decoded) => this.route(info, decoded),
      onAuthRequired: this.signers.onAuthRequired,
      alive: () => !this.disposed,
      logger: this.syncLog,
      decodeLogger: this.decodeLog,
    };
  }

  // D-03/D-04: a reconnect gets a fresh auth budget from the shared retry
  // operator (`resetState()`/the `defer`-scoped `consecutive` counter), so this
  // engine adds no reconnect mechanism of its own. D-14: a single relay's auth
  // failure does not kill either path (`RelayGroup`'s per-relay `catchError`).
  /** Opens the live subscription at the current tip, covering the message plane and the
   *  next-epoch rekey addresses. Re-derives keys first, since the community root may have
   *  moved since the last call. */
  private openLive(): void {
    this.keys = deriveChannelKeys(this.opts.material(), this.channelKey);
    const { authors } = channelLiveAuthors(this.opts.material(), this.channelKey);
    // Computed ONCE and reused for the guard, the auth registration, the
    // subscription target, and the debug log's length (mirrors
    // `community.ts`'s `openLive()` `targets` local verbatim) — the previous
    // four separate `transport()` calls made the guard agree with what was
    // actually dialled only by accident, and the fourth allocated a merged
    // array purely to read its length. D-09/Pitfall 4: the churn guard's key
    // covers BOTH the sorted authors list and the sorted merged transport set,
    // so a no-op `extraRelays$` re-emission (already de-duped upstream by
    // `ExtraRelays`) still can't tear down and reopen the live socket if
    // neither actually changed.
    const targets = this.transport();
    const sig = `${[...authors].sort().join(",")}|${[...targets].sort().join(",")}`;
    if (sig === this.liveAuthors && this.liveSub) return;
    this.liveAuthors = sig;
    this.signers.register([this.keys.current, ...this.keys.nextRekey.map((r) => r.key)]);
    this.liveSub?.unsubscribe();
    this.liveSub = this.opts.pool
      .subscription(targets, [{ kinds: [GIFT_WRAP_KIND, EPHEMERAL_GIFT_WRAP_KIND], authors }], {
        waitForAuth: authors,
        onAuthRequired: this.signers.onAuthRequired,
      })
      .subscribe((event) => void this.onWrap(event as NostrEvent).catch((cause) => this.failRotation(cause)));
    this.log("live subscription open targets=%d", targets.length);
  }

  /** Folds the retained rekey events into an adopt / removed / none decision. Total by
   *  construction — unusable candidates come back as diagnostics, never as throws. */
  private async readRotation(): Promise<ChannelRekeyOutcome> {
    const outcome = await readChannelRekey(
      this.channelKey,
      [...this.rekeyEvents.values()],
      this.opts.isAuthorized,
      this.opts.pubkey,
      this.opts.signer,
      this.opts.canRemoveSelf,
      this.opts.verifyVac,
    );
    return outcome;
  }

  /** Moves the channel into its terminal error state and stops listening. Reserved for
   *  fatal rotation failures, not for the routine per-candidate rejections. */
  private failRotation(cause: unknown): void {
    if (this.disposed) return;
    this.error$.next(cause instanceof Error ? cause.message : String(cause));
    this.phase$.next("error");
    this.liveSub?.unsubscribe();
  }

  /** Backfills the newly adopted epoch's message plane, so messages published between the
   *  rotation and the live subscription opening are not missed. */
  private async catchUpCurrent(): Promise<void> {
    const current = this.keys.current.pk;
    const events = await syncAuthors(this.syncContext(), [current]);
    await Promise.all(events.map((event) => this.onWrap(event)));
  }

  /** Handles a rekey that excluded us: report `"removed"`, tear down, then notify the
   *  parent. Already-synced history stays readable; only new traffic stops decoding. */
  private handleRemoved(): void {
    const id = this.channelId;
    this.log("channel removed id=%s", id.slice(0, 8));
    this.phase$.next("removed");
    this.dispose();
    this.opts.onRemoved?.(id);
  }
}
