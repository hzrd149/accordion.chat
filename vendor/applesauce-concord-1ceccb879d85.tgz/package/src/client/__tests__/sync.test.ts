// D-04 down-only re-read spine (ROTATE-06): `syncEpoch`'s "known" branch folds a
// historical epoch's already-fetched rekey plane instead of discarding it, and
// `syncEpochs` cascades a strictly-lower late-arriving winner into the walk's
// continuation. Exercised directly against `syncEpoch`/`syncEpochs` over a
// dependency-injected pool that SERVES pre-built wraps (no sockets, no
// ConcordCommunity) — mirrors private-channel.test.ts's `servingPool` pattern.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { BehaviorSubject, EMPTY, from, NEVER, Subject, throwError } from "rxjs";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { EventStore, logger } from "applesauce-core";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { Filter } from "applesauce-core/helpers/filter";
import type { RelayPool } from "applesauce-relay";

import { StreamSigners } from "../auth.ts";
import { createLegacyCommunity, historicalBaseRotation } from "../../helpers/__tests__/test-utils.ts";
import { EditionFactory } from "../../factories/control.ts";
import { deriveConcordKeys, rollForward, wrapForTarget } from "../../helpers/keys.ts";
import { grantLocator } from "../../helpers/crypto.ts";
import { computeEditionHash } from "../../helpers/editions.ts";
import { EPHEMERAL_GIFT_WRAP_KIND, GIFT_WRAP_KIND } from "../../helpers/gift-wrap.ts";
import { PERM, VSK } from "../../types.ts";
import type { JoinMaterial } from "../../types.ts";
import { buildChain, syncAuthors, type SyncContext, syncEpochs } from "../sync.ts";

/** A captured relay-level filter (the shape `servingPool`'s `request` receives). */
type CapturedFilter = { kinds?: number[]; authors?: string[]; since?: number; until?: number };

// A RelayPool stand-in that serves `events` matching each REQ's authors/kinds and
// completes (EOSE). No NIP-77, no live subscription — identical shape to
// private-channel.test.ts's `servingPool`. When `capture` is passed, every filter
// object the relay-level `request` receives is recorded into it — the spy seam
// for the backfill-direction filter-spy test (D-03).
function servingPool(events: NostrEvent[], capture?: CapturedFilter[]): RelayPool {
  const relay = {
    url: "wss://fake",
    challenge: null,
    challenge$: new BehaviorSubject<string | null>(null),
    isAuthenticated: () => false,
    authenticate: async () => ({ ok: true }),
    getSupported: async () => null,
    sync: () => EMPTY,
    request: (filters: unknown) => {
      const fs = (Array.isArray(filters) ? filters : [filters]) as CapturedFilter[];
      capture?.push(...fs);
      const match = events.filter((e) =>
        fs.some(
          (f) =>
            (!f.kinds || f.kinds.includes(e.kind)) &&
            (!f.authors || f.authors.includes(e.pubkey)) &&
            (f.since === undefined || e.created_at >= f.since) &&
            (f.until === undefined || e.created_at <= f.until),
        )
      );
      return from(match);
    },
  };
  return {
    status$: new Subject(),
    relay: () => relay,
    subscription: () => NEVER,
    request: (_relays: string[], filters: unknown) => relay.request(filters),
    publish: async () => [],
  } as unknown as RelayPool;
}

describe("syncEpochs — D-04 down-only re-read spine (ROTATE-06)", () => {
  it("re-reads a known epoch's rekey plane; a late-arriving strictly-lower sibling cascades into N+2", async () => {
    const owner = new PrivateKeySigner(generateSecretKey());
    const ownerPub = await owner.getPublicKey();
    const member = new PrivateKeySigner(generateSecretKey());
    const memberPub = await member.getPublicKey();
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();

    const genesis = await createLegacyCommunity({ ownerPubkey: ownerPub, name: "T", relays: ["wss://fake"] });
    const material0 = genesis.material;
    const keys0 = deriveConcordKeys(material0, []);

    const events: NostrEvent[] = [];

    // Grant `member` PERM.BAN (mirrors community.test.ts's AUTH-02 pattern) so a
    // SECOND, independent rotator is authorized to compete with the owner for
    // epoch 1 — CORD-06 §3 racing convergence needs two DISTINCT rotator
    // pubkeys, since `groupRotations` keys sets by (rotator, scope, newEpoch,
    // prevCommit): same-rotator chunks would merge into one set, not race.
    const roleId = "03".repeat(32);
    const role = {
      role_id: roleId,
      name: "Banhammer",
      position: 5,
      permissions: PERM.BAN.toString(),
      scope: { kind: "server" },
      color: 0,
    };
    const roleEd = await EditionFactory.create({
      vsk: VSK.ROLE,
      eid: roleId,
      version: 1,
      content: JSON.stringify(role),
    });
    events.push((await wrapForTarget(keys0, { plane: "control" }, owner, roleEd, { plaintext: true })).wrap);

    const grantEid = grantLocator(hexToBytes(material0.community_id), memberPub);
    const grantContent = JSON.stringify({ member: memberPub, role_ids: [roleId] });
    const grantEd = await EditionFactory.create({
      vsk: VSK.GRANT,
      eid: grantEid,
      version: 1,
      content: grantContent,
    });
    events.push((await wrapForTarget(keys0, { plane: "control" }, owner, grantEd, { plaintext: true })).wrap);

    // D-08/D-12: `member` is a non-owner rotator, so their rotation must cite
    // this SAME Grant (hand-computed via computeEditionHash, mirroring
    // admin.vacFor's own recompute) for syncEpoch's vacVerifier gate to honor it.
    const memberVac: [string, string, string] = [
      grantEid,
      "1",
      computeEditionHash({ vsk: VSK.GRANT, eid: grantEid, version: 1, content: grantContent }),
    ];

    // HAND-DERIVED ordering (CORD-06 §3's lowest-key-wins rule) — fixed byte
    // patterns, not random keys, so "LOW < HIGH" holds by construction and this
    // test's expectations never depend on lowerKeyWins/isStrictlyLowerKey
    // (the functions under test) to determine which root SHOULD win:
    //   lowKey  = 0x01 repeated 32x → hex "0101…01"
    //   highKey = 0xff repeated 32x → hex "ffff…ff"
    // "0101…" < "ffff…" lexicographically, so lowKey MUST be the winner.
    const lowKey = new Uint8Array(32).fill(0x01);
    const highKey = new Uint8Array(32).fill(0xff);
    expect(bytesToHex(lowKey) < bytesToHex(highKey)).toBe(true); // sanity-check the hand derivation itself

    const recipients = [ownerPub, memberPub, selfPub];

    // Owner's rotation lands first (HIGH root) — a normal, uncontested adoption.
    const ownerPlan = await historicalBaseRotation(keys0, owner, {
      recipients,
      self: ownerPub,
      heads: [],
      channels: [],
      newRoot: highKey,
    });
    events.push(...ownerPlan.rekeyWraps);

    const pool = servingPool(events);
    // D-41: the test owns the context's store and disposes it.
    const store = new EventStore();
    const ctx: SyncContext = {
      pool,
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test").extend("decode"),
    };

    try {
      // First full sync: only the owner's (HIGH) rotation is on the relay.
      const first = await syncEpochs(ctx, material0);
      expect(first.removed).toBe(false);
      expect(first.tipKeys?.material.root_epoch).toBe(1);
      expect(first.tipKeys?.material.community_root).toBe(bytesToHex(highKey));

      // The member's (LOW) rotation for the SAME epoch 0→1 slot arrives LATE —
      // appended to the relay only now, simulating a straggling relay/late publish.
      const memberPlan = await historicalBaseRotation(keys0, member, {
        recipients,
        self: memberPub,
        heads: [],
        channels: [],
        newRoot: lowKey,
        vac: memberVac,
      });
      events.push(...memberPlan.rekeyWraps);

      // A legitimate epoch1(LOW)→epoch2 rotation, minted by the owner directly off
      // the CORRECTED LOW root — proves the cascade rebuilds N+2 from the corrected
      // N+1, not the abandoned HIGH branch. Addressed under the LOW root, so it is
      // invisible to the walk until the LOW root is actually (re-)adopted.
      const keys1Low = rollForward(keys0, lowKey, 1, memberPub, []);
      const epoch2Key = generateSecretKey();
      const followupPlan = await historicalBaseRotation(keys1Low, owner, {
        recipients: [ownerPub, memberPub, selfPub],
        self: ownerPub,
        heads: [],
        channels: [],
        newRoot: epoch2Key,
      });
      events.push(...followupPlan.rekeyWraps);

      // Second (later) full sync starts from the PERSISTED material a caller would
      // have saved after the first walk — tip epoch 1 (HIGH), epoch 0 held.
      const persisted = first.tipKeys!.material;
      const second = await syncEpochs(ctx, persisted);

      // Epoch 0 is re-read ("known"), NOT re-decided as "adopt" — but it now
      // surfaces the strictly-lower sibling for `syncEpochs` to act on.
      const epoch0Result = second.epochs.find((e) => e.epoch === 0)!;
      expect(epoch0Result.transition).toBe("known");
      expect(epoch0Result.reReadAdopted?.key).toEqual(lowKey);

      // The cascade replaced chain[1]: the corrected epoch-1 root is LOW, not HIGH.
      const epoch1Result = second.epochs.find((e) => e.epoch === 1)!;
      expect(epoch1Result.keys.material.community_root).toBe(bytesToHex(lowKey));

      // N+2 rebuilt from the CORRECTED N+1 — the tip is epoch 2, minted off LOW.
      expect(second.tipKeys?.material.root_epoch).toBe(2);
      expect(second.tipKeys?.material.community_root).toBe(bytesToHex(epoch2Key));
      // The corrected LOW branch supplies continuation; held read history may retain HIGH.
      // ROTATE-12: epoch 1's held_roots entry is attributed to the member (who
      // minted the LOW root via memberVac), epoch 0 (genesis) carries none.
      expect(second.tipKeys?.material.held_roots).toEqual(expect.arrayContaining([
        expect.objectContaining({ epoch: 1, key: bytesToHex(lowKey), refounder: memberPub }),
        expect.objectContaining({ epoch: 0, key: material0.community_root }),
      ]));
    } finally {
      store.dispose();
    }
  });

  it("re-reading the SAME (non-strictly-lower) winner again leaves a settled epoch untouched (down-only)", async () => {
    const owner = new PrivateKeySigner(generateSecretKey());
    const ownerPub = await owner.getPublicKey();
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();

    const genesis = await createLegacyCommunity({ ownerPubkey: ownerPub, name: "T", relays: ["wss://fake"] });
    const material0 = genesis.material;
    const keys0 = deriveConcordKeys(material0, []);

    const highKey = new Uint8Array(32).fill(0xff);
    const recipients = [ownerPub, selfPub];
    const ownerPlan = await historicalBaseRotation(keys0, owner, {
      recipients,
      self: ownerPub,
      heads: [],
      channels: [],
      newRoot: highKey,
    });

    const events: NostrEvent[] = [...ownerPlan.rekeyWraps];
    const pool = servingPool(events);
    const store = new EventStore();
    const ctx: SyncContext = {
      pool,
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test").extend("decode"),
    };

    try {
      const first = await syncEpochs(ctx, material0);
      expect(first.tipKeys?.material.community_root).toBe(bytesToHex(highKey));

      // No new events arrive — a second full walk re-reads epoch 0 and rediscovers
      // the SAME (already-latched) root. It is surfaced as a re-read "adopt" (the
      // fold itself has no memory of what was already settled — see `syncEpoch`'s
      // doc comment), but `syncEpochs`'s down-only comparison must recognize it is
      // NOT strictly lower and leave the chain exactly as it was.
      const second = await syncEpochs(ctx, first.tipKeys!.material);
      const epoch0Result = second.epochs.find((e) => e.epoch === 0)!;
      expect(epoch0Result.reReadAdopted?.key).toEqual(highKey);
      expect(second.tipKeys?.material.root_epoch).toBe(1);
      expect(second.tipKeys?.material.community_root).toBe(bytesToHex(highKey));
    } finally {
      store.dispose();
    }
  });
});

describe("syncAuthors — backfill filter requests only the retained kind (D-01/D-03)", () => {
  it("kinds is [GIFT_WRAP_KIND] — 21059 (EPHEMERAL_GIFT_WRAP_KIND) absent", async () => {
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();

    const captured: CapturedFilter[] = [];
    const pool = servingPool([], captured);
    const store = new EventStore();
    const ctx: SyncContext = {
      pool,
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test").extend("decode"),
    };

    try {
      await syncAuthors(ctx, ["01".repeat(32)]);

      expect(captured.length).toBeGreaterThan(0);
      // Expected value is derived from the spec constants directly (TEST-01), not
      // from sync.ts's own BACKFILL_KINDS export, so a pass genuinely attributes to
      // the fix rather than to the filter-spy merely echoing production's constant.
      expect(captured[0].kinds).toEqual([GIFT_WRAP_KIND]);
      expect(captured[0].kinds).not.toContain(EPHEMERAL_GIFT_WRAP_KIND);
    } finally {
      store.dispose();
    }
  });
});

describe("syncAuthors — v7 historical reliability", () => {
  async function context(pool: RelayPool): Promise<SyncContext> {
    const signer = new PrivateKeySigner(generateSecretKey());
    return {
      pool,
      signer,
      self: await signer.getPublicKey(),
      signers: new StreamSigners(),
      eventStore: new EventStore(),
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test:decode"),
    };
  }

  it("replays verified local history when negentropy has nothing missing", async () => {
    const pool = servingPool([]);
    const relay = pool.relay("wss://fake");
    relay.getSupported = async () => [77];
    const ctx = await context(pool);
    try {
      const wrap = await ctx.signer.signEvent({ kind: GIFT_WRAP_KIND, created_at: 100, tags: [], content: "cached" });
      ctx.eventStore.add(wrap);
      expect((await syncAuthors(ctx, [wrap.pubkey])).map((event) => event.id)).toEqual([wrap.id]);
      expect((await syncAuthors(ctx, [wrap.pubkey])).map((event) => event.id)).toEqual([wrap.id]);
    } finally {
      ctx.eventStore.dispose();
    }
  });

  it("rejects all-relay failures instead of declaring an empty history synchronized", async () => {
    const pool = servingPool([]);
    pool.relay("wss://fake").request = () => throwError(() => new Error("offline"));
    const ctx = await context(pool);
    try {
      await expect(syncAuthors(ctx, [ctx.self])).rejects.toThrow("no relay completed");
    } finally {
      ctx.eventStore.dispose();
    }
  });

  it("rejects when pool liveness skips every relay", async () => {
    const pool = servingPool([]);
    pool.filterRelays = () => [];
    const ctx = await context(pool);
    try {
      await expect(syncAuthors(ctx, [ctx.self])).rejects.toThrow("no relay completed");
    } finally {
      ctx.eventStore.dispose();
    }
  });

  it("keeps a successful relay usable when another relay fails", async () => {
    const pool = servingPool([]);
    const good = pool.relay("wss://fake");
    const bad = { ...good, request: () => throwError(() => new Error("offline")) };
    pool.relay = ((url: string) => url === "wss://bad" ? bad : good) as RelayPool["relay"];
    const ctx = await context(pool);
    ctx.relays.push("wss://bad");
    try {
      expect(await syncAuthors(ctx, [ctx.self])).toEqual([]);
    } finally {
      ctx.eventStore.dispose();
    }
  });

  for (const advertised of [false, true]) {
    it(`loads every historical page under a ${advertised ? "known" : "silent"} relay cap`, async () => {
      const pool = servingPool([]);
      const ctx = await context(pool);
      try {
        const wraps: NostrEvent[] = [];
        for (let i = 0; i < 5; i++) {
          wraps.push(
            await ctx.signer.signEvent({
              kind: GIFT_WRAP_KIND,
              created_at: 100 + i,
              tags: [],
              content: `message ${i}`,
            }),
          );
        }
        const relay = pool.relay("wss://fake");
        relay.getLimitations = async () => advertised ? { max_limit: 2 } : null;
        let requests = 0;
        relay.request = (filters) => {
          requests++;
          const f = (Array.isArray(filters) ? filters[0] : filters) as Filter;
          return from(
            wraps.filter((event) => f.until === undefined || event.created_at <= f.until)
              .sort((a, b) => b.created_at - a.created_at).slice(0, Math.min(2, f.limit ?? 2)),
          );
        };
        const events = await syncAuthors(ctx, [ctx.self]);
        expect(new Set(events.map((event) => event.id))).toEqual(new Set(wraps.map((event) => event.id)));
        expect(requests).toBeGreaterThanOrEqual(3);
      } finally {
        ctx.eventStore.dispose();
      }
    });
  }
});

describe("buildChain — per-epoch refounder attribution (ROTATE-12/L01)", () => {
  it("attributes each synthesized epoch's refounder from its OWN held_roots entry, not the tip's", async () => {
    const owner = new PrivateKeySigner(generateSecretKey());
    const ownerPub = await owner.getPublicKey();
    const rotatorA = new PrivateKeySigner(generateSecretKey());
    const rotatorAPub = await rotatorA.getPublicKey();
    const rotatorB = new PrivateKeySigner(generateSecretKey());
    const rotatorBPub = await rotatorB.getPublicKey();

    const genesisCommunity = await createLegacyCommunity({ ownerPubkey: ownerPub, name: "T", relays: ["wss://fake"] });
    const material0 = genesisCommunity.material;

    // HAND-CONSTRUCTED 4-epoch chain — buildChain is exercised DIRECTLY over a
    // crafted JoinMaterial (no actual sync/Refounding), each historical epoch
    // naming a DISTINCT minting refounder, so the current tip's refounder
    // (rotatorB) provably cannot leak onto a DIFFERENT epoch's entry:
    //   epoch 0 (genesis) -> no refounder (created, never refounded)
    //   epoch 1           -> minted by rotatorA
    //   epoch 2           -> minted by rotatorB (first rotation)
    //   epoch 3 (tip)     -> minted by rotatorB again (a second, later rotation)
    const epoch1Root = new Uint8Array(32).fill(0x01);
    const epoch2Root = new Uint8Array(32).fill(0x02);
    const epoch3Root = new Uint8Array(32).fill(0x03);
    const material: JoinMaterial = {
      ...material0,
      community_root: bytesToHex(epoch3Root),
      root_epoch: 3,
      refounder: rotatorBPub,
      held_roots: [
        { epoch: 2, key: bytesToHex(epoch2Root), refounder: rotatorBPub },
        { epoch: 1, key: bytesToHex(epoch1Root), refounder: rotatorAPub },
        { epoch: 0, key: material0.community_root },
      ],
    };

    const chain = buildChain(material);
    expect(chain).toHaveLength(4);

    // Hand-derived expected epoch -> refounder mapping, independent of buildChain's
    // own output — genesis undefined, epoch 1 = rotatorA (NOT the tip's rotatorB),
    // epochs 2 and 3 both = rotatorB (their own, coincidentally-shared minter).
    const expected: Record<number, string | undefined> = {
      0: undefined,
      1: rotatorAPub,
      2: rotatorBPub,
      3: rotatorBPub,
    };
    for (const entry of chain) expect(entry.refounder).toBe(expected[entry.root_epoch]);
  });
});

describe("SyncContext.onAuthRequired type narrowing (WR-07 regression guard)", () => {
  it("accepts a StreamSigners handler and rejects a request-reading handler at compile time", () => {
    // Positive: every syncContext() in this codebase assigns this.signers.onAuthRequired
    // (a StreamSigners instance's handler, RelayAuthHandler & SyncAuthHandler) directly
    // here — it must type-check with no cast, proving Task 1's contravariant typing holds
    // at this boundary too.
    const positiveHandler: SyncContext["onAuthRequired"] = new StreamSigners().onAuthRequired;
    void positiveHandler;

    // Negative: a handler declared over a context that reads `request` must be REJECTED —
    // the loader's own auth context (what SyncContext["onAuthRequired"] is narrowed to)
    // never carries a `request` field at all. If this narrowing ever regresses (e.g. the
    // field is widened back to RelayAuthHandler), this line stops erroring and
    // `@ts-expect-error` fails the build.
    // @ts-expect-error - a handler reading `request` is not assignable to SyncContext's narrowed onAuthRequired
    const negativeHandler: SyncContext["onAuthRequired"] = (ctx: { request: unknown }) => {
      void ctx.request;
    };
    void negativeHandler;
  });
});
