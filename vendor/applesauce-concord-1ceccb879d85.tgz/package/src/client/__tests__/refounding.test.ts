import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { PrivateKeySigner } from "applesauce-signers/signers/private-key-signer";
import { generateSecretKey } from "applesauce-core/helpers/keys";

import { foldControl } from "../../helpers/control.ts";

import { buildRefounding, deriveConcordKeys, wrapForTarget } from "../../helpers/keys.ts";
import { decodeReceivedWrap } from "../receive.ts";

import type { DecodedEvent } from "../../types.ts";

import { createCommunity } from "../../helpers/community.ts";

import {
  evaluateCommonRelayCoverage,
  type PendingRefoundingRecord,
  type RefoundingArtifactPublication,
  RefoundingPublicationError,
} from "../refounding.ts";
import { memoryStorage, PendingRefoundingStore } from "../storage.ts";

const A = "wss://a.test/";
const B = "wss://b.test/";
const C = "wss://c.test/";
const EXTRA = "wss://extra.test/";

async function authenticRecord() {
  const signer = new PrivateKeySigner(generateSecretKey());
  const actor = await signer.getPublicKey();
  const genesis = await createCommunity({ ownerPubkey: actor, name: "prepared", relays: [A] });
  const keys = deriveConcordKeys(genesis.material, []);
  const originals: DecodedEvent[] = [];
  for (const draft of genesis.controlRumors) {
    const { wrap } = await wrapForTarget(keys, { plane: "control" }, signer, draft, { plaintext: true });
    originals.push(decodeReceivedWrap(wrap, { type: "control", convKey: keys.control.convKey })!);
  }
  const state = foldControl(originals, genesis.material);
  const plan = await buildRefounding(keys, signer, {
    state,
    recipients: [actor],
    self: actor,
    heads: originals,
    channels: state.channels,
  });
  const record: PendingRefoundingRecord = {
    version: 1,
    communityId: genesis.material.community_id,
    priorEpoch: 0,
    rotationId: plan.rekeyWraps[0].id,
    stage: "prepared",
    plan,
    mandatoryEvidence: [],
    commonRelays: [],
    warnings: [],
  };
  const storage = memoryStorage();
  const pending = new PendingRefoundingStore(storage, signer, actor, genesis.material.community_id);
  return { signer, actor, material: genesis.material, record, pending, storage };
}

function publication(id: string, accepted: string[]): RefoundingArtifactPublication {
  return {
    artifact: { id, kind: id === "control" ? "control-compaction" : "root-rekey" },
    responses: accepted.map((from) => ({ ok: true, from })),
  };
}

describe("evaluateCommonRelayCoverage", () => {
  it("accepts one strict common majority across every mandatory artifact", () => {
    const coverage = evaluateCommonRelayCoverage(
      [publication("root-1", [A, B]), publication("root-2", [A, B]), publication("control", [A, B])],
      [A, B, C],
    );

    expect(coverage.accepted).toBe(true);
    expect(coverage.commonRelays).toEqual([A, B]);
    expect(coverage.required).toBe(2);
  });

  it("rejects disjoint per-artifact majorities", () => {
    const coverage = evaluateCommonRelayCoverage(
      [publication("one", [A, B]), publication("two", [B, C]), publication("control", [A, C])],
      [A, B, C],
    );

    expect(coverage.accepted).toBe(false);
    expect(coverage.commonRelays).toEqual([]);
    expect(coverage.evidence.map((row) => row.acceptedRelays)).toEqual([
      [A, B],
      [B, C],
      [A, C],
    ]);
  });

  it("excludes transport-only relays from the denominator and intersection", () => {
    const coverage = evaluateCommonRelayCoverage(
      [publication("root", [A, B, EXTRA]), publication("control", [A, B, EXTRA])],
      [A, B, C],
    );

    expect(coverage.accepted).toBe(true);
    expect(coverage.commonRelays).toEqual([A, B]);
    expect(coverage.evidence.every((row) => !row.acceptedRelays.includes(EXTRA))).toBe(true);
  });

  it("normalizes duplicate protocol relays and malformed response origins", () => {
    const coverage = evaluateCommonRelayCoverage(
      [
        {
          artifact: { id: "root", kind: "root-rekey" },
          responses: [
            { ok: true, from: A.slice(0, -1) },
            { ok: true, from: "" },
          ],
        },
      ],
      [A, A.slice(0, -1), ""],
    );

    expect(coverage.accepted).toBe(true);
    expect(coverage.protocolRelays).toEqual([A]);
  });
});

describe("RefoundingPublicationError", () => {
  it("exposes stable evidence and causes without putting relay text in its message", () => {
    const cause = new Error("relay-controlled secret text");
    const coverage = evaluateCommonRelayCoverage(
      [{ artifact: { id: "root-id", kind: "root-rekey" }, responses: [], cause }],
      [A],
    );
    const error = new RefoundingPublicationError("rotation-id", coverage.evidence);

    expect(error.rotationId).toBe("rotation-id");
    expect(error.failedArtifactIds).toEqual(["root-id"]);
    expect(error.causes).toEqual([cause]);
    expect(error.message).not.toContain("relay-controlled secret text");
  });

  it("retains typed causes from negative relay acknowledgements", () => {
    const cause = new Error("relay rejected publication");
    const coverage = evaluateCommonRelayCoverage(
      [
        {
          artifact: { id: "control-id", kind: "control-compaction" },
          responses: [{ ok: false, from: A, error: cause, message: "untrusted relay text" }],
        },
      ],
      [A],
    );
    const error = new RefoundingPublicationError("rotation-id", coverage.evidence);

    expect(error.causes).toEqual([cause]);
    expect(error.message).not.toContain("untrusted relay text");
  });
});

describe("PendingRefoundingStore", () => {
  it("round-trips the complete prepared operation through self-encrypted storage", async () => {
    const f = await authenticRecord();
    try {
      await f.pending.save(f.record);
      const raw = await f.storage.getItem(f.pending.key);
      expect(raw).not.toContain(f.record.plan.next.material.community_root);
      const loaded = (await f.pending.load())!;
      expect(loaded.plan.next.material).toEqual(f.record.plan.next.material);
      expect(JSON.stringify(loaded.plan.rekeyWraps)).toBe(JSON.stringify(f.record.plan.rekeyWraps));
    } finally {
      await f.pending.remove();
    }
  });

  it("rejects authenticated records for a different community", async () => {
    const f = await authenticRecord();
    try {
      await f.pending.save(f.record);
      const second = new PendingRefoundingStore(f.storage, f.signer, f.actor, "11".repeat(32), f.pending.key);
      await expect(second.load()).rejects.toThrow("community");
    } finally {
      await f.pending.remove();
    }
  });

  it("durably records each completion stage before cleanup", async () => {
    const f = await authenticRecord();
    try {
      const publications = [
        ...f.record.plan.rekeyWraps.map((w) => ({
          artifact: { id: w.id, kind: "root-rekey" as const },
          responses: [{ from: A, ok: true }],
        })),
        ...f.record.plan.channelRekeyWraps.map((w) => ({
          artifact: { id: w.id, kind: "channel-rekey" as const },
          responses: [{ from: A, ok: true }],
        })),
        ...f.record.plan.compactionWraps.map((w) => ({
          artifact: { id: w.id, kind: "control-compaction" as const },
          responses: [{ from: A, ok: true }],
        })),
      ];
      const evidence = evaluateCommonRelayCoverage(publications, [A]);
      let record = { ...f.record, protocolRelays: [A], mandatoryEvidence: evidence.evidence, commonRelays: [A] };
      await f.pending.save(record);
      for (const stage of ["mandatory-confirmed", "adopted", "snapshot-attempted"] as const) {
        record = await f.pending.updateStage(record, stage) as typeof record;
        expect((await f.pending.load())?.stage).toBe(stage);
      }
      await f.pending.remove();
      expect(await f.pending.load()).toBeNull();
    } finally {
      await f.pending.remove();
    }
  });
});
