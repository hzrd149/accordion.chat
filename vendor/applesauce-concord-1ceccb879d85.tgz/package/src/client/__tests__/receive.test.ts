import { expect } from "@std/expect";
import { it } from "@std/testing/bdd";
import { setVerifyWrappedEventMethod, verifyEvent } from "applesauce-core/helpers/event";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { createCommunity } from "../../helpers/community.ts";
import { deriveConcordKeys, wrapForTarget } from "../../helpers/keys.ts";
import { createReceiveDecoder } from "../receive.ts";

it("receive reuse binds exact bytes and plane keys and keeps decoded evidence private", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const { material } = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "test", relays: [] });
  const keys = deriveConcordKeys(material, []);
  const { wrap } = await wrapForTarget(keys, { plane: "guestbook" }, signer, { kind: 1, tags: [], content: "valid" });
  const info = keys.planes.get(wrap.pubkey)!;
  const decode = createReceiveDecoder();
  const original = structuredClone(wrap);
  const first = decode(wrap, info)!;
  expect(first.rumor.content).toBe("valid");
  first.rumor.content = "changed";
  expect(decode(structuredClone(wrap), info)?.rumor.content).toBe("valid");
  wrap.content += "x";
  expect(decode(wrap, info)).toBeNull();
  expect(decode(original, { ...info, convKey: new Uint8Array(32) })).toBeNull();
  expect(decode(original, { ...info, type: "control" })).toBeNull();
  expect(decode(original, info)?.rumor.content).toBe("valid");
});

it("verifies each envelope once when a canonical copy has identical wire bytes", async () => {
  const signer = new PrivateKeySigner(generateSecretKey());
  const { material } = await createCommunity({ ownerPubkey: await signer.getPublicKey(), name: "test", relays: [] });
  const keys = deriveConcordKeys(material, []);
  const { wrap } = await wrapForTarget(keys, { plane: "guestbook" }, signer, { kind: 1, tags: [], content: "valid" });
  const info = keys.planes.get(wrap.pubkey)!;
  let calls = 0;
  setVerifyWrappedEventMethod((event) => {
    calls++;
    return verifyEvent(event);
  });
  try {
    const decode = createReceiveDecoder();
    expect(decode(wrap, info)).not.toBeNull();
    expect(calls).toBe(2);
    expect(decode(structuredClone(wrap), info)).not.toBeNull();
    expect(calls).toBe(2);
    expect(decode({ ...wrap, content: wrap.content + "x" }, info)).toBeNull();
    expect(calls).toBe(3);
  } finally {
    setVerifyWrappedEventMethod(verifyEvent);
  }
});
