import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { assertSpyCalls, resolvesNext, spy } from "@std/testing/mock";
import { firstValueFrom, take, toArray } from "rxjs";
import { RotationCoordinator, type RotationDiagnostic, type RotationOutcome } from "../rotation.ts";

type Next = { key: Uint8Array };

const flush = async () => {
  await Promise.resolve();
  await Promise.resolve();
};

function harness(outcomes: RotationOutcome<Next>[]) {
  const adopted: Next[] = [];
  const fatal: unknown[] = [];
  const fetch = spy(async (): Promise<void> => undefined);
  const coordinator = new RotationCoordinator<Next>({
    scopeId: "root",
    read: spy(async (): Promise<RotationOutcome<Next>> => outcomes.shift() ?? { kind: "none" }),
    keyOf: (next) => next.key,
    adopt: (next) => void adopted.push(next),
    remove: spy(),
    fetch,
    onFatal: (cause) => void fatal.push(cause),
  });
  return { coordinator, adopted, fatal, fetch };
}

/** Every reconcilable parked reason a fetch-then-reevaluate cycle must cover. */
const PARKED_REASONS = ["incomplete", "inconsistent", "continuity-gap", "citation-missing"] as const;

describe("RotationCoordinator", () => {
  it("adopts a lower live sibling but never moves the latch equal or upward", async () => {
    const high = { key: Uint8Array.of(9) };
    const low = { key: Uint8Array.of(1) };
    const h = harness([
      { kind: "adopt", epoch: 1, next: high },
      { kind: "adopt", epoch: 1, next: low },
      { kind: "adopt", epoch: 1, next: high },
      { kind: "adopt", epoch: 1, next: low },
    ]);
    for (let i = 0; i < 4; i++) {
      h.coordinator.notify();
      await h.coordinator.idle();
    }
    expect(h.adopted).toEqual([high, low]);
  });

  for (const reason of PARKED_REASONS) {
    it(`fetches and reevaluates a parked ${reason} candidate`, async () => {
      const h = harness([
        { kind: "none", diagnostics: [{ candidateId: "candidate", status: "parked", reason }] },
        { kind: "adopt", epoch: 1, next: { key: Uint8Array.of(1) } },
      ]);
      h.coordinator.notify();
      await flush();
      await flush();
      assertSpyCalls(h.fetch, 1);
      expect(h.adopted).toHaveLength(1);
    });
  }

  it("deduplicates a candidate fetch while it is in flight", async () => {
    let release!: () => void;
    const pending = new Promise<void>((resolve) => (release = resolve));
    const fetch = spy((): Promise<void> => pending);
    const diagnostic = { candidateId: "candidate", status: "parked" as const, reason: "incomplete" as const };
    const coordinator = new RotationCoordinator<Next>({
      scopeId: "channel-id",
      read: spy(async (): Promise<RotationOutcome<Next>> => ({ kind: "none", diagnostics: [diagnostic] })),
      keyOf: (next) => next.key,
      adopt: spy(),
      remove: spy(),
      fetch,
      onFatal: spy(),
    });
    coordinator.notify();
    coordinator.notify();
    await coordinator.idle();
    assertSpyCalls(fetch, 1);
    release();
  });

  it("exhausts one mismatched citation after three bounded attempts", async () => {
    const diagnostic = { candidateId: "candidate", status: "parked" as const, reason: "citation-mismatch" as const };
    const read = spy(async (): Promise<RotationOutcome<Next>> => ({ kind: "none", diagnostics: [diagnostic] }));
    const fetch = spy(async (): Promise<void> => undefined);
    const coordinator = new RotationCoordinator<Next>({
      scopeId: "root",
      read,
      keyOf: (next) => next.key,
      adopt: spy(),
      remove: spy(),
      fetch,
      onFatal: spy(),
    });
    const exhausted = firstValueFrom(
      coordinator.diagnostics$.pipe(
        take(5),
        toArray(),
      ),
    );
    coordinator.notify();
    for (let i = 0; i < 8; i++) {
      await flush();
      await coordinator.idle();
    }
    const seen = await exhausted;
    assertSpyCalls(fetch, 3);
    expect(seen.at(-1)).toMatchObject({
      scopeId: "root",
      candidateId: "candidate",
      reason: "reconciliation-exhausted",
      attempt: 3,
    });
  });

  it("reports remote defects without failing the coordinator", async () => {
    const diagnostics = [
      { candidateId: "bad", status: "rejected" as const, reason: "malformed" as const },
    ];
    const h = harness([{ kind: "none", diagnostics }]);
    const seen = firstValueFrom(h.coordinator.diagnostics$.pipe(take(1), toArray()));
    h.coordinator.notify();
    const expected: RotationDiagnostic[] = [{ scopeId: "root", ...diagnostics[0] }];
    expect(await seen).toEqual(expected);
    expect(h.fatal).toEqual([]);
  });

  it("preserves the original local transition failure as fatal", async () => {
    const cause = new Error("persistence failed");
    const h = harness([{ kind: "adopt", epoch: 1, next: { key: Uint8Array.of(1) } }]);
    h.coordinator.dispose();
    const coordinator = new RotationCoordinator<Next>({
      scopeId: "root",
      read: async () => ({ kind: "adopt", epoch: 1, next: { key: Uint8Array.of(1) } }),
      keyOf: (next) => next.key,
      adopt: async () => Promise.reject(cause),
      remove: spy(),
      onFatal: (error) => h.fatal.push(error),
    });
    coordinator.notify();
    await coordinator.idle();
    expect(h.fatal).toEqual([cause]);
  });

  it("does not latch a candidate whose local commit failed", async () => {
    const candidate = { key: Uint8Array.of(1) };
    const cause = new Error("persistence failed");
    const adopt = spy(resolvesNext<void>([cause, undefined]));
    const fatal: unknown[] = [];
    const coordinator = new RotationCoordinator<Next>({
      scopeId: "root",
      read: async () => ({ kind: "adopt", epoch: 1, next: candidate }),
      keyOf: (next) => next.key,
      adopt,
      remove: spy(),
      onFatal: (error) => fatal.push(error),
    });

    coordinator.notify();
    await coordinator.idle();
    coordinator.notify();
    await coordinator.idle();

    expect(fatal).toEqual([cause]);
    assertSpyCalls(adopt, 2);
  });
});
