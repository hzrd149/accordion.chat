// ConcordCommunity — the single-community reactive engine.
//
// A thin wrapper that connects the Concord parts (crypto/keys, the stream
// envelope, the plane RumorStores + fold models, factories/operations, and the
// NIP-42 stream-key authenticator) for ONE community. It owns no fold logic:
// every piece of derived state comes from a model over a RumorStore. The engine
// only derives keys, routes decoded wraps into the right plane store, runs the
// epoch-atomic sync, and publishes.

import {
  BehaviorSubject,
  combineLatest,
  distinctUntilChanged,
  map,
  type Observable,
  shareReplay,
  startWith,
  Subject,
  type Subscription,
  switchMap,
} from "rxjs";
import { type Debugger, EventStore, RumorStore } from "applesauce-core";
import {
  type EventTemplate,
  finalizeEvent,
  getEventHash,
  type NostrEvent,
  verifyWrappedEvent,
} from "applesauce-core/helpers/event";
import { ensureKTag } from "applesauce-core/helpers/factory";
import { generateSecretKey, getPublicKey } from "applesauce-core/helpers/keys";
import { mergeRelaySets } from "applesauce-core/helpers/relays";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { ChatMessageFactory, CommentFactory, ForumThreadFactory, ReactionFactory } from "applesauce-common/factories";
import { DeleteFactory, type Emoji } from "applesauce-core/factories";
import type { ISigner } from "applesauce-signers";
import type { PublishOptions, RelayAuthHandler, RelayPool } from "applesauce-relay";

import { logger } from "../logger.ts";
import { assertBaseRotationSupported } from "../helpers/keys.ts";
import { connectedRelays$, StreamSigners } from "./auth.ts";
import { createReceiveDecoder, decodeReceivedWrap } from "./receive.ts";
import {
  evaluateCommonRelayCoverage,
  type PendingRefoundingRecord,
  type RefoundingArtifact,
  type RefoundingArtifactPublication,
  RefoundingPublicationError,
  type RefoundingResult,
  type RefoundingWarning,
} from "./refounding.ts";
import { ExtraRelays, type ExtraRelaysOption } from "../helpers/relays.ts";
import {
  addChannelKey,
  buildChannelRekey,
  buildRefounding,
  channelEpochOf,
  type ConcordKeys,
  currentBaseRekeys,
  deriveConcordKeys,
  type PlaneInfo,
  planeKeyFor,
  readRekey,
  type RekeyOutcome,
  wrapForTarget,
  type WrapTarget,
} from "../helpers/keys.ts";
import {
  controlKeyFor,
  decodeControlRootDelivery,
  encodeControlRootDelivery,
  epochKeyCommitment,
  grantLocator,
  type GroupKey,
} from "../helpers/crypto.ts";
import { hasChannelKey } from "../helpers/community.ts";
import {
  base64ToBytes,
  decodeWrappedKey,
  findBlob,
  groupRotations,
  parseRekeyResult,
  rekeyLocator,
} from "../helpers/rekey.ts";
import { canonicalJson, mergeCommunities } from "../helpers/community-list.ts";
import { decodeWrap, EPHEMERAL_GIFT_WRAP_KIND, GIFT_WRAP_KIND, PLAINTEXT_SEAL_KIND } from "../helpers/gift-wrap.ts";
import { resolveEditionPin } from "../helpers/editions.ts";
import { checkChatBinding } from "../helpers/chat.ts";
import { retainChannelInput } from "./channel-input.ts";
import { isCurrentStaff, refoundAuthority, type Standing, vacVerifier } from "../helpers/permissions.ts";
import type { AttachmentEncryption, MediaAttachment } from "../helpers/imeta.ts";
import { buildInviteBundle, buildInviteLink, newInviteToken, STOCK_RELAYS } from "../helpers/invite-bundle.ts";
import { EditFactory } from "../factories/edit.ts";
import { DissolutionFactory } from "../factories/control.ts";
import { JoinLeaveFactory, KickFactory } from "../factories/guestbook.ts";
import { InviteBundleFactory } from "../factories/invite-bundle.ts";
import { DirectInviteFactory } from "../factories/direct-invite.ts";
import { bindToChannel, includeMediaEncryption, type MediaEncryption } from "../operations/channel.ts";
import { ConcordCommunityStateModel } from "../models/community.ts";
import { ConcordChatTimelineModel } from "../models/chat.ts";
import type { Filter } from "applesauce-core/helpers/filter";
import { decodedFromRumor } from "../models/utils.ts";
import {
  type ChannelKey,
  type ChannelMetadata,
  type CommunityMetadata,
  type CommunityState,
  type ConcordCommunityStatus,
  type ConcordSyncPhase,
  type ControlVerification,
  type DecodedEvent,
  type InviteBundle,
  type JoinMaterial,
  PERM,
  type Role,
  type RoleScope,
  type Rumor,
  VSK,
} from "../types.ts";
import { buildChain, planeStoreKey, syncAuthors, type SyncContext, syncEpochs } from "./sync.ts";
import { RotationCoordinator, type RotationDiagnostic } from "./rotation.ts";
import { ConcordCommunityAdmin, type CreateChannelOptions } from "./admin.ts";
import { ConcordPrivateChannel } from "./private-channel.ts";
import {
  type ConcordRumorStore,
  type ConcordStorage,
  type ConcordStoreFactory,
  type ConcordUploader,
  type ConcordUploadProgress,
  defaultStorage,
  PendingRefoundingStore,
} from "./storage.ts";
import type { ConcordInviteLink, CreateInviteOptions } from "./invite-manager.ts";
import { InviteRevocationPublishError, requireInviteRevocationAck } from "./revocation.ts";

/** Options for {@link ConcordCommunity.sendMessage}. */
export interface ConcordSendMessageOptions {
  /** Reports attachment progress across the whole send, so a composer can show one
   *  aggregate indicator rather than guessing which file is in flight. */
  onUploadProgress?: (progress: ConcordUploadProgress) => void;
}

/** Options for constructing a single-community {@link ConcordCommunity} engine. */
export interface ConcordCommunityOptions {
  /** Same-community verified floor to restore after truncating the control
   * cache. Complete retained histories reconstruct continuity automatically. */
  controlVerification?: ControlVerification;
  /** The membership/key material for this community (from an invite or the list). */
  material: JoinMaterial;
  /** The logged-in user's signer (NIP-44 required to follow Refoundings). */
  signer: ISigner;
  /** The logged-in user's hex pubkey. */
  pubkey: string;
  /** The applesauce RelayPool used for all subscriptions/publishes. */
  pool: RelayPool;
  /** Wrap-level store for kind-1059 dedup + the NIP-77 negentropy local store.
   *  Defaults to a fresh {@link EventStore}. */
  eventStore?: EventStore;
  /** Media uploader (encrypt + upload). Required to send files or set images. */
  uploader?: ConcordUploader;
  /** Fallback relays when the community defines none. */
  relays?: string[];
  /** Additive transport targets; see {@link ConcordClientOptions.extraRelays}.
   *  Never persisted or counted toward Refounding quorum, which uses only
   *  normalized, deduplicated protocol relays. */
  extraRelays?: ExtraRelaysOption;
  /** Per-plane store factory (persistent cache). Defaults to in-memory stores. */
  storeFactory?: ConcordStoreFactory;
  /** Durable storage for protected in-flight Refounding operations. */
  storage?: ConcordStorage;
  /** Persists replacement material and refreshes the Community List. Base transitions
   *  and held signing-capability restoration await this callback before exposing
   *  replacement keys. Reject to preserve the active pair and allow a later retry. */
  onMaterialChange?: (material: JoinMaterial) => void | Promise<void>;
  /** Called when a Refounding excludes us (CORD-06): the manager tombstones the
   *  membership and drops the community. */
  onRemoved?: (communityId: string) => void;
  /** Called after a public invite link has been minted and registered so the
   *  owning client can persist it into the user's private Invite List (13303). */
  onInviteCreated?: (invite: ConcordInviteLink) => void | Promise<void>;
  /** Called after a public invite link has been revoked so the owning client can
   *  persist the terminal tombstone into the user's private Invite List (13303). */
  onInviteRevoked?: (invite: ConcordInviteLink) => void | Promise<void>;
  /** Called after a Refounding rolls the community_root so the owning client can
   *  refresh every live invite bundle behind its unchanged URL (CORD-05 §2). */
  onRefounded?: (communityId: string) => void;
  /** A custom debug logger (defaults to the "applesauce:concord" namespace). */
  logger?: Debugger;
  /** The user's own auth handler (built ONCE by `ConcordClient`, D-08) — used ONLY by the
   *  Direct-Invite grant publish ({@link ConcordCommunity.grantChannelAccess}), whose author
   *  is a NIP-59 ephemeral key that `DirectInviteFactory.create` generates and destroys
   *  internally, never exposing it to this engine (D-16/D-17). A standalone community
   *  constructed without it simply passes no handler at that one site, and a gating relay
   *  refuses that one publish exactly as it does today. Do NOT use this anywhere else in
   *  this class — the stream/user split is D-09 and must stay visible. */
  userOnAuthRequired?: RelayAuthHandler;
}

/** Content equality for the member/ban sets, which are rebuilt on every fold. */
function sameSet(a: Set<string>, b: Set<string>): boolean {
  if (a === b) return true;
  if (a.size !== b.size) return false;
  for (const value of a) if (!b.has(value)) return false;
  return true;
}

/** A folded channel plus the client-local `accessible` affordance (CHAN-06):
 *  `true` for every public channel, and for a private channel iff `material.channels`
 *  currently holds a key for it. `accessible` is NEVER folded state — it rides only
 *  this emitted view, never {@link ChannelMetadata} or the control-plane fold. */
export type ChannelView = ChannelMetadata & { accessible: boolean };

/** Content equality for `channels$`'s emitted `ChannelView[]` — a fresh array is
 *  mapped on every emission, so reference equality would never suppress a no-op
 *  re-emission. Mirrors {@link sameSet}'s content-comparator role for `members$`. */
function sameChannelViews(a: ChannelView[], b: ChannelView[]): boolean {
  if (a === b) return true;
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i].channel_id !== b[i].channel_id) return false;
    if (a[i].accessible !== b[i].accessible) return false;
  }
  return true;
}

/** Thrown by {@link ConcordCommunity.sendMessage}/{@link ConcordCommunity.sendEvent}
 *  when the target channel is known (folded, visible in `state$.value.channels`)
 *  and private, but `material.channels` holds no key for it (CHAN-02/D-06). This
 *  is the client's own guard, thrown BEFORE `channelEpoch`/`planeKeyFor` are ever
 *  reached — with D-01/D-02, a keyless private channel has no `keys.channels`
 *  entry, so `planeKeyFor` would otherwise throw its generic `unknown channel`,
 *  indistinguishable from a truly-unknown id. Consumers `instanceof`-catch this
 *  to disable the composer precisely. `planeKeyFor`'s generic throw stays as the
 *  backstop for an id absent from `state.channels` entirely — this guard does
 *  not cover that case. */
export class MissingChannelKeyError extends Error {
  /**
   * Always carries the offending channel id, so a consumer that `instanceof`-catches this
   * can disable precisely that channel's composer rather than the whole UI.
   *
   * @param channelId The known private channel we hold no key for.
   */
  constructor(public readonly channelId: string) {
    super("missing private channel key");
    this.name = "MissingChannelKeyError";
  }
}

function sameStanding(a: Standing, b: Standing): boolean {
  return (
    a.isOwner === b.isOwner &&
    a.position === b.position &&
    a.permissions === b.permissions &&
    a.roleIds.length === b.roleIds.length &&
    a.roleIds.every((id, i) => id === b.roleIds[i])
  );
}

function emptyState(material: JoinMaterial): CommunityState {
  return {
    material,
    channels: [],
    roles: [],
    grants: new Map(),
    banlist: new Set(),
    inviteLinks: new Set(),
    members: new Set(),
    dissolved: false,
  };
}

/**
 * The reactive engine for one community: derives per-epoch keys, routes decoded wraps into
 * per-plane stores, runs the epoch-atomic sync walk, follows Refoundings, and publishes.
 * It owns no fold logic — every `*$` surface here is folded by the models layer from the
 * stores this engine fills.
 */
export class ConcordCommunity {
  /** The logged-in user's signer, used for sealing, publishing and NIP-42 auth. */
  readonly signer: ISigner;
  /** The logged-in user's hex pubkey — the identity authority checks resolve against. */
  readonly pubkey: string;
  /** The current folded community state (channels, roles, members, …). The
   *  aggregate; prefer the granular reads below, which only emit when their own
   *  slice changes. */
  readonly state$: BehaviorSubject<CommunityState>;
  /** The community's metadata (name, description, icon, banner, relays). */
  readonly metadata$: Observable<CommunityMetadata | undefined>;
  /** The community's live (non-deleted) channels, enriched with the client-local
   *  `accessible` flag (CHAN-06). Reacts to both a control-plane fold AND an
   *  out-of-band key grant/drop (`receiveChannelKeys`/`persistChannelKey`/
   *  `dropChannelKey`/`mintChannelKey`), with no simultaneous control-plane fold
   *  required — the reactivity gap this stream exists to close. */
  readonly channels$: Observable<ChannelView[]>;
  /** The community's roles, ordered by position (highest authority first). */
  readonly roles$: Observable<Role[]>;
  /** member → role_ids. */
  readonly grants$: Observable<Map<string, string[]>>;
  /** The banned pubkeys. */
  readonly banlist$: Observable<Set<string>>;
  /** Live invite-link coordinates; non-empty ⇒ the community is Public (CORD-05 §5). */
  readonly inviteLinks$: Observable<Set<string>>;
  /** The community's members. */
  readonly members$: Observable<Set<string>>;
  /** The community's sync-lifecycle phase (idle → syncing → live; removed/error). */
  readonly phase$: BehaviorSubject<ConcordSyncPhase> = new BehaviorSubject<ConcordSyncPhase>("idle");
  /** The community's current root epoch (bumps on each adopted Refounding). */
  readonly epoch$: BehaviorSubject<number>;
  /** The last sync error message, or null. */
  readonly error$: BehaviorSubject<string | null> = new BehaviorSubject<string | null>(null);
  /** Whether the owner has dissolved the community. */
  readonly dissolved$: Observable<boolean>;
  /** Whether any of the community's relays (plus any configured `extraRelays`) has
   *  an open socket — derived from the merged transport set, re-deriving on every
   *  later `extraRelays` emission (D-08). Because this is an any-of check, an
   *  always-up app-local extra keeps this reporting connected even while every
   *  community relay is down; UI reading "live" may be reading the local cache —
   *  an accepted, documented consequence (D-07), not a defect. */
  readonly connected$: Observable<boolean>;
  /** A flat snapshot of the community's status, for UI to react to as one value. */
  readonly status$: Observable<ConcordCommunityStatus>;

  /** Every action that requires authority — metadata, channels, roles, members,
   *  invites, refounding, dissolution — as one intent-shaped surface. This is the
   *  community-management API; prefer it over the flat aliases the community keeps
   *  for convenience. Nothing in it names a protocol plane. */
  readonly admin: ConcordCommunityAdmin;

  /** The community's debug logger — `options.logger` when threaded from the client,
   *  otherwise the `applesauce:concord` module base (D-01/D-02). */
  private readonly log: Debugger;
  private controlVerification?: ControlVerification;
  private controlHistory = new Map<string, DecodedEvent>();
  /** The `:sync` sub-logger, derived ONCE in the constructor — handed to every
   *  {@link SyncContext} this instance builds. `syncContext()` runs once per
   *  `start()` AND once per `reconcileLive()` batch, so `.extend()`ing there
   *  would reallocate and re-run namespace enable-matching each time. */
  private readonly syncLog: Debugger;
  /** The `:sync:decode` per-dropped-wrap logger (D-07), derived ONCE in the
   *  constructor — never re-`.extend()`d per wrap (that reallocates and
   *  re-runs namespace enable-matching on every call). */
  private readonly decodeLog: Debugger;
  /** The `:publish` sub-logger (D-03 light operational tracing), derived ONCE
   *  in the constructor — reused at every publish trace/dual-emit site in this
   *  engine (channel rekey, invite bundle mint/refresh/revoke, channel grant). */
  private readonly publishLog: Debugger;
  /** The `:fold` sub-logger (D-03), derived ONCE in the constructor — light
   *  tracing at control/member fold outcomes that change the community's
   *  epoch (a live Refounding adoption or an involuntary removal). */
  private readonly foldLog: Debugger;
  private readonly pool: RelayPool;
  /** This community's own pubkey→signer holder (D-02/D-06) — constructed here,
   *  never shared with a spawned private channel or the client (T-15-01). */
  private readonly signers: StreamSigners;
  /** The user's own auth handler, threaded through from `ConcordClient` (D-08) — used ONLY
   *  by the one Direct-Invite grant publish in {@link grantChannelAccess}. See
   *  {@link ConcordCommunityOptions.userOnAuthRequired}. */
  private readonly userOnAuthRequired?: RelayAuthHandler;
  private readonly eventStore: EventStore;
  private readonly uploader?: ConcordCommunityOptions["uploader"];
  private readonly defaultRelays: string[];
  private readonly storeFactory: ConcordStoreFactory;
  private readonly pendingRefounding: PendingRefoundingStore;
  private readonly onMaterialChange?: (material: JoinMaterial) => void | Promise<void>;
  private readonly onRemoved?: (communityId: string) => void;
  private readonly onInviteCreated?: (invite: ConcordInviteLink) => void | Promise<void>;
  private readonly onInviteRevoked?: (invite: ConcordInviteLink) => void | Promise<void>;
  private readonly onRefounded?: (communityId: string) => void;
  /** The RAW `extraRelays` option, kept unresolved so {@link spawnPrivateChannel}
   *  can pass it through to each sub-engine's OWN holder rather than a resolved
   *  snapshot (D-13) — the sub-engine must stay reactive to its own subscription. */
  private readonly extraRelaysOption?: ExtraRelaysOption;
  /** The per-engine transport-only extras holder (D-04) — merges into every
   *  network target this engine dials via {@link transport}; `relays()` itself
   *  is never touched. */
  private readonly extras: ExtraRelays;

  /** The current key state; rolled forward on a Refounding. */
  private keys: ConcordKeys;
  /** Emits whenever `this.keys.material.channels` mutates out-of-band (a Direct
   *  Invite grant, a channel Rekey, a voluntary leave, or a fresh mint) — CHAN-06:
   *  `channels$` combines this with the control-plane `channels` slice so its
   *  `accessible` flag reacts to key-holding changes with no simultaneous fold. */
  private readonly materialChanged$ = new Subject<void>();
  /** planeKey ("control"|"guestbook"|"dissolved"|"rekey"|`channel:<id>`) → store. */
  private readonly stores = new Map<string, ConcordRumorStore>();
  /** channelId → the sub-community engine for each private channel we hold a key for. */
  private readonly privateChannels = new Map<string, ConcordPrivateChannel>();

  private stateSub?: Subscription;
  private authorityNotificationQueued = false;
  private liveSub?: Subscription;
  /** Reacts to every later `extraRelays` emission (D-08/D-09): re-opens the live
   *  subscription once one already exists, so a no-op emission before `start()`
   *  has ever gone live cannot prematurely open a socket, and a real later
   *  change re-derives the merged set via `openLive()`'s own widened guard. */
  private extrasSub: Subscription;
  private liveAuthors = "";
  private readonly rotationDiagnostics = new Subject<RotationDiagnostic>();
  /** Rotation decisions for this community's root and for every private channel it spawns,
   *  on one stream. Emits as each non-adopted candidate is parked or rejected. */
  readonly rotationDiagnostics$: Observable<RotationDiagnostic> = this.rotationDiagnostics.asObservable();
  private rotation!: RotationCoordinator<ConcordKeys>;
  private readonly rotationOrigins = new WeakMap<ConcordKeys, JoinMaterial>();
  private readonly rotationGuards = new WeakMap<ConcordKeys, () => Promise<boolean>>();
  private predecessorCache?: { material: JoinMaterial; keys?: ConcordKeys };
  private materialFailureReported = false;
  private readonly syncCancelled = new Subject<void>();
  /** One commit lane for root and private-channel key transitions. */
  private materialTransitionTail: Promise<void> = Promise.resolve();
  /** Initiation/resume lane; independent of material adoption so callbacks cannot deadlock it. */
  private refoundingTail: Promise<void> = Promise.resolve();
  private promotionQueued = false;
  private promotionAttempt?: string;
  private promotionBusy = false;
  private started = false;
  private disposed = false;

  /** Derives the community's keys and builds its reactive surface; no network work runs
   *  until {@link start}. Self-cleaning: a throw anywhere in the tail releases the extras
   *  subscription rather than leaving it attached to the app's source. */
  constructor(options: ConcordCommunityOptions) {
    this.controlVerification = options.controlVerification?.communityId === options.material.community_id
      ? options.controlVerification
      : undefined;
    this.log = options.logger ?? logger;
    this.syncLog = this.log.extend("sync");
    this.decodeLog = this.syncLog.extend("decode");
    this.publishLog = this.log.extend("publish");
    this.foldLog = this.log.extend("fold");
    this.signer = options.signer;
    this.pubkey = options.pubkey;
    this.pool = options.pool;
    // Phase 17 RESID-01 supersedes Phase 15 WR-02's clear-on-recovery reading:
    // per-relay AUTH failures stay on the operation and structured `:auth`
    // diagnostic paths. Preventing transient AUTH from entering fatal UI state
    // is stronger than latching it here and trying to clear it later.
    this.signers = new StreamSigners();
    this.userOnAuthRequired = options.userOnAuthRequired;
    this.eventStore = options.eventStore ?? new EventStore();
    this.uploader = options.uploader;
    this.defaultRelays = options.relays?.length ? options.relays : STOCK_RELAYS;
    this.storeFactory = options.storeFactory ?? (() => new RumorStore());
    this.pendingRefounding = new PendingRefoundingStore(
      options.storage ?? defaultStorage(),
      this.signer,
      this.pubkey,
      options.material.community_id,
    );
    this.onMaterialChange = options.onMaterialChange;
    this.onRemoved = options.onRemoved;
    this.onInviteCreated = options.onInviteCreated;
    this.onInviteRevoked = options.onInviteRevoked;
    this.onRefounded = options.onRefounded;
    this.extraRelaysOption = options.extraRelays;
    // Seed extras before deriving status observables. If construction fails,
    // release this subscription only: the rest of the instance may be uninitialized.
    this.extras = new ExtraRelays(options.extraRelays);
    try {
      this.keys = deriveConcordKeys(options.material, []);
      this.state$ = new BehaviorSubject<CommunityState>(emptyState(options.material));
      this.epoch$ = new BehaviorSubject<number>(options.material.root_epoch);

      this.dissolved$ = this.state$.pipe(
        map((s) => s.dissolved),
        distinctUntilChanged(),
      );

      // Granular reads. Every control-plane slice keeps a STABLE REFERENCE between
      // control folds — `ConcordCommunityStateModel` spreads `{ ...control, members }`,
      // so `state$` re-emitting because a chat message moved the observed-authors set
      // leaves `roles`/`channels`/… pointing at the same objects. Reference identity is
      // therefore enough to keep these quiet under channel traffic.
      const slice = <T>(select: (s: CommunityState) => T): Observable<T> =>
        this.state$.pipe(map(select), distinctUntilChanged());
      this.metadata$ = slice((s) => s.metadata);
      // CHAN-06: `accessible` is client-local (never folded), and must react to a
      // key grant/drop ALONE — combineLatest with materialChanged$ so a Direct
      // Invite delivering a key with no simultaneous control-plane fold still
      // re-emits (the reactivity gap RESEARCH.md surfaced).
      this.channels$ = combineLatest([slice((s) => s.channels), this.materialChanged$.pipe(startWith(undefined))]).pipe(
        map(([channels]) =>
          channels.map((c): ChannelView => ({
            ...c,
            accessible: !c.private || hasChannelKey(this.material, c.channel_id),
          }))
        ),
        distinctUntilChanged(sameChannelViews),
      );
      this.roles$ = slice((s) => s.roles);
      this.grants$ = slice((s) => s.grants);
      this.banlist$ = slice((s) => s.banlist);
      this.inviteLinks$ = slice((s) => s.inviteLinks);
      // `members` is rebuilt by every guestbook/presence fold, so compare by content.
      this.members$ = this.state$.pipe(
        map((s) => s.members),
        distinctUntilChanged(sameSet),
      );

      // Reactive (D-08): switchMap over the extras holder's relays$ so a later
      // extraRelays emission re-derives connected$, rather than freezing at a
      // construction-time snapshot. Routes its merge through transport() (not
      // the switchMap's own emitted value) so it stays the class's one literal
      // merge point (D-04).
      this.connected$ = this.extras.relays$.pipe(switchMap(() => connectedRelays$(this.pool, this.transport())));
      this.status$ = combineLatest({
        phase: this.phase$,
        epoch: this.epoch$,
        dissolved: this.dissolved$,
        connected: this.connected$,
        error: this.error$,
      }).pipe(
        map(({ dissolved, ...s }): ConcordCommunityStatus => ({
          ...s,
          phase: dissolved ? "dissolved" : s.phase,
        })),
        distinctUntilChanged(
          (a, b) => a.phase === b.phase && a.epoch === b.epoch && a.connected === b.connected && a.error === b.error,
        ),
        shareReplay(1),
      );

      // Eagerly create the community planes so the state model has stores to fold
      // and the (cached) history renders immediately, before sync fills the delta.
      this.storeFor("control");
      this.storeFor(this.guestbookPlaneKey());
      this.storeFor("dissolved");
      this.storeFor("rekey");

      this.admin = new ConcordCommunityAdmin({
        community: this,
        store: this.storeFor("control"),
        state: () => this.state$.value,
        pubkey: this.pubkey,
        prepareControlWrap: (recipient) => this.prepareControlWrap(recipient),
        uploader: this.uploader,
        publish: (rumor, assertCurrent) =>
          this.publishToPlane({ plane: "control" }, rumor, { plaintext: true, assertCurrent }),
        publishRequired: (rumor, assertCurrent) =>
          this.publishToPlane({ plane: "control" }, rumor, {
            plaintext: true,
            assertCurrent,
            requiredAckStage: "invite registry unregister",
          }),
        mintChannelKey: (channelId, name) => {
          this.keys = addChannelKey(this.keys, channelId, name);
          this.onMaterialChange?.(this.keys.material);
          this.materialChanged$.next();
        },
      });

      this.rewireState();

      this.rotation = new RotationCoordinator({
        scopeId: "root",
        diagnostics: this.rotationDiagnostics,
        read: () => this.readRootRotation(),
        keyOf: (next) => hexToBytes(next.material.community_root),
        adopt: (next) => this.adoptRefounding(next),
        remove: () => this.handleRemoved(),
        fetch: async () => {
          const listens = this.rootRekeyKeys();
          const events = await syncAuthors(
            { ...this.syncContext(), relays: mergeRelaySets(this.relays()) },
            listens.map((keys) => keys.nextBaseRekey.key.pk),
            new Map(listens.flatMap((keys) => [...keys.planes])),
          );
          await Promise.all(events.map((event) => this.onWrap(event)));
        },
        onFatal: (cause) => this.failMaterialTransition(cause),
      });
      this.rotation.latch(this.material.root_epoch, hexToBytes(this.material.community_root));

      // D-09: guarded with `if (this.liveSub)` rather than firing unconditionally
      // — the ExtraRelays holder's internal BehaviorSubject always emits once
      // synchronously at construction (even with no `extraRelays` configured), and
      // an unguarded subscribe would open the live socket here, before `start()`
      // ever runs (a timing regression D-14's byte-identical requirement forbids).
      this.extrasSub = this.extras.relays$.subscribe(() => {
        if (!this.disposed && this.liveSub) this.openLive();
      });
    } catch (err) {
      this.extras.dispose();
      throw err;
    }
  }

  /** The community's current membership/key material. Replaced wholesale on each adopted
   *  Refounding, so callers should read it fresh rather than hold a copy. */
  get material(): JoinMaterial {
    return this.keys.material;
  }

  /** Pairwise staff root delivery belongs beside held material and the author signer (CORD-04 §3; CORD-02 §5). */
  private async prepareControlWrap(recipient: string): Promise<string> {
    const current = this.material;
    if (!current.control_root || !this.keys.control.signing) {
      throw new Error("control signing capability unavailable");
    }
    const control = controlKeyFor(current);
    if (control.pk !== this.keys.control.pk || !control.signing) {
      throw new Error("control signing capability unavailable");
    }
    if (!this.signer.nip44) throw new Error("NIP-44 support is required for control root delivery");
    const fields = ["community_id", "community_root", "root_epoch", "control_pk", "control_root"] as const;
    const material = fields.map((field) => current[field]);
    const check = () => {
      if (this.disposed || fields.some((field, index) => this.material[field] !== material[index])) {
        throw new Error("control root delivery material changed during preparation");
      }
    };
    const plaintext = encodeControlRootDelivery(hexToBytes(current.control_root), current.root_epoch);
    const author = await this.signer.getPublicKey();
    check();
    if (author !== this.pubkey) throw new Error("control root delivery signer does not match Grant author");
    // A remote getPublicKey may yield while the current owner-rooted authority
    // changes. Reuse the shared authority/rank predicate before giving it plaintext.
    const target = recipient === this.pubkey ? undefined : recipient;
    if (!refoundAuthority(this.state$.value, PERM.MANAGE_ROLES, target)(this.pubkey)) {
      throw new Error("missing current verified Grant delivery authority");
    }
    const ciphertext = await this.signer.nip44.encrypt(recipient, plaintext);
    check();
    return ciphertext;
  }

  /**
   * Restore a held staff capability from a private device snapshot (CORD-02 §5/§8).
   * Only the matching current split coordinate may contribute a validated root.
   * Waits for material persistence before exposing signing; preserves this engine
   * and its stores. Current authority still governs administrative writes.
   * @internal Used by the Community List reconciler, not ordinary invite ingestion.
   */
  async restoreHeldControl(held: JoinMaterial): Promise<void> {
    const release = await this.acquireMaterialTransition();
    try {
      while (!this.disposed) {
        if (this.disposed || this.keys.control.signing) return;
        const current = this.material;
        const coordinates = [
          "community_id",
          "owner",
          "owner_salt",
          "community_root",
          "root_epoch",
          "control_pk",
        ] as const;
        if (!current.control_pk || coordinates.some((field) => current[field] !== held[field])) return;
        const entry = (material: JoinMaterial) => ({
          community_id: material.community_id,
          current: material,
          seed: material,
          added_at: 0,
        });
        const merged = mergeCommunities([entry(current)], [entry(held)])[0].current;
        if (!merged.control_root) return;
        let next: ConcordKeys;
        try {
          next = deriveConcordKeys(
            { ...current, control_root: merged.control_root },
            this.state$.value.channels,
            this.keys,
          );
        } catch {
          return; // Malformed holder material is not a signing capability.
        }
        if (!next.control.signing) return;
        await this.onMaterialChange?.(next.material);
        if (this.disposed) return;
        // CORD-02 §8/CORD-05 §6: synchronous channel grants, mints and drops may
        // replace material while persistence awaits. Rebuild and durably retry
        // from that latest snapshot before exposing the restored staff capability.
        if (this.material !== current) continue;
        this.keys = next;
        this.signers.register([next.control.signing]);
        this.rewireState();
        this.materialChanged$.next();
        // Auth requirements change, while stores and the read coordinate stay intact.
        if (this.liveSub) this.openLive();
        return;
      }
    } finally {
      release();
    }
  }

  /** The current-epoch Guestbook store key (CORD-02 §5: the Guestbook rides the
   *  epoch) — mirrors `planeStoreKey`'s `guestbook@<epoch>` scheme in sync.ts. */
  private guestbookPlaneKey(): string {
    return `guestbook@${this.keys.material.root_epoch}`;
  }

  /**
   * D-03: dispose+delete any `guestbook@<epoch>` store whose epoch is no longer
   * live — neither the current epoch nor one of `held_roots`. Keys and stores
   * share one retention horizon: you can't decode an epoch you no longer hold the
   * root for (its address is unrecoverable), so its store is dead weight. Only
   * the guestbook plane is epoch-keyed this phase (control/dissolved/rekey/
   * channel are untouched) — called once per adopted Refounding, after the key
   * roll so `held_roots`/the current epoch are already current.
   */
  private trimStaleGuestbookStores(): void {
    const material = this.keys.material;
    const liveEpochs = new Set<number>([material.root_epoch, ...(material.held_roots ?? []).map((r) => r.epoch)]);
    for (const key of this.stores.keys()) {
      if (!key.startsWith("guestbook@")) continue;
      const epoch = Number(key.slice("guestbook@".length));
      if (liveEpochs.has(epoch)) continue;
      this.stores.get(key)?.dispose();
      this.stores.delete(key);
    }
  }

  /** The community's stable id — unchanged by Refoundings, unlike the root key and epoch. */
  get communityId(): string {
    return this.keys.material.community_id;
  }

  /** Walk every epoch to the tip (auth → full-sync each plane → fold → rekey),
   *  then open a live subscription at the latest epoch. */
  async start(): Promise<void> {
    if (this.started || this.disposed) return;
    this.started = true;
    // A fresh lifecycle walk clears a prior fatal lifecycle/sync error.
    this.error$.next(null);
    this.phase$.next("syncing");
    this.log("epoch walk starting");
    try {
      for (let attempt = 0; attempt < 3 && !this.disposed; attempt++) {
        const initialMaterial = this.material;
        // Candidate backfill may need held plane AUTH, but its unpublished tip must
        // never register capabilities in this engine's committed live holder.
        const walkSigners = new StreamSigners();
        const walk = await syncEpochs({
          ...this.syncContext(),
          signers: walkSigners,
          onAuthRequired: walkSigners.onAuthRequired,
        }, initialMaterial);
        if (this.disposed) return;
        this.controlVerification = walk.controlVerification ?? this.controlVerification;
        for (const event of walk.controlHistory ?? []) {
          this.controlHistory.set(event.author + ":" + event.rumor.id, event);
        }
        if (walk.removed) {
          this.handleRemoved();
          return;
        }
        if (!walk.tipKeys) throw new Error("epoch walk did not sync a held tip");
        if (walk.tipKeys) {
          const transitions = walk.selectedTransitions ?? [];
          if (transitions.length) {
            // CORD-04 §5/CORD-06 §3: all selected hops, including an earlier
            // staff hop below an owner tip, must remain authorized through save.
            this.rotationGuards.set(walk.tipKeys, () => this.startupTransitionsCurrent(transitions));
          }
          if (!await this.commitMaterial(walk.tipKeys, initialMaterial)) {
            continue;
          }
        }
        if (this.disposed) return;
        this.phase$.next("live");
        // CORD-02 §5: start held private streams once all tip planes have settled,
        // even when the quiet tip produces no later state emission.
        this.reconcileLive(this.state$.value.channels);
        this.schedulePromotion();
        this.rotation.notify();
        this.log("epoch walk complete tip_epoch=%d", this.keys.material.root_epoch);
        return;
      }
      if (!this.disposed) throw new Error("startup transition reevaluation exhausted");
    } catch (err) {
      if (this.disposed) return;
      this.started = false;
      this.error$.next(err instanceof Error ? err.message : String(err));
      this.phase$.next("error");
    }
  }

  /** Tears the community down: subscriptions, private-channel sub-engines and plane stores.
   *  Not restartable — the client builds a fresh engine on rejoin. */
  dispose(): void {
    this.disposed = true;
    this.syncCancelled.next();
    this.syncCancelled.complete();
    this.stateSub?.unsubscribe();
    this.liveSub?.unsubscribe();
    this.extrasSub.unsubscribe();
    this.extras.dispose();
    this.rotation.dispose();
    this.rotationDiagnostics.complete();
    for (const engine of this.privateChannels.values()) engine.dispose();
    this.privateChannels.clear();
    for (const store of this.stores.values()) store.dispose();
    this.stores.clear();
  }

  /** The Control Plane {@link RumorStore} — fold it with `ConcordControlModel` &
   *  friends, or read editions directly with `.timeline([{ kinds: [3308] }])`. */
  get controlStore(): ConcordRumorStore {
    return this.storeFor("control");
  }

  /** The current-epoch Guestbook Plane {@link RumorStore} (Joins/Leaves/Kicks/
   *  Snapshots). The Guestbook rides the epoch (CORD-02 §5) — a Refounding's new
   *  epoch reads a fresh store; see {@link guestbookPlaneKey}. */
  get guestbookStore(): ConcordRumorStore {
    return this.storeFor(this.guestbookPlaneKey());
  }

  /** A channel's raw diagnostic {@link RumorStore}, including banned authors.
   * Use {@link channelTimeline} for ban-aware inputs to rendering and effect folds. */
  channelStore(channelId: string): ConcordRumorStore {
    return this.storeFor(`channel:${channelId}`);
  }

  /** Ban-aware retained channel inputs, refiltered whenever current bans change.
   * Include all kinds needed by downstream message/edit/reaction/delete folds.
   * @param channelId Stable public or private channel id.
   * @param filters Nostr filters, defaulting to every kind.
   */
  channelTimeline(channelId: string, filters: Filter[] = [{}]): Observable<Rumor[]> {
    return this.channelStore(channelId).model(ConcordChatTimelineModel, this.banlist$, filters);
  }

  /** The store for one plane, created through the app's factory on first use so a
   *  newly-discovered channel gets persistence without a separate registration step. */
  private storeFor(planeKey: string): ConcordRumorStore {
    let store = this.stores.get(planeKey);
    if (!store) {
      store = this.storeFactory(this.communityId, planeKey);
      this.stores.set(planeKey, store);
      // A newly-discovered channel store must join the observed-authors set.
      if (this.started) this.rewireState();
    }
    return store;
  }

  /** (Re)subscribe the folded community state over the current store set. The
   *  fold lives entirely in {@link ConcordCommunityStateModel}; here we only
   *  combine it with the tiny dissolved-plane signal and mirror to `state$`. */
  private rewireState(): void {
    this.stateSub?.unsubscribe();
    const control = this.storeFor("control");
    const guestbook = this.storeFor(this.guestbookPlaneKey());
    const dissolved = this.storeFor("dissolved");
    // The live `observed` set is scoped to current-epoch guestbook (added by the
    // model itself, below) + channel activity only. Control/dissolved/rekey are
    // protocol/tombstone traffic, not "publishing" — excluding them also keeps the
    // control store from entangling the roster fold with observed-authorship
    // (Phase 8/9 territory). Public-channel stores stay un-epoch-scoped (continuous
    // chat history); a removed member's OLD public-channel activity is a known
    // residual DEFERRED to Phase 7 (channel epoch-keying) — see 06-RESEARCH.md
    // Open Question 1 and the community.test.ts regression test that pins it.
    const observed = [...this.stores.entries()].filter(([key]) => key.startsWith("channel:")).map(([, s]) => s);
    const state$ = control.model(ConcordCommunityStateModel, this.material, {
      guestbook,
      observed,
      controlVerification: this.controlVerification,
    });
    const dissolved$ = dissolved
      .timeline([{}])
      .pipe(
        map((rumors) =>
          rumors.some((r) => r.pubkey === this.material.owner && r.tags.some((t) => t[0] === "vsk" && t[1] === "10"))
        ),
      );
    this.stateSub = combineLatest([state$, dissolved$]).subscribe(([state, dissolved]) => {
      this.controlVerification = state.controlVerification;
      this.state$.next({ ...state, dissolved });
      this.schedulePromotion();
      if (this.phase$.value === "live" && this.rotation && !this.authorityNotificationQueued) {
        this.authorityNotificationQueued = true;
        queueMicrotask(() => {
          this.authorityNotificationQueued = false;
          if (!this.disposed && this.phase$.value === "live") this.rotation.notify();
        });
      }
      if (this.phase$.value === "live") this.reconcileLive(state.channels);
    });
  }

  /** CORD-04 §3: use only the selected authenticated own Grant, never retained
   * alternatives or display-only heads. Authority belongs to the shared helper. */
  private promotionCandidate(): { identity: string; author: string; wrap: string; material: JoinMaterial } | undefined {
    if (this.disposed || this.phase$.value !== "live" || this.keys.control.signing || !this.signer.nip44) return;
    const state = this.state$.value;
    const material = this.material;
    const coordinates = ["community_id", "owner", "owner_salt", "community_root", "root_epoch", "control_pk"] as const;
    if (
      !material.control_pk || coordinates.some((field) => state.material[field] !== material[field]) ||
      !isCurrentStaff(state, this.pubkey)
    ) return;
    const eid = grantLocator(hexToBytes(material.community_id), this.pubkey);
    const verification = state.controlVerification;
    const head = verification?.heads.get(eid);
    if (
      verification?.communityId !== material.community_id || !head || head.vsk !== VSK.GRANT ||
      verification.suspended.has(eid)
    ) return;
    try {
      const { edition } = head;
      if (resolveEditionPin([edition], [eid, String(head.version), head.hash]).kind !== "matched") return;
      const body: unknown = JSON.parse(edition.rumor.content);
      if (
        !body || typeof body !== "object" || !("member" in body) || body.member !== this.pubkey ||
        !("control_wrap" in body) || typeof body.control_wrap !== "string"
      ) return;
      if (
        !/^[0-9a-f]{64}$/.test(edition.author) || edition.author !== edition.rumor.pubkey ||
        edition.rumor.id !== getEventHash(edition.rumor)
      ) return;
      return {
        identity: JSON.stringify([
          material.community_id,
          material.owner,
          material.owner_salt,
          material.community_root,
          material.root_epoch,
          material.control_pk,
          material.channels,
          material.held_roots,
          head.version,
          head.hash,
          edition.rumor.id,
          edition.author,
        ]),
        author: edition.author,
        wrap: body.control_wrap,
        material,
      };
    } catch {
      return;
    }
  }

  /** Coalesce synchronous fold notifications and isolate untrusted deliveries
   * from fatal sync/rotation state. An eligible edition is attempted once. */
  private schedulePromotion(): void {
    if (this.disposed || this.phase$.value !== "live" || this.promotionQueued) return;
    this.promotionQueued = true;
    queueMicrotask(() => {
      this.promotionQueued = false;
      if (this.disposed) return;
      const candidate = this.promotionCandidate();
      if (!candidate) {
        this.promotionAttempt = undefined;
        return;
      }
      if (candidate.identity === this.promotionAttempt || this.promotionBusy) return;
      this.promotionAttempt = candidate.identity;
      this.promotionBusy = true;
      void this.adoptPromotion(candidate).catch(() => {
        this.decodeLog(
          "own Grant promotion rejected author=%s epoch=%d",
          candidate.author.slice(0, 8),
          candidate.material.root_epoch,
        );
      }).finally(() => {
        this.promotionBusy = false;
        this.schedulePromotion();
      });
    });
  }

  /** Validate pairwise material and commit it under the existing transition
   * lane. Recheck current identity after every await, including durable save. */
  private async adoptPromotion(
    candidate: { identity: string; author: string; wrap: string; material: JoinMaterial },
  ): Promise<void> {
    const plain = await this.signer.nip44!.decrypt(candidate.author, candidate.wrap);
    if (this.promotionCandidate()?.identity !== candidate.identity) return;
    const delivery = decodeControlRootDelivery(plain);
    if (!delivery || delivery.epoch !== candidate.material.root_epoch) return;
    const release = await this.acquireMaterialTransition();
    try {
      if (this.promotionCandidate()?.identity !== candidate.identity) return;
      // CORD-02 §5: derivation validates the delivered root against the exact
      // currently held epoch/control_pk pair before durable persistence.
      const next = deriveConcordKeys(
        { ...this.material, control_root: bytesToHex(delivery.controlRoot) },
        this.state$.value.channels,
        this.keys,
      );
      if (!next.control.signing) return;
      await this.onMaterialChange?.(next.material);
      if (this.promotionCandidate()?.identity !== candidate.identity) return;
      this.keys = next;
      this.signers.register([next.control.signing]);
      this.rewireState();
      this.materialChanged$.next();
      if (this.liveSub) this.openLive();
    } finally {
      release();
    }
  }

  /** Decode a live gift wrap and route it (used by the live subscription and by
   *  the optimistic echo of our own publishes). */
  private async onWrap(event: NostrEvent): Promise<void> {
    if (this.disposed) return;
    const decode = createReceiveDecoder();
    const info = this.keys.planes.get(event.pubkey) ??
      this.rootRekeyKeys().flatMap((keys) => [...keys.planes]).find(([pk]) => pk === event.pubkey)?.[1];
    if (!info) return;
    const wire = structuredClone(event);
    const decoded = decode(wire, info);
    if (!decoded) {
      // Epoch sourced from the enclosing scope's known value (channelEpochOf for
      // channel planes, else the root epoch) — RESEARCH Pitfall 3.
      const epoch = info.type === "channel"
        ? channelEpochOf(this.keys, info.channelId!)
        : this.keys.material.root_epoch;
      this.decodeLog("dropped wrap=%s plane=%s epoch=%d", wire.id.slice(0, 8), info.type, epoch);
      return;
    }
    // CORD-01 / CORD-04 §1: authenticate the held plane and inner control
    // binding before retaining either layer, even with stale SDK caches.
    const canonical = await Promise.resolve(this.eventStore.add(wire));
    if (this.disposed) return;
    if (!canonical || canonical.pubkey !== wire.pubkey) return;
    const retained = decode(canonical, info);
    if (retained) await this.route(info, retained);
  }

  /** The single funnel: apply the CORD-03 receive binding, then add the rumor
   *  to its plane store. Shared by sync and the live subscription. */
  private async route(info: PlaneInfo, decoded: DecodedEvent): Promise<void> {
    if (this.disposed) return;
    if (info.type === "control") this.controlHistory.set(decoded.author + ":" + decoded.rumor.id, decoded);
    if (info.type === "channel") {
      const epoch = info.epoch ?? channelEpochOf(this.keys, info.channelId!);
      // CORD-03 §3: drop any rumor whose channel/epoch binding doesn't match the
      // key that opened the wrap (anti-replay).
      if (!checkChatBinding(decoded.rumor.tags, info.channelId!, epoch)) return;
    }
    // `.add` is synchronous for an in-memory store and a Promise for an async-database-backed
    // one. Folded state derives reactively from the store's `insert$` (which fires once the add
    // resolves) and the folds are order-independent, so fire-and-forget is correct here — but
    // surface async-database errors rather than dropping them.
    const store = this.storeFor(planeStoreKey(info));
    if (info.type === "channel") await retainChannelInput(store, decoded.rumor);
    else await store.add(decoded.rumor);
    if (info.type === "rekey" && this.phase$.value === "live") this.rotation.notify();
  }

  /** The community's protocol relay set — its own relays, or the client defaults when it
   *  names none. This is the only relay set ever written into published content. */
  private relays(): string[] {
    return this.material.relays.length ? this.material.relays : this.defaultRelays;
  }

  /** The merged transport target for this community: {@link relays}'s protocol
   *  set unioned with the current extras snapshot (D-04) — the ONLY merge point
   *  in this class. `relays()` is the community's protocol relay set and is the
   *  only thing ever written into published content; `transport()` is the
   *  network target set and is never written anywhere. */
  private transport(): string[] {
    return this.extras.merge(this.relays());
  }

  /** Builds the context one sync pass runs against, snapshotting the merged transport set
   *  and handing over the pre-derived sub-loggers. */
  private syncContext(): SyncContext {
    return {
      controlVerification: this.controlVerification,
      controlHistory: [...this.controlHistory.values()],
      pool: this.pool,
      signers: this.signers,
      eventStore: this.eventStore,
      signer: this.signer,
      self: this.pubkey,
      relays: this.transport(),
      route: (info, decoded) => this.route(info, decoded),
      onAuthRequired: this.signers.onAuthRequired,
      alive: () => !this.disposed,
      onCancel: (cancel) => {
        const subscription = this.syncCancelled.subscribe(cancel);
        return () => subscription.unsubscribe();
      },
      logger: this.syncLog,
      decodeLogger: this.decodeLog,
    };
  }

  /** The PUBLIC channel stream keys — the SUBSCRIPTION/read set only, consumed
   *  solely by {@link currentAuthors}. Private channels sync on their own
   *  engines, so this must stay public-only or the community would subscribe to
   *  a private channel's plane (D-06 scope bleed). For the wider PUBLISH-side
   *  registration set, see {@link heldChannelKeys}. */
  private publicChannelKeys(): GroupKey[] {
    const publicIds = new Set(
      this.state$.value.channels.filter((c) => !c.private && !c.deleted).map((c) => c.channel_id),
    );
    return [...this.keys.channels.entries()].filter(([id]) => publicIds.has(id)).map(([, k]) => k);
  }

  /** All held channel keys for publish-side auth. Private-channel sub-engines
   *  handle reads, but this community publishes for both public and private
   *  channels. Per-operation auth still narrows to the publishing key. */
  private heldChannelKeys(): GroupKey[] {
    const liveIds = new Set(this.state$.value.channels.filter((c) => !c.deleted).map((c) => c.channel_id));
    return [...this.keys.channels.entries()].filter(([id]) => liveIds.has(id)).map(([, k]) => k);
  }

  /** The current-epoch stream pubkeys the community subscribes: core planes +
   *  PUBLIC channels only (private channels live on their sub-engines). */
  private currentAuthors(): string[] {
    const { control, guestbook, dissolved, nextBaseRekey } = this.keys;
    return [
      ...new Set([
        control.pk,
        guestbook.pk,
        dissolved.pk,
        nextBaseRekey.key.pk,
        ...this.rootRekeyKeys().map((keys) => keys.nextBaseRekey.key.pk),
        ...this.publicChannelKeys().map((k) => k.pk),
      ]),
    ];
  }

  // D-03/D-04: a reconnect gets a fresh auth budget from the shared retry
  // operator — `resetState()` clears the relay's auth state, and `authRetry`'s
  // `consecutive` counter lives in a `defer` closure the reconnect resubscribes
  // — so this engine adds no reconnect mechanism of its own; an idle scope with
  // no live operation re-authenticates nothing on reconnect, by design. D-14: a
  // single relay's auth failure does not kill either path — `RelayGroup` wraps
  // each relay in `catchError` before merging. `syncAuthors` waits for all
  // relays to settle and rejects when none completed successfully.
  /** Open (or reopen) the live subscription at the current epoch's addresses. */
  private openLive(): void {
    if (this.disposed || this.phase$.value !== "live") return;
    const authors = this.currentAuthors();
    // Computed ONCE and reused for the guard, the registration, and the
    // subscription target, so the guard can never disagree with what was
    // dialled (D-09/Pitfall 4). The guard key now covers BOTH the sorted
    // authors list and the sorted merged transport set, so a no-op extras
    // re-emission cannot tear down and reopen the live socket.
    const targets = this.transport();
    this.signers.register([
      ...(this.keys.control.signing ? [this.keys.control.signing] : []),
      this.keys.guestbook,
      this.keys.dissolved,
      this.keys.nextBaseRekey.key,
      ...this.rootRekeyKeys().map((keys) => keys.nextBaseRekey.key),
      ...this.heldChannelKeys(),
    ]);
    const waitForAuth = authors.filter((pk) => this.signers.get(pk) !== undefined);
    const sig = `${[...authors].sort().join(",")}|${[...targets].sort().join(",")}|${
      [...waitForAuth].sort().join(",")
    }`;
    if (sig === this.liveAuthors && this.liveSub) return;
    this.liveAuthors = sig;
    this.liveSub?.unsubscribe();
    this.liveSub = this.pool
      .subscription(targets, [{ kinds: [GIFT_WRAP_KIND, EPHEMERAL_GIFT_WRAP_KIND], authors }], {
        waitForAuth,
        onAuthRequired: this.signers.onAuthRequired,
      })
      .subscribe((event) => void this.onWrap(event as NostrEvent).catch((cause) => this.failRotation(cause)));
    this.log("live subscription open targets=%d", targets.length);
  }

  /** A live state change may reveal a new channel. Derive every channel address
   *  (for routing), catch up freshly-revealed PUBLIC channels + reopen the live
   *  subscription, and spawn/dispose a {@link ConcordPrivateChannel} sub-engine for
   *  each private channel we hold a key for. */
  private reconcileLive(channels: CommunityState["channels"]): void {
    if (this.disposed || this.phase$.value !== "live") return;
    const before = new Set(this.keys.channels.keys());
    this.keys = deriveConcordKeys(this.material, channels, this.keys);

    // Public channels ride the community live sub — catch up any newly revealed.
    const publicIds = new Set(channels.filter((c) => !c.private && !c.deleted).map((c) => c.channel_id));
    const fresh = [...this.keys.channels.entries()]
      .filter(([id]) => publicIds.has(id) && !before.has(id))
      .map(([, k]) => k.pk);
    if (fresh.length > 0) {
      this.log("catching up %d newly revealed public channel(s)", fresh.length);
      this.signers.register(this.heldChannelKeys());
      void syncAuthors(this.syncContext(), fresh, this.keys.planes).then(async (events) => {
        for (const ev of events) await this.onWrap(ev);
      }).catch((cause) => this.failRotation(cause));
    }
    this.openLive();
    this.reconcilePrivateChannels(channels);
  }

  /** Spawn a sub-engine for every private channel we hold a key for, and dispose
   *  those whose channel was deleted. */
  private reconcilePrivateChannels(channels: CommunityState["channels"]): void {
    const live = new Set<string>();
    for (const c of channels) {
      if (!c.private || c.deleted) continue;
      const key = this.material.channels.find((k) => k.id === c.channel_id);
      if (!key) continue; // a private channel we don't hold the key for — can't read it
      live.add(c.channel_id);
      if (!this.privateChannels.has(c.channel_id)) this.spawnPrivateChannel(key);
    }
    for (const [id, engine] of this.privateChannels) {
      if (live.has(id)) continue;
      engine.dispose();
      this.privateChannels.delete(id);
    }
  }

  /**
   * Merge channel keys delivered out-of-band — a Direct Invite / channel grant
   * (CORD-05 §6, see {@link grantChannelAccess}) — into our held material, then
   * spawn a sub-engine for each newly-granted private channel. Idempotent: keys we
   * already hold (by id) are ignored, so a redelivered grant is a no-op. A channel
   * whose metadata edition hasn't folded yet is picked up later by the next
   * {@link reconcileLive}. Returns true if anything new was merged.
   */
  receiveChannelKeys(keys: ChannelKey[]): boolean {
    const held = new Set(this.material.channels.map((c) => c.id));
    const fresh = keys.filter((k) => !held.has(k.id));
    if (fresh.length === 0) return false;
    const channels = [...this.material.channels, ...fresh];
    this.keys = deriveConcordKeys({ ...this.material, channels }, this.state$.value.channels, this.keys);
    this.onMaterialChange?.(this.keys.material);
    this.materialChanged$.next();
    if (this.phase$.value === "live") this.reconcilePrivateChannels(this.state$.value.channels);
    return true;
  }

  /** Starts the sub-engine for one private channel we hold a key for, wiring its authority
   *  predicates and key-persistence callbacks back into this community. */
  private spawnPrivateChannel(channelKey: ChannelKey): void {
    const currentState = (): CommunityState => this.state$.value;
    const self = this.pubkey;
    const engine = new ConcordPrivateChannel({
      channelKey,
      material: () => this.material,
      signer: this.signer,
      pubkey: this.pubkey,
      pool: this.pool,
      // Each private channel owns its own StreamSigners holder (D-06) — the
      // community never passes its own down, so a channel's keys are never
      // authenticated by the community's operations and vice versa (T-15-01).
      eventStore: this.eventStore,
      store: this.storeFor(`channel:${channelKey.id}`),
      bans: this.banlist$,
      relays: this.relays(),
      // Pass the ORIGINAL (unresolved) option through — not a resolved snapshot
      // (D-13) — so the sub-engine builds its own holder and stays reactive.
      extraRelays: this.extraRelaysOption,
      logger: this.log.extend("channel").extend(channelKey.id.slice(0, 8)),
      rotationDiagnostics: this.rotationDiagnostics,
      authorityChanges: this.state$,
      get isAuthorized() {
        return refoundAuthority(currentState(), PERM.MANAGE_CHANNELS);
      },
      // A rotator may only remove US if they also strictly outrank us (CORD-04),
      // so an under-ranked channel manager can't rekey a higher-ranked member out.
      get canRemoveSelf() {
        return refoundAuthority(currentState(), PERM.MANAGE_CHANNELS, self);
      },
      // D-08/D-12: vac-verify against the CURRENT folded state (rebuilt fresh
      // per call, mirroring admin.hasPerm's freshness) for MANAGE_CHANNELS.
      get verifyVac() {
        return vacVerifier(currentState(), PERM.MANAGE_CHANNELS);
      },
      prepareKeyChange: (ck) => this.prepareChannelKeyChange(ck),
      onRemoved: (id) => this.onPrivateChannelRemoved(id),
    });
    this.privateChannels.set(channelKey.id, engine);
    void engine.start();
  }

  /** Persist a rolled-forward channel key into `material.channels` (a channel Rekey). */
  private async persistChannelKey(channelKey: ChannelKey): Promise<void> {
    const commit = await this.prepareChannelKeyChange(channelKey);
    commit();
  }

  /** Persist a proposed channel key without exposing it, then return the
   * synchronous commit used by the child engine's transition barrier. */
  private async prepareChannelKeyChange(channelKey: ChannelKey): Promise<() => void> {
    const original = this.material.channels.find((channel) => channel.id === channelKey.id);
    const release = await this.acquireMaterialTransition();
    try {
      for (let attempt = 0; attempt < 3; attempt++) {
        const current = this.material;
        if (
          this.disposed || !original ||
          canonicalJson(current.channels.find((channel) => channel.id === channelKey.id)) !== canonicalJson(original)
        ) {
          throw new Error("channel material transition superseded");
        }
        const channels = current.channels.map((c) => (c.id === channelKey.id ? channelKey : c));
        const next = deriveConcordKeys({ ...current, channels }, this.state$.value.channels, this.keys);
        await this.onMaterialChange?.(next.material);
        if (this.disposed) throw new Error("channel material transition disposed");
        if (this.material !== current) continue;
        return () => {
          try {
            if (this.disposed || this.material !== current) throw new Error("channel material transition superseded");
            this.keys = next;
            this.materialChanged$.next();
          } finally {
            release();
          }
        };
      }
      throw new Error("channel material reconciliation exhausted");
    } catch (cause) {
      release();
      throw cause;
    }
  }

  /** Takes the single commit lane for key transitions and resolves with its release
   *  function. Serializing root and channel transitions is what stops two concurrent
   *  rotations from interleaving their persist-then-commit steps. */
  private async acquireMaterialTransition(): Promise<() => void> {
    const previous = this.materialTransitionTail;
    let release!: () => void;
    this.materialTransitionTail = new Promise<void>((resolve) => (release = resolve));
    await previous;
    return release;
  }

  /** CORD-06 §2/§3: reevaluate the held epoch at its canonical predecessor,
   * never at a losing read archive or an independently reconstructed authority fold. */
  private rootRekeyKeys(material = this.material): ConcordKeys[] {
    if (this.predecessorCache?.material !== material) {
      const predecessor = buildChain(material).at(-2);
      this.predecessorCache = { material, ...(predecessor ? { keys: deriveConcordKeys(predecessor, []) } : {}) };
    }
    return [
      ...(this.predecessorCache.keys ? [this.predecessorCache.keys] : []),
      this.keys,
    ];
  }

  /** Compare the complete read coordinate; matching staff enrichment is a local delta. */
  private sameMaterialCoordinate(left: JoinMaterial, right: JoinMaterial): boolean {
    const fields = ["community_id", "owner", "owner_salt", "community_root", "root_epoch", "control_pk"] as const;
    return fields.every((field) => left[field] === right[field]);
  }

  /** Revalidate the walk's signed selections against shared CURRENT authority.
   * CORD-06 §2/§3: rerun whole-pair selection, retaining continuity, chunk and
   * exact citation checks. Evidence/authority changes during any async check
   * retire the entire captured completion, including all its intermediate hops. */
  private async startupTransitionsCurrent(
    transitions: NonNullable<import("./sync.ts").EpochWalkResult["selectedTransitions"]>,
  ): Promise<boolean> {
    const identity = (events: DecodedEvent[]) =>
      canonicalJson([...new Set(events.map((event) => event.rumor.id))].sort());
    const relevant = (material: JoinMaterial, events: DecodedEvent[]) => {
      const commitment = bytesToHex(epochKeyCommitment(material.root_epoch, hexToBytes(material.community_root)));
      return currentBaseRekeys(material, events).filter((event) => {
        const parsed = parseRekeyResult(event);
        return parsed.kind === "parsed" && parsed.value.prevEpoch === BigInt(material.root_epoch) &&
          parsed.value.prevCommit === commitment;
      });
    };
    const timeline = await Promise.resolve(this.storeFor("rekey").getTimeline([{}]));
    if (this.disposed) return false;
    const events = timeline.map(decodedFromRumor);
    const state = this.state$.value;
    for (const transition of transitions) {
      const currentEvents = relevant(transition.keys.material, events);
      if (identity(currentEvents) !== identity(relevant(transition.keys.material, transition.events))) return false;
      const outcome = await readRekey(
        transition.keys,
        currentEvents,
        refoundAuthority(state),
        this.pubkey,
        this.signer,
        state.channels,
        refoundAuthority(state, PERM.BAN, this.pubkey),
        vacVerifier(state, PERM.BAN),
        transition.heldNext,
      );
      if (
        this.disposed || this.state$.value !== state || outcome.kind !== "adopt" ||
        outcome.rotator !== transition.rotator ||
        !this.sameMaterialCoordinate(outcome.next.material, transition.material) ||
        outcome.next.material.control_root !== transition.material.control_root
      ) return false;
    }
    // A sibling can arrive while a later hop's signer decrypt is pending. Check
    // every predecessor again after ALL awaited selections, then check authority
    // synchronously so the last await cannot reopen a stale completion window.
    const latest = await Promise.resolve(this.storeFor("rekey").getTimeline([{}]));
    if (this.disposed || this.state$.value !== state) return false;
    const latestEvents = latest.map(decodedFromRumor);
    return transitions.every((transition) =>
      identity(relevant(transition.keys.material, latestEvents)) ===
        identity(relevant(transition.keys.material, transition.events))
    );
  }

  /** Compare material independent of object field order and absent empty archives. */
  private sameMaterial(left: JoinMaterial, right: JoinMaterial): boolean {
    return canonicalJson({ ...left, held_roots: left.held_roots ?? [] }) ===
      canonicalJson({ ...right, held_roots: right.held_roots ?? [] });
  }

  /** Reconcile local deltas, preserving complete archived pairs and only matching
   * signing capabilities. A deliberate local drop overrides the captured snapshot. */
  private reconcileMaterial(candidate: JoinMaterial, initial: JoinMaterial, current: JoinMaterial): JoinMaterial {
    const before = new Map(initial.channels.map((channel) => [channel.id, channel]));
    const held = new Map(current.channels.map((channel) => [channel.id, channel]));
    const channels = new Map(candidate.channels.map((channel) => [channel.id, channel]));
    for (const id of new Set([...before.keys(), ...held.keys()])) {
      const local = held.get(id);
      if (canonicalJson(before.get(id)) !== canonicalJson(local)) {
        if (local) channels.set(id, local);
        else channels.delete(id);
      } else if (local && local.epoch > (channels.get(id)?.epoch ?? -1)) channels.set(id, local);
    }
    const roots = new Map<string, NonNullable<JoinMaterial["held_roots"]>[number]>();
    for (const root of [...candidate.held_roots ?? [], ...current.held_roots ?? []]) {
      if (
        root.candidate_id === undefined && root.epoch === candidate.root_epoch &&
        root.key === candidate.community_root && root.control_pk === candidate.control_pk &&
        (root.control_root === undefined || root.control_root === candidate.control_root)
      ) continue;
      const id = JSON.stringify([
        root.epoch,
        root.key,
        root.control_pk,
        root.prev_root,
        root.refounder,
        root.candidate_id,
      ]);
      const old = roots.get(id);
      roots.set(id, old?.control_root ? old : root);
    }
    let material = { ...candidate, channels: [...channels.values()] };
    if (roots.size) material = { ...material, held_roots: [...roots.values()] };
    if (this.sameMaterialCoordinate(candidate, current)) {
      const entry = (value: JoinMaterial) => ({
        community_id: value.community_id,
        current: value,
        seed: value,
        added_at: 0,
      });
      const merged = mergeCommunities([entry(material)], [entry(current)])[0].current;
      if (merged.control_root) material = { ...material, control_root: merged.control_root };
    }
    return material;
  }

  /** CORD-02 §8/CORD-06 §3: persist the whole reconciled winner before installing
   * keys, signers, state or stream coordinates. Rebuild after local mutations. */
  private async commitMaterial(candidate: ConcordKeys, initial: JoinMaterial): Promise<boolean> {
    const release = await this.acquireMaterialTransition();
    try {
      for (let attempt = 0; attempt < 3 && !this.disposed; attempt++) {
        const guard = this.rotationGuards.get(candidate);
        if (guard && !await guard()) return false;
        if (this.disposed) return false;
        const current = this.material;
        if (!this.sameMaterialCoordinate(initial, current)) return false;
        const material = this.reconcileMaterial(candidate.material, initial, current);
        const next = deriveConcordKeys(material, this.state$.value.channels, candidate);
        const saved = !this.sameMaterial(material, current);
        if (saved) await this.onMaterialChange?.(material);
        if (this.disposed) {
          if (saved) await this.persistHeldMaterial();
          return false;
        }
        if (guard && !await guard()) {
          // Storage may have accepted the staged pair before new signed evidence
          // retired it. Restore the held durable coordinate before reevaluation,
          // including when a demotion leaves no next adoptable candidate.
          if (saved) await this.persistHeldMaterial();
          return false;
        }
        if (this.disposed || !this.sameMaterialCoordinate(initial, this.material)) {
          if (saved) await this.persistHeldMaterial();
          return false;
        }
        if (this.material !== current) continue;
        this.keys = next;
        this.rotation?.latch(material.root_epoch, hexToBytes(material.community_root));
        this.materialFailureReported = false;
        this.error$.next(null);
        if (next.control.signing) this.signers.register([next.control.signing]);
        this.trimStaleGuestbookStores();
        this.rewireState();
        this.materialChanged$.next();
        this.epoch$.next(material.root_epoch);
        return true;
      }
      if (this.disposed) return false;
      throw new Error("material reconciliation exhausted");
    } finally {
      release();
    }
  }

  /** Restore durable material after a saved candidate becomes obsolete, rebasing
   * synchronous local deltas while the existing transition lane remains held.
   * Disposal cancels exposure, but cannot cancel cleanup of an accepted save. */
  private async persistHeldMaterial(): Promise<void> {
    for (let attempt = 0; attempt < 3; attempt++) {
      const current = this.material;
      await this.onMaterialChange?.(current);
      if (this.material === current) return;
    }
    throw new Error("held material reconciliation exhausted");
  }

  /** A channel Rekey excluded us: drop the sub-engine and our now-stale key (so we
   *  don't respawn an engine that just re-detects removal). Synced messages remain. */
  private onPrivateChannelRemoved(channelId: string): void {
    this.dropChannelKey(channelId);
  }

  /** Forget a private channel's key and dispose its sub-engine (idempotent). The
   *  shared teardown behind both an involuntary Rekey removal
   *  ({@link onPrivateChannelRemoved}) and a voluntary {@link leaveChannel}. */
  private dropChannelKey(channelId: string): void {
    const engine = this.privateChannels.get(channelId);
    if (engine) {
      engine.dispose();
      this.privateChannels.delete(channelId);
    }
    if (!hasChannelKey(this.material, channelId)) return;
    const channels = this.material.channels.filter((c) => c.id !== channelId);
    this.keys = deriveConcordKeys({ ...this.material, channels }, this.state$.value.channels, this.keys);
    this.onMaterialChange?.(this.keys.material);
    this.materialChanged$.next();
  }

  /**
   * Voluntarily leave a private channel (CORD-03): drop our copy of the channel
   * key and dispose its sub-engine, then persist. Purely local — no rotation, so
   * the remaining members are undisturbed. Self-exclude via {@link rotateChannel}
   * is impossible (you can never strictly outrank yourself), so a local key-drop
   * is the only self-leave. Messages already synced to cache stay readable; new
   * channel traffic no longer decodes.
   */
  async leaveChannel(channelId: string): Promise<void> {
    this.dropChannelKey(channelId);
  }

  /** Folds the retained root rekey events into an adopt / removed / none decision, gated on
   *  the rotator's authority in the CURRENT folded state — the live sibling of the check
   *  the sync walk makes per epoch. */
  private async readRootRotation(): Promise<RekeyOutcome> {
    if (this.disposed || this.phase$.value !== "live") return { kind: "none" };
    const initial = this.material;
    const state = this.state$.value;
    // `getTimeline` is sync for an in-memory store and a Promise for an async-database-backed one.
    const rekeyTimeline = await Promise.resolve(this.storeFor("rekey").getTimeline([{}]));
    const rekeyEvents = rekeyTimeline.map((rumor) => decodedFromRumor(rumor));
    if (rekeyEvents.length === 0) return { kind: "none" };
    const diagnostics: NonNullable<RekeyOutcome["diagnostics"]> = [];
    for (const keys of this.rootRekeyKeys(initial)) {
      const events = currentBaseRekeys(keys.material, rekeyEvents);
      if (!events.length) continue;
      const predecessor = keys.material.root_epoch < initial.root_epoch;
      const outcome = await readRekey(
        keys,
        events,
        refoundAuthority(state),
        this.pubkey,
        this.signer,
        state.channels,
        // A rotator may only remove US if they also strictly outrank us (CORD-04/
        // CORD-06 §3 "in both"), so an under-ranked BAN holder can't rotate a
        // higher-ranked member out via a root Refounding (mirrors spawnPrivateChannel).
        refoundAuthority(state, PERM.BAN, this.pubkey),
        // D-08/D-12: vac-verify against this SAME folded state (the live-check
        // sibling of sync.ts's syncEpoch gate).
        vacVerifier(state, PERM.BAN),
        predecessor ? initial : undefined,
      );
      if (this.disposed || !this.sameMaterialCoordinate(initial, this.material)) return { kind: "none" };
      diagnostics.push(...outcome.diagnostics ?? []);
      if (outcome.kind === "removed") {
        if (!predecessor) return { ...outcome, diagnostics };
        continue; // A held next epoch is positive keep-evidence, never removal.
      }
      if (outcome.kind === "adopt" && (!predecessor || outcome.next.material.community_root < initial.community_root)) {
        this.rotationOrigins.set(outcome.next, initial);
        const evidence = canonicalJson(events.map((event) => event.rumor.id).sort());
        const parsed = events.map(parseRekeyResult).find((result) =>
          result.kind === "parsed" && result.value.rotator === outcome.rotator
        );
        const vac = parsed?.kind === "parsed" ? parsed.value.vac : undefined;
        // CORD-04 §5/CORD-06 §3: capture selected receive evidence and shared
        // current authority. A sibling or demotion during storage retires this
        // completion; the coordinator folds the newest snapshot before retrying.
        this.rotationGuards.set(outcome.next, async () => {
          if (this.disposed) return false;
          const timeline = await Promise.resolve(this.storeFor("rekey").getTimeline([{}]));
          if (this.disposed) return false;
          const currentEvents = currentBaseRekeys(keys.material, timeline.map(decodedFromRumor));
          if (canonicalJson(currentEvents.map((event) => event.rumor.id).sort()) !== evidence) return false;
          const current = this.state$.value;
          return refoundAuthority(current)(outcome.rotator) &&
            vacVerifier(current, PERM.BAN)(outcome.rotator, vac);
        });
        return { ...outcome, diagnostics };
      }
      const retained = outcome.kind === "none" ? outcome.retainedMaterial : outcome.next.material;
      if (retained?.held_roots?.length) {
        const next = deriveConcordKeys(
          this.reconcileMaterial({ ...initial, held_roots: retained.held_roots }, initial, initial),
          state.channels,
          this.keys,
        );
        if (!this.sameMaterial(next.material, this.material)) {
          await this.commitMaterial(next, initial);
        }
      }
      if (diagnostics.some((diagnostic) => diagnostic.reason === "paired-control-conflict")) break;
    }
    return { kind: "none", ...(diagnostics.length ? { diagnostics } : {}) };
  }

  /** Moves the community into its terminal error state and stops listening. For fatal
   *  rotation failures only — routine per-candidate rejections go to `rotationDiagnostics$`. */
  private failRotation(cause: unknown): void {
    if (this.disposed) return;
    this.error$.next(cause instanceof Error ? cause.message : String(cause));
    this.phase$.next("error");
    this.liveSub?.unsubscribe();
  }

  /** Preserve committed reads and the original local failure while a candidate
   * remains retryable. Repeated failed notifications emit one bounded diagnostic. */
  private failMaterialTransition(cause: unknown): void {
    if (this.disposed) return;
    this.error$.next("material transition failed");
    if (this.materialFailureReported) return;
    this.materialFailureReported = true;
    this.rotationDiagnostics.next({
      scopeId: "root",
      candidateId: "material",
      status: "parked",
      reason: "transition-failed",
      cause,
    });
  }

  /** Follow a Refounding forward: swap in the rolled-forward key state, reopen the
   *  live subscription at the new epoch's addresses, and re-walk each private
   *  channel — a Refounding may bundle a channel Rekey sealed under the prior root
   *  (CORD-06 §3) and the channel-rekey address keys on the (now-changed) root. */
  private async adoptRefounding(next: ConcordKeys): Promise<boolean> {
    // Persistence is the commit barrier: until the complete candidate material
    // is durable, every public subject and every live/store binding continues to
    // describe the previously settled root.
    if (!await this.commitMaterial(next, this.rotationOrigins.get(next) ?? this.material)) {
      if (!this.disposed && this.phase$.value === "live") this.rotation.notify();
      return false;
    }
    this.openLive();
    for (const engine of this.privateChannels.values()) void engine.refreshForCommunityEpoch();
    // The root just rolled, so every live invite bundle now carries a stale
    // community_root. Ask the client to re-post them behind their unchanged URLs
    // (CORD-05 §2); it holds the per-link signer secrets, we don't.
    this.onRefounded?.(this.communityId);
    this.foldLog("refounding adopted epoch=%d", this.keys.material.root_epoch);
    return true;
  }

  /** Handles a Refounding that excluded us: report `"removed"`, tear down, then notify the
   *  client. Already-synced history stays readable; the new epoch simply never decodes. */
  private handleRemoved(): void {
    const cid = this.communityId;
    this.log("community removed cid=%s", cid.slice(0, 8));
    this.phase$.next("removed");
    this.dispose();
    this.onRemoved?.(cid);
  }

  /** The epoch a channel's outgoing messages bind to — its own for a private channel, the
   *  community root's for a public one. */
  private channelEpoch(channelId: string): number {
    return channelEpochOf(this.keys, channelId);
  }

  /** CHAN-02/D-06: throw a typed, `instanceof`-catchable {@link MissingChannelKeyError}
   *  if `channelId` is a KNOWN private channel we hold no key for — before
   *  `channelEpoch`/`planeKeyFor` are ever reached. A truly-unknown id (absent
   *  from `state.channels`) is NOT covered here; it still surfaces `planeKeyFor`'s
   *  generic `unknown channel` backstop. A public or keyed-private channel passes
   *  through untouched. */
  private requireChannelKey(channelId: string): void {
    const channel = this.state$.value.channels.find((c) => c.channel_id === channelId);
    if (channel?.private && !hasChannelKey(this.material, channelId)) throw new MissingChannelKeyError(channelId);
  }

  /** Publish ANY event to a channel (CORD-03) — a factory promise, a template, or
   *  a signed event. The channel/epoch binding + ms ordering are appended before
   *  the rumor is sealed + wrapped. */
  async sendEvent(
    channelId: string,
    source: PromiseLike<EventTemplate> | EventTemplate,
    opts: { plaintext?: boolean; ephemeral?: boolean; ephemeralSk?: Uint8Array } = {},
  ): Promise<string> {
    this.requireChannelKey(channelId);
    const epoch = this.channelEpoch(channelId);
    const rumor = await bindToChannel(channelId, epoch)(await source);
    return this.publishToPlane({ plane: "channel", channelId }, rumor, opts);
  }

  /** Send a chat message, optionally with attachments, a reply parent and custom emoji.
   *  Files are encrypted and uploaded before the message is published, so the rumor never
   *  references a blob that is not yet retrievable. */
  async sendMessage(
    channelId: string,
    text: string,
    replyTo?: { id: string; author: string },
    files?: Blob[],
    emojis?: Emoji[],
    options: ConcordSendMessageOptions = {},
  ): Promise<void> {
    this.requireChannelKey(channelId);
    // Resolve the wrapping key now so an unknown channel fails before any upload.
    planeKeyFor(this.keys, { plane: "channel", channelId });
    const epoch = this.channelEpoch(channelId);
    let content = text;
    let attachments: MediaAttachment[] | undefined;
    if (files?.length) {
      if (!this.uploader) throw new Error("no uploader configured: cannot send file attachments");
      attachments = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        let phase: ConcordUploadProgress["phase"] = "encrypting";
        const emit = (next: ConcordUploadProgress["phase"]) => {
          phase = next;
          options.onUploadProgress?.({ total: files.length, done: i, phase });
        };
        emit("encrypting");
        const attachment = await this.uploader.upload(file, this.communityId, { onProgress: emit });
        if (!attachment.url) throw new Error("uploader did not return a url");
        attachments.push(attachment);
        options.onUploadProgress?.({ total: files.length, done: i + 1, phase });
        content = content ? `${content}\n${attachment.url}` : attachment.url;
      }
    }

    let factory = ChatMessageFactory.create(content, { emojis });
    if (replyTo) factory = factory.replyTo({ id: replyTo.id, author: replyTo.author });
    if (attachments?.length) factory = factory.attachments(attachments);
    const encryption: MediaEncryption[] = (attachments ?? [])
      .filter(
        (a): a is MediaAttachment & { url: string; encryption: AttachmentEncryption } => !!a.url && !!a.encryption,
      )
      .map((a) => ({ url: a.url, ...a.encryption }));

    let rumor = await bindToChannel(channelId, epoch)(await factory);
    rumor = await includeMediaEncryption(encryption)(rumor);
    await this.publishToPlane({ plane: "channel", channelId }, rumor, {});
  }

  /** Post a NIP-7D forum thread (kind 11) to a channel. */
  async sendThread(channelId: string, title: string, body = ""): Promise<void> {
    this.requireChannelKey(channelId);
    const epoch = this.channelEpoch(channelId);
    const rumor = await bindToChannel(channelId, epoch)(await ForumThreadFactory.create(title, body));
    await this.publishToPlane({ plane: "channel", channelId }, rumor, {});
  }

  /** Reply to a channel thread with a NIP-22 kind 1111 comment (NIP-7D). */
  async replyToThread(channelId: string, parent: Rumor, body: string): Promise<void> {
    this.requireChannelKey(channelId);
    const epoch = this.channelEpoch(channelId);
    const rumor = await bindToChannel(channelId, epoch)(await CommentFactory.create(parent, body));
    await this.publishToPlane({ plane: "channel", channelId }, rumor, {});
  }

  /** React to a message with an emoji or a custom emoji reference. */
  async react(channelId: string, target: Rumor, reaction: string | Emoji): Promise<void> {
    this.requireChannelKey(channelId);
    const epoch = this.channelEpoch(channelId);
    const rumor = await bindToChannel(channelId, epoch)(await ReactionFactory.create(target, reaction));
    await this.publishToPlane({ plane: "channel", channelId }, rumor, {});
  }

  /** Publish a replacement body for one of our own messages. Readers apply the edit; the
   *  original rumor remains on relays. */
  async editMessage(channelId: string, targetId: string, text: string): Promise<void> {
    this.requireChannelKey(channelId);
    const epoch = this.channelEpoch(channelId);
    const rumor = await bindToChannel(channelId, epoch)(await EditFactory.create(targetId, text));
    await this.publishToPlane({ plane: "channel", channelId }, rumor, {});
  }

  /** Request deletion of a message. A request, not an erasure — relays and peers that
   *  already hold the rumor decide whether to honour it. */
  async deleteMessage(channelId: string, target: Rumor): Promise<void> {
    this.requireChannelKey(channelId);
    const epoch = this.channelEpoch(channelId);
    // A Concord Rumor never carries a `sig`, so `setDeleteEvents`' `isEvent(event)`
    // branch never fires for it and no "k" tag would be emitted. Pass only the id
    // (the bare-string branch) and apply `ensureKTag` explicitly with the target's
    // real kind on the awaited template before binding it to the channel.
    const template = await DeleteFactory.fromEvents([target.id]);
    const withKTag = { ...template, tags: ensureKTag(template.tags, target.kind) };
    const rumor = await bindToChannel(channelId, epoch)(withKTag);
    await this.publishToPlane({ plane: "channel", channelId }, rumor, {});
  }

  //
  // Each of these is a CORD-04 edition: the version/hash chain, the entity
  // coordinates, and the authority resolution all live in ConcordCommunityControl.
  // They stay exposed here so an app never has to know which plane an action lands
  // on — `kick` writes the guestbook, `ban` the control plane, and both read the
  // same to a caller.

  /** Patch the community metadata. Delegates to {@link ConcordCommunityAdmin.editMetadata}. */
  editMetadata(patch: Partial<CommunityMetadata>): Promise<void> {
    return this.admin.editMetadata(patch);
  }

  /** Encrypt an image via the uploader and publish it as the icon or banner. */
  setCommunityImage(which: "icon" | "banner", file: Blob): Promise<void> {
    return this.admin.setCommunityImage(which, file);
  }

  /** Clear the icon or banner. Delegates to the admin surface. */
  removeCommunityImage(which: "icon" | "banner"): Promise<void> {
    return this.admin.removeCommunityImage(which);
  }

  /** Create a channel and return its id. Delegates to the admin surface. */
  createChannel(name: string, options?: CreateChannelOptions): Promise<string> {
    return this.admin.createChannel(name, options);
  }

  /** Retire a channel; its id is never reused. Delegates to the admin surface. */
  deleteChannel(channelId: string): Promise<void> {
    return this.admin.deleteChannel(channelId);
  }

  /**
   * Mint a Role (CORD-04 §2). A server-scoped role (the default) grants rank
   * community-wide; a channel-scoped role (`{kind:"channel", channel_id}`) is the
   * spec's private-channel membership marker — its grant-holders are the intended
   * readership of that channel, kept in sync with key possession by the caller
   * (deliver on grant via {@link grantChannelAccess}, rekey on removal via
   * {@link rotateChannel}). A role mints no key, so this only records entitlement.
   */
  createRole(
    name: string,
    position: number,
    permissions: bigint,
    scope: RoleScope = { kind: "server" },
  ): Promise<string> {
    return this.admin.createRole(name, position, permissions, scope);
  }

  /** Patch a role in place. Delegates to the admin surface. */
  editRole(roleId: string, patch: Partial<Omit<Role, "role_id">>): Promise<void> {
    return this.admin.editRole(roleId, patch);
  }

  /**
   * Retire a Role (CORD-04). The role stays in {@link CommunityState.roles} flagged
   * `deleted` — so it remains visible and compactable — but confers no permissions
   * or rank, stripping its authority from every grant-holder. Reverse with
   * `editRole(roleId, { deleted: false })`. Existing grants are left untouched.
   */
  deleteRole(roleId: string): Promise<void> {
    return this.admin.deleteRole(roleId);
  }

  /** Replace a member's role set. Delegates to the admin surface. */
  grantRoles(member: string, roleIds: string[]): Promise<void> {
    return this.admin.grantRoles(member, roleIds);
  }

  /** Strip a member's roles (control plane) and publish the Kick (guestbook). */
  async kick(member: string): Promise<void> {
    // CORD-04/AUTH-05: kicking is acting on member — the caller must strictly
    // outrank them, not merely hold KICK. Mirrors rotateChannel's exclude-loop
    // outrank throw (:1039-1041), single target instead of a loop.
    if (!refoundAuthority(this.state$.value, PERM.KICK, member)(this.pubkey)) {
      throw new Error(`cannot kick ${member} — you do not outrank them or lack KICK`);
    }
    await this.admin.grantRoles(member, []);
    const vac = await this.admin.vacFor(this.pubkey);
    await this.publishToPlane({ plane: "guestbook" }, await KickFactory.create(member, vac), {});
  }

  /** Ban a member (control plane). Severing their read access additionally needs
   *  {@link refound}. Delegates to the admin surface. */
  ban(member: string): Promise<void> {
    return this.admin.ban(member);
  }

  /** Lift a ban. Delegates to the admin surface. */
  unban(member: string): Promise<void> {
    return this.admin.unban(member);
  }

  /**
   * Channel-scoped Rekey (CORD-06): rotate a private channel's key to sever the
   * excluded members, delivering the new key only to `keep`. Requires
   * `MANAGE_CHANNELS`. The new key is persisted into `material.channels` once the
   * channel's sub-engine adopts the rotation.
   */
  async rotateChannel(channelId: string, opts: { keep: string[]; exclude?: string[] }): Promise<void> {
    const channelKey = this.material.channels.find((c) => c.id === channelId);
    if (!channelKey) throw new Error("not a private channel we hold a key for");
    const state = this.state$.value;
    if (!refoundAuthority(state, PERM.MANAGE_CHANNELS)(this.pubkey)) {
      throw new Error("need MANAGE_CHANNELS to rekey a channel");
    }

    // CORD-04: excluding a member is acting on them — the rotator must strictly
    // outrank each one, not merely hold MANAGE_CHANNELS.
    for (const target of opts.exclude ?? []) {
      if (!refoundAuthority(state, PERM.MANAGE_CHANNELS, target)(this.pubkey)) {
        throw new Error(`cannot exclude ${target} from the channel — you do not outrank them`);
      }
    }

    const excluded = new Set(opts.exclude ?? []);
    const recipients = [...new Set([this.pubkey, ...opts.keep])].filter((pk) => !excluded.has(pk));
    // CORD-04/D-08: cite our own Grant (undefined for the owner) so a receiver
    // can vac-verify this channel rekey against its folded Roster.
    const vac = await this.admin.vacFor(this.pubkey);
    const plan = await buildChannelRekey(this.material, channelKey, this.signer, {
      recipients,
      self: this.pubkey,
      vac,
    });

    const relays = this.transport();
    // WR-01: register the exact key `buildChannelRekey` finalized the wraps with —
    // never recompute the address from `this.material.community_root`, which can
    // roll forward mid-flight (via a concurrent `adoptRefounding()` on `checkRekey`'s
    // 200ms timer) after the awaits above, desyncing a recomputed address from what
    // the wraps actually carry.
    this.signers.register([plan.rekeyKey]);
    this.publishLog("rotating channel=%s", channelId.slice(0, 8));
    for (const wrap of plan.rekeyWraps) {
      await this.pool.publish(relays, wrap, this.streamPublishOptions(wrap)).catch((err) => {
        this.publishLog("channel rekey publish failed: %s", (err as Error)?.message ?? err);
        console.warn("channel rekey publish failed", err);
      });
    }

    // Optimistically hand the rekey to the channel's sub-engine so it adopts the
    // new key immediately (which persists it via onKeyChange); fall back to
    // persisting directly if no sub-engine is running yet.
    const engine = this.privateChannels.get(channelId);
    if (engine) { for (const wrap of plan.rekeyWraps) engine.ingest(wrap); }
    else this.persistChannelKey(plan.next);
  }

  /** Publish the community's dissolution. Owner only, and irreversible — the marker is a
   *  plaintext seal so every member can read it regardless of epoch. */
  async dissolve(): Promise<void> {
    if (this.pubkey !== this.material.owner) throw new Error("only the owner can dissolve");
    await this.publishToPlane({ plane: "dissolved" }, await DissolutionFactory.create(), { plaintext: true });
  }

  /** Publish our Leave and tear the community down. The manager tombstones the
   *  membership in the Community List. */
  async leave(): Promise<void> {
    await this.publishToPlane({ plane: "guestbook" }, await JoinLeaveFactory.create("leave"), {});
    this.dispose();
  }

  /** Mint a public invite link: generate its signer key, publish the bundle, and register
   *  the coordinate so the link counts toward the community being Public (CORD-05 §5). */
  async createInvite(options: CreateInviteOptions): Promise<ConcordInviteLink> {
    // CORD-05 §5: registering the link needs CREATE_INVITE. Check before the bundle is
    // published so an unauthorized call leaves nothing unopenable on relays.
    if (!this.canDo(PERM.CREATE_INVITE)) throw new Error("need CREATE_INVITE to create an invite");
    const token = newInviteToken();
    const linkSk = generateSecretKey();
    const linkPub = getPublicKey(linkSk);
    // D-16: register the fresh link-signer key immediately so this holder can answer
    // for it below — the invite bundle is signed by `linkSk`, not a community stream key.
    this.signers.addSecretKey(linkSk);

    const state = this.state$.value;
    const bundle = buildInviteBundle(this.material, {
      name: state.metadata?.name,
      icon: state.metadata?.icon,
      creator_npub: this.pubkey,
      label: options.label,
      expires_at: options.expiresAt,
      channels: options.channels,
    });

    const template = await InviteBundleFactory.create(bundle, token);
    const signed = finalizeEvent(template, linkSk);
    this.eventStore.add(signed);
    // D-05 leak surface (T-12.3-15): one shared local used to feed both a
    // signed URL and a publish target was the dual-meaning local named in
    // CONTEXT.md — split into two: `protocolRelays` (this community's own
    // relay set) is the only thing the signed invite-link URL ever sees;
    // `transportRelays` (the merged set) is where the bundle is actually
    // published. Neither local is reassigned after binding.
    const protocolRelays = this.relays();
    const transportRelays = this.transport();
    this.publishLog("publishing invite bundle link=%s", linkPub.slice(0, 8));
    this.pool.publish(transportRelays, signed, this.streamPublishOptions(signed)).catch((err) => {
      this.publishLog("bundle publish failed: %s", (err as Error)?.message ?? err);
      console.warn("bundle publish failed", err);
    });

    // Register the link into the community (CORD-05 §5) so it counts as Public.
    await this.admin.registerInviteLink(linkPub);

    const invite: ConcordInviteLink = {
      token: bytesToHex(token),
      signerSk: bytesToHex(linkSk),
      signerPubkey: linkPub,
      communityId: this.communityId,
      url: buildInviteLink(options.base, linkPub, token, protocolRelays),
      label: options.label,
      channels: options.channels,
      createdAt: Math.floor(Date.now() / 1000),
      expiresAt: options.expiresAt,
      revoked: false,
    };
    await this.onInviteCreated?.(invite);
    return invite;
  }

  /**
   * Re-post the given live invite bundles behind their unchanged URLs (CORD-05 §2).
   * Called after a Refounding: each bundle is rebuilt from the CURRENT material (the
   * fresh community_root, root_epoch, and channel keys) and re-signed under the same
   * `link_signer`, replacing the stale bundle at its coordinate (`d: ""`). The URL —
   * whose naddr is the link_signer pubkey and whose token is unchanged — keeps
   * opening, so a link shared once survives every rotation. Best-effort per link.
   */
  async refreshInviteBundles(links: ConcordInviteLink[]): Promise<void> {
    const state = this.state$.value;
    // This shared local feeds only the bundle publish (no URL builder call in
    // this method), so — unlike createInvite's dual-meaning local — it becomes
    // the transport local outright rather than needing a protocol/transport split.
    const transportRelays = this.transport();
    this.publishLog("refreshing %d invite bundle(s)", links.length);
    for (const link of links) {
      try {
        const bundle = buildInviteBundle(this.material, {
          name: state.metadata?.name,
          icon: state.metadata?.icon,
          creator_npub: this.pubkey,
          label: link.label,
          expires_at: link.expiresAt,
          channels: link.channels,
        });
        // D-16: register this link's signer key before publishing so this holder can
        // answer for it — the refreshed bundle is signed by the link key, not a stream key.
        this.signers.addSecretKey(hexToBytes(link.signerSk));
        const template = await InviteBundleFactory.create(bundle, hexToBytes(link.token));
        const signed = finalizeEvent(template, hexToBytes(link.signerSk));
        this.eventStore.add(signed);
        this.pool.publish(transportRelays, signed, this.streamPublishOptions(signed)).catch((err) => {
          this.publishLog("invite bundle refresh publish failed: %s", (err as Error)?.message ?? err);
          console.warn("invite bundle refresh publish failed", err);
        });
      } catch (err) {
        this.publishLog(
          "invite refresh skipped for link=%s: %s",
          link.signerPubkey.slice(0, 8),
          (err as Error)?.message ?? err,
        );
        // NEVER log `link.token` — it is the 128-bit secret that keys the
        // kind-33301 bundle (the only thing guarding `community_root`). The
        // signer pubkey identifies the same link and is already public on relays.
        console.warn(`invite refresh skipped for link ${link.signerPubkey}`, err);
      }
    }
  }

  /** Retire a public invite link: publish the bundle tombstone signed by the link's own key,
   *  then unregister its coordinate (CORD-05 §5). */
  async revokeInvite(invite: ConcordInviteLink): Promise<ConcordInviteLink> {
    this.publishLog("revoking invite link=%s", invite.signerPubkey.slice(0, 8));
    // D-16: register the link's signer key before publishing — the revocation is
    // signed by the link key, not a community stream key.
    this.signers.addSecretKey(hexToBytes(invite.signerSk));
    const template = await InviteBundleFactory.revoke();
    const signed = finalizeEvent(template, hexToBytes(invite.signerSk));
    let responses;
    try {
      responses = await this.pool.publish(this.transport(), signed, this.streamPublishOptions(signed));
    } catch (cause) {
      throw new InviteRevocationPublishError("member bundle publication", [], { cause });
    }
    requireInviteRevocationAck("member bundle publication", responses);
    this.eventStore.add(signed);
    try {
      await this.admin.unregisterInviteLink(invite.signerPubkey);
    } catch (cause) {
      if (cause instanceof InviteRevocationPublishError) throw cause;
      throw new Error("invite registry unregister failed after bundle publication", { cause });
    }

    const revoked = { ...invite, revoked: true };
    await this.onInviteRevoked?.(revoked);
    return revoked;
  }

  /**
   * Grant a member access to one or more private channels we hold (CORD-05 §6 /
   * CORD-03: "delivered on grant"). Hands over each channel's CURRENT `(key, epoch)`
   * — plus any held prior keys, so they read recent history — via a single Direct
   * Invite gift-wrapped to `member`. This is the spec-correct way to ADD someone: no
   * rotation and no epoch bump (rotations sever, and a {@link rotateChannel} can
   * never onboard a new holder — its continuity check requires the prior key).
   * The bundle carries only the requested channel keys (never the caller's other
   * private channels), so an inviter can hand-pick an arbitrary subset. Requires
   * `MANAGE_CHANNELS`. Publish is best-effort to the community relays, where the
   * recipient's Direct-Invite watcher also listens.
   */
  async grantChannelAccess(channels: string | string[], member: string): Promise<void> {
    const ids = [...new Set(Array.isArray(channels) ? channels : [channels])];
    if (ids.length === 0) throw new Error("no channels to grant");
    if (!this.canDo(PERM.MANAGE_CHANNELS)) throw new Error("need MANAGE_CHANNELS to grant channel access");

    const state = this.state$.value;
    const bundle: InviteBundle = buildInviteBundle(this.material, {
      name: state.metadata?.name,
      icon: state.metadata?.icon,
      creator_npub: this.pubkey,
      channels: ids,
    });

    const wrap = await DirectInviteFactory.create(bundle, member, this.signer);
    this.eventStore.add(wrap);
    this.publishLog("granting channel access channels=%d member=%s", ids.length, member.slice(0, 8));
    // D-16/D-17 deviation, deliberate: this is a NIP-59 Direct Invite whose ephemeral
    // author key `DirectInviteFactory.create` generates and destroys internally, never
    // exposing it to this engine — `streamPublishOptions` cannot name a key no client can
    // ever hold, and doing so would make the requirement unsatisfiable by construction
    // rather than merely unmet. The key a gating relay actually checks here is the
    // connection's authenticated identity, so this ONE site waits on any authenticated
    // user and answers with the user's own handler. No other publish in this class
    // takes this shape — every other one names its own author.
    await this.pool
      .publish(this.transport(), wrap, { waitForAuth: true, onAuthRequired: this.userOnAuthRequired })
      .catch((err) => {
        this.publishLog("channel grant publish failed: %s", (err as Error)?.message ?? err);
        console.warn("channel grant publish failed", err);
      });
  }

  /**
   * Recover the original authenticated seals for selected, unsuspended control
   * heads (CORD-06 §2). RumorStore projections omit seals, while the wrap store
   * retains them across held epochs. Selection belongs to the verified model;
   * this identity join never bootstraps or folds retained alternatives.
   */
  private controlHeadsWithSeals(): DecodedEvent[] {
    const verification = this.state$.value.controlVerification;
    if (!verification || verification.communityId !== this.communityId) return [];
    const decoded: DecodedEvent[] = [];
    for (const [pk, info] of this.keys.planes) {
      if (info.type !== "control") continue;
      for (const wrap of this.eventStore.getByFilters([{ kinds: [GIFT_WRAP_KIND], authors: [pk] }])) {
        // CORD-01 author binding: authenticate both envelopes again at recovery,
        // rather than treating a filter or a memoized decode as proof.
        // A copied/mutated event can still carry the SDK's verified symbol.
        // structuredClone strips symbol caches, forcing verification of bytes.
        if (!verifyWrappedEvent(structuredClone(wrap))) continue;
        const d = decodeWrap(wrap, info.convKey);
        if (d?.sealKind === PLAINTEXT_SEAL_KIND) decoded.push(d);
      }
    }
    const recovered: DecodedEvent[] = [];
    for (const head of verification.heads.values()) {
      if (verification.suspended.has(head.eid)) continue;
      const original = decoded.find((d) => {
        try {
          // CORD-04 §1: match the selected edition, including its actor, schema,
          // chain and verbatim content. Hash equality alone omits schema/actor.
          const tag = (name: string) => d.rumor.tags.find((t) => t[0] === name)?.[1];
          return d.rumor.id === head.edition.rumor.id && d.author === head.edition.author &&
            d.rumor.id === getEventHash(d.rumor) && d.rumor.content === head.edition.rumor.content &&
            tag("vsk") === String(head.vsk) && tag("eid") === head.eid && tag("ep") === head.prevHash &&
            resolveEditionPin([d], [head.eid, String(head.version), head.hash]).kind === "matched";
        } catch {
          return false;
        }
      });
      if (!original) {
        throw new Error(`refounding aborted: original control seal unavailable for ${head.eid}`);
      }
      recovered.push(original);
    }
    return recovered;
  }

  /** Rotate the community root (CORD-06 §3) — the enforcement step behind a ban. Mints a new
   *  root, delivers it only to `keep`, and publishes the compaction and snapshot artifacts.
   *  Durable only once the mandatory artifacts reach a common relay majority. */
  async refound(opts: {
    keep: string[];
    exclude?: string[];
    /**
     * Per-private-channel keep lists (CORD-06 §3). ONLY the named channels are
     * rotated, and each new channel key is delivered ONLY to its own `keep` set —
     * pass a channel's actual membership, never the community-wide keep set, or a
     * member who was never in the channel would be granted its key. Unnamed
     * private channels are left untouched: the excluded retain their existing
     * channel key until a separate {@link rotateChannel}.
     */
    channelRekeys?: Array<{ channelId: string; keep: string[] }>;
  }): Promise<RefoundingResult> {
    // D-08 / CORD-02 §5: fail before queuing, pending storage, or remote signer I/O.
    assertBaseRotationSupported(this.material);
    const captured = {
      ...opts,
      keep: [...opts.keep],
      exclude: [...(opts.exclude ?? [])],
      channelRekeys: opts.channelRekeys?.map((entry) => ({ channelId: entry.channelId, keep: [...entry.keep] })),
    };
    const operation = this.refoundingTail.then(() => this.prepareRefounding(captured));
    this.refoundingTail = operation.then(() => {}, () => {});
    return operation;
  }

  /** Prepare a single immutable operation under captured shared authority (CORD-06 §3). */
  private async prepareRefounding(opts: Parameters<ConcordCommunity["refound"]>[0]): Promise<RefoundingResult> {
    assertBaseRotationSupported(this.material);
    if (!this.signer.nip44) throw new Error("this signer can't rotate keys (NIP-44 unsupported)");
    const initialMaterial = JSON.stringify(this.material);
    const stateIdentity = () =>
      JSON.stringify(
        this.state$.value,
        (_key, value) => value instanceof Map ? [...value] : value instanceof Set ? [...value] : value,
      );
    const initialState = stateIdentity();
    const loadGuard = () => {
      if (this.disposed || JSON.stringify(this.material) !== initialMaterial || stateIdentity() !== initialState) {
        throw new Error("refounding preparation changed; operation blocked");
      }
    };
    const stored = await this.pendingRefounding.load(loadGuard);
    loadGuard();
    if (await this.signer.getPublicKey() !== this.pubkey) throw new Error("refounding signer does not match actor");
    loadGuard();
    // CORD-06 §3: a losing parent remains immutable; equal epochs never adopt
    // its obsolete pair. Repair only after the lower full pair is committed.
    if (
      stored && this.material.root_epoch === stored.plan.newEpoch &&
      this.material.community_root < stored.plan.next.material.community_root
    ) {
      return await this.recoverLosingRefounding(stored);
    }
    // CORD-06 §3: retries resume signed work, never caller replacement options.
    if (stored?.preparation) {
      const savedRequest = JSON.parse(stored.preparation.request) as {
        recipients: string[];
        excluded: string[];
        channels: Array<[string, string[]]>;
      };
      opts = {
        keep: savedRequest.recipients,
        exclude: savedRequest.excluded,
        channelRekeys: savedRequest.channels.map(([channelId, keep]) => ({ channelId, keep })),
      };
    }
    const state = this.state$.value;
    if (!refoundAuthority(state)(this.pubkey)) throw new Error("need BAN or ownership to refound");
    if (opts.channelRekeys?.length && !refoundAuthority(state, PERM.MANAGE_CHANNELS)(this.pubkey)) {
      throw new Error("need MANAGE_CHANNELS for bundled private channel rekeys");
    }

    // CORD-04/CORD-06 §3: excluding a member is acting on them — the rotator must
    // strictly outrank each excluded target, not merely hold BAN (mirrors
    // rotateChannel's outrank loop). Throws before anything is built or published,
    // so a failed check aborts the whole Refounding atomically — no partial rotation.
    for (const target of opts.exclude ?? []) {
      if (!refoundAuthority(state, PERM.BAN, target)(this.pubkey)) {
        throw new Error(`cannot exclude ${target} — you do not outrank them`);
      }
      if (opts.channelRekeys?.length && !refoundAuthority(state, PERM.MANAGE_CHANNELS, target)(this.pubkey)) {
        throw new Error(`cannot exclude ${target} from bundled channels — you do not outrank them`);
      }
    }

    const excluded = new Set(opts.exclude ?? []);
    const recipients = [...new Set([this.pubkey, ...opts.keep])].filter((pk) => !excluded.has(pk));
    if (!recipients.includes(this.pubkey)) throw new Error("refounding recipients must include self");
    const request = JSON.stringify({
      recipients: [...recipients].sort(),
      excluded: [...excluded].sort(),
      channels: (opts.channelRekeys ?? []).map((c) => [c.channelId, [...new Set(c.keep)].sort()]).sort(),
    });
    const heads = this.controlHeadsWithSeals();
    const identity = () => {
      const current = this.state$.value;
      const verification = current.controlVerification;
      return JSON.stringify({
        material: this.material,
        actor: this.pubkey,
        roles: [...current.roles].sort((a, b) => a.role_id.localeCompare(b.role_id)),
        grants: [...current.grants].sort(),
        bans: [...current.banlist].sort(),
        channels: current.channels,
        heads: verification
          ? [...verification.heads].map((
            [eid, h],
          ) => [eid, h.vsk, h.version, h.hash, h.edition.author, h.edition.rumor.id]).sort()
          : [],
        suspended: verification ? [...verification.suspended].sort() : [],
        support: verification
          ? [...verification.grantHistory].map((
            [eid, history],
          ) => [eid, history.map((h) => [h.version, h.hash]).sort()]).sort()
          : [],
        recipients: recipients.map((pubkey) => [pubkey, isCurrentStaff(current, pubkey)]),
        originals: this.controlHeadsWithSeals().map((h) => JSON.stringify(h.seal)).sort(),
      });
    };
    let fingerprint = identity();
    let vac: [string, string, string] | undefined;
    const assertCurrent = () => {
      const current = this.state$.value;
      let same = false;
      try {
        same = identity() === fingerprint;
      } catch { /* Missing authenticated originals invalidates preparation. */ }
      if (
        this.disposed || !same || !refoundAuthority(current)(this.pubkey) ||
        (vac !== undefined && !vacVerifier(current, PERM.BAN)(this.pubkey, vac)) ||
        (opts.channelRekeys?.length && !refoundAuthority(current, PERM.MANAGE_CHANNELS)(this.pubkey)) ||
        [...excluded].some((target) =>
          !refoundAuthority(current, PERM.BAN, target)(this.pubkey) ||
          (opts.channelRekeys?.length && !refoundAuthority(current, PERM.MANAGE_CHANNELS, target)(this.pubkey))
        )
      ) {
        throw new Error("refounding preparation changed; operation blocked");
      }
    };
    assertCurrent();
    if (
      stored?.blocked ||
      (stored?.preparation &&
        stored.priorEpoch === this.material.root_epoch && stored.preparation.fingerprint !== fingerprint)
    ) {
      throw new Error("refounding preparation changed; pending operation blocked");
    }
    if (
      stored &&
      stored.priorEpoch !== this.material.root_epoch &&
      stored.plan.next.material.root_epoch !== this.material.root_epoch
    ) {
      throw new Error("pending refounding epoch does not match current material");
    }
    if (stored) {
      const held = stored.plan.next.material.held_roots?.find((h) =>
        h.epoch === stored.priorEpoch &&
        h.key === this.material.community_root
      );
      const atPrior = this.material.root_epoch === stored.priorEpoch && held &&
        held.control_pk === this.material.control_pk && held.control_root === this.material.control_root &&
        stored.plan.rekeyKey.pk === this.keys.nextBaseRekey.key.pk;
      const atNext = this.sameMaterialCoordinate(this.material, stored.plan.next.material) &&
        this.material.control_root === stored.plan.next.material.control_root;
      if (!atPrior && !atNext) throw new Error("pending refounding material does not match current coordinate");
      if ((stored.stage === "adopted" || stored.stage === "snapshot-attempted") && !atNext) {
        throw new Error("pending refounding adoption does not match current coordinate");
      }
    }

    // D-06: `protocolRelays` stays the protocol/counting set — the majority
    // threshold and the ack attribution below both read ONLY this local, derived
    // ONCE via `mergeRelaySets` (T-12.3-09-01/02) so a duplicate-by-normalization
    // entry or an unparseable entry can never make the two halves disagree, and
    // an unparseable entry can never throw instead of being dropped.
    // `transportRelays` (the merged set) is where every wrap is actually
    // published, so the split is visible in the diff rather than only in a
    // comment.
    const protocolRelays = stored?.protocolRelays ?? mergeRelaySets(this.relays());
    const transportRelays = this.transport();

    // Bundle a channel Rekey ONLY for the explicitly-named private channels, each
    // delivered to that channel's own membership (CORD-06 §3). Delivering to the
    // community keep set would over-grant — a kept member who was never in a
    // private channel would receive its key — so scoping is the caller's to supply.
    const channelRekeys = (opts.channelRekeys ?? []).flatMap(({ channelId, keep }) => {
      const channel = this.material.channels.find((c) => c.id === channelId);
      if (!channel) return [];
      const recips = [...new Set([this.pubkey, ...keep])].filter((pk) => !excluded.has(pk));
      return [{ channel, recipients: recips }];
    });

    // CORD-04/D-08: cite our own Grant (undefined for the owner) so a receiver
    // can vac-verify this Refounding (and any bundled channel rekeys) against
    // its folded Roster.
    let pending: PendingRefoundingRecord;
    if (stored) {
      pending = stored;
    } else {
      const priorEpoch = this.material.root_epoch;
      vac = await this.admin.vacFor(this.pubkey);
      assertCurrent();
      const plan = await buildRefounding(this.keys, this.signer, {
        state,
        recipients,
        self: this.pubkey,
        heads,
        channels: state.channels,
        channelRekeys,
        vac,
        assertCurrent,
      });
      assertCurrent();
      const rotationId = plan.rekeyWraps[0]?.id ?? plan.compactionWraps[0]?.id ?? `epoch-${plan.newEpoch}`;
      pending = {
        version: 1,
        communityId: this.communityId,
        priorEpoch,
        rotationId,
        stage: "prepared",
        plan,
        mandatoryEvidence: [],
        commonRelays: [],
        warnings: [],
        protocolRelays,
        preparation: {
          fingerprint,
          request,
          recipients: recipients.map((pubkey) => ({ pubkey, staff: isCurrentStaff(state, pubkey) })),
          excluded: [...excluded],
          channelIds: channelRekeys.map((c) => c.channel.id),
        },
      };
      await this.pendingRefounding.save(pending, assertCurrent);
    }
    const plan = pending.plan;
    assertCurrent();
    const assertResumeAuthority = () => {
      for (const wrap of [...plan.rekeyWraps, ...plan.channelRekeyWraps]) {
        const key = wrap.pubkey === plan.rekeyKey.pk
          ? plan.rekeyKey
          : plan.channelRekeyKeys.find((k) => k.pk === wrap.pubkey);
        const decoded = key && decodeReceivedWrap(wrap, { type: "rekey", convKey: key.convKey });
        const parsed = decoded && parseRekeyResult(decoded);
        const permission = wrap.pubkey === plan.rekeyKey.pk ? PERM.BAN : PERM.MANAGE_CHANNELS;
        if (
          !parsed || parsed.kind !== "parsed" || parsed.value.rotator !== this.pubkey ||
          !refoundAuthority(this.state$.value, permission)(this.pubkey) ||
          !vacVerifier(this.state$.value, permission)(this.pubkey, parsed.value.vac)
        ) {
          throw new Error("refounding preparation changed; pending operation blocked");
        }
      }
      if (pending.preparation?.recipients.some((r) => r.staff !== isCurrentStaff(this.state$.value, r.pubkey))) {
        throw new Error("refounding preparation changed; pending operation blocked");
      }
    };
    assertResumeAuthority();

    // Rekey blobs (root + channels) gate convergence. WR-01:
    // register the exact keys `buildRefounding` finalized these wraps with —
    // `plan.rekeyKey` for the root-roll and `plan.channelRekeyKeys` for the
    // bundled channel rekeys — rather than relying on `this.keys.nextBaseRekey.key`
    // having already been registered by the walk/openLive(), or recomputing the
    // channel-rekey address from `this.material.community_root`. Either
    // recomputation can be stale: `checkRekey()`'s 200ms timer can call
    // `adoptRefounding()` during the awaits above, rolling `this.keys`/`this.material`
    // forward before this line runs, which is exactly when the plan's own key and a
    // freshly recomputed one diverge.
    this.signers.register([plan.rekeyKey]);
    this.signers.register(plan.channelRekeyKeys);
    this.signers.register([...(plan.next.control.signing ? [plan.next.control.signing] : []), plan.next.guestbook]);

    const mandatory: Array<{ artifact: RefoundingArtifact; wrap: NostrEvent }> = [
      ...plan.rekeyWraps.map((wrap) => ({ artifact: { id: wrap.id, kind: "root-rekey" as const }, wrap })),
      ...plan.channelRekeyWraps.map((wrap) => ({ artifact: { id: wrap.id, kind: "channel-rekey" as const }, wrap })),
      ...plan.compactionWraps.map((wrap) => ({ artifact: { id: wrap.id, kind: "control-compaction" as const }, wrap })),
    ];
    const rotationId = pending.rotationId;
    if (!pending.protocolRelays) {
      pending = { ...pending, protocolRelays };
      await this.pendingRefounding.save(pending, assertCurrent);
    }
    const coverageFor = (artifacts: typeof mandatory) =>
      evaluateCommonRelayCoverage(
        artifacts.map(({ artifact }) => ({
          artifact,
          responses: (pending.mandatoryEvidence.find((row) =>
            row.artifact.id === artifact.id && row.artifact.kind === artifact.kind
          )?.relays ?? [])
            .filter((row) => row.status === "accepted").map((row) => ({ from: row.relay, ok: true })),
        })),
        protocolRelays,
      );
    const publishBatch = async (artifacts: typeof mandatory) => {
      assertCurrent();
      if (await this.signer.getPublicKey() !== this.pubkey) throw new Error("refounding signer does not match actor");
      assertCurrent();
      assertResumeAuthority();
      const settled = await Promise.allSettled(
        artifacts.map(({ wrap }) => this.pool.publish(transportRelays, wrap, this.streamPublishOptions(wrap))),
      );
      const publications: RefoundingArtifactPublication[] = artifacts.map(({ artifact }, index) => {
        const result = settled[index];
        return result.status === "fulfilled"
          ? { artifact, responses: result.value }
          : { artifact, responses: [], cause: result.reason };
      });
      const coverage = evaluateCommonRelayCoverage(publications, protocolRelays);
      for (const row of coverage.evidence) {
        const old = pending.mandatoryEvidence.find((e) => e.artifact.id === row.artifact.id);
        if (old) {
          row.relays = row.relays.map((r) =>
            old.relays.some((o) => o.relay === r.relay && o.status === "accepted")
              ? { ...r, status: "accepted" as const }
              : r
          );
          row.acceptedRelays = row.relays.filter((r) => r.status === "accepted").map((r) => r.relay);
          row.causes = [...old.causes, ...row.causes];
        }
      }
      pending = {
        ...pending,
        mandatoryEvidence: [
          ...pending.mandatoryEvidence.filter((old) =>
            !coverage.evidence.some((row) => row.artifact.id === old.artifact.id)
          ),
          ...coverage.evidence,
        ],
      };
      try {
        assertCurrent();
        assertResumeAuthority();
      } catch (error) {
        pending = { ...pending, blocked: "stale-preparation" };
        await this.pendingRefounding.save(pending);
        throw error;
      }
      await this.pendingRefounding.save(pending, assertCurrent);
    };
    const roots = mandatory.filter(({ artifact }) => artifact.kind === "root-rekey");
    if (!coverageFor(roots).accepted) {
      pending = { ...pending, stage: "prepared" };
      await publishBatch(mandatory.filter(({ artifact }) => artifact.kind !== "control-compaction"));
      const rootsCoverage = coverageFor(roots);
      if (!rootsCoverage.accepted) {
        throw new RefoundingPublicationError(
          rotationId,
          pending.mandatoryEvidence.filter((row) => row.artifact.kind === "root-rekey"),
        );
      }
    }
    if (pending.stage === "prepared") {
      pending = await this.pendingRefounding.updateStage(pending, "root-confirmed", {}, assertCurrent);
    }
    if (pending.stage === "root-confirmed" || !coverageFor(mandatory).accepted) {
      await publishBatch(mandatory.filter(({ artifact }) => artifact.kind !== "root-rekey"));
      const coverage = coverageFor(mandatory);
      if (!coverage.accepted) throw new RefoundingPublicationError(rotationId, pending.mandatoryEvidence);
      pending = await this.pendingRefounding.updateStage(pending, "mandatory-confirmed", {
        commonRelays: coverage.commonRelays,
      }, assertCurrent);
    }

    this.publishLog("refounding publish targets=%d protocol=%d", transportRelays.length, protocolRelays.length);

    if (pending.stage === "mandatory-confirmed") {
      if (
        this.material.root_epoch !== plan.newEpoch ||
        this.material.community_root !== plan.next.material.community_root ||
        this.material.control_pk !== plan.next.material.control_pk ||
        this.material.control_root !== plan.next.material.control_root
      ) {
        const next = deriveConcordKeys(plan.next.material, this.state$.value.channels, this.keys);
        this.rotationGuards.set(next, async () => {
          try {
            assertCurrent();
            assertResumeAuthority();
            if (await this.signer.getPublicKey() !== this.pubkey) return false;
            assertCurrent();
            assertResumeAuthority();
            return true;
          } catch {
            return false;
          }
        });
        if (!await this.adoptRefounding(next)) throw new Error("refounding adoption superseded");
      }
      fingerprint = identity();
      pending = await this.pendingRefounding.updateStage(pending, "adopted", {}, assertCurrent);
    }

    const snapshotArtifacts = plan.snapshotWraps.map((wrap) => ({
      artifact: { id: wrap.id, kind: "guestbook-snapshot" as const },
      wrap,
    }));
    if (pending.stage === "adopted") {
      // Record intent before the best-effort network call. A crash after publish
      // must not replay a snapshot whose success is not correctness-critical.
      pending = await this.pendingRefounding.updateStage(pending, "snapshot-attempted", {}, assertCurrent);
      assertResumeAuthority();
      if (await this.signer.getPublicKey() !== this.pubkey) throw new Error("refounding signer does not match actor");
      assertCurrent();
      assertResumeAuthority();
      const snapshotSettled = await Promise.allSettled(
        snapshotArtifacts.map(({ wrap }) => this.pool.publish(transportRelays, wrap, this.streamPublishOptions(wrap))),
      );
      const snapshotPublications: RefoundingArtifactPublication[] = snapshotArtifacts.map(({ artifact }, index) => {
        const result = snapshotSettled[index];
        return result.status === "fulfilled"
          ? { artifact, responses: result.value }
          : { artifact, responses: [], cause: result.reason };
      });
      const snapshotCoverage = evaluateCommonRelayCoverage(snapshotPublications, protocolRelays);
      const warnings: RefoundingWarning[] = snapshotCoverage.accepted ? [] : [
        {
          kind: "guestbook-snapshot-publication",
          rotationId,
          artifactIds: snapshotArtifacts.map(({ artifact }) => artifact.id),
          evidence: snapshotCoverage.evidence,
          causes: snapshotCoverage.evidence.flatMap((row) => row.causes),
        },
      ];
      pending = { ...pending, warnings };
      await this.pendingRefounding.save(pending);
    }
    await this.pendingRefounding.remove();
    return {
      rotationId,
      epoch: plan.newEpoch,
      warnings: pending.warnings,
      evidence: pending.mandatoryEvidence,
      commonRelays: pending.commonRelays,
    };
  }

  /** CORD-06 §3: reissue authenticated branch-only secrets as durable channel
   * successors, keeping losing base/compaction artifacts out of the winner. */
  private async recoverLosingRefounding(record: PendingRefoundingRecord): Promise<RefoundingResult> {
    let pending = record;
    const winningEvidenceIdentity = () =>
      canonicalJson(
        this.eventStore.getTimeline([{ authors: [record.plan.rekeyKey.pk] }])
          .map((wire) => [wire.id, wire.pubkey, wire.sig, wire.created_at, wire.tags, wire.content]).sort(),
      );
    const winningEvidence = winningEvidenceIdentity();
    const stateIdentity = () =>
      JSON.stringify(
        this.state$.value,
        (_key, value) => value instanceof Map ? [...value] : value instanceof Set ? [...value] : value,
      );
    let fingerprint = stateIdentity();
    let material = canonicalJson(this.material);
    const assertCurrent = () => {
      const state = this.state$.value;
      if (
        this.disposed || canonicalJson(this.material) !== material || stateIdentity() !== fingerprint ||
        winningEvidenceIdentity() !== winningEvidence ||
        !refoundAuthority(state)(this.pubkey) ||
        (pending.plan.channelRekeyWraps.length > 0 && !refoundAuthority(state, PERM.MANAGE_CHANNELS)(this.pubkey)) ||
        (pending.preparation?.excluded ?? []).some((target) =>
          !refoundAuthority(state, PERM.BAN, target)(this.pubkey) ||
          (pending.plan.channelRekeyWraps.length > 0 &&
            !refoundAuthority(state, PERM.MANAGE_CHANNELS, target)(this.pubkey))
        )
      ) throw new Error("losing refounding recovery changed; operation blocked");
    };
    const refresh = () => {
      fingerprint = stateIdentity();
      material = canonicalJson(this.material);
    };
    try {
      assertCurrent();
      // Reopen real winning wire evidence at the parent's continuity point.
      // Current material alone, even with equal epoch or a lower read root, is
      // not proof that it descends from this operation's predecessor.
      const prior = pending.plan.next.material.held_roots!.find((h) =>
        h.epoch === pending.priorEpoch && h.key === this.material.prev_root
      );
      if (!prior) throw new Error("losing refounding winner continuity unavailable");
      const priorMaterial: JoinMaterial = {
        ...pending.plan.next.material,
        community_root: prior.key,
        root_epoch: prior.epoch,
      };
      delete priorMaterial.control_pk;
      delete priorMaterial.control_root;
      if (prior.control_pk !== undefined) priorMaterial.control_pk = prior.control_pk;
      if (prior.control_root !== undefined) priorMaterial.control_root = prior.control_root;
      const priorKeys = deriveConcordKeys(priorMaterial, this.state$.value.channels);
      const wires = await Promise.resolve(this.eventStore.getTimeline([{ authors: [pending.plan.rekeyKey.pk] }]));
      assertCurrent();
      const events = wires.flatMap((wire) => {
        const decoded = decodeReceivedWrap(wire, { type: "rekey", convKey: pending.plan.rekeyKey.convKey });
        return decoded ? [decoded] : [];
      });
      const winner = await readRekey(
        priorKeys,
        events,
        refoundAuthority(this.state$.value),
        this.pubkey,
        this.signer,
        this.state$.value.channels,
        refoundAuthority(this.state$.value, PERM.BAN, this.pubkey),
        vacVerifier(this.state$.value, PERM.BAN),
      );
      assertCurrent();
      if (winner.kind !== "adopt" || !this.sameMaterialCoordinate(winner.next.material, this.material)) {
        throw new Error("losing refounding winner not authenticated");
      }
      const losing = pending.plan.next.material;
      if (
        !this.material.held_roots?.some((h) =>
          h.epoch === losing.root_epoch && h.key === losing.community_root &&
          h.control_pk === losing.control_pk && h.control_root === losing.control_root
        )
      ) {
        const next = deriveConcordKeys(
          {
            ...this.material,
            held_roots: [
              ...this.material.held_roots ?? [],
              {
                epoch: losing.root_epoch,
                key: losing.community_root,
                ...(losing.control_pk !== undefined ? { control_pk: losing.control_pk } : {}),
                ...(losing.control_root !== undefined ? { control_root: losing.control_root } : {}),
                ...(losing.prev_root !== undefined ? { prev_root: losing.prev_root } : {}),
                ...(losing.refounder !== undefined ? { refounder: losing.refounder } : {}),
              },
            ],
          },
          this.state$.value.channels,
          this.keys,
        );
        this.rotationGuards.set(next, async () => {
          assertCurrent();
          return true;
        });
        if (!await this.commitMaterial(next, this.material)) throw new Error("losing history commit superseded");
        refresh();
      }
      const protocolRelays = pending.protocolRelays ?? mergeRelaySets(this.relays());
      const grouped = groupRotations(pending.plan.channelRekeyWraps.map((wrap) => {
        const key = pending.plan.channelRekeyKeys.find((key) => key.pk === wrap.pubkey)!;
        const parsed = parseRekeyResult(decodeReceivedWrap(wrap, { type: "rekey", convKey: key.convKey })!);
        if (parsed.kind !== "parsed") throw new Error("invalid losing channel operation");
        return parsed.value;
      }));
      const priorCoverage = evaluateCommonRelayCoverage(
        (pending.channelRepairs ?? []).flatMap((child) =>
          child.wraps.map((wrap) => ({
            artifact: { id: wrap.id, kind: "channel-rekey" as const },
            responses: (child.evidence.find((row) => row.artifact.id === wrap.id)?.acceptedRelays ?? [])
              .map((from) => ({ from, ok: true })),
          }))
        ),
        protocolRelays,
      );
      const needsCommon = !priorCoverage.accepted || grouped.length !== pending.channelRepairs?.length;
      for (const set of grouped) {
        assertCurrent();
        const blob = findBlob(set, rekeyLocator(this.pubkey, this.pubkey, set.scopeIdHex, set.newEpoch));
        if (!blob) throw new Error("losing channel secret unavailable");
        const text = await this.signer.nip44!.decrypt(this.pubkey, blob.wrapped);
        assertCurrent();
        const secret = decodeWrappedKey(base64ToBytes(text), hexToBytes(set.scopeIdHex), set.newEpoch);
        const held = this.material.channels.find((channel) => channel.id === set.scopeIdHex);
        if (!held) throw new Error("losing channel predecessor unavailable");
        let repair = pending.channelRepairs?.find((child) => child.next.id === held.id);
        if (!repair && held.key === bytesToHex(secret) && held.epoch === Number(set.newEpoch)) continue;
        if (
          repair && (!this.sameMaterialCoordinate(repair.winner, this.material) ||
            repair.winner.control_root !== this.material.control_root)
        ) throw new Error("channel repair winner changed");
        if (!repair) {
          if (!pending.preparation) throw new Error("losing channel membership unavailable");
          const request = JSON.parse(pending.preparation.request) as { channels: Array<[string, string[]]> };
          const membership = request.channels.find(([id]) => id === held.id)?.[1];
          if (!membership) throw new Error("losing channel membership unavailable");
          const recipients = [...new Set([this.pubkey, ...membership])]
            .filter((pk) => !pending.preparation!.excluded.includes(pk));
          const vac = await this.admin.vacFor(this.pubkey);
          assertCurrent();
          if (!vacVerifier(this.state$.value, PERM.MANAGE_CHANNELS)(this.pubkey, vac)) {
            throw new Error("losing channel recovery authority unavailable");
          }
          const plan = await buildChannelRekey(this.material, held, this.signer, {
            self: this.pubkey,
            recipients,
            vac,
            newKey: secret,
            assertCurrent,
          });
          assertCurrent();
          repair = {
            winner: structuredClone(this.material),
            predecessor: held,
            next: plan.next,
            rekeyKey: plan.rekeyKey,
            wraps: plan.rekeyWraps,
            evidence: [],
            stage: "prepared",
          };
          pending = {
            ...pending,
            blocked: undefined,
            protocolRelays,
            channelRepairs: [...pending.channelRepairs ?? [], repair],
          };
          await this.pendingRefounding.save(pending, assertCurrent);
        }
        const index = pending.channelRepairs!.indexOf(repair);
        const saveChild = async () => {
          pending = {
            ...pending,
            channelRepairs: pending.channelRepairs!.map((child, i) => i === index ? repair! : child),
          };
          await this.pendingRefounding.save(pending, assertCurrent);
        };
        const coverage = () =>
          evaluateCommonRelayCoverage(
            repair!.wraps.map((wrap) => ({
              artifact: { id: wrap.id, kind: "channel-rekey" as const },
              responses: (repair!.evidence.find((row) => row.artifact.id === wrap.id)?.acceptedRelays ?? [])
                .map((from) => ({ from, ok: true })),
            })),
            protocolRelays,
          );
        if (!coverage().accepted || needsCommon) {
          if (await this.signer.getPublicKey() !== this.pubkey) {
            throw new Error("refounding signer does not match actor");
          }
          assertCurrent();
          // The child carries the current own Grant; replay never refreshes the
          // citation or silently re-signs stale artifacts.
          for (const wrap of repair.wraps) {
            const parsed = parseRekeyResult(
              decodeReceivedWrap(wrap, { type: "rekey", convKey: repair.rekeyKey.convKey })!,
            );
            if (
              parsed.kind !== "parsed" ||
              !vacVerifier(this.state$.value, PERM.MANAGE_CHANNELS)(this.pubkey, parsed.value.vac)
            ) {
              throw new Error("channel repair citation no longer current");
            }
          }
          this.signers.register([repair.rekeyKey]);
          const results = await Promise.allSettled(
            repair.wraps.map((wrap) => this.pool.publish(this.transport(), wrap, this.streamPublishOptions(wrap))),
          );
          const nextEvidence = evaluateCommonRelayCoverage(
            repair.wraps.map((wrap, i) => {
              const result = results[i];
              return {
                artifact: { id: wrap.id, kind: "channel-rekey" as const },
                responses: result.status === "fulfilled" ? result.value : [],
                ...(result.status === "rejected" ? { cause: result.reason } : {}),
              };
            }),
            protocolRelays,
          ).evidence;
          repair = {
            ...repair,
            evidence: nextEvidence.map((row) => {
              const old = repair!.evidence.find((e) => e.artifact.id === row.artifact.id);
              const relays = row.relays.map((r) =>
                old?.acceptedRelays.includes(r.relay) ? { ...r, status: "accepted" as const } : r
              );
              return {
                ...row,
                relays,
                acceptedRelays: relays.filter((r) => r.status === "accepted").map((r) => r.relay),
                causes: [...old?.causes ?? [], ...row.causes],
              };
            }),
          };
          assertCurrent();
          await saveChild();
          if (!coverage().accepted) throw new RefoundingPublicationError(pending.rotationId, repair.evidence);
        }
        if (repair.stage === "prepared") {
          repair = { ...repair, stage: "confirmed" };
          await saveChild();
        }
      }
      const common = evaluateCommonRelayCoverage(
        (pending.channelRepairs ?? []).flatMap((child) =>
          child.wraps.map((wrap) => ({
            artifact: { id: wrap.id, kind: "channel-rekey" as const },
            responses: (child.evidence.find((row) => row.artifact.id === wrap.id)?.acceptedRelays ?? []).map((
              from,
            ) => ({ from, ok: true })),
          }))
        ),
        protocolRelays,
      );
      if (pending.channelRepairs?.length && !common.accepted) {
        throw new RefoundingPublicationError(
          pending.rotationId,
          pending.channelRepairs.flatMap((child) => child.evidence),
        );
      }
      // One common strict majority and one durable material barrier for the
      // complete repair set; disjoint channel majorities cannot partially advance.
      const channels = this.material.channels.map((channel) => {
        const child = pending.channelRepairs?.find((child) => child.next.id === channel.id);
        if (!child || canonicalJson(channel) === canonicalJson(child.next)) return channel;
        if (canonicalJson(channel) !== canonicalJson(child.predecessor)) {
          throw new Error("channel repair predecessor changed");
        }
        return child.next;
      });
      if (canonicalJson(channels) !== canonicalJson(this.material.channels)) {
        const next = deriveConcordKeys({ ...this.material, channels }, this.state$.value.channels, this.keys);
        this.rotationGuards.set(next, async () => {
          assertCurrent();
          if (await this.signer.getPublicKey() !== this.pubkey) return false;
          assertCurrent();
          return true;
        });
        if (!await this.commitMaterial(next, this.material)) throw new Error("channel repair commit superseded");
        refresh();
      }
      pending = {
        ...pending,
        channelRepairs: pending.channelRepairs?.map((child) => ({ ...child, stage: "adopted" })),
      };
      await this.pendingRefounding.save(pending, assertCurrent);
      assertCurrent();
      // Feed durable originals to existing private engines as the same local
      // echo used by rotateChannel. Their own authority/continuity folds run
      // against the winning chain and their epochs move after the parent save.
      for (const child of pending.channelRepairs ?? []) {
        for (const wrap of child.wraps) this.privateChannels.get(child.next.id)?.ingest(wrap);
      }
      await this.pendingRefounding.archive(pending, assertCurrent);
      assertCurrent();
      await this.pendingRefounding.remove();
      return {
        rotationId: pending.rotationId,
        epoch: this.material.root_epoch,
        warnings: [],
        evidence: pending.channelRepairs?.flatMap((child) => child.evidence) ?? [],
        commonRelays: protocolRelays.filter((relay) =>
          pending.channelRepairs?.every((child) => child.evidence.every((row) => row.acceptedRelays.includes(relay))) ??
            true
        ),
      };
    } catch (error) {
      if (!(error instanceof RefoundingPublicationError)) {
        await this.pendingRefounding.save({ ...pending, blocked: "stale-preparation" });
      }
      throw error;
    }
  }

  /** D-01/D-15/D-16: every publish this engine makes derives its `waitForAuth` from
   *  the event it is publishing, never from a hand-typed key — a concord wrap is
   *  finalized with the STREAM secret key (`buildWrap` in `operations/gift-wrap.ts`),
   *  so the pubkey a gating relay wants authenticated IS `event.pubkey`. Answered by this scope's own
   *  {@link StreamSigners} holder, never the user's. After CR-01, every plane publish
   *  registers its own key (see {@link publishToPlane}) and every rekey publish
   *  registers from its plan, so `this.signers.get` finding nothing here now means a
   *  genuine registration gap — this trace firing is no longer benign. This helper
   *  still never throws and never gates the publish itself: a relay that doesn't gate
   *  writes accepts the event regardless, and refusing to publish here would turn an
   *  auth question into an availability bug. */
  private streamPublishOptions(event: NostrEvent): PublishOptions {
    if (!this.signers.get(event.pubkey)) {
      this.publishLog(
        "publishing wrap=%s with no registered signer for author=%s",
        event.id.slice(0, 8),
        event.pubkey.slice(0, 8),
      );
    }
    return { waitForAuth: [event.pubkey], onAuthRequired: this.signers.onAuthRequired };
  }

  /** Seal + wrap a rumor onto a plane, echo it locally, and publish it. For a
   *  channel prefer {@link sendEvent}, which appends the CORD-03 binding; this is
   *  the raw plane path used for control/guestbook seeding (genesis, Join). */
  async publishToPlane(
    target: WrapTarget,
    rumor: { kind: number; content: string; tags: string[][]; created_at?: number },
    opts: {
      plaintext?: boolean;
      ephemeral?: boolean;
      ephemeralSk?: Uint8Array;
      requiredAckStage?: string;
      assertCurrent?: () => void;
    } = {},
  ): Promise<string> {
    const assertCurrent = () => {
      if (this.disposed) throw new Error("community disposed during publication");
      opts.assertCurrent?.();
    };
    assertCurrent();
    const { wrap, rumorId, key } = await wrapForTarget(this.keys, target, this.signer, rumor, {
      ...opts,
      assertCurrent,
    });
    // CORD-04 §§1–3,5: final signer I/O may invalidate a prepared staff delivery.
    assertCurrent();
    // The key that finalized this wrap is registered here, from `wrapForTarget`'s own
    // return value (CR-01), so the pubkey `streamPublishOptions` names in `waitForAuth`
    // is answerable by construction for every plane target, present and future. Never
    // re-resolved by looking the target back up against `this.keys` after the `await` —
    // `this.keys` can be reassigned by a concurrent `adoptRefounding()` during
    // `wrapForTarget`'s await, which would resolve a different key than the one the
    // wrap was finalized with (the same race WR-01 documents on the rekey path).
    // `register()` is already idempotent, so this adds no allocation for the common
    // already-registered case.
    this.signers.register([key]);
    if (opts.requiredAckStage) {
      let responses;
      try {
        responses = await this.pool.publish(this.transport(), wrap, this.streamPublishOptions(wrap));
      } catch (cause) {
        throw new InviteRevocationPublishError(opts.requiredAckStage, [], { cause });
      }
      requireInviteRevocationAck(opts.requiredAckStage, responses);
      if (!opts.ephemeral) this.onWrap(wrap);
    } else {
      // Optimistic local echo first, so ordinary UI operations update before relays ack.
      if (!opts.ephemeral) this.onWrap(wrap);
      this.pool.publish(this.transport(), wrap, this.streamPublishOptions(wrap)).catch((err) => {
        this.publishLog("publish failed plane=%s: %s", target.plane, (err as Error)?.message ?? err);
        console.warn("publish failed", err);
      });
    }
    return rumorId;
  }

  //
  // Snapshot and reactive forms of the same checks. The snapshot form is correct in
  // an event handler (an answer at click-time) and is what the engine's own guards
  // use; a render path wants the `$` form, because a role grant that changes the
  // answer has to re-render the button it gates.

  /** A member's resolved authority — snapshot. */
  standingOf(member: string): Standing {
    return this.admin.standingOf(member);
  }

  /** A member's resolved authority, re-emitted whenever roles or grants move. */
  standing$(member: string): Observable<Standing> {
    return this.state$.pipe(
      map(() => this.standingOf(member)),
      distinctUntilChanged(sameStanding),
    );
  }

  /** Whether the logged-in user holds `perm` (and outranks `targetPosition`) — snapshot. */
  canDo(perm: bigint, targetPosition = 0xffffffff): boolean {
    return this.admin.canDo(perm, targetPosition);
  }

  /** Reactive {@link canDo} — prefer this in a render path. */
  can$(perm: bigint, targetPosition = 0xffffffff): Observable<boolean> {
    return this.state$.pipe(
      map(() => this.canDo(perm, targetPosition)),
      distinctUntilChanged(),
    );
  }

  /**
   * Whether the logged-in user may act on `member` with `perm` — reactive. Holding
   * the bit isn't enough: CORD-04 requires strictly outranking the target, and you
   * can never act on yourself (you never outrank yourself). Both halves are folded
   * in here so a caller can't pair `canDo` with a stale `standingOf` position or
   * forget the self-check.
   */
  canModerate$(member: string, perm: bigint): Observable<boolean> {
    return this.state$.pipe(
      map((state) => member !== this.pubkey && refoundAuthority(state, perm, member)(this.pubkey)),
      distinctUntilChanged(),
    );
  }
}
