import { EventStore } from "applesauce-core";
import { EventStoreSymbol, type Rumor } from "applesauce-core/helpers/event";
import type { ConcordRumorStore } from "./storage.ts";

const pending = new WeakMap<ConcordRumorStore, Map<string, Promise<void>>>();

/** Retain authenticated channel inputs before current-ban/effect projection (CORD-03 §3).
 * The upstream kind-5 manager prunes history and intercepts requests, so bypass it
 * only for already decoded/binding-checked deletion rumors. Other kinds use add.
 */
export async function retainChannelInput(store: ConcordRumorStore, rumor: Rumor): Promise<void> {
  if (rumor.kind !== 5) {
    await store.add(rumor);
    return;
  }
  let writes = pending.get(store);
  if (!writes) pending.set(store, writes = new Map());
  const existing = writes.get(rumor.id);
  if (existing) {
    await existing;
    await retainDeletion(store, rumor);
    return;
  }
  const write = retainDeletion(store, rumor);
  writes.set(rumor.id, write);
  try {
    await write;
  } finally {
    writes.delete(rumor.id);
  }
}

async function retainDeletion(store: ConcordRumorStore, rumor: Rumor): Promise<void> {
  if (store.verifyEvent && !store.verifyEvent(rumor)) return;
  const cached = await store.getEvent(rumor.id);
  if (cached) {
    if (EventStore.copySymbolsToDuplicateEvent(rumor, cached)) await store.update(cached);
    return;
  }
  // Publish canonical memory identity only after the durable write succeeds.
  // Otherwise a failed write leaves a cache hit that suppresses every retry.
  const persisted = await store.database.add(rumor);
  const canonical = store.memory.add(rumor);
  const inserted = store.memory.add(persisted);
  EventStore.copySymbolsToDuplicateEvent(persisted, inserted);
  if (inserted === canonical) {
    Object.defineProperty(inserted, EventStoreSymbol, { value: store, configurable: true, writable: true });
    store.insert$.next(inserted);
  } else if (EventStore.copySymbolsToDuplicateEvent(rumor, inserted)) {
    await store.update(inserted);
  }
}
