// Admin actions use the community's folded state. Control editions are built
// here; actions requiring keys or cross-plane I/O delegate to the community.

import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { generateSecretKey } from "applesauce-core/helpers/keys";

import { EditionFactory } from "../factories/control.ts";
import { assertByteCap, DESCRIPTION_MAX_BYTES, NAME_MAX_BYTES } from "../helpers/caps.ts";
import { banlistLocator, grantLocator, inviteLinksLocator } from "../helpers/crypto.ts";
import {
  canActOn,
  isStaffPermissionMask,
  parsePermissions,
  resolveStanding,
  type Standing,
  vacVerifier,
} from "../helpers/permissions.ts";
import { stateTargetSupportReady } from "../helpers/authority-support.ts";
import {
  type BlobPointer,
  type CommunityMetadata,
  type CommunityState,
  type Grant,
  type JoinMaterial,
  PERM,
  type Role,
  type RoleScope,
  type RumorTemplate,
  type VerifiedControlHead,
  VSK,
} from "../types.ts";
// Type-only: erased at runtime, so this doesn't create an import cycle with the
// community module that constructs us.
import type { ConcordCommunity } from "./community.ts";
import type { RefoundingResult } from "./refounding.ts";
import type { ConcordInviteLink, CreateInviteOptions } from "./invite-manager.ts";
import type { ConcordRumorStore, ConcordUploader } from "./storage.ts";

/** Options for {@link ConcordCommunityAdmin.createChannel}. */
export interface CreateChannelOptions {
  /** Create a private (key-gated, invite-only) channel. Defaults to `false` — a public channel. */
  private?: boolean;
}

/** An entity's current head edition — what the next version must chain to. */
export interface EditionHead {
  /** The head's `ev` version. The next edition must be exactly one higher. */
  version: number;
  /** The head's `edition_hash`, cited as the next edition's `ep` tag. */
  hash: string;
  /** The head's JSON content, so an edit can patch the current value rather than replace it blind. */
  content: string;
}

/** Options for a {@link ConcordCommunityAdmin}, wired by {@link ConcordCommunity}. */
export interface ConcordCommunityAdminOptions {
  /** The owning community. Backs the cross-plane composites, whose implementations
   *  need its key state, private-channel sub-engines, and relay handles. */
  community: ConcordCommunity;
  /** The retained Control Plane rumor store; selected heads come from the folded state. */
  store: ConcordRumorStore;
  /** The community's folded state, read as a snapshot at write time: roles/grants
   *  gate authority, and each edit patches the entity's current value. Never
   *  subscribed — the reactive surface lives on the community. */
  state: () => CommunityState;
  /** The logged-in user's hex pubkey. */
  pubkey: string;
  /** Media uploader (encrypt + upload). Required to set community images. */
  uploader?: ConcordUploader;
  /** Seal + wrap + publish a rumor onto the Control Plane (a plaintext seal, so a
   *  later Refounding can re-wrap the signed edition into the new epoch). When supplied,
   *  assertCurrent must run after each signer await and before registration/echo/publication. */
  publish: (rumor: RumorTemplate, assertCurrent?: () => void) => Promise<string>;
  /** Publish a control rumor only after at least one relay acknowledges it. */
  publishRequired?: (rumor: RumorTemplate, assertCurrent?: () => void) => Promise<string>;
  /** Prepare recipient-bound staff root ciphertext with the Grant author's signer (CORD-04 §3).
   * Required for staff-result Grants in explicit split material; legacy Grants omit delivery. */
  prepareControlWrap?: (recipient: string) => Promise<string | undefined>;
  /** Mint + persist a private channel's key, before its edition is published — a
   *  key that never reaches `material` is lost on reload. */
  mintChannelKey: (channelId: string, name: string) => void;
}

/**
 * The community-management API, reached as `community.admin`. Grouped by intent rather
 * than by protocol plane, so a caller looking to remove someone finds `kick` and `ban`
 * together without learning that one writes the guestbook and the other the control
 * plane. Owns no fold and no subscription: reads come from the community's folded
 * snapshot through `state`.
 */
export class ConcordCommunityAdmin {
  /** The acting user's hex pubkey — the authority every write here is checked against. */
  readonly pubkey: string;
  /** Invite-link management, also reachable as `community.admin.invites`. */
  readonly invites: ConcordCommunityAdminInvites;

  private readonly opts: ConcordCommunityAdminOptions;

  /** Wired by {@link ConcordCommunity}; not constructed directly by apps. */
  constructor(options: ConcordCommunityAdminOptions) {
    this.opts = options;
    this.pubkey = options.pubkey;
    this.invites = new ConcordCommunityAdminInvites(this);
  }

  /** The community's current material, read fresh each time — a Refounding replaces it,
   *  and a cached copy would address the previous epoch. */
  private get material(): JoinMaterial {
    return this.opts.state().material;
  }

  /** The community id as bytes, for the locator hashes entity coordinates derive from. */
  private get communityIdBytes(): Uint8Array {
    return hexToBytes(this.material.community_id);
  }

  /** Validate the selected head against same-community, unsuspended verification. */
  private selectedHead(eid: string): VerifiedControlHead | undefined {
    const state = this.opts.state();
    const verification = state.controlVerification;
    if (verification?.suspended.has(eid)) throw new Error(`entity ${eid} is suspended`);
    const head = verification?.heads.get(eid);
    const selected = state.heads?.get(eid);
    if (!head) {
      if (selected) throw new Error(`entity ${eid} has no verified head`);
      return undefined;
    }
    if (
      verification?.communityId !== state.material.community_id || head.eid !== eid ||
      selected?.rumor.id !== head.edition.rumor.id ||
      Number(selected.rumor.tags.find((t) => t[0] === "vsk")?.[1]) !== head.vsk
    ) {
      throw new Error(`entity ${eid} has inconsistent verified head`);
    }
    return head;
  }

  /** The selected verified head for `eid`; suspended entities cannot be edited. */
  async latestEdition(eid: string): Promise<EditionHead | undefined> {
    const head = this.selectedHead(eid);
    return head ? { version: head.version, hash: head.hash, content: head.edition.rumor.content } : undefined;
  }

  /** The `vac` citation of `actor`'s own Grant edition (CORD-04) — omitted for the
   *  owner, whose authority is intrinsic. Other actors require exact verified
   *  Grant history and current unbanned, unsuspended authority (CORD-04 §§1, 5). */
  async vacFor(actor: string): Promise<[string, string, string] | undefined> {
    if (actor === this.material.owner) return undefined;
    const eid = grantLocator(this.communityIdBytes, actor);
    const head = this.selectedHead(eid);
    const pin: [string, string, string] | undefined = head ? [eid, String(head.version), head.hash] : undefined;
    if (
      head?.vsk !== VSK.GRANT || !vacVerifier(this.opts.state(), 0n)(actor, pin) ||
      this.standingOf(actor).permissions === 0n
    ) {
      throw new Error(`actor ${actor} has no current verified authority`);
    }
    return pin;
  }

  // CORD-04 §§2–5: write-path checks consume the shared current citation
  // predicate and rank math, never reconstruct authority from raw rumors.
  /** Check current permissions, strict target rank and the selected entity before writing. */
  private assertWrite(vsk: number, eid: string, content: string): void {
    const head = this.selectedHead(eid);
    if (head && head.vsk !== vsk) throw new Error("entity type does not match verified head");
    const required = vsk === VSK.METADATA
      ? PERM.MANAGE_METADATA
      : vsk === VSK.CHANNEL
      ? PERM.MANAGE_CHANNELS
      : vsk === VSK.ROLE || vsk === VSK.GRANT
      ? PERM.MANAGE_ROLES
      : vsk === VSK.BANLIST
      ? PERM.BAN
      : vsk === VSK.INVITE_REGISTRY
      ? PERM.CREATE_INVITE
      : undefined;
    if (required === undefined) {
      if (this.pubkey !== this.material.owner) throw new Error("owner authority required");
    } else if (!this.canDo(required)) throw new Error("missing current permission or verified authority");
    const actor = this.standingOf(this.pubkey);
    if (vsk === VSK.ROLE) {
      const role = JSON.parse(content) as Role;
      const current = this.opts.state().roles.find((r) => r.role_id === eid);
      if (
        role.position === 0 || (!actor.isOwner &&
          (role.position <= actor.position || (current && current.position <= actor.position)))
      ) {
        throw new Error("cannot manage a Role you do not outrank");
      }
    } else if (vsk === VSK.GRANT) {
      const grant = JSON.parse(content) as { member: string; role_ids: string[] };
      if (eid !== grantLocator(this.communityIdBytes, grant.member)) throw new Error("Grant coordinate mismatch");
      if (
        grant.member === this.material.owner || (grant.member !== this.pubkey &&
          (!actor.isOwner && !stateTargetSupportReady(this.opts.state(), grant.member) ||
            !canActOn(actor, this.standingOf(grant.member), PERM.MANAGE_ROLES)))
      ) {
        throw new Error("cannot grant to a member you do not outrank");
      }
      for (const id of grant.role_ids) {
        const role = this.opts.state().roles.find((r) => r.role_id === id);
        if (
          !role || role.deleted || this.selectedHead(id)?.vsk !== VSK.ROLE ||
          (!actor.isOwner && role.position <= actor.position)
        ) throw new Error("cannot grant an unsupported or senior Role");
      }
    } else if (vsk === VSK.BANLIST) {
      const members = JSON.parse(content) as string[];
      for (const member of members) {
        if (this.opts.state().banlist.has(member)) continue;
        if (
          member === this.material.owner || (!actor.isOwner && !stateTargetSupportReady(this.opts.state(), member)) ||
          !canActOn(actor, this.standingOf(member), PERM.BAN)
        ) {
          throw new Error("cannot ban a member you do not outrank");
        }
      }
    }
  }

  /** Publish the next version of an entity, chained to its current head. Versions
   *  must stay contiguous and cite the head's hash — an edition that doesn't link
   *  is rejected or suspended by the receiving fold (CORD-04 §1). */
  async publishEdition(vsk: number, eid: string, content: string, required = false): Promise<void> {
    await this.publishGuardedEdition(vsk, eid, content, required);
  }

  /** Carry an optional issuance snapshot check across every asynchronous draft boundary. */
  private async publishGuardedEdition(
    vsk: number,
    eid: string,
    content: string,
    required = false,
    check?: () => void,
  ): Promise<void> {
    check?.();
    const latest = await this.latestEdition(eid);
    check?.();
    const version = latest ? latest.version + 1 : 1;
    const vac = await this.vacFor(this.pubkey);
    check?.();
    this.assertWrite(vsk, eid, content);
    const rumor = await EditionFactory.create({ vsk, eid, version, prevHash: latest?.hash, content, vac });
    check?.();
    this.assertWrite(vsk, eid, content);
    if (required) {
      if (!this.opts.publishRequired) {
        throw new Error("required publication is not configured: publishRequired is needed for this stage");
      }
      await this.opts.publishRequired(rumor, check);
    } else {
      await this.opts.publish(rumor, check);
    }
  }

  /** Patch the community metadata, merging over the current value so unrelated fields
   *  survive (CORD-02 §6's round-trip rule). Byte caps are asserted on the merged result. */
  async editMetadata(patch: Partial<CommunityMetadata>): Promise<void> {
    const material = this.material;
    const current = this.opts.state().metadata ?? { name: material.name, relays: material.relays };
    const next: CommunityMetadata = { ...current, ...patch };
    // D-03: asserted against the MERGED `next`, not `patch` — `patch` alone
    // would leave a bypass, since setCommunityImage/removeCommunityImage
    // below call this with a patch that only touches an image field, and the
    // merge can re-publish a pre-existing over-cap `name` that predates the
    // cap even though the patch itself never mentioned it.
    assertByteCap(next.name, NAME_MAX_BYTES, "community name");
    if (next.description !== undefined) assertByteCap(next.description, DESCRIPTION_MAX_BYTES, "community description");
    await this.publishEdition(VSK.METADATA, material.community_id, JSON.stringify(next));
  }

  /** Encrypt an image via the uploader and publish it as the icon or banner. */
  async setCommunityImage(which: "icon" | "banner", file: Blob): Promise<void> {
    if (!this.opts.uploader) throw new Error("no uploader configured: cannot set community image");
    const att = await this.opts.uploader.upload(file, this.material.community_id);
    if (!att.encryption || !att.originalSha256 || !att.url) {
      throw new Error("uploader did not return an encrypted attachment");
    }
    const pointer: BlobPointer = {
      url: att.url,
      key: att.encryption.key,
      nonce: att.encryption.nonce,
      hash: att.originalSha256,
    };
    await this.editMetadata({ [which]: pointer });
  }

  /** Clear the icon or banner. The blob itself is not deleted from its host — only the
   *  pointer is dropped from the metadata. */
  async removeCommunityImage(which: "icon" | "banner"): Promise<void> {
    await this.editMetadata({ [which]: undefined });
  }

  /** Create a channel and return its new id. A private channel also mints and persists a
   *  key before its edition is published, so the name cap is asserted first — a rejected
   *  name must not leave an orphaned key behind. */
  async createChannel(name: string, options: CreateChannelOptions = {}): Promise<string> {
    // WIRE-06/D-02: asserted first — before `mintChannelKey`'s side effect,
    // so a rejected channel name never mints a key that is then orphaned.
    assertByteCap(name, NAME_MAX_BYTES, "channel name");
    const isPrivate = options.private ?? false;
    const channelId = bytesToHex(generateSecretKey());
    if (isPrivate) this.opts.mintChannelKey(channelId, name);
    const content: Record<string, unknown> = { name, private: isPrivate };
    await this.publishEdition(VSK.CHANNEL, channelId, JSON.stringify(content));
    return channelId;
  }

  /**
   * Publish a terminal deletion; the channel id cannot be reused (CORD-03 §2).
   * Preserve unknown metadata fields (CORD-02 §6), excluding the coordinate
   * supplied separately to `publishEdition`. The fold already strips key material.
   */
  async deleteChannel(channelId: string): Promise<void> {
    const ch = this.opts.state().channels.find((c) => c.channel_id === channelId);
    if (!ch) return;
    const { channel_id: _channel_id, ...rest } = ch;
    await this.publishEdition(VSK.CHANNEL, channelId, JSON.stringify({ ...rest, deleted: true }));
  }

  /**
   * Mint a Role (CORD-04 §2). A server-scoped role (the default) grants rank
   * community-wide; a channel-scoped role (`{kind:"channel", channel_id}`) is the
   * spec's private-channel membership marker — its grant-holders are the intended
   * readership of that channel, kept in sync with key possession by the caller
   * (deliver on grant via `grantChannelAccess`, rekey on removal via
   * `rotateChannel`). A role mints no key, so this only records entitlement.
   */
  async createRole(
    name: string,
    position: number,
    permissions: bigint,
    scope: RoleScope = { kind: "server" },
  ): Promise<string> {
    const roleId = bytesToHex(generateSecretKey());
    const role: Role = {
      role_id: roleId,
      name,
      position,
      permissions: permissions.toString(),
      scope,
      color: 0,
    };
    await this.publishEdition(VSK.ROLE, roleId, JSON.stringify(role));
    return roleId;
  }

  /** Patch a role in place, keeping its id. Throws if the role is unknown, since publishing
   *  a version-1 edition for it would fork the chain rather than edit it. */
  async editRole(roleId: string, patch: Partial<Omit<Role, "role_id">>): Promise<void> {
    const current = this.opts.state().roles.find((r) => r.role_id === roleId);
    if (!current) throw new Error("role not found");
    const role: Role = { ...current, ...patch, role_id: roleId };
    await this.publishEdition(VSK.ROLE, roleId, JSON.stringify(role));
  }

  /**
   * Retire a Role (CORD-04). The role stays in {@link CommunityState.roles} flagged
   * `deleted` — so it remains visible and compactable — but confers no permissions
   * or rank, stripping its authority from every grant-holder. Reverse with
   * `editRole(roleId, { deleted: false })`. Existing grants are left untouched.
   */
  async deleteRole(roleId: string): Promise<void> {
    const current = this.opts.state().roles.find((r) => r.role_id === roleId);
    if (!current) return;
    await this.publishEdition(VSK.ROLE, roleId, JSON.stringify({ ...current, deleted: true }));
  }

  /** Replace `member`'s role set wholesale (CORD-04 §3). Split staff-result Grants deliver the
   * current held control root pairwise on every issuance, including recovery reissues.
   * Passing `[]` strips every role, which is how {@link kick} and {@link ban} revoke authority. */
  async grantRoles(member: string, roleIds: string[]): Promise<void> {
    const eid = grantLocator(this.communityIdBytes, member);
    const grant: Grant = { member, role_ids: [...roleIds] };
    const content = JSON.stringify(grant);
    this.assertWrite(VSK.GRANT, eid, content);
    const state = this.opts.state();
    const roles = new Map(state.roles.map((role) => [role.role_id, role]));
    const permissions = grant.role_ids.reduce((mask, id) => mask | parsePermissions(roles.get(id)!.permissions), 0n);
    const split = "control_pk" in state.material || "control_root" in state.material;
    if (!split || !isStaffPermissionMask(permissions)) {
      await this.publishEdition(VSK.GRANT, eid, content);
      return;
    }
    if (!this.opts.prepareControlWrap) throw new Error("split staff Grant control root delivery is not configured");
    // CORD-04 §§1–3,5; CORD-02 §5: neither possession nor an old citation can
    // authorize delivery. Pin selected support and material across signer I/O.
    const fields = ["community_id", "community_root", "root_epoch", "control_pk", "control_root"] as const;
    const material = fields.map((field) => state.material[field]);
    const actor = this.standingOf(this.pubkey);
    const target = this.standingOf(member);
    const coordinates = new Set([
      eid,
      ...grant.role_ids,
      ...actor.roleIds,
      ...target.roleIds,
      ...(actor.isOwner ? [] : [grantLocator(this.communityIdBytes, this.pubkey)]),
    ]);
    const headIdentity = (id: string) => {
      const head = this.selectedHead(id);
      return head ? `${head.vsk}:${head.version}:${head.hash}:${head.edition.rumor.id}` : undefined;
    };
    const heads = new Map([...coordinates].map((id) => [id, headIdentity(id)]));
    const check = () => {
      this.assertWrite(VSK.GRANT, eid, content);
      if (
        fields.some((field, index) => this.material[field] !== material[index]) ||
        [...heads].some(([id, identity]) => headIdentity(id) !== identity)
      ) throw new Error("staff Grant delivery state changed during preparation");
    };
    const vac = await this.vacFor(this.pubkey);
    check();
    if (!vacVerifier(this.opts.state(), PERM.MANAGE_ROLES)(this.pubkey, vac)) {
      throw new Error("missing current verified Grant delivery authority");
    }
    const controlWrap = await this.opts.prepareControlWrap(member);
    check();
    if (!controlWrap) throw new Error("split staff Grant control root delivery is unavailable");
    grant.control_wrap = controlWrap;
    await this.publishGuardedEdition(VSK.GRANT, eid, JSON.stringify(grant), false, check);
  }

  /** Add a member to the banlist and strip their roles. Holding `BAN` is not sufficient —
   *  the caller must also strictly outrank the target (CORD-04), and stripping roles is a
   *  Grant write that needs `MANAGE_ROLES`; both are checked before anything is published.
   *  Banning alone does not sever read access: that needs a Refounding (CORD-06). */
  async ban(member: string): Promise<void> {
    // CORD-04/AUTH-05: banning is acting on member — the caller must strictly
    // outrank them, not merely hold BAN. Mirrors community.ts's rotateChannel
    // exclude-loop outrank throw, using this class's own canDo/standingOf.
    if (
      (this.pubkey !== this.material.owner && !stateTargetSupportReady(this.opts.state(), member)) ||
      !this.canDo(PERM.BAN, this.standingOf(member).position)
    ) {
      throw new Error(`cannot ban ${member} — you do not outrank them or lack BAN`);
    }
    // CORD-04 §3: the role strip below is a Grant write. Check it up front so a
    // caller without MANAGE_ROLES cannot leave a ban published with roles intact.
    this.assertWrite(
      VSK.GRANT,
      grantLocator(this.communityIdBytes, member),
      JSON.stringify({ member, role_ids: [] } satisfies Grant),
    );
    const current = new Set(this.opts.state().banlist);
    current.add(member);
    await this.publishEdition(VSK.BANLIST, banlistLocator(this.communityIdBytes), JSON.stringify([...current]));
    await this.grantRoles(member, []);
    // NOTE: full enforcement also requires a Refounding (rekey) — CORD-06.
  }

  /** Remove a member from the banlist. Roles stripped by {@link ban} are not restored. */
  async unban(member: string): Promise<void> {
    const current = new Set(this.opts.state().banlist);
    current.delete(member);
    await this.publishEdition(VSK.BANLIST, banlistLocator(this.communityIdBytes), JSON.stringify([...current]));
  }

  /** Register a link_signer coordinate into OUR registry (CORD-05 §5), so the link
   *  counts toward the community being Public. The bundle itself isn't a plane
   *  event, so publishing it stays with the community. */
  async registerInviteLink(linkPubkey: string): Promise<void> {
    const eid = inviteLinksLocator(this.communityIdBytes, this.pubkey);
    const existing = await this.latestEdition(eid);
    let links: string[] = [];
    try {
      if (existing) links = JSON.parse(existing.content) as string[];
    } catch {
      /* ignore */
    }
    if (!links.includes(linkPubkey)) links.push(linkPubkey);
    await this.publishEdition(VSK.INVITE_REGISTRY, eid, JSON.stringify(links));
  }

  /** Remove a link_signer coordinate from OUR registry (CORD-05 §5), usually
   *  after reposting the bundle coordinate as a revocation tombstone. */
  async unregisterInviteLink(linkPubkey: string): Promise<void> {
    const eid = inviteLinksLocator(this.communityIdBytes, this.pubkey);
    const existing = await this.latestEdition(eid);
    let links: string[] = [];
    try {
      if (existing) links = JSON.parse(existing.content) as string[];
    } catch {
      /* ignore */
    }
    const next = links.filter((link) => link !== linkPubkey);
    if (next.length === links.length) return;
    await this.publishEdition(VSK.INVITE_REGISTRY, eid, JSON.stringify(next), true);
  }

  //
  // Implemented on the community (they need its keys, sub-engines, and relays) and
  // surfaced here so `admin` is the whole management API rather than the subset that
  // happens to be one plane wide.

  /** Strip a member's roles and publish the Kick. */
  kick(member: string): Promise<void> {
    return this.opts.community.kick(member);
  }

  /** Mint a public invite link and register it (CORD-05 §5). */
  createInvite(options: CreateInviteOptions): Promise<ConcordInviteLink> {
    return this.opts.community.createInvite(options);
  }

  /** Retire a public invite link (bundle tombstone + registry removal). */
  revokeInvite(invite: ConcordInviteLink): Promise<ConcordInviteLink> {
    return this.opts.community.revokeInvite(invite);
  }

  /** Hand a member the current key for one or more private channels we hold (CORD-05 §6). */
  grantChannelAccess(channels: string | string[], member: string): Promise<void> {
    return this.opts.community.grantChannelAccess(channels, member);
  }

  /** Rotate a private channel's key to sever the excluded members (CORD-06). */
  rotateChannel(channelId: string, opts: { keep: string[]; exclude?: string[] }): Promise<void> {
    return this.opts.community.rotateChannel(channelId, opts);
  }

  /** Rotate the community root — the enforcement step behind a ban (CORD-06). */
  refound(opts: {
    keep: string[];
    exclude?: string[];
    channelRekeys?: Array<{ channelId: string; keep: string[] }>;
  }): Promise<RefoundingResult> {
    return this.opts.community.refound(opts);
  }

  /** Shut the community down. Owner only, and irreversible. */
  dissolve(): Promise<void> {
    return this.opts.community.dissolve();
  }

  /** Resolve a member's effective rank and permissions from the owner-rooted role and
   *  grant chain — the authority every write in this class is gated on. */
  standingOf(member: string): Standing {
    const state = this.opts.state();
    if (member === state.material.owner) return resolveStanding(member, state.material.owner, new Map(), new Map());
    const verification = state.controlVerification;
    const eid = grantLocator(this.communityIdBytes, member);
    const supported = verification?.communityId === state.material.community_id && !state.banlist.has(member) &&
      !verification.suspended.has(eid) && verification.heads.get(eid)?.vsk === VSK.GRANT;
    const roles = new Map<string, Role>(
      state.roles.filter((r) =>
        verification?.heads.get(r.role_id)?.vsk === VSK.ROLE && !verification.suspended.has(r.role_id)
      ).map((r) => [r.role_id, r]),
    );
    return resolveStanding(member, state.material.owner, roles, supported ? state.grants : new Map());
  }

  /** Whether the logged-in user holds `perm` (and outranks `targetPosition`). */
  canDo(perm: bigint, targetPosition = 0xffffffff): boolean {
    return this.hasPerm(this.pubkey, perm, targetPosition);
  }

  /** Whether `member` holds `perm` — the roster authority check, e.g. for accepting
   *  a channel Rekey from a rotator. */
  hasPerm(member: string, perm: bigint, targetPosition = 0xffffffff): boolean {
    const standing = this.standingOf(member);
    if (!standing.isOwner) {
      const state = this.opts.state();
      const eid = grantLocator(this.communityIdBytes, member);
      const head = state.controlVerification?.heads.get(eid);
      if (!head || !vacVerifier(state, perm)(member, [eid, String(head.version), head.hash])) return false;
    }
    return canActOn(standing, { permissions: 0n, position: targetPosition, isOwner: false, roleIds: [] }, perm);
  }
}

/** Community-scoped invite-link management, exposed at `community.admin.invites`. */
export class ConcordCommunityAdminInvites {
  /** Constructed by {@link ConcordCommunityAdmin}; it is the namespace object behind
   *  `community.admin.invites`. */
  constructor(private readonly admin: ConcordCommunityAdmin) {}

  /** Mint and register a public invite link (CORD-05 §5). */
  create(options: CreateInviteOptions): Promise<ConcordInviteLink> {
    return this.admin.createInvite(options);
  }

  /** Retire a public invite link: bundle tombstone plus registry removal (CORD-05 §5). */
  revoke(invite: ConcordInviteLink): Promise<ConcordInviteLink> {
    return this.admin.revokeInvite(invite);
  }
}
