import { type Observable, Subject } from "rxjs";
import type { RekeyCandidateDiagnostic } from "../helpers/keys.ts";
import { isStrictlyLowerKey } from "../helpers/rekey.ts";

/** Why a candidate was not adopted: either a {@link RekeyCandidateDiagnostic} reason
 *  passed straight through from the fold, or this coordinator's own
 *  `"reconciliation-exhausted"`, raised once bounded refetching gives up on a
 *  candidate that stayed reconcilable but never became complete, or
 *  `"transition-failed"` when local durable adoption fails and remains retryable. */
export type RotationDiagnosticReason =
  | RekeyCandidateDiagnostic["reason"]
  | "reconciliation-exhausted"
  | "transition-failed";

/** One non-adoption decision, emitted on {@link RotationCoordinator.diagnostics$}.
 *  Rotation reads are total, so an unusable candidate is reported here instead of
 *  throwing — one bad candidate must never abort the fold. */
export interface RotationDiagnostic {
  /** The scope whose rotation this concerns: the community for the root plane, the channel id otherwise. */
  scopeId: string;
  /** Event id of the candidate being explained. */
  candidateId: string;
  /** `"parked"` stays retryable once more material arrives; `"rejected"` is terminal for this candidate. */
  status: "parked" | "rejected";
  /** Which of the reasons above applies. */
  reason: RotationDiagnosticReason;
  /** Bounded refetch attempts made so far, present only while reconciliation is running. */
  attempt?: number;
  /** The originating failure, retained programmatically for the app to inspect rather than formatted here. */
  cause?: unknown;
}

export type RotationOutcome<T> =
  | { kind: "adopt"; next: T; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | { kind: "removed"; epoch: number; diagnostics?: RekeyCandidateDiagnostic[] }
  | { kind: "none"; diagnostics?: RekeyCandidateDiagnostic[] };

export interface RotationCoordinatorOptions<T> {
  scopeId: string;
  read: () => Promise<RotationOutcome<T>>;
  keyOf: (next: T) => Uint8Array;
  /** False cancels an obsolete completion without settling its candidate. */
  adopt: (next: T) => void | boolean | Promise<void | boolean>;
  remove: () => void | Promise<void>;
  fetch?: () => void | Promise<void>;
  onFatal: (cause: unknown) => void;
  diagnostics?: Subject<RotationDiagnostic>;
  maxAttempts?: number;
  lifetimeMs?: number;
  now?: () => number;
}

const RECONCILABLE = new Set<RekeyCandidateDiagnostic["reason"]>([
  "incomplete",
  "inconsistent",
  "continuity-gap",
  "citation-missing",
  "citation-mismatch",
  "decrypt-failed",
]);

/** Shared live/historical down-only convergence decision. */
export function shouldAdoptRotation(existing: Uint8Array | undefined, candidate: Uint8Array): boolean {
  return existing === undefined || isStrictlyLowerKey(existing, candidate);
}

/** Serializes rotation folds while keeping bounded candidate fetches independent. */
export class RotationCoordinator<T> {
  private serial = Promise.resolve();
  private readonly latches = new Map<number, Uint8Array>();
  private readonly fetches = new Map<string, { attempts: number; started: number; running: boolean }>();
  private readonly exhausted = new Set<string>();
  private readonly reportedConflicts = new Set<string>();
  private queued = false;
  private disposed = false;
  readonly diagnostics$: Observable<RotationDiagnostic>;
  private readonly diagnostics: Subject<RotationDiagnostic>;

  constructor(private readonly opts: RotationCoordinatorOptions<T>) {
    this.diagnostics = opts.diagnostics ?? new Subject<RotationDiagnostic>();
    this.diagnostics$ = this.diagnostics.asObservable();
  }

  notify(): void {
    if (this.disposed || this.queued) return;
    this.queued = true;
    this.serial = this.serial.then(() => {
      this.queued = false;
      return this.evaluate();
    }).catch((cause) => this.opts.onFatal(cause));
  }

  /** Resolves after all evaluations currently queued on the serialized fold lane. */
  async idle(): Promise<void> {
    let pending: Promise<void>;
    do {
      pending = this.serial;
      await pending;
    } while (pending !== this.serial);
  }

  latch(epoch: number, key: Uint8Array): void {
    if (shouldAdoptRotation(this.latches.get(epoch), key)) this.latches.set(epoch, key);
  }

  dispose(): void {
    this.disposed = true;
    if (!this.opts.diagnostics) this.diagnostics.complete();
  }

  private async evaluate(): Promise<void> {
    if (this.disposed) return;
    const outcome = await this.opts.read();
    if (this.disposed) return;
    for (const diagnostic of outcome.diagnostics ?? []) {
      // Accepted D-13: parked pair conflicts keep evidence and held reads without
      // flooding diagnostics on every store/authority notification.
      if (diagnostic.reason === "paired-control-conflict") {
        if (this.reportedConflicts.has(diagnostic.candidateId)) continue;
        if (this.reportedConflicts.size >= 128) continue;
        this.reportedConflicts.add(diagnostic.candidateId);
      }
      this.diagnostics.next({ scopeId: this.opts.scopeId, ...diagnostic });
      if (diagnostic.status === "parked" && RECONCILABLE.has(diagnostic.reason)) this.reconcile(diagnostic);
    }
    if (this.disposed || outcome.kind === "none") return;
    if (outcome.kind === "removed") return void (await this.opts.remove());
    const candidate = this.opts.keyOf(outcome.next);
    const latched = this.latches.get(outcome.epoch);
    if (!shouldAdoptRotation(latched, candidate)) return;
    const committed = await this.opts.adopt(outcome.next);
    if (this.disposed || committed === false) return;
    // A failed transition did not settle the candidate. Keep the prior latch so
    // the exact same lower sibling remains retryable after local recovery.
    this.latch(outcome.epoch, candidate);
  }

  private reconcile(diagnostic: RekeyCandidateDiagnostic): void {
    if (!this.opts.fetch) return;
    const pin = diagnostic.reason === "citation-missing" || diagnostic.reason === "citation-mismatch"
      ? diagnostic.reason
      : "set";
    const id = `${diagnostic.candidateId}:${pin}`;
    if (this.exhausted.has(id)) return;
    const now = (this.opts.now ?? Date.now)();
    const state = this.fetches.get(id) ?? { attempts: 0, started: now, running: false };
    if (state.running) return;
    const maxAttempts = this.opts.maxAttempts ?? 3;
    const lifetimeMs = this.opts.lifetimeMs ?? 8_000;
    if (state.attempts >= maxAttempts || now - state.started >= lifetimeMs) {
      this.diagnostics.next({
        scopeId: this.opts.scopeId,
        candidateId: diagnostic.candidateId,
        status: "rejected",
        reason: "reconciliation-exhausted",
        attempt: state.attempts,
      });
      this.fetches.delete(id);
      this.exhausted.add(id);
      return;
    }
    state.running = true;
    state.attempts++;
    this.fetches.set(id, state);
    void Promise.resolve(this.opts.fetch())
      .then(() => {
        if (!this.disposed) this.notify();
      })
      .catch((cause) => {
        if (this.disposed) return;
        this.diagnostics.next({
          scopeId: this.opts.scopeId,
          candidateId: diagnostic.candidateId,
          status: "parked",
          reason: diagnostic.reason,
          attempt: state.attempts,
          cause,
        });
      })
      .finally(() => {
        state.running = false;
      });
  }
}
