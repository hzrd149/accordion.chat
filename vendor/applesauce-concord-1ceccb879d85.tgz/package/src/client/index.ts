/**
 * The Concord client engine: a single-community reactive wrapper
 * (`ConcordCommunity`), a thin multi-community manager (`ConcordClient`), and the
 * epoch-atomic sync primitives that connect them to relays.
 *
 * This is the only entrypoint that reaches for `applesauce-relay`,
 * `applesauce-signers` and `applesauce-loaders` at runtime, so the pure layers
 * stay usable without the network stack. Sync is a strict sequential epoch walk
 * with a per-epoch plane barrier; live subscriptions open only at the tip.
 *
 * @example
 * ```ts
 * import { ConcordClient } from "@applesauce/concord/client";
 * ```
 *
 * @module
 */

// Named (not `export *`) re-export: `createUserAuthHandler`, `lookupRelayStatus`,
// and `connectedRelays$` stay internal to the package; only `StreamSigners` and
// its options type are public.
export { StreamSigners, type StreamSignersOptions } from "./auth.ts";
/** Pluggable persistence, decoded-rumor caching and media upload — the seams the engine injects. */
export * as Storage from "./storage.ts";
// Export types referenced by public options explicitly for `deno doc`;
// namespace exports alone do not make them public. No runtime exports are added.
export type {
  ConcordRumorStore,
  ConcordStorage,
  ConcordStoreFactory,
  ConcordUploader,
  ConcordUploadOptions,
  ConcordUploadProgress,
} from "./storage.ts";
export * from "./sync.ts";
/** Verified receive boundaries for manual consumers before retaining wire events or decoded rumors. */
export { decodeReceivedWrap, verifyReceiveEnvelope } from "./receive.ts";
export * from "./channel-sync.ts";
export * from "./invite-watcher.ts";
export * from "./invite-manager.ts";
export * from "./private-channel.ts";
export * from "./admin.ts";
export * from "./community.ts";
export * from "./refounding.ts";
// Only rotation types are public; rotation and revocation runtime helpers stay internal.
export type { RotationDiagnostic, RotationDiagnosticReason } from "./rotation.ts";
/** Thrown by invite revocation when no relay accepts a required stage; catch it with `instanceof`. */
export { InviteRevocationPublishError } from "./revocation.ts";
export * from "./client.ts";
