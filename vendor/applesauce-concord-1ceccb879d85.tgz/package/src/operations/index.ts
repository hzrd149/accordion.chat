/**
 * Concord rumor operations — composable `EventOperation`s that mutate a rumor
 * draft's content/tags for each plane (chat, guestbook, control, rekey, invite).
 * The factories in `../factories` chain these onto blank rumor templates; the
 * envelope (`../helpers/stream.ts`) seals and wraps the finished rumor.
 *
 * @example
 * ```ts
 * import { giftWrap } from "@applesauce/concord/operations";
 * ```
 *
 * @module
 */

export * from "./channel.ts";
export * from "./edit.ts";
export * from "./gift-wrap.ts";
export * from "./guestbook.ts";
export * from "./control.ts";
export * from "./rekey.ts";
export * from "./invite-bundle.ts";
export * from "./direct-invite.ts";
export * from "./invite-list.ts";
export * from "./community-list.ts";
