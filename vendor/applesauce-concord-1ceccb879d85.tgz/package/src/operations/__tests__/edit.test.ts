import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { EDIT_KIND } from "../../helpers/edit.ts";
import { includeEditTarget } from "../edit.ts";

const blank = (kind: number) => ({ kind, content: "", tags: [] as string[][], created_at: 0 });

describe("edit operations", () => {
  it("includeEditTarget points at its target", async () => {
    const edit = await includeEditTarget("e2")(blank(EDIT_KIND));
    expect(edit.tags).toContainEqual(["e", "e2"]);
  });
});
