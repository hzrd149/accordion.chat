/**
 * Protocol helpers and a reactive client for encrypted Nostr communities (CORD-01…06).
 *
 * Install with `deno add jsr:@applesauce/concord`.
 *
 * Exports layer namespaces, protocol types, the client, and logger. Import
 * `/helpers`, `/operations`, `/factories`, `/casts`, or `/models` directly to
 * avoid the client layer's relay, signer, and loader runtime dependencies.
 * This entrypoint registers self-encryption for Community and Invite Lists
 * (kinds 13302 and 13303) at import time.
 *
 * @example
 * ```ts
 * import { ConcordClient } from "@applesauce/concord";
 * ```
 *
 * @module
 */

import "./helpers/register.ts";

/** The pure CORD protocol core — key math, permission math, folds and codecs. */
export * as Helpers from "./helpers/index.ts";
/** Composable rumor operations that fill a draft's content and tags. */
export * as Operations from "./operations/index.ts";
/** `EventFactory` subclasses that build each plane's rumors and documents. */
export * as Factories from "./factories/index.ts";
/** `EventCast` accessors over the community documents outside the envelope. */
export * as Casts from "./casts/index.ts";
/** RxJS models folding plane rumor stores into derived community state. */
export * as Models from "./models/index.ts";

export * from "./types.ts";
export * from "./client/index.ts";
// The `applesauce:concord` namespace root (D-01) — mirrors applesauce-core's own
// pattern of re-exporting its logger module from the package root, so a consumer
// can `logger.extend("myapp")` and pass the result as `ConcordClientOptions.logger`
// without hand-constructing the namespace string.
export * from "./logger.ts";
