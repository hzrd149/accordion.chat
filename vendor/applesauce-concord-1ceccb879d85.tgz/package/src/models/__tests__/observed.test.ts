import { expect } from "@std/expect";
import { it } from "@std/testing/bdd";
import { RumorStore } from "applesauce-core";
import { getEventHash, type Rumor } from "applesauce-core/helpers/event";
import { ConcordObservedAuthorsModel } from "../observed.ts";
import { ConcordCommunityStateModel } from "../community.ts";
import { createCommunity } from "../../helpers/community.ts";

const author = "11".repeat(32);
function rumor(time: number, kind = 9): Rumor {
  const event = { id: "", pubkey: author, created_at: time, kind, tags: [], content: String(time) };
  event.id = getEventHash(event);
  return event;
}

it("updates observed maxima incrementally, restores older activity on removal, and releases claims", () => {
  const store = new RumorStore();
  const older = rumor(1);
  store.add(older);
  const values: Map<string, number>[] = [];
  const sub = ConcordObservedAuthorsModel()(store).subscribe((value) => values.push(value));
  expect(store.isClaimed(older)).toBe(true);
  const newer = rumor(3);
  store.add(newer);
  store.add(rumor(2));
  store.add(rumor(4, 23313));
  expect(values.length).toBe(2);
  expect(values[0].get(author)).toBe(1000);
  store.remove(newer);
  expect(values.at(-1)?.get(author)).toBe(2000);
  store.remove(older);
  expect(values.length).toBe(3);
  store.remove(rumor(2));
  expect(values.at(-1)?.has(author)).toBe(false);
  sub.unsubscribe();
  store.dispose();
});

it("replaces author activity rather than retaining obsolete replaceable events", () => {
  const store = new RumorStore();
  const values: Map<string, number>[] = [];
  const sub = ConcordObservedAuthorsModel()(store).subscribe((value) => values.push(value));
  const old = rumor(1, 0);
  const current = rumor(3, 0);
  store.add(old);
  store.add(current);
  expect(store.isClaimed(old)).toBe(false);
  expect(store.isClaimed(current)).toBe(true);
  store.remove(current);
  expect(values.at(-1)?.has(author)).toBe(false);
  sub.unsubscribe();
  expect(store.isClaimed(current)).toBe(false);
  store.dispose();
});

it("buffers changes during async observation initialization and cancels pending initialization", async () => {
  const store = new RumorStore();
  const initial = rumor(1);
  store.add(initial);
  let finish!: (events: Rumor[]) => void;
  // Exercise the same read boundary supplied by AsyncRumorStore without database I/O.
  const asyncRead = {
    getTimeline: () =>
      new Promise<Rumor[]>((resolve) => {
        finish = resolve;
      }),
  };
  const original = store.getTimeline.bind(store);
  Object.defineProperty(store, "getTimeline", { value: asyncRead.getTimeline, configurable: true });
  let latest = new Map<string, number>();
  const sub = ConcordObservedAuthorsModel()(store).subscribe((value) => latest = value);
  store.remove(initial);
  const live = rumor(2);
  store.add(live);
  finish([initial]);
  await Promise.resolve();
  expect(latest.get(author)).toBe(2000);
  expect(store.isClaimed(initial)).toBe(false);
  sub.unsubscribe();
  expect(store.isClaimed(live)).toBe(false);
  const cancelled = ConcordObservedAuthorsModel()(store).subscribe();
  cancelled.unsubscribe();
  finish([live]);
  await Promise.resolve();
  expect(store.isClaimed(live)).toBe(false);
  Object.defineProperty(store, "getTimeline", { value: original });
  store.dispose();
});

it("does not re-emit community state for newer messages from a present member, but handles departures", async () => {
  const { material } = await createCommunity({ ownerPubkey: author, name: "perf", relays: [] });
  const control = new RumorStore();
  const guestbook = new RumorStore();
  const channel = new RumorStore();
  const states: Set<string>[] = [];
  const sub = ConcordCommunityStateModel(material, { guestbook, observed: [channel] }, 10000)(control)
    .subscribe((state) => states.push(state.members));
  const first = rumor(1);
  channel.add(first);
  expect(states.at(-1)?.has(author)).toBe(true);
  const count = states.length;
  const second = rumor(2);
  channel.add(second);
  expect(states.length).toBe(count);
  channel.remove(second);
  channel.remove(first);
  expect(states.at(-1)?.has(author)).toBe(false);
  sub.unsubscribe();
  control.dispose();
  guestbook.dispose();
  channel.dispose();
});

it("matches a fresh activity fold through mixed insertions and removals without reloading history", () => {
  const store = new RumorStore();
  const original = store.getTimeline.bind(store);
  let reads = 0;
  store.getTimeline = (filters) => {
    reads++;
    return original(filters);
  };
  let latest = new Map<string, number>();
  const sub = ConcordObservedAuthorsModel()(store).subscribe((value) => latest = value);
  const retained: Rumor[] = [];
  for (let i = 1; i <= 100; i++) {
    const event = rumor(i % 17 + 1, i % 7 === 0 ? 23313 : 9);
    event.pubkey = (i % 4 + 1).toString(16).padStart(64, "0");
    event.content = String(i);
    event.id = getEventHash(event);
    store.add(event);
    retained.push(event);
    if (i % 3 === 0) store.remove(retained.shift()!);
    const expected = new Map<string, number>();
    for (const current of original([{}])) {
      if (current.kind === 23313) continue;
      expected.set(current.pubkey, Math.max(expected.get(current.pubkey) ?? 0, current.created_at * 1000));
    }
    expect(latest).toEqual(expected);
  }
  expect(reads).toBe(1);
  sub.unsubscribe();
  for (const event of retained) expect(store.isClaimed(event)).toBe(false);
  store.dispose();
});
