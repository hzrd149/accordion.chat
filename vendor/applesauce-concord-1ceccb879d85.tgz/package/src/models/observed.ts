import type { Model } from "applesauce-core/event-store";
import { getEventUID, isEphemeralKind, isReplaceable, type Rumor } from "applesauce-core/helpers/event";
import { Observable, Subscription } from "rxjs";

import { rumorMs } from "../helpers/stream.ts";

/**
 * Compute latest observed activity per author from a RumorStore.
 *
 * Observation means *durable* authorship: ephemeral kinds (NIP-01 range
 * 20000-29999) never count as presence in the roster fold, so a voice
 * beacon cannot resurrect a removed member. This is a range check by
 * design — enumerating a single kind (e.g. the voice-presence beacon) is
 * the anti-pattern being avoided, since any future presence-like kind must
 * be covered by construction.
 */
export function ConcordObservedAuthorsModel(): Model<Map<string, number>, Rumor> {
  return (store) =>
    new Observable<Map<string, number>>((subscriber) => {
      const events = new Map<string, Rumor>();
      const authors = new Map<string, Map<string, number>>();
      const latest = new Map<string, number>();
      const pending: { rumor: Rumor; remove: boolean }[] = [];
      let ready = false;
      const publish = () => subscriber.next(new Map(latest));
      const remove = (rumor: Rumor): void => {
        const uid = getEventUID(rumor);
        if (events.get(uid)?.id !== rumor.id) return;
        events.delete(uid);
        store.removeClaim(rumor);
        const times = authors.get(rumor.pubkey)!;
        const removed = times.get(rumor.id);
        times.delete(rumor.id);
        if (!times.size) authors.delete(rumor.pubkey);
        if (removed !== latest.get(rumor.pubkey)) return;
        let maximum = 0;
        for (const ms of times.values()) maximum = Math.max(maximum, ms);
        if (maximum > 0) latest.set(rumor.pubkey, maximum);
        else latest.delete(rumor.pubkey);
      };
      const insert = (rumor: Rumor): void => {
        if (isEphemeralKind(rumor.kind)) return;
        const uid = getEventUID(rumor);
        const old = events.get(uid);
        if (old && (!isReplaceable(rumor.kind) || rumor.created_at < old.created_at)) return;
        if (old) remove(old);
        events.set(uid, rumor);
        store.claim(rumor);
        let times = authors.get(rumor.pubkey);
        if (!times) authors.set(rumor.pubkey, times = new Map());
        const ms = rumorMs(rumor);
        times.set(rumor.id, ms);
        if (ms > (latest.get(rumor.pubkey) ?? 0)) latest.set(rumor.pubkey, ms);
      };
      const apply = (rumor: Rumor, removing: boolean): void => {
        if (!ready) {
          pending.push({ rumor, remove: removing });
          return;
        }
        const before = latest.get(rumor.pubkey);
        if (removing) remove(rumor);
        else insert(rumor);
        if (before !== latest.get(rumor.pubkey)) publish();
      };
      const subscriptions = new Subscription();
      subscriptions.add(
        store.insert$.subscribe({ next: (rumor) => apply(rumor, false), error: (e) => subscriber.error(e) }),
      );
      subscriptions.add(
        store.remove$.subscribe({ next: (rumor) => apply(rumor, true), error: (e) => subscriber.error(e) }),
      );
      const initialize = (rumors: Rumor[]): void => {
        if (subscriber.closed) return;
        for (const rumor of rumors) insert(rumor);
        for (const entry of pending) {
          if (entry.remove) remove(entry.rumor);
          else insert(entry.rumor);
        }
        pending.length = 0;
        ready = true;
        publish();
      };
      try {
        const initial = store.getTimeline([{}]);
        if (initial instanceof Promise) initial.then(initialize).catch((e) => subscriber.error(e));
        else initialize(initial);
      } catch (e) {
        subscriber.error(e);
      }
      return () => {
        subscriptions.unsubscribe();
        for (const rumor of events.values()) store.removeClaim(rumor);
        events.clear();
        authors.clear();
        latest.clear();
        pending.length = 0;
      };
    });
}
