import { expect } from "@std/expect";
import { describe, it } from "@std/testing/bdd";
import { scanDeclarationImports } from "./doc-lint-graph.ts";

describe("declaration module references", () => {
  it("includes relative and package module augmentations alongside imports", () => {
    expect(scanDeclarationImports(`
      import type { User } from "applesauce-core/casts";
      declare module "./profile.js" { interface Profile { user: User; } }
      declare module "applesauce-core/casts" { interface User { active: boolean; } }
      // declare module "./comment.js" {}
      /** Example: declare module "./example.js" {} */
      type Example = 'declare module "./string.js" {}';
    `)).toEqual([
      { specifier: "applesauce-core/casts", reference: false },
      { specifier: "./profile.js", reference: false },
      { specifier: "applesauce-core/casts", reference: false },
    ]);
  });
});
