// Keep auth scoped and reactive: reject ambient registries, proactive triggers,
// retry-budget overrides, and duplicate handlers anywhere in src/.

/// <reference lib="deno.ns" />
// Test-only: `deno.json` sets `lib` to ES2022+DOM without `deno.ns`, so library
// source cannot reach for Deno APIs and stays browser-safe. This file is a test
// guard that must read the source tree, so it opts into the Deno namespace here
// rather than widening `lib` for all of `src/`.

import { dirname, fromFileUrl, join } from "@std/path";

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

// Resolved from this file's own module URL, never from process.cwd(), so the
// scan root does not depend on the working directory. The suite runs under
// `deno test` from the repository root.
const SELF = fromFileUrl(import.meta.url);
const SRC_ROOT = join(dirname(SELF), "..");

/**
 * Recursively collects every file under `dir` matching one of `extensions`,
 * excluding this guard's own file (`SELF`) — it necessarily contains every
 * forbidden literal below as regex source, and would otherwise flag itself.
 */
function collectFiles(dir: string, extensions: string[]): string[] {
  const out: string[] = [];
  for (const entry of Deno.readDirSync(dir)) {
    const full = join(dir, entry.name);
    if (entry.isDirectory) out.push(...collectFiles(full, extensions));
    else if (extensions.some((ext) => entry.name.endsWith(ext)) && full !== SELF) out.push(full);
  }
  return out;
}

const isTestPath = (path: string): boolean => path.includes("__tests__");

/** Every `.ts`/`.tsx` file under `src/` — the shared file list every check below scans. */
const allFiles = (): string[] => collectFiles(SRC_ROOT, [".ts", ".tsx"]);

// The five removed mechanisms — the deleted class name, the driver-authentication
// method, the old key-registration method name, the status-driven user-auth
// option, the removed per-engine driver-synchronisation method, the removed
// manual user-authenticate method, and the removed relay-wide-flag needs-auth
// predicate.
const REMOVED_MECHANISMS =
  /ConcordRelayAuth|authenticateStreamKeys|registerStreamKeys|autoAuthenticate|ensureAuth|authenticateUser|userNeedsAuth/;

// The relay challenge observable and the two relay-wide auth-required flags —
// D-01 forbids any proactive reader of these; auth only ever fires reactively
// off a relay's own refusal of an operation.
const AMBIENT_AUTH_TRIGGER = /challenge\$|authRequiredForRead|authRequiredForPublish/;

// D-05 keeps every concord call site on the upstream defaults (1 retry,
// 30_000ms) — the concord-side half of CAUTH-04's parity claim.
const RETRY_BUDGET_OVERRIDE = /authRetries|authTimeout/;

// The relay-supplied missing-pubkeys field — only `client/auth.ts` may
// implement a handler that reads it; a second copy elsewhere is exactly how a
// scope ends up authenticating a key it does not own (T-15-01).
const MISSING_PUBKEYS_FIELD = /missingPubkeys/;
const AUTH_HANDLER_FILE = join(SRC_ROOT, "client", "auth.ts");

describe("no ambient auth guard (CAUTH-03/D-06)", () => {
  it("scans well over fifty .ts files under src/ (anti-vacuity: a broken path cannot pass silently)", () => {
    const packageFiles = collectFiles(SRC_ROOT, [".ts", ".tsx"]);
    expect(packageFiles.length).toBeGreaterThan(50);
  });

  it("no file under src/ names any of the five removed mechanisms (tests included)", () => {
    const files = allFiles();
    const offenders: string[] = [];

    for (const file of files) {
      const text = Deno.readTextFileSync(file);
      if (REMOVED_MECHANISMS.test(text)) offenders.push(file);
    }

    expect(offenders).toEqual([]);
  });

  it("no non-test file under src/ subscribes to a relay challenge stream or reads a relay-wide auth-required flag", () => {
    const files = allFiles().filter((f) => !isTestPath(f));
    const offenders: string[] = [];

    for (const file of files) {
      const text = Deno.readTextFileSync(file);
      if (AMBIENT_AUTH_TRIGGER.test(text)) offenders.push(file);
    }

    expect(offenders).toEqual([]);
  });

  it("no non-test file under src/ overrides the auth retry count or the auth timeout", () => {
    const files = allFiles().filter((f) => !isTestPath(f));
    const offenders: string[] = [];

    for (const file of files) {
      const text = Deno.readTextFileSync(file);
      if (RETRY_BUDGET_OVERRIDE.test(text)) offenders.push(file);
    }

    expect(offenders).toEqual([]);
  });

  it("only client/auth.ts implements a handler over the relay-supplied missing-pubkeys field under src/ — one handler, not a family of hand-rolled copies", () => {
    const files = allFiles().filter((f) => f !== AUTH_HANDLER_FILE && !isTestPath(f));
    const offenders: string[] = [];

    for (const file of files) {
      const text = Deno.readTextFileSync(file);
      if (MISSING_PUBKEYS_FIELD.test(text)) offenders.push(file);
    }

    expect(offenders).toEqual([]);
  });
});
