/** An external declaration edge, including triple-slash declaration references. */
export interface DeclarationImport {
  specifier: string;
  reference: boolean;
}

/** Finds imports and module augmentations without treating comments or strings as module references. */
export function scanDeclarationImports(source: string): DeclarationImport[] {
  const edges: { offset: number; edge: DeclarationImport }[] = [];
  const tokens: { value: string; string: boolean; offset: number }[] = [];
  for (let i = 0; i < source.length;) {
    const char = source[i];
    if (/\s/.test(char)) {
      i++;
    } else if (source.startsWith("//", i)) {
      const end = source.indexOf("\n", i);
      const line = source.slice(i, end < 0 ? source.length : end);
      if (/^\/\/\/\s*<reference\b/.test(line)) {
        const match = /^\/\/\/\s*<reference\s+(path|types|lib)=["']([^"'\\]+)["']\s*\/?>\s*$/.exec(line);
        if (!match) throw new Error("Unsupported declaration reference: " + line);
        if (match[1] !== "lib") {
          edges.push({ offset: i, edge: { specifier: match[2], reference: true } });
        } else if (!/^(es\d+|esnext)(\.[a-z0-9.]+)?$|^dom(\.iterable)?$/.test(match[2])) {
          throw new Error("Unsupported built-in declaration reference: " + match[2]);
        }
      }
      i = end < 0 ? source.length : end;
    } else if (source.startsWith("/*", i)) {
      const end = source.indexOf("*/", i + 2);
      if (end < 0) throw new Error("Unterminated declaration comment");
      i = end + 2;
    } else if (char === '"' || char === "'" || char === "`") {
      const offset = i++;
      let value = "";
      let closed = false;
      while (i < source.length) {
        if (source[i] === char) {
          i++;
          closed = true;
          break;
        }
        if (source[i] === "\\") {
          value += source[i++];
          if (i === source.length) break;
        }
        value += source[i++];
      }
      if (!closed) throw new Error("Unterminated declaration string");
      tokens.push({ value, string: char !== "`", offset });
    } else {
      const offset = i;
      const word = /^[A-Za-z_$][\w$]*/.exec(source.slice(i));
      const value = word?.[0] ?? char;
      i += value.length;
      tokens.push({ value, string: false, offset });
    }
  }
  const add = (index: number): void => {
    const token = tokens[index];
    if (!token?.string || !token.value || /[\\\s]/.test(token.value)) {
      throw new Error("Unsupported nonliteral/escaped module specifier at " + token?.offset);
    }
    if (["with", "assert"].includes(tokens[index + 1]?.value)) throw new Error("Unsupported import attributes");
    edges.push({ offset: token.offset, edge: { specifier: token.value, reference: false } });
  };
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (
      !token.string && token.value === "declare" && tokens[i + 1]?.value === "module" &&
      tokens[i + 2]?.string
    ) {
      add(i + 2);
      continue;
    }
    if (token.string || !["import", "export"].includes(token.value) || tokens[i - 1]?.value === ".") continue;
    if (token.value === "import" && tokens[i + 1]?.value === "(") {
      add(i + 2);
      if (tokens[i + 3]?.value !== ")") throw new Error("Unsupported import type arguments");
    } else if (token.value === "import" && tokens[i + 1]?.string) {
      add(i + 1);
    } else {
      if (
        token.value === "export" && !["{", "*"].includes(tokens[i + 1]?.value) &&
        !(tokens[i + 1]?.value === "type" && ["{", "*"].includes(tokens[i + 2]?.value))
      ) continue;
      let braces = 0;
      for (let j = i + 1; j < tokens.length; j++) {
        if (!tokens[j].string && tokens[j].value === "{") braces++;
        if (!tokens[j].string && tokens[j].value === "}") braces--;
        if (!tokens[j].string && tokens[j].value === "from" && braces === 0) {
          add(j + 1);
          break;
        }
        if (token.value === "import" && ["=", "require"].includes(tokens[j].value)) {
          throw new Error("Unsupported import assignment");
        }
        if ([";", "import", "export"].includes(tokens[j].value) && !tokens[j].string) break;
      }
    }
  }
  return edges.sort((a, b) => a.offset - b.offset).map(({ edge }) => edge);
}

/** Minimal installed manifest data consumed by the declaration resolver. */
export interface PackageManifest {
  name: string;
  version: string;
  exports?: unknown;
  types?: string;
  typings?: string;
  main?: string;
}

/** Injected read operations keep graph resolution free of filesystem/network effects. */
export interface DeclarationFileSystem {
  exists(path: string): boolean;
  manifest(path: string): PackageManifest | undefined;
}

function normalize(path: string): string {
  if (!path.startsWith("/")) throw new Error("Expected absolute path: " + path);
  const parts: string[] = [];
  for (const part of path.split("/")) {
    if (part === "..") {
      if (!parts.length) throw new Error("Path escapes filesystem root");
      parts.pop();
    } else if (part && part !== ".") parts.push(part);
  }
  return "/" + parts.join("/");
}

function parent(path: string): string {
  return path.slice(0, path.lastIndexOf("/")) || "/";
}

/** Rejects canonical or lexical paths outside the specified directory boundary. */
export function assertInside(path: string, directory: string): void {
  const normalized = normalize(path);
  const root = normalize(directory);
  if (normalized !== root && !normalized.startsWith(root + "/")) {
    throw new Error("Path escapes allowed directory: " + path);
  }
}

/**
 * Chooses only declaration files in native Deno 2.9.6 import-mode probe order.
 * Require-mode imports and non-declaration TS fallback targets are unsupported.
 */
export function declarationCandidate(path: string, exists: (path: string) => boolean): string {
  path = normalize(path);
  // https://github.com/denoland/deno/blob/v2.9.6/libs/node_resolver/resolution.rs#L1173-L1216
  // Only .mjs/.cjs prioritize their matching declaration. Typed extensions
  // otherwise probe .d.ts then .d.mts in import mode, just like ordinary .js.
  const extensions = path.endsWith(".mjs")
    ? [".d.mts", ".d.ts"]
    : path.endsWith(".cjs")
    ? [".d.cts", ".d.ts", ".d.mts"]
    : [".d.ts", ".d.mts"];
  const candidates = /\.d\.(ts|mts|cts)$/.test(path)
    ? [path]
    : /\.(js|mjs|cjs|ts|mts|cts)$/.test(path)
    ? extensions.map((extension) => path.replace(/\.[^.]+$/, extension))
    : [path + ".d.ts", path + ".d.mts"];
  const found = [...new Set(candidates)].find(exists);
  if (found) return found;
  // Native .ts fallback takes precedence over directory resolution. The graph
  // serves declarations only: reject that target rather than selecting an index.
  const tsPath = /\.(js|mjs|cjs|ts|mts|cts)$/.test(path) ? path.replace(/\.[^.]+$/, ".ts") : path + ".ts";
  if (exists(tsPath)) throw new Error("Unsupported non-declaration TS fallback: " + tsPath);
  if (!/\.[^/]+$/.test(path) && !exists(path)) {
    const index = [path + "/index.d.ts", path + "/index.d.mts"].find(exists);
    if (index) return index;
  }
  throw new Error("Unresolved declaration: " + path);
}

function exportTarget(value: unknown): string {
  if (typeof value === "string") return value;
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Unsupported package export");
  const conditions = value as Record<string, unknown>;
  const supported = ["types", "import", "default", "node", "require", "browser", "es2015", "source"];
  if (Object.keys(conditions).some((key) => !supported.includes(key))) {
    throw new Error("Unsupported package export condition");
  }
  for (const key of ["types", "import", "default"]) {
    if (key in conditions) return exportTarget(conditions[key]);
  }
  throw new Error("No supported package export condition");
}

/** Resolves supported import-mode edges; native npm parity separately proves bare choices. */
export function resolveDeclaration(
  specifier: string,
  from: string,
  fs: DeclarationFileSystem,
  reference = false,
): string {
  if (/^[a-zA-Z][\w+.-]*:/.test(specifier) || specifier.startsWith("#")) {
    throw new Error("Unsupported declaration specifier: " + specifier);
  }
  if (
    specifier.startsWith(".") || specifier.startsWith("/") || (reference && fs.exists(parent(from) + "/" + specifier))
  ) {
    return declarationCandidate(specifier.startsWith("/") ? specifier : parent(from) + "/" + specifier, fs.exists);
  }
  const parts = specifier.split("/");
  const name = parts.slice(0, specifier.startsWith("@") ? 2 : 1).join("/");
  const subpath = specifier.slice(name.length).replace(/^\//, "");
  if (!name || name === "@" || parts.some((part) => part === ".." || part === ".")) {
    throw new Error("Invalid bare declaration specifier");
  }
  for (let directory = parent(from);; directory = parent(directory)) {
    const pkg = normalize(directory + "/node_modules/" + name);
    const manifest = fs.manifest(pkg + "/package.json");
    if (manifest) {
      if (manifest.name !== name) throw new Error("Installed package name mismatch");
      let target: string;
      if (manifest.exports !== undefined) {
        const exports = manifest.exports;
        const key = subpath ? "./" + subpath : ".";
        if (
          typeof exports === "string" || (exports && typeof exports === "object" && !Array.isArray(exports) &&
            !Object.keys(exports).some((entry) => entry.startsWith(".")))
        ) {
          if (subpath) throw new Error("Package subpath not exported");
          target = exportTarget(exports);
        } else if (exports && typeof exports === "object" && !Array.isArray(exports)) {
          const table = exports as Record<string, unknown>;
          if (key in table) target = exportTarget(table[key]);
          else {
            const matches = Object.keys(table).filter((pattern) => {
              const [prefix, suffix] = pattern.split("*");
              return pattern.includes("*") && pattern.split("*").length === 2 &&
                key.startsWith(prefix) && key.endsWith(suffix) && key.length >= prefix.length + suffix.length;
            }).sort((a, b) => b.split("*")[0].length - a.split("*")[0].length || b.length - a.length);
            if (!matches.length) throw new Error("Package subpath not exported: " + specifier);
            const pattern = matches[0];
            const [prefix, suffix] = pattern.split("*");
            const middle = key.slice(prefix.length, suffix ? -suffix.length : undefined);
            target = exportTarget(table[pattern]).replaceAll("*", middle);
          }
        } else throw new Error("Unsupported package exports");
        if (!target.startsWith("./")) throw new Error("Nonrelative package export");
      } else target = subpath || manifest.types || manifest.typings || manifest.main || "index.d.ts";
      const path = normalize(pkg + "/" + target);
      assertInside(path, pkg);
      return declarationCandidate(path, fs.exists);
    }
    if (directory === "/") break;
  }
  throw new Error("Unresolved bare declaration: " + specifier);
}

/** Returns exactly the existing seven entrypoints; substitutions and active links reject. */
export function deriveRoots(config: { exports?: unknown; links?: unknown }): string[] {
  const expected: Record<string, string> = {
    ".": "./src/index.ts",
    "./helpers": "./src/helpers/index.ts",
    "./operations": "./src/operations/index.ts",
    "./factories": "./src/factories/index.ts",
    "./casts": "./src/casts/index.ts",
    "./models": "./src/models/index.ts",
    "./client": "./src/client/index.ts",
  };
  if (config.links !== undefined && (!Array.isArray(config.links) || config.links.length)) {
    throw new Error("Active/unsupported local package links");
  }
  const exports = config.exports;
  if (!exports || typeof exports !== "object" || Array.isArray(exports)) throw new Error("Missing package exports");
  const table = exports as Record<string, unknown>;
  if (Object.keys(table).length !== 7 || Object.keys(expected).some((key) => table[key] !== expected[key])) {
    throw new Error("Public source roots differ from original seven entrypoints");
  }
  return Object.keys(expected).map((key) => (table[key] as string).slice(2));
}

/** Verifies the served and current installed inputs retain every original byte. */
export function assertByteIdentity(original: Uint8Array, current: Uint8Array): void {
  if (original.length !== current.length || original.some((byte, i) => byte !== current[i])) {
    throw new Error("Input declaration/config/source bytes changed");
  }
}

/** Requires an exact installed name/version in the native lock, preserving peer suffixes. */
export function assertLockedIdentity(name: string, version: string, locked: string[]): void {
  const identity = name + "@" + version;
  if (!locked.some((key) => key === identity || key.startsWith(identity + "_"))) {
    throw new Error("Unlocked installed identity: " + identity);
  }
}

/** A resolved declaration edge. */
export interface DeclarationEdge {
  from: string;
  specifier: string;
  to: string;
}

/** Rejects empty graphs, omitted declarations and locally mapped modules. */
export function assertCompleteGraph(paths: string[], edges: DeclarationEdge[], directory: string): void {
  if (!paths.length || !edges.length) throw new Error("Empty external declaration graph");
  const known = new Set(paths);
  for (const path of paths) {
    assertInside(path, directory);
    if (!/\.d\.(ts|mts|cts)$/.test(path)) throw new Error("Only installed declarations may be mapped");
  }
  for (const edge of edges) {
    if (!known.has(edge.from) || !known.has(edge.to)) throw new Error("Omitted/unresolved declaration edge");
  }
}

/** Raw native subprocess result; no diagnostic filtering is performed. */
export interface NativeResult {
  code: number;
  stdout: string;
  stderr: string;
}

/** Checks native exit and all diagnostic kinds, rejecting graph warnings even on exit zero. */
export function assertNativeResult(result: NativeResult, expectedKind?: string): void {
  const output = result.stdout + result.stderr;
  if (/\bwarn(?:ing)?\b/i.test(output)) throw new Error("Native graph warning");
  const diagnostics = [...output.matchAll(/error\[([^\]]+)\]/g)].map((match) => match[1]);
  const errors = [...output.matchAll(/(?:^|\n)\s*error:\s*([^\n]*)/g)].map((match) => match[1]);
  if (expectedKind) {
    if (
      result.code !== 1 || diagnostics.length !== 1 || diagnostics[0] !== expectedKind ||
      errors.some((message) => message !== "Found 1 documentation lint error.")
    ) {
      throw new Error("Negative control did not fail solely " + expectedKind);
    }
  } else if (result.code !== 0 || diagnostics.length || /(?:^|\n)\s*error\b/i.test(output)) {
    throw new Error("Native command failed");
  }
}

/** Requires all four native disconfirmation fixtures on every gate invocation. */
export function assertControls(controls: Record<string, NativeResult>): void {
  const expected: Record<string, string | undefined> = {
    good: undefined,
    private: "private-type-ref",
    "private-import": "private-type-ref",
    undocumented: "missing-jsdoc",
  };
  if (Object.keys(controls).length !== 4) throw new Error("Missing/unexpected local controls");
  for (const name of Object.keys(expected)) {
    if (!controls[name]) throw new Error("Missing local control: " + name);
    assertNativeResult(controls[name], expected[name]);
  }
}

/** Canonicalizes only exact module URL values/keys; comments and type text remain untouched. */
export function canonicalizeDocuments(value: unknown, identities: ReadonlyMap<string, string>): unknown {
  const known = new Set(
    [...identities.values()].map((url) => url.startsWith("file:") ? new URL(decodeURI(url)).href : url),
  );
  const canonical = (text: string): string => {
    const mapped = identities.get(text) ?? text;
    if (!mapped.startsWith("file:")) return mapped;
    // Native deno_doc uses both file:/ and file:/// and percent-encodes npm '+'/'@'.
    const url = new URL(decodeURI(mapped)).href;
    return known.has(url) ? url : text;
  };
  const visit = (item: unknown): unknown => {
    if (typeof item === "string") return canonical(item);
    if (Array.isArray(item)) return item.map(visit);
    if (item && typeof item === "object") {
      const out: Record<string, unknown> = {};
      for (const [key, entry] of Object.entries(item)) {
        const mapped = canonical(key);
        if (Object.hasOwn(out, mapped)) throw new Error("Module URL canonicalization collision");
        out[mapped] = visit(entry);
      }
      return out;
    }
    return item;
  };
  return visit(value);
}

function deepEqual(a: unknown, b: unknown): boolean {
  if (Object.is(a, b)) return true;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((entry, i) => deepEqual(entry, b[i]));
  }
  if (a && b && typeof a === "object" && typeof b === "object" && !Array.isArray(a) && !Array.isArray(b)) {
    const aa = a as Record<string, unknown>;
    const bb = b as Record<string, unknown>;
    return Object.keys(aa).length === Object.keys(bb).length &&
      Object.keys(aa).every((key) => Object.hasOwn(bb, key) && deepEqual(aa[key], bb[key]));
  }
  return false;
}

/** Requires deep native/projected equality after module identity replacement only. */
export function documentsEqual(native: unknown, projected: unknown, identities: ReadonlyMap<string, string>): boolean {
  return deepEqual(canonicalizeDocuments(native, identities), canonicalizeDocuments(projected, identities));
}
