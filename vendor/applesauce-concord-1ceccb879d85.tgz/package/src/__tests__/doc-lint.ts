/// <reference lib="deno.ns" />
// Unpublished CLI: only installed declarations get external URLs. Every public
// Concord module and local disconfirmation fixture retains its original file URL.
// Deno skips imported file-scheme declarations during doc lint. Serving only
// installed declarations exposes them to lint without relocating local source.

import { dirname, fromFileUrl, isAbsolute, join, relative, resolve, toFileUrl } from "@std/path";
import {
  assertByteIdentity,
  assertCompleteGraph,
  assertControls,
  assertInside,
  assertLockedIdentity,
  assertNativeResult,
  declarationCandidate,
  deriveRoots,
  documentsEqual,
  resolveDeclaration,
  scanDeclarationImports,
} from "./doc-lint-graph.ts";
import type { DeclarationEdge, DeclarationFileSystem, NativeResult, PackageManifest } from "./doc-lint-graph.ts";

/**
 * Removes `//` line comments and block comments from JSONC text, leaving string literals
 * untouched so a `//` inside a value (an `npm:` specifier, a URL) survives. `deno.json` is
 * JSONC and `JSON.parse` rejects it outright, so stripping first is what makes the
 * structural check below possible without adding a JSONC dependency.
 */
function stripJsonComments(text: string): string {
  let out = "";
  let inString = false;
  let inLineComment = false;
  let inBlockComment = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const next = text[i + 1];

    if (inLineComment) {
      // Keep the newline so line structure (and any error offsets) survive stripping.
      if (char === "\n") {
        inLineComment = false;
        out += char;
      }
      continue;
    }

    if (inBlockComment) {
      if (char === "*" && next === "/") i++, (inBlockComment = false);
      continue;
    }

    if (inString) {
      out += char;
      // A backslash escapes the next character, including an escaped quote.
      if (char === "\\") {
        out += next ?? "";
        i++;
        continue;
      }
      if (char === '"') inString = false;
      continue;
    }

    if (char === '"') {
      inString = true;
      out += char;
      continue;
    }
    if (char === "/" && next === "/") {
      inLineComment = true;
      i++;
      continue;
    }
    if (char === "/" && next === "*") {
      inBlockComment = true;
      i++;
      continue;
    }

    out += char;
  }

  return out;
}

interface NativeDependency {
  specifier: string;
  type?: { specifier?: string; error?: unknown };
  code?: { specifier?: string; error?: unknown };
}

interface NativeModule {
  specifier: string;
  error?: unknown;
  dependencies?: NativeDependency[];
}

interface NativeGraph {
  roots: string[];
  modules: NativeModule[];
}

interface CommandEvidence {
  label: string;
  command: string[];
  cwd: string;
  exit_code: number;
  seconds: number;
  stdout_sha256: string;
  stderr: string;
}

interface Declaration {
  path: string;
  bytes: Uint8Array;
  owner: string;
  identity: string;
}

const decoder = new TextDecoder("utf-8", { fatal: true });

async function sha256(bytes: Uint8Array): Promise<string> {
  const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", new Uint8Array(bytes)));
  return Array.from(hash, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function requireCondition(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

function checkNativeGraph(result: NativeResult): NativeGraph {
  try {
    assertNativeResult({ ...result, stdout: "" });
  } catch (cause) {
    throw new Error("Native graph rejected: " + result.stderr, { cause });
  }
  const graph = JSON.parse(result.stdout) as NativeGraph;
  requireCondition(Array.isArray(graph.roots) && graph.roots.length > 0, "Native graph roots missing");
  requireCondition(Array.isArray(graph.modules) && graph.modules.length > 0, "Native graph modules missing");
  for (const module of graph.modules) {
    requireCondition(!module.error, "Unresolved native module: " + module.specifier);
    for (const edge of module.dependencies ?? []) {
      requireCondition(!edge.type?.error && !edge.code?.error, "Unresolved native edge: " + edge.specifier);
      requireCondition(edge.type?.specifier || edge.code?.specifier, "Missing native edge: " + edge.specifier);
    }
  }
  return graph;
}

function outputPath(argument: string, artifacts: string, suffix: string): string {
  requireCondition(
    !isAbsolute(argument) && argument.startsWith(".artifacts/") && argument.endsWith(suffix),
    "Evidence output must be a relative .artifacts path ending in " + suffix,
  );
  const path = resolve(argument);
  assertInside(path, artifacts);
  assertInside(Deno.realPathSync(dirname(path)), artifacts);
  try {
    assertInside(Deno.realPathSync(path), artifacts);
  } catch (error) {
    if (!(error instanceof Deno.errors.NotFound)) throw error;
  }
  return path;
}

/** Executes the complete native gate, including equivalence and mandatory local controls. */
export async function runDocumentationLint(args: string[]): Promise<void> {
  const started = performance.now();
  const root = fromFileUrl(new URL("../../", import.meta.url)).replace(/\/$/, "");
  requireCondition(Deno.cwd() === root, "Run documentation lint from the package checkout root");
  Deno.mkdirSync(".artifacts", { recursive: true });
  const artifacts = Deno.realPathSync(".artifacts");
  assertInside(artifacts, root);
  const installed = Deno.realPathSync("node_modules");
  assertInside(installed, root);
  let reportPath: string | undefined;
  let logPath: string | undefined;
  for (let i = 0; i < args.length; i += 2) {
    const option = args[i];
    requireCondition(args[i + 1], "Missing output path");
    if (option === "--report" && !reportPath) reportPath = outputPath(args[i + 1], artifacts, ".json");
    else if (option === "--log" && !logPath) logPath = outputPath(args[i + 1], artifacts, ".log");
    else throw new Error("Unknown/duplicate argument: " + option);
  }
  const snapshots = new Map<string, Uint8Array>();
  const read = (path: string): Uint8Array => {
    const canonical = Deno.realPathSync(path);
    assertInside(canonical, root);
    const bytes = Deno.readFileSync(canonical);
    const previous = snapshots.get(canonical);
    if (previous) assertByteIdentity(previous, bytes);
    else snapshots.set(canonical, bytes);
    return bytes;
  };
  const config = JSON.parse(stripJsonComments(decoder.decode(read("deno.json")))) as {
    exports: Record<string, string>;
    imports: Record<string, string>;
    links?: unknown;
  };
  const roots = deriveRoots(config);
  const lock = JSON.parse(decoder.decode(read("deno.lock"))) as {
    npm: Record<string, unknown>;
    specifiers: Record<string, string>;
  };
  requireCondition(lock.npm && lock.specifiers, "Native lock metadata absent");
  const locked = Object.keys(lock.npm);
  for (const value of Object.values(config.imports)) {
    if (!value.startsWith("npm:")) continue;
    // Deno canonicalizes major-only caret ranges (e.g. ^7) to the major (7) in lock specifiers.
    const key = value.replace(/^npm:\//, "npm:").replace(/\/$/, "").replace(/@\^(\d+)$/, "@$1");
    requireCondition(Object.hasOwn(lock.specifiers, key), "Configured dependency is not locked: " + key);
  }
  const commands: CommandEvidence[] = [];
  const logs: string[] = [];
  const children = new Set<Deno.ChildProcess>();
  const temp = Deno.makeTempDirSync({ dir: artifacts, prefix: "concord-doc-lint-" });
  assertInside(Deno.realPathSync(temp), artifacts);
  let server: Deno.HttpServer<Deno.NetAddr> | undefined;
  let failed: unknown;
  const report: Record<string, unknown> = {
    runtime: Deno.version,
    started_at: new Date().toISOString(),
    status: "failed",
    roots,
    commands,
  };
  const run = async (label: string, command: string[], cwd = root, visible = false): Promise<NativeResult> => {
    const start = performance.now();
    const child = new Deno.Command("deno", {
      args: command,
      cwd,
      stdin: "null",
      stdout: "piped",
      stderr: "piped",
    }).spawn();
    children.add(child);
    let expired = false;
    const timer = setTimeout(() => {
      expired = true;
      try {
        child.kill("SIGKILL");
      } catch { /* Already exited; output still awaited below. */ }
    }, 20_000);
    try {
      const output = await child.output();
      const result = {
        code: output.code,
        stdout: decoder.decode(output.stdout),
        stderr: decoder.decode(output.stderr),
      };
      commands.push({
        label,
        command: ["deno", ...command],
        cwd,
        exit_code: result.code,
        seconds: (performance.now() - start) / 1000,
        stdout_sha256: await sha256(output.stdout),
        stderr: result.stderr,
      });
      logs.push(
        "\n=== " + label + " ===\n" + JSON.stringify(["deno", ...command]) + "\n" +
          "exit=" + result.code + "\n--- stdout (unfiltered) ---\n" + result.stdout +
          "\n--- stderr (unfiltered) ---\n" + result.stderr,
      );
      if (visible) {
        console.log("\n" + label + " (native exit " + result.code + ")");
        if (result.stdout) console.log(result.stdout);
        if (result.stderr) console.error(result.stderr);
      }
      requireCondition(!expired, "Native child deadline exceeded: " + label);
      return result;
    } finally {
      clearTimeout(timer);
      children.delete(child);
    }
  };
  // The overall tracer deadline leaves time for finally teardown before 60s.
  const deadline = setTimeout(() => {
    failed = new Error("Documentation validator exceeded 55-second deadline");
    for (const child of children) {
      try {
        child.kill("SIGKILL");
      } catch { /* Output/cleanup owns already exited children. */ }
    }
  }, 55_000);
  try {
    const nativeFlags = [
      "--config",
      join(root, "deno.json"),
      "--lock",
      join(root, "deno.lock"),
      "--frozen-lockfile",
      "--node-modules-dir=manual",
    ];
    // These graphs have only a CommonJS declaration sibling and no import map.
    // Native deno_doc must reject the missing .js/.mjs edges independently of
    // the two comparison maps, rather than certifying our own substitution.
    const incompleteGraphs: Record<string, NativeResult> = {};
    Deno.writeTextFileSync(join(temp, "fallback.d.cts"), "export interface Value { text: string; }\n");
    for (const extension of ["js", "mjs"]) {
      const path = join(temp, "incomplete-" + extension + ".d.ts");
      const specifier = "./fallback." + extension;
      Deno.writeTextFileSync(path, "export type Value = import(" + JSON.stringify(specifier) + ").Value;\n");
      const result = await run(
        "unmapped incomplete " + extension + " graph (expected native rejection)",
        ["doc", "--json", "--no-config", "--no-lock", path],
        root,
        true,
      );
      requireCondition(
        /\bModule not found\b/.test(result.stderr) && result.stderr.includes("fallback." + extension),
        "Native incomplete graph did not diagnose the missing edge: " + extension,
      );
      // deno doc --json may exit zero with an incomplete graph warning. The
      // gate's native-result guard must still reject that raw native result.
      let rejected = false;
      try {
        assertNativeResult(result);
      } catch {
        rejected = true;
      }
      requireCondition(rejected, "Native incomplete graph was accepted: " + extension);
      incompleteGraphs[extension] = result;
    }
    report.incomplete_graph_controls = incompleteGraphs;
    report.declaration_resolution = {
      mode: "import",
      supported_targets: "declarations only; non-declaration TS fallbacks reject",
      native_reference: "https://github.com/denoland/deno/blob/v2.9.6/libs/node_resolver/resolution.rs#L1173-L1216",
    };
    const scopes: Record<string, Record<string, string>> = {};
    const seeds: { from: string; specifier: string; to: string }[] = [];
    const queue: string[] = [];
    const nativeGraphs: { root: string; modules: number }[] = [];
    const exists = (path: string): boolean => {
      try {
        return Deno.statSync(path).isFile;
      } catch (error) {
        if (error instanceof Deno.errors.NotFound) return false;
        throw error;
      }
    };
    const fs: DeclarationFileSystem = {
      exists,
      manifest(path) {
        // Native node resolution may search ancestor directories. Only existing
        // manifests inside this checkout are eligible, never sibling checkouts.
        if (path !== root && !path.startsWith(root + "/")) return undefined;
        if (!exists(path)) return undefined;
        return JSON.parse(decoder.decode(read(path))) as PackageManifest;
      },
    };
    for (const entry of roots) {
      const graph = checkNativeGraph(
        await run("native type graph " + entry, ["info", "--json", ...nativeFlags, entry]),
      );
      requireCondition(
        graph.roots.length === 1 && graph.roots[0] === toFileUrl(join(root, entry)).href,
        "Native type graph substituted source root",
      );
      nativeGraphs.push({ root: graph.roots[0], modules: graph.modules.length });
      for (const module of graph.modules) {
        requireCondition(module.specifier.startsWith("file:"), "Unsupported non-file native module");
        const path = Deno.realPathSync(fromFileUrl(module.specifier));
        assertInside(path, root);
        if (path.startsWith(installed + "/")) continue;
        assertInside(path, join(root, "src"));
        read(path);
        for (const edge of module.dependencies ?? []) {
          const target = edge.type?.specifier ?? edge.code?.specifier;
          requireCondition(target && target.startsWith("file:"), "Unsupported native edge target");
          const targetPath = Deno.realPathSync(fromFileUrl(target));
          if (!targetPath.startsWith(installed + "/")) {
            assertInside(targetPath, join(root, "src"));
            continue;
          }
          const declaration = Deno.realPathSync(declarationCandidate(targetPath, exists));
          assertInside(declaration, installed);
          seeds.push({ from: module.specifier, specifier: edge.specifier, to: declaration });
          queue.push(declaration);
        }
      }
    }
    requireCondition(seeds.length, "Missing native external type edges");
    const ownerOf = (path: string): { path: string; manifest: PackageManifest } => {
      for (let directory = dirname(path); directory.startsWith(installed + "/"); directory = dirname(directory)) {
        const manifestPath = join(directory, "package.json");
        if (!exists(manifestPath)) continue;
        const manifest = fs.manifest(manifestPath);
        requireCondition(manifest?.name && manifest.version, "Installed manifest identity missing");
        assertLockedIdentity(manifest.name, manifest.version, locked);
        return { path: Deno.realPathSync(directory), manifest };
      }
      throw new Error("Installed owning package missing: " + path);
    };
    const declarations = new Map<string, Declaration>();
    const edges: DeclarationEdge[] = [];
    const nativeReferences: Record<string, Record<string, string>> = {};
    const bareGroups = new Map<string, Map<string, string>>();
    const sourceTargets = new Map<string, string>();
    for (const seed of seeds) {
      requireCondition(
        !seed.specifier.startsWith(".") && !seed.specifier.startsWith("/"),
        "Source dependency mapping must retain bare npm identity",
      );
      const previous = sourceTargets.get(seed.specifier);
      requireCondition(!previous || previous === seed.to, "Inconsistent configured source type resolution");
      sourceTargets.set(seed.specifier, seed.to);
    }
    bareGroups.set(root, sourceTargets);
    while (queue.length) {
      requireCondition(!failed, "Validator deadline exceeded");
      const path = queue.pop()!;
      if (declarations.has(path)) continue;
      assertInside(path, installed);
      const owner = ownerOf(path);
      const bytes = read(path);
      declarations.set(path, {
        path,
        bytes,
        owner: owner.path,
        identity: owner.manifest.name + "@" + owner.manifest.version,
      });
      for (const edge of scanDeclarationImports(decoder.decode(bytes))) {
        const target = Deno.realPathSync(resolveDeclaration(edge.specifier, path, fs, edge.reference));
        assertInside(target, installed);
        edges.push({ from: path, specifier: edge.specifier, to: target });
        queue.push(target);
        const relativeReference = edge.reference && exists(join(dirname(path), edge.specifier));
        if (relativeReference) {
          (nativeReferences[toFileUrl(path).href] ??= {})[edge.specifier] = toFileUrl(target).href;
        }
        if (!edge.specifier.startsWith(".") && !edge.specifier.startsWith("/") && !relativeReference) {
          let group = bareGroups.get(owner.path);
          if (!group) bareGroups.set(owner.path, group = new Map());
          const previous = group.get(edge.specifier);
          requireCondition(!previous || previous === target, "Inconsistent owning-package bare resolution");
          group.set(edge.specifier, target);
        }
      }
    }
    assertCompleteGraph([...declarations.keys()], edges, installed);
    report.native_graphs = nativeGraphs;
    report.edges = edges;
    report.source_type_edges = seeds;
    report.identities = [...new Set([...declarations.values()].map((declaration) => declaration.identity))].sort();
    // Resolve each distinct owning-package bare import using Deno itself with its
    // exact installed-and-locked npm identity and original subpath.
    const resolutions: { owner: string; specifier: string; identity: string; expected: string; actual: string }[] = [];
    let groupIndex = 0;
    for (const [owner, targets] of bareGroups) {
      const directory = join(temp, "native-" + groupIndex++);
      Deno.mkdirSync(directory);
      const imports: Record<string, string> = {};
      for (const [specifier, target] of targets) {
        const targetOwner = ownerOf(target);
        const name = specifier.split("/").slice(0, specifier.startsWith("@") ? 2 : 1).join("/");
        requireCondition(name === targetOwner.manifest.name, "Native probe package name substitution");
        imports[specifier] = "npm:" + targetOwner.manifest.name + "@" + targetOwner.manifest.version +
          specifier.slice(name.length);
      }
      const configPath = join(directory, "import-map.json");
      const probePath = join(directory, "probe.ts");
      Deno.writeTextFileSync(configPath, JSON.stringify({ imports }));
      Deno.writeTextFileSync(
        probePath,
        [...targets.keys()].map((specifier) => "import type {} from " + JSON.stringify(specifier) + ";").join("\n"),
      );
      const graph = checkNativeGraph(
        await run("native bare resolution " + owner, [
          "info",
          "--json",
          "--no-config",
          "--import-map",
          configPath,
          "--no-lock",
          "--node-modules-dir=manual",
          probePath,
        ]),
      );
      const probe = graph.modules.find((module) => module.specifier === toFileUrl(probePath).href);
      requireCondition(probe?.dependencies?.length === targets.size, "Missing native bare import checks");
      for (const dependency of probe.dependencies) {
        const target = targets.get(dependency.specifier);
        const actual = dependency.type?.specifier;
        requireCondition(target && actual && actual.startsWith("file:"), "Native npm type resolution missing");
        const nativePath = Deno.realPathSync(fromFileUrl(actual));
        requireCondition(nativePath === target, "Native npm declaration resolution differs: " + dependency.specifier);
        resolutions.push({
          owner,
          specifier: dependency.specifier,
          identity: imports[dependency.specifier],
          expected: toFileUrl(target).href,
          actual,
        });
      }
    }
    requireCondition(resolutions.length > 0 && bareGroups.size > 0, "Native bare resolution proof missing");
    report.native_resolutions = resolutions;
    const served = new Map<string, Declaration>();
    let unknownRequests = 0;
    server = Deno.serve({ hostname: "127.0.0.1", port: 0, onListen() {} }, (request) => {
      const url = new URL(request.url);
      const declaration = served.get(url.pathname);
      if (request.method !== "GET" || url.search || !declaration) {
        unknownRequests++;
        return new Response("Unknown declaration", { status: 404 });
      }
      // No request path ever becomes a filesystem read. The table contains only
      // realpath-checked declarations with immutable prevalidated input bytes.
      return new Response(new Uint8Array(declaration.bytes), {
        headers: { "content-type": "application/typescript", "cache-control": "no-store" },
      });
    });
    // The owned random directory name also prevents reuse of Deno's URL cache
    // if the OS eventually allocates a previously used ephemeral port.
    const origin = "http://127.0.0.1:" + server.addr.port + "/" +
      encodeURIComponent(temp.slice(temp.lastIndexOf("/") + 1)) + "/";
    report.external_origin = origin;
    const external = (path: string): string => {
      assertInside(path, installed);
      const url = new URL(relative(root, path).split("/").map(encodeURIComponent).join("/"), origin);
      return url.href;
    };
    const identities = new Map<string, string>();
    for (const declaration of declarations.values()) {
      const remote = external(declaration.path);
      served.set(new URL(remote).pathname, declaration);
      identities.set(remote, toFileUrl(declaration.path).href);
    }
    for (const path of snapshots.keys()) identities.set(toFileUrl(path).href, toFileUrl(path).href);
    for (const seed of seeds) {
      const scope = scopes[seed.from] ??= {};
      const target = external(seed.to);
      requireCondition(!scope[seed.specifier] || scope[seed.specifier] === target, "Conflicting native seed mappings");
      scope[seed.specifier] = target;
    }
    for (const edge of edges) {
      const source = external(edge.from);
      // Absolute URL keys are required for relative specifiers in scoped maps.
      const key = edge.specifier.startsWith(".") || edge.specifier.startsWith("/")
        ? new URL(edge.specifier, source).href
        : edge.specifier;
      (scopes[source] ??= {})[key] = external(edge.to);
    }
    const fixtures = {
      good:
        'import type { Observable } from "rxjs";\n/** A documented stream. */\nexport interface Good {\n/** Values. */\nvalues: Observable<string>;\n}\n',
      private:
        'import type { Observable } from "rxjs";\ninterface Hidden { value: string; }\n/** A documented stream. */\nexport interface Bad {\n/** Values. */\nvalues: Observable<Hidden>;\n}\n',
      "private-import":
        'import type { Observable } from "rxjs";\nimport type { Internal } from "./internal.ts";\n/** Public stream. */\nexport interface Leak {\n/** Values. */\nvalues: Observable<Internal>;\n}\n',
      undocumented: 'export function undocumented(): string { return "value"; }\n',
    };
    const internalSource =
      "/** Internal dependency. */\nexport interface Internal {\n/** Value. */\nvalue: string;\n}\n";
    Deno.writeTextFileSync(join(temp, "internal.ts"), internalSource);
    snapshots.set(join(temp, "internal.ts"), new TextEncoder().encode(internalSource));
    const rx = [...declarations.values()].find((declaration) =>
      declaration.identity.startsWith("rxjs@") && declaration.path.endsWith("/dist/types/index.d.ts")
    );
    requireCondition(rx, "Observable control dependency absent");
    for (const [name, source] of Object.entries(fixtures)) {
      const path = join(temp, name + ".ts");
      Deno.writeTextFileSync(path, source);
      snapshots.set(path, new TextEncoder().encode(source));
      scopes[toFileUrl(path).href] = { rxjs: external(rx.path) };
    }
    const importMap = join(temp, "import-map.json");
    const mapText = JSON.stringify({ imports: {}, scopes });
    Deno.writeTextFileSync(importMap, mapText);
    snapshots.set(importMap, new TextEncoder().encode(mapText));
    const graphFlags = [
      "--config",
      join(root, "deno.json"),
      "--import-map",
      importMap,
      "--allow-import=127.0.0.1:" + server.addr.port,
      "--no-lock",
      "--node-modules-dir=manual",
    ];
    const lint = await run("effective seven-root native lint", ["doc", "--lint", ...graphFlags, ...roots], root, true);
    assertNativeResult(lint);
    requireCondition(/Checked 7 files\b/.test(lint.stderr + lint.stdout), "Seven-root lint proof missing");
    report.effective_lint = {
      status: "passed",
      exit_code: lint.code,
      stderr: lint.stderr,
      command: commands.at(-1)?.command,
    };
    // deno_doc bypasses import maps for npm triple-slash path references, emitting
    // incomplete-graph warnings even with file-only mappings. Compare a complete
    // local file graph using temporary exact-byte snapshots. Independently proven
    // frozen native/npm resolutions choose every installed declaration; only
    // snapshot/remote module URL identities differ between comparison graphs.
    const snapshotDirectory = join(temp, "native-declarations");
    Deno.mkdirSync(snapshotDirectory);
    const nativeFiles = new Map<string, string>();
    const comparisonManifest: {
      installed: string;
      snapshot: string;
      installed_sha256: string;
      snapshot_sha256: string;
    }[] = [];
    for (const declaration of declarations.values()) {
      const path = join(snapshotDirectory, nativeFiles.size + ".d.ts");
      Deno.writeFileSync(path, declaration.bytes);
      const copy = Deno.readFileSync(path);
      assertByteIdentity(declaration.bytes, copy);
      snapshots.set(path, declaration.bytes);
      const url = toFileUrl(path).href;
      nativeFiles.set(declaration.path, url);
      identities.set(url, toFileUrl(declaration.path).href);
      comparisonManifest.push({
        installed: declaration.path,
        snapshot: path,
        installed_sha256: await sha256(declaration.bytes),
        snapshot_sha256: await sha256(copy),
      });
    }
    report.comparison_byte_manifest = comparisonManifest;
    report.url_identities = [...identities];
    const nativeMap = join(temp, "native-reference-import-map.json");
    const nativeScopes: Record<string, Record<string, string>> = {};
    for (const seed of seeds) (nativeScopes[seed.from] ??= {})[seed.specifier] = nativeFiles.get(seed.to)!;
    for (const edge of edges) {
      const source = nativeFiles.get(edge.from)!;
      const key = edge.specifier.startsWith(".") || edge.specifier.startsWith("/")
        ? new URL(edge.specifier, source).href
        : edge.specifier;
      (nativeScopes[source] ??= {})[key] = nativeFiles.get(edge.to)!;
    }
    const nativeMapText = JSON.stringify({ imports: {}, scopes: nativeScopes });
    Deno.writeTextFileSync(nativeMap, nativeMapText);
    snapshots.set(nativeMap, new TextEncoder().encode(nativeMapText));
    report.native_reference_mappings = nativeReferences;
    const comparisonGraph = checkNativeGraph(
      await run("file comparison type graph", [
        "info",
        "--json",
        "--config",
        join(root, "deno.json"),
        "--import-map",
        nativeMap,
        "--node-modules-dir=none",
        "--lock",
        join(root, "deno.lock"),
        "--frozen-lockfile",
        roots[0],
      ]),
    );
    const unexpectedInstalled = comparisonGraph.modules.filter((module) => module.specifier.includes("/node_modules/"));
    requireCondition(
      !unexpectedInstalled.length,
      "File comparison retained npm path: " + JSON.stringify(unexpectedInstalled.slice(0, 1)),
    );
    report.comparison_graph = {
      modules: comparisonGraph.modules.length,
      original_npm_paths: unexpectedInstalled.length,
    };
    const nativeDoc = await run("native public documentation JSON (exact-byte local declaration snapshots)", [
      "doc",
      "--json",
      ...nativeFlags.filter((flag) => flag !== "--node-modules-dir=manual"),
      "--node-modules-dir=none",
      "--no-npm",
      "--import-map",
      nativeMap,
      ...roots,
    ]);
    const projectedDoc = await run("projected public documentation JSON", ["doc", "--json", ...graphFlags, ...roots]);
    requireCondition(!/\bwarning\b/i.test(nativeDoc.stderr), "Native documentation warning: " + nativeDoc.stderr);
    assertNativeResult({ ...nativeDoc, stdout: "" });
    assertNativeResult({ ...projectedDoc, stdout: "" });
    const nativeDocument = JSON.parse(nativeDoc.stdout);
    const projectedDocument = JSON.parse(projectedDoc.stdout);
    requireCondition(
      documentsEqual(nativeDocument, projectedDocument, identities),
      "Public documentation JSON differs",
    );
    report.documentation = {
      deeply_equal: true,
      normalization: "exact module URL identities only",
      native_sha256: await sha256(new TextEncoder().encode(nativeDoc.stdout)),
      projected_sha256: await sha256(new TextEncoder().encode(projectedDoc.stdout)),
    };
    const controls: Record<string, NativeResult> = {};
    for (const name of Object.keys(fixtures)) {
      controls[name] = await run(
        "local control " + name + (name === "good" ? " (positive)" : " (expected native failure)"),
        ["doc", "--lint", ...graphFlags, join(temp, name + ".ts")],
        root,
        true,
      );
    }
    assertControls(controls);
    report.controls = controls;
    const manifest: {
      path: string;
      identity: string;
      bytes: number;
      installed_sha256: string;
      served_sha256: string;
    }[] = [];
    // Fetch every served declaration, independently comparing the response bytes
    // with the snapshotted installed input. Sequential requests keep resources bounded.
    for (const declaration of declarations.values()) {
      requireCondition(!failed, "Validator deadline exceeded");
      const abort = new AbortController();
      const timer = setTimeout(() => abort.abort(), 5000);
      let bytes: Uint8Array;
      try {
        const response = await fetch(external(declaration.path), { signal: abort.signal });
        requireCondition(response.ok, "Served declaration missing");
        bytes = new Uint8Array(await response.arrayBuffer());
      } finally {
        clearTimeout(timer);
      }
      assertByteIdentity(declaration.bytes, bytes);
      assertInside(Deno.realPathSync(declaration.path), installed);
      const hash = await sha256(declaration.bytes);
      manifest.push({
        path: declaration.path,
        identity: declaration.identity,
        bytes: declaration.bytes.length,
        installed_sha256: hash,
        served_sha256: await sha256(bytes),
      });
    }
    requireCondition(unknownRequests === 0, "Unknown external graph request");
    const snapshotManifest: { path: string; sha256: string }[] = [];
    for (const [path, bytes] of snapshots) {
      requireCondition(Deno.realPathSync(path) === path, "Input realpath changed");
      assertByteIdentity(bytes, Deno.readFileSync(path));
      snapshotManifest.push({ path, sha256: await sha256(bytes) });
    }
    requireCondition(!failed, "Validator deadline exceeded");
    report.byte_manifest = manifest;
    report.input_manifest = snapshotManifest;
    report.unknown_requests = unknownRequests;
    report.counts = {
      declarations: declarations.size,
      declaration_edges: edges.length,
      native_bare_checks: resolutions.length,
      owning_package_groups: bareGroups.size,
      locked_identities: (report.identities as string[]).length,
    };
    report.status = "passed";
    console.log(
      "Native documentation gate passed: seven roots, complete byte/type/document parity, four local controls.",
    );
  } catch (error) {
    failed = error;
    report.failure = error instanceof Error ? error.message : String(error);
    report.status = "failed";
  } finally {
    clearTimeout(deadline);
    for (const child of children) {
      try {
        child.kill("SIGKILL");
      } catch { /* Already exited. */ }
      await child.status;
    }
    if (server) await server.shutdown();
    assertInside(Deno.realPathSync(temp), artifacts);
    Deno.removeSync(temp, { recursive: true });
    report.seconds = (performance.now() - started) / 1000;
    report.cleaned_up = true;
    if (logPath) Deno.writeTextFileSync(logPath, logs.join(""));
    if (reportPath) Deno.writeTextFileSync(reportPath, JSON.stringify(report, null, 2) + "\n");
  }
  if (failed) throw failed;
}

if (import.meta.main) {
  try {
    await runDocumentationLint(Deno.args);
  } catch (error) {
    console.error(error);
    Deno.exitCode = 1;
  }
}
