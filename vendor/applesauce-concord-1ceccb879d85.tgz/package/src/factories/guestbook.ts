// CORD-02 §5 Guestbook rumor factories: joins/leaves, kicks, and refounder
// snapshots. Each builds an unsigned rumor template; sealing/wrapping is done by
// ../stream.ts.

import { blankEventTemplate, EventFactory } from "applesauce-core/factories";
import { JOIN_LEAVE_KIND, type JoinLeaveVerb, KICK_KIND, SNAPSHOT_CHUNK, SNAPSHOT_KIND } from "../helpers/guestbook.ts";
import { splitTime } from "../helpers/stream.ts";
import { includeMs } from "../operations/channel.ts";
import {
  includeInviteAttribution,
  includeKickTarget,
  includeSnapshotChunk,
  setJoinLeave,
} from "../operations/guestbook.ts";

/** Options for building a join/leave rumor. */
export interface JoinLeaveOptions {
  /** Millisecond timestamp (defaults to now). */
  ms?: number;
  /** Invite attribution for a join (CORD-05). */
  invite?: { creator: string; label?: string };
}

/** A factory for kind 3306 join/leave rumors (CORD-02 §5). */
export class JoinLeaveFactory extends EventFactory<typeof JOIN_LEAVE_KIND> {
  /** Builds a join or leave rumor, carrying an ordering time and, for a join, its invite attribution. */
  static create(verb: JoinLeaveVerb, opts?: JoinLeaveOptions): JoinLeaveFactory {
    let factory = new JoinLeaveFactory((res) => res(blankEventTemplate(JOIN_LEAVE_KIND)));
    factory = factory.verb(verb).ms(opts?.ms);
    if (opts?.invite) factory = factory.invite(opts.invite.creator, opts.invite.label);
    return factory;
  }

  /** Sets the join/leave verb as this rumor's content (CORD-02 §5) */
  verb(verb: JoinLeaveVerb): this {
    return this.chain(setJoinLeave(verb));
  }

  /** Adds the millisecond-resolution ordering remainder (CORD-02 §4) */
  ms(ms?: number): this {
    return this.chain(includeMs(ms));
  }

  /** Attributes a join to the invite link that produced it (CORD-05) */
  invite(creator: string, label?: string): this {
    return this.chain(includeInviteAttribution(creator, label));
  }
}

/** A factory for kind 3309 kick rumors (CORD-02 §5). */
export class KickFactory extends EventFactory<typeof KICK_KIND> {
  /** Builds a kick rumor targeting `member`, optionally carrying the actor's `vac` authority proof. */
  static create(member: string, vac?: [string, string, string], ms?: number): KickFactory {
    return new KickFactory((res) => res(blankEventTemplate(KICK_KIND))).ms(ms).target(member, vac);
  }

  /** Adds the millisecond-resolution ordering remainder (CORD-02 §4) */
  ms(ms?: number): this {
    return this.chain(includeMs(ms));
  }

  /** Points this kick at its target, optionally carrying the actor's `vac` proof */
  target(member: string, vac?: [string, string, string]): this {
    return this.chain(includeKickTarget(member, vac));
  }
}

/** A factory for a single chunk of a kind 3312 refounder snapshot (CORD-02 §5). */
export class SnapshotFactory extends EventFactory<typeof SNAPSHOT_KIND> {
  /** Builds chunk `index` of `count` for the snapshot `snapshotIdHex`. Prefer
   *  {@link buildSnapshotFactories}, which chunks a memberlist and shares one instant across
   *  every chunk. */
  static create(
    members: string[],
    snapshotIdHex: string,
    index: number,
    count: number,
    time: { created_at: number; ms: number } = splitTime(),
  ): SnapshotFactory {
    return new SnapshotFactory((res) => res(blankEventTemplate(SNAPSHOT_KIND))).chunk(
      members,
      snapshotIdHex,
      index,
      count,
      time,
    );
  }

  /** Fills one chunk of the snapshot: present members + the `snap` tag */
  chunk(
    members: string[],
    snapshotIdHex: string,
    index: number,
    count: number,
    time: { created_at: number; ms: number } = splitTime(),
  ): this {
    return this.chain(includeSnapshotChunk(members, snapshotIdHex, index, count, time));
  }
}

/**
 * Refounder-signed snapshot factories seeding a new epoch's Guestbook: present
 * members only, chunked at {@link SNAPSHOT_CHUNK}, all chunks sharing one
 * snapshot id and one timestamp (CORD-02 §5, TIME-02/D-08). The clock is read
 * exactly once here via {@link splitTime} and the resulting `{ created_at,
 * ms }` pair is threaded into every chunk's `SnapshotFactory.create` call, so
 * all N chunks of one snapshot share one instant and can never straddle a
 * second boundary.
 */
export function buildSnapshotFactories(
  members: string[],
  snapshotIdHex: string,
  nowMs: number = Date.now(),
): SnapshotFactory[] {
  const chunks: string[][] = [];
  for (let i = 0; i < members.length; i += SNAPSHOT_CHUNK) chunks.push(members.slice(i, i + SNAPSHOT_CHUNK));
  if (chunks.length === 0) chunks.push([]);
  const n = chunks.length;
  const time = splitTime(nowMs);
  return chunks.map((chunk, i) => SnapshotFactory.create(chunk, snapshotIdHex, i + 1, n, time));
}
