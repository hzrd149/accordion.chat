// A Concord channel message is now built with the applesauce-common
// `ChatMessageFactory` (kind 9, NIP-C7), bound to a channel with `bindToChannel`,
// and its imeta tags decorated with per-file encryption keys by
// `includeMediaEncryption`. These tests exercise that composition end to end.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { ChatMessageFactory } from "applesauce-common/factories";
import { PrivateKeySigner } from "applesauce-signers";
import { hexToBytes } from "@noble/hashes/utils.js";

import { kinds } from "applesauce-core/helpers/event";
import { bindToChannel, includeMediaEncryption } from "../../operations/channel.ts";
import { checkChatBinding } from "../../helpers/chat.ts";
import { controlGroupKey } from "../../helpers/crypto.ts";
import { parseImeta } from "../../helpers/imeta.ts";
import { sealRumor, toRumor, wrapSeal } from "../../operations/gift-wrap.ts";
import { decodeWrap } from "../../helpers/gift-wrap.ts";

describe("channel message composition", () => {
  it("binds channel/epoch, p-tags mentions, emoji-tags shortcodes", async () => {
    const emoji = { shortcode: "cat", url: "https://x/cat.png" };
    const message = await ChatMessageFactory.create(`hi nostr:${npub()} :cat:`, { emojis: [emoji] });
    const t = await bindToChannel("chan", 2)(message);

    expect(t.kind).toBe(kinds.ChatMessage);
    expect(checkChatBinding(t.tags, "chan", 2)).toBe(true);
    expect(t.tags.some((tag) => tag[0] === "p")).toBe(true);
    expect(t.tags).toContainEqual(["emoji", "cat", "https://x/cat.png"]);
  });

  it("adds a q reply tag, imeta tags, and per-file encryption", async () => {
    const message = await ChatMessageFactory.create("yo")
      .replyTo({ id: "e1", author: "a1" })
      .attachments([{ url: "https://x/1", type: "image/png" }]);
    let t = await bindToChannel("chan", 0)(message);
    t = await includeMediaEncryption([
      { url: "https://x/1", algorithm: "aes-gcm", key: "a".repeat(64), nonce: "b".repeat(32) },
    ])(t);

    expect(t.tags).toContainEqual(["q", "e1", "", "a1"]);
    const imeta = t.tags.find((tag) => tag[0] === "imeta")!;
    expect(imeta).toEqual([
      "imeta",
      "url https://x/1",
      "m image/png",
      "encryption-algorithm aes-gcm",
      `decryption-key ${"a".repeat(64)}`,
      `decryption-nonce ${"b".repeat(32)}`,
    ]);
    const attachment = parseImeta(t.tags).get("https://x/1")!;
    expect(attachment.encryption).toEqual({
      algorithm: "aes-gcm",
      key: "a".repeat(64),
      nonce: "b".repeat(32),
    });
    expect(attachment.encryptionError).toBeUndefined();
  });

  it("round-trips through the envelope", async () => {
    const author = new PrivateKeySigner(generateSecretKey());
    const authorPub = await author.getPublicKey();
    const key = controlGroupKey(hexToBytes("11".repeat(32)), hexToBytes("22".repeat(32)), 0);
    const template = await bindToChannel("chan", 0)(await ChatMessageFactory.create("hello"));
    // Build the rumor, then seal + wrap it onto the plane via the composable ops.
    const rumor = await toRumor(author)(template);
    const wrap = await wrapSeal(key.sk, key.convKey)(await sealRumor(key.convKey, author)(rumor));
    const dec = decodeWrap(wrap, key.convKey);
    expect(dec).not.toBeNull();
    expect(dec!.author).toBe(authorPub);
    expect(dec!.rumor.id).toBe(rumor.id);
    expect(dec!.rumor.content).toBe("hello");
    expect(dec!.rumor.content).toBe("hello");
    expect(checkChatBinding(dec!.rumor.tags, "chan", 0)).toBe(true);
  });
});

/** A throwaway npub for mention testing. */
function npub(): string {
  return "npub1sg6plzptd64u62a878hep2kev88swjh3tw00gjsfl8f237lmu63q0uf63m";
}
