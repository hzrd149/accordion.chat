// Chat Plane edit rumor factory (CORD-03 §3). Builds an unsigned kind 3302 edit
// rumor by chaining the operations in ../operations/edit.ts onto a blank
// template. The rumor is sealed + wrapped later by ../stream.ts; this factory
// never signs. Channel binding is applied at publish time via `bindToChannel`.

import { blankEventTemplate, EventFactory } from "applesauce-core/factories";
import { EDIT_KIND } from "../helpers/edit.ts";
import { includeEditTarget } from "../operations/edit.ts";

/** A factory for kind 3302 chat edits (CORD-03 §3). */
export class EditFactory extends EventFactory<typeof EDIT_KIND> {
  /** Builds an edit rumor replacing the text of message `targetId` with `newText`. */
  static create(targetId: string, newText: string): EditFactory {
    return new EditFactory((res) => res(blankEventTemplate(EDIT_KIND))).content(newText).target(targetId);
  }

  /** Points this edit at the message it replaces (`e` tag) */
  target(id: string): this {
    return this.chain(includeEditTarget(id));
  }
}
