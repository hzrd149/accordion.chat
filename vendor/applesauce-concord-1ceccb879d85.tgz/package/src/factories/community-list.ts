// CORD-02 §8: self-encrypted membership documents keyed by community_id.

import { blankEventTemplate, EventFactory, toEventTemplate } from "applesauce-core/factories";
import { isKind, type NostrEvent } from "applesauce-core/helpers";
import { COMMUNITY_LIST_KIND } from "../helpers/community-list.ts";
import type { CommunityListCommunity, JoinMaterial } from "../types.ts";
import {
  type CommunityListOperation,
  joinCommunity,
  leaveCommunity,
  modifyCommunityList,
  refreshCommunity,
} from "../operations/community-list.ts";
// Ensures kind 13302 encrypts with NIP-44 (self-encryption).
import "../helpers/register.ts";

/** A factory for the kind 13302 Community List (CORD-02 §8). */
export class CommunityListFactory extends EventFactory<typeof COMMUNITY_LIST_KIND> {
  /** Creates a fresh Community List factory seeded with an empty, self-encrypted document */
  static create(): CommunityListFactory {
    return new CommunityListFactory((res) => res(blankEventTemplate(COMMUNITY_LIST_KIND))).pipe();
  }

  /** Creates a factory that modifies an existing Community List event, merging changes into its contents */
  static modify(event: NostrEvent): CommunityListFactory {
    if (!isKind(event, COMMUNITY_LIST_KIND)) throw new Error("Expected a Concord community list event");
    return new CommunityListFactory((res) => res(toEventTemplate(event)));
  }

  /** Joins or refreshes a membership (community_id-keyed merge, resurrects a re-join) */
  join(community: CommunityListCommunity): CommunityListFactory {
    return this.pipe(joinCommunity(community));
  }

  /** Leaves a community by tombstoning the membership — a later join can still resurrect it */
  leave(communityId: string, removedAt: number = Date.now()): CommunityListFactory {
    return this.pipe(leaveCommunity(communityId, removedAt));
  }

  /** Replaces a membership's `current` snapshot in place (a caught-up rename or channel-key addition) */
  refresh(current: JoinMaterial): CommunityListFactory {
    return this.pipe(refreshCommunity(current));
  }

  /**
   * Chains one or more community list operations into a single
   * decrypt-merge-re-encrypt over the self-encrypted contents, wiring in the
   * chain's signer. Operations are applied left-to-right.
   */
  pipe(...operations: CommunityListOperation[]): CommunityListFactory {
    const apply: CommunityListOperation = (communities, tombstones) => {
      let state = { communities, tombstones };
      for (const operation of operations) state = operation(state.communities, state.tombstones);
      return state;
    };
    const result = this.chain((draft) => modifyCommunityList(apply, result.signer)(draft)) as CommunityListFactory;
    return result;
  }
}
