// CORD-04 Control-Plane edition hashing.
//
// An edition is a kind 3308 rumor carrying the edition machinery in tags (built
// by ../operations/control.ts + ../factories/control.ts). It rides a PLAINTEXT
// seal (kind 20014) so a Refounding can re-wrap the signed edition into a new
// epoch with its signature intact.

import { hexToBytes, utf8ToBytes } from "@noble/hashes/utils.js";
import { isHexKey } from "applesauce-core/helpers/string";
import { editionHash } from "./crypto.ts";
import type { DecodedEvent } from "../types.ts";

/** The fields an edition's hash is computed over. `vac` is authority machinery
 *  that rides the rumor's tags rather than the hash preimage, which is why
 *  {@link computeEditionHash} takes an `Omit<EditionInput, "vac">`. */
export interface EditionInput {
  /** The entity's value-schema kind — which document this edition carries. */
  vsk: number;
  /** The entity coordinate this edition versions: 32-byte hex. */
  eid: string;
  /** This edition's version, counting from 1. Highest wins, downgrades refused. */
  version: number;
  /** The previous edition_hash, hex. Omitted on the first edition, which is what
   *  roots the per-entity hash chain. */
  prevHash?: string;
  /** The entity's state as a JSON string. Hashed verbatim, so re-serializing the
   *  same state differently yields a different edition hash. */
  content: string;
  /** The author's Grant citation `[eid, version, edition hash]` — omitted for the
   *  owner, whose authority the community_id already proves. */
  vac?: [string, string, string];
}

/** Compute an edition's hash — what the next edition's `ep` will cite. */
export function computeEditionHash(input: Omit<EditionInput, "vac">): string {
  return editionHash(
    hexToBytes(input.eid),
    input.version,
    input.prevHash ? hexToBytes(input.prevHash) : undefined,
    utf8ToBytes(input.content),
  );
}

/** A citation of one exact edition: `[eid, version, edition_hash]`. All three are
 *  strings because the citation travels as a `vac` tag's values. */
export type EditionPin = [eid: string, version: string, hash: string];

/** The outcome of resolving an {@link EditionPin}. Total by construction — an
 *  unresolvable citation is classified rather than thrown, so one bad citation
 *  cannot abort a fold. `missing` may still resolve once more history syncs;
 *  `mismatch` means that version exists but hashes differently, which is why the
 *  two are distinguished rather than collapsed into one failure. */
export type EditionPinResult =
  | { kind: "matched"; edition: DecodedEvent }
  | { kind: "missing"; eid: string; version: number }
  | { kind: "mismatch"; eid: string; version: number }
  | { kind: "malformed" };

/** Resolve an exact CORD-04 `(coordinate, version, edition_hash)` citation. */
export function resolveEditionPin(editions: Iterable<DecodedEvent>, pin: EditionPin): EditionPinResult {
  if (!Array.isArray(pin) || pin.length !== 3) return { kind: "malformed" };
  const [eid, versionText, expectedHash] = pin;
  if (
    typeof eid !== "string" || !isHexKey(eid) || typeof versionText !== "string" ||
    !/^[1-9][0-9]*$/.test(versionText) || typeof expectedHash !== "string" || !isHexKey(expectedHash)
  ) return { kind: "malformed" };
  const version = Number(versionText);
  if (!Number.isSafeInteger(version) || version < 1) return { kind: "malformed" };

  let foundVersion = false;
  for (const edition of editions) {
    if (
      typeof edition.rumor.content !== "string" || !Array.isArray(edition.rumor.tags) ||
      !edition.rumor.tags.every((t) => Array.isArray(t) && t.every((v) => typeof v === "string"))
    ) continue;
    const tag = (name: string) => edition.rumor.tags.find((t) => t[0] === name)?.[1];
    if (edition.rumor.kind !== 3308 || tag("eid")?.toLowerCase() !== eid.toLowerCase()) continue;
    const candidateVersionText = tag("ev") ?? "1";
    if (!/^[1-9][0-9]*$/.test(candidateVersionText) || Number(candidateVersionText) !== version) continue;
    foundVersion = true;
    const prevHash = tag("ep");
    if (prevHash !== undefined && !isHexKey(prevHash)) continue;
    const actualHash = computeEditionHash({
      vsk: Number(tag("vsk") ?? 0),
      eid,
      version,
      prevHash,
      content: edition.rumor.content,
    });
    if (actualHash === expectedHash.toLowerCase()) return { kind: "matched", edition };
  }
  return foundVersion ? { kind: "mismatch", eid, version } : { kind: "missing", eid, version };
}
