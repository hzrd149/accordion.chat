import { hexToBytes } from "@noble/hashes/utils.js";
import { grantLocator } from "./crypto.ts";
import { type CommunityState, VSK } from "../types.ts";

/** CORD-04 §§1, 3, 5: unresolved target support is not a roleless standing. */
export function targetSupportReady(
  grantReady: boolean,
  roleIds: readonly string[] | undefined,
  roleReady: (id: string) => boolean,
): boolean {
  return grantReady && (roleIds ?? []).every(roleReady);
}

/** Check selected target support, preserving verified empty and absent Grants. */
export function stateTargetSupportReady(state: CommunityState, member: string): boolean {
  if (member === state.material.owner) return true;
  const verification = state.controlVerification;
  if (!verification || verification.communityId !== state.material.community_id) return false;
  const eid = grantLocator(hexToBytes(state.material.community_id), member);
  const ids = state.grants.get(member);
  return targetSupportReady(
    !verification.suspended.has(eid) && (ids === undefined || verification.heads.get(eid)?.vsk === VSK.GRANT),
    ids,
    (id) =>
      !verification.suspended.has(id) && verification.heads.get(id)?.vsk === VSK.ROLE &&
      state.roles.some((role) => role.role_id === id),
  );
}
