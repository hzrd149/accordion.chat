// CORD-02 §6 UTF-8 caps: names 64 bytes, descriptions 10000 bytes.
// Enforce on writes only; rejecting over-cap fields during folds could make
// existing channels unavailable. Read values remain unchanged for convergence.

/** The uniform 64-byte name cap (CORD-02 §6) — communities, channels, and roles all share it. */
export const NAME_MAX_BYTES = 64;

/** The 10000-byte description cap (CORD-02 §6). */
export const DESCRIPTION_MAX_BYTES = 10000;

/**
 * UTF-8 byte length of `value`. This is the single reason this module exists:
 * JavaScript's `String.length` counts UTF-16 code units, not bytes, and the
 * spec's caps are stated in bytes — that mismatch is audit finding M17. A
 * 17-character astral string is 68 UTF-8 bytes while its `.length` is 34, so
 * measuring with `.length` would silently admit an over-cap value. There is
 * deliberately no code-unit variant of this function.
 */
export function utf8ByteLength(value: string): number {
  return new TextEncoder().encode(value).length;
}

/**
 * Throw when `value`'s UTF-8 byte length exceeds `maxBytes`. The comparison
 * is strictly greater-than, never greater-than-or-equal: a value of exactly
 * `maxBytes` bytes is legal, because the spec says the field "caps at" that
 * figure — the boundary is exclusive.
 *
 * `field` is a human-readable subject supplied by the caller (e.g. the
 * community name, the community description, the channel name) — the thrown
 * message never carries the offending string itself.
 */
export function assertByteCap(value: string, maxBytes: number, field: string): void {
  const bytes = utf8ByteLength(value);
  if (bytes > maxBytes) throw new Error(`${field} is too large (${bytes} bytes > ${maxBytes}-byte cap)`);
}
