// CORD-06 Rekeys & Refoundings — the 3303 rekey-blob wire codec + rotation fold.
//
// Post-removal secrecy without ratchets: a rotation mints a fresh key at the
// next epoch and delivers it as per-recipient "rekey blobs" (kind 3303, up to
// 120 per event, chunked) at an address derived from the PRIOR secret — so
// every current holder can find it, and a removed member finding no blob for
// their locator across ALL chunks of a COMPLETE rotation knows they're out.
//
// CORD-06 §1: scope_id[32] || epoch_be[8] || new_key[32] is the
// 72-byte channel/legacy prefix. Split base forms append control_pk[32]
// and optionally the staff control_root[32]. The complete fixed-width record
// rides as standard base64 inside pairwise NIP-44, whose signer API uses strings.

import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { schnorr } from "@noble/curves/secp256k1.js";
import { blankEventTemplate } from "applesauce-core/factories";
import type { EventTemplate } from "applesauce-core/helpers/event";
import { controlSignerGroupKey, epochKeyCommitment, recipientLocator } from "./crypto.ts";
import { includeRekeyChunk } from "../operations/rekey.ts";
import type { DecodedEvent } from "../types.ts";

/** Concord rekey blob kind (CORD-06). */
export const REKEY_KIND = 3303;

/** Per-recipient blobs per rekey event (CORD-06 §1). */
export const REKEY_BLOBS_PER_EVENT = 120;

const ZERO32 = new Uint8Array(32);
/** The root-rotation scope id (a Refounding): all-zeroes, never a channel id. */
export const ROOT_SCOPE_HEX: string = "0".repeat(64);

const HEX64 = /^[0-9a-f]{64}$/i;
const DEC = /^\d+$/;
// A diagnostic sample bound, not a protocol limit on complete rotations.
const MISSING_INDEX_DIAGNOSTIC_LIMIT = 128;

function validChunk(index: number, count: number): boolean {
  return Number.isSafeInteger(index) && Number.isSafeInteger(count) && index >= 1 && count >= 1 && index <= count;
}

/** A rotation's scope: one Private Channel, or the community_root (a Refounding). */
export type RekeyScope = { kind: "channel"; channelId: Uint8Array } | { kind: "root" };

/** The 32-byte scope id: the channel id, or all-zeroes for the root. */
export function rekeyScopeId(scope: RekeyScope): Uint8Array {
  return scope.kind === "channel" ? scope.channelId : ZERO32;
}

/** scope_id[32] || epoch_be[8] || new_key[32] — scope and epoch live INSIDE the ciphertext. */
export function encodeWrappedKey(scopeId: Uint8Array, newEpoch: bigint, newKey: Uint8Array): Uint8Array {
  const out = new Uint8Array(72);
  out.set(scopeId, 0);
  new DataView(out.buffer).setBigUint64(32, newEpoch, false);
  out.set(newKey, 40);
  return out;
}

/**
 * Parse + verify a decrypted 72-byte blob against the event's tags: a recipient
 * accepts the key only when the INNER scope and epoch match, which is what makes
 * a blob unspliceable across channels/epochs (CORD-06 §1).
 */
export function decodeWrappedKey(plain: Uint8Array, expectedScopeId: Uint8Array, expectedEpoch: bigint): Uint8Array {
  if (plain.length !== 72) throw new Error(`wrapped key must be 72 bytes, got ${plain.length}`);
  const scopeId = plain.slice(0, 32);
  const epoch = new DataView(plain.buffer, plain.byteOffset).getBigUint64(32, false);
  if (bytesToHex(scopeId) !== bytesToHex(expectedScopeId)) throw new Error("wrapped key scope mismatch");
  if (epoch !== expectedEpoch) throw new Error("wrapped key epoch mismatch");
  return plain.slice(40, 72);
}

/** One complete base capability record, validated at its community/epoch (CORD-06 §1–3; CORD-02 §5). */
export type BaseRekeyMaterial =
  | {
    /** Historical pre-split form. */
    form: "legacy";
    /** Next member read root. */
    community_root: Uint8Array;
    /** Legacy epochs have no independent control address. */
    control_pk?: never;
    /** Legacy epochs have no independent staff root. */
    control_root?: never;
  }
  | {
    /** Split member form with read access only. */
    form: "member";
    /** Next member read root. */
    community_root: Uint8Array;
    /** Valid next x-only control address. */
    control_pk: Uint8Array;
    /** Members receive no staff root. */
    control_root?: never;
  }
  | {
    /** Split staff form with a matching signing root. */
    form: "staff";
    /** Next member read root. */
    community_root: Uint8Array;
    /** Valid next x-only control address. */
    control_pk: Uint8Array;
    /** Staff root validated against the address, community and epoch. */
    control_root: Uint8Array;
  };

function validateBaseEpoch(epoch: bigint): void {
  if (epoch < 0n || epoch > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error("base epoch must be a safe nonnegative integer");
  }
}

function validateControlPoint(pk: Uint8Array): void {
  if (pk.length !== 32) throw new Error("control public key must be 32 bytes");
  schnorr.utils.lift_x(BigInt("0x" + bytesToHex(pk)));
}

/** Emit only the 104-byte member or 136-byte staff base form (CORD-06 §1–3); historical 72-byte bases are read-only. */
export function encodeBaseWrappedKey(
  newEpoch: bigint,
  newRoot: Uint8Array,
  controlPk: Uint8Array,
  controlRoot?: Uint8Array,
): Uint8Array {
  validateBaseEpoch(newEpoch);
  if (newRoot.length !== 32 || (controlRoot !== undefined && controlRoot.length !== 32)) {
    throw new Error("base roots must be 32 bytes");
  }
  validateControlPoint(controlPk);
  const out = new Uint8Array(controlRoot === undefined ? 104 : 136);
  out.set(encodeWrappedKey(ZERO32, newEpoch, newRoot));
  out.set(controlPk, 72);
  if (controlRoot !== undefined) out.set(controlRoot, 104);
  return out;
}

/** Validate a historical 72-byte or split 104/136-byte base record before adoption (CORD-06 §1–3; CORD-02 §5). */
export function decodeBaseWrappedKey(
  plain: Uint8Array,
  expectedEpoch: bigint,
  communityId: Uint8Array,
): BaseRekeyMaterial {
  validateBaseEpoch(expectedEpoch);
  if (communityId.length !== 32) throw new Error("community identity must be 32 bytes");
  if (plain.length !== 72 && plain.length !== 104 && plain.length !== 136) throw new Error("invalid base blob width");
  const community_root = decodeWrappedKey(plain.subarray(0, 72), ZERO32, expectedEpoch);
  if (plain.length === 72) return { form: "legacy", community_root };
  const control_pk = plain.slice(72, 104);
  validateControlPoint(control_pk);
  if (plain.length === 104) return { form: "member", community_root, control_pk };
  const control_root = plain.slice(104, 136);
  if (controlSignerGroupKey(control_root, communityId, Number(expectedEpoch)).pk !== bytesToHex(control_pk)) {
    throw new Error("base control pair mismatch");
  }
  return { form: "staff", community_root, control_pk, control_root };
}

/** Encode bytes as STANDARD base64 — the form a wrapped key rides in
 *  inside the NIP-44 plaintext, because signer `nip44` interfaces carry strings
 *  rather than bytes. Not url-safe: the value never appears in a URL. */
export function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}
/** Decode the STANDARD base64 produced by {@link bytesToBase64}. */
export function base64ToBytes(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** One located, wrapped key. */
export interface RekeyBlob {
  /** Where its recipient finds it (hex of {@link recipientLocator}). */
  locator: string;
  /** NIP-44 ciphertext under the Rotator<->recipient pairwise key (base64 of the scoped record inside). */
  wrapped: string;
}

/** One rotation's machinery, stamped into every chunk's tags by
 *  {@link includeRekeyChunk} — the scope and epochs a recipient checks a decoded
 *  blob against before accepting the key it carries (CORD-06 §1). */
export interface RekeyRotation {
  /** Which key is being replaced: one Private Channel, or the community_root. */
  scope: RekeyScope;
  /** The epoch the newly minted key takes effect at (always `prevEpoch + 1`). */
  newEpoch: bigint;
  /** The epoch of the key being replaced. */
  prevEpoch: bigint;
  /** The epoch-key commitment over the key being replaced (continuity check). */
  prevCommit: string;
  /** The rotator's own Grant citation (CORD-04 `vac`, D-08): `[eid, version, hash]`
   *  of the rotator's Grant edition, proving the authority this rotation acts
   *  under — mirrors `includeKickTarget`/`vacFor`. Omitted for the owner, whose
   *  authority is proven by the community_id itself, never a delegated Grant. */
  vac?: [string, string, string];
}

/**
 * Build the chunked kind 3303 rekey rumors for one rotation (CORD-06 §1): the
 * blobs are split into events of at most {@link REKEY_BLOBS_PER_EVENT}, each
 * stamped with the rotation-machinery tags via {@link includeRekeyChunk}. An
 * empty blob set still yields one (empty) chunk so a COMPLETE rotation is always
 * publishable. Returns unsigned rumor templates for the caller to seal + wrap at
 * the rekey address (../operations/gift-wrap.ts) — building rekey events is
 * plane-agnostic, so it is a plain helper rather than an exposed factory.
 */
export function buildRekeyRumors(
  rotation: RekeyRotation,
  blobs: RekeyBlob[],
  ms: number = Date.now(),
): Promise<EventTemplate>[] {
  const chunks: RekeyBlob[][] = [];
  for (let i = 0; i < blobs.length; i += REKEY_BLOBS_PER_EVENT) chunks.push(blobs.slice(i, i + REKEY_BLOBS_PER_EVENT));
  if (chunks.length === 0) chunks.push([]);
  const n = chunks.length;
  return chunks.map((chunk, i) =>
    Promise.resolve(includeRekeyChunk(rotation, chunk, i + 1, n, ms)(blankEventTemplate(REKEY_KIND)))
  );
}

/** One kind 3303 chunk read back off the wire — the tag machinery plus the blobs
 *  it carries, with the rotator resolved to the seal's real signer (CORD-06 §1). */
export interface ParsedRekey {
  /** The rotator's real pubkey (the seal's signer). */
  rotator: string;
  /** Lowercased 32-byte scope id hex: {@link ROOT_SCOPE_HEX}, or the channel id. */
  scopeIdHex: string;
  /** The epoch the key this rotation carries takes effect at. */
  newEpoch: bigint;
  /** The epoch of the key this rotation replaces. */
  prevEpoch: bigint;
  /** The claimed commitment over the replaced key, checked against the key we
   *  actually hold by {@link checkContinuity}. */
  prevCommit: string;
  /** This chunk's 1-based position within the rotation. */
  chunkIndex: number;
  /** How many chunks the rotation claims in total; a set is COMPLETE only once
   *  all of them are held. */
  chunkCount: number;
  /** The per-recipient blobs this chunk carries (at most
   *  {@link REKEY_BLOBS_PER_EVENT}). */
  blobs: RekeyBlob[];
  /** The rumor's millisecond stamp — the generation marker {@link groupRotations}
   *  uses to notice a resumed rotation mixed into one bucket. */
  ms: number;
  /** The outer kind 1059 wrap's id: the stable per-chunk identity used for
   *  diagnostics and for ordering chunks deterministically. */
  wrapId: string;
  /** The rotator's Grant citation (CORD-04 `vac`, D-08), if the `["vac", eid,
   *  version, hash]` tag is present; absent for the owner (and for a malformed
   *  tag, treated identically to absence). */
  vac?: [string, string, string];
}

/** Why {@link parseRekeyResult} refused a decoded event, named after the tag or
 *  field that failed. Bounded and value-free, so it is safe to log. */
export type RekeyParseReason =
  | "kind"
  | "scope"
  | "new-epoch"
  | "prev-epoch"
  | "prev-commit"
  | "chunk"
  | "content";

/** A total parse outcome: decoders in this layer classify rather than throw, so
 *  a single malformed rekey event can never abort a fold. */
export type ParsedRekeyResult =
  | { kind: "parsed"; value: ParsedRekey }
  | { kind: "malformed"; reason: RekeyParseReason; cause?: unknown };

/** Parse a decoded rekey while retaining a bounded, log-safe failure classification. */
export function parseRekeyResult(d: DecodedEvent): ParsedRekeyResult {
  const r = d.rumor;
  if (r.kind !== REKEY_KIND) return { kind: "malformed", reason: "kind" };
  const get = (name: string) => r.tags.find((t) => t[0] === name);
  const scope = get("scope")?.[1];
  const newEpoch = get("newepoch")?.[1];
  const prevEpoch = get("prevepoch")?.[1];
  const prevCommit = get("prevcommit")?.[1];
  const chunk = get("chunk");
  if (!scope || !HEX64.test(scope)) return { kind: "malformed", reason: "scope" };
  if (!newEpoch || !DEC.test(newEpoch)) return { kind: "malformed", reason: "new-epoch" };
  if (!prevEpoch || !DEC.test(prevEpoch)) return { kind: "malformed", reason: "prev-epoch" };
  if (!prevCommit || !HEX64.test(prevCommit)) return { kind: "malformed", reason: "prev-commit" };
  const chunkIndex = chunk ? Number(chunk[1]) : 1;
  const chunkCount = chunk ? Number(chunk[2]) : 1;
  if (chunk && (!DEC.test(chunk[1] ?? "") || !DEC.test(chunk[2] ?? ""))) {
    return { kind: "malformed", reason: "chunk" };
  }
  if (!validChunk(chunkIndex, chunkCount)) {
    return { kind: "malformed", reason: "chunk" };
  }
  let blobs: RekeyBlob[];
  try {
    const parsed = JSON.parse(r.content) as RekeyBlob[];
    blobs = Array.isArray(parsed)
      ? parsed.filter((b) => b && typeof b.locator === "string" && typeof b.wrapped === "string")
      : [];
  } catch (cause) {
    return { kind: "malformed", reason: "content", cause };
  }
  const vacTag = get("vac");
  const vac: [string, string, string] | undefined = vacTag && vacTag[1] && vacTag[2] && vacTag[3]
    ? [vacTag[1], vacTag[2], vacTag[3]]
    : undefined;
  return {
    kind: "parsed",
    value: {
      rotator: d.author,
      scopeIdHex: scope.toLowerCase(),
      newEpoch: BigInt(newEpoch),
      prevEpoch: BigInt(prevEpoch),
      prevCommit: prevCommit.toLowerCase(),
      chunkIndex,
      chunkCount,
      blobs,
      ms: d.ms,
      wrapId: d.wrapId,
      vac,
    },
  };
}

/** Compatibility parser for callers that only need valid candidates. */
export function parseRekey(d: DecodedEvent): ParsedRekey | null {
  const result = parseRekeyResult(d);
  return result.kind === "parsed" ? result.value : null;
}

/**
 * Group parsed rekey chunks into complete rotations. Chunks correlate by
 * (rotator, scope, newepoch, prevcommit) so two Rotators concurrently rekeying
 * the same epoch never merge (CORD-06 §2). A rotation is COMPLETE only when all
 * `n` chunks are held — a missing chunk is never a removal.
 */
export interface RekeyRotationSet {
  /** Stable public identity derived only from the correlation tuple. */
  candidateId: string;
  /** The rotator's real pubkey. Authority is checked against the roster, never
   *  against possession of the prior key. */
  rotator: string;
  /** Lowercased 32-byte scope id hex, shared by every chunk in this bucket. */
  scopeIdHex: string;
  /** The epoch this rotation's new key takes effect at. */
  newEpoch: bigint;
  /** The epoch of the replaced key. The lowest claimed across the bucket wins,
   *  and any disagreement is itself recorded as a `prev-epoch` inconsistency. */
  prevEpoch: bigint;
  /** The commitment over the replaced key — part of the correlation tuple. */
  prevCommit: string;
  /** The rotation's total chunk count: the HIGHEST claimed across the bucket, so
   *  a stale generation claiming fewer cannot complete the set on its own. */
  chunkCount: number;
  /** chunkIndex → chunk. */
  chunks: Map<number, ParsedRekey>;
  /** The rotator's Grant citation (CORD-04 `vac`, D-08), captured from the FIRST
   *  chunk that created this bucket — mirrors `chunkCount`'s capture-at-creation
   *  convention. Cross-chunk vac agreement is out of scope (a mismatch doesn't
   *  independently ride the `consistent` flag). */
  vac?: [string, string, string];
  /**
   * False when chunks correlated into this bucket disagree on `chunkCount` (n)
   * or `prevEpoch` — a resumed rotation minting a different keep-list (and thus
   * a different n) correlates on the SAME (rotator, scope, newEpoch, prevCommit)
   * key (D-02, unchanged), so agreement must be checked across all chunks
   * instead of trusting whichever chunk arrived first (ROTATE-10/11).
   */
  consistent: boolean;
  /** The first at most 128 absent indexes for a consistent partial set. This
   * diagnostic sample never determines completeness or limits valid group size. */
  missingIndexes: number[];
  /** Bounded fields that disagree across chunks; safe for diagnostics. */
  inconsistencies: RekeyInconsistencyReason[];
  /** True only when the set is `consistent` AND all distinct indexes are held. A missing
   *  chunk is never a removal (CORD-06 §2). */
  complete: boolean;
}

/** Which correlated-but-disagreeing field made a bucket inconsistent. Bounded
 *  and value-free, so it is safe to log (ROTATE-10/11). */
export type RekeyInconsistencyReason = "chunk-count" | "prev-epoch" | "vac" | "generation";

/**
 * Bucket parsed chunks into candidate rotations by the (rotator, scope,
 * newEpoch, prevCommit) correlation tuple (CORD-06 §2), then settle each
 * bucket's `consistent`/`complete` flags. Two Rotators racing the same epoch
 * never merge; a resumed rotation that reuses the same tuple is surfaced as an
 * inconsistency instead of being allowed to complete on a stale generation.
 */
export function groupRotations(parsed: ParsedRekey[]): RekeyRotationSet[] {
  const byKey = new Map<string, RekeyRotationSet>();
  const chunkCounts = new Map<string, Set<number>>();
  const prevEpochs = new Map<string, Set<bigint>>();
  const vacs = new Map<string, Set<string>>();
  const generations = new Map<string, Set<number>>();
  for (const p of [...parsed].sort((a, b) => a.wrapId.localeCompare(b.wrapId))) {
    // Exported callers may bypass the parser. Ignore malformed numeric metadata
    // before it can affect a bucket's count, completeness or diagnostics.
    if (!validChunk(p.chunkIndex, p.chunkCount)) continue;
    const key = `${p.rotator}:${p.scopeIdHex}:${p.newEpoch}:${p.prevCommit}`;
    let set = byKey.get(key);
    if (!set) {
      byKey.set(
        key,
        set = {
          rotator: p.rotator,
          candidateId: key,
          scopeIdHex: p.scopeIdHex,
          newEpoch: p.newEpoch,
          prevEpoch: p.prevEpoch,
          prevCommit: p.prevCommit,
          chunkCount: p.chunkCount,
          chunks: new Map(),
          vac: p.vac,
          consistent: true,
          missingIndexes: [],
          inconsistencies: [],
          complete: false,
        },
      );
      chunkCounts.set(key, new Set());
      prevEpochs.set(key, new Set());
      vacs.set(key, new Set());
      generations.set(key, new Set());
    }
    chunkCounts.get(key)!.add(p.chunkCount);
    prevEpochs.get(key)!.add(p.prevEpoch);
    vacs.get(key)!.add(JSON.stringify(p.vac ?? null));
    generations.get(key)!.add(p.ms);
    // Keep every chunk — even one from a disagreeing generation — so the
    // disagreement is detectable below. Silently dropping a disagreeing chunk
    // (the old `if (p.chunkCount === set.chunkCount)` guard) is exactly what let
    // a stale first-arriving generation complete on its own.
    set.chunks.set(p.chunkIndex, p);
  }
  for (const [key, set] of byKey) {
    const reasons: RekeyInconsistencyReason[] = [];
    if (chunkCounts.get(key)!.size !== 1) reasons.push("chunk-count");
    if (prevEpochs.get(key)!.size !== 1) reasons.push("prev-epoch");
    if (vacs.get(key)!.size !== 1) reasons.push("vac");
    if (generations.get(key)!.size !== 1) reasons.push("generation");
    set.inconsistencies = reasons;
    set.consistent = reasons.length === 0;
    for (const count of chunkCounts.get(key)!) set.chunkCount = Math.max(set.chunkCount, count);
    for (const epoch of prevEpochs.get(key)!) if (epoch < set.prevEpoch) set.prevEpoch = epoch;
    // CORD-06 §2: validated indexes in [1,n] and a consistent n make distinct
    // cardinality sufficient to prove that ALL chunks are held. Work/storage
    // must scale with observed events, never the untrusted claimed count.
    set.complete = set.consistent && set.chunks.size === set.chunkCount;
    if (set.consistent && !set.complete) {
      for (
        let index = 1;
        index <= set.chunkCount && set.missingIndexes.length < MISSING_INDEX_DIAGNOSTIC_LIMIT;
        index++
      ) {
        if (!set.chunks.has(index)) set.missingIndexes.push(index);
      }
    }
  }
  return [...byKey.values()];
}

/**
 * Verify a rotation's CONTINUITY against the key we currently hold: the
 * commitment over (prevEpoch, heldKey) must equal the event's `prevcommit`.
 * A mismatch with a HIGHER prevepoch means we missed a rotation (fetch the gap
 * first); any other mismatch is a fork or garbage — reject (CORD-06 §2).
 */
export function checkContinuity(
  set: { prevEpoch: bigint; prevCommit: string },
  heldEpoch: bigint,
  heldKey: Uint8Array,
): { ok: true } | { ok: false; reason: "gap" | "fork" } {
  if (set.prevEpoch === heldEpoch) {
    const commit = bytesToHex(epochKeyCommitment(heldEpoch, heldKey));
    return commit === set.prevCommit ? { ok: true } : { ok: false, reason: "fork" };
  }
  return { ok: false, reason: set.prevEpoch > heldEpoch ? "gap" : "fork" };
}

/** Find my blob across a complete rotation's chunks by my locator. */
export function findBlob(set: RekeyRotationSet, locatorHex: string): RekeyBlob | undefined {
  for (const chunk of set.chunks.values()) {
    const hit = chunk.blobs.find((b) => b.locator === locatorHex);
    if (hit) return hit;
  }
  return undefined;
}

/**
 * Race convergence (CORD-06 §3): among authorized candidates at the same
 * continuity point, the lexicographically lowest NEW KEY wins.
 */
export function lowerKeyWins(a: Uint8Array, b: Uint8Array): Uint8Array {
  return bytesToHex(a) <= bytesToHex(b) ? a : b;
}

/**
 * D-04's down-only anti-refork test: is `candidate` STRICTLY lower than
 * `existing` (never equal, never higher)? Built from {@link lowerKeyWins} plus
 * a byte-inequality check, so a settled epoch's latch can only ever move down,
 * never sideways or up. Shared by both the root (community.ts) and channel
 * (private-channel.ts) `checkRekey` latches, and the sync-walk re-read cascade,
 * so all three agree on exactly the same ordering.
 */
export function isStrictlyLowerKey(existing: Uint8Array, candidate: Uint8Array): boolean {
  return lowerKeyWins(existing, candidate) === candidate && bytesToHex(existing) !== bytesToHex(candidate);
}

/** Compute a rotation locator from PUBLIC inputs only (bunker-friendly). */
export function rekeyLocator(rotatorHex: string, recipientHex: string, scopeIdHex: string, newEpoch: bigint): string {
  return recipientLocator(rotatorHex, recipientHex, hexToBytes(scopeIdHex), Number(newEpoch));
}
