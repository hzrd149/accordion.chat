import type { DecodedEvent, RumorTemplate } from "../../types.ts";
import { createCommunity, type Genesis } from "../community.ts";
import type { ISigner } from "applesauce-signers";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { bytesToHex, hexToBytes } from "@noble/hashes/utils.js";
import { baseRekeyGroupKey, epochKeyCommitment } from "../crypto.ts";
import { buildRekeyRumors, bytesToBase64, encodeWrappedKey, rekeyLocator, ROOT_SCOPE_HEX } from "../rekey.ts";
import { type ConcordKeys, type RefoundingPlan, rollForward } from "../keys.ts";
import { giftWrap } from "../../operations/gift-wrap.ts";

/** Independently authored historical peer base event; deliberately bypasses the compliant writer.
 * Also supplies hostile peer inputs for receive-authority regressions. Never used by production. */
export async function historicalBaseRotation(
  keys: ConcordKeys,
  signer: ISigner,
  opts: Omit<Parameters<typeof import("../keys.ts").buildRefounding>[2], "state">,
): Promise<RefoundingPlan> {
  const material = keys.material;
  const newEpoch = material.root_epoch + 1;
  const root = opts.newRoot ?? generateSecretKey();
  const key = baseRekeyGroupKey(hexToBytes(material.community_root), hexToBytes(material.community_id), newEpoch);
  const plain = bytesToBase64(encodeWrappedKey(new Uint8Array(32), BigInt(newEpoch), root));
  const blobs = await Promise.all(opts.recipients.map(async (pk) => ({
    locator: rekeyLocator(opts.self, pk, ROOT_SCOPE_HEX, BigInt(newEpoch)),
    wrapped: await signer.nip44!.encrypt(pk, plain),
  })));
  const rekeyWraps = [];
  for (
    const draft of buildRekeyRumors({
      scope: { kind: "root" },
      newEpoch: BigInt(newEpoch),
      prevEpoch: BigInt(material.root_epoch),
      prevCommit: bytesToHex(epochKeyCommitment(material.root_epoch, hexToBytes(material.community_root))),
      vac: opts.vac,
    }, blobs)
  ) {
    rekeyWraps.push(await giftWrap(key.sk, key.convKey, signer)(await draft));
  }
  return {
    rekeyWraps,
    channelRekeyWraps: [],
    compactionWraps: [],
    snapshotWraps: [],
    next: rollForward(keys, root, newEpoch, opts.self, opts.channels),
    newEpoch,
    rekeyKey: key,
    channelRekeyKeys: [],
  };
}

/** Explicit legacy material for signed historical/base-rotation regressions.
 * The generated identity/read root and unsigned editions remain genuine; neither
 * split field is present when the fixture is sealed at its legacy coordinate. */
export async function createLegacyCommunity(opts: Parameters<typeof createCommunity>[0]): Promise<Genesis> {
  const genesis = await createCommunity(opts);
  const { control_pk: _pk, control_root: _root, ...material } = genesis.material;
  return { ...genesis, material };
}

/** A synthetic decoded plane event for fold tests — no envelope required. */
export function decoded(
  rumor: RumorTemplate,
  author: string,
  ms = 1_000,
  id: string = Math.random().toString(16).slice(2),
): DecodedEvent {
  return {
    rumor: {
      id,
      kind: rumor.kind,
      pubkey: author,
      content: rumor.content,
      tags: rumor.tags,
      created_at: Math.floor(ms / 1000),
    },
    author,
    wrapId: id,
    sealKind: 20014,
    ms,
  };
}
