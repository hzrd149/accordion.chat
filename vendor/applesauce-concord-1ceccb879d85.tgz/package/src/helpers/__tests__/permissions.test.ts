import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";

import { hexToBytes } from "@noble/hashes/utils.js";
import { PERM, VSK } from "../../types.ts";
import type { Role } from "../../types.ts";
import { canActOn, hasPerm, parsePermissions, permNames, refoundAuthority, resolveStanding } from "../permissions.ts";
import { EditionFactory } from "../../factories/control.ts";
import { createCommunity } from "../community.ts";
import { foldControl } from "../control.ts";
import { grantLocator } from "../crypto.ts";
import { computeEditionHash } from "../editions.ts";
import { decoded } from "./test-utils.ts";

const OWNER = "ab".repeat(32);
const ACTOR = "11".repeat(32);
const ROLE = "22".repeat(32);

async function authorityFixture() {
  const { material } = await createCommunity({ ownerPubkey: OWNER, name: "Test", relays: [] });
  const eid = grantLocator(hexToBytes(material.community_id), ACTOR);
  const roleBody = {
    role_id: ROLE,
    name: "admin",
    position: 1,
    permissions: PERM.BAN.toString(),
    scope: { kind: "server" },
    color: 0,
  };
  const role = decoded(
    await EditionFactory.create({ vsk: VSK.ROLE, eid: ROLE, version: 1, content: JSON.stringify(roleBody) }),
    OWNER,
  );
  const grant = decoded(
    await EditionFactory.create({
      vsk: VSK.GRANT,
      eid,
      version: 1,
      content: JSON.stringify({ member: ACTOR, role_ids: [ROLE] }),
    }),
    OWNER,
  );
  const hash = computeEditionHash({ vsk: VSK.GRANT, eid, version: 1, content: grant.rumor.content });
  const pin: [string, string, string] = [eid, "1", hash];
  const state = foldControl([role, grant], material);
  return { material, eid, role, roleBody, grant, pin, state };
}

describe("permissions", () => {
  it("parses and tests bits", () => {
    const perms = PERM.MANAGE_ROLES | PERM.BAN;
    expect(parsePermissions(perms.toString())).toBe(perms);
    expect(parsePermissions("garbage")).toBe(0n);
    expect(hasPerm(perms, PERM.BAN)).toBe(true);
    expect(hasPerm(perms, PERM.KICK)).toBe(false);
    expect(permNames(perms).sort()).toEqual(["BAN", "MANAGE_ROLES"]);
  });

  it("resolves standing and outranking", () => {
    const owner = "owner";
    const roles = new Map<string, Role>([
      [
        "mod",
        {
          role_id: "mod",
          name: "mod",
          position: 5,
          permissions: PERM.KICK.toString(),
          scope: { kind: "server" },
          color: 0,
        },
      ],
    ]);
    const grants = new Map<string, string[]>([["alice", ["mod"]]]);
    const ownerStanding = resolveStanding(owner, owner, roles, grants);
    const alice = resolveStanding("alice", owner, roles, grants);
    const bob = resolveStanding("bob", owner, roles, grants);
    expect(ownerStanding.isOwner).toBe(true);
    expect(alice.position).toBe(5);
    expect(canActOn(alice, bob, PERM.KICK)).toBe(true); // alice(5) outranks roleless bob
    expect(canActOn(bob, alice, PERM.KICK)).toBe(false); // bob has no perm
    expect(canActOn(ownerStanding, alice, PERM.BAN)).toBe(true); // owner always
  });

  it("a deleted role confers no permissions or rank", () => {
    const owner = "owner";
    const roles = new Map<string, Role>([
      [
        "mod",
        {
          role_id: "mod",
          name: "mod",
          position: 5,
          permissions: PERM.KICK.toString(),
          scope: { kind: "server" },
          color: 0,
          deleted: true,
        },
      ],
    ]);
    const grants = new Map<string, string[]>([["alice", ["mod"]]]);
    const alice = resolveStanding("alice", owner, roles, grants);
    const bob = resolveStanding("bob", owner, roles, grants);
    expect(alice.permissions).toBe(0n); // deleted role grants nothing
    expect(alice.roleIds).toEqual(["mod"]); // grant is untouched
    expect(canActOn(alice, bob, PERM.KICK)).toBe(false); // no authority left
  });

  it("refoundAuthority: owner or a BAN-holder may rotate the root", async () => {
    const roles = new Map<string, Role>([
      [
        "ban",
        {
          role_id: "ban",
          name: "admin",
          position: 1,
          permissions: PERM.BAN.toString(),
          scope: { kind: "server" },
          color: 0,
        },
      ],
      [
        "mod",
        {
          role_id: "mod",
          name: "mod",
          position: 5,
          permissions: PERM.KICK.toString(),
          scope: { kind: "server" },
          color: 0,
        },
      ],
    ]);
    const { state } = await authorityFixture();
    const canRotate = refoundAuthority(state);
    expect(canRotate(OWNER)).toBe(true);
    expect(canRotate(ACTOR)).toBe(true);
    // The pure standing helper remains valid for a KICK-only role; it cannot rotate.
    expect(hasPerm(resolveStanding("bob", "owner", roles, new Map([["bob", ["mod"]]])).permissions, PERM.BAN)).toBe(
      false,
    );
    expect(canRotate("33".repeat(32))).toBe(false);
  });
});
