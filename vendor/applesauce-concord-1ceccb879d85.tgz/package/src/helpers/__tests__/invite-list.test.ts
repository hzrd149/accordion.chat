import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";

import {
  getInviteList,
  getLiveInvites,
  INVITE_LIST_INVITE_FIELDS,
  INVITE_LIST_KIND,
  isInviteListUnlocked,
  isInviteLive,
  isValidInviteList,
  liveInviteEntries,
  mergeInvites,
  mergeTombstones,
  parseInviteList,
  unlockInviteList,
  validateInviteListInvite,
} from "../invite-list.ts";
import { buildInviteLink } from "../invite-bundle.ts";
import { InviteListFactory } from "../../factories/invite-list.ts";
import type { InviteListInvite } from "../../types.ts";
import { CORD_ROUND_TRIP_SENTENCE } from "../../__tests__/cord-wire-fixtures.ts";

describe("invite-list CRDT", () => {
  const mkEntry = (token: string, id = "c") => ({
    token,
    signer_sk: "sk-" + token,
    community_id: id,
    url: "https://example.com/invite/" + token,
    created_at: 1_000,
  });

  it("merge is commutative and idempotent, and entries are immutable (first wins)", () => {
    const a = mergeInvites([], [mkEntry("x")]);
    const b = mergeInvites([], [mkEntry("y")]);
    const ab = mergeInvites(a, b);
    const ba = mergeInvites(b, a);
    expect(ab).toEqual(ba);
    expect(mergeInvites(ab, ab)).toEqual(ab);
    // A second entry with the same token never overwrites the first (immutable).
    const conflicting = mergeInvites(a, [{ ...mkEntry("x"), url: "https://evil.example/x" }]);
    expect(conflicting).toHaveLength(1);
    expect(conflicting[0].url).toBe("https://example.com/invite/x");
  });

  it("liveness: a tombstone terminally revokes and never resurrects", () => {
    let invites = mergeInvites([], [mkEntry("x")]);
    const tombstones = mergeTombstones([], [{ token: "x", community_id: "c" }]);
    expect(isInviteLive(invites, [], "x")).toBe(true);
    expect(isInviteLive(invites, tombstones, "x")).toBe(false);
    // Re-minting the same token cannot bring a revoked link back.
    invites = mergeInvites(invites, [mkEntry("x")]);
    expect(isInviteLive(invites, tombstones, "x")).toBe(false);
    expect(liveInviteEntries(invites, tombstones)).toHaveLength(0);
  });

  it("revoke unions tombstones idempotently", () => {
    let tombstones = mergeTombstones([], [{ token: "x", community_id: "c" }]);
    tombstones = mergeTombstones(tombstones, [{ token: "x", community_id: "c" }]);
    tombstones = mergeTombstones(tombstones, [{ token: "y", community_id: "c" }]);
    expect(tombstones.map((t) => t.token)).toEqual(["x", "y"]);
  });
});

describe("invite-list entry validation", () => {
  const validEntry = (): InviteListInvite => ({
    token: "11".repeat(16),
    signer_sk: "22".repeat(32),
    community_id: "33".repeat(32),
    url: buildInviteLink("https://example.com", "44".repeat(32), new Uint8Array(16).fill(0x11), [
      "wss://relay.example.com",
    ]),
    created_at: 1_000,
  });

  it("returns a fresh closed projection while preserving absent optionals", () => {
    const raw = { ...validEntry(), injected: "drop-me" };
    const result = validateInviteListInvite(raw);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.value).not.toBe(raw);
    expect(Object.prototype.hasOwnProperty.call(result.value, "injected")).toBe(false);
    expect(Object.prototype.hasOwnProperty.call(result.value, "label")).toBe(false);
  });

  it("returns a typed secret-free failure for malformed signer material", () => {
    const result = validateInviteListInvite({ ...validEntry(), signer_sk: "not-a-secret-key" });
    expect(result).toEqual({ ok: false, field: "signer_sk", reason: "invalid" });
    expect(JSON.stringify(result)).not.toContain("not-a-secret-key");
  });

  it("declares and exercises every trusted entry field non-vacuously", () => {
    expect(INVITE_LIST_INVITE_FIELDS).toEqual([
      "token",
      "signer_sk",
      "community_id",
      "url",
      "label",
      "channels",
      "created_at",
      "expires_at",
    ]);
  });

  const REQUIRED_FIELDS = ["token", "signer_sk", "community_id", "url", "created_at"] as const;

  for (const field of REQUIRED_FIELDS) {
    it(`rejects an absent required ${field} independently`, () => {
      const raw = { ...validEntry(), [field]: undefined };
      expect(validateInviteListInvite(raw)).toEqual({ ok: false, field, reason: "missing" });
    });
  }

  const OPTIONAL_FIELDS = ["label", "channels", "expires_at"] as const;

  for (const field of OPTIONAL_FIELDS) {
    it(`preserves absent optional ${field} as no own property`, () => {
      const result = validateInviteListInvite({ ...validEntry(), [field]: undefined });
      expect(result.ok).toBe(true);
      if (result.ok) expect(Object.prototype.hasOwnProperty.call(result.value, field)).toBe(false);
    });
  }

  const INVALID_OPTIONAL_CASES = [
    ["label", 42],
    ["channels", ["not-a-channel-id"]],
    ["expires_at", 1.5],
  ] as const;

  for (const [field, value] of INVALID_OPTIONAL_CASES) {
    it(`rejects an invalid present optional ${field}`, () => {
      expect(validateInviteListInvite({ ...validEntry(), [field]: value })).toEqual({
        ok: false,
        field,
        reason: "invalid",
      });
    });
  }

  it("accepts valid present optionals without coercion", () => {
    const optionals = { label: "friends", channels: ["55".repeat(32)], expires_at: 2_000 };
    const result = validateInviteListInvite({ ...validEntry(), ...optionals });
    expect(result).toEqual({ ok: true, value: { ...validEntry(), ...optionals } });
  });
});

describe("invite-list event helpers", () => {
  const entry = (token: string, id = "c"): InviteListInvite => ({
    token,
    signer_sk: "sk-" + token,
    community_id: id,
    url: "https://example.com/invite/" + token,
    created_at: 1_000,
  });

  // Rebuild an event stripped of the in-memory plaintext cache (a wire-fresh, locked copy).
  const relock = (event: {
    id: string;
    pubkey: string;
    created_at: number;
    kind: number;
    tags: string[][];
    content: string;
    sig: string;
  }) => ({
    id: event.id,
    pubkey: event.pubkey,
    created_at: event.created_at,
    kind: event.kind,
    tags: event.tags,
    content: event.content,
    sig: event.sig,
  });

  it("isValidInviteList only matches the invite list kind", () => {
    // deno-lint-ignore no-explicit-any -- mock partial-event shape in test code
    expect(isValidInviteList({ kind: INVITE_LIST_KIND } as any)).toBe(true);
    // deno-lint-ignore no-explicit-any -- mock partial-event shape in test code
    expect(isValidInviteList({ kind: 1 } as any)).toBe(false);
  });

  it("a locked event reads as locked with no parsed list", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const event = await InviteListFactory.create().mintInvite(entry("x")).sign(signer);

    const locked = relock(event);
    expect(isInviteListUnlocked(locked)).toBe(false);
    expect(getInviteList(locked)).toBeUndefined();
    expect(getLiveInvites(locked)).toBeUndefined();
  });

  it("unlockInviteList decrypts, parses, and derives live entries", async () => {
    const signer = new PrivateKeySigner(generateSecretKey());
    const created = await InviteListFactory.create()
      .mintInvite(entry("x"))
      .mintInvite(entry("y"))
      .revokeInvite("x", "c")
      .sign(signer);

    const event = relock(created);
    expect(isInviteListUnlocked(event)).toBe(false);
    const parsed = await unlockInviteList(event, signer);
    expect(isInviteListUnlocked(event)).toBe(true);
    expect(parsed.entries.map((e) => e.token).sort()).toEqual(["x", "y"]);
    expect(parsed.tombstones.map((t) => t.token)).toEqual(["x"]);

    // "x" was revoked terminally, so only "y" is live.
    const live = getLiveInvites(event)!;
    expect(live.map((e) => e.token)).toEqual(["y"]);
    // getInviteList returns the cached parse after unlock.
    expect(getInviteList(event)).toEqual(parsed);
  });

  // WIRE-09/D-12: the parsed document IS the wire document, so an unrecognized top-level key
  // survives parse -> mutate -> serialize. Authority: CORD-05 §4's restatement of CORD-02 §6's
  // round-trip MUST, as vendored verbatim in CORD_ROUND_TRIP_SENTENCE (cord-wire-fixtures.ts) —
  // quoted below rather than asserted against, since the property under test is preservation of
  // hand-written unrecognized keys, not a numeric spec constant (D-21/TEST-01).
  //
  // See `CORD_ROUND_TRIP_SENTENCE` (imported below) for the exact vendored text.
  describe("WIRE-09 round-trip: unrecognized top-level keys survive parse/mutate/serialize", () => {
    it("cites CORD_ROUND_TRIP_SENTENCE (CORD-05 §4 restating CORD-02 §6) as the round-trip authority", () => {
      expect(CORD_ROUND_TRIP_SENTENCE).toContain("round-trip fields it doesn't understand");
    });

    it("parseInviteList preserves unrecognized top-level keys — a scalar and a nested object — alongside entries/tombstones", () => {
      // `future_protocol_field` stands in for a real future protocol field this client version
      // does not know (CORD-02 §6: top-level fields outside `custom` are reserved for the
      // protocol). `custom` is another client's extension data. Both must survive, for different
      // reasons (D-13).
      const custom = { schema_version: 3, flags: ["a", "b"] };
      const doc = {
        entries: [entry("x")],
        tombstones: [],
        future_protocol_field: "not-junk-a-real-future-field",
        custom,
      };
      const parsed = parseInviteList(JSON.stringify(doc));
      expect(parsed.future_protocol_field).toBe("not-junk-a-real-future-field");
      expect(parsed.custom).toEqual(custom);
      expect(parsed.entries).toHaveLength(1);
    });

    it("a document carrying ONLY an unrecognized top-level key still defaults entries/tombstones to empty arrays", () => {
      const parsed = parseInviteList(JSON.stringify({ custom: { a: 1 } }));
      expect(parsed.entries).toEqual([]);
      expect(parsed.tombstones).toEqual([]);
      expect(parsed.custom).toEqual({ a: 1 });
    });

    it("modifyInviteList (via InviteListFactory) round-trips an unrecognized top-level key through a mint, asserted on the raw re-serialized plaintext", async () => {
      const signer = new PrivateKeySigner(generateSecretKey());
      const pubkey = await signer.getPublicKey();
      const custom = { schema_version: 3, flags: ["a", "b"] };
      const plaintext = JSON.stringify({
        entries: [],
        tombstones: [],
        future_protocol_field: "not-junk-a-real-future-field",
        custom,
      });
      const content = await signer.nip44!.encrypt(pubkey, plaintext);
      const seed = await signer.signEvent({ kind: INVITE_LIST_KIND, content, tags: [], created_at: 1 });

      const minted = await InviteListFactory.modify(seed).mintInvite(entry("x")).sign(signer);

      // Assert on the RAW re-serialized plaintext (never by re-reading through parseInviteList,
      // which would let a rename hide from this test) — the wire key set and both unrecognized
      // keys must survive.
      const rawPlaintext = await signer.nip44!.decrypt(pubkey, minted.content);
      const raw = JSON.parse(rawPlaintext) as Record<string, unknown>;
      expect(Object.keys(raw).sort()).toEqual(["custom", "entries", "future_protocol_field", "tombstones"]);
      expect(raw.future_protocol_field).toBe("not-junk-a-real-future-field");
      expect(raw.custom).toEqual(custom);
      expect((raw.entries as { token: string }[]).map((e) => e.token)).toEqual(["x"]);
    });
  });
});
