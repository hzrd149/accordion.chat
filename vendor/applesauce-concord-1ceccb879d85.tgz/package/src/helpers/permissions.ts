// CORD-04 permission / roster resolution.

import { hexToBytes } from "@noble/hashes/utils.js";
import { grantLocator } from "./crypto.ts";
import { PERM, VSK } from "../types.ts";
import type { CommunityState, PermName, Role } from "../types.ts";
import { resolveEditionPin } from "./editions.ts";
import { stateTargetSupportReady } from "./authority-support.ts";

/** Parse a role's permission bits from their decimal string form, defaulting to
 *  no bits when the value is unparseable — a malformed role confers nothing
 *  rather than failing the fold. */
export function parsePermissions(value: string): bigint {
  try {
    return BigInt(value);
  } catch {
    return 0n;
  }
}

/** Whether `perms` holds EVERY bit in `perm`, so it is safe to pass a multi-bit
 *  mask and get an all-of (never an any-of) answer. */
export function hasPerm(perms: bigint, perm: bigint): boolean {
  return (perms & perm) === perm;
}

/** Any of the six Control Plane staff bits, independent of role names or ADMIN_PERMS (CORD-04 §3). */
export function isStaffPermissionMask(permissions: bigint): boolean {
  const staff = PERM.MANAGE_ROLES | PERM.MANAGE_CHANNELS | PERM.MANAGE_METADATA | PERM.BAN |
    PERM.CREATE_INVITE | PERM.PIN_MESSAGES;
  return (permissions & staff) !== 0n;
}

/** The names of every permission bit set in `perms` (CORD-04 §3) — for display;
 *  authority checks use {@link hasPerm} against the bits themselves. */
export function permNames(perms: bigint): PermName[] {
  return (Object.keys(PERM) as PermName[]).filter((k) => hasPerm(perms, PERM[k]));
}

/** A member's resolved standing in the roster. */
export interface Standing {
  /** union of all role permission bits */
  permissions: bigint;
  /** lowest (highest-authority) position among held roles; owner is 0 */
  position: number;
  /** True only for the community owner, whose authority is proven by the
   *  community_id itself (CORD-02) rather than by any role. */
  isOwner: boolean;
  /** The ids of the roles granted to this member. */
  roleIds: string[];
}

const ROLELESS_POSITION = 0xffffffff;

/**
 * Resolve a member's standing from the folded roster.
 * The owner (proven by community_id, CORD-02) is position 0 and holds every bit.
 */
export function resolveStanding(
  member: string,
  owner: string,
  roles: Map<string, Role>,
  grants: Map<string, string[]>,
): Standing {
  if (member === owner) {
    let all = 0n;
    for (const p of Object.values(PERM)) all |= p;
    return { permissions: all, position: 0, isOwner: true, roleIds: [] };
  }
  const roleIds = grants.get(member) ?? [];
  let permissions = 0n;
  let position = ROLELESS_POSITION;
  for (const id of roleIds) {
    const role = roles.get(id);
    if (!role || role.deleted) continue; // a deleted role confers nothing
    permissions |= parsePermissions(role.permissions);
    if (role.position < position) position = role.position;
  }
  return { permissions, position, isOwner: false, roleIds };
}

/** Actor may act on target: holds the bit AND strictly outranks the target. */
export function canActOn(actor: Standing, target: Standing, required: bigint): boolean {
  if (actor.isOwner) return true;
  if (!hasPerm(actor.permissions, required)) return false;
  return actor.position < target.position;
}

/** CORD-04 §§1–5: only the verified, currently supported roster conveys authority. */
function currentStanding(state: CommunityState, roles: Map<string, Role>, member: string): Standing | undefined {
  const verification = state.controlVerification;
  if (!verification || verification.communityId !== state.material.community_id || state.banlist.has(member)) {
    return undefined;
  }
  const eid = grantLocator(hexToBytes(state.material.community_id), member);
  if (verification.suspended.has(eid) || verification.heads.get(eid)?.vsk !== VSK.GRANT) return undefined;
  const supported = new Map<string, Role>();
  for (const id of state.grants.get(member) ?? []) {
    if (verification.suspended.has(id) || verification.heads.get(id)?.vsk !== VSK.ROLE) continue;
    const role = roles.get(id);
    if (role) supported.set(id, role);
  }
  return resolveStanding(member, state.material.owner, supported, state.grants);
}

/** Whether a member currently has any Control Plane staff bit through verified,
 * owner-rooted, unsuspended support (CORD-04 §§1–5). The intrinsic owner remains
 * exempt; missing verification and bans fail closed for every other member.
 * Secret possession and historical Grants do not confer current authority. */
export function isCurrentStaff(state: CommunityState, member: string): boolean {
  if (member === state.material.owner) return true;
  try {
    const standing = currentStanding(state, new Map(state.roles.map((role) => [role.role_id, role])), member);
    return !!standing && isStaffPermissionMask(standing.permissions);
  } catch {
    return false;
  }
}

/**
 * Who may rotate a community's root (CORD-06 §1; CORD-04 §§2–5): the owner, or
 * a currently unbanned member holding BAN through verified, unsuspended roster
 * support. Missing verification fails closed for non-owners. Historical Grant
 * evidence and key possession confer no current authority — a removed member
 * still holding the prior root can forge a perfect rotation. Returns a predicate
 * so both the initiate path (refound) and the read path (checkRekey) test the
 * same rule against the same folded state. `requiredPerm` defaults to BAN;
 * channel rotation uses MANAGE_CHANNELS. An optional `target` also requires
 * strict rank and denies removal while the target's support is suspended.
 */
export function refoundAuthority(
  state: CommunityState,
  requiredPerm: bigint = PERM.BAN,
  target?: string,
): (rotator: string) => boolean {
  const owner = state.material.owner;
  const rolesMap = new Map<string, Role>(state.roles.map((r) => [r.role_id, r]));
  return (rotator) => {
    if (rotator === owner) return target !== owner;
    try {
      const standing = currentStanding(state, rolesMap, rotator);
      if (!standing || !hasPerm(standing.permissions, requiredPerm)) return false;
      if (target === undefined) return true;
      if (!stateTargetSupportReady(state, target)) return false;
      return canActOn(standing, resolveStanding(target, owner, rolesMap, state.grants), requiredPerm);
    } catch {
      return false;
    }
  };
}

/**
 * Verify exact historically authorized Grant evidence, then current permission
 * (CORD-04 §§1, 4–5). Owners are intrinsically exempt. Other actors must cite
 * their {@link grantLocator}, version and hash in the fold's validated history,
 * and still hold every `requiredPerm` bit in the unbanned, unsuspended roster.
 * Missing evidence returns false until synchronized; this pure helper does no
 * fetching. When `target` is supplied, also require strict current target rank;
 * suspended target support cannot be treated as a roleless removal target.
 * The returned predicate also accepts an optional per-action target, used by
 * Guestbook folds to check each Kick against the same readiness/rank rules.
 */
export function vacVerifier(
  state: CommunityState,
  requiredPerm: bigint,
  target?: string,
): (rotator: string, vac: [string, string, string] | undefined, actionTarget?: string) => boolean {
  const owner = state.material.owner;
  return (rotator, vac, actionTarget = target) => {
    if (rotator === owner) return actionTarget !== owner;
    if (!vac) return false;
    try {
      const verification = state.controlVerification;
      if (!verification || verification.communityId !== state.material.community_id) return false;
      const eid = grantLocator(hexToBytes(state.material.community_id), rotator);
      if (vac[0]?.toLowerCase() !== eid) return false;
      const history = (verification.grantHistory.get(eid) ?? []).filter((entry) => {
        if (
          entry.vsk !== VSK.GRANT || entry.eid !== eid || entry.member !== rotator ||
          String(entry.version) !== vac[1] || entry.hash !== vac[2]?.toLowerCase()
        ) return false;
        const rumor = entry.edition.rumor;
        if (Number(rumor.tags.find((t) => t[0] === "vsk")?.[1]) !== VSK.GRANT) return false;
        const body: unknown = JSON.parse(rumor.content);
        return typeof body === "object" && body !== null && "member" in body && body.member === rotator &&
          "role_ids" in body && Array.isArray(body.role_ids) &&
          body.role_ids.every((id: unknown) => typeof id === "string");
      });
      if (resolveEditionPin(history.map((entry) => entry.edition), vac).kind !== "matched") return false;
      return refoundAuthority(state, requiredPerm, actionTarget)(rotator);
    } catch {
      // Malformed caller evidence must park this action, never abort a fold.
      return false;
    }
  };
}
