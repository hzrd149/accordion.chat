import { EventCast, User } from "applesauce-core/casts";
import type { HiddenContentSigner, NostrEvent } from "applesauce-core/helpers";
import { castEventStream } from "applesauce-core/observable/cast-stream";
import { watchEventUpdates } from "applesauce-core/observable";
import type { ChainableObservable } from "applesauce-core/observable";
import "applesauce-common/casts";
import { map, of, switchMap } from "rxjs";

import "../helpers/register.ts";
import {
  COMMUNITY_LIST_KIND,
  getCommunityList,
  getLiveCommunities,
  isCommunityListUnlocked,
  type ParsedCommunityList,
  unlockCommunityList,
} from "../helpers/community-list.ts";
import type { CommunityListCommunity, CommunityTombstone } from "../types.ts";

/** A cast for a Concord CORD-02 encrypted Community List event (kind 13302). */
export class ConcordCommunityList extends EventCast {
  /** Wraps a kind 13302 event; throws if `event` is not a Community List. */
  constructor(event: NostrEvent, store: ConstructorParameters<typeof EventCast>[1]) {
    if (event.kind !== COMMUNITY_LIST_KIND) throw new Error("Invalid Concord community list event");
    super(event, store);
  }

  /** Whether the self-encrypted community list plaintext is cached on the event. */
  get unlocked(): boolean {
    return isCommunityListUnlocked(this.event);
  }

  /** The decrypted membership communities, if the event has been unlocked. This getter's name is
   *  the package's public vocabulary; the document's key is the wire's `entries` (D-12 aligned the
   *  parsed type to the wire without breaking this cast surface). */
  get communities(): CommunityListCommunity[] | undefined {
    return getCommunityList(this.event)?.entries;
  }

  /** The decrypted tombstones (left communities), if the event has been unlocked. */
  get tombstones(): CommunityTombstone[] | undefined {
    return getCommunityList(this.event)?.tombstones;
  }

  /** The live community memberships derived from the unlocked communities and tombstones. */
  get liveCommunities(): CommunityListCommunity[] | undefined {
    return getLiveCommunities(this.event);
  }

  /** The decrypted memberships as an observable — emits `undefined` until unlocked, then re-emits on unlock. */
  get communities$(): ChainableObservable<CommunityListCommunity[] | undefined> {
    return this.$$ref("communities$", (store) =>
      of(this.event).pipe(
        watchEventUpdates(store),
        // The getter name is the package's public vocabulary; the document's key is the wire's.
        map((event) => event && getCommunityList(event)?.entries),
      ));
  }

  /** The live memberships as an observable — emits `undefined` until unlocked, then re-emits on unlock. */
  get liveCommunities$(): ChainableObservable<CommunityListCommunity[] | undefined> {
    return this.$$ref("liveCommunities$", (store) =>
      of(this.event).pipe(
        watchEventUpdates(store),
        map((event) => event && getLiveCommunities(event)),
      ));
  }

  /** The decrypted tombstones (left communities) as an observable — emits `undefined` until unlocked. */
  get tombstones$(): ChainableObservable<CommunityTombstone[] | undefined> {
    return this.$$ref("tombstones$", (store) =>
      of(this.event).pipe(
        watchEventUpdates(store),
        map((event) => event && getCommunityList(event)?.tombstones),
      ));
  }

  /** Unlock and parse the self-encrypted community list using the owning user's signer. */
  async unlock(signer: HiddenContentSigner): Promise<ParsedCommunityList> {
    return unlockCommunityList(this.event, signer);
  }
}

/**
 * A `User` with the `concordCommunityList$` getter this module registers on `User.prototype` at
 * import time. Consumers cast to this interface, because JSR rejects ambient module augmentations
 * in published source (D-82).
 */
export interface ConcordCommunityListUser extends User {
  /** The user's Concord Community List event (kind 13302), if present in the event store. */
  readonly concordCommunityList$: ChainableObservable<ConcordCommunityList | undefined>;
}

if (!Object.getOwnPropertyDescriptor(User.prototype, "concordCommunityList$")) {
  Object.defineProperty(User.prototype, "concordCommunityList$", {
    get: function (this: User) {
      return this.$$ref("concordCommunityList$", (store) =>
        this.outboxes$.pipe(
          switchMap((outboxes) =>
            store
              .replaceable({ kind: COMMUNITY_LIST_KIND, pubkey: this.pubkey, relays: outboxes })
              .pipe(castEventStream(ConcordCommunityList, store))
          ),
        ));
    },
    enumerable: true,
    configurable: false,
  });
}
