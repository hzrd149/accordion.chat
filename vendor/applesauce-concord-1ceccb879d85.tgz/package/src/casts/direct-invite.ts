// Cast the unwrapped kind-3313 rumor, not its NIP-59 envelope (CORD-05 §6).
// Gift-wrap decoding verifies the seal and author binding; the store resolves
// that verified inviter to a User and provides per-event deduplication.

import type { CastRefEventStore } from "applesauce-core/casts";
import { EventCast } from "applesauce-core/casts";
import { unixNow } from "applesauce-core/helpers/time";
import type { DirectInviteRumor } from "../helpers/direct-invite.ts";
import { getDirectInviteBundle, isValidDirectInviteRumor } from "../helpers/direct-invite.ts";
import type { InviteBundle, Rumor } from "../types.ts";

/** A cast for a CORD-05 §6 Direct Invite (an unwrapped kind 3313 rumor). */
export class ConcordDirectInvite extends EventCast<DirectInviteRumor> {
  /** Wraps an already-unwrapped kind 3313 rumor; throws if it is not a Direct Invite. */
  constructor(event: Rumor, store: CastRefEventStore) {
    if (!isValidDirectInviteRumor(event)) throw new Error("Invalid Concord direct invite rumor (expected kind 3313)");
    super(event, store);
  }

  /** The unwrapped rumor (an alias for `event`, narrowed to a Direct Invite rumor). */
  get rumor(): DirectInviteRumor {
    return this.event;
  }

  /**
   * The inviter's real pubkey — the seal author. The gift-wrap decode enforces the
   * CORD-01 author binding, so this is the cryptographically-proven inviter.
   * (For the inviter as a resolvable profile, use the inherited `author`.)
   */
  get inviter(): string {
    return this.event.pubkey;
  }

  /**
   * The validated, self-certified §1 bundle, or `undefined` if the payload fails
   * the owner proof or the §1 bounds. Parsed once and memoized on the rumor by
   * {@link getDirectInviteBundle}.
   */
  get bundle(): InviteBundle | undefined {
    return getDirectInviteBundle(this.rumor);
  }

  /** Whether the invite carries a valid, self-certifying bundle. */
  get valid(): boolean {
    return this.bundle !== undefined;
  }

  /** The community id the invite grants access to, if the bundle is valid. */
  get communityId(): string | undefined {
    return this.bundle?.community_id;
  }

  /** Optional unix-seconds expiry (D-05); past it the preview still renders but joining refuses (CORD-05 §1). */
  get expiresAt(): number | undefined {
    return this.bundle?.expires_at;
  }

  /** Whether the invite has expired as of `now` (unix seconds). Always false when no expiry is set. */
  expired(now: number = unixNow()): boolean {
    const exp = this.expiresAt;
    return exp !== undefined && now > exp;
  }
}

// No dedicated cast helper: cast an unwrapped gift-wrap rumor (kind 3313) with core's generic
// `castEvent(rumor, ConcordDirectInvite, store)`. It throws if the rumor is not a Direct Invite
// (guard with `isValidDirectInviteRumor` when scanning a mixed giftwrap inbox); the `store`
// powers the inherited `author` accessor.
