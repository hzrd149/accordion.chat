/**
 * Concord `EventCast` wrappers — rich, store-backed accessors over the community
 * documents that live *outside* the gift-wrap envelope: the self-encrypted
 * Community List (kind 13302, CORD-02 §8) and Invite List (kind 13303,
 * CORD-05 §4), the addressable invite bundle (kind 33301, CORD-05 §1), and the
 * unwrapped Direct Invite rumor (kind 3313, CORD-05 §6). Each cast exposes the
 * decrypted document both as a plain getter and as an observable that re-emits
 * once the event is unlocked.
 *
 * Importing this module also registers `concordCommunityList$` and
 * `concordInviteList$` getters on applesauce's `User` prototype. JSR rejects
 * ambient module augmentations in published source, so consumers reach that
 * typing by casting a `User` to the exported {@link ConcordCommunityListUser} or
 * {@link ConcordInviteListUser} interface rather than through a global
 * `declare module` (D-82).
 *
 * @example
 * ```ts
 * import { ConcordCommunityList } from "@applesauce/concord/casts";
 * ```
 *
 * @module
 */

export * from "./community-list.ts";
export * from "./invite-bundle.ts";
export * from "./direct-invite.ts";
export * from "./invite-list.ts";
