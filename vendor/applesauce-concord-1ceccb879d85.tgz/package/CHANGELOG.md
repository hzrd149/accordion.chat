# @applesauce/concord

## Unreleased

### Breaking (major)

- Applesauce dependencies moved from the v7 prerelease to stable `^7` releases, so apps must use stable Applesauce v7
  packages alongside this library.
- `buildRefounding` now requires the current verified community `state` and held control signing capability, and its
  returned plan must be published and adopted in order.
- `ConcordKeys.control` and `CommunityKeys.control` are now read descriptors with an optional `signing` field, so read
  with `control.convKey` and check `control.signing` before signing control documents.
- Staff admin actions are now rejected unless the actor's current verified role, permissions and rank allow them, so
  apps should handle rejected admin calls when authority changes.
- Channel stores now keep deletion requests alongside the original events, so render messages through
  `community.channelTimeline` or a private channel's `timeline` instead of reading raw stores.

### Added (minor)

- New communities give members a read-only control key and reserve control signing for staff, with `controlKeyFor` and
  `controlSignerGroupKey` to access each.
- Base rotations can upgrade older communities to split member and staff keys while keeping their history readable, with
  new helpers including `assertBaseRotationSupported` and `currentBaseRekeys`.
- Staff Grants now deliver the control signing key to the granted member, with `encodeControlRootDelivery`,
  `decodeControlRootDelivery`, `isCurrentStaff`, `isStaffPermissionMask` and a new `PERM.PIN_MESSAGES` bit (pin actions
  are not implemented yet).
- Encrypted community lists now carry complete key history and staff signing keys across devices, and standalone
  communities can persist new key material through `onMaterialChange` before it is used.
- Refoundings can be safely retried with `community.admin.refound()` after a crash or partial publish when durable
  pending and membership storage is configured.
- `decodeReceivedWrap` and `verifyReceiveEnvelope` let apps verify incoming events before storing them, and sync accepts
  `controlVerification`, `controlHistory` and `SyncContext.onCancel` for continuity and cancellation.
- `ConcordChatTimelineModel`, `community.channelTimeline` and private channel `timeline` provide message timelines that
  update when bans or authority change.
- `InviteRevocationPublishError` is now exported from `/client` and the root, so apps can catch failed invite
  revocations with `instanceof`.

### Fixed (patch)

- `ban()` now rejects before publishing when the caller lacks `MANAGE_ROLES`, instead of leaving the ban in place with
  the member's roles intact.
- `createInvite()` now rejects before publishing anything when the caller lacks `CREATE_INVITE`, instead of leaving an
  unusable invite bundle on relays.
- `sendMessage()` to an unknown channel now fails before uploading any attachments.
- Importing only `/operations` now sets up Community List and Invite List encryption, so `modifyCommunityList` and
  `modifyInviteList` work without importing another barrel.

- Observed-author and community state models now update activity incrementally and skip membership notifications for
  ordinary messages from members who are already present.

- Community and private-channel receive paths and historical sync now reuse authenticated decodes for identical wire
  bytes, reducing repeated signature checks and decryption.

- `deriveConcordKeys` now reuses archived root and public-channel keys during repeated updates, reducing CPU use in
  communities with retained history.

- Historical community and channel sync now includes previously cached events, reports an error when every relay fails,
  and can be retried by calling `start()` again.
- Sync now handles relays that cap results, time out or require authentication, and public channel catch-up failures are
  reported instead of becoming unhandled rejections.
- Malformed or unauthorized control documents no longer crash community state or hide valid settings, and circular role
  delegation no longer grants authority.
- Revoked, banned or suspended staff can no longer act through stale cached permissions, and removed roles, grants and
  bans stay removed.
- Invalid incoming events are rejected before being stored, including with custom stores, and one bad rotation message
  no longer blocks valid key updates.
- Key changes are saved before use and survive failed saves, disposal and concurrent updates without losing newer state,
  and live subscriptions start only after historical sync completes.

See the [admin](docs/guide/admin.md), [client](docs/guide/client.md), [messaging](docs/guide/messaging.md) and
[storage](docs/guide/storage.md) guides for migration and durability requirements.

## 0.1.0

First JSR release as `@applesauce/concord`, a hard fork of the unreleased npm package `applesauce-concord`. The package
version resets from the monorepo's `6.2.0` to `0.1.0`; the npm name is retired. The earlier history below is retained
for provenance, not a published npm upgrade path.

### Distribution

- Deno-native TypeScript published directly to JSR, with no build step or separate declaration output.
- Seven supported entrypoints: `@applesauce/concord` and `/helpers`, `/operations`, `/factories`, `/casts`, `/models`
  and `/client`. Replace wildcard/deep imports with these barrels.

### API changes

- Removed runtime exports `RotationCoordinator`, `shouldAdoptRotation`, `InviteRevocationPublishError` and
  `requireInviteRevocationAck`. Rotation types remain available; use `StreamSigners` for supported auth integration.
  `createUserAuthHandler`, `lookupRelayStatus` and `connectedRelays$` remain internal.
- Replaced ambient `User` getter augmentation with `ConcordCommunityListUser` and `ConcordInviteListUser` from
  `@applesauce/concord/casts`. Import that barrel at runtime to register the getters, then cast to the relevant
  interface or declare a local augmentation. Getter behavior is unchanged.
- Added named type exports for `ConcordRumorStore`, `ConcordStorage`, `ConcordStoreFactory`, `ConcordUploader`,
  `ConcordUploadProgress` and `ConcordUploadOptions` in `/client`, and `RuleKind`, `RuleForPresent`, `AssertNever` and
  `RuleTableKeysExactly` in `/helpers`. These add no runtime exports.

## 6.2.0

Initial release as a standalone package.
